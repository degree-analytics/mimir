# Documentation Navigation Patterns

## Purpose
System-wide documentation navigation standards and breadcrumb patterns for consistent user experience across all Spacewalker documentation. Essential reference for all documentation contributors and maintainers across backend, mobile, admin, and workflow documentation.

## When to Use This
- Implementing breadcrumb navigation in documentation pages
- Understanding documentation hierarchy and organization patterns
- Creating consistent navigation experiences across platforms
- Maintaining documentation structure and cross-references
- Onboarding new documentation contributors
- Keywords: documentation navigation, breadcrumb patterns, documentation standards, navigation consistency

**Version:** 2.0 (Reorganized from contributing guidelines)
**Date:** 2025-06-29
**Status:** Current - Stable Documentation Navigation Standards

---

## Navigation Pattern Overview

### What are Documentation Breadcrumbs?
Breadcrumb navigation provides users with a clear path showing their current location within the documentation hierarchy. It enables quick navigation to parent sections and improves overall user experience by providing context across all Spacewalker documentation platforms.

### When to Implement Breadcrumbs
Apply breadcrumb navigation to documentation pages meeting these criteria:
- **3+ levels deep** in directory structure
- **Complex technical content** requiring hierarchical context
- **Cross-platform documentation** spanning multiple systems
- **User workflow documentation** with sequential steps

### System-Wide Benefits
- **Improved Cross-Platform Navigation** - Consistent experience across backend, mobile, admin docs
- **Clear Hierarchical Context** - Users understand location in overall documentation system
- **Reduced Navigation Confusion** - Less reliance on browser back button for complex workflows
- **Enhanced Discoverability** - Better discovery of related content across platform boundaries

---

## Standard Design Specification

### Universal Visual Format
```markdown
---
**Breadcrumb Navigation:**
🏠 [Home](/) > [Documentation](../) > [Category] > Page Title
---
```

### Design Elements (System-Wide Standards)
- **Home Icon**: 🏠 (house emoji) - Always first element across all documentation
- **Delimiter**: `>` (greater-than symbol) with spaces - Consistent across platforms
- **Links**: Standard markdown links `[Text](URL)` for all parent levels
- **Current Page**: Plain text (non-clickable) for final element
- **Placement**: Always at document top, before main heading with separator lines

### Visual Example
```
🏠 Home > Documentation > Backend Architecture > Security Architecture
```

---

## Platform-Specific Implementation Patterns

### Backend Documentation Hierarchy
**Pattern**: `🏠 [Home](/) > [Backend](../backend/) > [Category] > Page Title`

**Use for**:
- Backend architecture documents
- API development guides
- Database and migration documentation
- Backend service implementations

**Examples**:
```markdown
🏠 [Home](/) > [Backend](../backend/) > [Architecture](../backend/architecture/) > Security Architecture
🏠 [Home](/) > [Backend](../backend/) > [Development](../backend/development/) > API Development
🏠 [Home](/) > [Backend](../backend/) > [Requirements](../backend/requirements.md) > Backend Requirements
```

### Mobile Documentation Hierarchy
**Pattern**: `🏠 [Home](/) > [Mobile](../mobile/) > [Category] > Page Title`

**Use for**:
- Mobile architecture and design patterns
- React Native implementation guides
- Mobile UX and workflow documentation
- Offline-first development patterns

**Examples**:
```markdown
🏠 [Home](/) > [Mobile](../mobile/) > [Architecture](../mobile/architecture/) > Mobile Architecture
🏠 [Home](/) > [Mobile](../mobile/) > [Development](../mobile/development/) > React Native Patterns
🏠 [Home](/) > [Mobile](../mobile/) > [Requirements](../mobile/requirements.md) > Mobile Requirements
```

---

## Related Documentation Standards

### Platform Documentation
- **[Backend Architecture](../backend/architecture/README.md)** - Backend-specific documentation patterns
- **[Mobile Architecture](../mobile/architecture/README.md)** - Mobile documentation organization
- **[Admin Architecture](../admin/architecture/README.md)** - Admin documentation structure

### Workflow Documentation
- **[Development Setup](../setup/development-setup.md)** - Cross-platform development environment

---

**Status**: Updated navigation patterns with clean formatting and fixed cross-references
**Last Updated**: 2025-06-29
