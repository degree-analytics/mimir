# Rooms API Quick Reference Guide

## 🎯 The Golden Rule

**"Read from Inventory, Write to Rooms"**

## Quick Decision Tree

```mermaid
graph TD
    A[What do you need to do?] --> B{Operation Type}
    B --> C[Display/Read Data]
    B --> D[Create/Update/Delete]

    C --> E[Use Inventory API<br/>/inventory/rooms/*]
    D --> F[Use Rooms API<br/>/rooms/*]

    E --> G[rooms.getAll<br/>rooms.getById<br/>rooms.export<br/>rooms.getStatistics]
    F --> H[rooms.create<br/>rooms.update<br/>rooms.delete]
```

## API Method Reference

### Display & Analytics (Inventory API)

| Method | Endpoint | Use When |
|--------|----------|----------|
| `rooms.getAll()` | GET `/inventory/rooms` | Displaying room lists with survey data |
| `rooms.getById()` | GET `/inventory/rooms/{id}` | Showing room details with survey info |
| `rooms.export()` | GET `/inventory/rooms/export` | Exporting to CSV/Excel |
| `rooms.getStatistics()` | GET `/inventory/statistics` | Dashboard analytics |
| `rooms.updateAttributes()` | POST `/inventory/rooms/{id}/attributes` | Updating survey attributes |

### CRUD Operations (Rooms API)

| Method | Endpoint | Use When |
|--------|----------|----------|
| `rooms.create()` | POST `/rooms` | Adding new rooms to buildings |
| `rooms.update()` | PUT `/rooms/{id}` | Changing room info (name, type, etc.) |
| `rooms.delete()` | DELETE `/rooms/{id}` | Removing rooms from buildings |

## Common Scenarios

### Scenario: Building Detail Page
```typescript
// Show all rooms in a building with survey status
const roomsList = await rooms.getAll({ building_id: 123 });
```

### Scenario: Create Room Modal
```typescript
// User fills out form to add new room
const newRoom = await rooms.create({
  floor_id: 45,
  number: "201A",
  name: "Conference Room",
  space_type: "meeting",
  area: 250.5
});

// After creation, refresh the list (gets survey-enriched data)
const updatedList = await rooms.getAll({ floor_id: 45 });
```

### Scenario: Edit Room Information
```typescript
// Update basic room properties
await rooms.update(roomId, {
  name: "Large Conference Room",
  space_type: "conference",
  area: 300.0
});

// To display updated room with survey data
const updatedRoom = await rooms.getById(roomId);
```

### Scenario: Room Analytics Dashboard
```typescript
// Get statistics for dashboard
const stats = await rooms.getStatistics();

// Export filtered rooms
const csvData = await rooms.export({
  survey_status: 'completed',
  building_id: 123
});
```

## Data Model Differences

### Inventory API Response (Rich)
```typescript
{
  id: 1,
  number: "101",
  name: "Conference Room",
  // Survey-specific fields:
  survey_count: 5,
  last_survey_date: "2024-01-15T...",
  ficm_design_type: { code: "110", name: "Office" },
  latest_images: [...],
  attributes: [{ key: "condition", value: "good", confidence: 0.95 }]
}
```

### Rooms API Response (Basic)
```typescript
{
  id: 1,
  number: "101",
  name: "Conference Room",
  floor_id: 10,
  space_type: "meeting",
  area: 250.5
  // No survey data
}
```

## Common Pitfalls

### ❌ Don't mix data models
```typescript
// WRONG: Inventory data structure ≠ Rooms update structure
const room = await rooms.getById(123);  // Returns inventory format
await rooms.update(123, room);          // Expects rooms format
```

### ✅ Do transform when needed
```typescript
// RIGHT: Only send fields the rooms API expects
const room = await rooms.getById(123);
await rooms.update(123, {
  name: room.name,
  space_type: room.space_type,
  // Only basic fields, no survey data
});
```

## Testing Checklist

- [ ] Read operations hit `/inventory/*` endpoints
- [ ] Write operations hit `/rooms/*` endpoints
- [ ] Create/update return basic data (not survey-enriched)
- [ ] List/get return survey-enriched data
- [ ] Data transformations work between formats

## Need More Info?

- Full Architecture Doc: `docs/architecture/inventory-vs-rooms-api-pattern.md`
- API Client Code: `apps/admin/src/lib/api.ts`
- Backend Routes:
  - `apps/backend/src/spacecargo/api/routers/inventory.py`
  - `apps/backend/src/spacecargo/api/routers/rooms.py`
