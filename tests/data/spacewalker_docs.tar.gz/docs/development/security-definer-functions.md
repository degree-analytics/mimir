# SECURITY DEFINER Functions Documentation

## Overview

SECURITY DEFINER functions in PostgreSQL allow specific database operations to execute with elevated privileges while maintaining security through strict input validation and audit logging. This pattern is essential for cross-tenant operations in multi-tenant applications with Row-Level Security (RLS).

## Why SECURITY DEFINER Functions?

### The Problem
- RLS policies restrict data access based on tenant context
- Some operations legitimately need to cross tenant boundaries (e.g., user transfers, invitation acceptance)
- Direct privilege elevation in application code creates security risks
- Session cache issues can cause StaleDataError exceptions

### The Solution
SECURITY DEFINER functions provide:
- **Controlled privilege elevation** - Functions run with owner's privileges, not caller's
- **Input validation** - All parameters validated before execution
- **Audit logging** - Every operation logged for security tracking
- **Atomic operations** - Database handles transaction boundaries
- **Performance** - Reduced round trips between application and database

## Available SECURITY DEFINER Functions

### 1. accept_tenant_invitation
**Purpose**: Allow users to accept invitations and join new tenants

```sql
SELECT accept_tenant_invitation(
    p_invitation_id := 'invitation-uuid',
    p_user_id := 'user-uuid'
);
```

**Operations performed**:
- Validates invitation exists and is pending
- Updates user's tenant_id
- Marks invitation as accepted
- Creates audit log entry

**Use cases**:
- New user registration with invitation
- Existing user accepting invitation to join another tenant

### 2. move_user_to_tenant
**Purpose**: Transfer a user between tenants (admin operation)

```sql
SELECT move_user_to_tenant(
    p_user_id := 'user-uuid',
    p_from_tenant_id := 'source-tenant-uuid',
    p_to_tenant_id := 'target-tenant-uuid',
    p_moved_by := 'admin-user-uuid'
);
```

**Operations performed**:
- Validates user exists in source tenant
- Validates target tenant exists and is active
- Updates user's tenant_id
- Updates tenant_members table
- Creates audit log with move details

**Use cases**:
- Admin moving users between departments/organizations
- User account consolidation
- Tenant mergers

### 3. get_tenant_analytics
**Purpose**: Retrieve analytics data across all tenants (super-user only)

```sql
SELECT * FROM get_tenant_analytics(
    p_start_date := '2024-01-01',
    p_end_date := '2024-12-31',
    p_requested_by := 'superuser-uuid'
);
```

**Returns**: Table with columns:
- tenant_id
- tenant_name
- user_count
- building_count
- room_count
- last_activity
- created_at

**Use cases**:
- Platform-wide usage reports
- Billing calculations
- Tenant health monitoring

### 4. bulk_update_tenant_settings
**Purpose**: Update settings for multiple tenants simultaneously

```sql
SELECT bulk_update_tenant_settings(
    p_tenant_ids := ARRAY['tenant1-uuid', 'tenant2-uuid'],
    p_settings := '{"feature_x": true, "limit_y": 100}'::jsonb,
    p_updated_by := 'admin-uuid'
);
```

**Operations performed**:
- Validates all tenant IDs exist
- Updates settings for each tenant
- Creates audit log for bulk operation

**Use cases**:
- Feature rollouts
- Bulk configuration changes
- Emergency setting updates

### 5. clone_building_to_tenant
**Purpose**: Copy a building structure from one tenant to another

```sql
SELECT clone_building_to_tenant(
    p_building_id := 'building-uuid',
    p_source_tenant_id := 'source-tenant-uuid',
    p_target_tenant_id := 'target-tenant-uuid',
    p_cloned_by := 'user-uuid'
);
```

**Returns**: UUID of newly created building in target tenant

**Operations performed**:
- Copies building with all floors and rooms
- Maintains structure but generates new IDs
- Creates audit log with clone details

**Use cases**:
- Template building deployment
- Multi-campus organizations
- Testing and demo environments

### 6. bulk_deactivate_users
**Purpose**: Deactivate multiple users across tenants

```sql
SELECT bulk_deactivate_users(
    p_user_ids := ARRAY['user1-uuid', 'user2-uuid'],
    p_reason := 'Account cleanup',
    p_deactivated_by := 'admin-uuid'
);
```

**Operations performed**:
- Validates all user IDs
- Sets is_active = false for each user
- Creates detailed audit log

**Use cases**:
- Security incidents
- Bulk account suspension
- End-of-term cleanup

## Integration with Application Code

### Using Helper Functions

The application provides helper functions to safely execute SECURITY DEFINER functions:

```python
from spacecargo.api.utils.db_helpers import execute_with_super_user

# Execute a SECURITY DEFINER function
result = await execute_with_super_user(
    session=db,
    operation="SELECT accept_tenant_invitation(:invitation_id, :user_id)",
    params={
        "invitation_id": invitation_id,
        "user_id": user_id
    },
    audit_context={
        "action": "accept_invitation",
        "ip_address": request.client.host
    }
)
```

### Synchronous Version

For synchronous code, use the sync helper:

```python
from spacecargo.api.utils.db_helpers import execute_cross_tenant_query_sync

# Query with elevated privileges
result = execute_cross_tenant_query_sync(
    session=db,
    query="SELECT * FROM get_tenant_analytics(:start_date, :end_date, :user_id)",
    params={
        "start_date": start_date,
        "end_date": end_date,
        "user_id": current_user.id
    },
    bypass_rls=True
)
```

## Security Considerations

### Input Validation
All SECURITY DEFINER functions MUST:
- Validate all input parameters
- Check for SQL injection attempts
- Verify caller authorization
- Validate business rules

### Audit Logging
Every function execution creates an audit log entry containing:
- Operation type and function name
- User ID of caller
- Affected tenant IDs
- Parameters (sanitized)
- Timestamp
- Success/failure status

### Access Control
Functions should verify:
- Caller has necessary permissions
- Target resources exist and are accessible
- Operation complies with business rules
- Rate limits are respected

### Error Handling
Functions use PostgreSQL error codes:
- `P0001` - Business rule violation
- `P0002` - Not found
- `P0003` - Unauthorized
- `P0004` - Conflict/duplicate

## Best Practices

### 1. Minimal Privilege Principle
Only grant SECURITY DEFINER to functions that absolutely need cross-tenant access.

### 2. Strict Input Validation
```sql
-- Always validate inputs
IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'User ID is required' USING ERRCODE = 'P0001';
END IF;

-- Check existence
IF NOT EXISTS (SELECT 1 FROM users WHERE id = p_user_id) THEN
    RAISE EXCEPTION 'User not found: %', p_user_id USING ERRCODE = 'P0002';
END IF;
```

### 3. Comprehensive Audit Logging
```sql
-- Always log the operation
INSERT INTO audit_logs (
    operation_type,
    function_name,
    user_id,
    parameters,
    timestamp
) VALUES (
    'CROSS_TENANT_OPERATION',
    'function_name',
    p_user_id,
    jsonb_build_object('param1', value1, 'param2', value2),
    CURRENT_TIMESTAMP
);
```

### 4. Transaction Management
```sql
-- Use explicit transaction blocks for complex operations
BEGIN;
    -- Perform operations
    -- Log audit
COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
```

### 5. Testing Requirements
Each SECURITY DEFINER function needs:
- Unit tests for happy path
- Tests for each validation rule
- Tests for authorization checks
- Tests for audit logging
- Performance benchmarks

## Migration Guide

### Creating New SECURITY DEFINER Functions

1. **Define the function**:
```sql
CREATE OR REPLACE FUNCTION your_function_name(
    p_param1 TYPE,
    p_param2 TYPE
) RETURNS return_type
LANGUAGE plpgsql
SECURITY DEFINER
STRICT  -- Automatically handle NULL inputs
SET search_path = public, pg_catalog  -- Prevent search path attacks
AS $$
DECLARE
    -- Variables
BEGIN
    -- Validation
    -- Business logic
    -- Audit logging
    RETURN result;
END;
$$;
```

2. **Grant execution rights**:
```sql
GRANT EXECUTE ON FUNCTION your_function_name TO application_role;
REVOKE EXECUTE ON FUNCTION your_function_name FROM PUBLIC;
```

3. **Add to migration**:
```python
# In Alembic migration
op.execute("""
    CREATE OR REPLACE FUNCTION ...
""")
```

4. **Document in this file**

5. **Add integration tests**

## Troubleshooting

### Common Issues

**Issue**: Function not found
**Solution**: Check schema search path and execution grants

**Issue**: Permission denied
**Solution**: Verify function owner has necessary privileges

**Issue**: Audit logs missing
**Solution**: Check audit_logs table permissions and triggers

**Issue**: Transaction rollback
**Solution**: Review function error handling and RAISE statements

### Performance Monitoring

Monitor function performance using:
```sql
SELECT 
    funcname,
    calls,
    total_time,
    mean_time,
    max_time
FROM pg_stat_user_functions
WHERE funcname LIKE '%tenant%'
ORDER BY total_time DESC;
```

## Related Documentation

- [Database Configuration](../database/configuration.md)
- [RLS-Only Tenant Isolation](../architecture/adr-006-rls-only-tenant-isolation.md)
- [Multi-Tenant Superuser Guide](../admin/multi-tenant-superuser.md)
- [Tenant Isolation Issues](../gotchas/tenant-isolation-issues.md)