# Dynamic Justfile Help System

## Purpose
Documentation for the dynamic help system that automatically generates up-to-date command documentation by parsing the justfile in real-time. This system ensures help text never goes out of sync with actual commands.

## When to Use This
- Understanding how the help system works
- Adding new commands with proper documentation
- Troubleshooting help system issues
- Maintaining or extending the help generator

**Keywords:** justfile, help, documentation, command discovery, dynamic generation

---

## System Overview

### The Problem It Solves
Previously, the justfile contained 270+ lines of static help text that frequently became outdated as commands were added, modified, or removed. Developers would see help text for commands that no longer existed or miss documentation for new commands.

### How It Works
The dynamic help system:
1. **Parses** the justfile in real-time when `just help` is called
2. **Extracts** command names, arguments, and descriptions from comment patterns
3. **Categorizes** commands automatically based on prefixes and special mappings
4. **Formats** the output with consistent alignment and organization
5. **Generates** fresh help text every time, ensuring accuracy

### Key Benefits
- ✅ **Always Current**: Help reflects actual commands in justfile
- ✅ **Automatic Categorization**: Commands grouped logically by function
- ✅ **Consistent Formatting**: Professional, aligned output
- ✅ **Extensible**: Easy to add new categories and patterns
- ✅ **Maintainable**: No manual help text synchronization required

---

## Architecture

### Core Components

```
scripts/helpers/
├── generate_help.py      # Main help generator script
└── test_generate_help.py # Comprehensive test suite
```

### Help Generation Flow

1. **Parse Justfile** (`parse_justfile()`)
   - Uses regex pattern to extract command info
   - Filters out internal commands (starting with `_`)
   - Captures description, name, and arguments

2. **Categorize Commands** (`group_commands_by_category()`)
   - Applies prefix-based categorization
   - Handles special case commands
   - Filters out aliases

3. **Format Output** (`generate_help_text()`)
   - Calculates optimal column widths
   - Preserves logical category ordering
   - Adds headers, workflows, and tips

### Command Pattern Recognition

The system recognizes this pattern in the justfile:
```makefile
# Description of what this command does
command_name arg1='default' arg2:
    @echo "Command implementation"
```

**Key Pattern Elements:**
- **Comment line**: Must start with `#` and contain description
- **Command line**: Must follow immediately with command definition
- **Arguments**: Preserved exactly as written in justfile

---

## Configuration

### Category System

Commands are automatically categorized based on prefixes:

```python
DEFAULT_PREFIX_MAP = {
    'env_': 'Environment & Setup',
    'docker_': 'Docker & Services',
    'db_': 'Database',
    'aws_': 'AWS & Deployment',
    'test_': 'Testing',
    'dev_': 'Development Utilities',
    'ci_': 'CI/CD',
    'mobile_': 'Mobile Development',
    'admin_': 'Admin Development',
    'backend_': 'Backend Development',
    'claude_': 'Documentation & Tools'
}
```

### Special Commands

Commands that don't follow prefix patterns:
```python
SPECIAL_COMMANDS = {
    'Docker & Services': ['up', 'down', 'build', 'logs', 'restart'],
    'Documentation & Tools': ['help', 'venv'],
    'Environment & Setup': ['install', 'fresh_start', 'setup']
}
```

### Configurable Constants

```python
MAX_COLUMN_WIDTH = 40  # Maximum width for command column
SEPARATOR_WIDTH = 78   # Width for category separator lines
```

---

## Adding New Commands

### Basic Command Documentation

```makefile
# Brief description of what this command does
new_command arg='default':
    @echo "Implementation"
```

### Best Practices for Descriptions

✅ **Good Examples:**
```makefile
# Deploy backend service to AWS
# Run comprehensive unit tests with coverage
# Create database backup with timestamp
```

❌ **Avoid:**
```makefile
# Backend deployment  (too brief)
# This command deploys the backend service to AWS environment specified (too verbose)
# Deploy  (unclear what's being deployed)
```

### Command Naming for Auto-Categorization

Choose prefixes that align with existing categories:
- `db_backup_restore` → Database category
- `test_integration_mobile` → Testing category
- `aws_logs_debug` → AWS & Deployment category

### Empty Descriptions

Commands with empty descriptions are supported:
```makefile
#
command_with_empty_desc:
    @echo "Still works"
```

---

## Testing

### Test Suite Coverage

The help system includes comprehensive tests:

```bash
# Run all tests (basic + integration + edge cases)
python3 scripts/helpers/test_generate_help.py
```

**Test Categories:**
- **Basic Tests** (8 tests): Core functionality with mock justfile
- **Integration Tests** (6 tests): Real justfile parsing and validation
- **Edge Case Tests** (3 tests): Error handling and unicode support

### Test Validation

✅ **Verified Functionality:**
- Header generation and formatting
- Internal command filtering (`_` prefixed commands)
- Command categorization and sorting
- Argument preservation
- Category ordering preservation
- Common workflows section
- Tips section
- Unicode character support
- Error handling for missing/malformed files

### Adding New Tests

When extending the system, add tests for:
- New category mappings
- Special command patterns
- Error conditions
- Output formatting changes

---

## Troubleshooting

### Common Issues

**Error: "Python 3 required for help generation"**
- Install Python 3: `brew install python3` (macOS) or system package manager
- Or run directly: `python scripts/helpers/generate_help.py`

**Help shows unexpected categorization**
- Check command prefix matches `DEFAULT_PREFIX_MAP`
- Add special case to `SPECIAL_COMMANDS` if needed
- Verify command follows documentation pattern

**Missing commands in help output**
- Ensure comment line directly precedes command definition
- Check command doesn't start with `_` (internal commands filtered)
- Verify command isn't in `SKIP_ALIASES` list

**Formatting issues**
- Commands longer than `MAX_COLUMN_WIDTH` may wrap
- Check for unusual characters in descriptions
- Verify UTF-8 encoding if using unicode

### Debug Mode

For detailed debugging, run the script directly:
```bash
python3 scripts/helpers/generate_help.py
```

This bypasses justfile error handling and shows full Python traceback.

---

## Maintenance

### Regular Maintenance Tasks

1. **Review Categories**: Periodically review if new command patterns need categories
2. **Update Tests**: Add tests for new command patterns or edge cases
3. **Validate Output**: Run `just help` after major justfile changes
4. **Check Performance**: Monitor parse time for very large justfiles

### Extending the System

**Adding New Categories:**
1. Add to `DEFAULT_CATEGORIES` list (preserves ordering)
2. Add prefix mappings to `DEFAULT_PREFIX_MAP`
3. Update tests to verify new categorization

**Custom Formatting:**
- Modify `format_command()` for command-specific formatting
- Adjust `MAX_COLUMN_WIDTH` and `SEPARATOR_WIDTH` constants
- Update header/footer in `generate_help_text()`

**Advanced Parsing:**
- Enhance regex pattern for complex command syntax
- Add support for multiline descriptions
- Implement command grouping beyond categories

---

## Technical Implementation

### Error Handling

The system includes robust error handling:
- **File Operations**: UTF-8 encoding with error replacement
- **Memory Management**: Protection against large file processing
- **Validation**: Basic justfile format validation
- **Graceful Degradation**: Fallback error messages for missing Python 3

### Performance Characteristics

- **Parse Time**: ~10-50ms for typical justfiles (100-500 commands)
- **Memory Usage**: Minimal - processes file in single read
- **Scalability**: Tested with 300+ command justfiles

### Unicode Support

Full unicode support for:
- Command descriptions with emoji and international characters
- UTF-8 file encoding with graceful error handling
- Proper text alignment with unicode characters

---

## Integration with Spacewalker Patterns

### CLAUDE.md Compliance
- Follows justfile-first philosophy
- Maintains verification standards with comprehensive tests
- Provides clear error messages with actionable solutions
- Integrates with existing development workflows

### Development Workflow Integration
- Works with existing `just help` command
- No changes to daily development commands required
- Maintains backward compatibility
- Supports all existing justfile patterns

---

## Related Documentation

### Development Tools
- **[Development README](./README.md)** - Overview of development tooling and workflows
- **[Justfile Workflow](../claude-components/justfile-workflow.md)** - Core justfile usage patterns

### Setup & Configuration
- **[Development Setup](../setup/development-setup.md)** - Environment configuration including Python setup

### Testing & Quality
- **[Testing Guide](../workflows/testing-guide.md)** - Testing strategies and quality assurance

---

**Last Updated:** 2025-07-18
**Status:** Current - Dynamic help system implementation complete with comprehensive testing
**Next Review:** Q4 2025 - Evaluate performance with larger justfiles
