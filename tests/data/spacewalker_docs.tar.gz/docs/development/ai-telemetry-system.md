# AI Telemetry System

## Purpose
Comprehensive guide for the unified AI telemetry system that provides standardized monitoring, session correlation, and cost tracking across all AI tools in the Spacewalker platform. Essential reference for developers integrating AI tools and monitoring teams implementing telemetry collection.

## When to Use This
- Integrating new AI tools with telemetry tracking
- Understanding AI usage patterns and costs
- Setting up monitoring for AI operations
- Troubleshooting AI tool integration issues
- Implementing session correlation for AI activities

**Keywords:** AI telemetry, monitoring, session tracking, cost analysis, Pushgateway, Prometheus

**Version:** 1.0 (Initial Implementation)
**Date:** 2025-09-07
**Status:** Current - Production Ready

---

## System Overview

### Architecture Benefits
The unified AI telemetry system provides:
- **75% Code Reduction** - From 836 duplicate lines to 210 unified lines
- **Session Correlation** - All AI calls include session and user identification
- **Standardized Integration** - 3-line pattern for any AI tool
- **Monitoring Ready** - Prometheus metrics sent to Pushgateway with full context
- **Cost Tracking** - Token usage tracking across different AI providers
- **Error Monitoring** - Automatic failure detection and reporting

### Eliminated Duplication
The telemetry refactor removed these duplicate session detectors:
- `mimir-docsearch` (shared package) 
- `scripts/helpers/actions/claude_session_detector.py`
- `scripts/helpers/claude_session_detector.py`

**Result**: Single source of truth for AI telemetry across the entire platform.

---

## Core Components

### 1. Unified Telemetry Library (`ai_telemetry.py`)

**Purpose**: Central telemetry tracking with context manager pattern for clean integration.

#### Key Features
- Automatic session detection and user identification
- Token usage tracking for multiple AI providers (OpenRouter, Anthropic, OpenAI)
- Prometheus metrics generation with proper labeling
- Error handling and success/failure tracking
- Configurable Pushgateway integration

#### Core Classes

**`AITelemetryTracker`** - Main telemetry tracking class
```python
class AITelemetryTracker:
    def __init__(self, agent_name: str, operation: str)
    def start(self) -> None
    def send_metrics(self) -> None
    # Properties: success, tokens_used, error_message
```

**`SessionDetector`** - Session and user identification
```python
class SessionDetector:
    @staticmethod
    def get_session_info() -> Tuple[str, str]  # Returns (session_id, user)
```

**Token Data Classes** - Provider-specific token extraction
- `TokenData` - Base token structure
- `OpenRouterTokens` - OpenRouter API token format
- `AnthropicTokens` - Anthropic API token format

### 2. Integration Examples (`ai_telemetry_integration_example.py`)

**Purpose**: Copy-paste examples for monitoring teams to integrate AI telemetry into any tool.

#### Available Examples
- **OpenRouter Integration** - Complete example with token extraction
- **Anthropic Integration** - Claude API with proper token handling
- **OpenAI Integration** - GPT models with usage tracking
- **Generic Integration** - Template for any AI provider
- **Error Handling Patterns** - Robust error handling examples

### 3. Active Integrations

#### Git-Info Tool (`ai_client.py`)
**AI Operations Tracked:**
- Commit message generation
- PR title creation
- PR description generation
- PR review analysis

**Integration Pattern:**
```python
with track_ai_call("git-info", "commit-generation") as tracker:
    response = client.messages.create(...)
    tracker.tokens_used = extract_anthropic_tokens(response)
    tracker.success = True
```

#### Mímir Tool (`mimir.ai.llm_integration`)
**AI Operations Tracked:**
- Document search and analysis
- AI question answering
- Documentation indexing

#### GitHub Actions Analyzer (`scripts/helpers/actions/ai_analyzer.py`)
**AI Operations Tracked:**
- CI/CD failure analysis
- Build error categorization
- Performance optimization suggestions

---

## Integration Guide

### Quick Integration (3 Lines)

For any AI tool, use this standardized pattern:

```python
from scripts.helpers.ai_telemetry import track_ai_call

# Your existing AI code
def your_ai_function():
    with track_ai_call("your-tool", "operation-name") as tracker:
        result = your_ai_api_call()  # Your existing API call
        tracker.tokens_used = extract_tokens(result)  # Add token extraction
        return result  # Your existing return
```

### Complete Integration Example

```python
#!/usr/bin/env python3
"""
Example AI tool with full telemetry integration
"""
import sys
import os
import anthropic
from typing import Dict, Any

# Add helpers to path for telemetry
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))
from scripts.helpers.ai_telemetry import track_ai_call, extract_anthropic_tokens

def analyze_code(code: str) -> Dict[str, Any]:
    """Analyze code with AI and full telemetry tracking"""

    client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    with track_ai_call("code-analyzer", "code-analysis") as tracker:
        try:
            response = client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1000,
                messages=[{
                    "role": "user",
                    "content": f"Analyze this code:\n\n{code}"
                }]
            )

            # Extract tokens and mark success
            tracker.tokens_used = extract_anthropic_tokens(response)
            tracker.success = True

            return {
                "analysis": response.content[0].text,
                "tokens_used": tracker.tokens_used
            }

        except Exception as e:
            tracker.success = False
            tracker.error_message = str(e)
            raise

if __name__ == "__main__":
    result = analyze_code(sys.argv[1])
    print(result["analysis"])
```

### Token Extraction Helpers

The library provides token extractors for different AI providers:

```python
from scripts.helpers.ai_telemetry import (
    extract_openrouter_tokens,
    extract_anthropic_tokens,
    extract_openai_tokens
)

# OpenRouter
tracker.tokens_used = extract_openrouter_tokens(response)

# Anthropic Claude
tracker.tokens_used = extract_anthropic_tokens(response)

# OpenAI GPT
tracker.tokens_used = extract_openai_tokens(response)
```

---

## Monitoring Integration

### Session Correlation
Every AI call includes:
- **Session ID** - Unique identifier for the development session
- **User ID** - Developer's username for activity correlation
- **Agent Name** - Which AI tool made the call
- **Operation** - Specific operation within the tool

### Prometheus Metrics Format

```
# HELP ai_agent_calls_total Total number of AI agent calls
# TYPE ai_agent_calls_total counter
ai_agent_calls_total{agent="git-info",operation="commit-generation",user="chadwalters",session_id="env-c14d6f78"} 1

# HELP ai_agent_tokens_total Total tokens used by AI agents
# TYPE ai_agent_tokens_total counter
ai_agent_tokens_total{agent="git-info",operation="commit-generation",user="chadwalters",session_id="env-c14d6f78",type="input"} 150
ai_agent_tokens_total{agent="git-info",operation="commit-generation",user="chadwalters",session_id="env-c14d6f78",type="output"} 75

# HELP ai_agent_duration_seconds Duration of AI agent calls
# TYPE ai_agent_duration_seconds histogram
ai_agent_duration_seconds{agent="git-info",operation="commit-generation",user="chadwalters",session_id="env-c14d6f78"} 2.34

# HELP ai_agent_success_total Successful AI agent calls
# TYPE ai_agent_success_total counter
ai_agent_success_total{agent="git-info",operation="commit-generation",user="chadwalters",session_id="env-c14d6f78"} 1
```

### Pushgateway Integration

Metrics are automatically sent to the monitoring Pushgateway with enhanced URL structure:

```
POST http://monitoring.spacewalker.littleponies.com:9091/metrics/job/ai_agents/session_id/env-c14d6f78/user_id/chadwalters
```

### Configuration

Set these environment variables for telemetry:

```bash
# Pushgateway endpoint
PUSHGATEWAY_URL="http://monitoring.spacewalker.littleponies.com:9091"

# Disable telemetry (optional, for development)
DISABLE_AI_TELEMETRY="false"

# Session override (optional, normally auto-detected)
CLAUDE_SESSION_ID="custom-session-id"
```

---

## Available AI Tools

### Production Tools with Telemetry

1. **Git-Info Tool** - `just git-info <command>`
   - **Operations**: commit, pr-title, pr-desc, pr-review-issues
   - **Telemetry**: Full session correlation and token tracking
   - **Usage**: Integrated into daily development workflow

2. **Doc-Finder Tool** - `just docs <command>`
   - **Operations**: search, ask, index
   - **Telemetry**: Document analysis cost tracking
   - **Usage**: Documentation search and AI question answering

3. **GitHub Actions Analyzer** - Used in CI/CD pipeline
   - **Operations**: failure-analysis, error-categorization
   - **Telemetry**: Automated CI/CD cost tracking
   - **Usage**: Automatic build failure analysis

### Integration Commands

```bash
# Git operations with telemetry
just git-info commit              # Generate commit message with tracking
just git-info pr-desc 290         # Generate PR description with monitoring

# Documentation with telemetry
just docs ask "How do I deploy?"  # AI question with cost tracking
just docs search "authentication" # Smart search with usage monitoring

# All operations automatically include:
# - Session correlation
# - User identification
# - Token usage tracking
# - Success/failure monitoring
```

---

## Development Guidelines

### Adding New AI Tools

When creating new AI tools, follow the standardized telemetry pattern:

1. **Import telemetry library**
   ```python
   from scripts.helpers.ai_telemetry import track_ai_call
   ```

2. **Use context manager pattern**
   ```python
   with track_ai_call("tool-name", "operation") as tracker:
   ```

3. **Extract and assign token usage**
   ```python
   tracker.tokens_used = extract_tokens(response)
   ```

4. **Handle errors properly**
   ```python
   try:
       # AI operation
   except Exception as e:
       tracker.success = False
       tracker.error_message = str(e)
       raise
   ```

### Telemetry Best Practices

#### Agent Naming Convention
- Use kebab-case for agent names: `"git-info"`, `"mimir"`, `"code-analyzer"`
- Be descriptive but concise
- Match tool directory or script name when possible

#### Operation Naming Convention
- Use descriptive operation names: `"commit-generation"`, `"document-search"`, `"error-analysis"`
- Use kebab-case consistently
- Include enough detail for monitoring granularity

#### Error Handling
```python
with track_ai_call("tool", "operation") as tracker:
    try:
        result = ai_operation()
        tracker.success = True  # Explicit success marking
        return result
    except SpecificAIError as e:
        tracker.error_message = f"AI API Error: {e}"
        tracker.success = False
        raise
    except Exception as e:
        tracker.error_message = f"Unexpected error: {e}"
        tracker.success = False
        raise
```

---

## Monitoring Team Integration

### Quick Setup for New Monitoring Systems

Copy the integration example and customize for your monitoring setup:

```python
# Copy from ai_telemetry_integration_example.py
from ai_telemetry import track_ai_call

def monitor_ai_operations():
    with track_ai_call("my-tool", "my-operation") as tracker:
        # Your AI operation here
        response = call_your_ai_api()

        # Extract tokens (customize for your API)
        tracker.tokens_used = extract_tokens(response)

        # Operation completed successfully
        tracker.success = True

        return response
```

### Customization Points

1. **Pushgateway URL** - Set `PUSHGATEWAY_URL` environment variable
2. **Session Detection** - Override `CLAUDE_SESSION_ID` if needed
3. **User Detection** - Automatic from environment, customizable in code
4. **Token Extraction** - Add custom extractors for new AI providers

### Metrics Collection

Monitor these key metrics:
- **ai_agent_calls_total** - Call volume per tool/operation
- **ai_agent_tokens_total** - Token usage and costs
- **ai_agent_duration_seconds** - Performance monitoring
- **ai_agent_success_total** - Success rate tracking

All metrics include labels for:
- `agent` - Which AI tool
- `operation` - Specific operation
- `user` - Developer username
- `session_id` - Session correlation

---

## Troubleshooting

### Common Integration Issues

#### Import Path Problems
```python
# Add this at the top of your script
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))
```

#### Session Detection Failures
- Check that `CLAUDE_SESSION_ID` is set in environment
- Verify user detection is working with `whoami`
- Test session detection manually:
  ```python
  from scripts.helpers.ai_telemetry import SessionDetector
  session_id, user = SessionDetector.get_session_info()
  print(f"Session: {session_id}, User: {user}")
  ```

#### Token Extraction Issues
- Verify you're using the correct extractor for your AI provider
- Check response format matches expected structure
- Add debug logging:
  ```python
  print(f"Response structure: {type(response)}")
  print(f"Available attributes: {dir(response)}")
  ```

#### Pushgateway Connection Problems
- Verify `PUSHGATEWAY_URL` is set correctly
- Test network connectivity to monitoring endpoint
- Check for HTTP 400 errors in logs (usually URL format issues)

### Debugging Telemetry

Enable debug logging:
```python
import logging
logging.basicConfig(level=logging.DEBUG)

with track_ai_call("debug-tool", "debug-operation") as tracker:
    # Your AI operation with debug logging
    pass
```

### Manual Testing

Test telemetry integration without AI calls:
```python
from scripts.helpers.ai_telemetry import track_ai_call, TokenData

with track_ai_call("test-tool", "test-operation") as tracker:
    # Simulate AI operation
    import time
    time.sleep(1)

    # Set test token data
    tracker.tokens_used = TokenData(input_tokens=100, output_tokens=50)
    tracker.success = True

print("Test telemetry sent successfully!")
```

---

## Cost Analysis and Optimization

### Token Usage Patterns

The telemetry system tracks token usage across all AI operations, enabling cost analysis:

#### By Tool
- **git-info**: Typically 100-300 tokens per operation
- **mimir**: 200-1000 tokens depending on query complexity
- **actions-analyzer**: 500-2000 tokens for CI/CD failure analysis

#### By Operation Type
- **Simple generation**: 50-200 tokens (commit messages, titles)
- **Content analysis**: 200-800 tokens (PR reviews, document analysis)
- **Complex analysis**: 500-2000+ tokens (code review, failure analysis)

### Optimization Strategies

Based on telemetry data, optimize AI usage:

1. **Prompt Optimization** - Track token usage to identify inefficient prompts
2. **Model Selection** - Use telemetry to choose optimal models for each operation
3. **Caching** - Identify repeated operations that could benefit from caching
4. **User Patterns** - Understand which tools and operations are most cost-effective

---

## Related Documentation

### Implementation Details
- **[Helpers Directory Structure](./helpers-directory-structure.md)** - Overall helpers organization
- **[AI Development Setup](../setup/ai-development-setup.md)** - AI development environment
- **[Git-Info System](./git-info-system.md)** - Git-info tool documentation

### Monitoring and Operations
- **[Monitoring Runbook](../monitoring/monitoring-runbook.md)** - Monitoring system management
- **[Production Monitoring Deployment](../workflows/production-monitoring-deployment.md)** - Monitoring setup

### Development Workflows
- **[Development Tools](./development-tools.md)** - Overall development tooling
- **[Project Structure](./project-structure.md)** - Codebase organization

---

**Status**: ✅ **PRODUCTION READY**
**Last Updated**: 2025-09-07
**Integration**: All active AI tools include telemetry
**Monitoring**: Full Pushgateway integration with session correlation

---

*This telemetry system provides comprehensive monitoring and cost tracking for all AI operations in Spacewalker. The unified architecture eliminates code duplication while providing rich telemetry data for monitoring teams and cost optimization.*
