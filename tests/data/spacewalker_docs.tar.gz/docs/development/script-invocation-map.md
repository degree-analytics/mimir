# Script Invocation Map for Justfile

This document provides a comprehensive map of how scripts are invoked throughout the justfile, including direct paths, helper functions, and dynamic execution patterns.

## Table of Contents
1. [Helper Functions](#helper-functions)
2. [Script Categories](#script-categories)
3. [Invocation Methods](#invocation-methods)
4. [Command → Helper → Script Relationships](#command--helper--script-relationships)

## Helper Functions

### `_aws_run` - AWS Deployment Script Runner
**Location**: Line 942
**Purpose**: Executes AWS deployment scripts with proper profile/region configuration
**Pattern**: `just _aws_run <script_name> <env> <region> <args>`

```bash
_aws_run script env region='' *args='':
    # Auto-configures AWS profile based on environment
    # Validates AWS access before execution
    # Executes: ./scripts/deployment/{{script}} {{env}} {{args}} $FINAL_REGION
```

**Scripts executed via _aws_run**:
- `debug-stuck-deployment.sh` (line 1934)

## Script Categories

### 1. Helper Scripts (`scripts/helpers/`)
Python-based utility scripts for various operations:

| Script | Direct Invocation | Purpose |
|--------|------------------|----------|
| `generate_help.py` | `@python scripts/helpers/generate_help.py` | Generate help documentation |
| `db_operations_wrapper.py` | `python scripts/helpers/db_operations_wrapper.py --env {{env}} {{action}} {{args}}` | Database operations wrapper |
| `db_sql_wrapper.py` | `python scripts/helpers/db_sql_wrapper.py "{{query}}" {{env}} {{flags}}` | SQL query wrapper |
| `health_checker.py` | Multiple invocations | Health checks and wait operations |
| `url_manager.py` | `python scripts/helpers/url_manager.py --env {{env}} --format {{format}} urls` | URL management |
| `env_validator.py` | `python scripts/helpers/env_validator.py {{env}}` | Environment validation |
| `service_manager.py` | `python scripts/helpers/service_manager.py --action {{action}} --service {{name}} --env {{env}}` | Service management |
| `test_manager.py` | `python scripts/helpers/test_manager.py {{test_type}} {{repo}} {{args}}` | Test execution management |
| `lint_manager.py` | `@python3 scripts/helpers/lint_manager.py {{ACTION}} {{TARGET}} {{OPTIONS}}` | Linting management |
| `docs_manager.py` | `@python3 scripts/helpers/docs_manager.py {{ACTION}} {{TARGET}} {{OPTIONS}}` | Documentation management |
| `logs_manager.py` | `@python3 scripts/helpers/logs_manager.py {{service}} {{env}} {{args}}` | Log management |
| `bastion_manager.py` | `@python3 scripts/helpers/bastion_manager.py {{action}} {{env}} {{args}}` | Bastion host management |
| `deployment_manager.py` | `@PYTHONPATH={{justfile_directory()}} python scripts/helpers/deployment_manager.py --action {{action}} --service {{service}} --env {{env}} {{args}}` | Deployment management |
| `sm_manager.py` | `@python scripts/helpers/sm_manager.py {{action}} {{env}} {{args}}` | Secrets Manager operations |
| `ecs_manager.py` | `@python scripts/helpers/ecs_manager.py --action {{action}} --service {{service}} --env {{env}}` | ECS management |
| `monitor_manager.py` | Multiple invocations | Monitoring management |
| `stack_manager.py` | `@python scripts/helpers/stack_manager.py {{action}} {{env}} {{stack_name}} {{args}}` | CloudFormation stack management |
| `ecr_manager.py` | `@python scripts/helpers/ecr_manager.py {{action}} {{env}} {{args}}` | ECR repository management |
| `s3_manager.py` | `@python scripts/helpers/s3_manager.py {{action}} {{env}} {{args}}` | S3 bucket operations |
| `version_manager.py` | `@python scripts/helpers/version_manager.py {{action}} {{target}} {{args}}` | Version management |

### 2. Deployment Scripts (`scripts/deployment/`)
Bash scripts for deployment operations:

| Script | Invocation Method | Purpose |
|--------|------------------|----------|
| `debug-stuck-deployment.sh` | Via `_aws_run` helper | Debug stuck deployments |
| `force-ecs-deployment.sh` | Direct with AWS_PROFILE | Force ECS deployments |
| `fix-deployment.sh` | Direct invocation | Fix deployment issues |
| `fix-frozen-state.sh` | Direct invocation | Fix frozen deployment states |
| `init-demo-database.sh` | Direct invocation | Initialize demo database |
| `debug-ecs-deployment.sh` | Direct invocation | Debug ECS deployments |
| `debug-health-checks.sh` | Direct invocation | Debug health check issues |

### 3. Database Scripts (`scripts/database/`)
Python scripts for database operations:

| Script | Invocation Pattern | Purpose |
|--------|-------------------|----------|
| `aws_db_wrapper.py` | Wraps other DB scripts | Database connection wrapper |
| `aws_db_demo_comprehensive.py` | Via `aws_db_wrapper.py` | Comprehensive demo data |
| `aws_init_complete.py` | Via `aws_db_wrapper.py` | Complete DB initialization |
| `aws_db_demo_full.py` | Via `aws_db_wrapper.py` | Full demo data setup |
| `aws_db_demo_clean.py` | Via `aws_db_wrapper.py` | Clean demo data |
| `aws_db_demo_status.py` | Via `aws_db_wrapper.py` | Demo data status |
| `aws_db_check_coverage.py` | Via `aws_db_wrapper.py` | Check data coverage |
| `db_helper.py` | Direct invocation | Database tunneling |

### 4. Version Scripts (`scripts/version/`)
Version management scripts:

| Script | Direct Invocation | Purpose |
|--------|------------------|----------|
| `generate-backend-version.sh` | `./scripts/version/generate-backend-version.sh` | Generate backend version |
| `generate-version.sh` | Multiple with different outputs | Generate version files |
| `sync-package-versions.sh` | `./scripts/version/sync-package-versions.sh --force {{VERSION}}` | Sync package versions |

### 5. Other Scripts

| Script | Location | Invocation | Purpose |
|--------|----------|------------|----------|
| `restart_service.sh` | `scripts/` | Direct | Restart ECS services |

| `eas_version_sync.sh` | `scripts/` | Direct with VERSION | EAS version sync |
| `claude_validate_commands.sh` | `scripts/` | Direct | Validate Claude commands |
| `claude_memory.sh` | `scripts/` | Direct with pwd | Claude memory operations |
| `expo_manager.py` | `scripts/helpers/` | Via `just expo ip` | Configure mobile development IP |
| `mimir` CLI | External package (`mimir-docsearch`) | `mimir index/search/ask` | Document search |

## Invocation Methods

### 1. Direct Path Invocation
```bash
# Python scripts
python scripts/helpers/script_name.py [args]
python3 scripts/helpers/script_name.py [args]

# Shell scripts
./scripts/deployment/script_name.sh [args]
./scripts/version/script_name.sh [args]
```

### 2. Via Helper Functions
```bash
# _aws_run helper
just _aws_run script_name.sh {{env}} {{region}} {{args}}
```

### 3. With Environment Setup
```bash
# AWS Profile setup
AWS_PROFILE=$(just _set_aws_profile {{env}}) ./scripts/deployment/script.sh

# PYTHONPATH setup
PYTHONPATH={{justfile_directory()}} python scripts/helpers/script.py
```

### 4. Via Wrapper Scripts
```bash
# Database operations via wrapper
python3 scripts/database/aws_db_wrapper.py --env {{env}} "python3 scripts/database/target_script.py"
```

## Command → Helper → Script Relationships

### AWS Commands
```
just aws_debug_stuck dev
  └─> _aws_run debug-stuck-deployment.sh dev
      └─> ./scripts/deployment/debug-stuck-deployment.sh dev $FINAL_REGION
```

### Database Commands
```
just db_demo_comprehensive dev
  └─> python3 scripts/database/aws_db_wrapper.py --env dev
      └─> python3 scripts/database/aws_db_demo_comprehensive.py
```

### Stack Management Commands
```
just stack status dev backend
  └─> python scripts/helpers/stack_manager.py status dev backend

just stack events dev backend
  └─> python scripts/helpers/stack_manager.py events dev backend --count 20

just stack inspect dev backend
  └─> python scripts/helpers/stack_manager.py inspect dev backend
```

### ECR Management Commands
```
just ecr list dev
  └─> python scripts/helpers/ecr_manager.py list dev

just ecr clean dev --force
  └─> python scripts/helpers/ecr_manager.py clean dev --force

just ecr latest dev
  └─> python scripts/helpers/ecr_manager.py latest dev
```

### S3 Management Commands
```
just s3 list dev
  └─> python scripts/helpers/s3_manager.py list dev

just s3 list dev --tenant-id 123
  └─> python scripts/helpers/s3_manager.py list dev --tenant-id 123

just s3 recent dev --minutes 60
  └─> python scripts/helpers/s3_manager.py recent dev --minutes 60

just s3 stats dev
  └─> python scripts/helpers/s3_manager.py stats dev
```

### Version Management Commands
```
just version generate
  └─> python scripts/helpers/version_manager.py generate all

just version generate backend
  └─> python scripts/helpers/version_manager.py generate backend

just version generate all --prod
  └─> python scripts/helpers/version_manager.py generate all --prod

just version validate
  └─> python scripts/helpers/version_manager.py validate

just version sync 1.2.3
  └─> python scripts/helpers/version_manager.py sync 1.2.3
```

### Service Management Commands
```
just service install all
  └─> python scripts/helpers/service_manager.py --action install --service all --env local

just service install mobile
  └─> python scripts/helpers/service_manager.py --action install --service mobile --env local

just service clean mobile
  └─> python scripts/helpers/service_manager.py --action clean --service mobile --env local

just aws restart backend dev
  └─> python scripts/helpers/deployment_manager.py --action restart --service backend --env dev

just aws images backend dev
  └─> python scripts/helpers/deployment_manager.py --action images --service backend --env dev
```

### Health Check Commands
```
just health dev
  └─> python scripts/helpers/health_checker.py --env dev --service all check

just wait dev timeout=300
  └─> python scripts/helpers/health_checker.py --env dev --timeout 300 wait
```

## Key Patterns

1. **Helper Scripts** (`scripts/helpers/*.py`) are typically invoked directly with command-line arguments
2. **Deployment Scripts** (`scripts/deployment/*.sh`) may be invoked:
   - Directly with AWS_PROFILE setup
   - Via `_aws_run` helper function
3. **Database Scripts** (`scripts/database/*.py`) are often wrapped by `aws_db_wrapper.py`
4. **Version Scripts** (`scripts/version/*.sh`) are invoked directly
5. **Environment-specific scripts** always receive `{{env}}` as a parameter
6. **AWS scripts** often require profile/region configuration
