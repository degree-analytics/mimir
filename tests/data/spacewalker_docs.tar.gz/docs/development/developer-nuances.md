# Developer Onboarding: Repo Nuances & Conventions

This guide highlights key repo-specific practices so new contributors can get productive fast and avoid common pitfalls.

---

## Justfile-first philosophy

Our automation and workflows are centralized in the `justfile`.

- **Why**: Single source of truth, reproducible workflows, less drift between local and CI.
- **Discoverability**: Run `just help` for a live, auto-generated catalog. See [Dynamic Justfile Help System](./justfile-help-system.md).
- **Where to add commands**:
  - Use clear prefixes that auto-categorize (e.g., `db_`, `aws_`, `mobile_`, `admin_`, `backend_`, `test_`).
  - Use underscores, not hyphens, for naming consistency.
  - Prefer small, composable commands that call other `just` recipes rather than inlining long scripts.
- **Style and constraints**:
  - Keep commands minimal and focused; avoid bloat or overlapping aliases.
  - Avoid environment activation within each command; provide a phase-0 setup like `just install` and assume an activated environment for day-to-day commands.
  - Ensure commands are idempotent where possible and safe to re-run.
  - If a new pattern emerges in 3+ places, consider promoting it into a first-class `just` command.
- **Validation**:
  - After adding/modifying commands, verify `just help` output and ensure descriptions are present and accurate.
  - Favor consistent versions for runtimes and tooling; keep commands aligned with declared engine versions.

Related docs:
- [Dynamic Justfile Help System](./justfile-help-system.md)
- [Development Tools](./development-tools.md)

---

## Current test hygiene (temporary workaround)

Backend integration tests can be sensitive to database state and may fail if prior runs leave residual data. Until test isolation is fully addressed, use a clean DB between runs:

- **Recommended reset sequence between runs** (fast, ~5 seconds seed):
  - `just db reset local`
  - `just db init local`
  - `just db seed local`

Then run the relevant test target, e.g.: `just test integration all_backend`.

Notes:
- This is a known limitation while finishing recent RLS changes and migration fixes.
- The long-term direction is to improve test hygiene using Postgres Testcontainers, a complete FICM seed, a default system tenant, and wiring seeding into the dev container and `justfile`.
- Track and update tests to reduce cross-test coupling; prefer explicit setup/teardown for integration suites.

Related docs:
- [Testing Guide](../workflows/testing-guide.md)
- [Database Access](../workflows/database-access.md)

---

## .claude commands and agent governance

We maintain shared, reusable commands under `.claude/commands/`.

- **Treat as shared assets**: Changes affect everyone; prefer evolution over duplication.
- **Avoid bloat and duplication**: Before adding a new command, check if an existing one can be extended.
- **Quality bar**:
  - Clear purpose, usage, and verification steps.
  - Safety checks for destructive operations; support dry-run where feasible.
  - Keep commands small and composable; orchestrate via higher-level workflows when necessary.
- **Reviews**: Propose changes via PRs; include updates to related docs and examples.
- **Naming and structure**: Follow the documented command structure and conventions.

Related docs:
- [Claude Commands Guide](./claude-commands.md)
- [CLAUDE.md Context Management](./claude-context-management.md)

---

## Quick references

- **Help and discovery**: `just help`
- **Local spin-up**: `just env_setup && just up`, then `just health`
- **Common dev loop**: `just dev_cycle`
- **Backend tests**: `just test unit all_backend`, `just test integration all_backend`
- **DB hygiene (temporary)**: `just db reset local`, `just db init local`, `just db seed local`

If something feels repetitive or unclear, prefer adding or refining a `just` command and updating this doc rather than scattering bespoke scripts.

---

Status: Current
