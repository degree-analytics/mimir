# ast-grep Integration Developer Guide

## Purpose
Comprehensive guide for SpaceWalker developers to understand, use, and maintain ast-grep integration for automated security pattern detection, providing hands-on workflows, rule development, and performance optimization strategies.

## When to Use This
- Resolving ast-grep security violations in code
- Creating new security rules for SpaceWalker patterns
- Integrating ast-grep into development workflows
- Optimizing ast-grep performance for large codebases
- Understanding security patterns and compliance requirements

**Keywords:** ast-grep, security patterns, static analysis, code quality, lint integration, rule development

**Version:** 1.0
**Date:** 2025-09-09
**Status:** Active - Production Ready

---

## Quick Navigation

### For New Developers
- [Getting Started](#getting-started) - 5-minute setup
- [Common Violations](#common-security-violations) - Fix patterns
- [Development Workflow](#development-workflow) - Daily usage

### For Advanced Users
- [Rule Development](#rule-development) - Creating new rules
- [Performance Optimization](#performance-optimization) - Speed improvements
- [Testing Strategy](#testing-and-validation) - Quality assurance

### For Troubleshooting
- [Common Issues](#common-issues-and-solutions) - Quick fixes
- [Performance Problems](#performance-debugging) - Diagnosis
- [Full Troubleshooting Guide](../workflows/ast-grep-troubleshooting.md) - Complete reference

---

## Getting Started

### Prerequisites
- ast-grep binary installed (`cargo install ast-grep` or `brew install ast-grep`)
- SpaceWalker development environment set up
- Basic familiarity with justfile commands

### Quick Setup Verification
```bash
# Verify ast-grep is available
ast-grep --version

# Test SpaceWalker integration
just lint check astgrep

# Expected output (clean codebase):
# Performance Summary:
#   • Total execution time: 1.700s (target: <30s) ✓
#   • Files scanned: 969 (574.7 files/s)
#   • Rules executed: 7 (4.1 rules/s)
#   • Security issues found: 0
```

### Core Commands
```bash
# Primary development commands
just lint check astgrep          # Check for violations (1.7s avg)
just lint fix astgrep            # Apply automatic fixes where possible

# Advanced usage
python3 scripts/helpers/lint_manager.py check astgrep --files src/api/
python3 scripts/helpers/benchmark_astgrep.py --report
```

---

## Security Rules Overview

SpaceWalker implements **7 critical security rules** targeting the most common vulnerability patterns:

### Rule Summary

| Rule | Purpose | Language | Typical Fix Time |
|------|---------|----------|------------------|
| **API Trailing Slash Prevention** | Prevent FastAPI 403 auth failures | Python | 30 seconds |
| **Cross-Tenant Leakage Detection** | Detect tenant boundary violations | Python | 2-5 minutes |
| **Database Query Safety** | Prevent SQL injection | Python | 1-3 minutes |
| **Environment Variable Security** | Detect hardcoded secrets | Python | 1 minute |
| **Frontend API Consistency** | Ensure proper error handling | TypeScript | 2-4 minutes |
| **JWT Security Patterns** | Validate JWT practices | Python | 1-2 minutes |
| **RLS Violation Detection** | Prevent RLS bypass | Python | 2-3 minutes |

### Performance Characteristics
- **Execution Time**: ~1.7 seconds for full codebase scan
- **Files Processed**: 969 files (99.2% filtered out for efficiency)
- **Memory Usage**: 0.7MB peak (99.9% under 500MB target)
- **Parallel Workers**: 8 optimal workers for maximum throughput

---

## Common Security Violations

### 1. API Trailing Slash Prevention

**Problem**: FastAPI routes with trailing slashes cause 403 authentication failures

**Example Violation**:
```python
# ❌ Bad - causes authentication failures
@app.get("/api/buildings/")
@app.get("/api/users/")
```

**Fix**:
```python
# ✅ Good - proper FastAPI route pattern
@app.get("/api/buildings")
@app.get("/api/users")
```

**Resolution Time**: 30 seconds (simple find-replace)

### 2. Cross-Tenant Leakage Detection

**Problem**: Potential access to data across tenant boundaries

**Example Violation**:
```python
# ❌ Bad - queries all users across tenants
def get_all_users():
    return User.query.all()
```

**Fix**:
```python
# ✅ Good - tenant-scoped access
def get_all_users(current_tenant_id: int = Depends(get_current_tenant_id)):
    return User.query.filter(User.tenant_id == current_tenant_id).all()
```

**Resolution Time**: 2-5 minutes (requires tenant context understanding)

### 3. Database Query Safety

**Problem**: SQL injection vulnerabilities from unsafe query construction

**Example Violation**:
```python
# ❌ Bad - vulnerable to SQL injection
query = f"SELECT * FROM users WHERE id = {user_id}"
cursor.execute(query)
```

**Fix**:
```python
# ✅ Good - parameterized query
cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
```

**Resolution Time**: 1-3 minutes (parameterization required)

### 4. Environment Variable Security

**Problem**: Hardcoded secrets in source code

**Example Violation**:
```python
# ❌ Bad - secret exposed in code
SECRET_KEY = "sk-1234567890abcdef"
JWT_SECRET = "my-secret-key"
```

**Fix**:
```python
# ✅ Good - environment variable usage
SECRET_KEY = os.getenv("SECRET_KEY")
JWT_SECRET = os.getenv("JWT_SECRET")
```

**Resolution Time**: 1 minute (environment variable setup)

### 5. Frontend API Consistency

**Problem**: Missing error handling in API calls

**Example Violation**:
```typescript
// ❌ Bad - no error handling
const response = await fetch(url);
const data = await response.json();
```

**Fix**:
```typescript
// ✅ Good - proper error handling
try {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
} catch (error) {
    console.error('API call failed:', error);
    throw error;
}
```

**Resolution Time**: 2-4 minutes (error handling implementation)

### 6. JWT Security Patterns

**Problem**: Insecure JWT practices

**Example Violation**:
```python
# ❌ Bad - hardcoded secret and weak algorithm
token = jwt.encode(payload, "secret123", algorithm="none")
```

**Fix**:
```python
# ✅ Good - environment variable and strong algorithm
token = jwt.encode(payload, os.getenv("JWT_SECRET"), algorithm="HS256")
```

**Resolution Time**: 1-2 minutes (configuration update)

### 7. RLS Violation Detection

**Problem**: Bypassing Row Level Security by direct tenant_id access

**Example Violation**:
```python
# ❌ Bad - directly accessing tenant_id
def get_user_tenant(current_user):
    user_tenant = current_user.tenant_id
    return user_tenant
```

**Fix**:
```python
# ✅ Good - using dependency injection for tenant context
def get_user_tenant(current_tenant_id: int = Depends(get_current_tenant_id)):
    return current_tenant_id
```

**Resolution Time**: 2-3 minutes (dependency injection pattern)

---

## Development Workflow

### Daily Development Integration

#### Pre-commit Validation (Fast - 1.7s)
```bash
# Part of daily development cycle
just lint check astgrep

# If violations found:
just lint fix astgrep                    # Apply automatic fixes
# Review and manually fix remaining issues
just lint check astgrep                  # Verify fixes
```

#### Pre-PR Comprehensive Check
```bash
# Full validation before creating PR
just lint check all --parallel           # All linters including ast-grep
just test unit backend                    # Unit tests
just test integration backend             # Integration tests
```

### IDE Integration

#### VS Code Setup
Add to `.vscode/tasks.json`:
```json
{
    "label": "ast-grep Check",
    "type": "shell",
    "command": "just lint check astgrep",
    "group": "build",
    "presentation": {
        "echo": true,
        "reveal": "always",
        "focus": false,
        "panel": "shared"
    }
}
```

#### Real-time Validation
```bash
# File watcher for development
fswatch -o . | xargs -n1 -I{} just lint check astgrep --files $(git diff --name-only)
```

### Git Hook Integration

#### Pre-commit Hook
Add to `.pre-commit-config.yaml`:
```yaml
- repo: local
  hooks:
    - id: ast-grep-security
      name: ast-grep Security Check
      entry: just lint check astgrep
      language: system
      pass_filenames: false
```

---

## Rule Development

### Rule Structure and Syntax

#### Standard Rule Template
```yaml
id: rule-unique-identifier
message: "Brief description of the issue and solution"
severity: error|warning|info
language: python|typescript|javascript
note: |
  Detailed explanation with:
  ❌ Bad examples
  ✅ Good examples
  Context about why this matters

rule:
  kind: string|call|attribute|assignment
  pattern: $PATTERN_DEFINITION
  # Optional constraints
  has:
    kind: specific_node_type
    pattern: $CONSTRAINT
```

#### Pattern Matching Examples

**String Matching**:
```yaml
rule:
  kind: string
  pattern: "secret123"  # Matches hardcoded secret
```

**Function Call Matching**:
```yaml
rule:
  kind: call
  pattern: $FUNC.query.all()  # Matches unsafe query patterns
```

**Attribute Access**:
```yaml
rule:
  kind: attribute
  pattern: $USER.tenant_id    # Matches RLS violations
```

### Creating New Rules

#### Step 1: Identify Security Pattern
```python
# Example: Detect logging sensitive data
import logging
logging.info(f"User password: {password}")  # ❌ Security issue
```

#### Step 2: Create Rule File
Create `.ast-grep/rules/security/logging-sensitive-data.yml`:
```yaml
id: logging-sensitive-data-prevention
message: "Logging sensitive data like passwords detected. Use generic messages instead."
severity: error
language: python
note: |
  Prevents accidental logging of sensitive information.

  ❌ Bad:
  logging.info(f"User password: {password}")

  ✅ Good:
  logging.info("User authentication successful")

rule:
  kind: call
  pattern: logging.$METHOD($MSG)
  has:
    kind: string
    regex: '.*(password|secret|key|token).*'
```

#### Step 3: Add Test Cases
Create `.ast-grep/rules/security/tests/logging-sensitive-data-test.yml`:
```yaml
# Test cases for rule validation
positive:
  - |
    import logging
    logging.info(f"User password: {password}")
  - |
    logging.error(f"Secret key invalid: {api_key}")

negative:
  - |
    import logging
    logging.info("User authentication successful")
  - |
    logging.debug("Processing user request")
```

#### Step 4: Validate Rule
```bash
# Test rule syntax and matches
sg test --rule .ast-grep/rules/security/logging-sensitive-data.yml

# Test against actual codebase
sg scan --rule .ast-grep/rules/security/logging-sensitive-data.yml apps/backend/
```

#### Step 5: Performance Benchmark
```bash
# Test performance impact
python3 scripts/helpers/benchmark_astgrep.py --per-rule
```

### Rule Development Best Practices

#### Performance Guidelines
- **Pattern Complexity**: Keep patterns simple and specific
- **File Targeting**: Use language-specific targeting
- **Regex Usage**: Minimize regex complexity for speed
- **Target Scope**: Focus on high-impact security patterns

#### Quality Standards
- **Test Coverage**: Include positive and negative test cases
- **Documentation**: Provide clear examples and rationale
- **Maintainability**: Use descriptive IDs and messages
- **Team Review**: Get security team approval for new rules

---

## Performance Optimization

### Current Performance Metrics
- **Full Scan Time**: 1.7 seconds (94.3% better than 30s target)
- **Memory Usage**: 0.7MB (99.9% under 500MB limit)
- **File Filtering**: 99.2% efficiency (116,925 → 969 files)
- **Parallel Processing**: 8 optimal workers

### Optimization Strategies

#### 1. File Filtering Optimization
**Current Configuration** (`.ast-grep/sgconfig.yml`):
```yaml
ignore:
  - "node_modules/**"      # ~50,000 files excluded
  - ".venv/**"            # ~15,000 files excluded
  - "__pycache__/**"      # ~5,000 files excluded
  - "ios/Pods/**"         # ~30,000 files excluded
  - "build/**"
  - "dist/**"
  - ".build/**"
```

**Adding New Exclusions**:
```yaml
# Add patterns for new directories that don't need scanning
ignore:
  - "vendor/**"           # Third-party vendor code
  - "*.min.js"            # Minified JavaScript
  - "coverage/**"         # Test coverage reports
```

#### 2. Parallel Execution Tuning
**Optimal Configuration** (`lint_manager.py`):
```python
# Current optimal settings
with ThreadPoolExecutor(max_workers=min(len(rule_directories), 8)) as executor:
    # 8 workers provides best performance/resource balance
```

**Custom Worker Scaling**:
```python
# For different environments
cpu_count = os.cpu_count()
optimal_workers = min(max(cpu_count // 2, 4), 8)  # Scale with CPU, cap at 8
```

#### 3. Rule Performance Analysis
```bash
# Identify slow rules
python3 scripts/helpers/benchmark_astgrep.py --per-rule

# Expected output:
# Rule performance analysis:
# security/api-trailing-slash: 0.12s
# security/cross-tenant-leakage: 0.25s
# security/database-query-safety: 0.18s
```

### Performance Monitoring

#### Real-time Performance Tracking
```python
# Built into lint_manager.py
Performance Summary:
  • Total execution time: 1.700s (target: <30s) ✓
  • Files scanned: 969 (574.7 files/s)
  • Rules executed: 7 (4.1 rules/s)
  • Parallel workers: 8
  • Peak memory (traced): 0.3MB
  • Process memory: 0.7MB (target: <500MB) ✓
```

#### CI/CD Performance Regression Detection
```bash
# Automated in GitHub Actions
time_regression=$(echo "$scan_time > $benchmark_time * 1.5" | bc -l)
memory_regression=$(echo "$memory_used > $benchmark_memory * 1.2" | bc -l)
```

---

## Testing and Validation

### Test Categories

#### Unit Tests for Rules
**Location**: `tests/unit/test_astgrep_rules.py`

**Purpose**: Validate individual rule behavior
```bash
# Run rule-specific unit tests
just test unit backend --filter="test_astgrep_rules"

# Expected results:
# - Rule syntax validation
# - Positive/negative test cases
# - Performance benchmarks (<1s per rule)
```

#### Integration Tests for System
**Location**: `apps/backend/tests/integration/test_lint_manager_astgrep.py`

**Purpose**: End-to-end system validation
```bash
# Run integration tests
just test integration backend --filter="test_lint_manager_astgrep"

# Tests include:
# - Full codebase scan functionality
# - Parallel execution validation
# - Error handling and edge cases
```

#### Performance Tests
**Location**: `apps/backend/tests/integration/test_lint_manager_astgrep_performance.py`

**Purpose**: Performance target validation
```bash
# Validate performance targets
just test integration backend --filter="test_lint_manager_astgrep_performance"

# Assertions:
# - Execution time <30s (currently 1.7s)
# - Memory usage <500MB (currently 0.7MB)
```

### Test-Driven Rule Development

#### 1. Write Test Cases First
```yaml
# Create test file before implementing rule
# .ast-grep/rules/security/tests/new-rule-test.yml
positive:
  - |
    # Code that SHOULD trigger the rule
    problematic_pattern()
negative:
  - |
    # Code that should NOT trigger the rule
    safe_pattern()
```

#### 2. Implement Rule
```yaml
# Create rule based on test requirements
id: new-security-rule
message: "Security issue detected"
# ... rule implementation
```

#### 3. Validate Performance
```bash
# Ensure new rule doesn't degrade performance
python3 scripts/helpers/benchmark_astgrep.py --per-rule | grep new-security-rule
# Target: <2s per rule execution
```

---

## Configuration Management

### Primary Configuration File
**Location**: `.ast-grep/sgconfig.yml`

**Complete Configuration**:
```yaml
# Rule organization
ruleDirs:
  - rules/security      # Security vulnerabilities and best practices
  - rules/api-design    # REST API design patterns and consistency
  - rules/mobile        # React Native specific patterns
  - rules/admin         # React admin interface patterns
  - rules/common        # Shared patterns across all codebases

# Language targeting
languageGlobs:
  typescript: ["*.ts", "*.tsx"]
  javascript: ["*.js", "*.jsx"]
  python: ["*.py"]
  yaml: ["*.yml", "*.yaml"]
  json: ["*.json"]

# Performance optimization through exclusion
ignore:
  - "node_modules/**"
  - ".venv/**"
  - "__pycache__/**"
  - "ios/Pods/**"
  - "build/**"
  - "dist/**"
  - ".build/**"
  - "coverage/**"
```

### Directory Structure
```
.ast-grep/
├── sgconfig.yml           # Main configuration
├── rules/                 # Rule directories
│   ├── security/         # 7 security rules
│   │   ├── api-trailing-slash.yml
│   │   ├── cross-tenant-leakage.yml
│   │   ├── database-query-safety.yml
│   │   ├── env-var-security.yml
│   │   ├── frontend-api-consistency.yml
│   │   ├── jwt-security.yml
│   │   ├── rls-violation.yml
│   │   └── tests/        # Test files for rules
│   ├── api-design/       # Future: API consistency rules
│   ├── mobile/           # Future: React Native patterns
│   ├── admin/            # Future: Admin interface patterns
│   ├── common/           # Future: Cross-platform patterns
│   └── utils/            # Shared utilities
└── snapshots/            # Test snapshots
```

### Configuration Validation
```bash
# Verify configuration is valid
sg check --config .ast-grep/sgconfig.yml

# Test rule loading
sg list-rules --config .ast-grep/sgconfig.yml
```

---

## Common Issues and Solutions

### Installation Issues

#### Problem: ast-grep binary not found
```bash
# Error: command not found: ast-grep
just lint check astgrep
```

**Solutions**:
```bash
# Install via Rust cargo
cargo install ast-grep

# Install via Homebrew (macOS)
brew install ast-grep

# Verify installation
ast-grep --version
which ast-grep
```

#### Problem: Configuration file missing
```bash
# Error: Configuration file not found
```

**Solution**:
```bash
# Verify configuration exists
ls -la .ast-grep/sgconfig.yml

# If missing, check git status
git status .ast-grep/
```

### Performance Issues

#### Problem: Execution time >5s
```bash
# Diagnosis
python3 scripts/helpers/benchmark_astgrep.py --full-scan

# Check for new files being included
python3 scripts/helpers/benchmark_astgrep.py --file-analysis
```

**Solutions**:
1. **Check ignore patterns**: Add new file exclusions
2. **Worker optimization**: Verify 8 workers optimal
3. **Rule analysis**: Identify slow rules with `--per-rule`

#### Problem: Memory usage spikes
```bash
# Diagnosis
python3 scripts/helpers/benchmark_astgrep.py --memory-profile
```

**Solutions**:
1. **Batch size**: Reduce parallel processing batch size
2. **Rule optimization**: Simplify complex rule patterns
3. **File filtering**: More aggressive ignore patterns

### Rule Issues

#### Problem: Rule syntax errors
```bash
# Error: Invalid rule syntax in security/new-rule.yml
```

**Diagnosis**:
```bash
# Validate rule syntax
sg test --rule .ast-grep/rules/security/new-rule.yml
```

**Common Fixes**:
1. **YAML indentation**: Fix spacing and alignment
2. **Pattern syntax**: Verify ast-grep pattern format
3. **Language targeting**: Ensure correct language specified

### Performance Debugging

#### Comprehensive Diagnostics
```bash
# Full performance analysis
python3 scripts/helpers/benchmark_astgrep.py --report

# Output analysis:
{
  "overall_assessment": {
    "grade": "PASS",  # Should be PASS for good performance
    "recommended_worker_count": 8
  },
  "benchmarks": {
    "full_scan": {
      "execution_time_s": 1.700,    # Target: <30s
      "process_memory_mb": 0.7,     # Target: <500MB
      "files_scanned": 969          # Filtered count
    }
  }
}
```

---

## Integration Points

### lint_manager.py Integration
**Location**: `scripts/helpers/lint_manager.py`
**Function**: `run_astgrep_lint()` (line 447)

**Key Features**:
- Real-time performance profiling
- Parallel execution with 8 workers
- Memory usage monitoring
- Comprehensive error handling

### Justfile Commands
```bash
# Primary interface commands
just lint check astgrep          # Check violations
just lint fix astgrep            # Apply fixes
just lint check all --parallel   # All linters including ast-grep

# Direct script access
python3 scripts/helpers/lint_manager.py check astgrep
python3 scripts/helpers/lint_manager.py fix astgrep --files src/
```

### CI/CD Pipeline Integration
**GitHub Workflow**: `.github/workflows/ast-grep-security.yml`

**Pipeline Stages**:
1. Setup (Python + dependencies)
2. Configuration verification
3. Optimized security scan
4. Performance benchmarking
5. Regression analysis
6. Results reporting

**PR Comment Format**:
```markdown
## ✅ ast-grep Security Scan Results
- **Findings:** 0 security issues detected
- **Files Scanned:** 969
- **Performance:** 1.7s scan time (target: <30s) ✅
```

---

## Advanced Usage

### Custom Rule Development Workflow
```bash
# 1. Create rule file
cat > .ast-grep/rules/security/new-rule.yml << 'EOF'
id: custom-security-pattern
message: "Custom security issue detected"
severity: error
language: python
rule:
  kind: call
  pattern: unsafe_function($ARG)
EOF

# 2. Create test cases
cat > .ast-grep/rules/security/tests/new-rule-test.yml << 'EOF'
positive:
  - unsafe_function("test")
negative:
  - safe_function("test")
EOF

# 3. Validate rule
sg test --rule .ast-grep/rules/security/new-rule.yml

# 4. Test performance
python3 scripts/helpers/benchmark_astgrep.py --per-rule | grep custom-security-pattern
```

### Selective Scanning
```bash
# Scan specific directories
python3 scripts/helpers/lint_manager.py check astgrep --files apps/backend/

# Scan specific file types
sg scan --pattern "*.py" .ast-grep/rules/security/

# Scan changed files only
git diff --name-only | xargs python3 scripts/helpers/lint_manager.py check astgrep --files
```

### Performance Tuning for Large Codebases
```python
# Custom performance configuration
class AstGrepOptimizer:
    def __init__(self, codebase_size):
        if codebase_size > 10000:
            self.workers = 12
            self.batch_size = 100
        else:
            self.workers = 8
            self.batch_size = 50
```

---

## Related Documentation

### Core References
- **[ast-grep Architecture Documentation](../architecture/structural-analysis.md)** - System design and integration
- **[ast-grep Troubleshooting Guide](../workflows/ast-grep-troubleshooting.md)** - Complete problem resolution
- **[Performance Optimization Guide](ast-grep-optimization-guide.md)** - Detailed performance tuning

### SpaceWalker Integration
- **[Lint System Documentation](adding-custom-lints.md)** - Integration with broader linting
- **[Security Architecture](../architecture/security-architecture.md)** - Security context
- **[Development Workflows](../workflows/)** - Integration with dev processes

### External Resources
- **[ast-grep Official Documentation](https://ast-grep.github.io/)** - Core tool capabilities
- **[Security Pattern Libraries](https://owasp.org/)** - Industry standards
- **[Static Analysis Best Practices](https://github.com/analysis-tools-dev/static-analysis)** - Tool comparison

---

**Next Steps:**
1. **Start with Quick Setup**: Run `just lint check astgrep` to verify integration
2. **Learn Common Patterns**: Review security violations and fixes
3. **Integrate into Workflow**: Add to pre-commit hooks and IDE
4. **Create Custom Rules**: Follow rule development workflow for team-specific patterns
5. **Monitor Performance**: Use benchmarking tools for optimization

**Support**: For complex issues, see [ast-grep Troubleshooting Guide](../workflows/ast-grep-troubleshooting.md) or contact the development team.
