# 🔧 Justfile Special Characters Handling Guide

## Problem Description

When passing arguments with special characters (parentheses, quotes, spaces, etc.) through justfile recipes to bash scripts, you may encounter syntax errors like:

```bash
syntax error near unexpected token '('
```

This happens because justfile's default argument interpolation doesn't properly escape special characters for shell execution.

## Solution: Use `[positional-arguments]`

The `[positional-arguments]` attribute tells justfile to pass all arguments as positional parameters ($1, $2, etc.) instead of interpolating them directly into the recipe. This ensures proper shell escaping.

### Example: The PR Command Fix

**Before (Broken):**
```just
pr action pr_number='' *args='':
    #!/usr/bin/env bash
    bash scripts/helpers/pr/pr_command.sh '{{action}}' '{{pr_number}}' {{args}}
```

**After (Fixed):**
```just
[positional-arguments]
pr action pr_number='' *args='':
    #!/usr/bin/env bash
    set -euo pipefail
    # $1 = action, $2 = pr_number, $3... = remaining args
    bash scripts/helpers/pr/pr_command.sh "$1" "$2" "${@:3}"
```

## How It Works

1. **`[positional-arguments]`** attribute enables positional parameter mode for the recipe
2. **Parameters become**: `$1`, `$2`, `$3`, etc. in order of declaration
3. **Variadic args** (`*args`) start at the next position
4. **`"${@:3}"`** means "all arguments from position 3 onwards"

## When to Use This Pattern

Use `[positional-arguments]` when:
- ✅ Passing user input that might contain special characters
- ✅ Working with file paths that might have spaces
- ✅ Handling titles, descriptions, or text with punctuation
- ✅ Dealing with JSON strings or code snippets
- ✅ Any time you see shell syntax errors with special characters

## Common Patterns

### Pattern 1: Simple Command with Options
```just
[positional-arguments]
command target *options='':
    #!/usr/bin/env bash
    set -euo pipefail
    some-script.sh "$1" "${@:2}"
```

### Pattern 2: Command with Named Parameters
```just
[positional-arguments]
deploy env service *flags='':
    #!/usr/bin/env bash
    set -euo pipefail
    # $1 = env, $2 = service, $3... = flags
    deploy-script.sh --env "$1" --service "$2" "${@:3}"
```

### Pattern 3: Optional Parameters with Defaults
```just
[positional-arguments]
test suite='all' *args='':
    #!/usr/bin/env bash
    set -euo pipefail
    # $1 = suite (defaults to 'all'), $2... = additional args
    test-runner.sh --suite "$1" "${@:2}"
```

## Alternative Approaches (Less Recommended)

### 1. Using justfile's `quote()` function
```just
command arg:
    some-script {{quote(arg)}}
```
**Limitation**: Only works for individual arguments, not variadic args

### 2. Using eval (Dangerous)
```just
command *args='':
    eval "some-script {{args}}"
```
**Warning**: Can lead to command injection vulnerabilities

### 3. Manual escaping
```just
command *args='':
    # Attempt to escape manually - error prone!
    some-script {{replace(args, "(", "\\(")}}
```
**Problem**: Incomplete and fragile

## Best Practices

1. **Always use `[positional-arguments]`** for commands that accept user input
2. **Document the positional mapping** in comments
3. **Use proper quoting** around positional parameters: `"$1"` not `$1`
4. **Test with edge cases**:
   - Parentheses: `just command "test (with parens)"`
   - Quotes: `just command "test with 'quotes'"`
   - Spaces: `just command "test with spaces"`
   - Special chars: `just command "test & special | chars"`

## Debugging Tips

If you encounter issues:

1. **Add debug output**:
   ```just
   [positional-arguments]
   command *args='':
       #!/usr/bin/env bash
       set -euo pipefail
       echo "Args received: $@"
       echo "Arg count: $#"
       echo "First arg: ${1:-none}"
   ```

2. **Check justfile version**: Ensure you're using just 0.8.0 or later
   ```bash
   just --version
   ```

3. **Test directly**: Try the problematic command outside justfile
   ```bash
   bash scripts/helpers/pr/pr_command.sh edit 327 --title="test (with parens)"
   ```

## Applied Fixes in Spacewalker

Currently, the following commands use `[positional-arguments]`:

1. **`pr` command** - Handles PR operations with titles/descriptions containing special characters
   - Location: `justfile` line 833

## When to Apply This Fix

Before adding `[positional-arguments]` to other commands, check if they:

1. Accept user-provided text input
2. Work with file paths
3. Pass through command-line arguments
4. Have reported issues with special characters

## Example Migration

If you need to fix another command, here's the process:

1. **Identify the problematic command**
2. **Add `[positional-arguments]` attribute**
3. **Update the recipe to use positional parameters**
4. **Test with special characters**
5. **Document the change**

### Before:
```just
notes add title *content='':
    #!/usr/bin/env bash
    notes-manager add "{{title}}" {{content}}
```

### After:
```just
[positional-arguments]
notes add title *content='':
    #!/usr/bin/env bash
    set -euo pipefail
    # $1 = title, $2... = content words
    notes-manager add "$1" "${@:2}"
```

## References

- [Justfile Positional Arguments Documentation](https://just.systems/man/en/recipe-attributes.html#positional-arguments)
- [Justfile Functions (quote)](https://just.systems/man/en/functions.html#quote)
- [Bash Special Characters](https://www.gnu.org/software/bash/manual/html_node/Special-Characters.html)