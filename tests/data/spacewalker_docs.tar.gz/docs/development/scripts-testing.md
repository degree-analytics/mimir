# Scripts/Helpers Testing

## Overview

The scripts and helpers testing infrastructure is integrated into the unified test system and CI/CD pipeline.

## Test Organization

All scripts/helpers tests are located in `scripts/tests/`:

```
scripts/tests/
├── __init__.py                         # Package marker
├── git_info_tests/                     # Git-info AI system tests
│   ├── test_git_info_basic.py
│   └── test_git_info_integration.py
├── test_connection_manager.py          # Database connection tests
├── test_health_checker.py              # Health check tests
├── test_git_info.py                    # Simple git-info tests
└── ...                                # Other helper tests
```

## Running Tests Locally

### Using the unified test command:
```bash
# Run all scripts tests
just test unit scripts

# Run specific test pattern
just test unit scripts --pattern=git_info

# Run with coverage
just test unit scripts --coverage

# Run with CI settings
just test unit scripts --ci
```

### Direct pytest execution:
```bash
# From project root
cd scripts && python -m pytest tests/

# Run specific test file
cd scripts && python -m pytest tests/test_git_info.py -v
```

## CI/CD Integration

Scripts tests run as part of the CI/CD pipeline in the `test-scripts` job:

1. **Parallel execution**: Runs alongside backend, admin, and mobile tests
2. **Coverage reporting**: Generates coverage reports uploaded as artifacts
3. **PR comments**: Test status included in automated PR comments
4. **Dependencies**: Python 3.11, pytest, and project requirements

## Known Issues

Some tests are excluded by default due to platform-specific issues:
- `test_bastion_file_locking.py` - fcntl module issues
- `test_env_validator.py` - Import compatibility
- `test_tunnel_manager.py` - psutil dependency

These exclusions are configured in `test_manager.py`.

## Adding New Tests

1. Create test file in `scripts/tests/` following the pattern `test_*.py`
2. Import helpers using proper path setup:
   ```python
   import sys
   from pathlib import Path

   # Add helpers directory to path
   helpers_dir = Path(__file__).parent.parent / 'helpers'
   sys.path.insert(0, str(helpers_dir))

   from your_helper import YourClass
   ```
3. Follow pytest conventions for test discovery
4. Tests will automatically be included in CI runs

## Test Configuration

- **pytest.ini**: Located at `scripts/pytest.ini`
- **Python path**: Automatically set to include `scripts/helpers` and `scripts`
- **Coverage**: Measures coverage of `scripts/helpers` directory
- **Output**: Coverage reports saved to `.build/coverage/scripts/`
