# ast-grep Technical Content Inventory

## Overview

This document serves as the comprehensive technical content inventory for developing ast-grep documentation deliverables. It organizes all relevant technical content, code examples, configuration samples, performance data, and integration details from the SpaceWalker codebase.

**Created for TaskMaster Task 10.2** - *Gather and Organize Technical Content*

---

## 1. Security Rules Catalog

### 1.1 Complete Rule Set (7 Rules)

**Location**: `.ast-grep/rules/security/`

| Rule ID | File | Purpose | Language | Severity |
|---------|------|---------|----------|----------|
| api-trailing-slash-prevention | api-trailing-slash.yml | Prevent FastAPI authentication failures from trailing slashes | Python | Error |
| cross-tenant-leakage-detection | cross-tenant-leakage.yml | Detect potential cross-tenant data access | Python | Error |
| database-query-safety | database-query-safety.yml | Prevent SQL injection vulnerabilities | Python | Error |
| environment-variable-security | env-var-security.yml | Detect hardcoded secrets in code | Python | Error |
| frontend-api-consistency | frontend-api-consistency.yml | Ensure proper API error handling | TypeScript | Error |
| jwt-security-patterns | jwt-security.yml | Validate JWT security practices | Python | Error |
| rls-violation-detection | rls-violation.yml | Prevent RLS bypass patterns | Python | Error |

### 1.2 Rule Structure Pattern

**Standard Rule Format**:
```yaml
id: rule-unique-identifier
message: "Brief description of the issue and solution"
severity: error|warning|info
language: python|typescript|javascript
note: |
  Detailed explanation with:
  ❌ Bad examples
  ✅ Good examples
  Context about why this matters

rule:
  # Pattern matching logic
  kind: string|call|attribute|assignment
  pattern: $PATTERN_DEFINITION
```

### 1.3 Detailed Rule Analysis

#### API Trailing Slash Prevention
**Problem**: FastAPI routes with trailing slashes cause 403 authentication failures
**Pattern**: `/api/buildings/$|/api/users/$|/buildings/$|/users/$|/rooms/.+/$`
**Good Example**: `@app.get("/api/buildings")`
**Bad Example**: `@app.get("/api/buildings/")`

#### Cross-Tenant Leakage Detection
**Problem**: Potential access to data across tenant boundaries
**Pattern**: Detects `$MODEL.query.all()` and risky `tenant_id=$VAR` filters
**Good Example**: `current_tenant_id: int = Depends(get_current_tenant_id)`
**Bad Example**: `users = User.query.all()`

#### Database Query Safety
**Problem**: SQL injection vulnerabilities from unsafe query construction
**Pattern**: `(?i)(SELECT|UPDATE|DELETE).*WHERE.*\{.*\}` and similar
**Good Example**: `cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))`
**Bad Example**: `query = f"SELECT * FROM users WHERE id = {user_id}"`

#### Environment Variable Security
**Problem**: Hardcoded secrets in source code
**Pattern**: Assignments to secret-like variables with string literals
**Good Example**: `SECRET_KEY = os.getenv("SECRET_KEY")`
**Bad Example**: `SECRET_KEY = "sk-1234567890abcdef"`

#### Frontend API Consistency
**Problem**: Missing error handling in API calls
**Pattern**: `await fetch()` without try-catch or response.ok checks
**Good Example**: Try-catch with `response.ok` validation
**Bad Example**: `const response = await fetch(url); const data = await response.json();`

#### JWT Security Patterns
**Problem**: Insecure JWT practices
**Pattern**: Hardcoded secrets like `secret123` or weak algorithms like `none`
**Good Example**: `jwt.encode(payload, os.getenv("JWT_SECRET"), algorithm="HS256")`
**Bad Example**: `jwt.encode(payload, "secret123", algorithm="none")`

#### RLS Violation Detection
**Problem**: Bypassing Row Level Security by direct tenant_id access
**Pattern**: `current_user.tenant_id` attribute access
**Good Example**: `current_tenant_id: int = Depends(get_current_tenant_id)`
**Bad Example**: `user_tenant = current_user.tenant_id`

---

## 2. Configuration Management

### 2.1 Main Configuration (sgconfig.yml)

**Location**: `.ast-grep/sgconfig.yml`

**Key Configuration Sections**:
```yaml
# Rule organization
ruleDirs:
  - rules/security      # Security vulnerabilities and best practices
  - rules/api-design    # REST API design patterns and consistency
  - rules/mobile        # React Native specific patterns
  - rules/admin         # React admin interface patterns
  - rules/common        # Shared patterns across all codebases

# Language targeting
languageGlobs:
  typescript: ["*.ts", "*.tsx"]
  javascript: ["*.js", "*.jsx"]
  python: ["*.py"]
  yaml: ["*.yml", "*.yaml"]
  json: ["*.json"]

# Performance optimization through exclusion
ignore:
  - "node_modules/**"    # ~50,000 files excluded
  - ".venv/**"          # ~15,000 files excluded
  - "__pycache__/**"    # ~5,000 files excluded
  - "ios/Pods/**"       # ~30,000 files excluded
  - "build/**"
  - "dist/**"
  - ".build/**"
```

### 2.2 Directory Structure

```
.ast-grep/
├── sgconfig.yml           # Main configuration
├── rules/                 # Rule directories
│   ├── security/         # 7 security rules
│   │   ├── api-trailing-slash.yml
│   │   ├── cross-tenant-leakage.yml
│   │   ├── database-query-safety.yml
│   │   ├── env-var-security.yml
│   │   ├── frontend-api-consistency.yml
│   │   ├── jwt-security.yml
│   │   ├── rls-violation.yml
│   │   └── tests/        # Test files for rules
│   ├── api-design/       # API consistency (planned)
│   ├── mobile/           # React Native patterns (planned)
│   ├── admin/            # Admin interface patterns (planned)
│   ├── common/           # Cross-platform patterns (planned)
│   └── utils/            # Shared utilities
└── snapshots/            # Test snapshots
```

---

## 3. Performance Optimization Data

### 3.1 Performance Achievements

**Current Performance (Post-Optimization)**:
- **Execution Time**: ~1.7s (94.3% better than 30s target)
- **Memory Usage**: 0.7MB (99.9% under 500MB target)
- **File Filtering**: 99.2% reduction (116,925 → 969 relevant files)
- **Parallel Workers**: 8 optimal workers (empirically determined)

### 3.2 Performance Comparison

| Metric | Target | Achieved | Improvement |
|--------|--------|----------|-------------|
| Execution Time | <30s | 1.7s | 94.3% faster |
| Memory Usage | <500MB | 0.7MB | 99.9% reduction |
| File Processing | All files | 969 files | 99.2% filtered |
| Worker Efficiency | Unknown | 8 workers | Optimal determined |

### 3.3 Optimization Strategies

#### Strategy 1: Parallel Execution
```python
# Optimal configuration found through benchmarking
with ThreadPoolExecutor(max_workers=min(len(rule_directories), 8)) as executor:
    future_to_rule = {
        executor.submit(run_rule_directory, rule_info): rule_info[0]
        for rule_info in rule_directories
    }
```

#### Strategy 2: Intelligent File Filtering
- **Git Integration**: Uses `git ls-files` to respect .gitignore
- **Extension Filtering**: Targets supported file types only
- **Pattern Exclusion**: Comprehensive ignore patterns
- **Path Validation**: Ensures files exist before processing

#### Strategy 3: Memory Profiling & Monitoring
```python
# Dual memory tracking
tracemalloc.start()
if PSUTIL_AVAILABLE:
    current_process = psutil.Process()
    start_memory = current_process.memory_info()
```

### 3.4 Benchmarking Tools

**benchmark_astgrep.py** capabilities:
```bash
# Available benchmarks
python3 scripts/helpers/benchmark_astgrep.py --full-scan      # Complete scan timing
python3 scripts/helpers/benchmark_astgrep.py --test-workers  # Worker optimization
python3 scripts/helpers/benchmark_astgrep.py --per-rule      # Rule-level performance
python3 scripts/helpers/benchmark_astgrep.py --report        # Comprehensive report
```

---

## 4. Integration Points

### 4.1 lint_manager.py Integration

**Location**: `scripts/helpers/lint_manager.py`
**Function**: `run_astgrep_lint()` at line 447

**Key Integration Features**:
- **Performance Profiling**: Real-time memory and timing tracking
- **Parallel Rule Execution**: ThreadPoolExecutor with 8 workers
- **Intelligent File Filtering**: Git-aware file discovery
- **Comprehensive Error Handling**: Graceful degradation
- **Progress Reporting**: Real-time performance feedback

**Performance Output Format**:
```
Performance Summary:
  • Total execution time: 1.700s (target: <30s) ✓
  • Files scanned: 969 (574.7 files/s)
  • Rules executed: 28 (16.5 rules/s)
  • Parallel workers: 8
  • Peak memory (traced): 0.3MB
  • Process memory: 0.7MB (target: <500MB) ✓
  • Memory delta: +0.1MB
```

### 4.2 Justfile Commands

**Primary Interface**:
```bash
# Recommended commands
just lint check astgrep        # Check for violations
just lint fix astgrep          # Apply automatic fixes

# Direct access
python3 scripts/helpers/lint_manager.py check astgrep
python3 scripts/helpers/lint_manager.py fix astgrep --files src/api/routes.py
```

### 4.3 CI/CD Integration

**GitHub Workflow**: `.github/workflows/ast-grep-security.yml`

**Pipeline Architecture**:
1. **Setup** (Python + dependencies)
2. **Configuration Verification**
3. **Optimized Security Scan**
4. **Performance Benchmarking**
5. **Regression Analysis**
6. **Results Reporting**
7. **Artifact Archival**

**Performance Monitoring**:
```yaml
# Regression detection logic
time_regression=$(echo "$scan_time > $benchmark_time * 1.5" | bc -l)  # >50% increase
memory_regression=$(echo "$memory_used > $benchmark_memory * 1.2" | bc -l)  # >20% increase
```

**PR Comment Format**:
```markdown
## ✅ ast-grep Security Scan Results

### 🛡️ Security Analysis
- **Findings:** 0 security issues detected
- **Files Scanned:** 969
- **Rules Executed:** 7

### ⚡ Performance Metrics
- **Scan Time:** 1.7s (target: <30s)
- **Memory Usage:** 0.7MB (target: <500MB)
- **Performance Targets:** ✅ Met
- **Benchmark Grade:** PASS
- **Regression Status:** ✅ None
```

---

## 5. Testing Strategy

### 5.1 Test Categories

**Unit Tests** (`tests/unit/test_astgrep_rules.py`):
- Rule syntax and structure validation
- Performance benchmarks (<1s per rule)
- Positive/negative test cases
- F.I.R.S.T principles compliance
- Mocked CLI interactions for speed

**Integration Tests** (`apps/backend/tests/integration/test_lint_manager_astgrep.py`):
- Parallel execution functionality
- End-to-end performance validation
- Error handling and edge cases
- Full codebase scan testing

**Performance Tests** (`apps/backend/tests/integration/test_lint_manager_astgrep_performance.py`):
- 30-second execution target validation
- Memory usage under 500MB validation
- File filtering effectiveness
- Worker optimization verification

### 5.2 Test Execution Commands

```bash
# Unit tests for rules
just test unit backend --filter="test_astgrep_rules"

# Integration tests for performance
just test integration backend --filter="test_lint_manager_astgrep"

# Performance benchmarking
python3 scripts/helpers/benchmark_astgrep.py --report
```

### 5.3 Performance Validation

**Test Assertions**:
```python
def test_full_codebase_scan_performance(self):
    # Performance assertion - should complete within 30s target
    assert execution_time < 30.0, f"Full scan exceeded 30s target: {execution_time:.3f}s"

def test_memory_usage_stays_under_limit(self):
    # Memory should stay well under 500MB limit
    assert process_memory_mb < 500.0, f"Memory usage exceeded 500MB: {process_memory_mb:.1f}MB"
```

---

## 6. Common Error Patterns & Resolutions

### 6.1 Installation Issues

**Problem**: ast-grep binary not found
```bash
# Solution: Install via package manager
cargo install ast-grep          # Rust
brew install ast-grep           # macOS
```

**Problem**: Configuration file missing
```bash
# Solution: Verify configuration exists
ls -la .ast-grep/sgconfig.yml
```

### 6.2 Performance Issues

**Problem**: Execution time >5s
```bash
# Diagnosis
python3 scripts/helpers/benchmark_astgrep.py --full-scan

# Solutions:
# - Check file filtering effectiveness
# - Verify worker count optimization
# - Review new ignore patterns needed
```

**Problem**: Memory usage spikes
```bash
# Diagnosis
python3 scripts/helpers/benchmark_astgrep.py --memory-profile

# Solutions:
# - Reduce batch size in parallel processing
# - Check for memory leaks in rule processing
```

### 6.3 Rule Processing Failures

**Problem**: Individual rules timing out
```bash
# Diagnosis
python3 scripts/helpers/benchmark_astgrep.py --per-rule

# Solutions:
# - Optimize complex rule patterns
# - Increase per-rule timeout limits
# - Split complex rules into simpler components
```

---

## 7. Development Workflow Examples

### 7.1 Pre-commit Validation

**Fast Development Cycle**:
```bash
# Quick validation during development (~1.7s)
just lint check astgrep

# Part of comprehensive pre-commit
just lint check all --parallel
```

### 7.2 CI/CD Pipeline Usage

**Automated Validation**:
```bash
# Strict validation with performance monitoring
python3 scripts/helpers/lint_manager.py check astgrep --ci

# Expected metrics collection in CI
scan_time=$(grep "Total execution time:" scan_output | ...)
process_memory=$(grep "Process memory:" scan_output | ...)
```

### 7.3 Rule Development Workflow

**Adding New Rules**:
1. Create rule file in appropriate directory
2. Add positive/negative test cases
3. Validate with unit tests
4. Benchmark performance impact
5. Update configuration if needed

**Testing New Rules**:
```bash
# Test specific rule files
sg scan --rule .ast-grep/rules/security/new-rule.yml target-file.py

# Validate rule syntax
sg test --rule .ast-grep/rules/security/new-rule.yml
```

---

## 8. Future Enhancement Opportunities

### 8.1 Planned Optimizations

**Rule Compilation Caching**:
- Current: Rules parsed on each execution
- Opportunity: Cache compiled rule patterns
- Expected Benefit: 10-15% execution time reduction

**Incremental Scanning**:
- Current: Full codebase scan on each run
- Opportunity: Only scan changed files (git diff)
- Expected Benefit: 80-90% time reduction for incremental runs

**Rule Dependency Optimization**:
- Current: All rules run independently
- Opportunity: Skip dependent rules when prerequisites fail
- Expected Benefit: Early termination, faster failure feedback

### 8.2 Scalability Considerations

- **Current Capacity**: ~1000 files, 30 rules
- **Estimated Scaling**: Linear to ~10,000 files with current optimizations
- **Memory Growth**: Sub-linear due to efficient filtering
- **Worker Scaling**: Tested up to 16 workers (diminishing returns beyond 8)

---

## 9. Documentation Deliverable Organization

### 9.1 Proposed Documentation Structure

**Developer Guide** (Primary technical reference):
- Getting started with ast-grep
- Rule development workflow
- Integration with lint_manager.py
- Performance optimization techniques
- Testing and validation

**Architecture Documentation** (System design):
- ast-grep integration architecture
- Parallel execution design
- File filtering optimization
- Memory management strategy
- CI/CD pipeline integration

**Quick Start Guide** (Fast onboarding):
- 5-minute setup
- Essential commands
- Common use cases
- Troubleshooting checklist

**Troubleshooting Guide** (Problem resolution):
- Common errors and solutions
- Performance debugging
- Configuration issues
- Rule development problems

**Team Onboarding** (New team member guide):
- Understanding security rules
- Development workflow integration
- Performance expectations
- Best practices

### 9.2 Content Mapping by Deliverable

**Developer Guide Content**:
- All 7 security rules with examples
- Configuration management (sgconfig.yml)
- Performance optimization strategies
- Integration points (lint_manager.py, justfile, CI/CD)
- Testing strategy and commands

**Architecture Documentation Content**:
- Parallel execution implementation
- File filtering architecture
- Memory profiling system
- CI/CD integration design
- Performance monitoring infrastructure

**Quick Start Guide Content**:
- Installation commands
- Basic justfile commands
- Performance verification
- Essential troubleshooting

**Troubleshooting Guide Content**:
- Common error patterns and solutions
- Performance debugging workflow
- Configuration validation
- Rule development issues

**Team Onboarding Content**:
- Security rule understanding
- Development workflow integration
- Performance expectations
- Best practices and standards

---

## 10. Code Samples Repository

### 10.1 Configuration Examples

**Basic sgconfig.yml**:
```yaml
ruleDirs:
  - rules/security
languageGlobs:
  python: ["*.py"]
  typescript: ["*.ts", "*.tsx"]
ignore:
  - "node_modules/**"
  - ".venv/**"
```

**Advanced Performance Configuration**:
```yaml
ignore:
  - "node_modules/**"      # ~50,000 files
  - ".venv/**"            # ~15,000 files
  - "__pycache__/**"      # ~5,000 files
  - "ios/Pods/**"         # ~30,000 files
  - "build/**"
  - "dist/**"
  - ".build/**"
  - "coverage/**"
```

### 10.2 Integration Code Examples

**lint_manager.py Integration**:
```python
def run_astgrep_lint(action: str, files: Optional[List[str]] = None) -> int:
    """Run ast-grep linting with semantic pattern matching using parallel rule execution."""
    # Performance profiling setup
    tracemalloc.start()
    start_total_time = time.perf_counter()

    # Parallel rule execution
    with ThreadPoolExecutor(max_workers=min(len(rule_directories), 8)) as executor:
        # ... implementation
```

**Performance Benchmarking**:
```python
class PerformanceProfiler:
    def start_profiling(self, operation_name: str):
        self.start_time = time.perf_counter()
        tracemalloc.start()
        if self.process:
            self.start_memory = self.process.memory_info()
```

### 10.3 CI/CD Configuration Examples

**GitHub Actions Workflow**:
```yaml
- name: Run optimized ast-grep security scan
  run: |
    python3 scripts/helpers/lint_manager.py check astgrep 2>&1 | tee scan_output
    scan_time=$(grep "Total execution time:" scan_output | ...)
    process_memory=$(grep "Process memory:" scan_output | ...)
```

---

## 11. Performance Metrics & Benchmarks

### 11.1 Current Performance Baseline

**Comprehensive Performance Report**:
```json
{
  "overall_assessment": {
    "grade": "PASS",
    "recommended_worker_count": 8
  },
  "benchmarks": {
    "full_scan": {
      "execution_time_s": 1.700,
      "process_memory_mb": 0.7,
      "files_scanned": 969,
      "rules_executed": 7
    }
  }
}
```

### 11.2 Performance Targets

| Metric | Target | Current | Status |
|--------|--------|---------|--------|
| Full Scan Time | <30s | 1.7s | ✅ Pass |
| Memory Usage | <500MB | 0.7MB | ✅ Pass |
| Per-Rule Time | <2s | <0.25s avg | ✅ Pass |
| File Filtering | Optimized | 99.2% reduction | ✅ Pass |

### 11.3 Regression Detection

**Alert Thresholds**:
- **Time Regression**: >50% increase vs baseline
- **Memory Regression**: >20% increase vs baseline
- **File Count**: Significant increase in processed files
- **Rule Failures**: Any rule processing timeouts

---

This technical content inventory provides comprehensive coverage of all ast-grep related technical content in the SpaceWalker codebase, organized for efficient documentation development across all planned deliverables.
