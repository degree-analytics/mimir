# Spacewalker Development Tools

## Purpose
Professional-grade development automation and helper scripts for cross-platform Spacewalker development. Essential reference for advanced automation capabilities, database management, workflow orchestration, and development environment configuration across backend, admin, and mobile platforms.

## When to Use This
- Setting up development environments and automation workflows
- Understanding database access patterns and security procedures
- Implementing CI/CD workflows and quality automation
- Managing cross-platform mobile development configurations
- Troubleshooting development environment issues
- Keywords: development automation, helper scripts, database management, workflow orchestration, cross-platform tools

**Version:** 2.0 (Reorganized from tools documentation)
**Date:** 2025-06-29
**Status:** Current - Production Development Automation

---

## =� Development Tools Overview

### Professional-Grade Automation Philosophy
Spacewalker's development tools provide **professional-grade automation capabilities** that go beyond simple shell commands, offering advanced error handling, timeout protection, progress tracking, and cross-platform compatibility essential for enterprise development workflows.

### Tool Categories by Development Phase
1. **Environment Setup** - Cross-platform configuration and mobile development setup
2. **Database Operations** - Secure access, backup management, migration support
3. **Workflow Orchestration** - CI/CD pipeline automation and quality assurance
4. **Development Support** - Debugging tools, validation scripts, and maintenance utilities

---

## =� Development Tools Organization

```
scripts/
   database/
      db_helper.py           # Secure AWS database access via bastion host
      README.md              # Database scripts documentation
   dev/
      configure_mobile.py    # Cross-platform mobile IP configuration
   helpers/
       workflow_manager.py     # Advanced workflow orchestration
       db_manager.py          # Intelligent database operations
```

### Integration with Development Workflow
All tools integrate seamlessly with justfile commands, providing consistent interfaces while leveraging sophisticated Python automation for complex operations requiring state management, error recovery, and cross-platform compatibility.

---

## =� Cross-Platform Mobile Configuration

### `scripts/dev/configure_mobile.py`

**Purpose**: Robust, cross-platform mobile IP configuration that replaces brittle shell script approaches with reliable Python automation for React Native development.

#### Enterprise Features
- **Cross-Platform IP Detection** - Works reliably on macOS, Linux, Windows
- **Multiple Fallback Strategies** - Ensures reliable IP detection in complex network environments
- **Regex-Based File Updates** - Safe, precise configuration updates with validation
- **Automatic Backup Creation** - Backup before modifications with rollback capability
- **Network Validation** - Verifies IP format and network reachability

#### Development Workflow Integration
```bash
# Quick IP fix with auto-detection (recommended)
just fix_ip

# Detailed operation logging for debugging
just fix_ip --verbose

# Direct script usage with advanced options
python scripts/dev/configure_mobile.py [options]
```

#### Advanced IP Detection Strategies
The script implements a sophisticated detection hierarchy designed for reliability in enterprise network environments:

**1. Socket Connection Method (Primary)**
- Connects to `8.8.8.8:80` to determine active interface IP
- Works reliably behind NAT and with complex network setups
- Fast execution and highly reliable
- Handles VPN and multi-interface configurations

**2. Network Interface Enumeration (Fallback)**
- Systematically scans network interfaces for valid addresses
- Intelligent filtering of VPN and virtual interfaces
- Cross-platform interface detection
- Prioritizes physical network interfaces

**3. Hostname Resolution (Last Resort)**
- Resolves local hostname to IP address
- Works when other methods fail due to network restrictions
- May return loopback address in some configurations
- Provides diagnostic information for troubleshooting

#### Configuration File Management
**Files Updated:**
- `apps/mobile/.env` - Updates `EXPO_PUBLIC_BACKEND_URL` for backend connectivity
- `apps/mobile/app.json` - Updates Metro bundler configuration for development

**Example Execution Output:**
```bash
=
 Detecting local IP address...
 Local IP detected: 192.168.1.100 (via socket method)
=� Updating apps/mobile/.env...
=� Updating apps/mobile/app.json...
 Configuration updated successfully
=� Updated EXPO_PUBLIC_BACKEND_URL: http://192.168.1.100:8000
=� Updated Metro configuration for development server
```

#### Comprehensive Error Handling
- **Network Unreachable** - Provides detailed diagnostic information and network troubleshooting steps
- **File Permissions** - Clear error messages with specific solution instructions
- **Invalid IP Format** - Format validation with helpful feedback and correction suggestions
- **Backup Failures** - Graceful degradation with warnings and alternative approaches

---

## =� Secure Database Access & Management

### `scripts/database/db_helper.py`

**Purpose**: Enterprise-grade secure database access via bastion host with AWS Secrets Manager integration, eliminating hardcoded credentials and providing production-level security for database operations.

#### Enterprise Security Architecture
- **AWS Secrets Manager Integration** - Zero hardcoded credentials with automatic rotation support
- **CloudFormation Discovery** - Auto-retrieves bastion IP from infrastructure stack outputs
- **SSH Tunnel Management** - Automated tunnel creation, lifecycle management, and cleanup
- **Connection Orchestration** - Seamless database connection workflow with error recovery
- **Migration Debugging** - Built-in Alembic status checking and lock detection

#### Secure Access Workflow Commands
```bash
# Comprehensive connectivity and credential testing
just db_test

# One-shot automated connection (recommended for most use cases)
just db_quick_connect

# Create persistent SSH tunnel for extended sessions
just db_tunnel

# Connect via existing tunnel (use with db_tunnel)
just db_connect

# Direct SSH access to bastion host for advanced operations
just bastion_ssh

# Check Alembic migrations and detect locks
just db_migration_status
```

#### Advanced Database Security
**Credential Management:**
- **Secrets Manager** - Database credentials fetched securely from `AURORA/{env}-spacewalker`
- **CloudFormation Integration** - Bastion IP discovered dynamically from stack outputs
- **SSH Key Management** - Secure key handling via `~/.ssh/{env}-spacewalker-key.pem`
- **Zero Credential Storage** - No credentials stored in code, configuration, or environment files

**Network Security Architecture:**
- **Bastion Host** - Dedicated t4g.nano EC2 instance with IP-restricted SSH access
- **Security Group Configuration** - Database accepts connections only from bastion host
- **Encrypted SSH Tunneling** - All database traffic encrypted through secure jump host
- **Port Conflict Management** - Automatic port discovery and conflict resolution

#### Automated Connection Workflow
**Quick Connect Process (`just db_quick_connect`):**
```
1. Validate AWS credentials and IAM permissions
2. Fetch database credentials from AWS Secrets Manager
3. Discover bastion IP from CloudFormation stack outputs
4. Validate SSH key exists and has correct permissions
5. Find available local port (starting from 5432)
6. Create SSH tunnel in background with monitoring
7. Establish database connection via encrypted tunnel
8. Provide interactive psql session
9. Clean up tunnel and connections on exit
```

**Manual Connection Process (`just db_tunnel` + `just db_connect`):**
```bash
# Terminal 1: Create persistent tunnel
just db_tunnel
# Validates credentials, creates tunnel, displays connection info

# Terminal 2: Connect to database
just db_connect
# Connects via existing tunnel for interactive session
```

#### Migration Debugging & Monitoring
**Automated Status Checking:**
```sql
-- Automatically executed by db_migration_status
SELECT version_num, is_partial FROM alembic_version;
SELECT pid, locktype, mode, granted, relation FROM pg_locks
WHERE locktype IN ('advisory', 'relation');
SELECT * FROM pg_stat_activity WHERE state != 'idle';
```

**Common Debugging Scenarios:**
- **Hanging Migrations** - Detect DDL locks from concurrent migration processes
- **Migration Conflicts** - Identify conflicting migration attempts and resolution paths
- **Connection Issues** - Comprehensive validation of database connectivity and credential access
- **Lock Investigation** - Detailed analysis of advisory locks and blocking processes

---

## =� Workflow Orchestration & CI/CD

### `scripts/helpers/workflow_manager.py`

**Purpose**: Professional workflow orchestration with enterprise-grade timeout protection, comprehensive error handling, progress tracking, and configurable retry logic for complex development workflows.

#### Advanced Workflow Architecture
```python
@dataclass
class WorkflowStep:
    name: str          # Unique identifier for tracking and logging
    command: str       # Command to execute with full argument specification
    description: str   # Human-readable description for progress reporting
    timeout: int       # Maximum execution time in seconds
    required: bool     # Whether failure should stop entire workflow
    retry_count: int   # Number of automatic retries on failure
    retry_delay: int   # Delay between retries in seconds
```

#### Production-Ready Workflows

**1. Complete Development Setup (`setup`)**
```bash
python scripts/helpers/workflow_manager.py setup [--verbose] [--skip-tests]
```
**Comprehensive Environment Preparation:**
- Environment prerequisite validation (Docker, Node.js, Python versions)
- Dependency installation with version verification
- Cross-platform mobile IP configuration
- Docker environment preparation and service startup
- Service health validation with connectivity testing
- Unit test verification across all platforms

**2. CI/CD Pipeline Automation (`ci`)**
```bash
python scripts/helpers/workflow_manager.py ci [--unit-only] [--verbose] [--fail-fast]
```
**Enterprise CI/CD Capabilities:**
- `--unit-only` - Skip integration tests for rapid feedback cycles
- `--verbose` - Comprehensive step-by-step logging and diagnostics
- `--fail-fast` - Stop on first failure for rapid development feedback

**CI/CD Pipeline Steps:**
- Dependency installation with integrity verification
- Code quality checks (linting, formatting, type checking)
- Unit test execution across all platforms
- Infrastructure startup and health validation (unless `--unit-only`)
- Integration test execution with isolation (unless `--unit-only`)
- Infrastructure cleanup and resource management

**3. Production Readiness Validation (`prod-check`)**
```bash
python scripts/helpers/workflow_manager.py prod-check [--verbose] [--strict]
```
**Production Deployment Validation:**
- Code quality validation with strict standards
- Complete test suite execution with coverage requirements
- Build verification and artifact validation
- Environment configuration validation
- Security compliance checking
- Performance baseline validation

#### Enterprise-Grade Features

**Intelligent Timeout Protection:**
```python
# Example: Unit tests with context-aware timeout
WorkflowStep(
    name="test_unit_backend",
    command="just test unit all_backend",
    description="Executing backend unit tests with coverage",
    timeout=300,  # 5 minutes - appropriate for unit test suite
    required=True,
    retry_count=1,
    retry_delay=10
)
```

**Real-Time Progress Tracking:**
```
[14:32:15] 9 Starting CI workflow with 8 steps
[14:32:15] 9 Step 1/8: Environment prerequisite validation
[14:32:17]  env_check completed successfully (2.1s)
[14:32:17] 9 Step 2/8: Installing dependencies with verification
[14:34:22]  dependency_install completed successfully (2m 5s)
[14:34:22] 9 Step 3/8: Code quality validation
```

**Sophisticated Error Recovery:**
- **Required Steps** - Workflow terminates with comprehensive error reporting and recovery suggestions
- **Optional Steps** - Continue execution with detailed warnings and impact analysis
- **Timeout Handling** - Graceful process termination with diagnostic information
- **Retry Logic** - Configurable retry attempts with exponential backoff for transient failures

---

## =� Intelligent Database Management

### `scripts/helpers/db_manager.py`

**Purpose**: Enterprise-grade database operations with automatic backup management, migration validation, comprehensive safety checks, and intelligent recovery procedures.

#### Advanced Database Operations
- **Automatic Backup Creation** - Timestamped backups before any destructive operation
- **Health Monitoring** - Sophisticated database readiness detection with timeout handling
- **Migration Validation** - Schema consistency verification and conflict detection
- **Safe Operations** - Multiple safety checks, confirmations, and rollback capabilities

#### Comprehensive Backup Management
**Backup Operations:**
```bash
# Create timestamped backup with metadata
python scripts/helpers/db_manager.py backup [--name custom_name] [--compress]

# List available backups with size and metadata
python scripts/helpers/db_manager.py list [--detailed]

# Intelligent cleanup maintaining recent backups
python scripts/helpers/db_manager.py cleanup [--keep 10] [--preserve-named]
```

**Advanced Restore Operations:**
```bash
# Restore from specific backup with validation
python scripts/helpers/db_manager.py restore backup_20241221_143022.sql [--verify]

# Safe reset with automatic backup creation
python scripts/helpers/db_manager.py safe-reset [--no-backup] [--force]
```

**Validation & Health Monitoring:**
```bash
# Comprehensive migration and schema validation
python scripts/helpers/db_manager.py validate [--verbose] [--fix-issues]
```

#### Intelligent Backup Management
**Automatic Naming Convention:**
```
backup_20241221_143022.sql    # Auto-generated with timestamp
migration_prep.sql            # Custom named for specific purposes
before_schema_change.sql      # Descriptive custom naming
pre_deployment_backup.sql     # Release-specific backup
```

**Organized Storage:**
```
.build/db_backups/
   backup_20241221_143022.sql    # Recent automatic backup
   backup_20241221_120000.sql    # Previous automatic backup
   migration_prep.sql            # Custom named backup
   before_schema_change.sql      # Schema change backup
   metadata/
       backup_20241221_143022.meta   # Backup metadata
       checksums.md5                 # Integrity verification
```

**Intelligent Cleanup Strategy:**
- Preserves 10 most recent automatic backups by default
- Sorts by modification time for chronological cleanup
- Automatically preserves custom-named backups
- Validates backup integrity before deletion
- Provides dry-run option for cleanup verification

#### Enterprise Safety Features
**Pre-Operation Validation:**
- Database connectivity verification with timeout handling
- Available disk space checking (minimum 2GB for operations)
- Backup directory permissions and write access validation
- User confirmation for destructive operations with impact summary

**Advanced Health Monitoring:**
```python
def wait_for_database(self, max_wait: int = 60) -> bool:
    """
    Wait for database readiness with comprehensive health checks.
    Includes connectivity, schema validation, and migration status.
    """
    for attempt in range(max_wait):
        if self.is_database_running():
            # Check basic connectivity
            connectivity_check = self.run_command(
                "docker compose exec -T db pg_isready -U postgres"
            )
            if connectivity_check[0]:
                # Verify schema accessibility
                schema_check = self.verify_schema_access()
                if schema_check:
                    return True
        time.sleep(1)
    return False
```

**Migration Status Validation:**
- Current migration version verification
- Schema consistency checking across environments
- Migration conflict detection and resolution suggestions
- Data integrity validation post-migration

#### Seamless Integration with Development Workflow
**Justfile Command Integration:**
```bash
# Database management commands using db_manager internally
just db_backup                 # -> db_manager.py backup
just db_backup_named "release" # -> db_manager.py backup --name release
just db_safe_reset             # -> db_manager.py safe-reset
just db_validate               # -> db_manager.py validate
just db_list_backups          # -> db_manager.py list
just db_cleanup               # -> db_manager.py cleanup
just db_restore "backup.sql"  # -> db_manager.py restore backup.sql
```

**Example Production Workflows:**

**Safe Database Reset with Backup:**
```bash
$ just db_safe_reset
[14:30:15] 9 Performing pre-reset validation...
[14:30:15]  Database connectivity verified
[14:30:15]  Sufficient disk space available (15.2 GB)
[14:30:15] 9 Creating backup before reset...
[14:30:16]  Backup created: .build/db_backups/backup_20241221_143015.sql (45.2 MB)
[14:30:16] 9 Performing safe database reset...
[14:30:25]  Database reset completed successfully
[14:30:25] 9 Backup available for rollback if needed
```

**Release Preparation Backup:**
```bash
$ just db_backup_named "pre-release-v2.2"
[14:35:20] 9 Creating named backup for release preparation...
[14:35:22]  Backup created: .build/db_backups/pre-release-v2.2.sql (48.7 MB)
[14:35:22]  Backup metadata saved: .build/db_backups/metadata/pre-release-v2.2.meta
[14:35:22] 9 Backup ready for release rollback procedures
```

---

## 🎭 Playwright E2E Testing Tools

### Purpose & Philosophy
Professional E2E testing requires sophisticated debugging tools, environment management, and test maintenance utilities. Spacewalker's Playwright integration provides comprehensive browser automation with advanced debugging capabilities, multi-environment support, and intelligent test health monitoring.

### Playwright Tool Integration

#### Browser Management & Installation
```bash
# Install and manage Playwright browsers
just playwright_install                    # Install chromium, firefox, webkit
npx playwright install --help             # View installation options
npx playwright install chromium --force   # Force reinstall specific browser

# Browser maintenance and updates
npx playwright --version                  # Check Playwright version
npx playwright install-deps               # Install system dependencies
```

#### Advanced Debugging & Development
```bash
# Interactive test development
just test_e2e_admin_ui                    # Open Playwright UI for debugging
just test_e2e_admin_debug                 # Debug with extended timeouts
just test_e2e_admin_debug "auth"          # Debug specific test patterns

# Detailed logging and trace analysis
DEBUG=pw:api just test_e2e_admin          # Enable API debugging
DEBUG=pw:browser just test_e2e_admin      # Enable browser debugging
DEBUG=pw:page just test_e2e_admin         # Enable page-level debugging

# Test execution with custom configurations
HEADED=true just test_e2e_admin           # Run tests in headed mode
TEST_TIMEOUT=120000 just test_e2e_admin   # Custom timeout configuration
```

#### Multi-Environment Testing Support
```bash
# Environment-specific test execution
just test_e2e_admin_env local             # Test against localhost:3001
just test_e2e_admin_env dev               # Test against dev environment
just test_e2e_admin_env staging           # Test against staging environment

# Environment validation and health checks
just demo_verify_e2e                     # Validate demo data requirements
curl https://admin.spacewalker.littleponies.com/health  # Manual connectivity check
```

### Professional Test Development Workflow

#### Test Report Generation & Analysis
```bash
# Comprehensive reporting tools
just test_e2e_admin_report               # Generate and open HTML reports
just test_e2e_admin_perf                 # Performance benchmarking reports

# CI/CD integration reports
npx playwright test --reporter=html,junit --output=.build/test-results/
npx playwright show-report --host=0.0.0.0 --port=8080  # Remote report access
```

#### Test Health Monitoring & Maintenance
```bash
# Automated test maintenance
npm run test:flaky-detection             # Identify unreliable tests
npm run test:performance-baseline       # Performance regression detection
npm run test:coverage-gaps              # Identify untested workflows

# Test environment synchronization
scripts/sync-test-environments.sh       # Sync demo data across environments
```

### Integration with Development Tools

#### IDE Integration & Developer Experience
Advanced Playwright integration with VS Code debugger support:

```json
// .vscode/launch.json - Professional debugging setup
{
  "name": "Debug E2E Test",
  "type": "node",
  "request": "launch",
  "program": "${workspaceFolder}/node_modules/@playwright/test/cli.js",
  "args": ["test", "--debug", "${file}"],
  "console": "integratedTerminal",
  "env": {
    "DEBUG": "pw:api",
    "HEADED": "true"
  }
}
```

#### Quality Gates & Pre-commit Hooks
```bash
# Automated quality assurance
.husky/pre-commit:
#!/bin/sh
npm run test:lint-e2e                   # Lint E2E test files
npm run test:validate-selectors         # Check selector robustness
npm run test:smoke-e2e                  # Quick smoke tests

.husky/pre-push:
#!/bin/sh
npm run test:critical-path              # Essential workflow validation
```

---

## 🔧 BACnet Helper Scripts & Diagnostic Tools

### Purpose & Philosophy
Professional BACnet development requires consistent environment management and reliable diagnostic operations. Spacewalker provides comprehensive helper scripts that ensure reliable interaction with BACnet connector environments through standardized justfile commands and specialized diagnostic tools.

### Script Categories & Hierarchy

#### 1. Docker Environment Management (Primary Tool: Justfile)
The justfile serves as the primary interface for all Docker operations, providing consistent and reliable BACnet environment management:

```bash
# ✅ PRIMARY: Use justfile commands (recommended approach)
just docker-build                       # Build BACnet services
just docker-build --no-cache            # Force rebuild without cache
just docker-build --prod                # Build for production
just docker-start                       # Start BACnet services
just docker-stop                        # Stop BACnet services
just docker-logs                        # View BACnet connector logs
just docker-shell                       # Get shell access to containers
just docker-clean all                   # Deep clean Docker resources

# ✅ LEGACY SUPPORT: Scripts delegate to justfile commands
./scripts/docker_bacnet.sh build        # Delegates to just docker-build
./scripts/docker_bacnet.sh start        # Delegates to just docker-start
./scripts/docker_bacnet.sh stop         # Delegates to just docker-stop
```

**Anti-Patterns to Avoid:**
```bash
# ❌ DON'T: Direct docker commands bypass helper script benefits
# docker-compose up -d
# docker-compose down
# docker exec -it occupancy-bacnet-connector bash
```

#### 2. BACnet Diagnostics & Communication Testing
Specialized diagnostic scripts in `scripts/diagnostics/` provide comprehensive BACnet operations testing:

```bash
# ✅ RECOMMENDED: Use diagnostic wrapper commands
just diagnostics_bacnet                              # Discover BACnet devices
./scripts/diagnostics/device-info.sh 337733         # Get detailed device information
./scripts/diagnostics/read-objects.sh 337733        # Read BACnet objects from device
./scripts/diagnostics/verify-bacnet-setup.sh        # Verify BACnet stack configuration

# ✅ ZONE DATA OPERATIONS: Specialized zone management
./scripts/diagnostics/list-all-zones.sh             # List all available zones
./scripts/diagnostics/count-all-zones.sh            # Count total zones
./scripts/diagnostics/count-object-types.sh         # Count BACnet object types
./scripts/diagnostics/show-filter-status.sh         # Check zone filtering status
```

**Anti-Patterns to Avoid:**
```bash
# ❌ DON'T: Direct BACnet client commands bypass error handling
# docker exec testing-bacnet-client bacwi
# docker exec testing-bacnet-client bacrp
```

#### 3. Container Script Architecture
Professional script organization with clear separation of concerns:

**Host Scripts** (`scripts/`):
- `docker_bacnet.sh` - Main Docker management (delegates to justfile)
- `diagnostics/` - Host-side diagnostic scripts for BACnet operations
- Error handling, logging, and user interface management

**Container Scripts** (`docker/testing/bacnet-client/scripts/`):
- Internal container operations and BACnet protocol handling
- Called automatically by host scripts
- **Should never be executed directly**

### Advanced BACnet Operations

#### Building and Environment Management
```bash
# ✅ PRIMARY: Comprehensive build operations
just docker-build                                    # Build all BACnet services
just docker-build occupancy-bacnet-connector         # Build specific service
just docker-build --no-cache                         # Force rebuild without cache
just docker-build --prod                             # Build for production deployment
just docker-start                                    # Start BACnet services
just docker-rebuild                                  # Build and restart in one command

# ✅ LEGACY: Script delegation maintains compatibility
./scripts/docker_bacnet.sh build                     # Same as just docker-build
./scripts/docker_bacnet.sh start                     # Same as just docker-start
./scripts/docker_bacnet.sh rebuild                   # Same as just docker-rebuild
```

#### Monitoring and Debugging
```bash
# ✅ PRIMARY: Comprehensive logging and debugging
just docker-logs                                     # View logs for main BACnet service
just docker-logs occupancy-bacnet-connector          # View logs for specific service
just docker-logs-snapshot                            # Get logs snapshot (automation-friendly)
just docker-status                                   # Show service status overview
just docker-shell                                    # Access shell in main service
just docker-shell occupancy-bacnet-connector         # Access shell in specific service
just docker-exec occupancy-bacnet-connector "ps aux" # Execute command in container

# ✅ LEGACY: Script delegation for compatibility
./scripts/docker_bacnet.sh logs occupancy-bacnet-connector
./scripts/docker_bacnet.sh logs-snapshot occupancy-bacnet-connector
./scripts/docker_bacnet.sh shell occupancy-bacnet-connector
```

#### BACnet Protocol Operations
```bash
# Device discovery and network validation
just diagnostics_bacnet

# Comprehensive device analysis
./scripts/diagnostics/device-info.sh 337733

# BACnet object enumeration and reading
./scripts/diagnostics/read-objects.sh 337733

# Environment and stack verification
./scripts/diagnostics/verify-bacnet-setup.sh

# Zone data management and filtering
./scripts/diagnostics/list-all-zones.sh
./scripts/diagnostics/show-filter-status.sh
```

### Professional Development Best Practices

#### 1. Always Use Helper Scripts Instead of Direct Commands
```bash
# ✅ CORRECT: Use helper scripts with error handling
./scripts/docker_bacnet.sh start

# ❌ INCORRECT: Direct docker commands bypass safety features
# docker-compose up -d
```

#### 2. Use Appropriate Scripts for Each Task
```bash
# ✅ CORRECT: Use BACnet diagnostic wrapper
just diagnostics_bacnet

# ❌ INCORRECT: Direct container execution bypasses error handling
# docker exec testing-bacnet-client verify-bacnet-setup.sh
```

#### 3. Leverage Automation-Friendly Commands
```bash
# ✅ FOR AUTOMATION/AI: Use snapshot commands for scripting
./scripts/docker_bacnet.sh logs-snapshot

# ✅ FOR INTERACTIVE USE: Use streaming commands for real-time monitoring
./scripts/docker_bacnet.sh logs
```

#### 4. Use Proper Verification and Validation Tools
```bash
# ✅ CORRECT: Use comprehensive diagnostic tools
just diagnostics_bacnet
./scripts/diagnostics/verify-bacnet-setup.sh

# ❌ INCORRECT: Manual BACnet property reads lack error handling
# Direct bacrp commands without wrapper scripts
```

### Troubleshooting Workflows

#### Container and Service Issues
```bash
# Check overall container status
./scripts/docker_bacnet.sh status

# View detailed service logs
./scripts/docker_bacnet.sh logs occupancy-bacnet-connector

# Verify BACnet stack configuration
just diagnostics_bacnet
```

#### BACnet Communication Problems
```bash
# Comprehensive BACnet network diagnosis
just diagnostics_bacnet

# Device-specific connectivity testing
./scripts/diagnostics/device-info.sh 337733

# Object-level communication verification
./scripts/diagnostics/read-objects.sh 337733
```

#### Persistent Issues Resolution
For issues requiring comprehensive troubleshooting:
1. **Environment Rebuild** - Use procedures in [BACnet Environment Rebuild](../backend/bacnet-environment-rebuild.md)
2. **Configuration Validation** - Check configuration files and environment variables
3. **Recent Changes Review** - Analyze recent code changes that might affect BACnet operations

### Migration to Justfile Architecture

#### Primary Command Benefits
The migration to justfile-based commands provides:
- **Single Source of Truth** - All commands defined consistently in justfile
- **Enhanced Functionality** - More options, better error handling, and comprehensive validation
- **Consistency** - Matches testing infrastructure and deployment commands
- **Muscle Memory Preservation** - Legacy scripts continue to work through delegation

#### Legacy Script Compatibility
All legacy scripts maintain full backward compatibility:
- `./scripts/docker_bacnet.sh` → delegates to `just docker-*` commands
- `./scripts/docker_build.sh` → delegates to `just docker-build`
- `./scripts/docker_run.sh` → delegates to `just docker-start`

#### Quick Reference for BACnet Operations
```bash
# Essential BACnet development commands
just docker-build --no-cache              # Force rebuild BACnet environment
just docker-start                         # Start BACnet services
just docker-logs                          # Monitor BACnet connector logs
just docker-shell                         # Access BACnet container shell
just docker-clean all                     # Deep clean BACnet environment
just diagnostics_bacnet                   # Verify BACnet communication

# View all available commands
just help
```

### Integration with Development Workflows

#### Daily Development Cycle
1. **Environment Startup** - `just docker-start` for reliable service initialization
2. **Development Iteration** - Use `just docker-logs` for real-time monitoring
3. **Testing Validation** - `just diagnostics_bacnet` for communication verification
4. **Environment Cleanup** - `just docker-stop` for clean shutdown

#### Task Completion Verification
- **Unit Changes** - `just docker-restart occupancy-bacnet-connector` for quick iteration
- **Integration Changes** - Full environment rebuild using [BACnet Environment Rebuild](../backend/bacnet-environment-rebuild.md)
- **Testing Requirements** - Comprehensive testing using [BACnet Testing Guide](../backend/bacnet-testing-guide.md)

---

## 🛠️ Development Tool Creation & Maintenance

### Adding New Development Tools

#### Professional Tool Development Standards
**Development Environment Requirements:**
- **Python 3.12+** with comprehensive type hints and mypy validation
- **Comprehensive Error Handling** with structured logging and user-friendly messages
- **Structured Logging** with timestamp, level, and context information
- **Timeout Protection** for all long-running operations
- **Cross-Platform Compatibility** tested on macOS, Linux, and Windows
- **Comprehensive Documentation** with usage examples and troubleshooting guides

#### Tool Integration Pattern
```bash
# 1. Create script in appropriate directory with proper structure
scripts/[category]/new_tool.py

# 2. Add justfile command wrapper for consistent interface
[category]_new_tool:
    python scripts/[category]/new_tool.py {{args}}

# 3. Update comprehensive documentation
docs_new/workflows/development-tools.md

# 4. Integrate with help system and discovery
just help  # Should include new command
```

### Quality Assurance & Testing

#### Unit Testing Strategy
```bash
# Test individual script components in isolation
pytest tests/scripts/ -v --tb=short

# Test with comprehensive output and coverage
pytest tests/scripts/ -v --tb=short --cov=scripts --cov-report=html

# Test specific tool categories
pytest tests/scripts/test_db_manager.py -v
pytest tests/scripts/test_workflow_manager.py -v
```

#### Integration Testing in Real Environments
```bash
# Test scripts in actual development environment
just test integration all

# Test specific workflow with validation
python scripts/helpers/workflow_manager.py setup --verbose

# Test database operations with real data
python scripts/helpers/db_manager.py validate --verbose
```

### Monitoring, Debugging & Observability

#### Comprehensive Verbose Mode
All development tools support detailed verbose mode for debugging and monitoring:
```bash
# Workflow manager with detailed logging
python scripts/helpers/workflow_manager.py setup --verbose

# Database manager with operation details
python scripts/helpers/db_manager.py backup --verbose

# Mobile configuration with network diagnostics
python scripts/dev/configure_mobile.py --verbose
```

#### Structured Log Analysis
Development tools use consistent structured logging for easy analysis and monitoring:
```
[14:32:15] 9 [workflow_manager] Starting setup workflow with 7 steps
[14:32:15] 9 [workflow_manager] Step 1/7: Environment prerequisite validation
[14:32:17]  [workflow_manager] env_check completed successfully (2.1s)
[14:32:17] L [workflow_manager] Step 2/7 failed: Connection timeout (30s)
[14:32:17] =' [workflow_manager] Retry attempt 1/3 for dependency_install
```

---

## <� Development Tool Usage Guidelines

### When to Use Development Tools vs Simple Commands

#### Use Professional Development Tools When:
- **Complex Multi-Step Logic** - Operations requiring conditionals, loops, and state management
- **Sophisticated Error Handling** - Operations requiring recovery procedures and retry logic
- **Cross-Platform Compatibility** - Code that must work reliably across macOS, Linux, Windows
- **State Management** - Operations requiring persistent state tracking and session management
- **Enterprise Features** - Timeout protection, progress tracking, comprehensive validation
- **Security Requirements** - Operations involving credentials, encryption, or secure protocols

#### Use Simple Justfile Commands When:
- **Direct Tool Access** - Simple, direct access to underlying development tools
- **Quick Diagnostic Actions** - Fast, lightweight operations for immediate feedback
- **Single Command Operations** - Simple commands with basic parameter passing
- **Debugging Tasks** - Quick diagnostic commands for troubleshooting

### Development Tool Best Practices

#### Professional Development Workflow
1. **Progressive Enhancement** - Start with simple justfile commands, evolve to sophisticated scripts when complexity demands it
2. **Safety-First Design** - Always include comprehensive safety checks, validation, and rollback capabilities
3. **User Experience Focus** - Provide clear feedback, progress indication, and helpful error messages
4. **Comprehensive Error Handling** - Anticipate failure modes and provide graceful recovery procedures
5. **Documentation Excellence** - Include detailed usage examples, troubleshooting guides, and best practices

#### Security & Reliability Standards
- **Credential Security** - Never store credentials in code; use AWS Secrets Manager and secure key management
- **Input Validation** - Comprehensive validation of all user inputs with sanitization
- **Resource Management** - Proper cleanup of temporary resources, connections, and processes
- **Audit Logging** - Detailed logging of all operations for security and troubleshooting
- **Error Recovery** - Graceful degradation and recovery procedures for all failure scenarios

---

## =� Related Development Documentation

### Platform-Specific Development Resources
> =� **Backend Teams**: See [Backend Development](../backend/development/) for backend-specific automation integration
> =� **Admin Teams**: See [Admin Development](../admin/development/) for dashboard development automation
> =� **Mobile Teams**: See [Mobile Development](../mobile/development/) for React Native development tools

### Workflow & Operations Documentation
- **[Development Setup](../setup/development-setup.md)** - Complete development environment configuration
- **[Testing Strategy](../workflows/testing-strategy.md)** - Testing automation and quality assurance workflows
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Production deployment automation and tooling

### Testing & Quality Assurance Tools
- **[Testing Strategy](../workflows/testing-strategy.md)** - Testing automation and quality assurance workflows
- **[E2E Testing Framework](../../tests/docs/README.md)** - Complete E2E testing documentation and Playwright tools ⭐
- **[Debugging Guide](../../tests/docs/debugging-guide.md)** - E2E test troubleshooting and Playwright debugging procedures

### Architecture & Requirements
- **[Architecture Requirements](../architecture/architecture-requirements.md)** - Infrastructure requirements for development tooling
- **[Product Overview](../product/product-overview.md)** - System overview and development tool integration context

---

**Status**:  **PRODUCTION-READY ENTERPRISE AUTOMATION**
**Last Updated**: 2025-06-29
**Tool Categories**: Environment Setup, Database Operations, Workflow Orchestration, Development Support
**Platform Coverage**: Cross-Platform (Backend, Admin, Mobile)

---

*These professional development tools transform Spacewalker from a collection of utilities into an integrated enterprise development platform with sophisticated automation, intelligent error handling, comprehensive security, and exceptional developer experience.*
