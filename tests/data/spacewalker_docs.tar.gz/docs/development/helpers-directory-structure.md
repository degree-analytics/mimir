# Helpers Directory Structure Guide

This guide documents the organization and purpose of the `scripts/helpers/` directory, which contains all justfile-integrated automation scripts.

## Overview

The helpers directory provides a centralized location for all scripts that are directly invoked by justfile commands. This organization ensures:
- Clear separation between justfile commands and their implementations
- Easy discovery of available automation tools
- Consistent naming patterns
- Modular, testable components

## Directory Structure

```
scripts/helpers/
├── actions/                 # GitHub Actions and CI/CD analysis tools
│   ├── ai_analyzer.py      # Claude-powered AI analysis for GitHub Actions
│   └── actions_command.sh  # Action router for GitHub Actions commands
│
├── pr/                      # PR analysis and management tools
│   ├── pr_analyzer.py      # Consolidated PR analyzer (fetch + analyze + format)
│   ├── pr_command.sh       # Action router for just gh-pr commands
│   ├── ai_analyzer.py      # Claude-powered AI analysis
│   ├── test_status.py      # CI/CD status checker
│   └── comment_manager.py  # Safe PR comment posting
│
├── ai_telemetry.py         # 🆕 Unified AI telemetry library for all AI tools
├── ai_telemetry_integration_example.py # 🆕 Copy-paste examples for monitoring teams
├── ai_client.py            # 🔄 Git-info AI integration with telemetry
├── deployment_manager.py   # Unified AWS deployment orchestration
├── health_checker.py       # Multi-environment health validation
├── service_manager.py      # Docker service lifecycle management
├── test_manager.py         # Unified test command router
├── lint_manager.py         # Multi-language linting orchestration
├── logs_manager.py         # Centralized log viewing
├── db_operations_wrapper.py # Database operations across environments
├── env_validator.py        # Environment prerequisite checking
├── url_manager.py          # Service URL discovery
├── bastion_manager.py      # SSH bastion access management
├── monitor_manager.py      # Monitoring and alerting operations
├── sm_manager.py           # AWS Secrets Manager operations
├── ecs_manager.py          # ECS service operations
├── stack_manager.py        # CloudFormation stack management
├── ecr_manager.py          # ECR repository management
├── s3_manager.py           # S3 bucket operations
├── version_manager.py      # Cross-service version management
├── claude_manager.py       # Claude.md context management
├── mcp_manager.py          # MCP server management
├── prod_manager.py         # Production mode safety controls
├── docs_manager.py         # Documentation validation
├── command_mapper.py       # Direct command to just command mapping
└── generate_help.py        # Dynamic justfile help generator
```

## AI Telemetry System (New)

### Unified Telemetry Architecture
The new AI telemetry system eliminates code duplication and provides standardized monitoring for all AI tools:

#### Key Components
- **`ai_telemetry.py`** - Unified telemetry library with context manager pattern
- **`ai_telemetry_integration_example.py`** - Copy-paste examples for monitoring teams
- **`ai_client.py`** - Git-info integration updated with telemetry tracking
- **`actions/ai_analyzer.py`** - GitHub Actions analyzer with telemetry

#### Architecture Benefits
- **75% code reduction** - From 836 duplicate lines to 210 unified lines
- **Session correlation** - All AI calls include session and user identification
- **Standardized integration** - 3-line pattern for any AI tool
- **Monitoring-ready** - Prometheus metrics sent to Pushgateway with identification

#### Integration Pattern
```python
from scripts.helpers.ai_telemetry import track_ai_call

with track_ai_call("tool-name", "operation-name") as tracker:
    # Your AI API call here
    result = api_call()
    tracker.tokens_used = extract_tokens(result)
    tracker.success = True
```

#### Removed Duplication
The telemetry refactor eliminated these duplicate session detectors:
- Documentation search tooling now lives in the shared `mimir-docsearch` package.
- `scripts/helpers/actions/claude_session_detector.py`
- `scripts/helpers/claude_session_detector.py`

## Design Principles

### 1. Single Responsibility
Each script does one thing well and can be tested independently.

### 2. Justfile Integration
Scripts are designed to be called from justfile commands with clear interfaces:
```bash
# Justfile command
pr action pr_number='' *args='':
    @bash scripts/helpers/pr/pr_command.sh "{{action}}" "{{pr_number}}" {{args}}

# Direct script usage (for testing)
python scripts/helpers/pr/pr_analyzer.py degree-analytics/spacewalker 290 --format=summary
```

### 3. Modular Architecture
Scripts can import and compose functionality from other helpers:
```python
# analyzer.py uses other modules
from .fetcher import PRComprehensiveFetcher
from .enhancer import PREnhancedAnalyzer
```

### 4. Consistent Naming
- Use descriptive names that match their justfile command
- Group related functionality in subdirectories
- Maintain `snake_case` for Python files

## Adding New Helpers

When creating new automation scripts:

1. **Determine Category**
   - Does it fit in an existing subdirectory?
   - Or does it need a new category?

2. **Create Script**
   ```python
   #!/usr/bin/env python3
   """
   Brief description of what this script does
   """
   import argparse
   # ... implementation
   ```

3. **Add Justfile Command**
   ```bash
   # New command description
   new_command arg1='default':
       python scripts/helpers/category/script_name.py {{arg1}}
   ```

4. **Document Usage**
   - Add help text in the script
   - Update this guide if adding new categories
   - Include examples in docstrings

## Testing Helpers

All helper scripts should be testable:

```bash
# Run script directly
python scripts/helpers/pr/analyzer.py --help

# Test with arguments
python scripts/helpers/pr/analyzer.py 290 --format=title

# Unit tests (if available)
pytest scripts/helpers/test_*.py
```

## PR Tools Deep Dive

The PR analysis tools demonstrate the helper pattern at its best:

### Consolidated Architecture
```
pr/
├── pr_analyzer.py      # Single entry point combining fetch + analyze + format
├── pr_command.sh       # Action-based router for consistent CLI interface
├── ai_analyzer.py      # Optional AI enhancement layer
├── test_status.py      # Specialized CI/CD status checking
└── comment_manager.py  # Safe PR commenting functionality
```

### Key Design Decisions

1. **Action-First Pattern**: `just gh-pr <action> <pr_number>`
   - Matches other justfile tools (aws, test, lint)
   - Enables quick access to specific data
   - Reduces cognitive load

2. **Single Analyzer**: `pr_analyzer.py` consolidates what was 7+ scripts
   - Parallel data fetching for efficiency
   - Multiple output formats (json, summary, commits, files, stats, timeline)
   - ~80% more data than previous implementation

3. **Direct Data Access**: Most actions bypass AI processing
   - Faster responses
   - Lower token usage
   - Predictable output format

### Usage Examples
```bash
# Different actions, same pattern
just gh-pr show 290        # Summary view
just gh-pr commits 290     # Detailed commit history
just gh-pr files 290       # File changes by directory
just gh-pr stats 290       # Comprehensive statistics
just gh-pr timeline 290    # Chronological events

# AI enhancement when needed
just git-info pr-review-issues 290 --analysis=summary         # Comprehensive AI-powered review
just git-info pr-review-issues 290 --analysis=actionable --since-last-push  # New items since last push
```

## Common Patterns

### Argument Parsing
```python
parser = argparse.ArgumentParser(description='Tool description')
parser.add_argument('required_arg', help='Required argument')
parser.add_argument('--optional', default='value', help='Optional flag')
```

### Environment Variables
```python
api_key = os.getenv('ANTHROPIC_API_KEY')
if not api_key:
    print("Error: ANTHROPIC_API_KEY not set")
    sys.exit(1)
```

### JSON Input/Output
```python
# Read from stdin
data = json.load(sys.stdin)

# Output to stdout
print(json.dumps(result, indent=2))
```

## Maintenance

### Archiving Old Scripts
When scripts become obsolete:
1. Move to `scripts/archived_*/` with clear naming
2. Remove corresponding justfile commands
3. Update documentation

### Version Control
- Keep scripts focused and under 500 lines
- Use modules for complex functionality
- Maintain backwards compatibility when possible

## Related Documentation

- [Justfile Workflow](../claude-components/justfile-workflow.md) - Justfile best practices
- [Project Structure](./project-structure.md) - Overall codebase organization
- [PR Analysis Guide](../workflows/pr-analysis-guide.md) - Using PR helper tools
