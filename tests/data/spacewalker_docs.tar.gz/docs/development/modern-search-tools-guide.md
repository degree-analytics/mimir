# Modern Search Tools Guide - SpaceWalker

Comprehensive guide to using ast-grep (sg) and ripgrep (rg) for effective code analysis in the SpaceWalker codebase.

## Tool Hierarchy & Decision Tree

### 🎯 When to Use Which Tool

```
┌─────────────────────────────────────────────────────┐
│                 SEARCH TOOL DECISION TREE            │
├─────────────────────────────────────────────────────┤
│ 🔍 What are you looking for?                        │
│                                                     │
│ ┌─ Code structure/patterns? ────────→ USE ast-grep (sg)
│ ├─ Text content/values? ───────────→ USE ripgrep (rg)  
│ └─ Filter command output? ─────────→ USE grep         │
└─────────────────────────────────────────────────────┘
```

### ⚠️ Critical Rule: ast-grep First for Code Analysis

**Always try `sg` first when analyzing code structure.** Only fall back to `rg` for content that `sg` cannot handle effectively.

---

## 🔧 ast-grep (sg) - Structural Code Analysis

### Core SpaceWalker Patterns

#### 1. API Endpoint Analysis
```bash
# Find all API calls with specific methods
sg --pattern 'api.get($_)' --lang typescript apps/admin/src/
sg --pattern 'api.post($_, $_)' --lang typescript apps/admin/src/
sg --pattern 'api.$method($_)' --lang typescript apps/admin/src/

# Find API endpoint definitions (FastAPI)
sg --pattern '@app.$method($_)' --lang python apps/backend/src/
sg --pattern '@router.$method($_)' --lang python apps/backend/src/

# Find problematic trailing slashes in API calls
sg --pattern 'api.$_("/$$$")' --lang typescript apps/
sg --pattern "api.$_('/$$$')" --lang typescript apps/
```

#### 2. React/TypeScript Patterns
```bash
# Find React hooks usage
sg --pattern 'useState($_)' --lang typescript apps/admin/src/
sg --pattern 'useEffect(() => { $$$ }, $_)' --lang typescript apps/admin/src/
sg --pattern 'const [$state, $setter] = useState($_)' --lang typescript

# Find component props interfaces
sg --pattern 'interface $_Props { $$$ }' --lang typescript apps/admin/src/
sg --pattern 'type $_Props = { $$$ }' --lang typescript apps/admin/src/

# Find specific components usage
sg --pattern '<$Component $$$>' --lang typescript apps/admin/src/
sg --pattern 'import { $_ } from "@/components/$_"' --lang typescript
```

#### 3. Authentication & Security Patterns
```bash
# Find current_user usage (should use get_current_tenant_id)
sg --pattern 'current_user.tenant_id' --lang python apps/backend/
sg --pattern '$_.current_user.tenant_id' --lang python apps/backend/

# Find proper RLS pattern usage
sg --pattern 'get_current_tenant_id($_)' --lang python apps/backend/
sg --pattern 'Depends(get_current_tenant_id)' --lang python apps/backend/

# Find JWT token handling
sg --pattern 'jwt.encode($_)' --lang python apps/backend/
sg --pattern 'jwt.decode($_)' --lang python apps/backend/
```

#### 4. Database & Migration Patterns
```bash
# Find SQLAlchemy model definitions
sg --pattern 'class $_(Base): $$$ ' --lang python apps/backend/
sg --pattern '__tablename__ = "$_"' --lang python apps/backend/

# Find Alembic migration operations
sg --pattern 'op.create_table($_)' --lang python apps/backend/migrations/
sg --pattern 'op.add_column($_)' --lang python apps/backend/migrations/

# Find query patterns that might need RLS
sg --pattern 'session.query($_)' --lang python apps/backend/
sg --pattern 'db.query($_)' --lang python apps/backend/
```

#### 5. Testing Patterns
```bash
# Find test function definitions
sg --pattern 'def test_$_($$$): $$$' --lang python
sg --pattern 'test("$_", $_)' --lang typescript
sg --pattern 'it("$_", $_)' --lang typescript

# Find fixture usage
sg --pattern '@pytest.fixture' --lang python
sg --pattern 'def $_($$$): $$$' --lang python apps/backend/tests/

# Find test assertions
sg --pattern 'assert $_' --lang python
sg --pattern 'expect($_).$_($_)' --lang typescript
```

#### 6. Error Handling Patterns
```bash
# Find exception handling
sg --pattern 'try: $$$ except $_: $$$' --lang python
sg --pattern 'raise $_($_)' --lang python

# Find error responses
sg --pattern 'HTTPException($_)' --lang python apps/backend/
sg --pattern 'status_code=403' --lang python apps/backend/

# Find logging patterns
sg --pattern 'logger.$_($_)' --lang python
sg --pattern 'console.$_($_)' --lang typescript
```

### Advanced ast-grep Usage

#### Custom Rule Patterns
```bash
# Multi-line pattern matching
sg --pattern $'function $_($$$) {\n$$$\nreturn $$$;\n}' --lang typescript

# Class method patterns
sg --pattern 'class $_ { $$$ $method($$$) { $$$ } $$$ }' --lang typescript

# Import analysis
sg --pattern 'from $module import $$$' --lang python
sg --pattern 'import { $$$ } from "$module"' --lang typescript
```

#### Security-Focused Patterns
```bash
# Find potential SQL injection points
sg --pattern 'f"SELECT * FROM {$_}"' --lang python
sg --pattern '"SELECT * FROM " + $_' --lang python

# Find hardcoded secrets (basic detection)
sg --pattern '"$secret"' --lang python | rg -i "password|key|token"
sg --pattern "'$secret'" --lang python | rg -i "password|key|token"
```

---

## 🚀 ripgrep (rg) - High-Performance Content Search

### SpaceWalker-Optimized Commands

#### 1. Documentation Search
```bash
# Find specific gotcha patterns
rg "trailing slash" docs/gotchas/ -n
rg "403.*forbidden" docs/ -i -A 3 -B 3
rg "authentication.*failure" docs/ -i

# Search for specific technologies/patterns
rg "FastAPI" docs/ --type md
rg "PostgreSQL\|postgres" docs/ -i
rg "Docker\|docker" docs/ --type md
```

#### 2. Configuration & Environment
```bash
# Find environment variables
rg "^[A-Z_]+=" .env* --type-not binary
rg "\$\{?[A-Z_]+\}?" --type yaml --type dockerfile

# Find specific configuration values
rg "database.*url" . -i --type yaml --type json
rg "jwt.*secret" . -i --glob "!.env*"
rg "api.*key" . -i --glob "!node_modules"
```

#### 3. Error Analysis & Debugging
```bash
# Find error messages and logging
rg "error|Error|ERROR" apps/backend/src/ --type py -n
rg "404|403|401|500" apps/ -n
rg "exception|Exception|EXCEPTION" --type py -A 2

# Find specific error patterns
rg "connection.*refused" logs/ -i
rg "timeout" apps/ --type py --type js -n
rg "authentication.*failed" . -i
```

#### 4. API & Network Patterns
```bash
# Find HTTP methods and status codes
rg "GET|POST|PUT|DELETE" apps/backend/ --type py -n
rg "status_code.*[0-9]{3}" apps/backend/ --type py
rg "fetch\(|axios\." apps/admin/src/ --type typescript

# Find URL patterns
rg "https?://[^\s'\"]*" . --type py --type js --type typescript
rg "localhost:[0-9]+" . -n
rg "api/[^'\"]*" . --type typescript --type py
```

#### 5. Database & Migration Search
```bash
# Find specific table or column references
rg "users" apps/backend/ --type py -w -n
rg "tenant_id" apps/backend/ --type py -n
rg "created_at|updated_at" . --type py -n

# Find migration-related content
rg "alembic" . --type py --type yaml -n
rg "revision.*=" apps/backend/migrations/ -A 1
rg "CREATE TABLE|ALTER TABLE" . -i -n
```

#### 6. Performance & Optimization
```bash
# Find potential performance issues
rg "SELECT \*" . --type py -n
rg "sleep\(|delay\(" . --type py --type js --type typescript
rg "for.*in.*range" apps/backend/ --type py -n

# Find caching patterns
rg "cache|Cache|CACHE" . --type py --type js -n
rg "redis|Redis" . --type py --type yaml
```

### Advanced ripgrep Usage

#### File Type Optimization
```bash
# Exclude common directories
rg "pattern" --glob "!node_modules" --glob "!.git" --glob "!dist"

# Include only specific file types
rg "pattern" --type py --type js --type typescript --type yaml

# Custom file type definitions
rg "pattern" --type-add 'config:*.{yaml,yml,json,toml}' --type config
```

#### Context and Formatting
```bash
# Show surrounding context
rg "error" apps/ -A 3 -B 3 -n  # 3 lines before/after with line numbers
rg "TODO" . -C 2 --type py     # 2 lines context around TODO comments

# JSON output for automation
rg "pattern" --json | jq '.data.lines.text'

# Count matches per file
rg "test" --count --sort-files apps/backend/
```

---

## 📋 Common SpaceWalker Analysis Workflows

### 1. Security Audit Workflow
```bash
# Step 1: Find authentication patterns
sg --pattern 'current_user.tenant_id' --lang python apps/backend/
sg --pattern 'Depends(get_current_user)' --lang python apps/backend/

# Step 2: Find API trailing slash issues
sg --pattern 'api.$_("/$$$")' --lang typescript apps/
rg "api.*/" apps/ --type typescript -n

# Step 3: Find hardcoded secrets
rg -i "password|key|secret|token" --type py --type js --glob "!*.env*" -n
```

### 2. API Analysis Workflow  
```bash
# Step 1: Map all API endpoints
sg --pattern '@router.$method("$path")' --lang python apps/backend/
sg --pattern 'api.$method($_)' --lang typescript apps/admin/

# Step 2: Find error handling
rg "HTTPException\|raise.*Exception" apps/backend/ --type py -n
sg --pattern 'catch ($e) { $$$ }' --lang typescript apps/

# Step 3: Validate request/response patterns
sg --pattern 'response_model=$_' --lang python apps/backend/
sg --pattern 'interface.*Response' --lang typescript apps/admin/
```

### 3. Database Migration Impact Analysis
```bash
# Step 1: Find affected models
table_name="users"  # Replace with actual table
sg --pattern "class $_(Base):" --lang python apps/backend/ | rg "$table_name" -i

# Step 2: Find all references to changed columns
column_name="tenant_id"  # Replace with actual column  
rg "$column_name" apps/backend/ --type py -n

# Step 3: Find related tests
sg --pattern 'def test_$_($$$): $$$' --lang python | rg "$table_name\|$column_name" -i
```

### 4. Component Refactoring Analysis
```bash
# Step 1: Find component definition
component_name="UserTable"  # Replace with actual component
sg --pattern "const $component_name = " --lang typescript apps/admin/

# Step 2: Find all usages  
sg --pattern "<$component_name $$$>" --lang typescript apps/admin/
rg "$component_name" apps/admin/src/ --type typescript -n

# Step 3: Find related types/interfaces
sg --pattern "interface ${component_name}Props" --lang typescript apps/admin/
sg --pattern "type ${component_name}Props" --lang typescript apps/admin/
```

---

## 🔍 Integration with SpaceWalker Workflows

### Documentation-First Workflow Integration
```bash
# Before implementing a fix, search for existing patterns
just docs search "authentication error" --format llm
sg --pattern 'HTTPException(status_code=403)' --lang python apps/backend/
rg "403.*forbidden" docs/ -i

# Document your findings
echo "Found existing auth error pattern in apps/backend/src/auth.py:42" >> .build/tmp/search-results.md
```

### Testing Integration
```bash
# Find existing test patterns before writing new tests
sg --pattern 'def test_auth$_($$$): $$$' --lang python apps/backend/tests/
rg "test.*authentication" apps/backend/tests/ --type py -n

# Find fixture patterns
sg --pattern '@pytest.fixture' --lang python apps/backend/tests/
rg "def.*fixture" apps/backend/tests/ --type py -n
```

### Code Review Integration
```bash
# Analyze PR changes for common issues
git diff --name-only | xargs sg --pattern 'current_user.tenant_id' --lang python
git diff --name-only | xargs rg "api.*/" --type typescript

# Check for proper error handling in changed files
git diff --name-only | xargs sg --pattern 'try: $$$ except: $$$' --lang python
```

---

## 📊 Performance Tips & Best Practices

### 1. ast-grep Performance
- **Use specific language flags**: `--lang typescript` is faster than auto-detection
- **Limit search scope**: Target specific directories rather than entire project
- **Use simpler patterns first**: Complex nested patterns are slower

### 2. ripgrep Performance  
- **Use file type filters**: `--type py` is faster than searching all files
- **Use glob patterns**: `--glob "apps/backend/*"` focuses the search
- **Exclude large directories**: `--glob "!node_modules"` saves time

### 3. Combined Workflow Optimization
```bash
# ✅ EFFICIENT - Narrow scope progressively
sg --pattern 'api.$_($_)' --lang typescript apps/admin/src/components/
rg "403" apps/backend/src/auth.py -n

# ❌ INEFFICIENT - Too broad scope  
sg --pattern 'api.$_($_)' .
rg "403" . -r
```

---

## 🚫 Common Anti-Patterns to Avoid

### DON'T: Use grep for code structure
```bash
# ❌ WRONG
grep -r "function" apps/admin/src/

# ✅ CORRECT  
sg --pattern 'function $_($_) { $$$ }' --lang typescript apps/admin/src/
```

### DON'T: Use complex regex when ast-grep can do it
```bash
# ❌ WRONG
rg "class\s+\w+.*:" --type py

# ✅ CORRECT
sg --pattern 'class $_: $$$' --lang python
```

### DON'T: Search without scoping
```bash
# ❌ WRONG - searches everything including node_modules
rg "useState" .

# ✅ CORRECT - targeted search
sg --pattern 'useState($_)' --lang typescript apps/admin/src/
```

---

## 🔧 Tool Integration with SpaceWalker

### Justfile Integration (Planned)
```bash
# Future planned commands
just code analyze pattern "api.get"     # Run sg with SpaceWalker patterns
just code search content "403 error"    # Run rg with optimized flags  
just code audit security                # Run security-focused sg/rg patterns
```

### IDE Integration Recommendations
- **VSCode**: Install ast-grep extension for syntax highlighting
- **Vim/Neovim**: Configure ast-grep and ripgrep for fuzzy finding
- **JetBrains**: Use ast-grep for structural search and replace

### CI/CD Integration (Planned)
```yaml
# Example GitHub Actions integration
- name: Security Pattern Analysis
  run: |
    sg --pattern 'current_user.tenant_id' --lang python apps/backend/ > /tmp/rls-violations.txt
    if [ -s /tmp/rls-violations.txt ]; then exit 1; fi
```

---

## 📚 Additional Resources

### Learning ast-grep
- **Official Documentation**: https://ast-grep.github.io/
- **Pattern Playground**: https://ast-grep.github.io/playground.html
- **Language Support**: TypeScript, Python, JavaScript, Rust, Go, Java, C++

### Learning ripgrep  
- **Official Repository**: https://github.com/BurntSushi/ripgrep
- **User Guide**: https://github.com/BurntSushi/ripgrep/blob/master/GUIDE.md
- **Regex Syntax**: https://docs.rs/regex/latest/regex/#syntax

### SpaceWalker-Specific Patterns
- **API Patterns**: See `docs/gotchas/api-trailing-slashes.md`
- **RLS Patterns**: See `docs/backend/security/rls-architecture-complete.md`  
- **Authentication**: See `docs/backend/authentication-api.md`

---

**Remember**: Always prioritize `sg` for code structure analysis, use `rg` for content search, and reserve `grep` only for command output processing.