# Docker Container Management Patterns

## Core Principle: Separation of Concerns

**Container lifecycle** and **operations within containers** are separate responsibilities with different commands.

## Container Lifecycle Commands

These commands manage Docker container state:

- `just service up all` - Start all services
- `just service down all` - Stop all services
- `just service up backend` - Start backend only
- `just service up mobile` - Start mobile only
- `just service up admin` - Start admin only

## Operation Commands

These commands perform work **assuming containers are running**:

- `just db_schema_reset` - Reset database schema
- `just db_demo` - Seed demo data
- `just test all backend_case` - Run specific test
- `just shell backend` - Open shell in container

### Fail Fast Pattern

Operations should check container health and **fail immediately** if containers aren't running:

```bash
# Good: Check and fail fast
if ! docker compose ps db | grep -i healthy > /dev/null; then
    echo "❌ Database container is not running!"
    echo "👉 Run 'just up' first, then retry"
    exit 1
fi
```

```bash
# Bad: Starting containers within operations
just up db backend  # DON'T DO THIS
```

## Allowed Exceptions

Only these command patterns may manage containers:

### 1. Lifecycle Commands (`*_start`, `*_fresh`)
Commands explicitly about "starting fresh":
- `fresh_start` - Fresh environment setup
- `backend_fresh` - Fresh backend development cycle
- `quick_start` - Quick start for development

### 2. CI Commands (`ci_*`)
CI controls full container lifecycle:
- `test integration all` - Integration testing with containers
- `test unit all` - Unit testing (no infrastructure needed)

### 3. Docker Commands (`docker_*`)
Commands explicitly about Docker management:
- `docker_rebuild` - Rebuild containers from scratch
- `docker_clean` - Clean Docker resources

### 4. Destructive Reset Commands
Commands that explicitly destroy and recreate:
- `db_reset` - **DESTRUCTIVE**: Stops containers, removes data, restarts
  - Use `db_schema_reset` instead for 99% of cases

## Common Anti-Patterns

❌ **Don't do this:**
```bash
# Operation that manages containers
db_operation:
    just up db backend  # Wrong!
    # ... do database work
```

✅ **Do this instead:**
```bash
# Operation assumes containers are running
db_operation:
    # Check containers are healthy
    if ! docker compose ps db | grep -i healthy > /dev/null; then
        echo "❌ Database not running! Run 'just up' first"
        exit 1
    fi
    # ... do database work
```

## Why This Matters

1. **Predictability**: Users control when containers start/stop
2. **Performance**: Avoid unnecessary container restarts
3. **Debugging**: Clear separation when container vs. application issues occur
4. **CI**: Different container management strategies for different environments

## Linting

Use `just lint check docker` to check for container management violations in justfile commands.
