# Development Reference Documentation

Development tooling, project structure, and meta-documentation for Spacewalker development.

## Purpose
Reference documentation for development tools, project organization, and documentation standards. Essential resource for understanding development workflows, project structure, and maintaining documentation quality.

## When to Use This
- Understanding monorepo organization and project structure
- Setting up development tools and IDE configurations
- Maintaining documentation standards and navigation patterns
- Developer tooling setup and optimization

**Keywords:** development tools, project structure, documentation standards, developer reference

---

## Contents

### Project Organization
- **[Project Structure](../development/project-structure.md)** - Monorepo organization, component relationships, and conventions ⭐

### Development Tooling
- **[Development Tools](../development/development-tools.md)** - IDE setup, debugging, profiling, and development optimization ⭐

### Documentation & Standards
- **[Documentation Navigation Patterns](./documentation-navigation-patterns.md)** - Documentation organization principles and best practices
- **[TaskMaster Commands](/tm/help)** - AI-powered project management and task breakdown with Claude Code

---

## Development Environment Overview

### Monorepo Structure
```
spacewalker/
├── apps/
│   ├── backend/     # FastAPI backend service
│   ├── admin/       # Next.js admin dashboard
│   └── mobile/      # React Native (Expo) mobile app
├── packages/
│   └── shared-types/ # Shared TypeScript definitions
├── docs/            # Comprehensive documentation
├── justfile         # Development command definitions
└── package.json     # Root package configuration
```

### Key Development Tools
- **Command Runner:** `just` - Unified command interface
- **Package Manager:** `pnpm` - Efficient dependency management
- **Python Tooling:** `uv` - Fast Python package management
- **Containerization:** Docker - Development and deployment
- **Version Control:** Git with Graphite (`gt`) - Stack-based workflows

---

## Quick Reference

### Daily Development Commands
```bash
# Essential workflow
just up              # Start development environment
just dev_cycle       # Run tests and linting
just health          # Check system status
just down            # Stop development environment

# Application-specific
just backend         # Backend development server
just admin           # Admin dashboard development
just expo start --offline  # Mobile app development (Expo)

# Database operations
just db shell      # Database access
just db_backup       # Create database backup
```

### Code Quality Tools
```bash
# Linting and formatting
just lint            # Auto-fix all linting issues
just lint check all      # Read-only linting validation

# Testing workflows
just test unit all       # Fast unit tests
just test integration all # Integration tests with services
```

---

## Development Best Practices

### Project Organization
- **Shared Dependencies:** Common packages at root level
- **App-Specific Code:** Isolated in respective app directories
- **Shared Types:** TypeScript definitions for cross-app consistency
- **Documentation:** Organized by role and use case

### Development Workflow
- **Stack-Based Git:** Use `gt` for branch management
- **Atomic Commits:** One logical change per commit
- **Quality Gates:** Automated linting and testing
- **Documentation:** Keep docs current with code changes

### Tool Configuration
- **IDE Setup:** Consistent configuration across team
- **Linting Rules:** Unified code style enforcement
- **Testing Strategy:** Comprehensive coverage across platforms
- **Development Scripts:** Standardized via `justfile`

---

## Related Documentation

### Setup & Configuration
- **[Development Setup](../setup/development-setup.md)** - Complete environment configuration
- **[Environment Configuration](../setup/environment-configuration.md)** - Advanced environment settings

### Operational Workflows
- **[Git Workflows](../workflows/git-commit-standards.md)** - Commit standards and branching strategies
- **[Graphite Workflows](../workflows/graphite-workflows.md)** - Stack-based development with GT CLI
- **[Testing Guide](../workflows/testing-guide.md)** - Quality assurance workflows
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment procedures

### Component Development
- **[Backend Development](../backend/development/)** - FastAPI development patterns
- **[Mobile Development](../mobile/development/)** - React Native development workflows
- **[Admin Development](../admin/development/)** - Next.js dashboard development

### Architecture Context
- **[System Architecture](../architecture/)** - Technical architecture overview
- **[Component Architecture](../architecture/component-diagrams.md)** - Component relationships

---

**Last Updated:** 2025-06-29
**Status:** Current - Reorganized from workflows directory with enhanced developer focus
