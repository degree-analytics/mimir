# Git Info System

**Status**: Active
**Version**: 1.0.0
**Last Updated**: 2024-01-31

## Overview

The Git Info System is an AI-powered tool that generates high-quality git commit messages, PR titles, descriptions, and reviews using Anthropic's Claude API. It replaces multiple deprecated PR analysis scripts with a unified interface.

## Features

- **Commit Messages**: Analyzes staged changes and generates conventional commit messages
- **PR Titles**: Creates concise, descriptive PR titles following project conventions
- **PR Descriptions**: Generates comprehensive PR descriptions with code examples
- **PR Reviews**: Provides detailed PR analysis with timeline awareness

## Usage

### Basic Commands

```bash
# Generate commit message from staged changes
just git-info commit

# Generate PR title
just git-info pr-title 330

# Generate PR description
just git-info pr-desc 330

# Generate comprehensive PR review (summary)
just git-info pr-review-issues 330 --analysis=summary

# Actionable, time-aware review
just git-info pr-review-issues 330 --analysis=actionable --since-last-push
```

### Options

```bash
# Use different AI model (default: sonnet)
just git-info pr-desc 330 --model=opus    # Highest quality
just git-info pr-desc 330 --model=haiku   # Fast and efficient

# Save output to file
just git-info pr-desc 330 --output=description.md

# Get JSON output
just git-info pr-desc 330 --format=json
```

## Architecture

### Components

1. **git_info_manager.py**: Main orchestrator that coordinates all operations
2. **context_collector.py**: Gathers git/PR context with security validation
3. **timeline_analyzer.py**: Analyzes PR timeline for temporal awareness
4. **ai_client.py**: Handles Anthropic API interactions
5. **git_info_prompts.py**: Contains optimized prompts for each operation

### Data Flow

```
User Command → Git Info Manager → Context Collector → AI Client → Response
                                ↘ Timeline Analyzer ↗
```

## Key Improvements (2024-01-31)

1. **Executive Summary First**: All outputs start with 2-3 sentence summary
2. **Code Examples**: Shows actual before/after code snippets
3. **Prioritized Information**: Most important changes listed first
4. **Reduced Emojis**: Professional output with minimal emoji usage
5. **File Metrics**: Every output shows files changed and line counts

## Security Features

- Input validation for PR numbers and repository names
- Command injection prevention
- Secure subprocess execution
- API key validation

## Configuration

### Required Environment Variables

```bash
# Anthropic API key (required)
export ANTHROPIC_API_KEY='your-api-key'

# GitHub repository (optional, defaults to degree-analytics/spacewalker)
export GH_REPO='owner/repo'
```

### Model Selection

- **sonnet** (default): Best balance of quality and speed
- **opus**: Highest quality, use for complex PRs
- **haiku**: Fast and efficient, good for simple changes

## Examples

### Commit Message Generation

```bash
$ just git-info commit
fix(auth): resolve token refresh race condition

- Add mutex lock to prevent concurrent refresh attempts
- Return cached token if refresh is already in progress
- Add tests for concurrent refresh scenarios

Fixes #245
```

### PR Description Generation

```bash
$ just git-info pr-desc 330
**15 files changed: +1,007 -368 lines**

This PR implements a comprehensive automated migration safety system that executes database migrations within ECS tasks...

## Key Changes

### 1. ECS-Based Migration Safety System
- **What**: Added remote migration execution via ECS
- **Why**: Ensures production-level safety
- **Code Example**:
```bash
# Before: Manual migration checks
# After: Automatic validation blocks deployments
just migrations validate dev
```
...
```

## Troubleshooting

### API Key Not Found
```bash
❌ Error: ANTHROPIC_API_KEY not set in environment
```
**Solution**: Add to your `.env` file or export the variable

### PR Not Found
```bash
❌ Error: Could not fetch PR data
```
**Solution**: Ensure you have `gh` CLI authenticated and PR exists

### Token Limit Exceeded
The system automatically truncates data to fit within model context windows.

## Integration with Other Tools

- **TaskMaster**: Can be used to track PR review tasks
- **Claude Commands**: `/commit` command uses this system
- **CI/CD**: Integrated into PR workflows for automated descriptions

## Related Documentation

- [Git Commit Standards](../workflows/git-commit-standards.md)
- [PR Analysis Guide](../workflows/pr-analysis-guide.md)
- [System Architecture](../architecture/system-architecture.md)
