# Adding Custom Lints to lint

This guide explains how to add custom validation scripts that integrate with the unified `lint` command.

## Overview

The `lint` system automatically discovers and runs validation scripts that follow the `validate_*.py` naming convention. This allows you to add project-specific linting rules beyond what standard tools like Ruff, ESLint, or shellcheck provide.

## Quick Start

1. Create a Python script in the `scripts/` directory with the name `validate_<your_validator>.py`
2. Make it executable: `chmod +x scripts/validate_<your_validator>.py`
3. Run it with: `just lint check all`

## Validator Script Structure

Here's a minimal template for a custom validator:

```python
#!/usr/bin/env python3
"""
Brief description of what this validator checks.
"""

import sys
from pathlib import Path

# ANSI color codes for consistent output
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'

def print_error(msg: str) -> None:
    """Print error message in red."""
    print(f"{Colors.RED}❌ {msg}{Colors.END}")

def print_warning(msg: str) -> None:
    """Print warning message in yellow."""
    print(f"{Colors.YELLOW}⚠️  {msg}{Colors.END}")

def print_success(msg: str) -> None:
    """Print success message in green."""
    print(f"{Colors.GREEN}✅ {msg}{Colors.END}")

def main():
    """Main validation logic."""
    errors = []
    warnings = []

    # Your validation logic here
    # Collect errors and warnings

    # Report results
    if warnings:
        for warning in warnings:
            print_warning(warning)

    if errors:
        for error in errors:
            print_error(error)
        return 1  # Non-zero exit code for errors

    print_success("Validation passed!")
    return 0

if __name__ == "__main__":
    sys.exit(main())
```

## Exit Codes

Your validator should follow these conventions:
- **0**: All checks passed
- **1**: Validation errors found
- **2+**: Script execution errors

The `lint` system treats any non-zero exit code as a failure.

## Best Practices

### 1. Clear Output

Use colored output and emojis for better readability:
- ✅ Success messages in green
- ⚠️  Warnings in yellow
- ❌ Errors in red

### 2. Descriptive Names

Choose validator names that clearly indicate what they check:
- ✅ `validate_cf_consistency.py` - Validates CloudFormation template consistency
- ✅ `validate_links.py` - Validates documentation links and script references
- ❌ `validate_stuff.py` - Too vague

### 3. Performance

Keep validators fast:
- Cache results when possible
- Skip unnecessary file reads
- Use early exits for common cases

### 4. Error Reporting

Provide actionable error messages:
```python
# Bad
print_error("Invalid configuration")

# Good
print_error(f"docker-compose.yml:12: POSTGRES_USER should be 'spacewalker_user', found 'postgres'")
```

### 5. Respect CI Environment

Check for CI-specific flags:
```python
# Skip file generation in CI
if "--no-report" in sys.argv:
    skip_report_generation = True
```

## Examples

### CloudFormation Consistency Validator

Ensures CloudFormation templates match actual configuration:

```python
# scripts/validate_cf_consistency.py
# Checks: SAM templates match docker-compose services
# Validates: Environment variables are consistent
# Warns: About missing or extra configurations
```

### Link Validator

Validates links in documentation:

```python
# scripts/validate_links.py
# Checks: All links in markdown files are valid
# Validates: Internal file references exist
# Reports: Broken links and missing files
```

> **Note**: The database configuration validator and environment variable validator examples have been removed as they are no longer part of the codebase. Create similar validators following the patterns shown above.

## Integration with CI/CD

All validators in `scripts/validate_*.py` automatically run in CI when:
- Pull requests are created
- Code is pushed to main/dev branches
- `just lint check all` is executed

## Testing Your Validator

1. **Test locally first:**
   ```bash
   python scripts/validate_my_feature.py
   ```

2. **Test with lint:**
   ```bash
   just lint check all
   ```

3. **Test specific output:**
   ```bash
   just lint check all | grep "My Feature"
   ```

## Debugging

If your validator isn't being picked up:

1. Check the filename matches `validate_*.py`
2. Ensure the script is executable
3. Verify it's in the `scripts/` directory
4. Check for Python syntax errors
5. Run directly to see errors: `python scripts/validate_*.py`

## Advanced Features

### Processing Specific File Types

```python
def find_files(pattern: str) -> List[Path]:
    """Find all files matching a pattern."""
    project_root = Path(__file__).parent.parent
    return list(project_root.rglob(pattern))

# Example: Check all YAML files
for yaml_file in find_files("*.yml"):
    validate_yaml(yaml_file)
```

### Parallel Processing

For expensive checks, consider using multiprocessing:

```python
from concurrent.futures import ProcessPoolExecutor

def validate_file(filepath: Path) -> List[str]:
    """Validate a single file."""
    errors = []
    # Validation logic
    return errors

# Process files in parallel
with ProcessPoolExecutor() as executor:
    all_errors = []
    futures = [executor.submit(validate_file, f) for f in files]
    for future in futures:
        all_errors.extend(future.result())
```

### Configuration Support

Allow configuration via environment variables:

```python
# Respect verbosity settings
verbose = os.getenv("LINT_VERBOSE", "").lower() == "true"

# Skip in certain environments
if os.getenv("SKIP_CUSTOM_LINTS"):
    sys.exit(0)
```

## Common Patterns

### File Content Validation

```python
def check_file_content(filepath: Path, required_text: str) -> bool:
    """Check if file contains required text."""
    try:
        content = filepath.read_text()
        return required_text in content
    except Exception as e:
        print_warning(f"Could not read {filepath}: {e}")
        return False
```

### Configuration Consistency

```python
def check_config_consistency(configs: Dict[str, str]) -> List[str]:
    """Check that all configs have the same value."""
    errors = []
    values = list(configs.values())
    if len(set(values)) > 1:
        for file, value in configs.items():
            errors.append(f"{file}: Found '{value}', expected '{values[0]}'")
    return errors
```

### Pattern Matching

```python
import re

def find_pattern_violations(content: str, pattern: str) -> List[int]:
    """Find lines that don't match pattern."""
    violations = []
    for line_num, line in enumerate(content.splitlines(), 1):
        if not re.match(pattern, line):
            violations.append(line_num)
    return violations
```

## Removing Old Validators

When migrating from old linting commands:

1. Move the script to follow naming convention
2. Update any documentation references
3. Remove old justfile commands
4. Update CI/CD pipelines to use `lint check all`

## Need Help?

- Check existing validators in `scripts/validate_*.py` for examples
- Run `just lint help` for usage information
- See `scripts/helpers/lint_manager.py` for the discovery mechanism
