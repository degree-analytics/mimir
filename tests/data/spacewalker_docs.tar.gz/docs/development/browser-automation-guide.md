# 🌐 Browser Automation Guide

**Purpose**: Standardized approach for browser automation during development, testing, and verification
**Updated**: 2025-09-24
**Priority**: Chrome DevTools MCP → Playwright MCP → Manual

---

## 📊 Browser Automation Priority Hierarchy

### 1. Chrome DevTools MCP (PRIMARY)
**Use for**: Interactive development, visual verification, debugging
**Best when**: You need real-time browser control and visual feedback

```bash
# Navigate to pages
mcp__chrome-devtools__navigate_page --url="https://admin.spacewalker.littleponies.com"

# Take screenshots for verification
mcp__chrome-devtools__take_screenshot

# Get page structure/DOM
mcp__chrome-devtools__take_snapshot

# Interact with elements
mcp__chrome-devtools__click --uid="submit-button"
mcp__chrome-devtools__fill --uid="email-field" --value="test@example.com"
```

### 2. Playwright MCP (SECONDARY)
**Use for**: Automated test execution, complex scenarios, CI/CD
**Best when**: Chrome DevTools unavailable or insufficient

```bash
# Navigate and interact
mcp__playwright__browser_navigate
mcp__playwright__browser_click
mcp__playwright__browser_type

# Take screenshots
mcp__playwright__browser_take_screenshot
```

### 3. Manual Browser Verification (FALLBACK)
**Use for**: Complex interactions neither MCP can handle
**Best when**: Both MCP tools unavailable or experiencing issues

```bash
# Traditional approaches
npx playwright test --headed
# Direct browser: localhost:3000 or https://admin.spacewalker.littleponies.com
```

---

## 🎯 Common Use Cases

### Visual Layout Verification
```bash
# PREFERRED APPROACH
# 1. Navigate to the page
mcp__chrome-devtools__navigate_page --url="https://admin.spacewalker.littleponies.com/surveys"

# 2. Take screenshot for verification
mcp__chrome-devtools__take_screenshot

# 3. Get DOM structure if needed
mcp__chrome-devtools__take_snapshot

# FALLBACK if chrome-devtools unavailable
mcp__playwright__browser_navigate
mcp__playwright__browser_take_screenshot
```

### Form Testing
```bash
# PREFERRED: Chrome DevTools
mcp__chrome-devtools__navigate_page --url="/login"
mcp__chrome-devtools__fill --uid="email" --value="admin@demo.university.edu"
mcp__chrome-devtools__fill --uid="password" --value="admin123"
mcp__chrome-devtools__click --uid="submit-button"
mcp__chrome-devtools__take_screenshot  # Verify success

# FALLBACK: Playwright
mcp__playwright__browser_type --text="admin@demo.university.edu"
mcp__playwright__browser_click --selector="button[type='submit']"
```

### Responsive Design Testing
```bash
# Chrome DevTools approach
mcp__chrome-devtools__resize_page --width=375 --height=667  # Mobile
mcp__chrome-devtools__take_screenshot

mcp__chrome-devtools__resize_page --width=768 --height=1024  # Tablet
mcp__chrome-devtools__take_screenshot

mcp__chrome-devtools__resize_page --width=1920 --height=1080  # Desktop
mcp__chrome-devtools__take_screenshot
```

---

## 🔧 Tool-Specific Features

### Chrome DevTools MCP Advantages
- **Real Chrome browser** - Actual rendering engine
- **Visual screenshots** - Immediate visual feedback
- **DOM snapshots** - Text-based page structure
- **Network inspection** - Monitor API calls
- **Performance profiling** - Identify bottlenecks
- **Direct element interaction** - Click, type, drag
- **Multiple pages/tabs** - Test multi-window scenarios

### Playwright MCP Advantages
- **Cross-browser support** - Chrome, Firefox, Safari
- **Headless mode** - Faster for automated tests
- **Advanced selectors** - Complex element targeting
- **Network mocking** - Simulate API responses
- **Mobile emulation** - Device-specific testing
- **Video recording** - Capture test execution
- **Parallel execution** - Run multiple tests simultaneously

---

## 🚨 Important Considerations

### When to Use Each Tool

**Chrome DevTools MCP**:
✅ Layout/visual verification
✅ Interactive debugging
✅ Real-time development feedback
✅ Screenshot-based verification
✅ Single-page focused testing

**Playwright MCP**:
✅ E2E test automation
✅ Cross-browser testing
✅ CI/CD pipeline integration
✅ Complex test scenarios
✅ Performance testing

**Manual Browser**:
✅ User experience validation
✅ Complex multi-step workflows
✅ When both MCPs fail
✅ Exploratory testing

### Configuration Requirements

**Chrome DevTools MCP**:
- Requires Chrome browser installed
- Node.js ≥22.12.0
- May need `--isolated` or `--headless` flags

**Playwright MCP**:
- Installs browsers automatically
- Works with any Node.js version
- Better for CI/CD environments

---

## 📝 Best Practices

### 1. Always Verify Visual Changes
```bash
# After any UI change
mcp__chrome-devtools__navigate_page --url="/changed-page"
mcp__chrome-devtools__take_screenshot
# Describe what you see in the screenshot
```

### 2. Use Appropriate Timeouts
```bash
# Chrome DevTools - wait for elements
mcp__chrome-devtools__wait_for --text="Survey loaded"

# Playwright - explicit waits
mcp__playwright__browser_wait_for --selector=".survey-item"
```

### 3. Handle Authentication
```bash
# Set up authentication once
mcp__chrome-devtools__navigate_page --url="/login"
mcp__chrome-devtools__fill --uid="email" --value="admin@demo.university.edu"
mcp__chrome-devtools__fill --uid="password" --value="admin123"
mcp__chrome-devtools__click --uid="submit"

# Verify login success
mcp__chrome-devtools__wait_for --text="Dashboard"
```

### 4. Clean Up Resources
```bash
# Close pages when done
mcp__chrome-devtools__close_page
mcp__playwright__browser_close
```

---

## 🔍 Troubleshooting

### Chrome DevTools Issues
```bash
# If chrome-devtools fails to start
# 1. Check Chrome is installed
# 2. Check Node version: node --version (needs ≥22.12.0)
# 3. Try with --isolated flag
# 4. Fall back to Playwright MCP
```

### Playwright Issues
```bash
# If playwright fails
# 1. Check browser installation: npx playwright install
# 2. Try different browser: --browser=firefox
# 3. Use headed mode for debugging: --headed
# 4. Fall back to manual testing
```

### General Issues
- **Timing problems**: Add explicit waits
- **Element not found**: Use multiple selector strategies
- **Screenshots blank**: Wait for page load
- **Authentication lost**: Re-authenticate between tests

---

## 📚 Related Documentation

- [Verification Standards](../claude-components/verification-standards.md)
- [Admin UI Testing](/docs/admin/CLAUDE.md)
- [Playwright Testing Gotchas](../gotchas/playwright-testing-gotchas.md)
- [Testing Guide](../workflows/testing-guide.md)

---

**Remember**: Chrome DevTools MCP is preferred for development and visual verification. Playwright MCP is better for automated testing. Choose the right tool for your specific needs.
