# Project Structure Reference

## Purpose
Comprehensive overview of the Spacewalker monorepo structure, directory organization, package relationships, and build dependencies to help developers navigate and understand the codebase effectively.

## When to Use This
- Understanding the overall project organization and architecture
- Navigating the monorepo and finding specific components
- Onboarding new developers to the codebase structure
- Planning changes that affect multiple applications or packages
- Keywords: project structure, monorepo, directory organization, architecture overview

**Version:** 2.0 (Updated for new documentation structure)
**Date:** 2025-06-29
**Status:** Current - Foundational Reference

---

## Quick Navigation

### For New Developers
- **[Getting Started Guide](../setup/getting-started.md)** - Complete setup and first build
- **[Environment Configuration](../setup/environment-setup.md)** - Variable setup and troubleshooting
- **[Development Workflows](./README.md)** - Main system overview

### Application-Specific Documentation
- **[Backend Development](../backend/development/README.md)** - FastAPI application development
- **[Admin Architecture](../admin/architecture/README.md)** - Next.js dashboard architecture
- **[Mobile Development](../mobile/development/README.md)** - React Native app development

---

## Top-Level Directory Structure

```
.
├── apps/                    # Primary deployable applications
│   ├── admin/              # Next.js admin dashboard
│   ├── backend/            # FastAPI Python API
│   └── mobile/             # React Native (Expo) mobile app
├── docs/                   # Legacy documentation (being reorganized)
├── docs_new/               # Reorganized documentation structure
│   ├── backend/            # Backend-specific documentation
│   ├── admin/              # Admin dashboard documentation
│   ├── mobile/             # Mobile app documentation
│   ├── workflows/          # System-wide processes and guides
│   └── gotchas/            # Common issues and troubleshooting
├── packages/               # Shared code and components
│   ├── shared-types/       # TypeScript interfaces and types
│   └── ui/                 # Shared React components (planned)
├── scripts/                # Helper scripts and utilities
├── sam/                    # AWS SAM deployment configurations
├── working-memory/         # Development notes and temporary files
├── .build/                 # Build artifacts and container volumes
├── .github/                # GitHub Actions CI/CD workflows
├── .vscode/                # VS Code workspace configuration
├── docker/                 # Docker and docker-compose files
├── justfile                # Command runner recipes
├── package.json            # Root package configuration
├── pnpm-lock.yaml          # Package lockfile
└── pnpm-workspace.yaml     # Workspace configuration
```

---

## Application Directories

### `apps/` - Primary Applications

This directory contains the three main, deployable applications of the Spacewalker system:

#### `admin/` - Administrative Dashboard
- **Technology**: Next.js 15 with TypeScript and React
- **Purpose**: Web application for data review, management, and reporting
- **Users**: Administrators, managers, and data reviewers
- **Key Features**: Survey data review, user management, reporting and exports
- **Documentation**: [Admin Architecture Guide](../admin/architecture/README.md)

#### `backend/` - Core API Service
- **Technology**: FastAPI with Python 3.11+, SQLAlchemy, PostgreSQL
- **Purpose**: Core API, authentication, business logic, and data processing
- **Users**: All client applications (admin dashboard, mobile app)
- **Key Features**: REST API, authentication, AI processing, data validation
- **Documentation**: [Backend Development Guide](../backend/development/README.md)

#### `mobile/` - Field Survey Application
- **Technology**: React Native with Expo SDK 52 and TypeScript
- **Purpose**: Mobile app for field surveyors to collect room data and photos
- **Users**: Field surveyors and data collection teams
- **Key Features**: Offline-first data collection, photo capture, sync capabilities
- **Documentation**: [Mobile Development Guide](../mobile/development/README.md)

---

## Shared Code

### `packages/` - Shared Libraries

This directory contains shared code, types, and components used across multiple applications:

#### `shared-types/` - TypeScript Definitions
- **Purpose**: Shared TypeScript interfaces and types for API contracts
- **Used By**: All applications (backend, admin, mobile)
- **Key Contents**: API request/response types, database models, common interfaces
- **Dependencies**: None (foundational package)

#### `ui/` - Shared React Components (Planned)
- **Purpose**: Reusable React components for admin dashboard and mobile app
- **Used By**: Admin dashboard and mobile app
- **Status**: Planned for future implementation
- **Target Components**: Form components, data displays, common UI elements

---

## Documentation Structure

### `docs_new/` - Reorganized Documentation

The new documentation structure organizes content by application and concern:

#### Application-Specific Documentation
- **`backend/`** - FastAPI service documentation, API design, database schemas
- **`admin/`** - Dashboard architecture, component structure, deployment
- **`mobile/`** - React Native app architecture, offline strategies, platform specifics

#### Cross-System Documentation
- **`workflows/`** - System-wide processes, getting started guides, deployment workflows
- **`gotchas/`** - Common issues, troubleshooting guides, known problems and solutions

#### Legacy Documentation
- **`docs/`** - Original documentation structure (being phased out)

---

## Support Directories

### Development and Infrastructure

#### `scripts/` - Development Utilities
- **Purpose**: Helper scripts for database management, backups, infrastructure setup
- **Key Scripts**: Database operations, backup utilities, development automation
- **Usage**: Called by justfile recipes or run directly for maintenance

#### `sam/` - AWS Deployment
- **Purpose**: AWS SAM (Serverless Application Model) deployment configurations
- **Contents**: CloudFormation templates, deployment scripts, infrastructure as code
- **Target**: Production and staging AWS environment deployments

#### `working-memory/` - Development Notes
- **Purpose**: Development notes, temporary files, work-in-progress documentation
- **Contents**: Investigation notes, planning documents, temporary analysis
- **Status**: Not included in production builds, development-only

### Build and Configuration

#### `.build/` - Build Artifacts
- **Purpose**: Git-ignored directory for build artifacts, container volumes, generated files
- **Benefits**: Keeps main project directories clean and organized
- **Contents**: Docker volumes, compiled assets, temporary build files

#### `.github/` - CI/CD Configuration
- **Purpose**: GitHub-specific files for automated workflows
- **Key Files**: GitHub Actions workflows for testing, building, and deployment
- **Triggers**: Pull requests, merges to main, release tags

#### `docker/` - Container Configuration
- **Purpose**: Docker-related files for development and production environments
- **Key Files**: `docker-compose.yml` for orchestrating multi-service development
- **Environments**: Development, testing, and production container configurations

---

## Package Relationships & Build Dependencies

The applications have the following dependency relationships:

### Dependency Graph
```
shared-types (foundational)
    ↑
    ├── backend (depends on shared-types)
    ├── admin (depends on shared-types, connects to backend)
    └── mobile (depends on shared-types, connects to backend)
```

### Build Order
1. **`shared-types`** - Foundational package with no internal dependencies
2. **`backend`** - Depends on `shared-types` for API contract alignment
3. **`admin` & `mobile`** - Both depend on `shared-types` for typing and `backend` for runtime API access

### Runtime Dependencies
- **Backend** must be healthy before frontend applications can connect
- **Database** (PostgreSQL) must be available before backend can start
- **Redis** cache is optional but recommended for performance
- **Frontend applications** can start independently but require backend for functionality

---

## Configuration Management

### Application Configuration
- **Individual Apps**: Each application in `apps/` manages its own configuration
- **Shared Config**: Common settings managed through environment variables
- **Local Development**: Centralized `.env` file at project root

### Environment Variables
- **Root `.env`**: Provides environment variables to all services via Docker Compose
- **Application-Specific**: Apps can override or extend root configuration
- **Documentation**: [Environment Configuration Guide](../setup/environment-setup.md)

### Development Tooling
Configuration for development tools is distributed based on scope:
- **Root Level**: Project-wide tools (`ESLint`, `Prettier`, `pnpm` workspace)
- **Application Level**: App-specific tools (`pytest`, `ruff`, app-specific linting)
- **Justfile**: Centralized command interface for all development operations

---

## Command Interface

### `justfile` - Development Commands
The `justfile` serves as the centralized command interface for all development operations:

```bash
# Common development commands
just up          # Start all services
just down        # Stop all services
just test        # Run all tests
just lint        # Run all linters
just build       # Build all applications
just health      # Check service health
```

**Complete Reference**: Run `just help` to see all available commands

---

## Getting Started

### For New Developers
1. **[Getting Started Guide](../setup/getting-started.md)** - Complete setup walkthrough
2. **[Environment Configuration](../setup/environment-setup.md)** - Detailed variable setup
3. **[Development Workflows](./README.md)** - Overview and navigation hub

### For Specific Applications
- **Backend Development**: [Backend Guide](../backend/development/README.md)
- **Admin Development**: [Admin Architecture Guide](../admin/architecture/README.md)
- **Mobile Development**: [Mobile Guide](../mobile/development/README.md)

### For Operations
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment procedures
- **[Testing Guide](../workflows/testing-guide.md)** - Testing strategies and automation
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Problem resolution

---

## Related Documentation

- **[Development Workflows](./README.md)** - Main system overview and navigation
- **[Getting Started Guide](../setup/getting-started.md)** - Complete project setup
- **[Environment Configuration](../setup/environment-setup.md)** - Variable setup and troubleshooting
- **[System Architecture](../architecture/system-architecture.md)** - Technical architecture and design patterns

---

**Status**: ✅ Updated and current as of 2025-06-29. Reorganized for improved navigation and enhanced with new documentation structure references.
