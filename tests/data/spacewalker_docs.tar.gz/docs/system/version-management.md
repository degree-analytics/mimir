# SpaceWalker Version Management System

## Overview

SpaceWalker implements a comprehensive semantic versioning system that provides version traceability from development through production deployment. The system uses a centralized configuration with automated generation across all services.

## Architecture

### Central Configuration
- **Location**: `version.json` (monorepo root)
- **Format**: Simple JSON with base semantic version
- **Example**: `{"version": "2.1.3"}`

### Version Generation
- **Script**: `scripts/version/generate-version.sh`
- **Format**: `MAJOR.MINOR.PATCH` (clean format for all environments)
- **Example**: `2.1.3`
- **Note**: Environment suffixes (-dev, -staging) removed for iOS/Android compatibility

## Version Display Locations

### 1. Backend (FastAPI)
**Where Displayed:**
- Health endpoints: `/health`, `/health/db`, `/health/ai`
- FastAPI application metadata (OpenAPI schema)
- Root health check: `/` endpoint

**Version Source:**
- Generated file: `apps/backend/src/spacecargo/_version.py`
- Package level: `spacecargo.__version__`

**How Generated:**
```bash
# During Docker build or development
./scripts/version/generate-version.sh --format python --output apps/backend/src/spacecargo/_version.py
```

**Example Response:**
```json
{
  "status": "healthy",
  "service": "backend",
  "version": {
    "version": "2.1.3",
    "versionBase": "2.1.3",
    "buildDate": "2025-06-30T19:14:28Z",
    "gitCommit": "75fead5",
    "gitBranch": "unknown",
    "environment": "dev"
  }
}
```

### 2. Admin Dashboard (Next.js)
**Where Displayed:**
- Dashboard layout footer (collapsible component)
- Health endpoint: `/api/health`

**Version Source:**
- Generated file: `apps/admin/src/version.ts`
- Component: `apps/admin/src/components/VersionDisplay.tsx`

**How Generated:**
```bash
# During Docker build or development
./scripts/version/generate-version.sh --format typescript --output apps/admin/src/version.ts
```

**UI Features:**
- Material-UI expandable card
- Environment indicator (colored dot)
- Fallback: health endpoint → local version file → error state
- Displays: version, environment, build date, git commit, branch

### 3. Mobile App (React Native)
**Where Displayed:**
- Home screen footer (collapsible component)
- Health server: `apps/mobile/health-server.js:3001/health`

**Version Source:**
- Generated file: `apps/mobile/src/version.ts`
- Component: `apps/mobile/src/components/VersionDisplay.tsx`
- App Store config: `apps/mobile/app.json` (iOS buildNumber)

**How Generated:**
```bash
# During Docker build or development
./scripts/version/generate-version.sh --format typescript --output apps/mobile/src/version.ts
```

**UI Features:**
- React Native TouchableOpacity expandable view
- Environment indicator (colored dot)
- Primary source: local version file (no network dependency)
- Displays: version, environment, build date, git commit, branch

**iOS Build Numbers:**
- **CRITICAL**: iOS requires monotonically increasing build numbers for TestFlight/App Store
- Location: `apps/mobile/app.json` → `expo.ios.buildNumber`
- **Must increment** with every TestFlight submission, regardless of version changes
- Build number is separate from semantic version and must never decrease

## Version Calculation Details

### Build Metadata Format
```
ENVIRONMENT.BUILDDATE.GITCOMMIT[.dirty]
```

**Components:**
- **ENVIRONMENT**: `dev` | `staging` | `prod`
- **BUILDDATE**: `YYYYMMDD` format
- **GITCOMMIT**: Short git SHA (7 characters)
- **dirty**: Added if uncommitted changes exist

### Environment Detection Logic
```bash
# Priority order:
1. DEPLOY_ENV environment variable
2. NODE_ENV environment variable (production→prod, staging→staging, other→dev)
3. Git branch analysis (main/master→prod, staging→staging, other→dev)
```

### Version Generation Triggers
1. **Docker Build**: Automatic during container build process
2. **CI/CD Pipeline**: Generated and cached for each commit
3. **Development**: Manual via `just generate_version` command
4. **Testing**: Test script validates generation with various git states

## File Structure

```
spacewalker/
├── version.json                              # Central version config
├── scripts/version/
│   ├── generate-version.sh                   # Main generation script
│   ├── generate-backend-version.sh           # Backend-specific wrapper
│   └── test-generate-version.sh              # Comprehensive tests
├── apps/backend/src/spacecargo/
│   ├── _version.py                           # Generated Python version
│   ├── __init__.py                           # Package-level version exports
│   ├── main.py                               # FastAPI app version integration
│   └── api/routers/health.py                 # Health endpoints with version
├── apps/admin/src/
│   ├── version.ts                            # Generated TypeScript version
│   ├── components/VersionDisplay.tsx         # UI component
│   └── pages/api/health.ts                   # Health endpoint
└── apps/mobile/src/
    ├── version.ts                            # Generated TypeScript version
    ├── components/VersionDisplay.tsx         # UI component
    └── ../health-server.js                   # Health server
```

## Development Workflow

### Version Bumping
```bash
# Update base version
echo '{"version": "2.2.0"}' > version.json

# Regenerate version files
just generate_version

# Commit changes
git add version.json apps/*/src/*version*
git commit -m "bump: Update to version 2.2.0"
```

### iOS Build Number Management

**CRITICAL RULE**: iOS build numbers must always increase for TestFlight/App Store submissions.

#### When to Increment iOS Build Number
1. **Every TestFlight submission** - Even if version didn't change
2. **After any TestFlight submission failure** - If resubmitting same version
3. **Version bumps** - When changing semantic version
4. **Hot fixes** - Emergency patches to same version

#### iOS Version Bump Workflow
```bash
# Method 1: Manual increment in app.json
# Edit apps/mobile/app.json:
# "buildNumber": "4" → "buildNumber": "5"

# Method 2: Using justfile command (recommended)
just mobile_bump_build

# Method 3: Combined version + build bump
just mobile_bump_version 1.0.4  # Updates both version and buildNumber

# Always regenerate version files after changes
just generate_version

# Commit both changes together
git add apps/mobile/app.json apps/*/src/*version*
git commit -m "bump: iOS build number for TestFlight submission"
```

#### iOS Build Number Validation
```bash
# Check current build number
cat apps/mobile/app.json | jq '.expo.ios.buildNumber'

# Validate build number hasn't decreased
# Build numbers should follow: 1, 2, 3, 4, 5... (never backwards)
```

#### TestFlight Submission Checklist
- [ ] Semantic version updated in `version.json` (if needed)
- [ ] iOS build number incremented in `apps/mobile/app.json`
- [ ] Generated version files updated with `just generate_version`
- [ ] No previous TestFlight submission exists with same build number
- [ ] Build number is higher than any previous TestFlight submission

### Local Development
```bash
# Generate versions for all services
just generate_version

# Test version generation
./scripts/version/test-generate-version.sh

# Check version in running services
curl http://localhost:8000/health | jq .version
curl http://localhost:3000/api/health | jq .version
curl http://localhost:3001/health | jq .version
```

## Production Deployment

### Docker Image Tagging
Each deployment creates multiple tags:
- `${ECR_REGISTRY}/${ENV}-${SERVICE}:${SEMANTIC_VERSION}` (with `+` replaced by `-`)
- `${ECR_REGISTRY}/${ENV}-${SERVICE}:v${SEMANTIC_VERSION}` (with `+` replaced by `-`)
- `${ECR_REGISTRY}/${ENV}-${SERVICE}:${GIT_BRANCH}` (with `/` replaced by `-`)
- `${ECR_REGISTRY}/${ENV}-${SERVICE}:${GIT_SHA}`
- `${ECR_REGISTRY}/${ENV}-${SERVICE}:latest`

**Note:** Docker doesn't support `+` in tag names, so semantic versions like `2.1.3+dev.20250701.abc123` are converted to `2.1.3-dev.20250701.abc123` for Docker tags.

### GitHub Releases
- Created automatically on `dev` and `main` branch deployments
- Branch-specific release strategy:
  - `dev` branch: Creates `dev-v${VERSION}` tags as prereleases
  - `main` branch: Creates `v${VERSION}` tags as production releases
- Includes deployment metadata: version, git SHA, branch, timestamp, and deployed services
- Releases are marked as `--latest` for easy tracking

### Health Check Monitoring
All services expose version information via health endpoints for:
- AWS load balancer health checks
- Monitoring and alerting systems
- Deployment verification
- Production debugging and traceability

## Troubleshooting

### Common Issues

**Version displays "unknown":**
- Check if `_version.py` or `version.ts` files exist
- Verify git repository is accessible during build
- Ensure version generation script ran successfully

**Mobile version not updating:**
- Mobile uses local version file as primary source
- Regenerate with `just generate_version`
- Rebuild mobile app bundle

**Health endpoints missing version:**
- Check import statements in health endpoint files
- Verify fallback handling for missing version files
- Review Docker build logs for version generation step

**Git metadata missing:**
- Ensure `.git` directory is available during build
- Check Docker build context includes git information
- Verify CI/CD environment has git access

### Validation Commands
```bash
# Test version generation
./scripts/version/test-generate-version.sh

# Validate all service versions match
just check_version_consistency

# Generate and test all formats
./scripts/version/generate-version.sh --format json
./scripts/version/generate-version.sh --format python  
./scripts/version/generate-version.sh --format typescript
```

## Version Format Decision

### Clean Semantic Versions (July 2025)

**Decision**: Remove environment suffixes (-dev, -staging) from all generated versions

**Rationale**:
- **iOS Compatibility**: Apple App Store rejects versions with suffixes like "1.0.4-dev"
- **Android Consistency**: Keep version formats identical across platforms
- **Simpler Deployment**: Reduces version parsing complexity in CI/CD
- **Environment Tracking**: Environment is still tracked in separate metadata field

**Before**: `1.0.4-dev`, `1.0.4-staging`, `1.0.4`  
**After**: `1.0.4` (for all environments)

**Implementation**:
- Modified `scripts/version/generate-version.sh` to always return base version
- Environment information remains available in `environment` field
- No impact on version comparison or sorting
- Simplified app store submission process