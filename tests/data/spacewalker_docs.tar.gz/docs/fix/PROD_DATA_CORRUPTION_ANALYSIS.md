# 🚨 Production Data Corruption Analysis & Fix Plan

**Date**: 2025-09-10
**Issue**: Degree Analytics tenant API failures (500 errors) in production
**Root Cause**: Orphaned data from production relaunch without database reset

---

## 🎯 **PROBLEM SUMMARY**

**Symptoms**:
- ❌ Surveys API: 500 errors for Degree Analytics tenant
- ❌ Dashboard API: Returns all zeros (0 buildings, 0 rooms, 0 surveys)
- ✅ Buildings API: Works correctly (shows 3 buildings)
- ✅ Tenant dropdown: Shows correct summary data

**Root Cause**: Pydantic validation failures when serializing Room objects that have `building_id = NULL` but API models expect `building` and `building_name` fields to be populated.

---

## 📊 **DATA CORRUPTION BREAKDOWN**

### **✅ GOOD DATA (Keep & Repair)**

**Buildings (SAFE)**:
| ID | Name | Tenant ID | Status |
|----|------|-----------|--------|
| 17 | Chad's House | 6 | ✅ Good |
| 21 | Josh's House | 6 | ✅ Good |
| 25 | Emma's House | 6 | ✅ Good |

**Floors (SAFE)**:
| ID | Name | Building ID | Building Name | Status |
|----|------|-------------|---------------|--------|
| 27 | Second Floor | 17 | Chad's House | ✅ Good |
| 37 | 2nd Floor | 21 | Josh's House | ✅ Good |
| 42 | Ground | 25 | Emma's House | ✅ Good |

**Rooms (NEED REPAIR - building_id = NULL)**:
| Room ID | Name | Floor ID | Building Should Be | Issue |
|---------|------|----------|-------------------|-------|
| **106** | Chad's Office | 27 | 17 (Chad's House) | building_id = NULL |
| **152** | Office | 37 | 21 (Josh's House) | building_id = NULL |
| **156** | Living Room | 42 | 25 (Emma's House) | building_id = NULL |

**Surveys (WILL WORK after room repair)**:
| Survey ID | Room ID | Room Name | User | Status |
|-----------|---------|-----------|------|--------|
| 128 | 106 | Chad's Office | chad.walters@degreeanalytics.com | approved |
| 132 | 152 | Office | josh.park@degreeanalytics.com | rejected |
| 133 | 152 | Office | josh.park@degreeanalytics.com | approved |
| 134 | 106 | Chad's Office | chad.walters@degreeanalytics.com | pending |
| 138 | 156 | Living Room | emma.cole@degreeanalytics.com | pending |
| 139 | 156 | Living Room | emma.cole@degreeanalytics.com | pending |
| 140 | 156 | Living Room | emma.cole@degreeanalytics.com | pending |
| 141 | 156 | Living Room | emma.cole@degreeanalytics.com | pending |

---

### **❌ ZOMBIE DATA (Safe to Delete)**

**Zombie Rooms from Orphaned Floors**:
| Room ID | Name | Floor ID | Issue |
|---------|------|----------|-------|
| 153 | Living Room | 38 | Floor has building_id = NULL |
| 154 | Living Room | 40 | Floor has building_id = NULL |
| 155 | livingroom2 | 41 | Floor has building_id = NULL |

**Zombie Surveys**:
| Survey ID | Room ID | User | Status |
|-----------|---------|------|--------|
| 135 | 153 | emma.cole@degreeanalytics.com | rejected |
| 136 | 154 | emma.cole@degreeanalytics.com | approved |
| 137 | 154 | emma.cole@degreeanalytics.com | approved |

**Generic Numbered Rooms (Building cleanup failure)**:
- **Room IDs 1-45**: All reference deleted building_ids 1, 2, 3
- **Pattern**: "Room 101", "Room 102", etc. (auto-generated test data)
- **Status**: No surveys attached, safe to delete

**Orphaned Floors**:
- **19 floors total** with building_id = NULL
- **Includes floors 38, 40, 41** referenced by zombie rooms above

---

## 🛠️ **REPAIR COMMANDS**

### **Step 1: Repair Good Rooms (CRITICAL - Fixes APIs)**
```sql
-- Fix building_id for legitimate rooms that have proper floor relationships
UPDATE rooms SET building_id = 17 WHERE id = 106; -- Chad's Office → Chad's House
UPDATE rooms SET building_id = 21 WHERE id = 152; -- Office → Josh's House
UPDATE rooms SET building_id = 25 WHERE id = 156; -- Living Room → Emma's House
```

### **Step 2: Clean Up Zombie Surveys**
```sql
-- Delete surveys referencing zombie rooms (rooms 153, 154, 155)
DELETE FROM surveys WHERE id IN (135, 136, 137);
```

### **Step 3: Clean Up Zombie Rooms**
```sql
-- Delete zombie rooms from orphaned floors
DELETE FROM rooms WHERE id IN (153, 154, 155);

-- Delete generic numbered rooms (building cleanup failure)
DELETE FROM rooms WHERE id >= 1 AND id <= 45;
```

### **Step 4: Clean Up Orphaned Floors**
```sql
-- Delete all floors with NULL building_id (19 total)
DELETE FROM floors WHERE building_id IS NULL;
```

---

## 🔥 **IMMEDIATE IMPACT**

**After Step 1 only**:
- ✅ Surveys API will work (no more 500 errors)
- ✅ Dashboard API will show correct data
- ✅ All Degree Analytics functionality restored

**After all steps**:
- ✅ Clean database with no zombie data
- ✅ Proper data integrity maintained
- ⚠️ 3 legitimate surveys deleted (user data loss, but necessary)

---

## 🎯 **VERIFICATION QUERIES**

### **Before Repair - Confirm Broken State**:
```sql
-- Should return 6 rows (broken rooms)
SELECT id, name, building_id, floor_id FROM rooms WHERE building_id IS NULL;

-- Should return 11 rows (broken surveys causing API failures)
SELECT s.id, s.room_id, r.name, r.building_id
FROM surveys s
JOIN rooms r ON s.room_id = r.id
WHERE r.building_id IS NULL AND s.tenant_id = 6;
```

### **After Repair - Confirm Fixed State**:
```sql
-- Should return 3 rows with proper building_ids
SELECT id, name, building_id, floor_id FROM rooms WHERE id IN (106, 152, 156);

-- Should return 8 rows (working surveys)
SELECT s.id, s.room_id, r.name, r.building_id, b.name as building_name
FROM surveys s
JOIN rooms r ON s.room_id = r.id
JOIN buildings b ON r.building_id = b.id
WHERE s.tenant_id = 6;
```

---

## 🚨 **NEXT STEPS: Prevent Future Corruption**

### **Investigation Required**:
1. **Why are rooms created with building_id = NULL?**
   - Check room creation endpoints
   - Review building-room relationship logic
   - Examine floor-based room creation (rooms getting floor_id but not building_id)

2. **Why did prod relaunch leave zombie data?**
   - Review cascade deletion policies
   - Check building deletion logic
   - Examine data migration/cleanup procedures

### **Code Issues to Investigate**:
```sql
-- This pattern should NOT be possible:
-- room.floor_id → valid floor → valid building
-- room.building_id → NULL
```

**Files to examine**:
- Room creation endpoints (`/api/rooms` POST)
- Building deletion logic
- Database model relationships and constraints
- Migration scripts for building/room relationships

---

## 🔍 **TIMELINE OF EVENTS**

1. **Initial Setup**: Buildings 1, 2, 3 created with rooms 1-45 (test data)
2. **Production Relaunch**: Infrastructure redeployed, but database preserved
3. **Building Cleanup**: Buildings 1, 2, 3 deleted (cascade deletion failed)
4. **User Activity**: Chad, Josh, Emma created new buildings (17, 21, 25)
5. **Room Creation**: New rooms (106, 152-156) created with floor_id but NULL building_id
6. **Survey Activity**: Users submitted surveys referencing broken rooms
7. **API Failures**: Pydantic validation fails on room serialization

**Key Insight**: The issue isn't just cleanup from prod relaunch - there's an ongoing bug in room creation that needs fixing to prevent future occurrences.

---

## ⚠️ **EXECUTION PLAN**

1. **IMMEDIATE**: Execute Step 1 (repair good rooms) → Restores API functionality
2. **VERIFICATION**: Test Surveys and Dashboard APIs for Degree Analytics
3. **CLEANUP**: Execute Steps 2-4 (remove zombie data) → Clean database
4. **INVESTIGATION**: Find and fix room creation bug → Prevent recurrence
5. **MONITORING**: Watch for future building_id = NULL rooms

---

**Prepared by**: Claude Code Analysis
**Reviewed by**: [To be completed]
**Execution Status**: Pending approval
