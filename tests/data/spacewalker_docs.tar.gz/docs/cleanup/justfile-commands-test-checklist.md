# Justfile Commands Test Checklist

## Testing Instructions
- Test each command in the appropriate environment (local/dev)
- Document any failures or errors
- Note which scripts are invoked by each command
- Mark [✓] for passed, [✗] for failed, [N/A] for not applicable

## Basic Commands
- [ ] `just` (default help)
- [ ] `just help`

## Database Operations
- [ ] `just db action=status env=dev`
- [ ] `just db init dev`
- [ ] `just db shell dev`
- [ ] `just db seed dev`
- [ ] `just db verify dev`
- [ ] `just db clean dev`
- [ ] `just sql "SELECT 1" dev`

## Health & URLs
- [ ] `just health dev`
- [ ] `just health local`
- [ ] `just wait dev`
- [ ] `just urls dev`
- [ ] `just urls local`

## Environment Management
- [ ] `just env_validate dev`
- [ ] `just env_setup`
- [ ] `just env_status`

## Service Management
- [ ] `just up`
- [ ] `just down`
- [ ] `just restart backend`
- [ ] `just stop backend`
- [ ] `just ps`

## Testing Commands
- [ ] `just test unit all`
- [ ] `just test unit backend`
- [ ] `just test unit admin`
- [ ] `just test unit mobile`
- [ ] `just test integration all`
- [ ] `just test system backend`
- [ ] `just dev_cycle`
- [ ] `just dev_cycle_full`

## Linting & Code Quality
- [ ] `just lint check all`
- [ ] `just lint check backend`
- [ ] `just lint check admin`
- [ ] `just lint check mobile`
- [ ] `just lint format all`

## AWS Operations
- [ ] `just aws status all dev`
- [ ] `just aws debug dev`
- [ ] `just aws logs dev`
- [ ] `just aws deploy backend dev` (DO NOT RUN - just verify command exists)
- [ ] `just aws diagnose dev`
- [ ] `just aws history dev`

## Secrets Management
- [ ] `just secrets list dev`
- [ ] `just secrets show dev --secret-name api-keys`
- [ ] `just secrets health dev`

## Stack Management
- [ ] `just stack status dev`
- [ ] `just stack events dev backend`
- [ ] `just stack inspect dev backend`
- [ ] `just stack exports dev backend`

## Mobile Commands
- [ ] `just mobile_health`
- [ ] `just mobile_troubleshoot`
- [ ] `just mobile_build_status`
- [ ] `just mobile_ci_status`

## Documentation
- [ ] `just docs action=generate`
- [ ] `just docs action=validate`
- [ ] `just docs action=search query="test"`

## Monitoring
- [ ] `just monitor action=status env=dev`
- [ ] `just monitor action=health env=dev`
- [ ] `just monitor action=dashboards env=dev`

## Logs
- [ ] `just logs backend dev`
- [ ] `just logs admin dev`
- [ ] `just logs all dev --tail=10`

## Bastion Management
- [ ] `just bastion list dev`
- [ ] `just bastion status dev`

## Production Commands (DO NOT TEST)
- [ ] `just prod enable` (NEVER RUN)
- [ ] `just prod disable` (Can run if needed)
- [ ] `just prod status`

## Database Demo Commands
- [ ] `just db_demo dev`
- [ ] `just db_demo_comprehensive dev`
- [ ] `just db_demo_full dev`
- [ ] `just db_demo_clean dev`
- [ ] `just db_demo_status dev`

## AWS Database Commands
- [ ] `just aws_db_status dev`
- [ ] `just aws_db_demo_status dev`

## ECS Commands
- [ ] `just ecs env backend dev`

## Deployment Commands (Verify Only)
- [ ] `just aws_deploy_backend dev` (DO NOT RUN)
- [ ] `just aws_deploy_admin dev` (DO NOT RUN)
- [ ] `just aws_restart_backend dev` (Can test if needed)
- [ ] `just aws_force_deploy dev backend` (DO NOT RUN)

## Debugging Commands
- [ ] `just debug_stuck dev`
- [ ] `just debug_ecs dev backend`
- [ ] `just aws_fix_deployment dev backend` (DO NOT RUN)
- [ ] `just aws_fix_frozen dev` (DO NOT RUN)

## Version Commands
- [ ] `just version`
- [ ] `just version_backend`
- [ ] `just version_sync 1.0.0` (DO NOT RUN - modifies files)

## E2E Testing
- [ ] `just e2e_test dev`
- [ ] `just e2e_post_deploy dev`

## Other Commands
- [ ] `just clean`
- [ ] `just claude_validate`
- [ ] `just claude_memory`
- [ ] `just android_release_status`

## Scripts Invoked Summary
After testing, document which scripts are invoked by each command category:
- Helper scripts (scripts/helpers/)
- Deployment scripts (scripts/deployment/)
- Database scripts (scripts/database/)
- Version scripts (scripts/version/)
- Other scripts
