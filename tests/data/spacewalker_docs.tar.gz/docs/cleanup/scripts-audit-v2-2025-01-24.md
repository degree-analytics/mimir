# Scripts Audit Report v2 - 2025-01-24

## Executive Summary

Total scripts audited: **131 scripts** across various directories
- Python scripts: 87
- Shell scripts: 44
- JavaScript scripts: 0

## Script Categories and Status

### 1. ACTIVE Scripts (Used in justfile or imported)

#### Helper Scripts (`scripts/helpers/`) - 17 Python scripts
All actively used in justfile commands:
- `bastion_manager.py` - Bastion host management
- `connection_manager.py` - Core AWS connectivity (imported by 8 modules)
- `config.py` - Configuration management (imported by 4 modules)
- `db_manager.py` - Database management wrapper
- `db_operations_wrapper.py` - Database operations
- `db_shell.py` - Database shell access
- `db_sql_wrapper.py` - SQL query wrapper
- `deployment_manager.py` - AWS deployment management
- `docs_manager.py` - Documentation management
- `ecs_manager.py` - ECS operations
- `env_validator.py` - Environment validation
- `generate_help.py` - Help documentation generation
- `health_checker.py` - Health checks and waiting
- `lint_manager.py` - Linting operations
- `logs_manager.py` - Log management
- `monitor_manager.py` - Monitoring operations
- `service_manager.py` - Service management
- `sm_manager.py` - Secrets Manager operations
- `stack_manager.py` - CloudFormation stack management
- `test_manager.py` - Test execution management
- `url_manager.py` - URL management
- `base_manager.py` - Base class (imported by 3 modules)

#### Deployment Scripts (`scripts/deployment/`) - 23 scripts
Active scripts:
- `check-deployment-status-enhanced.sh` - Used by `aws debug` command
- `debug-stuck-deployment.sh` - Used via `_aws_run` helper
- `force-ecs-deployment.sh` - Used in `aws_force_deploy`
- `fix-deployment.sh` - Used in `aws_fix_deployment`
- `fix-frozen-state.sh` - Used in `aws_fix_frozen`
- `init-demo-database.sh` - Used in `aws_db_demo_init`
- `debug-ecs-deployment.sh` - Used in `ecs_debug`
- `time-utils.sh` - Utility sourced by other scripts
- Python modules: `aws_utils.py`, `config.py`, `deploy.py`, `sam_operations.py`

Potentially unused (need investigation):
- `check-aws-infrastructure.sh`
- `check-database.sh`
- `check-deployments.sh`
- `check-health.sh`
- `check-images.sh`
- `check-issues.sh`
- `check-stacks.sh`
- `debug-health-checks.sh`
- `show-deployment-history.sh`

#### Database Scripts (`scripts/database/`) - 27 scripts
Active scripts (used via `aws_db_wrapper.py`):
- `aws_db_demo_comprehensive.py`
- `aws_db_demo_full.py`
- `aws_db_demo_clean.py`
- `aws_db_demo_status.py`
- `aws_db_check_coverage.py`
- `aws_init_complete.py`
- `db_helper.py` - Core database utilities
- `aws_db_wrapper.py` - Main wrapper for DB operations

Backend imports (spacecargo.scripts namespace):
- `seed_demo_comprehensive.py`
- `demo/` subdirectory scripts for demo data

#### Version Scripts (`scripts/version/`) - 3 scripts
All actively used:
- `generate-backend-version.sh` - Backend version generation
- `generate-version.sh` - Version file generation (used in CI/CD)
- `sync-package-versions.sh` - Package version synchronization

### 2. CI_ONLY Scripts
- `scripts/version/generate-version.sh` - Used in CI/CD workflow
- `scripts/eas_version_sync.sh` - Used in CI/CD for mobile builds

### 3. IMPORTED Scripts (Python modules)
Core modules with multiple importers:
- `scripts.helpers.connection_manager` (8 importers)
- `scripts.helpers.config` (4 importers)
- `scripts.database.db_helper` (3 importers)
- `scripts.helpers.base_manager` (3 importers)

### 4. HISTORICAL/ONE-TIME Scripts
Potentially historical (need confirmation):
- `scripts/archive/add-expo-token-to-secrets.sh` - Already in archive
- `scripts/add-expo-token-to-secrets.sh` - Duplicate of archived version
- `scripts/init-system-attributes.sh` - One-time initialization
- `scripts/verify-system-attributes.sh` - One-time verification

### 5. DEVELOPMENT Scripts
- `scripts/helpers/expo_manager.py ip` - Replaces old `scripts/dev/configure_mobile.py` for mobile IP setup
- `mimir` (external package) - Documentation search CLI (`mimir index|search|ask`)
- `scripts/claude_validate_commands.sh` - Claude command validation
- `scripts/claude_memory.sh` - Claude memory operations

### 6. UNUSED/DEPRECATED Scripts
Scripts with no references found:
- Many check-*.sh scripts in deployment/ that aren't referenced in justfile
- Potential duplicates between shell and Python versions

## Import Dependency Graph

```
connection_manager (hub)
├── db_manager
├── db_shell
├── db_sql
├── health_checker
├── logs_manager
├── sm_manager
├── test_connection_manager
└── url_manager

config (shared)
├── bastion_manager
├── db_manager
├── db_operations_wrapper
└── tunnel_manager

base_manager (inheritance)
├── deployment_manager
├── ecs_manager
└── monitor_manager
```

## Recommendations

### Phase 1: Immediate Actions
1. **Keep archive/**: Already contains obsolete scripts
2. **Create deprecated/** directory for staged deprecation
3. **Document** all check-*.sh scripts in deployment/ - understand their purpose

### Phase 2: Investigation Required
1. Check if deployment/check-*.sh scripts are used elsewhere
2. Verify if scripts/add-expo-token-to-secrets.sh is duplicate of archived version
3. Test removal of apparently unused scripts

### Phase 3: Staged Deprecation
1. Move candidates to deprecated/ with README
2. Add logging to track any usage
3. Monitor for 2 weeks
4. Move to archive/ after confirmation

### Phase 4: Documentation
1. Update script invocation map with findings
2. Create README in deprecated/ and archive/
3. Document decision rationale for each script

## Script Invocation Patterns

1. **Direct invocation**: `python scripts/helpers/script.py`
2. **Via helpers**: `just _aws_run script.sh`
3. **With environment**: `AWS_PROFILE=$(...) ./scripts/script.sh`
4. **Via wrappers**: Database scripts through `aws_db_wrapper.py`
5. **As imports**: Python modules imported by other scripts/backend

## Critical Dependencies

- `connection_manager.py` is central to AWS operations
- `config.py` provides shared configuration
- `db_helper.py` is core to database operations
- Version scripts are critical for CI/CD pipeline

## Next Steps

1. Test all justfile commands to verify working state
2. Create deprecated/ directory structure
3. Begin staged deprecation of identified unused scripts
4. Update documentation with findings
