# Troubleshooting FICM Loading Issues

## Purpose
Provides solutions for common FICM (Facilities Inventory and Classification Manual) data loading issues in the Spacewalker platform, particularly in the dev-admin interface.

## When to Use This
- FICM codes show "0 loaded" in dev-admin
- FICM hierarchy API returns data but UI doesn't display it
- Tenant-specific FICM data not appearing
- Data structure mismatch errors

**Keywords:** FICM troubleshooting, loading issues, hierarchy API, dev-admin, data structure

## Common Issues and Solutions

### Issue 1: "0 FICM codes loaded" Despite Data in Database

#### Symptoms
- Dev-admin shows "0 FICM codes loaded"
- Database queries confirm FICM data exists
- API returns data but frontend doesn't display it

#### Root Cause
Frontend expects hierarchical data structure but API returns flat array.

#### Solution
Update frontend to process flat array structure:

```typescript
// ❌ OLD CODE - Expects hierarchical structure
data.forEach((category: FICMHierarchyCategory) => {
  if (category.base_codes) {
    category.base_codes.forEach((baseCode) => {
      // Process nested structure
    });
  }
});

// ✅ NEW CODE - Processes flat array
data.forEach((item: any) => {
  if (item.full_code && item.full_name) {
    allCodes.push({
      code: item.full_code,
      name: item.full_name,
      description: item.full_description || '',
    });
  }
});
```

### Issue 2: Wrong Tenant Context (Superusers)

#### Symptoms
- FICM data shows for wrong tenant
- Data disappears after tenant switch
- Inconsistent data between UI elements

#### Root Cause
Missing or incorrect `X-Selected-Tenant-Id` header.

#### Solution
1. Check localStorage for selected tenant:
   ```javascript
   localStorage.getItem('selectedTenantId')
   ```

2. Verify API requests include header:
   - Open DevTools Network tab
   - Check request headers for `X-Selected-Tenant-Id`

3. Ensure tenant has FICM data:
   ```bash
   just ficm_status <tenant_id>
   ```

### Issue 3: API Returns Empty Array

#### Symptoms
- `/api/ficm/hierarchy` returns `[]`
- Database has FICM data but API doesn't return it

#### Root Cause
Tenant filtering or RLS (Row Level Security) issues.

#### Diagnostic Steps
1. Check current tenant context:
   ```bash
   # For superuser, check which tenant is selected
   curl -H "Authorization: Bearer $TOKEN" \
        -H "X-Selected-Tenant-Id: 2" \
        http://localhost:8000/api/ficm/hierarchy
   ```

2. Verify FICM data for tenant:
   ```bash
   just ficm_status 2  # Check specific tenant
   ```

3. Check if data is active:
   ```sql
   SELECT COUNT(*) FROM ficm_base_codes 
   WHERE tenant_id = 2 AND is_active = true;
   ```

### Issue 4: Partial Data Loading

#### Symptoms
- Some FICM codes load but not all
- Missing design types or base codes
- Inconsistent counts between DB and UI

#### Root Cause
Incomplete data migration or inactive records.

#### Solution
1. Check active vs total records:
   ```bash
   just db_query "SELECT is_active, COUNT(*) FROM ficm_base_codes WHERE tenant_id = 2 GROUP BY is_active"
   ```

2. Activate all FICM records:
   ```sql
   UPDATE ficm_base_codes SET is_active = true WHERE tenant_id = 2;
   UPDATE ficm_design_types SET is_active = true WHERE tenant_id = 2;
   ```

## Debugging Workflow

### Step 1: Verify Database Data
```bash
# Check FICM data status
just ficm_status

# For specific tenant
just ficm_status 2
```

### Step 2: Test API Directly
```bash
# Test hierarchy endpoint
curl -H "Authorization: Bearer $TOKEN" \
     http://localhost:8000/api/ficm/hierarchy | jq length

# For superuser with tenant selection
curl -H "Authorization: Bearer $TOKEN" \
     -H "X-Selected-Tenant-Id: 2" \
     http://localhost:8000/api/ficm/hierarchy | jq length
```

### Step 3: Check Frontend Processing
1. Add console logging:
   ```typescript
   console.log(`Loaded ${allCodes.length} FICM codes from hierarchy API`);
   ```

2. Verify data structure in browser console:
   ```javascript
   // Check first item structure
   console.log(data[0]);
   ```

### Step 4: Verify UI Updates
1. Check React state updates
2. Verify component re-renders
3. Check for conditional rendering issues

## Prevention

### Best Practices
1. **Always check data structure**: Don't assume API response format
2. **Use TypeScript interfaces**: Define expected API response types
3. **Add data validation**: Check for required fields before processing
4. **Include logging**: Log data counts at each processing step

### Testing Checklist
- [ ] Test with empty tenant (no FICM data)
- [ ] Test with partial data (some inactive)
- [ ] Test with full data set
- [ ] Test tenant switching (superusers)
- [ ] Test after data updates

## Quick Commands

```bash
# Check FICM status for all tenants
just ficm_status

# Check specific tenant
just ficm_status 2

# Test dev-admin FICM loading
just dev_admin_test

# Validate FICM data structure
just ficm_validate
```

## Related Documentation
- [FICM API](../backend/ficm-api.md)
- [Multi-Tenant Superuser](../admin/multi-tenant-superuser.md)
- [AI Testing Tools](../admin/ai-testing-tools.md)

## Version History
- **v1.0** (2025-01-16): Initial troubleshooting guide for FICM loading issues