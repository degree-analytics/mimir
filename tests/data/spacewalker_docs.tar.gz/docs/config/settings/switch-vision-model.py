#!/usr/bin/env python3
"""
Vision Model Switcher for Space Walker Evaluation Package

This script makes it easy to switch between the top 10 vision models for 2025
in your evaluation configurations.

Usage:
    python switch-vision-model.py --config config/uw_madison_production.yaml --model claude_sonnet_4
    python switch-vision-model.py --list-models
    python switch-vision-model.py --show-recommendations

Examples:
    # Switch to best accuracy model
    python switch-vision-model.py --config config/uw_madison_production.yaml --model best_accuracy

    # Switch to best value model
    python switch-vision-model.py --config config/uw_madison_production.yaml --model best_value

    # Switch to development model (cheapest)
    python switch-vision-model.py --config config/uw_madison_production.yaml --model development
"""

import argparse
import yaml
from pathlib import Path
from typing import Dict, Any, List
import sys

# Load vision models configuration
VISION_MODELS_CONFIG = Path(__file__).parent / "vision-models-2025.yaml"

def load_vision_models_config() -> Dict[str, Any]:
    """Load the vision models configuration."""
    if not VISION_MODELS_CONFIG.exists():
        print(f"❌ Vision models config not found: {VISION_MODELS_CONFIG}")
        sys.exit(1)

    with open(VISION_MODELS_CONFIG, 'r') as f:
        return yaml.safe_load(f)

def get_all_models(config: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Get all available models from the configuration."""
    models = {}

    # Production model
    if 'production_model' in config:
        models['production'] = config['production_model']

    # All tier models
    for tier in ['tier_1_premium', 'tier_2_balanced', 'tier_3_efficient', 'tier_4_openrouter']:
        if tier in config:
            for model in config[tier]:
                models[model['name']] = model

    return models

def get_quick_configs(config: Dict[str, Any]) -> Dict[str, str]:
    """Get quick configuration shortcuts."""
    if 'quick_configs' in config:
        return {k: v['name'] for k, v in config['quick_configs'].items()}
    return {}

def list_models():
    """List all available vision models."""
    config = load_vision_models_config()
    models = get_all_models(config)
    quick_configs = get_quick_configs(config)

    print("🔥 TOP 10 VISION MODELS FOR 2025")
    print("=" * 50)

    # Production model
    if 'production' in models:
        model = models['production']
        print(f"\n🏭 PRODUCTION MODEL:")
        print(f"   {model['name']} - {model['display_name']}")
        print(f"   Provider: {model['provider']}, Model: {model['model_id']}")
        print(f"   Cost: ${model['cost_per_1k_input']:.3f}/${model['cost_per_1k_output']:.3f} per 1K tokens")
        print(f"   Use: {model['recommended_use']}")

    # Tier 1: Premium
    print(f"\n🥇 TIER 1: PREMIUM MODELS (Best Performance)")
    tier1_models = [m for m in models.values() if m.get('name') in ['claude_sonnet_4', 'gpt_4_1', 'gemini_2_5_pro']]
    for model in tier1_models:
        print(f"   {model['display_name']}")
        print(f"   └─ ${model['cost_per_1k_input']:.2f}/${model['cost_per_1k_output']:.2f} per 1K | {model['recommended_use']}")

    # Tier 2: Balanced
    print(f"\n🥈 TIER 2: BALANCED MODELS (Good Performance)")
    tier2_models = [m for m in models.values() if m.get('name') in ['claude_3_7_sonnet', 'gpt_4o', 'gemini_2_5_flash']]
    for model in tier2_models:
        print(f"   {model['display_name']}")
        print(f"   └─ ${model['cost_per_1k_input']:.2f}/${model['cost_per_1k_output']:.2f} per 1K | {model['recommended_use']}")

    # Tier 3: Efficient
    print(f"\n💰 TIER 3: EFFICIENT MODELS (Cost-Effective)")
    tier3_models = [m for m in models.values() if m.get('name') in ['gpt_4_1_mini', 'gpt_4_1_nano', 'gemini_2_0_flash']]
    for model in tier3_models:
        print(f"   {model['display_name']}")
        print(f"   └─ ${model['cost_per_1k_input']:.2f}/${model['cost_per_1k_output']:.2f} per 1K | {model['recommended_use']}")

    # Quick configs
    print(f"\n⚡ QUICK CONFIGURATIONS:")
    for config_name, model_name in quick_configs.items():
        if model_name in models:
            model = models[model_name]
            print(f"   {config_name:20} → {model['display_name']}")

    print(f"\n📝 USAGE:")
    print(f"   python switch-vision-model.py --config <config.yaml> --model <model_name>")
    print(f"   python switch-vision-model.py --config <config.yaml> --model best_accuracy")

def show_recommendations():
    """Show usage recommendations by scenario."""
    config = load_vision_models_config()
    scenarios = config.get('scenarios', {})

    print("🎯 VISION MODEL RECOMMENDATIONS BY SCENARIO")
    print("=" * 50)

    for scenario, info in scenarios.items():
        print(f"\n📋 {scenario.upper().replace('_', ' ')}")
        print(f"   Description: {info['description']}")
        print(f"   Recommended: {', '.join(info['recommended_models'])}")
        print(f"   Rationale: {info['rationale']}")

    # API Keys
    api_keys = config.get('api_keys', {})
    print(f"\n🔑 API KEY REQUIREMENTS:")
    for provider, info in api_keys.items():
        print(f"   {provider.upper():12} → {info['env_var']:20} ({len(info['models'])} models)")

def switch_model(config_path: str, model_name: str):
    """Switch the vision judge model in a configuration file."""
    config_path = Path(config_path)
    if not config_path.exists():
        print(f"❌ Config file not found: {config_path}")
        return

    # Load vision models config
    vision_config = load_vision_models_config()
    models = get_all_models(vision_config)
    quick_configs = get_quick_configs(vision_config)

    # Resolve model name (handle quick configs)
    if model_name in quick_configs:
        model_name = quick_configs[model_name]

    if model_name not in models:
        print(f"❌ Model '{model_name}' not found. Use --list-models to see available options.")
        return

    model = models[model_name]

    # Load the config file
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)

    # Update vision judge configuration
    vision_judge_config = {
        'name': f"vision_judge_{model_name}",
        'provider': model['provider'],
        'model_id': model['model_id'],
        'temperature': model['temperature'],
        'max_tokens': model['max_tokens'],
        'additional_params': model.get('additional_params', {})
    }

    config['vision_judge'] = vision_judge_config

    # Save the updated config
    with open(config_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, indent=2)

    print(f"✅ Updated vision judge in {config_path}")
    print(f"   Model: {model['display_name']}")
    print(f"   Provider: {model['provider']}")
    print(f"   ID: {model['model_id']}")
    print(f"   Cost: ${model['cost_per_1k_input']:.3f}/${model['cost_per_1k_output']:.3f} per 1K tokens")
    print(f"   Recommended for: {model['recommended_use']}")

    # Show API key requirement
    api_keys = vision_config.get('api_keys', {})
    provider = model['provider']
    if provider in api_keys:
        env_var = api_keys[provider]['env_var']
        print(f"\n🔑 Required API Key: {env_var}")
        print(f"   Make sure this environment variable is set before running evaluations.")

def main():
    parser = argparse.ArgumentParser(
        description="Switch between vision models in Space Walker evaluation configs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )

    parser.add_argument(
        '--config', '-c',
        help="Path to configuration file to modify"
    )

    parser.add_argument(
        '--model', '-m',
        help="Model name or quick config (e.g., 'claude_sonnet_4', 'best_accuracy', 'development')"
    )

    parser.add_argument(
        '--list-models', '-l',
        action='store_true',
        help="List all available vision models"
    )

    parser.add_argument(
        '--show-recommendations', '-r',
        action='store_true',
        help="Show model recommendations by use case"
    )

    args = parser.parse_args()

    if args.list_models:
        list_models()
    elif args.show_recommendations:
        show_recommendations()
    elif args.config and args.model:
        switch_model(args.config, args.model)
    else:
        parser.print_help()
        print(f"\n💡 Quick start:")
        print(f"   python {sys.argv[0]} --list-models")
        print(f"   python {sys.argv[0]} --show-recommendations")

if __name__ == "__main__":
    main()
