# Vision Models Configuration - 2025

Easy configuration system for the top 10 vision models available in 2025 for Space Walker evaluation.

## Quick Start

### 1. List Available Models
```bash
python switch-vision-model.py --list-models
```

### 2. Switch to Best Model for Your Use Case
```bash
# Best accuracy (regardless of cost)
python switch-vision-model.py --config ../../packages/eval/config/uw_madison_production.yaml --model best_accuracy

# Best value (performance per dollar)
python switch-vision-model.py --config ../../packages/eval/config/uw_madison_production.yaml --model best_value

# Development testing (cheapest)
python switch-vision-model.py --config ../../packages/eval/config/uw_madison_production.yaml --model development

# Current production model
python switch-vision-model.py --config ../../packages/eval/config/uw_madison_production.yaml --model production_current
```

### 3. View Recommendations by Scenario
```bash
python switch-vision-model.py --show-recommendations
```

## Top 10 Vision Models (Ranked)

### 🏭 Production Model (Currently Used)
- **Gemini 2.0 Flash Lite** - `gemini-2.0-flash-lite-001`
- Current Space Walker production model
- Cost: $0.075/$0.30 per 1K tokens

### 🥇 Tier 1: Premium (Best Performance)
1. **Claude Sonnet 4** - `claude-sonnet-4-20250514`
   - Best accuracy available
   - Cost: $3.15/$15.75 per 1K tokens

2. **GPT-4.1** - `gpt-4.1`
   - OpenAI's latest flagship
   - Cost: $2.00/$8.00 per 1K tokens

3. **Gemini 2.5 Pro** - `gemini-2.5-pro`
   - Google's most capable with thinking
   - Cost: $1.25/$5.00 per 1K tokens

### 🥈 Tier 2: Balanced (Good Performance)
4. **Claude 3.7 Sonnet** - `claude-3-7-sonnet-20250124`
5. **GPT-4o** - `gpt-4o`
6. **Gemini 2.5 Flash** - `gemini-2.5-flash`

### 💰 Tier 3: Efficient (Cost-Effective)
7. **GPT-4.1 Mini** - `gpt-4.1-mini`
8. **GPT-4.1 Nano** - `gpt-4.1-nano`
9. **Gemini 2.0 Flash** - `gemini-2.0-flash`
10. **Claude 3.5 Haiku (OpenRouter)** - `anthropic/claude-3.5-haiku`

## Usage Scenarios

### 🔬 Production FICM Classification
**Recommended:** `production_gemini_flash`, `gemini_2_5_flash`, `claude_sonnet_4`
- Balance of accuracy, cost, and reliability

### 🧪 Development & Testing
**Recommended:** `gpt_4_1_nano`, `gemini_2_5_flash`, `gpt_4_1_mini`
- Low cost, fast iteration, good for testing

### 🎯 Maximum Accuracy Required
**Recommended:** `claude_sonnet_4`, `gpt_4_1`, `gemini_2_5_pro`
- Top-tier models regardless of cost

### 💰 Budget-Constrained Evaluation
**Recommended:** `gpt_4_1_nano`, `gemini_2_5_flash`, `gemini_2_0_flash`
- Lowest cost per evaluation

### 🔬 Research & Comparison Studies
**Recommended:** `claude_sonnet_4`, `gpt_4_1`, `gemini_2_5_pro`, `gemini_2_5_flash`
- Diverse providers and capabilities

## API Key Setup

Make sure you have the required API keys set as environment variables:

```bash
# OpenAI models (GPT-4.1, GPT-4o, GPT-4.1 Mini, GPT-4.1 Nano)
export OPENAI_API_KEY="your-openai-key"

# Anthropic models (Claude Sonnet 4, Claude 3.7 Sonnet)
export ANTHROPIC_API_KEY="your-anthropic-key"

# Google models (Gemini 2.5 Pro, Gemini 2.5 Flash, Gemini 2.0 Flash)
export GOOGLE_API_KEY="your-google-key"

# OpenRouter (Single key for 300+ models including alternatives)
export OPENROUTER_API_KEY="your-openrouter-key"
```

## Files

- `vision-models-2025.yaml` - Complete model specifications and configurations
- `switch-vision-model.py` - Command-line tool to switch models
- `README.md` - This documentation

## Examples

### Switch to Claude Sonnet 4 (Highest Accuracy)
```bash
cd docs/config/settings
python switch-vision-model.py \
  --config ../../../packages/eval/config/uw_madison_production.yaml \
  --model claude_sonnet_4
```

### Switch to Budget Option for Development
```bash
cd docs/config/settings
python switch-vision-model.py \
  --config ../../../packages/eval/config/uw_madison_production.yaml \
  --model development
```

### View All Options
```bash
cd docs/config/settings
python switch-vision-model.py --list-models
```

## Model Selection Guide

| Use Case | Model | Monthly Cost (1M tokens) | Accuracy | Speed |
|----------|-------|---------------------------|----------|-------|
| Production | Gemini 2.5 Flash | $405 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Research | Claude Sonnet 4 | $18,900 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| Development | GPT-4.1 Nano | $500 | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Balanced | GPT-4.1 | $10,000 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |

## Deprecated Models (Do Not Use)

❌ `gpt-4-vision-preview` - Deprecated December 2024
❌ `claude-3-5-sonnet-20241022` - Deprecated October 2025
❌ `gpt-4.5-preview` - Deprecated July 2025

Use the replacement models listed in `vision-models-2025.yaml`.
