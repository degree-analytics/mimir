# Health Endpoint Response Schema

This document defines the standard JSON response format for health endpoints across all SpaceWalker services.

## Standard Response Format

All health endpoints (`/health` or `/api/health`) MUST return a JSON response with the following structure:

```typescript
interface HealthResponse {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string; // ISO 8601 format
  service: string; // Service identifier: 'backend' | 'admin' | 'mobile'
  version: VersionInfo;
  checks: Record<string, HealthCheck>;
}

interface VersionInfo {
  version: string; // Full semantic version with build metadata
  versionBase: string; // Base semantic version (MAJOR.MINOR.PATCH)
  buildDate: string; // Build timestamp in ISO format
  gitCommit: string; // Git commit hash (short)
  gitBranch: string; // Git branch name
  environment: string; // Environment: 'dev' | 'staging' | 'prod'
}

interface HealthCheck {
  status: 'healthy' | 'unhealthy';
  message: string;
  severity?: 'critical' | 'warning';
  [key: string]: any; // Additional service-specific data
}
```

## HTTP Status Codes

- **200**: Service is healthy
- **503**: Service is degraded or unhealthy
- **500**: Internal server error during health check

## Service-Specific Health Checks

### Backend Service
- Database connectivity (`checks.database`)
- AI service connectivity (`checks.ai`)
- File storage connectivity (`checks.storage`)

### Admin Service  
- Backend API connectivity (`checks.backend`)

### Mobile Service
- Expo dev server status (`checks.expoDevServer`)
- Backend API connectivity (`checks.backend`)
- Container status (`checks.container`)

## Example Responses

### Healthy Backend
```json
{
  "status": "healthy",
  "timestamp": "2025-06-30T19:27:18Z",
  "service": "backend",
  "version": {
    "version": "2.1.3+dev.20250630.75fead5.dirty",
    "versionBase": "2.1.3",
    "buildDate": "2025-06-30T19:27:18Z",
    "gitCommit": "75fead5",
    "gitBranch": "chadrwalters/eng-584",
    "environment": "dev"
  },
  "checks": {
    "database": {
      "status": "healthy",
      "message": "Database connection successful"
    }
  }
}
```

### Degraded Mobile Service
```json
{
  "status": "degraded", 
  "timestamp": "2025-06-30T19:27:18Z",
  "service": "mobile",
  "version": {
    "version": "2.1.3+dev.20250630.75fead5.dirty",
    "versionBase": "2.1.3",
    "buildDate": "2025-06-30T19:27:18Z", 
    "gitCommit": "75fead5",
    "gitBranch": "chadrwalters/eng-584",
    "environment": "dev"
  },
  "checks": {
    "expoDevServer": {
      "status": "healthy",
      "message": "Expo dev server responding",
      "port": 8081
    },
    "backend": {
      "status": "unhealthy",
      "message": "Backend connection failed: timeout",
      "severity": "warning"
    }
  }
}
```

## Implementation Status

✅ **Backend**: Implemented in `main.py` and `health.py`  
✅ **Admin**: Implemented in `src/pages/api/health.ts`  
✅ **Mobile**: Implemented in `health-server.js`

## Validation

Use the test script `test-health-formats.js` to validate response format consistency across all services.