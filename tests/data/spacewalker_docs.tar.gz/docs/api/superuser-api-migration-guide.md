# Superuser API Migration Guide

## Overview

This guide covers breaking changes introduced to the Superuser API endpoints that now require the `X-Selected-Tenant-Id` header for cross-tenant operations.

**Version**: Introduced in PR #434
**Impact**: 🔴 **BREAKING CHANGE** for existing superuser API clients
**Affected Routes**: All `/api/superuser/*` endpoints that perform tenant-specific operations

## What Changed

### New Header Requirement

All superuser endpoints that perform tenant-specific operations now **require** the `X-Selected-Tenant-Id` header to ensure explicit tenant context selection and prevent accidental cross-tenant access.

### Security Enhancement

This change enhances security by:
- Preventing accidental cross-tenant operations
- Ensuring explicit tenant context selection
- Improving audit logging for cross-tenant access
- Reducing the risk of superuser mistakes affecting wrong tenants

## Affected Endpoints

### Tenant-Specific Operations (Header REQUIRED)

These endpoints now **require** the `X-Selected-Tenant-Id` header:

| Endpoint | Method | Header Requirement |
|----------|--------|-------------------|
| `/api/superuser/tenants/{tenant_id}` | GET | ✅ Required - Must match `{tenant_id}` |
| `/api/superuser/tenants/{tenant_id}` | PUT | ✅ Required - Must match `{tenant_id}` |
| `/api/superuser/tenants/{tenant_id}` | DELETE | ✅ Required - Must match `{tenant_id}` |
| `/api/superuser/tenants/{tenant_id}/users` | GET | ✅ Required - Must match `{tenant_id}` |
| `/api/superuser/tenants/{tenant_id}/owner` | PUT | ✅ Required - Must match `{tenant_id}` |
| `/api/superuser/users/{user_id}/status` | PUT | ✅ Required - Must match user's tenant |
| `/api/superuser/users/{user_id}/role` | PUT | ✅ Required - Must match user's tenant |
| `/api/superuser/users/{user_id}/tenant` | PUT | ✅ Required - Must match user's current tenant |

### Global Operations (Header OPTIONAL)

These endpoints allow the header but don't require it:

| Endpoint | Method | Header Requirement |
|----------|--------|-------------------|
| `/api/superuser/tenants` | GET | 🔵 Optional - For validation only |
| `/api/superuser/tenants` | POST | 🔵 Optional - For validation only |
| `/api/superuser/users` | GET | 🔵 Optional - For validation only |
| `/api/superuser/tenants/check-subdomain` | GET | 🔵 Optional - For validation only |

## Migration Steps

### 1. Update API Client Headers

Add the `X-Selected-Tenant-Id` header to all superuser API requests:

#### Before (❌ Will Fail)
```javascript
// This will now return 400 Bad Request
const response = await fetch('/api/superuser/tenants/123', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json'
  }
});
```

#### After (✅ Correct)
```javascript
// Add X-Selected-Tenant-Id header
const response = await fetch('/api/superuser/tenants/123', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json',
    'X-Selected-Tenant-Id': '123'  // ← Required header
  }
});
```

### 2. Header Validation Rules

The header must follow these rules:

- **Format**: Must be a positive integer as string
- **Validation**: Tenant must exist and not be deleted
- **Matching**: For tenant-specific operations, header must match the tenant ID in the URL
- **User Operations**: For user operations, header must match the user's current tenant ID

#### Valid Examples
```http
X-Selected-Tenant-Id: 1
X-Selected-Tenant-Id: 42
X-Selected-Tenant-Id: 999
```

#### Invalid Examples (❌ Will Return 400)
```http
X-Selected-Tenant-Id: 0          # Must be positive
X-Selected-Tenant-Id: -1         # Must be positive
X-Selected-Tenant-Id: abc        # Must be integer
X-Selected-Tenant-Id: 1.5        # Must be integer
X-Selected-Tenant-Id: "1"        # No quotes in header value
```

### 3. Error Handling

Update your error handling to catch the new validation errors:

```javascript
try {
  const response = await fetch('/api/superuser/tenants/123', {
    method: 'GET',
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-Selected-Tenant-Id': '123'
    }
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail);
  }

  return await response.json();
} catch (error) {
  if (error.message.includes('X-Selected-Tenant-Id header is required')) {
    console.error('Missing required tenant header:', error.message);
    // Handle missing header error
  } else if (error.message.includes('Invalid X-Selected-Tenant-Id format')) {
    console.error('Invalid tenant ID format:', error.message);
    // Handle invalid format error
  } else if (error.message.includes('must match')) {
    console.error('Tenant ID mismatch:', error.message);
    // Handle mismatch error
  } else {
    console.error('API error:', error.message);
    // Handle other errors
  }
}
```

### 4. Common Client Patterns

#### React/JavaScript Frontend
```javascript
// Create a superuser API client with automatic header injection
class SuperuserApiClient {
  constructor(baseUrl, getAuthToken) {
    this.baseUrl = baseUrl;
    this.getAuthToken = getAuthToken;
  }

  async request(endpoint, options = {}, tenantId = null) {
    const headers = {
      'Authorization': 'Bearer ' + this.getAuthToken(),
      'Content-Type': 'application/json',
      ...options.headers
    };

    // Add tenant header if provided
    if (tenantId) {
      headers['X-Selected-Tenant-Id'] = tenantId.toString();
    }

    const response = await fetch(this.baseUrl + endpoint, {
      ...options,
      headers
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail);
    }

    return await response.json();
  }

  // Tenant operations - header required
  async getTenant(tenantId) {
    return this.request(`/superuser/tenants/${tenantId}`, {}, tenantId);
  }

  async updateTenant(tenantId, data) {
    return this.request(`/superuser/tenants/${tenantId}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    }, tenantId);
  }

  // Global operations - header optional
  async listTenants() {
    return this.request('/superuser/tenants');
  }
}
```

#### Python Client
```python
import requests
from typing import Optional

class SuperuserApiClient:
    def __init__(self, base_url: str, get_auth_token):
        self.base_url = base_url
        self.get_auth_token = get_auth_token

    def _request(self, endpoint: str, method: str = 'GET',
                 json_data: Optional[dict] = None, tenant_id: Optional[int] = None):
        headers = {
            'Authorization': f'Bearer {self.get_auth_token()}',
            'Content-Type': 'application/json'
        }

        # Add tenant header if provided
        if tenant_id:
            headers['X-Selected-Tenant-Id'] = str(tenant_id)

        response = requests.request(
            method=method,
            url=self.base_url + endpoint,
            headers=headers,
            json=json_data
        )

        response.raise_for_status()
        return response.json()

    # Tenant operations - header required
    def get_tenant(self, tenant_id: int):
        return self._request(f'/superuser/tenants/{tenant_id}', tenant_id=tenant_id)

    def update_tenant(self, tenant_id: int, data: dict):
        return self._request(f'/superuser/tenants/{tenant_id}', 'PUT', data, tenant_id)

    # Global operations - header optional
    def list_tenants(self):
        return self._request('/superuser/tenants')
```

#### curl Examples
```bash
# Tenant-specific operation (header required)
curl -X GET "https://api.example.com/api/superuser/tenants/123" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Selected-Tenant-Id: 123" \
  -H "Content-Type: application/json"

# Global operation (header optional)
curl -X GET "https://api.example.com/api/superuser/tenants" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json"

# User operation (header must match user's tenant)
curl -X PUT "https://api.example.com/api/superuser/users/user-456/status" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Selected-Tenant-Id: 789" \
  -H "Content-Type: application/json" \
  -d '{"is_active": true}'
```

## Error Messages

The API will return helpful error messages with examples:

### Missing Header
```json
{
  "detail": "X-Selected-Tenant-Id header is required for cross-tenant operations. Example: X-Selected-Tenant-Id: 123"
}
```

### Invalid Format
```json
{
  "detail": "Invalid X-Selected-Tenant-Id format. Must be a positive integer. Example: X-Selected-Tenant-Id: 123"
}
```

### Tenant Not Found
```json
{
  "detail": "Tenant 999 not found or has been deleted"
}
```

### Tenant Mismatch
```json
{
  "detail": "X-Selected-Tenant-Id (123) must match the requested tenant ID (456)"
}
```

### User Tenant Mismatch
```json
{
  "detail": "X-Selected-Tenant-Id (123) must match the user's tenant ID (456)"
}
```

## Testing Your Migration

### 1. Verify Header Requirements
Test each endpoint to ensure headers are properly included:

```bash
# Test missing header (should fail)
curl -X GET "https://api.example.com/api/superuser/tenants/123" \
  -H "Authorization: Bearer $TOKEN"
# Expected: 400 Bad Request

# Test with header (should succeed)
curl -X GET "https://api.example.com/api/superuser/tenants/123" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Selected-Tenant-Id: 123"
# Expected: 200 OK
```

### 2. Validate Error Handling
Test your error handling with invalid headers:

```bash
# Test invalid format
curl -X GET "https://api.example.com/api/superuser/tenants/123" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Selected-Tenant-Id: abc"
# Expected: 400 Bad Request with format error

# Test tenant mismatch
curl -X GET "https://api.example.com/api/superuser/tenants/123" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Selected-Tenant-Id: 456"
# Expected: 400 Bad Request with mismatch error
```

### 3. Check Security Audit Logs
Verify that your API calls are properly logged for security auditing:
- Check application logs for "SECURITY: Superuser cross-tenant access" entries
- Ensure tenant context is correctly recorded in audit trails

## Rollback Plan

If you need to rollback this change temporarily:

1. The original endpoints will continue to work once the header requirement is restored
2. No database schema changes were made
3. Client code without headers will work again after rollback
4. Audit logging will revert to previous format

## FAQ

### Q: Do I need to update all superuser API calls?
**A**: Only tenant-specific operations require the header. Global operations like listing all tenants are optional.

### Q: What if I'm calling the API from a browser?
**A**: Add the header to your fetch/axios requests as shown in the JavaScript examples above.

### Q: Can I use the same header value for multiple API calls?
**A**: Yes, if you're working within the same tenant context. Change the header value when switching tenant contexts.

### Q: What happens if I provide the wrong tenant ID?
**A**: The API will return a 400 Bad Request error indicating the mismatch between the header and the requested resource.

### Q: Are there any performance impacts?
**A**: Minimal. The header validation adds only a small overhead for tenant existence checking.

## Support

If you encounter issues during migration:

1. Check the error messages - they include helpful examples
2. Verify your header format matches the requirements
3. Ensure tenant IDs exist and are active
4. Test with curl first to isolate client-side issues
5. Check application logs for detailed error information

## Timeline

- **Immediate**: All new superuser API calls must include headers
- **Grace Period**: None - this is an immediate breaking change
- **Enforcement**: Active immediately upon deployment

This migration is required for security compliance and cannot be made backward-compatible due to the security implications of cross-tenant operations.
