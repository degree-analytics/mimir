# 🚫 ABSOLUTE SAFETY RULES

## NEVER WITHOUT PERMISSION:
1. **Source Control**: NO gt/git commands except read-only (`git status`, `git diff`)
2. **Deployments**: NO `just aws_deploy_*` or infrastructure changes
3. **AWS Resources**: NO manual AWS CLI/console modifications
4. **🚨 PRODUCTION MODE ACTIVATION**: NEVER run `just prod enable` or any command that enables production mode

## 🛡️ PRODUCTION SAFETY CRITICAL RULES:
- **NEVER ENABLE** production mode (`just prod enable`) - ALWAYS tell user to enable it
- **CAN DISABLE** production mode (`just prod disable`) when needed for safety
- **CAN DEPLOY** to production IF user has enabled production mode AND we agree on the action
- **MUST VERIFY** production mode is active before any production deployments

## ✅ ALWAYS ASK FIRST:
- "Should I run [specific command]?" → Wait for explicit "yes"
- "Please enable production mode with: just prod enable [minutes]" → Wait for user confirmation

## 🚨 SPECIFIC DANGEROUS COMMANDS - NEVER RUN WITHOUT PERMISSION:

### Git Operations (Except Read-Only)
- `git push` → Can affect shared repository
- `git commit` → Only with explicit user request
- `git reset --hard` → Destroys uncommitted work
- `git branch -D` → Deletes branches permanently
- `gt submit` → Creates/modifies pull requests

### Database Operations
- `just db clean` → Removes demo data (preserves foundation data)
- `DROP TABLE`, `DELETE FROM` → Data loss
- Any `alembic downgrade` → Potential data loss

### AWS/Production Operations
- `just prod enable` → Enables production mode
- `just aws_deploy_* prod` → Production deployments
- `just aws_delete_*` → Resource deletion
- `just aws_nuclear_cleanup` → Force deletes resources
- Any `aws` command that modifies resources

### File System Operations
- `rm -rf` → Permanent file deletion
- `sudo` commands → System-level changes
- Any operation outside project directory → System impact

### Docker/Infrastructure
- `docker system prune` → Removes Docker resources
- `just clean` → Removes build artifacts
- `docker compose down -v` → Removes volumes/data
