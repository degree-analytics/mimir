# 🎯 INTERACTIVE SELECTION PATTERN

## Overview
When presenting multiple options, issues, or tasks that need user input, always use numbered lists with visual priority indicators for clarity and easy selection.

## Core Pattern

### ✅ CORRECT Format
```
Found 4 issues that need attention:

[1] 🔴 Migration dependency broken
    File: migrations/a9e5415ac7b4.py
    Error: KeyError in alembic history

[2] 🟡 Dummy user pattern issue
    File: ai/shared_utils.py
    Warning: Hardcoded tenant ID

[3] 🔴 Backend tests failing
    Error: 5 tests failed in test_room_attributes

[4] 🔵 Code formatting issues
    Files: 3 files need formatting

→ Which should I fix? Reply with numbers (e.g., "1,3" or "all"):
```

### ❌ INCORRECT Format
```
Found these issues:
- Migration dependency is broken
- Dummy user pattern needs fixing
- Tests are failing
- Code formatting issues

What should I do?
```

## Priority Indicators

Use visual markers to indicate severity/priority:
- 🔴 **Critical/High** - Must fix, blocking issues
- 🟡 **Medium** - Should fix, impacts functionality
- 🟢 **Low** - Nice to have, minor improvements
- 🔵 **Info/Style** - Optional, code quality

## Selection Format Support

Accept flexible user responses:

### Supported Input Formats
- **Numbers**: `1,3` or `1 3` or `1 and 3`
- **Ranges**: `1-3` (selects items 1, 2, and 3)
- **All**: `all` or `*`
- **Exclusions**: `all except 2` or `not 4`
- **Single**: `just 1` or `only 2`
- **None**: `none` or `skip`
- **Priority-based**: `critical` or `high priority`

### Example Processing
```python
# User input: "1,3-5, 7"
# Parsed as: [1, 3, 4, 5, 7]

# User input: "all except 2,4"
# Parsed as: [1, 3, 5, 6, 7, 8] (if 8 items total)

# User input: "critical"
# Parsed as: All items marked with 🔴
```

## Use Cases

### 1. Error Resolution
```
Build failed with 3 errors:

[1] 🔴 TypeScript error in UserForm.tsx:45
    Property 'email' does not exist on type 'User'

[2] 🔴 Import error in api.ts:12
    Cannot find module '@/types/user'

[3] 🟡 ESLint warning in utils.ts:89
    'userId' is assigned but never used

→ Fix which errors first? (e.g., "1,2" or "all"):
```

### 2. PR Review Comments
```
PR has 5 review comments to address:

[1] 🔴 Security: SQL injection vulnerability
    Line 45: Use parameterized queries

[2] 🟡 Performance: N+1 query issue
    Line 78: Consider eager loading

[3] 🔵 Style: Variable naming
    Line 23: Use camelCase not snake_case

[4] 🟡 Logic: Missing null check
    Line 91: Check if user exists

[5] 🟢 Documentation: Add function comment
    Line 12: Document return type

→ Which comments should I address? (e.g., "1,2,4" or "critical"):
```

### 3. File Updates
```
Migration affects 6 files:

[1] models/user.py - Add new field
[2] schemas/user.py - Update validation
[3] routers/users.py - Handle new field
[4] tests/test_users.py - Update tests
[5] migrations/add_field.py - Create migration
[6] docs/api.md - Update documentation

→ Which files should I update? (e.g., "1-4" or "all"):
```

### 4. Test Failures
```
Test suite has 4 failures:

[1] 🔴 test_user_creation - Database error
    AssertionError: User not found in database

[2] 🔴 test_authentication - Token invalid
    ValueError: JWT signature verification failed

[3] 🟡 test_email_sending - Timeout
    TimeoutError: SMTP connection timed out

[4] 🟢 test_ui_rendering - Snapshot mismatch
    Component rendering differs from snapshot

→ Which tests should I fix? (e.g., "1,2" for critical):
```

## Implementation Guidelines

### 1. Always Include Context
Each item should have:
- Clear description of the issue/task
- File location or component affected
- Error message or specific details
- Severity indicator

### 2. Group Related Items
When many items exist, group by:
- Component (backend, frontend, mobile)
- Severity (critical first, then medium, then low)
- Type (errors, warnings, suggestions)
- File/module affected

### 3. Provide Clear Instructions
- Always end with a clear prompt
- Give example input formats
- Mention special keywords like "all" or "critical"

### 4. Handle Edge Cases
```
No critical issues found.

Found 2 minor issues:
[1] 🔵 Unused import in utils.py
[2] 🔵 Extra whitespace in config.json

→ Fix these minor issues? (yes/no/1/2/all):
```

## Advanced Patterns

### Nested Selections
```
Choose implementation approach:

[1] Quick fix (15 min)
    - Patch the immediate issue
    - Minimal code changes
    - May need revisiting

[2] Proper refactor (2 hours)
    - Fix root cause
    - Update tests
    - Better long-term solution

[3] Full redesign (1 day)
    - Architectural changes
    - Migration required
    - Most maintainable

→ Which approach? (1/2/3):
```

### Progressive Disclosure
```
Initial scan found issues in 3 areas:

[1] Database (5 issues)
[2] API (3 issues)
[3] Frontend (8 issues)

→ Which area to investigate? (1/2/3/all):

[User selects: 1]

Database issues:
[1.1] 🔴 Migration conflict
[1.2] 🔴 Missing index on users.email
[1.3] 🟡 Deprecated column still referenced
[1.4] 🟡 Connection pool too small
[1.5] 🔵 Naming convention violation

→ Which database issues to fix? (e.g., "1.1,1.2" or "all"):
```

## Integration with SpaceWalker

This pattern is especially useful for:
- TaskMaster task selection
- Build error resolution
- Test failure prioritization
- PR review comment addressing
- Migration conflict resolution
- Multi-tenant issue debugging

## Remember
- Always use numbered lists for multiple items
- Include visual priority indicators
- Provide clear selection instructions
- Accept flexible input formats
- Group and organize large lists
- Give context for each item