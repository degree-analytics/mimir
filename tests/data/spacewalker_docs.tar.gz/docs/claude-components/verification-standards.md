# 🚨 VERIFICATION BEFORE COMPLETION (MANDATORY)

**NEVER mark a task as "done" without verification. The word "done" is a CONTRACT that means:**
- Implementation complete AND verified working
- NOT "I think this should work" or "Code looks correct"
- ONLY "I have confirmed this works as expected"

## Required Verification Methods:

### Automated Testing (Preferred)
**🚫 CRITICAL: NEVER use pytest directly - ALWAYS use justfile commands:**

```bash
# Backend changes
just test unit backend           # Unit tests (REQUIRED)
just test integration backend    # Integration tests (REQUIRED for backend changes)

# Admin changes
just test unit admin            # React component tests

# Mobile changes
just test unit mobile           # React Native tests

# Full verification
just test all all                   # Complete test suite
```

**❌ ANTI-PATTERNS - NEVER DO THIS:**
```bash
pytest tests/unit/              # Use `just test unit backend` instead
pytest tests/integration/       # Use `just test integration backend` instead
npm run test                    # Use `just test unit admin` instead
```

### Integration Test Requirements (MANDATORY for Backend Changes)
**For ANY backend code changes, integration tests MUST be executed successfully before marking tasks complete.**

#### Required Integration Test Verification
```bash
# Minimum requirement for backend changes
just test unit backend && just test integration backend

# Alternative filter-based testing for specific functionality
just test integration backend --filter="test_email*"     # Email-related changes
just test integration backend --filter="test_auth*"      # Authentication changes
just test integration backend --filter="test_tenant*"    # Tenant-related changes
```

#### Integration Test Status Requirements
- **✅ PASS**: All integration tests must pass (exit code 0)
- **❌ TIMEOUT**: If tests timeout, run specific patterns or file-by-file
- **⚠️ WARNINGS**: Pydantic deprecation warnings are acceptable but should be noted
- **🔍 COVERAGE**: Integration tests are exempt from coverage requirements

#### Known Integration Test Issues
Based on recent fixes and current status:

1. **Token Matching**: Fixed - Dynamic token generation resolves hardcoded mismatches
2. **LocalStack Email**: Fixed - Proper async delays for email processing
3. **Performance**: Some tests may timeout - use pattern matching for specific areas
4. **Deprecation Warnings**: Pydantic V1 validators cause warnings but tests still pass

### Code Quality Verification
```bash
# Lint checking
just lint check all                 # Check all code quality issues
just lint check backend             # Backend Python linting
just lint check admin               # Admin TypeScript linting
just lint check mobile              # Mobile TypeScript linting
just lint check all --ci            # CI-style strict linting

# Auto-formatting
just lint format all                # Format all code
just lint format backend            # Format backend code
just lint format admin              # Format admin code
just lint format mobile             # Format mobile code
```

### Environment & Service Verification
```bash
# Health checks
just health local                   # Check local environment health
just health dev                     # Check dev environment health
just wait dev                       # Wait for services to be ready

# Database verification
just db verify                      # Verify database state and consistency
just db verify dev                  # Verify dev database

# Service URLs
just urls local                     # Get local service URLs
just urls dev                       # Get dev service URLs
```

### Screenshot Verification (LOCAL DEVELOPMENT ONLY)
**CRITICAL**: For ANY layout, spacing, or visual changes, screenshot verification is REQUIRED during **local development**:

```bash
# LOCAL DEVELOPMENT: Visual verification methods (in priority order)

# 1. PRIMARY: Chrome DevTools MCP (preferred for interactive development)
mcp__chrome-devtools__navigate_page  # Navigate to the page
mcp__chrome-devtools__take_screenshot  # Capture visual state
mcp__chrome-devtools__take_snapshot   # Get page structure

# 2. SECONDARY: Playwright MCP (for automated test scenarios)
mcp__playwright__browser_navigate     # When chrome-devtools unavailable

# 3. FALLBACK: Traditional methods
npx playwright test --headed           # Run tests with browser UI
# Browser dev tools: Right-click → Inspect → Screenshots tab
# Manual browser testing on localhost:3000
```

**Why Screenshots Are Required (Local Development):**
- Accessibility snapshots DO NOT show visual spacing/layout issues
- Material-UI Container components have hidden width constraints
- CSS layout changes may not be apparent in code-only verification
- Layout "fixes" often fail silently without visual confirmation

**LOCAL DEVELOPMENT Process:**
1. **Take screenshot BEFORE** claiming any layout fix works
2. **Test in browser** at localhost:3000
3. **Verify on multiple screen sizes** (mobile, tablet, desktop)
4. **Only claim success** after visual confirmation

**GitHub PR Environment:**
- **NO screenshot uploads required** in PR comments
- **Document verification completed locally** in commit messages
- **Use descriptive commit messages** describing what was verified
- Example: `fix: improve survey table width utilization (verified 1920px, 1440px, 768px)`

### Manual Testing (When No Tests Exist)
**Documentation Requirements:**
- List exact steps performed
- Include commands run and their output
- Note any edge cases tested
- Document expected vs actual behavior

**Example Manual Verification:**
```
Verified by:
1. Started services: `just up`
2. Navigated to feature at /buildings/new
3. Tested form validation with invalid inputs
4. Confirmed error messages display correctly
5. Submitted valid form and verified database entry
Results: All functionality works as expected
```

⚠️ **CRITICAL**: Claiming completion without verification breaks project trust

## Pre-Completion Checklist:

### Discover Test Requirements
```bash
# Find existing test files
find . -name "*test*" -o -name "*spec*" | rg "\.(js|ts|py)$"

# Check for test patterns
just help | grep test           # Available test commands
rg "test" package.json     # NPM test scripts
find . -name pytest.ini -o -name jest.config.js  # Test configs
```

### Domain-Specific Verification
- **Backend**: Database migrations, API endpoints, authentication + **MANDATORY integration tests**
- **Admin**: UI components, form validation, routing
- **Mobile**: Device compatibility, offline functionality
- **Infrastructure**: Service health, deployment success

### Integration Test Verification Checklist (Backend Changes)
Before marking any backend task as complete, verify:
- [ ] Unit tests pass: `just test unit backend`
- [ ] Integration tests pass: `just test integration backend`
- [ ] If integration tests timeout: Run relevant pattern-based tests
- [ ] Document any warnings or timeouts encountered
- [ ] Confirm no breaking changes to existing functionality

### Verification Evidence Required
**For Unit Test Results:**
```
✅ Unit tests passed: just test unit backend
Results: 363 tests passed, 0 failed, 1 skipped, coverage 79.93%
```

**For Integration Test Results (Required for Backend Changes):**
```
✅ Integration tests passed: just test integration backend
Results: 156 tests passed, 0 failed, 23 skipped
Duration: 5m 32s
Warnings: 105 Pydantic deprecation warnings (acceptable)
```

**For Pattern-Based Integration Testing:**
```
✅ Email integration tests: just test integration backend --pattern="test_email*"
Results: 13 tests passed, 0 failed
Files: test_email_localstack.py, test_localstack_email_content.py
```

**For Manual Testing (When Integration Tests Not Available):**
```
✅ Manual verification completed:
1. Feature X tested with scenarios A, B, C
2. Edge cases handled: empty input, malformed data
3. Error conditions verified: proper error messages
4. Performance acceptable: <2s response time
5. Integration verified: Database state, external service calls
```

**If tests timeout or fail**: Document specific workarounds used and results achieved
