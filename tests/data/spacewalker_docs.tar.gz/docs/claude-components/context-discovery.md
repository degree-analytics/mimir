# 🔍 CONTEXT DISCOVERY & SEARCH PATTERNS

## Search Tool Hierarchy (MANDATORY)

**Use the right tool for the right job - prioritize structural analysis over text search:**

### Priority Order (ALWAYS follow this hierarchy)

## 1. 🔧 ast-grep (sg) - Structural Code Analysis
**Primary use**: Code structure, syntax patterns, AST-based analysis
**When to use**: Finding function definitions, class hierarchies, import patterns, code patterns
**Command patterns**:
```bash
# Find function definitions
sg --pattern 'def $_($_) { $$$ }' --lang python
sg --pattern 'function $_($_) { $$$ }' --lang typescript

# Find class definitions
sg --pattern 'class $_ { $$$ }' --lang python
sg --pattern 'class $_ extends $_ { $$$ }' --lang typescript

# Find API endpoints
sg --pattern 'api.$_($_)' apps/admin/src/
sg --pattern '@app.route($_)' apps/backend/

# Find React components
sg --pattern 'function $_($_): JSX.Element { $$$ }' --lang typescript
sg --pattern 'const $_ = ($_) => { $$$ }' --lang typescript

# Find imports
sg --pattern 'import { $_ } from "$_"' --lang typescript
sg --pattern 'from $_ import $_' --lang python
```

## 2. 🔍 ripgrep (rg) - High-Performance Text Search
**Primary use**: Text content search, file filtering, fast regex matching
**When to use**: Finding error messages, configuration values, API endpoints, text patterns
**Command patterns**:
```bash
# Basic text search
rg "search-term"
rg "403 Forbidden" --type py

# With line numbers
rg -n "jwt.*token" --type typescript

# Case insensitive
rg -i "error" apps/backend/

# File type filtering
rg "T.D.O" --type js --type ts       # Search for task items

# Glob patterns
rg "import.*User" --glob "*.tsx"

# Exclude directories
rg "password" --glob "!node_modules" --glob "!.venv"

# Context lines
rg -C 3 "database_url"  # 3 lines before and after

# Files with matches only
rg -l "test.*integration"
```

## 3. 📝 grep - Command Output Processing ONLY
**Primary use**: Processing output from other commands (NOT for file search)
**When to use**: Filtering command output, pipeline text processing
**Command patterns**:
```bash
# ✅ CORRECT - Processing command output
just help | grep test
docker ps | grep spacewalker
git log --oneline | grep fix
ps aux | grep python

# ❌ WRONG - Never use for file search
grep -r "function" apps/  # Use sg or rg instead
find . -exec grep "api" {} \;  # Use rg instead
```

## SpaceWalker Documentation Search

### Internal Documentation (`just docs`)
**Purpose**: Search project-specific patterns, decisions, and implementation details
```bash
# Basic search
just docs search "rate limiting"

# With options
just docs search "authentication" --limit 10
just docs search "tenant isolation" --format llm

# Advanced search strategies
just docs search "deployment patterns"
just docs search "testing strategies"
just docs search "error handling"
```

### Context7 MCP (Library Documentation)
**Purpose**: Third-party library and framework documentation
```python
# Step 1: Resolve library ID
mcp__context7__resolve-library-id("fastapi")

# Step 2: Get documentation
mcp__context7__get-library-docs(
    context7CompatibleLibraryID="/tiangolo/fastapi",
    tokens=5000,
    topic="authentication"
)
```

## Search Strategy Workflows

### 🐛 Bug Investigation Workflow
```bash
# 1. Find error message origin
rg "error message text" --type py

# 2. Find function definition
sg --pattern 'def $_($_)' apps/backend/ | grep function_name

# 3. Find all usages
sg --pattern 'function_name($_)' apps/

# 4. Check test coverage
rg "test.*function_name" tests/

# 5. Review documentation
just docs search "function_name"
```

### 🏗️ Architecture Understanding
```bash
# 1. Find main entry points
sg --pattern '@app.route($_)' apps/backend/
sg --pattern 'export default function $_' apps/admin/

# 2. Trace dependencies
sg --pattern 'import.*from "$_"' --lang typescript
sg --pattern 'from $_ import' --lang python

# 3. Find configuration
rg "DATABASE_URL|API_KEY|SECRET" --glob "*.env*"

# 4. Understand patterns
just docs search "architecture patterns"
```

### 🔍 Feature Development Research
```bash
# 1. Find similar implementations
sg --pattern 'class $_Controller' apps/
rg "similar_feature" --type py

# 2. Check existing patterns
just docs search "feature_area"

# 3. Find related tests
rg "test.*feature" tests/

# 4. Review library docs
# Use Context7 for framework documentation
```

## Anti-Patterns to AVOID

### ❌ WRONG Approaches
```bash
# Don't use grep for file content
grep -r "function" apps/admin/src/

# Don't use find with grep
find . -name "*.py" -exec grep "class" {} \;

# Don't use basic text search for code structure
rg "function.*useState"  # Use sg for structural patterns

# Don't search without context
rg "error"  # Too broad, add context
```

### ✅ CORRECT Approaches
```bash
# Use sg for code structure
sg --pattern 'const [$_] = useState($_)' --lang typescript

# Use rg for content with context
rg "error" --type py -C 3 apps/backend/

# Use grep only for command output
docker logs backend | grep ERROR

# Search with specific patterns
sg --pattern 'catch ($_) { $$$ }' --lang typescript
```

## File Discovery Patterns

### Finding Files by Name
```bash
# Using fd (if available)
fd "test.*\.py$"
fd -e tsx Button

# Using find
find . -name "*test*.py"
find apps -name "*.tsx" -type f

# Using rg to list files
rg --files | rg "test"
```

### Finding Files by Content
```bash
# Files containing specific text
rg -l "DatabaseConnection"

# Files with specific patterns
sg --pattern 'class $_ extends Component' -l

# Files modified recently
find . -type f -mtime -7 | xargs rg "T.D.O"    # Find task items in recent files
```

## Performance Tips

### 1. Use Type Filters
```bash
# Faster - with type filter
rg "search" --type py

# Slower - without filter
rg "search"
```

### 2. Use Glob Patterns
```bash
# Faster - specific glob
rg "pattern" --glob "apps/backend/**/*.py"

# Slower - searching everything
rg "pattern"
```

### 3. Exclude Unnecessary Directories
```bash
# Always exclude these
--glob "!node_modules"
--glob "!.venv"
--glob "!.git"
--glob "!build"
--glob "!dist"
```

### 4. Use Parallel Search
```bash
# ripgrep is parallel by default
rg "pattern"  # Uses all CPU cores

# For sg, results are also parallel
sg --pattern 'pattern'  # Parallel by default
```

## Integration with SpaceWalker Workflows

### 1. Before Making Changes
```bash
# Understand existing patterns
sg --pattern 'similar_function' apps/
just docs search "feature area"
```

### 2. During Development
```bash
# Find examples to follow
sg --pattern 'test_$_' tests/
rg "similar implementation" --type py
```

### 3. Before Committing
```bash
# Check for task items
rg "T.D.O|FIX.ME|X.X.X"           # Search for development notes

# Find console.logs or prints
rg "console\.log|print\(" --type tsx --type py
```

### 4. During Review
```bash
# Find all changes to specific patterns
git diff | grep "^+" | rg "pattern"

# Check test coverage
rg "test.*new_feature" tests/
```

## Remember

1. **Structure over Text**: Use `sg` for code patterns, `rg` for content
2. **Right Tool**: Never use `grep` for file search
3. **Be Specific**: Add context, types, and patterns
4. **Exclude Noise**: Always exclude node_modules, .venv, etc.
5. **Combine Tools**: Use multiple tools in sequence for complex searches
6. **Document Search**: Use `just docs search` for project patterns
7. **Library Docs**: Use Context7 for framework documentation