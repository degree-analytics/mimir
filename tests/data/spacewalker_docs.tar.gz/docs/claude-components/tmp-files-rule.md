# 📁 TEMPORARY FILES RULE (ROOT LEVEL)

## 🚫 NEVER use /tmp/ for temporary files

**Problem**: Writing to `/tmp/` requires user permission every time, breaking workflow and automation.

**Solution**: ALWAYS use `.build/tmp/` within the project directory.

## ✅ CORRECT Pattern

```bash
# Create tmp directory if needed (no permission required)
mkdir -p .build/tmp

# Write temporary files
echo "test data" > .build/tmp/test-output.log
just test all backend 2>&1 | tee .build/tmp/test-results.txt

# Use in scripts
TEMP_FILE=".build/tmp/analysis-$(date +%s).json"
```

## ❌ INCORRECT Pattern (NEVER DO THIS)

```bash
# WRONG - requires permission
echo "data" > /tmp/test.txt
curl -o /tmp/response.json https://api.example.com
just test all backend > /tmp/test-output.log
```

## 📋 Common Use Cases

### 1. Test Output Capture
```bash
# Capture test output for analysis
mkdir -p .build/tmp
just test all backend 2>&1 | tee .build/tmp/test-output.log
rg "FAILED" .build/tmp/test-output.log
```

### 2. API Response Caching
```bash
# Cache API responses
mkdir -p .build/tmp
curl -s https://api.github.com/repos/owner/repo > .build/tmp/github-response.json
```

### 3. Script Intermediate Files
```bash
# Multi-step processing
mkdir -p .build/tmp
rg "ERROR" logs/*.log > .build/tmp/errors-raw.txt
sort .build/tmp/errors-raw.txt | uniq > .build/tmp/errors-unique.txt
```

### 4. Build Artifacts
```bash
# Temporary build files
mkdir -p .build/tmp
npm run build -- --output-path .build/tmp/dist
```

## 🎯 Implementation in Scripts

### Python Scripts
```python
import os
from pathlib import Path

# Create tmp directory
tmp_dir = Path(".build/tmp")
tmp_dir.mkdir(parents=True, exist_ok=True)

# Use for temporary files
temp_file = tmp_dir / f"analysis-{int(time.time())}.json"
with open(temp_file, 'w') as f:
    json.dump(data, f)
```

### Bash Scripts
```bash
#!/bin/bash
# Ensure tmp directory exists
TMP_DIR=".build/tmp"
mkdir -p "$TMP_DIR"

# Use for all temporary files
TEMP_LOG="$TMP_DIR/script-output-$$.log"
TEMP_DATA="$TMP_DIR/processed-data-$$.json"
```

## 🗑️ Cleanup Strategy

### Add to .gitignore
```
# Temporary files
.build/tmp/
```

### Add cleanup command to justfile
```just
# Clean temporary files
clean-tmp:
    @echo "🗑️ Cleaning temporary files..."
    @rm -rf .build/tmp/*
    @echo "✅ Temporary files cleaned"

# Full clean including tmp
clean-all: clean clean-tmp
    @echo "✅ All build artifacts and temporary files cleaned"
```

## 📍 Benefits

1. **No permission prompts** - Files stay within project directory
2. **Automatic cleanup** - Part of project's .gitignore and clean commands
3. **Predictable location** - Always know where temp files are
4. **Project isolation** - No conflicts with system temp files
5. **CI/CD friendly** - Works in any environment without special permissions

## 🔧 Retroactive Fix

For any existing scripts using /tmp/:
```bash
# Find all references
rg "/tmp/" scripts/ docs/ justfile

# Replace with .build/tmp/
# Example: sed -i 's|/tmp/|.build/tmp/|g' script.sh
```

## 📝 Add to CLAUDE.md

This rule should be added to the root CLAUDE.md as:

```markdown
## 🚫 TEMPORARY FILES - NEVER USE /tmp/

**MANDATORY**: Always use `.build/tmp/` for temporary files
- Create with: `mkdir -p .build/tmp`
- Never requires permission
- Automatically gitignored
- Cleaned with `just clean-tmp`

Examples:
- ✅ `.build/tmp/test-output.log`
- ❌ `/tmp/test-output.log`
```
