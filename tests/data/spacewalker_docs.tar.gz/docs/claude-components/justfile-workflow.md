# 🎯 JUSTFILE FIRST, ALWAYS

**Workflow**: Need command? → `just help` → Find it → Use it

**Anti-pattern**: Running `docker`, `aws`, `npm` directly when justfile equivalents exist

## Core Philosophy
- Justfiles provide standardized, project-specific command interfaces
- They encapsulate complex multi-step operations
- They ensure consistent environments and parameters
- Always check justfile before reaching for underlying tools

## Command Discovery Examples

### ✅ CORRECT Pattern
```bash
just help                    # Discover available commands first
just health dev              # Use discovered standardized command
just test unit backend       # Use project-specific test command
alembic upgrade head         # Use database automation (run in backend dir)
```

### ❌ ANTI-PATTERNS to Avoid
```bash
aws ecs describe-services    # Don't use AWS CLI directly
docker compose up backend    # Use `just service up backend` instead
pytest tests/unit/          # Use `just test unit backend` instead
npm run test                 # Use `just test unit admin` instead
```

## Common Command Categories

### Development Workflow
- **Environment**: `just env_setup`, `just service up all`, `just service down all`, `just health`
- **Testing**: `just test unit all`, `just test integration all`, `just dev_cycle`
- **Code Quality**: `just lint check all`, `just lint format all`, `just format`

### Database Operations
- **Safe**: `just db init`, `just db seed`, `just db verify`
- **🚨 Nuclear**: `just db clean-all-non-system-tenants` (removes ALL customer data, keeps System)
- **🚨 Nuclear**: `just db wipe-all` (deletes ALL data + resets sequences)
- **🚨 Physical**: `just db reset-physical` (LOCAL ONLY - destroys schema)
- **Shell Access**: `just db shell` (interactive PostgreSQL)
- **SQL Queries**: `just sql "SELECT * FROM users"` (safe query execution)

### AWS/Cloud Operations
- **Health & URLs**: `just health dev`, `just urls dev`, `just aws status all dev`
- **Deployment**: `just aws deploy backend dev`, `just aws status all dev`
- **Secrets**: `just secrets list dev`, `just secrets show dev --secret-name api-keys`
- **CloudFormation**: `just stack status dev`, `just stack inspect dev backend`, `just stack events dev backend`
- **Debugging**: `just logs backend dev`, `just aws debug dev`

### Specialized Tools
- **Mobile**: `just expo ip auto`, `just shell mobile`
- **CLAUDE.md**: `just claude validate`, `just claude memory`

## Workflow Examples

### Daily Development
```bash
just service up all          # Start services
just health                  # Verify readiness
just dev_cycle              # Fast: lint + unit tests (30-60 sec)
# Work on features...
just dev_cycle              # Quick validation after changes
just test all all           # Comprehensive check before committing
```

### Database Changes
```bash
just db verify              # Check current state
# Create migration manually if needed
alembic upgrade head        # Apply changes (in backend dir)
just db seed                # Refresh test data
```

### Deployment Process
```bash
just health dev           # Pre-deployment check
just aws deploy backend dev # Deploy changes
just health dev           # Post-deployment verification
```

## When Direct Commands Are Acceptable

**Limited cases for direct usage:**
- Git operations: `git status`, `git diff` (read-only)
- File operations: `ls`, `cat`, `grep` (simple inspection)
- Creating migrations: `alembic revision --autogenerate -m "msg"`

**Always use justfile for:**
- Multi-step operations
- Environment-specific commands
- Complex parameter combinations
- Frequently repeated tasks

## Handling Special Characters in Arguments

When justfile commands need to handle arguments with special characters (parentheses, quotes, spaces), use the `[positional-arguments]` attribute. See the [Justfile Special Characters Guide](../development/justfile-special-characters-guide.md) for details.

**Quick Example:**
```bash
# This now works with parentheses in the title:
just gh-pr edit 327 --title="feat(deployment): comprehensive verification (prevents rollbacks)"
```
