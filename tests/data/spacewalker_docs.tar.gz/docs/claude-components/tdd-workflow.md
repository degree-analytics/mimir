# 🧪 TEST-DRIVEN DEVELOPMENT WORKFLOW

**CORE PRINCIPLE**: Write QA-quality tests first to provide clear, measurable implementation targets and ensure design quality.

## 🚨 MANDATORY TDD PROCESS

**For all new code changes and bug fixes**: Tests must be written BEFORE implementation.

### 1. **Test Discussion Phase** (REQUIRED)
AI must propose test scenarios and get human approval before implementing:

```
## Proposed Tests for [Feature/Bug Fix Name]

**Problem**: [Brief description of what we're solving]

**Unit Tests** (isolated, fast, mocked dependencies):
[1] 🧪 [Specific behavior test - what should happen]
[2] 🧪 [Edge case test - boundary condition]
[3] 🧪 [Error handling test - what should fail]

**Integration Tests** (real APIs, LocalStack for AWS):
[4] 🧪 [End-to-end workflow test]
[5] 🧪 [Database/external service integration test]
[6] 🧪 [AWS service test using LocalStack]

**Selective Test Execution**:
`just test unit backend --filter=test_auth*`
`just test integration backend --filter=test_localstack_email*`

→ These tests simulate real user behavior and failure modes.
→ Do these cover the right scenarios? Any missing edge cases?
```

### 2. **Red-Green-Refactor Cycle** (After approval)

**AI Development Cycle (Fast Feedback)**:
1. **RED**: Write failing unit tests based on approved plan
2. **GREEN**: Write minimal code to make unit tests pass
3. **REFACTOR**: Improve code while keeping unit tests green

**Human/CI Verification (Slower, Complete)**:
4. Human runs integration tests or leaves to CI
5. Integration test failures require additional development cycles

## 🎯 TEST QUALITY STANDARDS (F.I.R.S.T)

### **QA Professional Testing Mindset**
- **Fast**: Quick execution to encourage frequent running
- **Independent**: Tests don't depend on other tests or external state
- **Repeatable**: Same results every time, any environment
- **Self-validating**: Clear pass/fail without manual verification
- **Thorough**: Cover edge cases, error conditions, and real user scenarios

### **Test Behavior, Not Implementation**
- ✅ Test what users see and experience
- ✅ Test API responses, database state changes, error messages
- ✅ Test real workflow scenarios and failure modes
- ❌ Don't test internal method calls or implementation details
- ❌ Don't create tests just to make coverage numbers look good

## 🏗️ TEST ARCHITECTURE (UNIT vs INTEGRATION)

### **Unit Tests** (`tests/unit/`)
**Purpose**: Test isolated functions/classes with mocked dependencies

**Characteristics**:
- Fast execution (< 1 second per test)
- No external dependencies (database, network, files)
- Mock all external services and AWS clients
- Focus on business logic, validation, utility functions

**Examples**:
```python
# Testing password hashing utility
def test_hash_password_different_results():
    password = "test_password_123"
    hash1 = hash_password(password)
    hash2 = hash_password(password)
    assert hash1 != hash2  # Different due to salt

# Testing JWT token creation
def test_create_access_token_structure():
    data = {"sub": "test@example.com", "tenant_id": 1}
    token = create_access_token(data)
    assert len(token.split(".")) == 3  # JWT format
```

**Justfile Command**:
```bash
just test unit backend --filter=test_auth*        # Auth-related unit tests
just test unit backend --filter=test_password*    # Password utility tests
```

### **Integration Tests** (`tests/integration/`)
**Purpose**: Test complete API endpoints with real database and LocalStack

**Characteristics**:
- Real database transactions (with test fixtures)
- Real API calls through FastAPI test client
- LocalStack for AWS services (S3, SES, Secrets Manager)
- Full request/response cycles with authentication
- Tenant isolation and security verification

**Examples**:
```python
# Testing complete registration endpoint
def test_register_success(client, test_tenant, test_invitation_token):
    response = client.post("/api/auth/register", json={
        "email": test_invitation_token["email"],
        "password": "TestPass123!",
        "name": "Test User",
        "invitation_token": test_invitation_token["token"],
    })
    assert response.status_code == 200
    assert "password" not in response.json()

# Testing email sending through LocalStack
def test_send_email_localstack(client, localstack_endpoint):
    # Test full email workflow using LocalStack SES
    response = client.post("/api/email/send", json={
        "to": "test@example.com",
        "subject": "Test Email",
        "body": "Test message"
    })
    assert response.status_code == 200
```

**Justfile Command**:
```bash
just test integration backend --filter=test_auth*         # Auth integration tests
just test integration backend --filter=test_localstack*   # LocalStack AWS tests
just test integration backend --filter=test_email*        # Email service tests
```

## 🌩️ LOCALSTACK INTEGRATION (AWS TESTING)

### **Why LocalStack?**
- **Real AWS behavior** without real AWS costs or setup
- **Isolated testing** - each test gets clean AWS environment
- **Fast feedback** - no network calls to real AWS
- **CI-friendly** - consistent behavior across environments

### **Available Services**:
- **S3**: File upload, bucket operations, storage validation
- **SES**: Email sending, template rendering, delivery tracking
- **Secrets Manager**: API keys, database credentials, JWT secrets

### **LocalStack Test Requirements**:
```python
@pytest.mark.integration
class TestLocalStackEmailIntegration:
    """Integration tests require LocalStack - no skipping allowed"""

    def test_email_sending_full_workflow(self, ensure_localstack_ready):
        # Test will FAIL if LocalStack not available
        # This ensures consistent testing environment
```

### **LocalStack Health Checking**:
Tests verify LocalStack services are ready before executing:
- Health endpoint check (60s timeout)
- Required services: s3, ses, secretsmanager
- No test skipping - integration tests REQUIRE LocalStack

## 🔧 TDD WORKFLOW INTEGRATION

### **TodoWrite Integration**
TDD tasks automatically added to task management:
```
[1] 🧪 Propose test plan for user authentication fix
[2] 🔴 Write failing unit tests (password validation)
[3] 🟢 Implement code to make unit tests pass
[4] 🔵 Refactor with unit test coverage maintained
[5] ✅ Verify unit tests pass (AI responsibility)
[6] 🏁 Human verifies integration tests or leaves to CI
```

### **Verification Standards Integration**
TDD enhances existing verification requirements:
- Tests written BEFORE implementation ✅
- **AI verifies**: Unit tests pass during development cycle ✅
- **Human verifies**: Integration tests pass before task completion ✅
- Manual verification still required for UI changes ✅

## ⚡ TEST EXECUTION RESPONSIBILITIES

### **AI Responsibility (Fast Development Cycle)**
**ONLY run unit tests during TDD development**:

```bash
# AI runs these during Red-Green-Refactor cycle
just test unit backend --filter=test_auth*       # Authentication unit tests
just test unit backend --filter=test_email*      # Email service unit tests
just test unit backend --filter=test_password*   # Password utility tests
just test unit backend --filter=test_jwt*        # JWT token tests
```

**Why unit tests only?**
- Fast execution (< 30 seconds)
- Immediate feedback during development
- No external dependencies to set up
- Perfect for TDD Red-Green-Refactor cycle

### **Human/CI Responsibility (Complete Verification)**
**Integration tests are too slow for interactive TDD**:

```bash
# Human runs these manually or leaves to CI
just test integration backend --filter=test_auth*         # Auth API endpoints
just test integration backend --filter=test_localstack*   # LocalStack AWS tests
just test integration backend --filter=test_email*        # Email service integration
just test integration backend --filter=test_tenant*       # Database/RLS tests
```

**Why human/CI handles integration tests?**
- Slower execution (2-10 minutes)
- Require LocalStack setup and database fixtures
- Break TDD flow if run interactively
- Better suited for final verification

### **Complete Test Suite (Before Task Completion)**
```bash
# Human responsibility before marking "done"
just test unit backend              # All unit tests (AI verified these work)
just test integration backend       # All integration tests (human/CI verification)
just test all backend              # Complete backend test suite
```

## 🚫 WHAT WE DON'T TEST (YET)

### **No E2E Tests Currently**
- Browser automation (Playwright/Selenium)
- Multi-service integration testing
- Mobile app + backend integration
- **Future consideration**: May be evaluated when system complexity increases

### **Scope Boundaries**
- Stay within unit/integration test layers
- Use LocalStack instead of real AWS
- Focus on API-level testing rather than UI testing
- Manual verification still required for visual changes

## 🎓 TDD BEST PRACTICES

### **1. Test Names Should Tell Stories**
```python
# ✅ Good - describes behavior
def test_password_verification_fails_with_wrong_password():

# ❌ Bad - describes implementation
def test_bcrypt_check_returns_false():
```

### **2. Arrange-Act-Assert Pattern**
```python
def test_user_registration_creates_database_record():
    # Arrange - set up test data
    email = "test@example.com"
    password = "TestPass123!"

    # Act - perform the action being tested
    response = client.post("/auth/register", json={
        "email": email, "password": password, ...
    })

    # Assert - verify the results
    assert response.status_code == 200
    assert User.query.filter_by(email=email).first() is not None
```

### **3. Test Edge Cases and Error Conditions**
```python
# Test happy path
def test_login_succeeds_with_valid_credentials():

# Test error conditions
def test_login_fails_with_expired_token():
def test_login_fails_with_malformed_request():
def test_login_fails_with_sql_injection_attempt():
```

### **4. One Logical Assertion Per Test**
```python
# ✅ Good - focused test
def test_registration_returns_user_without_password():
    response = client.post("/auth/register", json=valid_data)
    user_data = response.json()
    assert "password" not in user_data

# ❌ Avoid - testing multiple concepts
def test_registration_does_everything():
    # Tests password hashing AND response format AND database storage
```

## ⚠️ TDD ANTI-PATTERNS TO AVOID

### **❌ Don't Do This**
- Writing tests after implementation (defeats TDD purpose)
- Testing implementation details instead of behavior
- Creating tests just to improve coverage metrics
- Skipping the discussion phase with stakeholders
- Writing overly complex tests that are harder to maintain than code
- Using TDD for everything (simple utility functions may not need it)

### **✅ Do This Instead**
- Write tests first based on requirements discussion
- Test observable behavior and outcomes
- Focus on tests that prevent real bugs
- Get approval on test scenarios before implementing
- Keep tests simple and focused
- Use TDD strategically for complex or critical functionality

## 🔗 INTEGRATION WITH EXISTING WORKFLOWS

### **GT Workflow Integration**
```bash
# TDD cycle integrated with GT branching
gt create --all -m "feat: add user password reset (TDD)"
# 1. Write tests first
# 2. Make tests pass
# 3. Refactor
# 4. Commit with tests
gt submit  # Create PR with test coverage
```

### **Verification Standards Enhancement**
TDD supplements existing verification without replacing it:
- Screenshots still required for UI changes
- Manual testing still required where appropriate
- Integration tests with LocalStack reduce need for manual AWS testing
- Unit tests provide fast feedback during development

### **Critical Thinking Integration**
TDD supports the critical thinking approach:
- Tests clarify requirements before implementation
- Failing tests provide concrete goals
- Test scenarios help identify edge cases early
- TDD cycle prevents "solution in search of a problem" coding

## 📋 TDD CHECKLIST

### **Before Starting Implementation (AI + Human)**
- [ ] Discussed test scenarios with stakeholder
- [ ] Got approval on test plan
- [ ] Identified unit tests needed (AI will run these)
- [ ] Identified integration tests needed (human/CI will run these)
- [ ] Planned selective test execution strategy

### **During TDD Cycle (AI Responsibility)**
- [ ] **RED**: Written failing unit tests based on approved scenarios
- [ ] **GREEN**: Written minimal code to make unit tests pass
- [ ] **REFACTOR**: Improved code design while keeping unit tests green
- [ ] Used selective unit test running: `just test unit backend --filter=relevant*`
- [ ] Verified unit tests actually test intended behavior

### **Before Marking Complete (Human Responsibility)**
- [ ] **AI completed**: All relevant unit tests pass
- [ ] **Human verifies**: Integration tests pass: `just test integration backend --filter=relevant*`
- [ ] **Human verifies**: Full test suite passes: `just test all backend`
- [ ] Tests follow F.I.R.S.T principles
- [ ] Test names clearly describe behavior being tested
- [ ] No implementation details leaked into tests

### **Division of Responsibilities**
**AI handles:**
- Unit test development and execution
- Fast TDD Red-Green-Refactor cycles
- Code implementation guided by unit test failures

**Human handles:**
- Final integration test verification
- Complete test suite execution before "done"
- Decision on whether integration tests are sufficient for task completion

---

**Remember**: TDD is not about testing - it's about design with a safety harness. Failing tests provide clear, measurable goals that guide implementation toward the right solution.
