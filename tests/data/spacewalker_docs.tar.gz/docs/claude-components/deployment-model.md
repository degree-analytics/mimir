# 📦 DEPLOYMENT MODEL

## 🚨 THREE DISTINCT DEPLOYMENT OPERATIONS (CRITICAL)

Understanding the difference between these three operations is essential for proper deployment:

## 1. 🏗️ Infrastructure Deployment
**Command Pattern**: `just aws deploy [component] dev`
**What it does**: Creates or updates AWS infrastructure resources using CloudFormation templates
**Components**: foundation, database, cluster, subnets, certificates, dns, monitoring
**Creates/Updates**: VPC, ECS clusters, RDS instances, load balancers, security groups
**Example**:
```bash
just aws deploy foundation dev    # Creates VPC, subnets, security groups
just aws deploy database dev      # Creates RDS instance
just aws deploy cluster dev       # Creates ECS cluster
```

## 2. 🔄 Service Management
**Command Pattern**: `just aws deploy [service] dev` or `just aws images [service] dev`
**What it does**: Restarts or redeploys services using EXISTING container images from ECR
**Services**: backend, admin, mobile
**CRITICAL NOTES**:
- **DOES NOT build new code** from your local changes
- **DOES NOT create new container images**
- **ONLY restarts services** with whatever image is currently in ECR
- If you've made code changes locally, this will NOT deploy them

**Example**:
```bash
just aws deploy backend dev    # Restarts backend with current ECR image
just aws images backend dev    # Updates service to use latest ECR image tag
```

## 3. 📦 New Code Deployment
**Command Pattern**: Git push → CI/CD Pipeline
**What it does**: Actually deploys NEW CODE you've written
**Process**:
1. Developer writes code locally
2. Developer commits: `gt create --all -m "feat: new feature"`
3. Developer pushes: `gt submit` (creates PR)
4. After merge: `git push origin dev` or `git push origin main`
5. CI/CD pipeline automatically:
   - Builds new container images from your code
   - Pushes images to ECR
   - Updates ECS services with new images
   - Deploys your actual code changes

**This is the ONLY way to deploy new code you've written!**

## 🎯 Quick Decision Guide

**Q: I need to create a new database or VPC**
A: Infrastructure deployment → `just aws deploy foundation dev`

**Q: I need to restart a crashed service**
A: Service management → `just aws deploy backend dev`

**Q: I wrote new code and want to deploy it**
A: New code deployment → Commit, push, let CI/CD handle it

**Q: I changed environment variables in AWS**
A: Service management → `just aws deploy backend dev` (to pick up new env vars)

**Q: I fixed a bug in the backend code**
A: New code deployment → Commit, push, CI/CD deploys it

## ⚠️ Common Mistakes

### Mistake 1: Using `aws deploy` for code changes
```bash
# ❌ WRONG - This won't deploy your code changes
vim apps/backend/src/routers/users.py  # Fix a bug
just aws deploy backend dev            # This does NOT deploy your fix!

# ✅ CORRECT - Use git/CI for code changes
vim apps/backend/src/routers/users.py  # Fix a bug
gt create --all -m "fix: user validation bug"
gt submit                               # Creates PR
# After merge, CI/CD deploys your fix
```

### Mistake 2: Expecting immediate deployment
```bash
# ❌ WRONG - Local changes aren't in ECR yet
just test unit backend                 # Tests pass locally
just aws deploy backend dev            # Deploys OLD code from ECR!

# ✅ CORRECT - Push to trigger CI/CD
just test unit backend                 # Tests pass locally
gt create --all -m "feat: new endpoint"
gt submit                              # CI/CD builds and deploys
```

## 🔄 Deployment Workflows

### Development Workflow
```bash
# 1. Make code changes
vim apps/backend/src/...

# 2. Test locally
just test unit backend
just test integration backend

# 3. Commit and push
gt create --all -m "feat: description"
gt submit

# 4. CI/CD automatically deploys to dev
# 5. Verify deployment
just health dev
```

### Production Workflow
```bash
# 1. Ensure dev deployment successful
just health dev

# 2. Create PR from dev to main
gt checkout main
gt create --all -m "merge: dev to main"
gt submit

# 3. After approval and merge
# 4. Enable production mode
just prod enable --minutes=30

# 5. CI/CD deploys to production
# 6. Verify deployment
just health prod

# 7. Disable production mode
just prod disable
```

## 📊 Deployment Matrix

| Operation | Command | Deploys Code? | Updates Infrastructure? | Restarts Services? |
|-----------|---------|---------------|-------------------------|-------------------|
| Infrastructure | `just aws deploy foundation dev` | ❌ | ✅ | ❌ |
| Service Restart | `just aws deploy backend dev` | ❌ | ❌ | ✅ |
| Code Deployment | `git push` → CI/CD | ✅ | ❌ | ✅ |
| Full Stack | All three in sequence | ✅ | ✅ | ✅ |

## 🚀 Remember

- **Infrastructure**: CloudFormation templates → AWS resources
- **Service Management**: Restart/redeploy with existing images
- **New Code**: Git → CI/CD → New images → Deployment

When in doubt: If you changed code, use git. If you need AWS resources, use `aws deploy`. If services need restarting, use `aws deploy` on the service.