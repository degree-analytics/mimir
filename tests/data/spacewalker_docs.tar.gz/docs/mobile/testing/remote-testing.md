# Remote Mobile Testing Guide

**Status:** Drafted 2025-09-16  
**Use this when:** You are away from the office (e.g., coffee shop Wi-Fi or LTE hotspot) and cannot rely on devices reaching your laptop over the local network, but you still need to validate the Spacewalker mobile experience.

---

## 1. Quick Decision Tree

1. **Need to verify a merged build or share with QA?** → Use the **Preview (internal) EAS build** workflow.
2. **Need to test work-in-progress code from your laptop on a physical device?** → Run the dev client with **Expo tunnel mode**.
3. **Need only the admin web UI?** → Use the hosted dev URL instead of your laptop IP.

---

## 2. Preview/Internal Build Workflow (No Laptop Networking Required)

Use this path any time firewall rules block your local machine, or you want a shareable build that already targets remote services.

1. **Trigger a preview build** (uses `https://backend.spacewalker.littleponies.com`).
   ```bash
   just expo build all preview --wait
   ```
   - CI already uses the same profile on merges to `dev`. Run locally only when you need a fresh build right away.

2. **Distribute to testers**.
   - iOS: Upload to TestFlight (`just expo submit ios preview --latest`).
   - Android: Upload to Internal testing (`just expo submit android preview --latest`).

3. **Install on your phone** via the standard TestFlight/Play Console links. No local IPs are required; the build ships with preview environment URLs baked in (`EXPO_PUBLIC_API_BASE_URL` set for you).

Use `just mobile_ci_status` if you want to check the job kicked off by CI instead of building locally.

---

## 3. Dev Client + Expo Tunnel (Local Code, Difficult Network)

Use this path when you must run the code that is still on your laptop. Expo’s tunnel relays traffic through Expo’s servers so the phone does not need to reach your 192.168.x.x address directly.

1. **Start backend/admin locally (optional).** If you need fresh backend data, run:
   ```bash
   just service up backend,admin
   ```

2. **Start the Expo dev server in tunnel + dev-client mode.**
   ```bash
   just expo mobile-tunnel on
   ```
   - Writes preview-friendly env overrides (forces `https://backend.spacewalker.littleponies.com`).
   - Launches Expo with the correct flags (`--dev-client --tunnel`) so your phone can connect immediately.
   - Automatically picks an open Metro port (falls back if 8081 is busy) and skips the Xcode simulator diagnostic prompts.
   - When you’re back on a trusted network, run `just expo mobile-tunnel off` to remove the overrides.
   - **Heads-up:** The app talks to the shared preview backend, so any backend changes on your branch are **not** exercised.

3. **Install/refresh the dev client** on your device if you have not already:
   ```bash
   just expo build ios development --wait
   just expo build android development --wait
   ```
   Install the artifacts once, then reuse them. They target `development` profile with `developmentClient: true`.

4. **Open the project** from your phone.
   - Launch the dev client app.
   - Scan the QR code or enter the `exp://` tunnel URL that Expo prints.

5. **Verify API target**. When running locally, confirm the mobile app is pointing at the correct backend:
   ```bash
   just mobile_config_debug | grep API_BASE_URL
   ```
   Update `.env.local` if you need the tunnel to hit a remote backend instead of localhost.

> :bulb: If tunnel mode is slow, try `--lan` plus a personal hotspot; but that still requires your device to reach the laptop IP.

---

## 4. Admin Web UI From Mobile

You do **not** need the laptop IP for the admin experience. Use the hosted dev URL:

```text
https://admin.spacewalker.littleponies.com
```

- Log in with the shared dev credentials (`dev@spacecargo.ai / dev123`).
- This domain is reachable from any network and mirrors the same preview backend.

---

## 5. Checklist Before You Leave Wi-Fi

- [ ] Mobile dev client installed (latest `development` profile build).
- [ ] Expo CLI logged in (`just expo whoami`).
- [ ] Ran `just expo mobile-tunnel on` (or confirmed tunnel overrides are in place).
- [ ] Preview EAS build succeeded if others need to test without your laptop present (`just mobile_ci_status`).

---

## 6. Troubleshooting References

- Tunnel mode instructions: `docs/mobile/troubleshooting-guide.md` → “Development server connection issues”.
- Environment variables: `docs/mobile/environment-config.md`.
- Emulator/dev-client setup: `docs/mobile/emulators.md`.
