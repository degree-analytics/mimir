# Mobile Development Patterns

## Purpose
Comprehensive development patterns and best practices for React Native mobile development in the Spacewalker system, covering core technologies, navigation, state management, offline storage, UI patterns, performance optimization, and testing strategies. Essential reference for mobile developers building cross-platform applications with Expo and React Native.

## When to Use This
- Developing new React Native components and screens
- Implementing navigation and routing patterns in mobile applications
- Setting up state management and data persistence solutions
- Following mobile development best practices and architectural patterns
- Optimizing performance for mobile devices and user experience
- Keywords: React Native patterns, mobile development, Expo, navigation, state management, MMKV, performance optimization

**Version:** 2.3 (Reorganized from implementation documentation)
**Date:** 2025-06-29
**Status:** Current - Production Mobile Development Patterns

---

## 📱 Core Technology Stack

The Spacewalker mobile application leverages a modern React Native stack optimized for cross-platform development and performance:

### Primary Technologies
- **Framework:** React Native 0.76.6 - Cross-platform mobile application framework
- **SDK:** Expo SDK 52 - Development platform and toolchain for React Native
- **Language:** TypeScript - Type-safe JavaScript with enhanced developer experience
- **UI Library:** React Native Paper - Material Design components for React Native
- **Navigation:** React Navigation - Declarative navigation library for React Native

### Data and State Management
- **Global State Management:** React Context for application-wide state (authentication, user preferences)
- **Complex Local State:** Zustand for feature-specific state management with optimized performance
- **Offline Storage:** MMKV for high-performance synchronous local storage
- **Server State:** React Query (planned) for API state management with caching and synchronization

---

## 🧭 Navigation Patterns

Navigation architecture uses **React Navigation** for all routing and screen management, providing consistent navigation experiences across the application.

### Navigation Structure

**Location:** `apps/mobile/src/navigation/`

### Stack Navigator Pattern

```typescript
// In apps/mobile/src/navigation/AppNavigator.tsx
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from '../app/index';
import BuildingScreen from '../app/buildings';
import SurveyScreen from '../app/surveys';

const Stack = createNativeStackNavigator();

function AppStack() {
  return (
    <Stack.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerStyle: {
          backgroundColor: '#2196F3',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: 'Spacewalker' }}
      />
      <Stack.Screen
        name="Buildings"
        component={BuildingScreen}
        options={{ title: 'Buildings' }}
      />
      <Stack.Screen
        name="Surveys"
        component={SurveyScreen}
        options={{ title: 'Survey Management' }}
      />
    </Stack.Navigator>
  );
}
```

### Navigation Best Practices

#### Type-Safe Navigation
```typescript
// Define navigation parameter types
export type RootStackParamList = {
  Home: undefined;
  Buildings: undefined;
  Surveys: { buildingId?: string };
  SurveyDetail: { surveyId: string };
};

// Use typed navigation hooks
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export const useTypedNavigation = () => useNavigation<NavigationProp>();
```

#### Navigation Performance
- Use lazy loading for screens with heavy components
- Implement navigation preloading for frequently accessed screens
- Optimize screen transitions with custom animations when needed

---

## 🏪 State Management Patterns

State management architecture follows a tiered approach based on scope and complexity requirements.

### Global State with React Context

For application-wide state such as authentication status, user preferences, and theme settings:

**Source:** `apps/mobile/src/contexts/AuthContext.tsx`

```typescript
// AuthContext implementation
import React, { createContext, useContext, useReducer, ReactNode } from 'react';

interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  token: string | null;
  loading: boolean;
}

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  refreshToken: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  const login = async (email: string, password: string) => {
    dispatch({ type: 'LOGIN_START' });
    try {
      const response = await authService.login(email, password);
      dispatch({ type: 'LOGIN_SUCCESS', payload: response });
    } catch (error) {
      dispatch({ type: 'LOGIN_ERROR', payload: error.message });
    }
  };

  return (
    <AuthContext.Provider value={{ ...state, login, logout, refreshToken }}>
      {children}
    </AuthContext.Provider>
  );
};
```

### Complex Local State with Zustand

For feature-specific state management with enhanced performance and debugging capabilities:

```typescript
// Survey state management with Zustand
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

interface SurveyState {
  currentSurvey: Survey | null;
  surveys: Survey[];
  isLoading: boolean;
  error: string | null;

  // Actions
  setSurvey: (survey: Survey) => void;
  addSurvey: (survey: Survey) => void;
  updateSurvey: (id: string, updates: Partial<Survey>) => void;
  deleteSurvey: (id: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

export const useSurveyStore = create<SurveyState>()(
  devtools(
    persist(
      (set, get) => ({
        currentSurvey: null,
        surveys: [],
        isLoading: false,
        error: null,

        setSurvey: (survey) => set({ currentSurvey: survey }),

        addSurvey: (survey) =>
          set((state) => ({
            surveys: [...state.surveys, survey]
          })),

        updateSurvey: (id, updates) =>
          set((state) => ({
            surveys: state.surveys.map(survey =>
              survey.id === id ? { ...survey, ...updates } : survey
            )
          })),

        deleteSurvey: (id) =>
          set((state) => ({
            surveys: state.surveys.filter(survey => survey.id !== id)
          })),

        setLoading: (loading) => set({ isLoading: loading }),
        setError: (error) => set({ error }),
      }),
      {
        name: 'survey-store',
        partialize: (state) => ({ surveys: state.surveys }),
      }
    )
  )
);
```

### Server State Management (Planned)

React Query integration for API state management with automatic caching and synchronization:

```typescript
// Example React Query integration (planned implementation)
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export const useSurveys = (buildingId?: string) => {
  return useQuery({
    queryKey: ['surveys', buildingId],
    queryFn: () => apiService.getSurveys(buildingId),
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });
};

export const useCreateSurvey = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: apiService.createSurvey,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['surveys'] });
    },
  });
};
```

---

## 💾 Offline Storage with MMKV

High-performance synchronous local storage using **React Native MMKV** for superior performance compared to AsyncStorage.

### Storage Architecture

**Implementation:** Custom storage service wrapping MMKV for consistent usage patterns

**Location:** `apps/mobile/src/lib/storage.ts`

### Storage Service Implementation

```typescript
// Comprehensive MMKV storage service
import { MMKV } from 'react-native-mmkv';

export const storage = new MMKV();

// Generic storage functions with type safety
export const setStorageItem = <T>(key: string, value: T): void => {
  try {
    storage.set(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error setting storage item ${key}:`, error);
  }
};

export const getStorageItem = <T>(key: string): T | null => {
  try {
    const item = storage.getString(key);
    return item ? JSON.parse(item) : null;
  } catch (error) {
    console.error(`Error getting storage item ${key}:`, error);
    return null;
  }
};

export const removeStorageItem = (key: string): void => {
  try {
    storage.delete(key);
  } catch (error) {
    console.error(`Error removing storage item ${key}:`, error);
  }
};

// Specialized storage functions for common use cases
export const setSurveyDraft = (draft: SurveyDraft): void => {
  setStorageItem('survey.draft', draft);
};

export const getSurveyDraft = (): SurveyDraft | null => {
  return getStorageItem<SurveyDraft>('survey.draft');
};

export const clearSurveyDraft = (): void => {
  removeStorageItem('survey.draft');
};

// Offline queue management
export const addToOfflineQueue = (action: OfflineAction): void => {
  const queue = getStorageItem<OfflineAction[]>('offline.queue') || [];
  queue.push(action);
  setStorageItem('offline.queue', queue);
};

export const getOfflineQueue = (): OfflineAction[] => {
  return getStorageItem<OfflineAction[]>('offline.queue') || [];
};

export const clearOfflineQueue = (): void => {
  removeStorageItem('offline.queue');
};
```

### Storage Best Practices

#### Data Structure Guidelines
- Use clear, hierarchical key naming conventions (`feature.subfactor.item`)
- Serialize complex objects to JSON strings
- Implement error handling for storage operations
- Consider data size limitations and cleanup strategies

#### Offline-First Pattern
```typescript
// Offline-first data synchronization pattern
const handleSurveyUpdate = async (surveyData: SurveyData) => {
  // Immediately update local state
  updateSurvey(surveyData);

  // Save to offline storage
  setSurveyDraft(surveyData);

  // Attempt server sync if online
  if (isOnline) {
    try {
      await syncToServer(surveyData);
      clearSurveyDraft(); // Clear draft after successful sync
    } catch (error) {
      // Add to offline queue for later sync
      addToOfflineQueue({
        type: 'UPDATE_SURVEY',
        data: surveyData,
        timestamp: Date.now(),
      });
    }
  }
};
```

---

## 🎨 Component and UI Patterns

UI architecture leverages **React Native Paper** for Material Design components with custom extensions for application-specific needs.

### Component Organization

**Structure:** `apps/mobile/src/components/`
- **Base Components:** Reusable UI primitives
- **Composite Components:** Feature-specific component combinations
- **Screen Components:** Full-screen layouts and containers

### Section Header with Action Button Pattern

For screen sections that need both a title and an action button (like "Start New Survey"), use this consistent layout pattern:

```typescript
// Section header with action button - ENG-698 pattern
<View style={styles.sectionHeader}>
  <Text style={styles.sectionTitle}>Survey History</Text>
  <TouchableOpacity
    style={styles.headerSurveyButton}
    onPress={() => navigation.navigate('Camera', { roomId: room.id })}
  >
    <Ionicons name="camera" size={18} color={theme.colors.white} />
    <Text style={styles.headerSurveyButtonText}>Start New Survey</Text>
  </TouchableOpacity>
</View>

// Required styling pattern
const styles = StyleSheet.create({
  sectionHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  headerSurveyButton: {
    alignItems: 'center',
    backgroundColor: theme.colors.primaryDark,
    borderRadius: 6,
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  headerSurveyButtonText: {
    color: theme.colors.white,
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 6,
  },
});
```

### Conditional UI Rendering Patterns

**Critical Pattern:** Always ensure UI elements remain accessible regardless of data state.

```typescript
// ❌ ANTI-PATTERN: Button only appears when data exists
{room.survey_history.length > 0 && (
  <View style={styles.sectionHeader}>
    <Text style={styles.sectionTitle}>Survey History</Text>
    <TouchableOpacity style={styles.headerButton}>
      <Text>Start New Survey</Text>
    </TouchableOpacity>
  </View>
)}

// ✅ CORRECT PATTERN: Button always accessible, only content is conditional
<View style={styles.section}>
  <View style={styles.sectionHeader}>
    <Text style={styles.sectionTitle}>Survey History</Text>
    <TouchableOpacity style={styles.headerButton}>
      <Text>Start New Survey</Text>
    </TouchableOpacity>
  </View>
  {room.survey_history.length > 0 ? (
    room.survey_history.map(survey => (
      <SurveyItem key={survey.id} survey={survey} />
    ))
  ) : (
    <Text style={styles.noSurveysText}>No surveys yet. Start your first survey!</Text>
  )}
</View>
```

### Layout Patterns for Headers

**flexDirection and justifyContent combinations for common layouts:**

```typescript
// Horizontal layout with space between elements
sectionHeader: {
  alignItems: 'center',
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginBottom: 16,
}

// Centered layout with icon and text
headerButton: {
  alignItems: 'center',
  flexDirection: 'row',
  paddingHorizontal: 12,
  paddingVertical: 8,
}

// Vertical stack with centered alignment
centeredColumn: {
  alignItems: 'center',
  flexDirection: 'column',
  justifyContent: 'center',
}
```

### Reusable Component Pattern

```typescript
// Example: Custom Button component extending React Native Paper
import React from 'react';
import { Button as PaperButton, ButtonProps } from 'react-native-paper';
import { StyleSheet } from 'react-native';

interface CustomButtonProps extends Omit<ButtonProps, 'children'> {
  title: string;
  variant?: 'primary' | 'secondary' | 'danger';
  size?: 'small' | 'medium' | 'large';
}

export const Button: React.FC<CustomButtonProps> = ({
  title,
  variant = 'primary',
  size = 'medium',
  style,
  ...props
}) => {
  return (
    <PaperButton
      mode="contained"
      style={[
        styles.base,
        styles[variant],
        styles[size],
        style,
      ]}
      {...props}
    >
      {title}
    </PaperButton>
  );
};

const styles = StyleSheet.create({
  base: {
    borderRadius: 8,
  },
  primary: {
    backgroundColor: '#2196F3',
  },
  secondary: {
    backgroundColor: '#757575',
  },
  danger: {
    backgroundColor: '#F44336',
  },
  small: {
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  medium: {
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  large: {
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
});
```

### Styling Best Practices

#### Performance-Optimized Styling
```typescript
// Use StyleSheet.create for optimal performance
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    paddingHorizontal: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  // Avoid inline styles for static styles
});

// Reserve inline styles only for dynamic values
<View style={[styles.container, { marginTop: dynamicMargin }]} />
```

#### Responsive Design Patterns
```typescript
// Responsive design using device dimensions
import { Dimensions, Platform } from 'react-native';

const { width, height } = Dimensions.get('window');
const isTablet = width >= 768;
const isAndroid = Platform.OS === 'android';

const responsiveStyles = StyleSheet.create({
  container: {
    padding: isTablet ? 24 : 16,
    marginTop: isAndroid ? 24 : 0,
  },
});
```

---

## ⚡ Performance Optimization Patterns

Mobile performance optimization focuses on rendering efficiency, memory management, and user experience responsiveness.

### List Virtualization

```typescript
// Optimized list rendering with FlatList
import React, { memo, useCallback } from 'react';
import { FlatList, ListRenderItem } from 'react-native';

interface SurveyListProps {
  surveys: Survey[];
  onSurveyPress: (survey: Survey) => void;
}

const SurveyItem = memo<{ survey: Survey; onPress: (survey: Survey) => void }>(
  ({ survey, onPress }) => {
    const handlePress = useCallback(() => onPress(survey), [survey, onPress]);

    return (
      <TouchableOpacity style={styles.item} onPress={handlePress}>
        <Text style={styles.title}>{survey.title}</Text>
        <Text style={styles.status}>{survey.status}</Text>
      </TouchableOpacity>
    );
  }
);

export const SurveyList: React.FC<SurveyListProps> = ({ surveys, onSurveyPress }) => {
  const renderItem: ListRenderItem<Survey> = useCallback(
    ({ item }) => <SurveyItem survey={item} onPress={onSurveyPress} />,
    [onSurveyPress]
  );

  const keyExtractor = useCallback((item: Survey) => item.id, []);

  return (
    <FlatList
      data={surveys}
      renderItem={renderItem}
      keyExtractor={keyExtractor}
      removeClippedSubviews={true}
      maxToRenderPerBatch={10}
      windowSize={21}
      initialNumToRender={10}
      getItemLayout={(data, index) => ({
        length: 80,
        offset: 80 * index,
        index,
      })}
    />
  );
};
```

### Component Memoization

```typescript
// Strategic use of React.memo and hooks for performance
import React, { memo, useCallback, useMemo } from 'react';

interface ExpensiveComponentProps {
  data: ComplexData[];
  filter: string;
  onItemSelect: (item: ComplexData) => void;
}

export const ExpensiveComponent = memo<ExpensiveComponentProps>(
  ({ data, filter, onItemSelect }) => {
    // Memoize expensive calculations
    const filteredData = useMemo(() => {
      return data.filter(item =>
        item.name.toLowerCase().includes(filter.toLowerCase())
      );
    }, [data, filter]);

    // Memoize callback functions
    const handleItemSelect = useCallback((item: ComplexData) => {
      onItemSelect(item);
    }, [onItemSelect]);

    return (
      <FlatList
        data={filteredData}
        renderItem={({ item }) => (
          <ItemComponent
            item={item}
            onSelect={handleItemSelect}
          />
        )}
      />
    );
  }
);
```

### Image Optimization

```typescript
// Optimized image handling with expo-image
import { Image } from 'expo-image';

export const OptimizedImage: React.FC<{
  source: string;
  width: number;
  height: number;
}> = ({ source, width, height }) => {
  return (
    <Image
      source={{ uri: source }}
      style={{ width, height }}
      contentFit="cover"
      cachePolicy="memory-disk"
      recyclingKey={source}
      placeholder={{
        blurhash: 'L6PZfSi_.AyE_3t7t7R**0o#DgR4',
      }}
    />
  );
};
```

---

## 🧪 Testing Patterns

Comprehensive testing strategy covering unit tests, component tests, and integration testing for React Native applications.

### Unit and Component Testing

**Framework:** Jest and React Native Testing Library
**Approach:** Co-located test files with components for maintainability

```typescript
// Example: Button.test.tsx
import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import { Button } from './Button';

describe('Button Component', () => {
  it('renders correctly with title', () => {
    const { getByText } = render(<Button title="Test Button" />);
    expect(getByText('Test Button')).toBeTruthy();
  });

  it('calls onPress when pressed', () => {
    const mockOnPress = jest.fn();
    const { getByText } = render(
      <Button title="Test Button" onPress={mockOnPress} />
    );

    fireEvent.press(getByText('Test Button'));
    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it('applies correct styling based on variant', () => {
    const { getByTestId } = render(
      <Button title="Test" variant="danger" testID="button" />
    );

    const button = getByTestId('button');
    expect(button.props.style).toContainEqual(
      expect.objectContaining({ backgroundColor: '#F44336' })
    );
  });
});
```

### Integration Testing

```typescript
// Example: Survey creation flow integration test
import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import { SurveyCreationScreen } from './SurveyCreationScreen';
import { mockApiService } from '../__mocks__/apiService';

jest.mock('../services/apiService', () => mockApiService);

describe('Survey Creation Flow', () => {
  it('creates survey successfully', async () => {
    const { getByTestId, getByText } = render(<SurveyCreationScreen />);

    // Fill form fields
    fireEvent.changeText(getByTestId('survey-title-input'), 'Test Survey');
    fireEvent.changeText(getByTestId('survey-notes-input'), 'Test notes');

    // Submit form
    fireEvent.press(getByText('Create Survey'));

    // Wait for API call and success state
    await waitFor(() => {
      expect(mockApiService.createSurvey).toHaveBeenCalledWith({
        title: 'Test Survey',
        notes: 'Test notes',
      });
    });

    expect(getByText('Survey created successfully')).toBeTruthy();
  });
});
```

### End-to-End Testing (Planned)

Future implementation with Detox for complete user journey testing across real devices and simulators.

---

## 📋 Related Mobile Development Documentation

### Architecture and Components
> 📱 **Mobile Architecture**: See [Mobile Container Architecture](./architecture/mobile-container-architecture.md) for comprehensive mobile application architecture and design patterns
> 📱 **App Components**: See [App Components](./app-components.md) for detailed mobile component architecture and organization

### Development Workflows
- **[Development Setup](../setup/development-setup.md)** - Complete development environment configuration for React Native
- **[Testing Guide](../workflows/testing-guide.md)** - Comprehensive testing strategies for mobile applications
- **[Deployment Guide](../workflows/deployment-guide.md)** - Mobile application deployment and distribution workflows

### Performance and Security
- **[Deployment Guide](../workflows/deployment-guide.md)** - Advanced performance optimization techniques for React Native
- **[Security Architecture](../architecture/security-architecture.md)** - Security implementation patterns and best practices for mobile applications

---

**Status**: ✅ **PRODUCTION MOBILE DEVELOPMENT PATTERNS**
**Last Updated**: 2025-06-29
**Scope**: React Native Development, Navigation, State Management, Performance, Testing
**Technology Stack**: React Native, Expo, TypeScript, React Navigation, MMKV, React Native Paper

---

*This mobile development patterns guide provides essential patterns and best practices for building robust, performant, and maintainable React Native applications, ensuring consistent development practices across all Spacewalker mobile platforms.*
