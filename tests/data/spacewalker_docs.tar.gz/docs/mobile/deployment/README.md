# Mobile Deployment

**Spacewalker Mobile App Deployment**  
**Last Updated:** 2025-07-08  
**Status:** ✅ Production Ready with CI/CD Automation

## Overview

This directory contains comprehensive documentation for deploying the Spacewalker mobile application to app stores. The deployment system features fully automated CI/CD pipelines with safety measures like staged rollouts and draft submissions.

## 📱 Supported Platforms

### Android - Google Play Store
- **Status:** ✅ Production Ready
- **Automation:** Full CI/CD with GitHub Actions
- **Tracks:** Internal testing, Production with staged rollout
- **Guide:** [Complete Android Deployment Guide](../android-deployment-guide.md)

### iOS - App Store (Coming Soon)
- **Status:** ⏳ In Development
- **TestFlight:** Manual setup required
- **Automation:** Planned for future release

## 🚀 Quick Start

### Android Deployment
```bash
# Build and deploy Android production app
just android_build_prod
just android_submit_playstore production

# Check deployment status
just android_release_status
```

### Automated Deployment (Recommended)
1. **Create PR** → Triggers development build for testing
2. **Merge to `dev`** → Builds and submits to internal testing track
3. **Merge to `main`** → Builds and submits to production track (draft)
4. **Manual promotion** → Review and promote in Google Play Console

## 📋 Deployment Documentation

### Platform-Specific Guides
- **[Android Deployment Guide](../android-deployment-guide.md)** - Complete Google Play Store deployment
- **[GitHub Actions Configuration](./github-actions-config.md)** - CI/CD pipeline setup

### Supporting Documentation
- **[Mobile Architecture](../architecture/README.md)** - App architecture overview
- **[Development Patterns](../development-patterns.md)** - Coding standards
- **[Testing Strategy](../testing/README.md)** - Quality assurance

## 🔧 Configuration Files

### EAS Configuration
- **Location:** `apps/mobile/eas.json`
- **Purpose:** Build and submission profiles
- **Validation:** `npm run validate:eas`

### CI/CD Pipeline
- **Location:** `.github/workflows/eas-build.yml`
- **Features:** Automated builds and submissions
- **Triggers:** PR, push to dev/main, manual

### Environment Configuration
- **Build-time:** EXPO_PUBLIC_ prefixed variables
- **Runtime:** app.config.js dynamic configuration
- **Profiles:** Development, Preview, Production

## 🛡️ Security & Safety

### Build Security
- Remote credential management via EAS
- Service account key protection
- GitHub Secrets for sensitive data
- Branch protection rules

### Deployment Safety
- **Draft submissions** - Manual review required for production
- **Staged rollouts** - Gradual release (20% → 50% → 100%)
- **Internal testing** - Team validation before public release
- **Rollback capability** - Quick reversion if issues detected

## 📊 Deployment Workflow

### Development Cycle
```mermaid
graph LR
    A[Local Development] --> B[Create PR]
    B --> C[Development Build]
    C --> D[Code Review]
    D --> E[Merge to dev]
    E --> F[Preview Build]
    F --> G[Internal Testing]
    G --> H[Merge to main]
    H --> I[Production Build]
    I --> J[Draft Submission]
    J --> K[Manual Promotion]
```

### Release Tracks
| Track | Purpose | Automation | Audience |
|-------|---------|------------|----------|
| Internal | Team testing | Full | Development team |
| Production | Public release | Build + Draft | End users |

## 🧪 Testing Integration

### Automated Testing
- **Unit tests** run on every PR
- **Integration tests** validate API connectivity
- **Build validation** ensures configuration correctness

### Manual Testing
- **Development builds** for local testing
- **Internal track** for team validation
- **Production drafts** for final review

## 📈 Monitoring & Analytics

### Build Monitoring
- GitHub Actions status checks
- EAS build dashboard
- Automated notifications for failures

### Release Monitoring
- Google Play Console crash reports
- User reviews and ratings
- Performance metrics tracking

## 🚨 Troubleshooting

### Common Issues
- **Build failures:** Check EAS configuration and credentials
- **Submission errors:** Verify service account permissions
- **CI/CD problems:** Review GitHub Actions logs

### Debug Commands
```bash
# Validate configuration
just android_validate_config
npm run validate:eas

# Check build status
just mobile_ci_status
just android_release_status

# Test submission config
npm run test:submission
```

### Getting Help
1. Review the [Android Deployment Guide troubleshooting section](../android-deployment-guide.md#troubleshooting)
2. Check [GitHub Actions configuration](./github-actions-config.md)
3. Validate setup with provided commands
4. Consult mobile architecture documentation

## 📋 Deployment Checklist

### Pre-Deployment
- [ ] All tests passing
- [ ] Configuration validated
- [ ] Environment variables set
- [ ] Service accounts configured
- [ ] Credentials properly stored

### Deployment
- [ ] Code reviewed and approved
- [ ] Appropriate branch selected
- [ ] CI/CD pipeline triggered
- [ ] Build completes successfully
- [ ] Submission to correct track

### Post-Deployment
- [ ] App installs correctly
- [ ] Core functionality verified
- [ ] Crash reports monitored
- [ ] User feedback reviewed
- [ ] Rollout percentage adjusted as needed

## 🔗 External Resources

### Documentation Links
- [Expo EAS Documentation](https://docs.expo.dev/build/introduction/)
- [Google Play Console](https://play.google.com/console)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)

### Internal Links
- [Documentation Index](../../INDEX.md)
- [Mobile README](../README.md)
- [Project Overview](../../product/product-overview.md)

---

## 📱 Platform Status Summary

| Platform | Status | Automation | Last Updated |
|----------|--------|------------|--------------|
| Android | ✅ Production Ready | Full CI/CD | 2025-07-08 |
| iOS | ⏳ In Development | Manual | TBD |

---

**🚀 Quick Commands:**
```bash
just android_build_prod              # Build Android production
just android_submit_playstore production  # Submit to Google Play
just android_release_status          # Check deployment status
just android_validate_config         # Validate configuration
```

---

*Last updated: 2025-07-08 | Next review: 2025-08-08*
