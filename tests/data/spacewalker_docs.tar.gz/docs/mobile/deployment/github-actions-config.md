# Mobile CI/CD GitHub Actions Configuration

This document outlines the required GitHub repository configuration for the EAS Build workflow.

## Required GitHub Repository Configuration

### 1. EXPO_TOKEN (Required)
- **Description**: Authentication token for Expo/EAS services
- **How to obtain**:
  1. Log in to your Expo account at https://expo.dev
  2. Go to Account Settings → Access Tokens
  3. Click "Create Token"
  4. Name it "GitHub Actions CI/CD" or similar
  5. Copy the token value
- **How to add to GitHub**:
  1. Go to your repository on GitHub
  2. Navigate to Settings → Repository Variables and Actions
  3. Click "New repository variable"
  4. Name: `EXPO_TOKEN`
  5. Value: Paste the token from Expo
  6. Click "Add variable"

## TestFlight Submission Configuration (Recommended)

For automatic TestFlight submission, use App Store Connect API authentication:

### 2. APP_STORE_CONNECT_API_KEY_ID (Required for TestFlight)
- **Description**: The Key ID from App Store Connect API
- **Example**: `ABC123DEF4`
- **How to obtain**: See [TestFlight Submission Setup Guide](testflight-submission-setup.md)

### 3. APP_STORE_CONNECT_API_ISSUER_ID (Required for TestFlight)
- **Description**: The Issuer ID from App Store Connect API
- **Example**: `12345678-1234-1234-1234-123456789012`
- **How to obtain**: Found in App Store Connect → Users and Access → Integrations

### 4. APP_STORE_CONNECT_API_KEY (Required for TestFlight)
- **Description**: Base64-encoded .p8 key file from App Store Connect
- **How to create**:
  1. Generate API key in App Store Connect with "App Manager" role
  2. Download the .p8 file (can only download once!)
  3. Base64 encode the file:
     ```bash
     base64 -i AuthKey_ABC123DEF4.p8 | pbcopy  # macOS
     ```
  4. Add the encoded content as the repository variable value

### 5. SLACK_WEBHOOK_URL (Optional)
- **Description**: Webhook URL for Slack notifications on successful TestFlight submissions
- **How to obtain**:
  1. Go to your Slack workspace's App Directory
  2. Add "Incoming Webhooks" app
  3. Choose a channel for notifications
  4. Copy the webhook URL

## Alternative: Apple ID Authentication (Not Recommended for CI/CD)

If you cannot use App Store Connect API, you can use Apple ID authentication, but this is less reliable due to 2FA requirements:

### APPLE_ID (Alternative)
- **Description**: Apple ID email for App Store Connect
- **Example**: `your-email@company.com`

### APPLE_ID_PASSWORD (Alternative)
- **Description**: App-specific password for Apple ID
- **Note**: Requires 2FA which can cause CI/CD failures

## Verification

To verify your configuration is correct:

1. Run the workflow manually:
   ```bash
   gh workflow run "EAS Build" --ref your-branch
   ```

2. Check the workflow logs for the "🔐 Setup Expo token" step:
   - Should show: "✅ Expo token configured"
   - If it shows an error, the token is not properly configured

3. Verify EAS authentication in the "🏗️ Configure EAS" step:
   - Should show your Expo username
   - Should show project information

## Security Best Practices

1. **Token Rotation**: Rotate your EXPO_TOKEN every 90 days
2. **Minimal Permissions**: Create tokens with only the permissions needed
3. **Audit Access**: Regularly review who has access to these repository variables
4. **Use Environments**: For production builds, consider using GitHub Environments with additional protections

## Troubleshooting

### EXPO_TOKEN Not Working
1. Verify the token hasn't expired
2. Check that the token has the correct permissions
3. Ensure no extra spaces or characters when pasting
4. Try regenerating the token if issues persist

### Authentication Failures
1. Check the workflow logs for specific error messages
2. Verify your Expo account has access to the project
3. Ensure the EAS project ID in `app.config.js` matches your Expo project

## References

- [Expo Access Tokens Documentation](https://docs.expo.dev/accounts/account-types/#access-tokens)
- [GitHub Encrypted Variables](https://docs.github.com/en/actions/security-guides/encrypted-secrets)
- [EAS Build Authentication](https://docs.expo.dev/build/setup/)