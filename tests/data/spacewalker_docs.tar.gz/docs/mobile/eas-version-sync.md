# EAS Version Sync System

**SpaceWalker Mobile** - Automated version and build number synchronization for EAS builds

---

## 📋 Overview

The EAS Version Sync system automatically manages semantic versions and unique build numbers for iOS and Android platforms, ensuring successful TestFlight and Google Play submissions without conflicts.

**Key Benefits:**
- **Prevents duplicate build numbers** that cause TestFlight submission failures
- **Automates version management** across iOS and Android platforms
- **Integrates seamlessly** with CI/CD pipeline
- **Provides timestamp-based uniqueness** for reliable build identification

---

## 🎯 Core Components

### 1. Version Sync Script
**Location**: `scripts/eas_version_sync.sh`

**Purpose**: Updates `app.json` with synchronized version information:
- **App Version**: Clean semantic version (e.g., `1.0.4`)
- **iOS Build Number**: Unique timestamp-based identifier
- **Android Version Code**: Same timestamp for consistency

### 2. Build Number Generation
**Format**: `YYMMDDHHMM` (10-digit timestamp)

**Structure**:
```
YY MM DD HH MM
25 07 18 14 45  = 2507181445
│  │  │  │  └─── Minutes (00-59)
│  │  │  └────── Hour (00-23)
│  │  └───────── Day (01-31)
│  └────────── Month (01-12)
└───────────── Year (last 2 digits)
```

**Examples**:
- `2507181445` = July 18, 2025 at 14:45
- `2507181446` = July 18, 2025 at 14:46
- `2512311159` = December 31, 2025 at 11:59

---

## 🚀 Usage

### Automatic Usage (CI/CD)

The version sync runs automatically during EAS builds in GitHub Actions:

```yaml
# CI/CD workflow automatically calls
bash ../../scripts/eas_version_sync.sh "$SEMANTIC_VERSION"
```

**Triggered By**:
- Push to `main` branch (production builds)
- Push to `dev` branch (development builds)
- Manual workflow dispatch

### Manual Usage (Development)

For local development or emergency fixes:

```bash
# 1. Navigate to project root
cd /path/to/spacewalker

# 2. Run version sync with desired version
bash scripts/eas_version_sync.sh "1.0.4"

# 3. Verify changes
cd apps/mobile
cat app.json | jq '{version: .expo.version, ios: .expo.ios.buildNumber, android: .expo.android.versionCode}'
```

### Script Parameters

```bash
# Using command line argument
bash scripts/eas_version_sync.sh "1.0.4-dev"

# Using environment variable
export EXPO_PUBLIC_VERSION="1.0.4"
bash scripts/eas_version_sync.sh

# Version validation (script will extract base version)
bash scripts/eas_version_sync.sh "1.0.4-dev.20250718.abc123"  # Uses "1.0.4"
```

---

## 🔧 Configuration

### Script Execution Context

The script automatically detects execution context and locates `app.json`:

```bash
# From project root
bash scripts/eas_version_sync.sh "1.0.4"

# From mobile directory (CI/CD context)
cd apps/mobile
bash ../../scripts/eas_version_sync.sh "1.0.4"

# From any subdirectory
bash /path/to/scripts/eas_version_sync.sh "1.0.4"
```

### Version Processing

**Input Version**: `1.0.4-dev.20250718.abc123`
**Processed To**:
- **App Version**: `1.0.4` (semantic base only)
- **Build Number**: `2507181445` (current timestamp)
- **Android Code**: `2507181445` (same as iOS)

### Platform-Specific Updates

**iOS Configuration**:
```json
{
  "expo": {
    "version": "1.0.4",
    "ios": {
      "buildNumber": "2507181445"
    }
  }
}
```

**Android Configuration**:
```json
{
  "expo": {
    "version": "1.0.4",
    "android": {
      "versionCode": 2507181445
    }
  }
}
```

---

## 📊 Monitoring and Validation

### Pre-Build Validation

```bash
# Check current app.json state
cd apps/mobile
cat app.json | jq '.expo.version, .expo.ios.buildNumber, .expo.android.versionCode'

# Validate build number format
BUILD_NUM=$(cat app.json | jq -r '.expo.ios.buildNumber')
echo $BUILD_NUM | grep -E '^[0-9]{10}$' && echo "✅ Valid" || echo "❌ Invalid"
```

### Post-Build Verification

```bash
# Check EAS build list for version consistency
eas build:list --platform ios --limit 3
eas build:list --platform android --limit 3

# Verify no duplicate build numbers in recent history
eas build:list --platform ios --json | jq '.[].metadata.buildNumber' | sort | uniq -d
```

### CI/CD Pipeline Monitoring

Monitor these log outputs during CI/CD builds:

```
🔄 Syncing EAS versions...
📋 Semantic version: 1.0.4-dev.20250718.abc123
📱 App version: 1.0.4
🔢 Build number: 2507181445
📝 Updating apps/mobile/app.json...
✅ Updated app.json:
{
  "expo.version": "1.0.4",
  "expo.ios.buildNumber": "2507181445",
  "expo.android.versionCode": 2507181445
}
✅ EAS version sync complete!
```

---

## ⚠️ Troubleshooting

### Common Issues

#### 1. Script Permission Denied
```bash
# Problem: Permission denied when executing script
# Solution: Make script executable
chmod +x scripts/eas_version_sync.sh
```

#### 2. JSON Utility Missing
```bash
# Problem: "json: command not found"
# Solution: Install json utility
npm install -g json

# Verify installation
which json
```

#### 3. Invalid Version Format
```bash
# Problem: Script exits with "No version provided"
# Solution: Provide valid semantic version
bash scripts/eas_version_sync.sh "1.0.4"  # ✅ Valid
bash scripts/eas_version_sync.sh ""       # ❌ Invalid
```

#### 4. App.json Not Found
```bash
# Problem: "Could not find app.json"
# Solution: Run from correct directory or check file location
ls -la apps/mobile/app.json  # Verify file exists
cd apps/mobile               # Navigate to mobile directory
```

### Version Sync Validation

#### Test Script Execution
```bash
# Dry run test (backup app.json first)
cp apps/mobile/app.json apps/mobile/app.json.backup

# Test version sync
bash scripts/eas_version_sync.sh "1.0.4"

# Check changes
git diff apps/mobile/app.json

# Restore if needed
cp apps/mobile/app.json.backup apps/mobile/app.json
```

#### Validate Build Number Uniqueness
```bash
# Check for potential timestamp collisions
for i in {1..5}; do
  echo "Build number $(date -u +"%y%m%d%H%M") at $(date)"
  sleep 1
done
```

### CI/CD Pipeline Issues

#### Debug Workflow Execution
```bash
# Check GitHub Actions logs for version sync output
gh run list --workflow "CI/CD Pipeline" --limit 3
gh run view <run-id> --log | grep -A 10 -B 5 "Syncing version"
```

#### Manual Pipeline Testing
```bash
# Test version sync in mobile directory (simulates CI)
cd apps/mobile
export EXPO_PUBLIC_VERSION="1.0.4-test"
bash ../../scripts/eas_version_sync.sh "$EXPO_PUBLIC_VERSION"
```

---

## 🔮 Advanced Usage

### Custom Build Number Formats

For special cases, the script can be modified to support different build number formats:

```bash
# Current format: YYMMDDHHMM (10 digits)
BUILD_NUMBER=$(date -u +"%y%m%d%H%M")

# Alternative formats (requires script modification):
# YYYYMMDDHHMM (12 digits) - full year
# MMDDHHMM (8 digits) - shorter format
# Unix timestamp (10+ digits) - epoch seconds
```

### Version Rollback Scenarios

```bash
# Scenario: Need to rollback to previous build number
# 1. Check previous successful build
eas build:list --platform ios --status finished --limit 5

# 2. Extract previous build number
PREV_BUILD="2507181430"

# 3. Manually update app.json (emergency only)
cd apps/mobile
json -I -f app.json -e "this.expo.ios.buildNumber='$PREV_BUILD'"
json -I -f app.json -e "this.expo.android.versionCode=$PREV_BUILD"
```

### Integration with Version Bumping

```bash
# Combine with semantic version bumping
# 1. Update version.json
echo '{"version": "1.0.5"}' > version.json

# 2. Generate new semantic version
NEW_VERSION=$(bash scripts/version/generate-version.sh)

# 3. Sync EAS versions
bash scripts/eas_version_sync.sh "$NEW_VERSION"

# 4. Commit changes
git add version.json apps/mobile/app.json
git commit -m "bump: version to 1.0.5 with EAS sync"
```

---

## 📚 Related Documentation

- **[TestFlight Duplicate Builds](../gotchas/testflight-duplicate-builds.md)** - Troubleshooting duplicate build issues
- **[Version Management System](../system/version-management.md)** - Overall version management architecture
- **[Mobile Development Workflows](../workflows/mobile-development.md)** - Complete mobile development guide
- **[EAS Build Archive Optimization](../gotchas/eas-build-archive-optimization.md)** - Build size optimization
- **[CI/CD Build Guide](../workflows/ci-cd-build-guide.md)** - CI/CD pipeline configuration

---

## 🏷️ Metadata

**Version**: 1.0.0  
**Last Updated**: 2025-07-18  
**Maintainer**: Development Team  
**Status**: Production Ready  

**Keywords**: EAS, version sync, build numbers, TestFlight, mobile deployment, automation