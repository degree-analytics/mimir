# Mobile Offline Sync Patterns

## Purpose
Comprehensive offline synchronization patterns for React Native mobile applications including queue management, conflict resolution, sync progress tracking, and network-aware sync strategies for the Spacewalker mobile app.

## When to Use This
- Implementing robust offline-first mobile applications
- Managing data synchronization between local storage and remote servers
- Handling sync conflicts and resolution strategies
- Implementing progress tracking for sync operations
- Keywords: offline sync, conflict resolution, sync queue, data synchronization, mobile offline

**Version:** 1.0
**Date:** 2025-07-09
**Status:** Current

## Key Concepts
- **Sync Queue**: Ordered queue of operations to be synchronized when connectivity is available
- **Conflict Resolution**: Strategies for handling data conflicts when local and remote data differ
- **Optimistic Updates**: Immediately applying changes locally while queuing for remote sync
- **Progressive Sync**: Syncing data in chunks to manage memory and network usage
- **Sync Status Tracking**: Monitoring and reporting sync progress to users

## Sync Architecture Overview

```mermaid
graph TD
    A[User Action] --> B[Update Local Data]
    B --> C[Add to Sync Queue]
    C --> D{Network Available?}

    D -->|Yes| E[Process Sync Queue]
    D -->|No| F[Store in Queue]

    E --> G[Upload to Server]
    G --> H{Upload Success?}

    H -->|Yes| I[Remove from Queue]
    H -->|No| J[Retry Logic]

    J --> K{Max Retries?}
    K -->|No| L[Exponential Backoff]
    K -->|Yes| M[Mark as Failed]

    L --> G
    I --> N[Update Sync Status]
    M --> O[User Notification]

    F --> P[Network Monitor]
    P --> Q{Network Restored?}
    Q -->|Yes| E
    Q -->|No| P

    classDef local fill:#E3F2FD,stroke:#1976D2,color:#000000
    classDef queue fill:#F3E5F5,stroke:#7B1FA2,color:#000000
    classDef network fill:#E8F5E8,stroke:#388E3C,color:#000000
    classDef retry fill:#FFF3E0,stroke:#F57C00,color:#000000

    class A,B,I,N local
    class C,F,E,G queue
    class D,P,Q network
    class J,K,L,M,O retry
```

## Advanced Sync Queue Management

### Priority-Based Sync Queue

```typescript
import { MMKV } from 'react-native-mmkv';

export enum SyncPriority {
  LOW = 1,
  NORMAL = 2,
  HIGH = 3,
  URGENT = 4,
}

export enum SyncStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled',
}

export interface SyncOperation {
  id: string;
  type: 'survey' | 'image' | 'user_data' | 'metadata';
  priority: SyncPriority;
  status: SyncStatus;
  payload: any;
  metadata: {
    userId: string;
    timestamp: number;
    retryCount: number;
    maxRetries: number;
    lastError?: string;
    estimatedSize?: number;
    dependencies?: string[];
  };
  createdAt: number;
  updatedAt: number;
  scheduledAt?: number;
}

export class AdvancedSyncQueue {
  private storage: MMKV;
  private processing = false;
  private listeners: Set<(status: SyncQueueStatus) => void> = new Set();

  constructor() {
    this.storage = new MMKV({ id: 'sync-queue' });
    this.initializeQueue();
  }

  private initializeQueue(): void {
    // Clean up stale processing items on startup
    const items = this.getAllItems();
    items.forEach(item => {
      if (item.status === SyncStatus.PROCESSING) {
        this.updateItem(item.id, {
          status: SyncStatus.PENDING,
          metadata: { ...item.metadata, retryCount: item.metadata.retryCount + 1 },
        });
      }
    });
  }

  // Add operation to queue with proper prioritization
  async addOperation(operation: Omit<SyncOperation, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const id = `${operation.type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = Date.now();

    const fullOperation: SyncOperation = {
      ...operation,
      id,
      createdAt: now,
      updatedAt: now,
      status: SyncStatus.PENDING,
    };

    // Check for dependencies
    if (operation.metadata.dependencies?.length) {
      const dependenciesReady = await this.checkDependencies(operation.metadata.dependencies);
      if (!dependenciesReady) {
        fullOperation.status = SyncStatus.PENDING;
        fullOperation.scheduledAt = now + 30000; // Retry in 30 seconds
      }
    }

    this.storage.set(id, JSON.stringify(fullOperation));
    this.notifyListeners();

    return id;
  }

  // Get next operations to process based on priority and dependencies
  getNextOperations(limit: number = 5): SyncOperation[] {
    const items = this.getAllItems();
    const now = Date.now();

    return items
      .filter(item =>
        item.status === SyncStatus.PENDING &&
        (item.scheduledAt === undefined || item.scheduledAt <= now)
      )
      .sort((a, b) => {
        // Sort by priority first, then by timestamp
        if (a.priority !== b.priority) {
          return b.priority - a.priority;
        }
        return a.createdAt - b.createdAt;
      })
      .slice(0, limit);
  }

  // Update operation status and metadata
  updateItem(id: string, updates: Partial<SyncOperation>): void {
    const item = this.getItem(id);
    if (!item) return;

    const updatedItem = {
      ...item,
      ...updates,
      updatedAt: Date.now(),
    };

    this.storage.set(id, JSON.stringify(updatedItem));
    this.notifyListeners();
  }

  // Remove completed or cancelled operations
  removeItem(id: string): void {
    this.storage.delete(id);
    this.notifyListeners();
  }

  // Get specific operation
  getItem(id: string): SyncOperation | null {
    const item = this.storage.getString(id);
    return item ? JSON.parse(item) : null;
  }

  // Get all operations
  getAllItems(): SyncOperation[] {
    const keys = this.storage.getAllKeys();
    return keys
      .map(key => {
        const item = this.storage.getString(key);
        return item ? JSON.parse(item) : null;
      })
      .filter(Boolean);
  }

  // Check if dependencies are satisfied
  private async checkDependencies(dependencies: string[]): Promise<boolean> {
    for (const depId of dependencies) {
      const dep = this.getItem(depId);
      if (!dep || dep.status !== SyncStatus.COMPLETED) {
        return false;
      }
    }
    return true;
  }

  // Get queue statistics
  getQueueStats(): SyncQueueStatus {
    const items = this.getAllItems();

    return {
      total: items.length,
      pending: items.filter(i => i.status === SyncStatus.PENDING).length,
      processing: items.filter(i => i.status === SyncStatus.PROCESSING).length,
      completed: items.filter(i => i.status === SyncStatus.COMPLETED).length,
      failed: items.filter(i => i.status === SyncStatus.FAILED).length,
      totalSize: items.reduce((sum, item) => sum + (item.metadata.estimatedSize || 0), 0),
    };
  }

  // Subscribe to queue changes
  subscribe(listener: (status: SyncQueueStatus) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners(): void {
    const status = this.getQueueStats();
    this.listeners.forEach(listener => listener(status));
  }

  // Clear all items (for testing or reset)
  clear(): void {
    const keys = this.storage.getAllKeys();
    keys.forEach(key => this.storage.delete(key));
    this.notifyListeners();
  }
}

interface SyncQueueStatus {
  total: number;
  pending: number;
  processing: number;
  completed: number;
  failed: number;
  totalSize: number;
}
```

### Intelligent Sync Processor

```typescript
import NetInfo from '@react-native-community/netinfo';
import { enhancedRetryRequest } from '../utils/enhancedRetry';

export class IntelligentSyncProcessor {
  private queue: AdvancedSyncQueue;
  private processing = false;
  private networkState: any = null;
  private batchSize = 3;
  private processingInterval: NodeJS.Timeout | null = null;

  constructor(queue: AdvancedSyncQueue) {
    this.queue = queue;
    this.initializeNetworkMonitoring();
  }

  private initializeNetworkMonitoring(): void {
    NetInfo.addEventListener(state => {
      const wasOffline = !this.networkState?.isConnected;
      this.networkState = state;

      // Start processing when network becomes available
      if (wasOffline && state.isConnected) {
        this.startProcessing();
      } else if (!state.isConnected) {
        this.stopProcessing();
      }
    });
  }

  async startProcessing(): Promise<void> {
    if (this.processing) return;

    this.processing = true;

    // Process immediately, then set up interval
    await this.processQueue();

    // Continue processing every 30 seconds
    this.processingInterval = setInterval(async () => {
      await this.processQueue();
    }, 30000);
  }

  stopProcessing(): void {
    this.processing = false;
    if (this.processingInterval) {
      clearInterval(this.processingInterval);
      this.processingInterval = null;
    }
  }

  private async processQueue(): Promise<void> {
    if (!this.processing || !this.networkState?.isConnected) return;

    try {
      // Adjust batch size based on network conditions
      const batchSize = this.calculateOptimalBatchSize();
      const operations = this.queue.getNextOperations(batchSize);

      if (operations.length === 0) return;

      // Process operations in parallel with controlled concurrency
      const promises = operations.map(operation => this.processOperation(operation));
      await Promise.allSettled(promises);

    } catch (error) {
      console.error('Error processing sync queue:', error);
    }
  }

  private calculateOptimalBatchSize(): number {
    const { type, effectiveType } = this.networkState;

    // Adjust batch size based on network quality
    if (effectiveType === 'slow-2g' || effectiveType === '2g') {
      return 1;
    } else if (effectiveType === '3g') {
      return 2;
    } else if (effectiveType === '4g' || type === 'wifi') {
      return 5;
    }

    return this.batchSize;
  }

  private async processOperation(operation: SyncOperation): Promise<void> {
    // Mark as processing
    this.queue.updateItem(operation.id, {
      status: SyncStatus.PROCESSING,
    });

    try {
      const result = await this.executeOperation(operation);

      if (result.success) {
        this.queue.updateItem(operation.id, {
          status: SyncStatus.COMPLETED,
        });

        // Remove completed operation after a delay (for status tracking)
        setTimeout(() => {
          this.queue.removeItem(operation.id);
        }, 30000);
      } else {
        await this.handleOperationFailure(operation, result.error);
      }
    } catch (error) {
      await this.handleOperationFailure(operation, error);
    }
  }

  private async executeOperation(operation: SyncOperation): Promise<{ success: boolean; error?: any }> {
    const { type, payload } = operation;

    return enhancedRetryRequest(async () => {
      switch (type) {
        case 'survey':
          return await this.syncSurvey(payload);
        case 'image':
          return await this.syncImage(payload);
        case 'user_data':
          return await this.syncUserData(payload);
        case 'metadata':
          return await this.syncMetadata(payload);
        default:
          throw new Error(`Unknown operation type: ${type}`);
      }
    });
  }

  private async handleOperationFailure(operation: SyncOperation, error: any): Promise<void> {
    const retryCount = operation.metadata.retryCount + 1;
    const maxRetries = operation.metadata.maxRetries;

    if (retryCount >= maxRetries) {
      // Max retries reached - mark as failed
      this.queue.updateItem(operation.id, {
        status: SyncStatus.FAILED,
        metadata: {
          ...operation.metadata,
          retryCount,
          lastError: error.message || 'Unknown error',
        },
      });
    } else {
      // Schedule retry with exponential backoff
      const delay = Math.min(1000 * Math.pow(2, retryCount), 300000); // Max 5 minutes

      this.queue.updateItem(operation.id, {
        status: SyncStatus.PENDING,
        scheduledAt: Date.now() + delay,
        metadata: {
          ...operation.metadata,
          retryCount,
          lastError: error.message || 'Unknown error',
        },
      });
    }
  }

  // Sync operation implementations
  private async syncSurvey(surveyData: any): Promise<any> {
    // Implementation for survey sync
    return await fetch('/api/surveys', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(surveyData),
    });
  }

  private async syncImage(imageData: any): Promise<any> {
    // Implementation for image sync
    const formData = new FormData();
    formData.append('image', imageData);

    return await fetch('/api/images', {
      method: 'POST',
      body: formData,
    });
  }

  private async syncUserData(userData: any): Promise<any> {
    // Implementation for user data sync
    return await fetch('/api/user', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData),
    });
  }

  private async syncMetadata(metadata: any): Promise<any> {
    // Implementation for metadata sync
    return await fetch('/api/metadata', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(metadata),
    });
  }
}
```

## Conflict Resolution Strategies

### Advanced Conflict Resolution

```typescript
export enum ConflictResolutionStrategy {
  CLIENT_WINS = 'client_wins',
  SERVER_WINS = 'server_wins',
  MERGE = 'merge',
  USER_CHOICE = 'user_choice',
  CUSTOM = 'custom',
}

export interface ConflictResolutionResult<T> {
  resolved: T;
  strategy: ConflictResolutionStrategy;
  conflicts: ConflictDetail[];
  requiresUserInput: boolean;
}

export interface ConflictDetail {
  field: string;
  localValue: any;
  remoteValue: any;
  resolution: 'local' | 'remote' | 'merged' | 'user_choice';
}

export class ConflictResolver {
  private static instance: ConflictResolver;
  private resolutionStrategies: Map<string, ConflictResolutionStrategy> = new Map();

  static getInstance(): ConflictResolver {
    if (!ConflictResolver.instance) {
      ConflictResolver.instance = new ConflictResolver();
    }
    return ConflictResolver.instance;
  }

  // Register conflict resolution strategy for specific data types
  setResolutionStrategy(dataType: string, strategy: ConflictResolutionStrategy): void {
    this.resolutionStrategies.set(dataType, strategy);
  }

  async resolveConflict<T>(
    localData: T,
    remoteData: T,
    dataType: string,
    metadata?: any
  ): Promise<ConflictResolutionResult<T>> {
    const strategy = this.resolutionStrategies.get(dataType) || ConflictResolutionStrategy.SERVER_WINS;

    switch (strategy) {
      case ConflictResolutionStrategy.CLIENT_WINS:
        return this.resolveClientWins(localData, remoteData);

      case ConflictResolutionStrategy.SERVER_WINS:
        return this.resolveServerWins(localData, remoteData);

      case ConflictResolutionStrategy.MERGE:
        return this.resolveMerge(localData, remoteData);

      case ConflictResolutionStrategy.USER_CHOICE:
        return this.resolveUserChoice(localData, remoteData);

      case ConflictResolutionStrategy.CUSTOM:
        return this.resolveCustom(localData, remoteData, dataType, metadata);

      default:
        return this.resolveServerWins(localData, remoteData);
    }
  }

  private resolveClientWins<T>(localData: T, remoteData: T): ConflictResolutionResult<T> {
    return {
      resolved: localData,
      strategy: ConflictResolutionStrategy.CLIENT_WINS,
      conflicts: this.identifyConflicts(localData, remoteData),
      requiresUserInput: false,
    };
  }

  private resolveServerWins<T>(localData: T, remoteData: T): ConflictResolutionResult<T> {
    return {
      resolved: remoteData,
      strategy: ConflictResolutionStrategy.SERVER_WINS,
      conflicts: this.identifyConflicts(localData, remoteData),
      requiresUserInput: false,
    };
  }

  private resolveMerge<T>(localData: T, remoteData: T): ConflictResolutionResult<T> {
    const conflicts = this.identifyConflicts(localData, remoteData);
    const merged = this.mergeObjects(localData, remoteData);

    return {
      resolved: merged,
      strategy: ConflictResolutionStrategy.MERGE,
      conflicts,
      requiresUserInput: false,
    };
  }

  private async resolveUserChoice<T>(
    localData: T,
    remoteData: T
  ): Promise<ConflictResolutionResult<T>> {
    const conflicts = this.identifyConflicts(localData, remoteData);

    // This would typically trigger a UI component
    const userChoice = await this.promptUserForResolution(localData, remoteData, conflicts);

    return {
      resolved: userChoice,
      strategy: ConflictResolutionStrategy.USER_CHOICE,
      conflicts,
      requiresUserInput: true,
    };
  }

  private resolveCustom<T>(
    localData: T,
    remoteData: T,
    dataType: string,
    metadata?: any
  ): ConflictResolutionResult<T> {
    // Custom resolution logic based on data type
    if (dataType === 'survey') {
      return this.resolveSurveyConflict(localData, remoteData, metadata);
    }

    // Default to server wins for unknown types
    return this.resolveServerWins(localData, remoteData);
  }

  private resolveSurveyConflict<T>(
    localData: T,
    remoteData: T,
    metadata?: any
  ): ConflictResolutionResult<T> {
    // Survey-specific conflict resolution
    // For example: merge attributes, prefer local images, combine notes
    const conflicts = this.identifyConflicts(localData, remoteData);

    const resolved = {
      ...remoteData,
      ...(localData as any).attributes && {
        attributes: { ...(remoteData as any).attributes, ...(localData as any).attributes }
      },
      ...(localData as any).images && {
        images: [...new Set([...(remoteData as any).images || [], ...(localData as any).images || []])]
      },
      ...(localData as any).notes && (remoteData as any).notes && {
        notes: `${(remoteData as any).notes}\n\n--- Local Changes ---\n${(localData as any).notes}`
      },
    };

    return {
      resolved: resolved as T,
      strategy: ConflictResolutionStrategy.CUSTOM,
      conflicts,
      requiresUserInput: false,
    };
  }

  private identifyConflicts<T>(localData: T, remoteData: T): ConflictDetail[] {
    const conflicts: ConflictDetail[] = [];

    const localObj = localData as any;
    const remoteObj = remoteData as any;

    // Compare all fields
    const allKeys = new Set([...Object.keys(localObj), ...Object.keys(remoteObj)]);

    for (const key of allKeys) {
      const localValue = localObj[key];
      const remoteValue = remoteObj[key];

      if (JSON.stringify(localValue) !== JSON.stringify(remoteValue)) {
        conflicts.push({
          field: key,
          localValue,
          remoteValue,
          resolution: 'remote', // Default resolution
        });
      }
    }

    return conflicts;
  }

  private mergeObjects<T>(localData: T, remoteData: T): T {
    // Deep merge implementation
    const merged = { ...remoteData };
    const localObj = localData as any;
    const mergedObj = merged as any;

    for (const key in localObj) {
      if (localObj.hasOwnProperty(key)) {
        if (typeof localObj[key] === 'object' && typeof mergedObj[key] === 'object') {
          mergedObj[key] = this.mergeObjects(localObj[key], mergedObj[key]);
        } else {
          // For non-objects, prefer local changes
          mergedObj[key] = localObj[key];
        }
      }
    }

    return merged;
  }

  private async promptUserForResolution<T>(
    localData: T,
    remoteData: T,
    conflicts: ConflictDetail[]
  ): Promise<T> {
    // This would integrate with a UI component
    // For now, return a placeholder
    return new Promise((resolve) => {
      // In a real implementation, this would show a conflict resolution UI
      console.log('User choice required for conflict resolution');
      resolve(remoteData); // Default to remote
    });
  }
}
```

### Conflict Resolution UI Component

```typescript
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

interface ConflictResolutionModalProps {
  visible: boolean;
  conflicts: ConflictDetail[];
  onResolve: (resolution: any) => void;
  onCancel: () => void;
}

export const ConflictResolutionModal: React.FC<ConflictResolutionModalProps> = ({
  visible,
  conflicts,
  onResolve,
  onCancel,
}) => {
  const [resolutions, setResolutions] = useState<Map<string, 'local' | 'remote'>>(new Map());

  const handleFieldResolution = (field: string, choice: 'local' | 'remote') => {
    setResolutions(prev => new Map(prev).set(field, choice));
  };

  const handleResolve = () => {
    const resolution = {};
    conflicts.forEach(conflict => {
      const choice = resolutions.get(conflict.field) || 'remote';
      (resolution as any)[conflict.field] = choice === 'local' ? conflict.localValue : conflict.remoteValue;
    });

    onResolve(resolution);
  };

  if (!visible) return null;

  return (
    <View style={styles.overlay}>
      <View style={styles.modal}>
        <Text style={styles.title}>Resolve Data Conflicts</Text>
        <Text style={styles.subtitle}>
          Changes were made both locally and remotely. Please choose which version to keep for each field.
        </Text>

        <ScrollView style={styles.conflictList}>
          {conflicts.map((conflict, index) => (
            <View key={index} style={styles.conflictItem}>
              <Text style={styles.fieldName}>{conflict.field}</Text>

              <View style={styles.choiceContainer}>
                <TouchableOpacity
                  style={[
                    styles.choiceButton,
                    resolutions.get(conflict.field) === 'local' && styles.choiceButtonSelected
                  ]}
                  onPress={() => handleFieldResolution(conflict.field, 'local')}
                >
                  <Text style={styles.choiceLabel}>Local Version</Text>
                  <Text style={styles.choiceValue}>{JSON.stringify(conflict.localValue)}</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.choiceButton,
                    resolutions.get(conflict.field) === 'remote' && styles.choiceButtonSelected
                  ]}
                  onPress={() => handleFieldResolution(conflict.field, 'remote')}
                >
                  <Text style={styles.choiceLabel}>Remote Version</Text>
                  <Text style={styles.choiceValue}>{JSON.stringify(conflict.remoteValue)}</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </ScrollView>

        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.cancelButton} onPress={onCancel}>
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.resolveButton} onPress={handleResolve}>
            <Text style={styles.resolveButtonText}>Resolve Conflicts</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modal: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 20,
    maxWidth: '90%',
    maxHeight: '80%',
    width: 400,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  conflictList: {
    maxHeight: 300,
  },
  conflictItem: {
    marginBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingBottom: 15,
  },
  fieldName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  choiceContainer: {
    flexDirection: 'row',
    gap: 10,
  },
  choiceButton: {
    flex: 1,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
  },
  choiceButtonSelected: {
    borderColor: '#2196F3',
    backgroundColor: '#f0f8ff',
  },
  choiceLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  choiceValue: {
    fontSize: 12,
    color: '#666',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  cancelButton: {
    flex: 1,
    padding: 12,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    marginRight: 10,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#666',
  },
  resolveButton: {
    flex: 1,
    padding: 12,
    backgroundColor: '#2196F3',
    borderRadius: 4,
    alignItems: 'center',
  },
  resolveButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
```

## Sync Progress Tracking

### Sync Status Hook

```typescript
import { useState, useEffect } from 'react';

export interface SyncProgress {
  total: number;
  completed: number;
  failed: number;
  percentage: number;
  currentOperation?: string;
  estimatedTimeRemaining?: number;
  isActive: boolean;
}

export const useSyncProgress = () => {
  const [progress, setProgress] = useState<SyncProgress>({
    total: 0,
    completed: 0,
    failed: 0,
    percentage: 0,
    isActive: false,
  });

  useEffect(() => {
    const syncQueue = new AdvancedSyncQueue();
    const processor = new IntelligentSyncProcessor(syncQueue);

    const unsubscribe = syncQueue.subscribe((status) => {
      const total = status.pending + status.processing + status.completed + status.failed;
      const completed = status.completed;
      const failed = status.failed;
      const percentage = total > 0 ? (completed / total) * 100 : 0;

      setProgress({
        total,
        completed,
        failed,
        percentage,
        isActive: status.processing > 0,
      });
    });

    return unsubscribe;
  }, []);

  return progress;
};
```

### Sync Status Component

```typescript
import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useSyncProgress } from '../hooks/useSyncProgress';

export const SyncStatusIndicator: React.FC = () => {
  const progress = useSyncProgress();

  if (!progress.isActive && progress.total === 0) {
    return null;
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Syncing Data</Text>
        {progress.isActive && <ActivityIndicator size="small" />}
      </View>

      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View
            style={[
              styles.progressFill,
              { width: `${progress.percentage}%` }
            ]}
          />
        </View>
        <Text style={styles.progressText}>
          {progress.completed} / {progress.total} completed
        </Text>
      </View>

      {progress.failed > 0 && (
        <Text style={styles.errorText}>
          {progress.failed} items failed to sync
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f5f5f5',
    padding: 12,
    borderRadius: 8,
    margin: 10,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  progressContainer: {
    marginBottom: 4,
  },
  progressBar: {
    height: 4,
    backgroundColor: '#e0e0e0',
    borderRadius: 2,
    marginBottom: 4,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#2196F3',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 12,
    color: '#666',
  },
  errorText: {
    fontSize: 12,
    color: '#f44336',
  },
});
```

## Testing Offline Sync Patterns

### Sync Testing Utilities

```typescript
export class SyncTestUtils {
  static createMockSyncQueue(): AdvancedSyncQueue {
    const mockQueue = new AdvancedSyncQueue();

    // Add some test operations
    mockQueue.addOperation({
      type: 'survey',
      priority: SyncPriority.HIGH,
      status: SyncStatus.PENDING,
      payload: { id: 'survey-1', data: 'test' },
      metadata: {
        userId: 'test-user',
        timestamp: Date.now(),
        retryCount: 0,
        maxRetries: 3,
      },
    });

    return mockQueue;
  }

  static async simulateNetworkFailure(): Promise<void> {
    // Mock network failure
    const originalFetch = global.fetch;
    global.fetch = jest.fn(() =>
      Promise.reject(new Error('Network failure'))
    );

    return () => {
      global.fetch = originalFetch;
    };
  }

  static async testConflictResolution(): Promise<void> {
    const resolver = ConflictResolver.getInstance();

    const localData = { id: 1, name: 'Local Name', value: 100 };
    const remoteData = { id: 1, name: 'Remote Name', value: 200 };

    const result = await resolver.resolveConflict(
      localData,
      remoteData,
      'test-data'
    );

    expect(result.resolved).toBeDefined();
    expect(result.conflicts).toHaveLength(2); // name and value conflicts
  }
}
```

## Related Documentation
- [Mobile Authentication Patterns](./authentication-patterns.md) - Secure authentication and token management
- [Mobile Survey Upload Patterns](./survey-upload-patterns.md) - Image upload and progress tracking
- [Mobile Offline-First Patterns](./offline-first-patterns.md) - UX patterns for offline scenarios
- [Mobile Architecture Overview](./architecture/README.md) - Overall mobile architecture patterns

---
**Status**: ✅ Current
**Last Updated**: 2025-07-09
**Technology Stack**: React Native, TypeScript, MMKV, NetInfo, SQLite
