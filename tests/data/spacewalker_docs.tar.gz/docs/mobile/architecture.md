# Mobile Architecture: Dual-Mode Configuration System

**SpaceWalker Mobile App** - Comprehensive dual-mode configuration architecture for React Native/Expo builds

---

## 📋 Overview

The SpaceWalker mobile application uses a **dual-mode configuration system** that supports both:
- **Build-time configuration** (EAS builds with `EXPO_PUBLIC_` variables)
- **Runtime configuration** (local development with dynamic environment switching)

This architecture enables seamless environment switching, proper separation of concerns, and production-ready deployments while maintaining development flexibility.

---

## 🏗️ Architecture Components

### 1. Configuration Layers

```mermaid
graph TD
    A[Environment Variables] --> B[Dual-Mode Config Utils]
    B --> C[Environment Config]
    C --> D[App Components]

    A1[EXPO_PUBLIC_* Variables] --> B
    A2[Constants.expoConfig.extra] --> B
    A3[Hardcoded Fallbacks] --> B

    C --> D1[API Clients]
    C --> D2[UI Components]
    C --> D3[Environment Indicators]
```

#### Priority Order:
1. **`EXPO_PUBLIC_*` variables** (EAS builds, highest priority)
2. **`Constants.expoConfig.extra` values** (local development)
3. **Hardcoded fallback defaults** (safety net)

### 2. Core Configuration Files

#### 📁 **Configuration Architecture**
```
apps/mobile/
├── app.config.js              # Expo app configuration with environment variable handling
├── eas.json                   # EAS build profiles (dev/preview/prod)
└── src/config/
    ├── environment.ts          # Main environment configuration module
    ├── config-utils.ts         # Dual-mode configuration utilities
    └── api.config.ts          # API endpoint configuration
```

---

## 🎯 Dual-Mode Configuration System

### Build-Time Configuration (EAS Builds)

When building with EAS (Expo Application Services), the configuration uses `EXPO_PUBLIC_` prefixed environment variables that are embedded into the app bundle at build time.

#### **EAS Build Profiles** (`eas.json`)

```json
{
  "build": {
    "development": {
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "http://localhost:8000",
        "EXPO_PUBLIC_APP_VARIANT": "development",
        "EXPO_PUBLIC_BUNDLE_ID_IOS": "com.degreeanalytics.spacewalker.dev"
      }
    },
    "preview": {
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "https://backend.spacewalker.littleponies.com",
        "EXPO_PUBLIC_APP_VARIANT": "preview",
        "EXPO_PUBLIC_BUNDLE_ID_IOS": "com.degreeanalytics.spacewalker.preview"
      }
    },
    "production": {
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "https://api.spacewalker.com",
        "EXPO_PUBLIC_APP_VARIANT": "production",
        "EXPO_PUBLIC_BUNDLE_ID_IOS": "com.degreeanalytics.spacewalker"
      }
    }
  }
}
```

#### **App Configuration** (`app.config.js`)

The `app.config.js` dynamically configures the app based on environment variables:

```javascript
export default ({ config }) => ({
  ...config,
  name: "Spacewalker",
  ios: {
    bundleIdentifier: validateBundleId(process.env.EXPO_PUBLIC_BUNDLE_ID_IOS, 'ios')
                     || "com.degreeanalytics.spacewalker"
  },
  android: {
    package: validateBundleId(process.env.EXPO_PUBLIC_BUNDLE_ID_ANDROID, 'android')
            || "com.degreeanalytics.spacewalker"
  },
  extra: {
    // Runtime variables available via Constants.expoConfig.extra
    API_BASE_URL: process.env.API_BASE_URL || "http://localhost:8000",
    APP_VARIANT: process.env.APP_VARIANT || "development",
    // Build-time variables also available at runtime
    EXPO_PUBLIC_API_BASE_URL: process.env.EXPO_PUBLIC_API_BASE_URL,
    EXPO_PUBLIC_APP_VARIANT: process.env.EXPO_PUBLIC_APP_VARIANT
  }
});
```

### Runtime Configuration (Local Development)

For local development, the configuration system uses `Constants.expoConfig.extra` to access environment variables dynamically.

#### **Environment Configuration** (`src/config/environment.ts`)

```typescript
/**
 * Get the current app variant using dual-mode configuration
 */
export const getAppVariant = (): AppVariant => {
  // Use dual-mode configuration with development as default
  const variant = getConfig('APP_VARIANT', 'development') as AppVariant;

  // Validate and return variant
  if (['development', 'preview', 'production'].includes(variant)) {
    return variant;
  }

  console.warn(`⚠️  Invalid APP_VARIANT value: ${variant}, falling back to development`);
  return 'development';
};

/**
 * Get the API URL using dual-mode configuration
 */
export const getApiUrl = (): string => {
  // Try new API_BASE_URL variable name
  const newConfigUrl = getConfig('API_BASE_URL');
  if (newConfigUrl) return newConfigUrl;

  // Backward compatibility with API_URL
  const legacyConfigUrl = getConfig('API_URL');
  if (legacyConfigUrl) {
    console.warn('⚠️  Using deprecated API_URL variable. Please update to API_BASE_URL');
    return legacyConfigUrl;
  }

  // Fallback to app variant-based defaults
  const appVariant = getAppVariant();
  const fallbackUrls = {
    production: 'https://api.spacewalker.com',
    preview: 'https://backend.spacewalker.littleponies.com',
    development: 'http://localhost:8000'
  };

  return fallbackUrls[appVariant];
};
```

#### **Configuration Utilities** (`src/config/config-utils.ts`)

The dual-mode configuration utilities abstract the complexity of accessing environment variables:

```typescript
/**
 * Get configuration value using dual-mode approach
 * Tries EXPO_PUBLIC_ variables first, then Constants.expoConfig.extra
 */
export const getConfig = (key: string, fallback?: string): string | undefined => {
  // 1. Try EXPO_PUBLIC_ prefixed version (EAS builds)
  const expoPublicValue = process.env[`EXPO_PUBLIC_${key}`];
  if (expoPublicValue) return expoPublicValue;

  // 2. Try Constants.expoConfig.extra (local development)
  const expoConfigValue = Constants.expoConfig?.extra?.[key];
  if (expoConfigValue) return expoConfigValue;

  // 3. Try direct process.env access
  const envValue = process.env[key];
  if (envValue) return envValue;

  // 4. Return fallback
  return fallback;
};
```

---

## 🌍 Environment Types

### Development Environment
- **API URL**: `http://localhost:8000`
- **Bundle ID**: `com.degreeanalytics.spacewalker.dev`
- **Use Case**: Local development with backend on localhost
- **Visual Indicator**: Orange "DEV" badge

### Preview Environment
- **API URL**: `https://backend.spacewalker.littleponies.com`
- **Bundle ID**: `com.degreeanalytics.spacewalker.preview`
- **Use Case**: Testing with dev backend deployment
- **Visual Indicator**: Blue "PREVIEW" badge

### Production Environment
- **API URL**: `https://api.spacewalker.com`
- **Bundle ID**: `com.degreeanalytics.spacewalker`
- **Use Case**: Production app store releases
- **Visual Indicator**: Green "PROD" badge (hidden by default)

---

## 📱 Build-Time vs Runtime Configuration

### Build-Time Configuration (Bundle IDs, App Names)

These values are embedded into the app bundle and cannot be changed at runtime:

- **Bundle Identifiers**: iOS and Android package names
- **App Name**: Display name in app stores
- **Icons and Splash Screens**: Visual assets
- **Permissions**: Camera, location, storage permissions

**Configuration**: Handled through `EXPO_PUBLIC_*` variables in `eas.json` and processed by `app.config.js`

### Runtime Configuration (API Endpoints, Feature Flags)

These values can be changed without rebuilding the app:

- **API Base URLs**: Backend endpoint addresses
- **Feature Flags**: Enable/disable features dynamically
- **Analytics Configuration**: Tracking and monitoring settings
- **Environment Indicators**: Visual badges and debugging info

**Configuration**: Handled through `src/config/environment.ts` with dual-mode access

---

## 🔄 Configuration Flow

### 1. App Startup Flow

```mermaid
sequenceDiagram
    participant App as App.tsx
    participant Env as environment.ts
    participant Utils as config-utils.ts
    participant Constants as Constants.expoConfig

    App->>Env: initializeConfiguration()
    Env->>Utils: getConfig('APP_VARIANT')
    Utils->>Constants: Check EXPO_PUBLIC_APP_VARIANT
    Utils-->>Utils: Fallback to Constants.expoConfig.extra
    Utils-->>Env: Return variant value
    Env->>App: Return configuration object
    App->>App: Configure API clients and services
```

### 2. Environment Variable Resolution

```typescript
// 1. EAS Build (EXPO_PUBLIC_ variables available)
process.env.EXPO_PUBLIC_APP_VARIANT → "production"

// 2. Local Development (Constants.expoConfig.extra available)
Constants.expoConfig.extra.APP_VARIANT → "development"

// 3. Fallback (hardcoded defaults)
"development"
```

---

## 🛠️ Development Workflows

### Local Development Setup

1. **Start development server**: `just expo start --offline` or `npm start`
2. **Environment is automatically set**: Development mode with localhost API
3. **Live reload enabled**: Changes reflected immediately
4. **QR code scanning**: Connect via Expo Go app

### Building for Testing

1. **Preview build**: `just mobile_build_dev` (points to dev backend)
2. **Local build**: `just mobile_build_local` (points to localhost)
3. **Production build**: EAS build with production profile

### Environment Switching

The app automatically detects its environment based on the build profile used. No manual switching required in production builds.

For local development, you can override configuration by setting environment variables in your shell or `.env.local` file.

---

## 🔍 Configuration Validation

### Startup Validation

The app performs comprehensive configuration validation on startup:

```typescript
export const validateEnvironment = (): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];

  // Validate API URL format
  try {
    new URL(getApiUrl());
  } catch (error) {
    errors.push(`Invalid API_BASE_URL format: ${getApiUrl()}`);
  }

  // Validate app variant
  const appVariant = getAppVariant();
  if (!['development', 'preview', 'production'].includes(appVariant)) {
    errors.push(`Invalid APP_VARIANT: ${appVariant}`);
  }

  return { isValid: errors.length === 0, errors };
};
```

### Debug Information

During development, the app logs detailed configuration information:

```
🌍 Dual-Mode Environment Configuration:
  Configuration Mode: expo-public
  App Variant: development
  API URL: http://localhost:8000
  Is Development: true
  Validation: PASSED

🔧 Configuration Sources:
  EXPO_PUBLIC_ vars available: true
  Constants.expoConfig.extra available: true
```

---

## 🚨 Best Practices

### 1. Environment Variable Naming
- **Use `EXPO_PUBLIC_` prefix** for build-time variables that need to be embedded
- **Use standard names** without prefix for runtime variables in local development
- **Always provide fallbacks** for critical configuration values

### 2. Security Considerations
- **Never embed secrets** in `EXPO_PUBLIC_` variables (they are visible in the bundle)
- **Use runtime configuration** for sensitive values that should not be embedded
- **Validate all configuration** values before using them

### 3. Bundle Management
- **Use different bundle IDs** for each environment to allow side-by-side installation
- **Follow reverse domain naming** (com.company.app.variant)
- **Keep production bundle ID clean** without environment suffixes

### 4. Testing Strategy
- **Test each environment** separately with appropriate backend endpoints
- **Validate configuration** in automated tests
- **Use environment indicators** to verify correct configuration in UI

---

## 📊 Environment Indicator System

The app includes visual indicators to help developers and testers identify the current environment:

### Environment Badges

Each environment displays a colored badge in the UI:

```typescript
const getEnvironmentDisplayConfigs = (): Record<AppVariant, EnvironmentDisplayConfig> => ({
  development: {
    displayName: 'DEV',
    color: '#FF9800', // Orange
    backgroundColor: 'rgba(255, 152, 0, 0.9)',
    shouldShowByDefault: true,
  },
  preview: {
    displayName: 'PREVIEW',
    color: '#2196F3', // Blue
    backgroundColor: 'rgba(33, 150, 243, 0.9)',
    shouldShowByDefault: true,
  },
  production: {
    displayName: 'PROD',
    color: '#4CAF50', // Green
    backgroundColor: 'rgba(76, 175, 80, 0.9)',
    shouldShowByDefault: false, // Hidden in production
  },
});
```

### Usage in Components

```typescript
import { getEnvironmentConfig } from '../config/environment';

const EnvironmentIndicator = () => {
  const config = getEnvironmentConfig();

  if (!config.displayConfig.shouldShowByDefault) {
    return null; // Hidden in production
  }

  return (
    <View style={{
      backgroundColor: config.displayConfig.backgroundColor,
      padding: 4
    }}>
      <Text style={{ color: config.displayConfig.textColor }}>
        {config.displayConfig.displayName}
      </Text>
    </View>
  );
};
```

---

## 🔧 Troubleshooting

### Common Configuration Issues

1. **API calls failing**
   - Check `getApiUrl()` returns correct URL for your environment
   - Verify backend is running on expected port/domain
   - Check network connectivity and CORS settings

2. **Wrong environment detected**
   - Verify `EXPO_PUBLIC_APP_VARIANT` is set correctly in build
   - Check `Constants.expoConfig.extra.APP_VARIANT` in development
   - Review fallback logic in `getAppVariant()`

3. **Bundle ID conflicts**
   - Ensure different bundle IDs for each environment
   - Check `EXPO_PUBLIC_BUNDLE_ID_IOS/ANDROID` variables
   - Verify app.config.js bundle ID validation

### Debug Commands

```bash
# Check current configuration
just mobile_config_debug

# Validate environment setup
just mobile_env_validate

# View all environment variables
just mobile_env_list
```

---

## 📊 Architecture Diagrams

### 1. Complete Mobile Application Architecture

```mermaid
graph TB
    subgraph "Development Environment"
        DEV_ENV[Local Development]
        DEV_ENV --> DEV_BACKEND[localhost:8000]
        DEV_ENV --> DEV_MOBILE[Expo Dev Server :8081]
    end

    subgraph "Preview Environment"
        PREVIEW_ENV[Preview Testing]
        PREVIEW_ENV --> PREVIEW_BACKEND[backend.spacewalker.littleponies.com]
        PREVIEW_ENV --> PREVIEW_MOBILE[TestFlight Beta]
    end

    subgraph "Production Environment"
        PROD_ENV[Production Release]
        PROD_ENV --> PROD_BACKEND[api.spacewalker.com]
        PROD_ENV --> PROD_MOBILE[App Store]
    end

    subgraph "Mobile App Core"
        APP[SpaceWalker Mobile App]
        APP --> AUTH[Authentication]
        APP --> CAMERA[Camera & Photo Capture]
        APP --> INVENTORY[Inventory Management]
        APP --> SYNC[Data Synchronization]
        APP --> AI[AI Analysis Integration]
    end

    subgraph "Configuration System"
        CONFIG[Dual-Mode Configuration]
        CONFIG --> BUILD_TIME[Build-Time Variables<br/>EXPO_PUBLIC_*]
        CONFIG --> RUNTIME[Runtime Variables<br/>Constants.expoConfig.extra]
        CONFIG --> FALLBACK[Hardcoded Fallbacks]
    end

    APP --> CONFIG
    CONFIG --> DEV_BACKEND
    CONFIG --> PREVIEW_BACKEND
    CONFIG --> PROD_BACKEND

    style DEV_ENV fill:#ff9800,color:#fff
    style PREVIEW_ENV fill:#2196f3,color:#fff
    style PROD_ENV fill:#4caf50,color:#fff
    style CONFIG fill:#9c27b0,color:#fff
```

### 2. Build and Deployment Pipeline

```mermaid
flowchart LR
    subgraph "Development"
        DEV[Local Development]
        DEV --> DEV_TEST[Unit Tests]
        DEV --> DEV_LINT[Code Quality]
    end

    subgraph "Source Control"
        GIT[Git Repository]
        MAIN[Main Branch]
        FEATURE[Feature Branches]
    end

    subgraph "CI/CD Pipeline"
        ACTIONS[GitHub Actions]
        BUILD[EAS Build]
        TEST[Automated Tests]
        DEPLOY[Deployment]
    end

    subgraph "Distribution"
        TESTFLIGHT[TestFlight<br/>Beta Testing]
        APPSTORE[App Store<br/>Production]
        PLAYSTORE[Play Store<br/>Production]
    end

    DEV --> FEATURE
    FEATURE --> MAIN
    MAIN --> ACTIONS
    ACTIONS --> BUILD
    BUILD --> TEST
    TEST --> DEPLOY
    DEPLOY --> TESTFLIGHT
    TESTFLIGHT --> APPSTORE
    DEPLOY --> PLAYSTORE

    GIT --> ACTIONS

    style DEV fill:#ff9800,color:#fff
    style ACTIONS fill:#2196f3,color:#fff
    style TESTFLIGHT fill:#4caf50,color:#fff
    style APPSTORE fill:#4caf50,color:#fff
```

### 3. Configuration Flow Diagram

```mermaid
sequenceDiagram
    participant App as Mobile App
    participant Config as environment.ts
    participant Utils as config-utils.ts
    participant EAS as EAS Build
    participant Constants as Constants.expoConfig

    Note over App,Constants: App Startup Configuration Flow

    App->>Config: initializeConfiguration()
    Config->>Utils: getConfig('APP_VARIANT')

    alt EAS Build Environment
        Utils->>EAS: Check process.env.EXPO_PUBLIC_APP_VARIANT
        EAS-->>Utils: Return 'production'
        Utils-->>Config: 'production'
    else Local Development
        Utils->>Constants: Check Constants.expoConfig.extra.APP_VARIANT
        Constants-->>Utils: Return 'development'
        Utils-->>Config: 'development'
    else Fallback
        Utils-->>Config: Return 'development' (default)
    end

    Config->>Utils: getConfig('API_BASE_URL')

    alt Configuration Found
        Utils-->>Config: Return configured URL
    else Fallback to Variant
        Utils->>Config: Use variant-based default
        Config-->>Utils: Return fallback URL
    end

    Config->>App: Return complete configuration
    App->>App: Configure API clients and services

    Note over App,Constants: Configuration validated and app ready
```

### 4. Environment Switching Architecture

```mermaid
graph TD
    subgraph "Configuration Sources"
        A1[EXPO_PUBLIC_API_BASE_URL]
        A2[EXPO_PUBLIC_APP_VARIANT]
        A3[EXPO_PUBLIC_BUNDLE_ID_IOS]
        A4[Constants.expoConfig.extra]
        A5[Hardcoded Defaults]
    end

    subgraph "Configuration Processor"
        B[getConfig() Function]
        B1[Priority Resolution]
        B2[Validation Logic]
        B3[Fallback Handling]
    end

    subgraph "Environment Outputs"
        C1[Development<br/>🟠 localhost:8000<br/>.dev bundle]
        C2[Preview<br/>🔵 dev backend<br/>.preview bundle]
        C3[Production<br/>🟢 prod backend<br/>base bundle]
    end

    subgraph "App Components"
        D1[API Clients]
        D2[Environment Indicator]
        D3[Build Configuration]
    end

    A1 --> B
    A2 --> B
    A3 --> B
    A4 --> B
    A5 --> B

    B --> B1
    B1 --> B2
    B2 --> B3

    B3 --> C1
    B3 --> C2
    B3 --> C3

    C1 --> D1
    C2 --> D1
    C3 --> D1

    C1 --> D2
    C2 --> D2
    C3 --> D2

    C1 --> D3
    C2 --> D3
    C3 --> D3

    style C1 fill:#ff9800,color:#fff
    style C2 fill:#2196f3,color:#fff
    style C3 fill:#4caf50,color:#fff
```

### 5. Bundle ID and Certificate Management

```mermaid
graph TB
    subgraph "Environment-Specific Bundle IDs"
        DEV_BUNDLE[Development<br/>com.degreeanalytics.spacewalker.dev]
        PREVIEW_BUNDLE[Preview<br/>com.degreeanalytics.spacewalker.preview]
        PROD_BUNDLE[Production<br/>com.degreeanalytics.spacewalker]
    end

    subgraph "Apple Developer Portal"
        APPLE[Apple Developer Account]
        CERTIFICATES[Certificates & Profiles]
        TEAM[Team ID: F43878J8DN]
        APP_STORE[App Store Connect]
    end

    subgraph "EAS Credential Management"
        EAS_CREDS[EAS Credentials]
        KEYCHAIN[Secure Keychain]
        PROVISIONING[Provisioning Profiles]
    end

    subgraph "Build Artifacts"
        IOS_APP[iOS .ipa Files]
        ANDROID_APP[Android .aab Files]
        TESTFLIGHT[TestFlight Distribution]
        PLAY_STORE[Play Store Distribution]
    end

    DEV_BUNDLE --> EAS_CREDS
    PREVIEW_BUNDLE --> EAS_CREDS
    PROD_BUNDLE --> EAS_CREDS

    APPLE --> CERTIFICATES
    CERTIFICATES --> TEAM
    TEAM --> APP_STORE

    EAS_CREDS --> KEYCHAIN
    EAS_CREDS --> PROVISIONING

    KEYCHAIN --> IOS_APP
    PROVISIONING --> IOS_APP
    EAS_CREDS --> ANDROID_APP

    IOS_APP --> TESTFLIGHT
    ANDROID_APP --> PLAY_STORE

    style DEV_BUNDLE fill:#ff9800,color:#fff
    style PREVIEW_BUNDLE fill:#2196f3,color:#fff
    style PROD_BUNDLE fill:#4caf50,color:#fff
```

### 6. API Integration Architecture

```mermaid
graph LR
    subgraph "Mobile App"
        APP[SpaceWalker Mobile]
        API_CLIENT[API Client]
        AUTH_SERVICE[Auth Service]
        DATA_SYNC[Data Sync]
    end

    subgraph "Configuration"
        ENV_CONFIG[Environment Config]
        API_CONFIG[API Configuration]
        ENV_INDICATOR[Environment Indicator]
    end

    subgraph "Backend Environments"
        LOCAL[Local Backend<br/>localhost:8000]
        DEV[Dev Backend<br/>backend.spacewalker.littleponies.com]
        PROD[Production Backend<br/>api.spacewalker.com]
    end

    subgraph "Backend Services"
        AUTH_API[Authentication API]
        INVENTORY_API[Inventory API]
        UPLOAD_API[Upload API]
        AI_API[AI Processing API]
    end

    APP --> API_CLIENT
    APP --> AUTH_SERVICE
    APP --> DATA_SYNC

    API_CLIENT --> ENV_CONFIG
    ENV_CONFIG --> API_CONFIG
    API_CONFIG --> ENV_INDICATOR

    API_CLIENT --> LOCAL
    API_CLIENT --> DEV
    API_CLIENT --> PROD

    LOCAL --> AUTH_API
    DEV --> AUTH_API
    PROD --> AUTH_API

    LOCAL --> INVENTORY_API
    DEV --> INVENTORY_API
    PROD --> INVENTORY_API

    LOCAL --> UPLOAD_API
    DEV --> UPLOAD_API
    PROD --> UPLOAD_API

    LOCAL --> AI_API
    DEV --> AI_API
    PROD --> AI_API

    style LOCAL fill:#ff9800,color:#fff
    style DEV fill:#2196f3,color:#fff
    style PROD fill:#4caf50,color:#fff
```

### 7. Development Workflow Diagram

```mermaid
flowchart TD
    START[Start Development] --> SETUP[just env_setup]
    SETUP --> SERVICES[just up]
    SERVICES --> MOBILE[just expo start --offline]\n

    MOBILE --> DEV_CYCLE{Development Cycle}

    DEV_CYCLE --> CODE[Write Code]
    CODE --> TEST[just test unit all_mobile]
    TEST --> LINT[just lint check mobile]
    LINT --> BUILD[just mobile_build_local]
    BUILD --> DEVICE[Test on Device]

    DEVICE --> WORKS{Works?}
    WORKS -->|No| DEBUG[Debug Issues]
    DEBUG --> CODE
    WORKS -->|Yes| COMMIT[git commit]

    COMMIT --> PR[Create PR]
    PR --> CI[GitHub Actions CI]
    CI --> MERGE[Merge to main]

    MERGE --> AUTO_BUILD[Automatic EAS Build]
    AUTO_BUILD --> TESTFLIGHT[TestFlight Distribution]
    TESTFLIGHT --> FEEDBACK[Collect Feedback]

    FEEDBACK --> ITERATE{Iterate?}
    ITERATE -->|Yes| CODE
    ITERATE -->|No| RELEASE[App Store Release]

    style START fill:#4caf50,color:#fff
    style CI fill:#2196f3,color:#fff
    style TESTFLIGHT fill:#ff9800,color:#fff
    style RELEASE fill:#4caf50,color:#fff
```

### 8. Error Handling and Fallback Flow

```mermaid
graph TD
    APP_START[App Startup] --> CONFIG_INIT[Initialize Configuration]

    CONFIG_INIT --> CHECK_EXPO_PUBLIC{EXPO_PUBLIC_* Available?}
    CHECK_EXPO_PUBLIC -->|Yes| USE_EXPO_PUBLIC[Use EAS Build Variables]
    CHECK_EXPO_PUBLIC -->|No| CHECK_CONSTANTS{Constants.expoConfig.extra Available?}

    CHECK_CONSTANTS -->|Yes| USE_CONSTANTS[Use Runtime Variables]
    CHECK_CONSTANTS -->|No| USE_FALLBACK[Use Hardcoded Fallbacks]

    USE_EXPO_PUBLIC --> VALIDATE_CONFIG[Validate Configuration]
    USE_CONSTANTS --> VALIDATE_CONFIG
    USE_FALLBACK --> VALIDATE_CONFIG

    VALIDATE_CONFIG --> CONFIG_VALID{Configuration Valid?}
    CONFIG_VALID -->|Yes| START_APP[Start Application]
    CONFIG_VALID -->|No| LOG_ERROR[Log Configuration Error]

    LOG_ERROR --> USE_EMERGENCY[Use Emergency Defaults]
    USE_EMERGENCY --> START_APP

    START_APP --> SHOW_ENV_INDICATOR[Show Environment Indicator]
    SHOW_ENV_INDICATOR --> INIT_API[Initialize API Clients]

    INIT_API --> API_HEALTH{API Health Check}
    API_HEALTH -->|Success| APP_READY[Application Ready]
    API_HEALTH -->|Failure| SHOW_ERROR[Show Network Error]

    SHOW_ERROR --> RETRY{User Retry?}
    RETRY -->|Yes| INIT_API
    RETRY -->|No| OFFLINE_MODE[Limited Offline Mode]

    style CONFIG_INIT fill:#2196f3,color:#fff
    style VALIDATE_CONFIG fill:#ff9800,color:#fff
    style APP_READY fill:#4caf50,color:#fff
    style SHOW_ERROR fill:#f44336,color:#fff
```

---

## 📚 Related Documentation

- **[Environment Configuration Guide](./environment-config.md)** - Detailed setup instructions
- **[Build Pipeline Guide](./build-pipeline.md)** - EAS build troubleshooting
- **[TestFlight Deployment](./testflight-guide.md)** - Production deployment process
- **[Mobile Development Workflows](../workflows/mobile-development.md)** - Complete development guide

---

**Last Updated**: {{ current_date }}
**Architecture Version**: 2.0 (Dual-Mode Configuration)
