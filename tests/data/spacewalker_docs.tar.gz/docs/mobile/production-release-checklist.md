# Production Release Checklist

**Spacewalker Mobile App - Google Play Store Release**  
**Last Updated:** 2025-07-08  
**Status:** ✅ Ready for Production Use

## Overview

This checklist ensures safe and successful production releases of the Spacewalker mobile application to the Google Play Store. Follow all steps in order to maintain quality and minimize risk.

---

## 📋 Pre-Release Checklist

### 🧪 Quality Assurance
- [ ] **All tests passing**
  ```bash
  just mobile_test
  # Verify: All unit tests pass
  # Verify: No failing integration tests
  ```

- [ ] **Code quality checks**
  ```bash
  just mobile_lint
  # Verify: No linting errors
  # Verify: Code follows project standards
  ```

- [ ] **Configuration validation**
  ```bash
  just android_validate_config
  npm run validate:eas
  # Verify: EAS configuration is valid
  # Verify: All required environment variables set
  ```

### 🔧 Technical Prerequisites
- [ ] **Build succeeds locally**
  ```bash
  just android_build_prod
  # Verify: Production build completes without errors
  # Verify: APK/AAB generates successfully
  ```

- [ ] **Service account configured**
  ```bash
  ls apps/mobile/android/service-account-key.json
  # Verify: Service account key exists
  # Verify: Google Play Console permissions granted
  ```

- [ ] **EAS credentials configured**
  ```bash
  cd apps/mobile && eas credentials --platform android
  # Verify: Upload keystore configured
  # Verify: Credentials stored remotely
  ```

### 📱 App Store Prerequisites
- [ ] **Google Play Console setup complete**
  - [ ] App listing created with correct name "Spacewalker"
  - [ ] Store listing information complete (description, screenshots)
  - [ ] Content rating questionnaire completed
  - [ ] Pricing and distribution settings configured
  - [ ] Privacy policy URL added

- [ ] **Release tracks configured**
  - [ ] Internal testing track available
  - [ ] Production track ready for submissions
  - [ ] Service account has release permissions

### 🔐 Security Verification
- [ ] **Credentials secured**
  - [ ] Keystore password stored securely
  - [ ] Service account key not committed to git
  - [ ] EXPO_TOKEN configured in GitHub secrets
  - [ ] All sensitive data properly protected

---

## 🚀 Release Process

### 1. Code Preparation
- [ ] **Create release branch**
  ```bash
  git checkout dev
  git pull origin dev
  git checkout main
  git merge dev
  # Verify: All intended changes included
  # Verify: No merge conflicts
  ```

- [ ] **Update version information**
  ```bash
  # Check current version
  grep version apps/mobile/package.json
  # Update if needed (EAS auto-increments build numbers)
  ```

- [ ] **Generate release notes**
  ```bash
  just android_generate_release_notes
  # Review and save release notes for Google Play Console
  ```

### 2. Pre-Deployment Testing
- [ ] **Final validation**
  ```bash
  just android_validate_config
  npm run test:submission
  # Verify: All checks pass
  ```

- [ ] **Test preview build** (recommended)
  ```bash
  cd apps/mobile && eas build --profile preview
  # Wait for build completion
  # Install and test from internal track
  # Verify: Core functionality works
  # Verify: API connectivity correct
  ```

### 3. Production Deployment
- [ ] **Trigger production build**
  ```bash
  # Option 1: Automated (recommended)
  git push origin main
  # Verify: GitHub Actions workflow triggers
  # Verify: Build completes successfully
  
  # Option 2: Manual
  just android_build_prod
  just android_submit_playstore production
  ```

- [ ] **Monitor build progress**
  ```bash
  just mobile_ci_status
  just android_release_status
  # Verify: Build appears in EAS dashboard
  # Verify: No build errors
  ```

### 4. Google Play Console Review
- [ ] **Verify submission**
  - [ ] Build appears in Google Play Console
  - [ ] Submission status is "draft" (production)
  - [ ] Version code auto-incremented correctly
  - [ ] Bundle ID matches: com.degreeanalytics.spacewalker

- [ ] **Update release information**
  - [ ] Add/update release notes
  - [ ] Verify app description and metadata
  - [ ] Check screenshots are current
  - [ ] Confirm target countries/regions

---

## 📊 Post-Submission Checklist

### 🔍 Review and Promotion
- [ ] **Review draft release**
  - [ ] All information accurate
  - [ ] Release notes describe changes clearly
  - [ ] No policy violations flagged
  - [ ] App content rating appropriate

- [ ] **Configure staged rollout**
  - [ ] Set initial rollout to 20%
  - [ ] Plan monitoring schedule
  - [ ] Prepare rollback procedure if needed

- [ ] **Promote to production**
  - [ ] Click "Send for review" in Google Play Console
  - [ ] Monitor for review completion (typically 1-3 days)
  - [ ] Watch for policy issues or rejections

### 📈 Post-Release Monitoring

#### First 24 Hours
- [ ] **Monitor crash reports**
  - [ ] Check Google Play Console > Quality > Crashes
  - [ ] Verify crash rate below 2%
  - [ ] Investigate any new crash patterns

- [ ] **Review user feedback**
  - [ ] Monitor ratings and reviews
  - [ ] Respond to critical issues quickly
  - [ ] Watch for feature-related complaints

- [ ] **Verify functionality**
  - [ ] Install from Play Store
  - [ ] Test core user flows
  - [ ] Verify API connectivity
  - [ ] Check environment indicators

#### First Week
- [ ] **Analyze performance metrics**
  - [ ] Daily active users
  - [ ] Session duration
  - [ ] Feature usage patterns
  - [ ] API error rates

- [ ] **Gradual rollout progression**
  - [ ] Day 2-3: Increase to 50% if no issues
  - [ ] Day 5-7: Increase to 100% if stable
  - [ ] Monitor each rollout stage carefully

### 🚨 Issue Response
- [ ] **Rollback procedure ready**
  ```bash
  # If critical issues detected:
  # 1. Halt rollout in Google Play Console
  # 2. Activate previous version
  # 3. Communicate with team and users
  # 4. Prepare hotfix if needed
  ```

- [ ] **Communication plan**
  - [ ] Team notification channels ready
  - [ ] User communication template prepared
  - [ ] Escalation procedures defined

---

## 🔧 Troubleshooting Quick Reference

### Common Issues and Solutions

#### Build Failures
```bash
# Check EAS configuration
just android_validate_config

# Verify credentials
cd apps/mobile && eas credentials --platform android

# Check recent builds
just android_release_status
```

#### Submission Errors
```bash
# Test submission configuration
npm run test:submission

# Check service account permissions
# 1. Go to Google Play Console > Users and permissions
# 2. Verify service account has "Release apps" permission
# 3. Check service account key file exists
```

#### Google Play Console Issues
- **"App not available"**: Check distribution settings and target countries
- **"Version already exists"**: Verify auto-increment is enabled in eas.json
- **"Policy violation"**: Review content rating and app description
- **"Pending publication"**: Ensure all required fields are completed

---

## 📋 Emergency Procedures

### Critical Issue Response
1. **Immediate Actions**
   - [ ] Halt rollout in Google Play Console
   - [ ] Document the issue with screenshots
   - [ ] Notify development team immediately

2. **Assessment**
   - [ ] Determine severity and impact
   - [ ] Check if issue affects all users or subset
   - [ ] Review crash reports and user feedback

3. **Resolution Options**
   - [ ] **Option A**: Activate previous version (immediate)
   - [ ] **Option B**: Prepare and deploy hotfix
   - [ ] **Option C**: Communicate workaround to users

4. **Follow-up**
   - [ ] Root cause analysis
   - [ ] Update procedures to prevent recurrence
   - [ ] Document lessons learned

### Rollback Procedure
```bash
# In Google Play Console:
# 1. Go to Production track
# 2. Find problematic release
# 3. Click "Halt rollout"
# 4. Navigate to previous release
# 5. Click "Resume rollout" on stable version
```

---

## ✅ Success Criteria

### Release Considered Successful When:
- [ ] Build deployed to production track without errors
- [ ] App passes Google Play review process
- [ ] Crash rate remains below 2%
- [ ] User rating maintains above 4.0 stars
- [ ] No critical functionality regressions
- [ ] 100% rollout completed without issues

### Key Performance Indicators
- **Technical**: Crash rate, ANR rate, startup time
- **User Experience**: Rating, reviews, user retention  
- **Business**: Downloads, active users, feature adoption

---

## 📝 Release Record Template

```markdown
## Release: v[VERSION] - [DATE]

### Build Information
- **Version Code**: [AUTO_GENERATED]
- **Version Name**: [SEMANTIC_VERSION]
- **Build Profile**: production
- **Submission Track**: production

### Release Notes
[GENERATED_FROM_GIT_COMMITS]

### Checklist Completion
- [x] All pre-release checks completed
- [x] Build successful and submitted
- [x] Google Play review passed
- [x] Staged rollout initiated (20%)
- [x] 24-hour monitoring completed
- [x] Full rollout (100%) completed

### Metrics
- **Crash Rate**: [X]%
- **Rating**: [X.X] stars
- **Downloads**: [X] users
- **Issues**: [NONE/RESOLVED]

### Notes
[ANY_SPECIAL_CONSIDERATIONS_OR_ISSUES]
```

---

## 🔗 Quick Reference Links

### Commands
```bash
# Essential commands
just android_build_prod                    # Build production
just android_submit_playstore production   # Submit to Play Store
just android_release_status               # Check status
just android_validate_config              # Validate setup

# Monitoring
just mobile_ci_status                     # EAS build status
just android_generate_release_notes       # Release notes
```

### Documentation
- [Android Deployment Guide](./android-deployment-guide.md)
- [Mobile Architecture](./architecture/README.md)
- [Troubleshooting Guide](./android-deployment-guide.md#troubleshooting)
- [GitHub Actions Configuration](./deployment/github-actions-config.md)

### External Resources
- [Google Play Console](https://play.google.com/console)
- [EAS Dashboard](https://expo.dev/)
- [Google Play Developer Policies](https://play.google.com/about/developer-content-policy/)

---

**⚠️ Important Reminders:**
- Always test with preview builds before production
- Monitor crash reports and user feedback closely
- Keep rollback procedures readily available
- Document any issues or deviations from this checklist

---

*Last updated: 2025-07-08 | Next review: 2025-08-08*