# Mobile App Components

## Purpose
Detailed implementation documentation for the React Native mobile app components, including screen architecture, state management patterns, offline storage implementation, and service layer organization. Essential reference for mobile developers working on the Spacewalker survey application.

## When to Use This
- Implementing new mobile screens and UI components
- Understanding React Native architecture and offline-first patterns
- Working with MMKV storage and state management systems
- Debugging mobile component interactions and data flow
- Planning mobile component modifications and feature additions
- Keywords: React Native components, mobile architecture, offline storage, state management, UI patterns

**Version:** 2.0 (Extracted from component diagrams)
**Date:** 2025-06-29
**Status:** Current - Production Implementation Reference

---

## 📱 Mobile App Architecture

The mobile app follows a layered architecture with React Native and Expo, emphasizing clean separation between UI presentation, state management, business logic, and storage. The architecture prioritizes offline-first functionality and smooth user experience.

### Component Layer Organization
```
UI Layer (Screens & Components)
    ↓
State & Logic Layer (Context & Services)
    ↓
Storage Layer (MMKV & Persistence)
```

---

## 🎨 UI Layer Components

### Screens
**Location**: `apps/mobile/src/app/`
**Technology**: React Native with Expo Router
**Status**: `[Implemented]`

**Responsibility**: User-facing views for each step of the survey workflow, implementing the core user journey from authentication through survey completion.

#### Screen Organization
```
app/
├── (auth)/
│   ├── login.tsx        # User authentication screen
│   └── register.tsx     # User registration screen
├── (tabs)/
│   ├── home.tsx         # Dashboard and survey list
│   ├── camera.tsx       # Photo capture for surveys
│   ├── survey.tsx       # Survey form and data entry
│   └── profile.tsx      # User profile and settings
├── review.tsx           # Survey review before submission
├── sync.tsx            # Offline sync status and management
└── _layout.tsx         # Root navigation layout
```

#### Screen Implementation Patterns
```typescript
// Example screen structure with offline-first patterns
export default function SurveyScreen() {
  const { survey, updateSurvey } = useSurveyContext();
  const { isOnline } = useNetworkStatus();
  const { saveOffline } = useOfflineStorage();

  const handleSurveyUpdate = async (data: SurveyData) => {
    updateSurvey(data);

    // Always save offline first
    await saveOffline('survey', data);

    // Attempt sync if online
    if (isOnline) {
      await syncToServer(data);
    }
  };

  return (
    <SurveyForm
      data={survey}
      onUpdate={handleSurveyUpdate}
      offlineMode={!isOnline}
    />
  );
}
```

#### Key Screen Features
- **Offline-First Design** - All screens function without network connectivity
- **Navigation Integration** - Seamless navigation with Expo Router
- **State Persistence** - Automatic state saving across app restarts
- **Progress Tracking** - Visual indicators for multi-step workflows
- **Error Handling** - User-friendly error messages and recovery options

### Reusable Components
**Location**: `apps/mobile/src/components/`
**Technology**: React Native with TypeScript
**Status**: `[Implemented]`

**Responsibility**: Shared UI elements that provide consistent design and behavior across all screens.

#### Component Organization
```
components/
├── forms/
│   ├── SurveyForm.tsx      # Main survey data entry form
│   ├── PhotoCapture.tsx    # Camera integration component
│   └── FormInput.tsx       # Standardized form inputs
├── ui/
│   ├── Button.tsx          # Consistent button styling
│   ├── LoadingSpinner.tsx  # Loading state indicators
│   └── ErrorBoundary.tsx   # Error handling wrapper
├── layout/
│   ├── Screen.tsx          # Screen wrapper with safe areas
│   └── Header.tsx          # Navigation header component
└── sync/
    ├── SyncStatus.tsx      # Offline sync status display
    └── SyncProgress.tsx    # Sync progress indicators
```

#### Component Design Principles
- **Atomic Design** - Components built from small, reusable pieces
- **TypeScript Integration** - Full type safety across all components
- **Accessibility Support** - Screen reader and accessibility compliance
- **Theme Consistency** - Centralized styling and design tokens
- **Performance Optimization** - Memoization and efficient re-rendering

#### Example Component Pattern
```typescript
interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'danger';
  disabled?: boolean;
  loading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  disabled = false,
  loading = false,
}) => {
  return (
    <TouchableOpacity
      style={[styles.button, styles[variant], disabled && styles.disabled]}
      onPress={onPress}
      disabled={disabled || loading}
    >
      {loading ? (
        <LoadingSpinner color="white" />
      ) : (
        <Text style={styles.buttonText}>{title}</Text>
      )}
    </TouchableOpacity>
  );
};
```

---

## ⚡ State & Logic Layer Components

### React Context State Management
**Location**: `apps/mobile/src/contexts/`
**Technology**: React Context API with TypeScript
**Status**: `[Implemented]`

**Responsibility**: Manages global application state including authentication, user session, and survey data across all screens.

#### Context Organization
```
contexts/
├── AuthContext.tsx         # User authentication and session
├── SurveyContext.tsx       # Current survey state and data
├── NetworkContext.tsx      # Network connectivity status
├── SyncContext.tsx         # Offline sync state management
└── ThemeContext.tsx        # App theme and styling
```

#### State Management Features
- **Global State** - Centralized state accessible from any component
- **Persistent State** - State automatically persisted to offline storage
- **Type Safety** - Full TypeScript support for all state operations
- **State Synchronization** - Automatic sync between context and storage
- **Performance Optimization** - Selective re-rendering with context splitting

#### Example Context Implementation
```typescript
interface SurveyContextType {
  survey: Survey | null;
  surveys: Survey[];
  isLoading: boolean;
  updateSurvey: (data: Partial<Survey>) => void;
  saveSurvey: () => Promise<void>;
  loadSurveys: () => Promise<void>;
}

export const SurveyContext = createContext<SurveyContextType | undefined>(undefined);

export const SurveyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [survey, setSurvey] = useState<Survey | null>(null);
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const updateSurvey = useCallback((data: Partial<Survey>) => {
    setSurvey(prev => prev ? { ...prev, ...data } : null);
  }, []);

  const saveSurvey = useCallback(async () => {
    if (!survey) return;

    setIsLoading(true);
    try {
      await offlineStorage.store('currentSurvey', survey);
      await syncService.queueForSync(survey);
    } finally {
      setIsLoading(false);
    }
  }, [survey]);

  return (
    <SurveyContext.Provider value={{
      survey,
      surveys,
      isLoading,
      updateSurvey,
      saveSurvey,
      loadSurveys,
    }}>
      {children}
    </SurveyContext.Provider>
  );
};
```

### Services & API Client
**Location**: `apps/mobile/src/lib/`
**Technology**: React Native with Axios/Fetch
**Status**: `[Implemented]`

**Responsibility**: Handles API communication, offline sync logic, business rules, and external service integrations.

#### Service Organization
```
lib/
├── api/
│   ├── client.ts           # Base API client configuration
│   ├── auth.ts             # Authentication API calls
│   ├── surveys.ts          # Survey CRUD operations
│   └── sync.ts             # Data synchronization logic
├── services/
│   ├── StorageService.ts   # Offline storage abstraction
│   ├── SyncService.ts      # Background sync coordination
│   ├── CameraService.ts    # Camera and photo management
│   └── ValidationService.ts # Data validation rules
└── utils/
    ├── network.ts          # Network connectivity utilities
    ├── permissions.ts      # Device permission management
    └── crypto.ts           # Data encryption and security
```

#### Service Features
- **Offline-First Design** - All operations work offline with queued sync
- **Error Handling** - Comprehensive error recovery and user feedback
- **Request Queuing** - Automatic retry logic for failed network requests
- **Data Validation** - Client-side validation matching server requirements
- **Security** - Encrypted storage and secure API communication

#### Example Service Implementation
```typescript
class SyncService {
  private syncQueue: SyncItem[] = [];
  private issyncing = false;

  async queueForSync(data: any, endpoint: string, method: 'POST' | 'PUT' | 'DELETE') {
    const syncItem: SyncItem = {
      id: generateId(),
      data,
      endpoint,
      method,
      timestamp: Date.now(),
      retryCount: 0,
    };

    this.syncQueue.push(syncItem);
    await this.persistQueue();

    // Attempt immediate sync if online
    if (await this.isOnline()) {
      this.processSyncQueue();
    }
  }

  async processSyncQueue() {
    if (this.issyncing || this.syncQueue.length === 0) return;

    this.issyncing = true;

    try {
      for (const item of this.syncQueue) {
        await this.syncItem(item);
      }
      this.syncQueue = [];
      await this.persistQueue();
    } finally {
      this.issyncing = false;
    }
  }

  private async syncItem(item: SyncItem) {
    try {
      const response = await apiClient.request({
        method: item.method,
        url: item.endpoint,
        data: item.data,
      });

      // Item successfully synced
      return response;
    } catch (error) {
      item.retryCount++;
      if (item.retryCount >= MAX_RETRIES) {
        // Move to failed queue for manual review
        await this.moveToFailedQueue(item);
      }
      throw error;
    }
  }
}
```

---

## 💾 Storage Layer Components

### MMKV Storage
**Location**: `apps/mobile/src/lib/storage/`
**Technology**: React Native MMKV
**Status**: `[Implemented]`

**Responsibility**: High-performance key-value store for offline data persistence, providing fast, synchronous storage operations.

#### Storage Features
- **High Performance** - Synchronous operations with minimal overhead
- **Data Encryption** - Optional encryption for sensitive data
- **Large Data Support** - Efficient storage of survey images and JSON data
- **Cross-Platform** - Consistent behavior on iOS and Android
- **Crash Recovery** - Automatic recovery from app crashes

#### Storage Organization
```typescript
class OfflineStorage {
  private storage = new MMKV({
    id: 'spacewalker',
    encryptionKey: 'your-encryption-key',
  });

  // Survey data storage
  async storeSurvey(survey: Survey): Promise<void> {
    const key = `survey_${survey.id}`;
    this.storage.set(key, JSON.stringify(survey));
  }

  async getSurvey(surveyId: string): Promise<Survey | null> {
    const key = `survey_${surveyId}`;
    const data = this.storage.getString(key);
    return data ? JSON.parse(data) : null;
  }

  // Sync queue management
  async storeSyncQueue(queue: SyncItem[]): Promise<void> {
    this.storage.set('sync_queue', JSON.stringify(queue));
  }

  async getSyncQueue(): Promise<SyncItem[]> {
    const data = this.storage.getString('sync_queue');
    return data ? JSON.parse(data) : [];
  }

  // User preferences
  async storeUserPreferences(prefs: UserPreferences): Promise<void> {
    this.storage.set('user_preferences', JSON.stringify(prefs));
  }

  // Secure storage for tokens
  async storeAuthToken(token: string): Promise<void> {
    this.storage.set('auth_token', token);
  }

  async getAuthToken(): Promise<string | null> {
    return this.storage.getString('auth_token') || null;
  }
}
```

### State Persistence Integration
The storage layer integrates seamlessly with React Context to provide automatic state persistence:

```typescript
// Automatic state persistence hook
function usePersistedState<T>(key: string, initialValue: T): [T, (value: T) => void] {
  const [state, setState] = useState<T>(() => {
    const stored = storage.getString(key);
    return stored ? JSON.parse(stored) : initialValue;
  });

  const setPersistentState = useCallback((value: T) => {
    setState(value);
    storage.set(key, JSON.stringify(value));
  }, [key]);

  return [state, setPersistentState];
}
```

---

## 🔄 Component Interaction Patterns

### Data Flow Architecture
```
User Interaction → Screen Component → Context State → Service Layer → Storage Layer
       ↓                ↓                ↓              ↓              ↓
   Event Handler → State Update → Business Logic → API Call → Data Persistence
       ↓                ↓                ↓              ↓              ↓
   UI Update ← Component Re-render ← State Change ← Response ← Storage Confirmation
```

### Offline-First Flow
```typescript
// Example: Survey submission with offline-first approach
const submitSurvey = async (surveyData: Survey) => {
  // 1. Immediately update UI state
  setSurveyStatus('submitting');

  // 2. Save to offline storage first (always succeeds)
  await offlineStorage.storeSurvey(surveyData);

  // 3. Update UI to show "saved locally"
  setSurveyStatus('saved_locally');

  // 4. If online, attempt sync
  if (isOnline) {
    try {
      await apiClient.submitSurvey(surveyData);
      setSurveyStatus('synced');
    } catch (error) {
      // Queue for later sync, keep "saved locally" status
      await syncService.queueForSync(surveyData, '/api/surveys', 'POST');
      setSurveyStatus('queued_for_sync');
    }
  } else {
    // Queue for sync when online
    await syncService.queueForSync(surveyData, '/api/surveys', 'POST');
    setSurveyStatus('queued_for_sync');
  }
};
```

### Background Sync Process
```typescript
// Automatic background sync when app becomes active
useEffect(() => {
  const handleAppStateChange = (nextAppState: AppStateStatus) => {
    if (nextAppState === 'active') {
      // Check connectivity and process sync queue
      checkConnectivityAndSync();
    }
  };

  const subscription = AppState.addEventListener('change', handleAppStateChange);
  return () => subscription?.remove();
}, []);

const checkConnectivityAndSync = async () => {
  const isConnected = await NetInfo.fetch().then(state => state.isConnected);

  if (isConnected) {
    await syncService.processSyncQueue();
    await loadLatestDataFromServer();
  }
};
```

---

## 🧪 Mobile Component Testing

### Component Testing
```typescript
// Screen component testing with React Native Testing Library
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import { SurveyScreen } from '../screens/SurveyScreen';

describe('SurveyScreen', () => {
  it('should save survey data offline', async () => {
    const mockSave = jest.fn();
    const { getByTestId } = render(
      <SurveyScreen onSave={mockSave} />
    );

    const titleInput = getByTestId('survey-title-input');
    fireEvent.changeText(titleInput, 'Test Survey');

    const saveButton = getByTestId('save-button');
    fireEvent.press(saveButton);

    await waitFor(() => {
      expect(mockSave).toHaveBeenCalledWith({
        title: 'Test Survey'
      });
    });
  });
});
```

### Service Testing
```typescript
// Service layer testing with mocked dependencies
describe('SyncService', () => {
  it('should queue items for sync when offline', async () => {
    const syncService = new SyncService();
    jest.spyOn(syncService, 'isOnline').mockResolvedValue(false);

    await syncService.queueForSync(testData, '/api/surveys', 'POST');

    const queue = await syncService.getSyncQueue();
    expect(queue).toHaveLength(1);
    expect(queue[0].data).toEqual(testData);
  });
});
```

### Storage Testing
```typescript
// Storage layer testing
describe('OfflineStorage', () => {
  it('should store and retrieve survey data', async () => {
    const storage = new OfflineStorage();
    const testSurvey = { id: '123', title: 'Test Survey' };

    await storage.storeSurvey(testSurvey);
    const retrieved = await storage.getSurvey('123');

    expect(retrieved).toEqual(testSurvey);
  });
});
```

---

## 📊 Performance Optimization

### UI Performance
- **Component Memoization** - Use React.memo for expensive components
- **List Virtualization** - FlatList for large data sets
- **Image Optimization** - Lazy loading and caching for survey photos
- **Navigation Optimization** - Lazy screen loading with React Navigation

### Storage Performance
- **MMKV Optimization** - Batch operations and efficient serialization
- **Data Compression** - Compress large survey data before storage
- **Cache Management** - Intelligent cache eviction policies
- **Background Processing** - Sync operations in background threads

### Network Performance
- **Request Batching** - Combine multiple API calls when possible
- **Caching Strategy** - Cache API responses with expiration policies
- **Retry Logic** - Exponential backoff for failed requests
- **Data Compression** - GZIP compression for API payloads

---

## 🔧 Mobile Configuration

### App Configuration
```typescript
// App configuration with environment variables
export const CONFIG = {
  API_BASE_URL: process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8000',
  OFFLINE_STORAGE_KEY: 'spacewalker_offline',
  SYNC_INTERVAL: 30000, // 30 seconds
  MAX_RETRY_ATTEMPTS: 3,
  IMAGE_QUALITY: 0.8,
  MAX_IMAGE_SIZE: 1024 * 1024 * 5, // 5MB
};
```

### Build Configuration
```json
// app.json - Expo configuration
{
  "expo": {
    "name": "Spacewalker",
    "slug": "spacewalker-mobile",
    "platforms": ["ios", "android"],
    "version": "1.0.0",
    "extra": {
      "apiUrl": "https://api.spacewalker.com"
    },
    "plugins": [
      "expo-camera",
      "expo-image-picker",
      "react-native-mmkv"
    ]
  }
}
```

---

## 📋 Related Mobile Documentation

### Development Resources
> 📱 **Mobile Setup**: See [Development Setup](../setup/development-setup.md) for React Native environment configuration
> 📱 **Testing Guide**: See [Testing Guide](../workflows/testing-guide.md) for comprehensive testing approaches

### Architecture Context
- **[Component Architecture Overview](../architecture/component-diagrams.md)** - Cross-system component relationships and mobile integration
- **[Offline-First Architecture](./architecture/offline-first.md)** - Detailed offline-first implementation strategies

### API Integration
> 🚀 **Backend Integration**: See [API Development Guide](../backend/api-development.md) for API contract information
> 🚀 **Authentication Flow**: See [Development Patterns](./development-patterns.md) for JWT implementation in React Native

---

**Status**: ✅ **PRODUCTION IMPLEMENTATION REFERENCE**
**Last Updated**: 2025-06-29
**Component Scope**: React Native Mobile App UI, State Management, and Storage
**Technology Stack**: React Native, Expo, TypeScript, MMKV, React Context

---

*This mobile component documentation provides comprehensive implementation guidance for developers working on the React Native application, ensuring consistent offline-first patterns and maintainable architecture across all mobile features.*
