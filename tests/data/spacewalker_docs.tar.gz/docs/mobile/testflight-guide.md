# TestFlight Distribution Guide

**SpaceWalker Mobile App** - Complete guide to TestFlight beta distribution, from setup to user management

> **Note**: This guide has been updated to reflect the current command structure. Mobile-specific justfile commands (e.g., `just mobile_build_*`, `just mobile_deploy_*`) have been deprecated in favor of direct EAS CLI usage and unified commands.

---

## 📋 Overview

This comprehensive guide covers the complete TestFlight distribution process for the SpaceWalker mobile application, including:
- **Initial TestFlight setup** and App Store Connect configuration
- **Automated submission** via CI/CD pipeline
- **Beta tester management** and group organization
- **Distribution workflows** for internal and external testing
- **Troubleshooting** common TestFlight issues

---

## 🎯 TestFlight Distribution Strategy

### Distribution Tiers

| Tier | Purpose | Audience | Duration | Review Required |
|------|---------|----------|----------|-----------------|
| **Internal Testing** | Development team | Internal developers | Immediate | No |
| **External Beta** | Quality assurance | QA team, stakeholders | 1-3 days | No |
| **Public Beta** | Pre-release testing | Selected users | 1-3 days | Yes (Apple Review) |
| **Production** | App Store release | All users | 24-48 hours | Yes (App Review) |

### Release Channels

```mermaid
graph TD
    A[Development Build] --> B[Internal Testing]
    B --> C[External Beta]
    C --> D[Public Beta]
    D --> E[App Store Release]

    A1[EAS Build Commands] --> B
    B --> C1[TestFlight Groups]
    C --> D1[Public Beta Groups]
    D --> E1[App Store Connect]
```

---

## 🚀 Initial TestFlight Setup

### 1. App Store Connect Configuration

#### Create App Record
1. **Login to App Store Connect**
   - Go to [App Store Connect](https://appstoreconnect.apple.com)
   - Sign in with your Apple Developer account

2. **Create New App**
   - Click "+" → "New App"
   - **Platform**: iOS
   - **Name**: SpaceWalker
   - **Primary Language**: English (U.S.)
   - **Bundle ID**: `com.degreeanalytics.spacewalker`
   - **SKU**: `spacewalker-001`

3. **Configure App Information**
   ```
   App Category: Business
   Secondary Category: Productivity
   Content Rights: No, it does not contain, show, or access third-party content
   Age Rating: 4+ (No Restricted Content)
   ```

4. **Set Export Compliance**
   - **Uses Encryption**: No (or configure based on app requirements)
   - **Exempt**: Check "Uses only standard encryption"

#### TestFlight Configuration
1. **Navigate to TestFlight Tab**
   - Select your app → TestFlight
   - Review TestFlight Beta App Information

2. **Configure Beta App Information**
   - **Beta App Name**: SpaceWalker
   - **Beta App Description**:
     ```
     SpaceWalker is a mobile inventory management application for building
     space documentation and analysis. This beta version includes:

     - Building and room documentation
     - Camera-based inventory capture
     - AI-powered room analysis
     - Real-time sync with backend systems

     Please report any issues or feedback to the development team.
     ```
   - **Feedback Email**: `spacewalker-feedback@degreeanalytics.com`
   - **Marketing URL**: (Optional)
   - **Privacy Policy URL**: (If applicable)

3. **Set Beta App Review Information**
   ```
   App Review Information:
   - First Name: [Admin First Name]
   - Last Name: [Admin Last Name]
   - Email: [Admin Email]
   - Phone: [Admin Phone]
   - Review Notes: Standard beta testing app for internal QA
   ```

### 2. App Store Connect API Setup

#### Generate API Key
1. **Navigate to Users and Access**
   - App Store Connect → Users and Access
   - Integrations → App Store Connect API

2. **Create API Key**
   - **Name**: `SpaceWalker CI/CD`
   - **Access**: App Manager
   - **Download**: `.p8` file (save securely - only available once!)
   - **Save Key Information**:
     - Key ID: `ABC123DEF4`
     - Issuer ID: `12345678-1234-1234-1234-123456789012`

#### Configure GitHub Secrets
```bash
# Required for automated TestFlight submission
APP_STORE_CONNECT_API_KEY_ID=ABC123DEF4
APP_STORE_CONNECT_API_ISSUER_ID=12345678-1234-1234-1234-123456789012
APP_STORE_CONNECT_API_KEY=<base64-encoded-p8-file>

# Encode .p8 file:
base64 -i AuthKey_ABC123DEF4.p8 | pbcopy
```

### 3. EAS Configuration Verification

Ensure `apps/mobile/eas.json` is properly configured:

```json
{
  "cli": {
    "version": ">= 12.0.0"
  },
  "build": {
    "production": {
      "credentialsSource": "remote",
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "https://api.spacewalker.com",
        "EXPO_PUBLIC_APP_VARIANT": "production"
      },
      "ios": {
        "resourceClass": "default",
        "autoIncrement": true
      }
    }
  },
  "submit": {
    "production": {
      "ios": {
        "appleId": "chad.walters@gmail.com",
        "appleTeamId": "F43878J8DN",
        "ascAppId": "6748350302",
        "sku": "spacewalker-001",
        "language": "en-US"
      }
    }
  }
}
```

---

## 🤖 Automated TestFlight Submission

### CI/CD Workflow Overview

The automated TestFlight submission workflow is triggered by:
- **Push to main branch** with changes in `apps/mobile/**`
- **Successful EAS build** completion
- **Production build profile** used

### 🔄 Automated Version Sync

**Critical Feature**: Prevents TestFlight duplicate build submission failures through automated version and build number management.

#### How It Works
Before each EAS build, the CI/CD pipeline automatically:

1. **Extracts semantic version** from build metadata (e.g., `1.0.4-dev.20250718.abc123` → `1.0.4`)
2. **Generates unique build number** using timestamp format `YYMMDDHHMM` (e.g., `2507181445`)
3. **Updates app.json** with synchronized versions:
   - `expo.version`: Clean semantic version (`1.0.4`)
   - `expo.ios.buildNumber`: Unique timestamp (`2507181445`)
   - `expo.android.versionCode`: Same timestamp for consistency

#### Pipeline Integration
```yaml
# Automatic execution in CI/CD
- name: Sync version and build number
  run: |
    cd apps/mobile
    bash ../../scripts/eas_version_sync.sh "$SEMANTIC_VERSION"
```

#### Build Number Format
**Pattern**: `YYMMDDHHMM` ensures uniqueness and chronological ordering
- `2507181445` = July 18, 2025 at 14:45
- `2507181446` = July 18, 2025 at 14:46

#### Benefits
- **Eliminates duplicate build errors**: Each build has guaranteed unique identifier
- **Prevents submission failures**: No more "You've already submitted this build" errors
- **Maintains consistency**: Same versioning across iOS and Android platforms
- **Zero manual intervention**: Fully automated in CI/CD pipeline

#### Monitoring Version Sync
```bash
# Check current app.json state
cd apps/mobile
cat app.json | jq '{version: .expo.version, ios: .expo.ios.buildNumber, android: .expo.android.versionCode}'

# View CI/CD logs for version sync output
gh run list --workflow "CI/CD Pipeline" --limit 3
gh run view <run-id> --log | rg -A 10 "Syncing version"

# Validate build number uniqueness
eas build:list --platform ios --json | jq '.[].metadata.buildNumber' | sort | uniq -d
```

**Related Documentation**: [EAS Version Sync System](./eas-version-sync.md) for detailed technical implementation.

### Workflow Stages

#### 1. Build Stage (15-30 minutes)
```bash
# Triggered automatically on main branch push
# Builds production iOS app bundle
eas build --platform ios --profile production --non-interactive
```

#### 2. Wait Stage (5 minutes)
```bash
# Allows EAS to process and finalize build
# Ensures build artifacts are ready for submission
sleep 300
```

#### 3. Submission Stage (5-10 minutes)
```bash
# Submits latest build to TestFlight
eas submit --platform ios --latest --profile production --non-interactive
```

#### 4. Apple Processing (10-15 minutes)
- Apple processes submission
- Performs automated security scanning
- Makes build available to beta testers

### Manual Submission Commands

```bash
# Navigate to mobile directory
cd apps/mobile

# Build production iOS
eas build --platform ios --profile production

# Submit to TestFlight (after build completes)
./scripts/submit-to-testflight.sh production ios

# Or submit using EAS directly
eas submit --platform ios --latest --profile production

# Check submission status
eas submit:list --platform ios
```

---

## 👥 Beta Tester Management

### Internal Testing Groups

#### Development Team Group
- **Purpose**: Immediate testing by development team
- **Size**: 5-10 members
- **Access**: Automatic upon build completion
- **Feedback**: Direct to development channels

**Setup**:
1. TestFlight → Internal Testing → "+" Create Group
2. **Group Name**: "Development Team"
3. **Add Members**: Development team Apple IDs
4. **Enable Auto-Add**: Check "Automatically distribute to this group"

#### QA Team Group
- **Purpose**: Quality assurance testing
- **Size**: 5-15 members
- **Access**: Manual distribution after development team approval
- **Feedback**: Structured feedback via designated channels

**Setup**:
1. Create Group: "QA Team"
2. Add QA team members
3. Configure manual distribution
4. Set feedback guidelines

### External Testing Groups

#### Stakeholder Group
- **Purpose**: Stakeholder and client preview
- **Size**: 10-25 members
- **Access**: Manual distribution for milestone builds
- **Feedback**: High-level feature feedback

#### Beta User Group
- **Purpose**: Real user testing
- **Size**: 50-100 members
- **Access**: Selective distribution for release candidates
- **Feedback**: User experience and bug reports

**Public Beta Setup** (Requires Apple Review):
1. TestFlight → External Testing → "+" Create Group
2. **Group Name**: "Public Beta Users"
3. **Public Link**: Enable for easy tester recruitment
4. **Apple Review**: Submit for public beta review

### Tester Invitation Process

#### Internal Testers
1. **Add via Email**:
   - TestFlight → Internal Testing → Group → Add Testers
   - Enter Apple ID email addresses
   - Send invitations

2. **Automatic Distribution**:
   - Enable for development team
   - New builds automatically available

#### External Testers
1. **Individual Invitations**:
   ```
   Subject: SpaceWalker Beta Testing Invitation

   You're invited to test SpaceWalker, our mobile inventory management app.

   To join:
   1. Install TestFlight from the App Store
   2. Tap this link on your iOS device: [TestFlight Link]
   3. Accept the invitation
   4. Install SpaceWalker when available

   Please provide feedback on:
   - App functionality and performance
   - User interface and experience
   - Any bugs or issues encountered

   Contact: spacewalker-feedback@degreeanalytics.com
   ```

2. **Public Beta Links**:
   - Generate shareable link in TestFlight
   - Include in documentation, emails, or websites
   - Monitor tester capacity (10,000 external tester limit)

---

## 📋 Distribution Workflows

### Development Build Distribution

```bash
# 1. Build development version
cd apps/mobile
eas build --platform ios --profile development

# 2. Internal team receives automatically
# (if auto-distribution enabled)

# 3. Manual distribution to QA
# App Store Connect → TestFlight → Select Build → Add Group
```

### Preview Build Distribution

```bash
# 1. Build preview version (points to dev backend)
cd apps/mobile
eas build --platform ios --profile preview

# 2. Distribute to stakeholders
# App Store Connect → TestFlight → External Testing → Add Group

# 3. Send notification email
# Include: features to test, known issues, feedback channels
```

### Production Release Candidate

```bash
# 1. Build production version
eas build --platform ios --profile production

# 2. Internal testing first
# Development team → QA team

# 3. External beta distribution
# Stakeholders → Beta users

# 4. Collect feedback and iterate

# 5. App Store submission (if approved)
# App Store Connect → App Store → Submit for Review
```

### Emergency Build Distribution

```bash
# 1. Hot fix build
cd apps/mobile
eas build --platform ios --profile production --priority=urgent

# 2. Direct distribution to affected groups
# Skip normal workflow for critical issues

# 3. Immediate notification
# Alert testers of urgent fix

# 4. Expedited feedback collection
# Focus on specific issue validation
```

---

## 📊 Build and Distribution Monitoring

### GitHub Actions Monitoring

#### Status Checks
- **`eas-build/production`**: Build completion status
- **`testflight-submission`**: Submission status
- **`release-notes-generation`**: Release notes creation

#### Notification Channels

**Slack Integration** (if configured):
```bash
# Add to GitHub Secrets:
SLACK_WEBHOOK_URL=<your-slack-webhook-url>

# Notifications include:
# - Build completion
# - TestFlight submission success/failure
# - Direct links to builds and logs
```

**Email Notifications**:
- GitHub Actions email notifications
- TestFlight submission confirmations
- Apple processing status updates

### TestFlight Analytics

#### Usage Metrics
- **Download Rate**: Percentage of invited testers who install
- **Session Duration**: How long testers use the app
- **Crash Rate**: Frequency of app crashes during testing
- **Feedback Rate**: Percentage of testers providing feedback

#### Monitoring Dashboard
```bash
# View TestFlight analytics:
# App Store Connect → TestFlight → TestFlight Analytics

# Key metrics to track:
# - Active testers over time
# - Install rate by group
# - Feedback submission rate
# - Crash statistics
```

### Build Artifacts and Logs

#### GitHub Actions Artifacts
```bash
# Download from GitHub Actions:
# - eas-build-logs-* (build process logs)
# - testflight-submission-logs-* (submission logs)
# - release-notes-* (generated release notes)
```

#### EAS Build Dashboard
```bash
# Check build status:
cd apps/mobile
eas build:list --platform ios --limit 10

# View detailed build logs:
eas logs --build-id <build-id>
```

---

## 🔧 Troubleshooting

### Common TestFlight Issues

#### 1. Submission Failures

**"App Store Connect API key expired"**
```bash
# Solution:
# 1. Check if API key was revoked in App Store Connect
# 2. Regenerate key if necessary
# 3. Update GitHub secrets with new key
```

**"Build not found for submission"**
```bash
# Solution:
# 1. Check EAS build status: cd apps/mobile && eas build:list
# 2. Ensure build completed successfully
# 3. Wait additional time for Apple processing
# 4. Try manual submission: ./scripts/submit-to-testflight.sh
```

**"Invalid credentials or permissions"**
```bash
# Solution:
# 1. Verify API key permissions in App Store Connect
# 2. Check base64 encoding of .p8 file
# 3. Ensure Apple Team ID matches
# 4. Verify ascAppId is correct
```

#### 2. Build Distribution Issues

**"Testers not receiving builds"**
```bash
# Solution:
# 1. Check group settings in TestFlight
# 2. Verify auto-distribution is enabled
# 3. Ensure testers have accepted invitations
# 4. Check build approval status
```

**"External testing not available"**
```bash
# Solution:
# 1. Submit app for external beta review
# 2. Ensure all required metadata is complete
# 3. Check beta app information compliance
# 4. Wait for Apple approval (24-48 hours)
```

#### 3. Tester Management Issues

**"Unable to add testers"**
```bash
# Solution:
# 1. Check tester limit (100 internal, 10,000 external)
# 2. Verify email addresses are valid Apple IDs
# 3. Ensure testers haven't already been invited
# 4. Check App Store Connect permissions
```

**"Testers can't install app"**
```bash
# Solution:
# 1. Verify device compatibility (iOS version, device type)
# 2. Check TestFlight app is installed on device
# 3. Ensure invitation was accepted
# 4. Try removing and re-adding tester
```

### Debug and Recovery Commands

#### Build Recovery
```bash
# Check recent builds
cd apps/mobile
eas build:list --platform ios --limit 5

# Manual build if CI fails
eas build --platform ios --profile production

# Manual submission
./scripts/submit-to-testflight.sh production ios

# Check submission status
eas submit:list --platform ios
```

#### Configuration Validation
```bash
# Validate EAS configuration
cd apps/mobile && eas build:configure

# Check credentials
eas credentials --platform ios

# Validate app.config.js
expo config --type public

# Test local submission
eas submit --platform ios --latest --profile production --dry-run
```

#### Log Analysis
```bash
# View detailed build logs
eas logs --build-id <build-id>

# Check CI/CD logs
# GitHub → Actions → Workflow runs → View logs

# Download log artifacts
# GitHub → Actions → Artifacts → Download
```

---

## 📈 Best Practices

### Release Management

#### 1. Version Control
```bash
# Use semantic versioning
1.0.0 → 1.0.1 (patch)
1.0.1 → 1.1.0 (minor)
1.1.0 → 2.0.0 (major)

# Tag releases
git tag -a v1.0.0 -m "Production release v1.0.0"
git push origin v1.0.0
```

#### 2. Build Validation
```bash
# Before TestFlight submission:
just test all mobile              # Run all tests
just lint check mobile            # Code quality check
cd apps/mobile && eas build --platform ios --profile development  # Test build process
```

#### 3. Release Notes
```bash
# Auto-generated from commits:
git log v1.0.0..HEAD --oneline --grep="feat\|fix\|mobile"

# Manual enhancement in TestFlight:
# App Store Connect → TestFlight → Build → What to Test
```

### Tester Management

#### 1. Group Organization
- **Keep groups small** for focused feedback
- **Use descriptive names** (Development, QA, Stakeholders)
- **Rotate external testers** to get fresh perspectives
- **Monitor engagement** and remove inactive testers

#### 2. Feedback Collection
```bash
# Structured feedback forms:
# - What feature were you testing?
# - What device and iOS version?
# - Steps to reproduce any issues
# - Screenshots or videos (if applicable)
# - Overall feedback and suggestions
```

#### 3. Communication
- **Clear release notes** for each build
- **Regular updates** on testing progress
- **Prompt responses** to tester feedback
- **Acknowledgment** of reported issues

### Security and Compliance

#### 1. API Key Management
- **Rotate keys** every 6-12 months
- **Use least privilege** permissions
- **Monitor usage** in App Store Connect
- **Secure storage** of .p8 files

#### 2. Tester Privacy
- **Limit personal data** in test builds
- **Clear privacy policies** for beta testing
- **Secure feedback channels** for sensitive issues
- **Regular cleanup** of inactive testers

#### 3. Compliance Monitoring
- **Export compliance** settings
- **Content rating** accuracy
- **App Store guidelines** adherence
- **Beta testing policies** compliance

---

## 📚 Release Workflow Examples

### Standard Release Workflow

```bash
# 1. Development and testing
git checkout -b feature/new-feature
# ... develop feature ...
just test all mobile
git commit -m "feat(mobile): add new feature"

# 2. Merge to main (triggers CI/CD)
git checkout main
git merge feature/new-feature
git push origin main

# 3. Automatic build and TestFlight submission
# (GitHub Actions handles this automatically)

# 4. Monitor submission
cd apps/mobile && eas build:list --platform ios
# Check GitHub Actions for status

# 5. Notify testers
# Send email or Slack notification about new build

# 6. Collect feedback
# Monitor TestFlight feedback and external channels

# 7. Iterate or promote
# Fix issues or promote to App Store
```

### Emergency Hotfix Workflow

```bash
# 1. Create hotfix branch
git checkout -b hotfix/critical-fix main

# 2. Implement fix
# ... fix critical issue ...
just test unit mobile --pattern="critical"

# 3. Emergency merge
git checkout main
git merge hotfix/critical-fix
git push origin main

# 4. Monitor urgent deployment
# Watch GitHub Actions closely

# 5. Direct notification
# Immediately notify key testers

# 6. Expedited validation
# Focus testing on fix verification

# 7. Fast-track to production
# If validated, submit to App Store immediately
```

### Feature Preview Workflow

```bash
# 1. Build preview version
cd apps/mobile && eas build --platform ios --profile preview

# 2. Selective distribution
# Add only stakeholder group

# 3. Structured feedback session
# Schedule demo/feedback call

# 4. Iterate based on feedback
# Make adjustments before wider release

# 5. Broader beta distribution
# Add external testing groups

# 6. Final validation
# Complete testing cycle

# 7. Production release
# Submit to App Store when ready
```

---

## 📊 Success Metrics

### Distribution Metrics
- **Submission Success Rate**: >95% of CI/CD submissions succeed
- **Time to TestFlight**: <60 minutes from main branch push
- **Tester Adoption Rate**: >80% of invited testers install builds
- **Feedback Response Rate**: >30% of testers provide feedback

### Quality Metrics
- **Crash Rate**: <2% during beta testing
- **Critical Issues**: <1 per build
- **Feedback Resolution**: <48 hours response time
- **Build Iteration**: <3 builds per feature cycle

### Process Metrics
- **Release Frequency**: Weekly beta releases
- **Time to Market**: <2 weeks from feature complete to App Store
- **Automation Coverage**: >90% of releases automated
- **Manual Intervention**: <10% of submissions require manual steps

---

## 📚 Related Documentation

- **[Mobile Architecture](./architecture.md)** - Dual-mode configuration system
- **[Environment Configuration](./environment-config.md)** - Environment setup guide
- **[Build Pipeline](./build-pipeline.md)** - EAS build troubleshooting
- **[Mobile Development Workflows](../workflows/mobile-development.md)** - Complete development guide
- **[GitHub Actions Configuration](./deployment/github-actions-config.md)** - CI/CD setup

### External Resources
- **[TestFlight Documentation](https://developer.apple.com/testflight/)**
- **[App Store Connect API](https://developer.apple.com/documentation/appstoreconnectapi)**
- **[EAS Submit Documentation](https://docs.expo.dev/submit/introduction/)**
- **[Apple Beta Testing Guidelines](https://developer.apple.com/app-store/review/guidelines/#beta-testing)**

---

**Last Updated**: {{ current_date }}
**Guide Version**: 2.0 (Automated Distribution)
**TestFlight Status**: ✅ Fully Configured and Operational
