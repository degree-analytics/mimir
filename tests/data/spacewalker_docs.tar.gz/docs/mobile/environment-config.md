# Mobile Environment Configuration Guide

**SpaceWalker Mobile App** - Complete guide to environment setup, configuration management, and troubleshooting

---

## 📋 Overview

This guide covers the complete setup and configuration of the SpaceWalker mobile application across different environments. The app uses a **dual-mode configuration system** that supports both local development and production builds.

---

## 🎯 Environment Types

| Environment | Purpose | API Endpoint | Bundle ID | Build Profile |
|-------------|---------|--------------|-----------|---------------|
| **Development** | Local development | `http://localhost:8000` | `com.degreeanalytics.spacewalker.dev` | `development` |
| **Preview** | Testing with dev backend | `https://backend.spacewalker.littleponies.com` | `com.degreeanalytics.spacewalker.preview` | `preview` |
| **Production** | App store releases | `https://api.spacewalker.com` | `com.degreeanalytics.spacewalker` | `production` |

---

## 🚀 Quick Start

### 1. Prerequisites

Before setting up the mobile app, ensure you have:

```bash
# Required software
node --version    # Should be v20.19.4 (exact version)
npm --version     # Should be >=10.0.0
expo --version    # Latest version recommended

# Platform-specific requirements
# iOS: Xcode 14.0+, iOS Simulator 16.0+
# Android: Android Studio, Android SDK 33+
```

### 2. Initial Setup

```bash
# Clone and setup the project
git clone <repository-url>
cd spacewalker

# Install dependencies and setup environment
just env_setup

# Start mobile development server
just expo start --offline
```

### 3. First-Time Configuration

```bash
# Update mobile IP configuration for local development
just expo ip auto

# Verify environment setup
just mobile_env_validate

# Start all services
just up
```

---

## 🔧 Environment Variables

### Required Variables

#### **Development Environment** (`.env.local`)

```bash
# API Configuration
EXPO_PUBLIC_API_BASE_URL=http://localhost:8000
EXPO_PUBLIC_APP_VARIANT=development

# Bundle Configuration
EXPO_PUBLIC_BUNDLE_ID_IOS=com.degreeanalytics.spacewalker.dev
EXPO_PUBLIC_BUNDLE_ID_ANDROID=com.degreeanalytics.spacewalker.dev

# Optional: AI Services (for room analysis features)
EXPO_PUBLIC_GEMINI_API_KEY=your_gemini_api_key_here

# Environment Identifier
EXPO_PUBLIC_ENVIRONMENT=local
```

#### **Preview Environment** (EAS Build)

These variables are configured in `eas.json` for preview builds:

```json
{
  "build": {
    "preview": {
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "https://backend.spacewalker.littleponies.com",
        "EXPO_PUBLIC_APP_VARIANT": "preview",
        "EXPO_PUBLIC_BUNDLE_ID_IOS": "com.degreeanalytics.spacewalker.preview",
        "EXPO_PUBLIC_BUNDLE_ID_ANDROID": "com.degreeanalytics.spacewalker.preview"
      }
    }
  }
}
```

#### **Production Environment** (EAS Build)

Production variables are configured in `eas.json`:

```json
{
  "build": {
    "production": {
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "https://api.spacewalker.com",
        "EXPO_PUBLIC_APP_VARIANT": "production",
        "EXPO_PUBLIC_BUNDLE_ID_IOS": "com.degreeanalytics.spacewalker",
        "EXPO_PUBLIC_BUNDLE_ID_ANDROID": "com.degreeanalytics.spacewalker"
      }
    }
  }
}
```

### Variable Types and Usage

#### `EXPO_PUBLIC_*` Variables (Build-Time)

These variables are embedded into the app bundle during EAS builds:

- **`EXPO_PUBLIC_API_BASE_URL`**: Backend API endpoint
- **`EXPO_PUBLIC_APP_VARIANT`**: Environment identifier (development/preview/production)
- **`EXPO_PUBLIC_BUNDLE_ID_IOS`**: iOS bundle identifier
- **`EXPO_PUBLIC_BUNDLE_ID_ANDROID`**: Android package name
- **`EXPO_PUBLIC_GEMINI_API_KEY`**: AI service API key

#### Runtime Variables (Development)

These variables are used during local development:

- **`API_BASE_URL`**: Runtime API endpoint override
- **`APP_VARIANT`**: Runtime environment override
- **`GEMINI_API_KEY`**: Runtime AI service key

---

## 🛠️ Configuration Files

### 1. App Configuration (`app.config.js`)

The main Expo configuration file that handles environment-specific settings:

```javascript
export default ({ config }) => ({
  ...config,
  name: "Spacewalker",
  slug: "spacewalker",
  version: "1.0.0",

  // Dynamic bundle ID based on environment
  ios: {
    bundleIdentifier: validateBundleId(
      process.env.EXPO_PUBLIC_BUNDLE_ID_IOS,
      'ios'
    ) || "com.degreeanalytics.spacewalker",
    appleTeamId: "F43878J8DN",
    deploymentTarget: "13.0"
  },

  android: {
    package: validateBundleId(
      process.env.EXPO_PUBLIC_BUNDLE_ID_ANDROID,
      'android'
    ) || "com.degreeanalytics.spacewalker",
    compileSdkVersion: 34,
    targetSdkVersion: 34
  },

  // Runtime configuration available via Constants.expoConfig.extra
  extra: {
    API_BASE_URL: process.env.API_BASE_URL || "http://localhost:8000",
    APP_VARIANT: process.env.APP_VARIANT || "development",
    EXPO_PUBLIC_API_BASE_URL: process.env.EXPO_PUBLIC_API_BASE_URL,
    EXPO_PUBLIC_APP_VARIANT: process.env.EXPO_PUBLIC_APP_VARIANT
  }
});
```

### 2. EAS Configuration (`eas.json`)

Defines build profiles for different environments:

```json
{
  "cli": {
    "version": ">= 12.0.0"
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal",
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "http://localhost:8000",
        "EXPO_PUBLIC_APP_VARIANT": "development"
      },
      "ios": {
        "simulator": true
      },
      "android": {
        "buildType": "apk"
      }
    },
    "preview": {
      "distribution": "internal",
      "credentialsSource": "remote",
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "https://backend.spacewalker.littleponies.com",
        "EXPO_PUBLIC_APP_VARIANT": "preview"
      }
    },
    "production": {
      "credentialsSource": "remote",
      "env": {
        "EXPO_PUBLIC_API_BASE_URL": "https://api.spacewalker.com",
        "EXPO_PUBLIC_APP_VARIANT": "production"
      }
    }
  },
  "submit": {
    "production": {
      "ios": {
        "appleId": "chad.walters@gmail.com",
        "appleTeamId": "F43878J8DN",
        "ascAppId": "6748350302"
      }
    }
  }
}
```

### 3. Environment Module (`src/config/environment.ts`)

The main configuration module that handles dual-mode configuration:

```typescript
import { getConfig } from './config-utils';

export type AppVariant = 'development' | 'preview' | 'production';

/**
 * Get the current app variant using dual-mode configuration
 */
export const getAppVariant = (): AppVariant => {
  const variant = getConfig('APP_VARIANT', 'development') as AppVariant;

  if (['development', 'preview', 'production'].includes(variant)) {
    return variant;
  }

  console.warn(`⚠️  Invalid APP_VARIANT: ${variant}, falling back to development`);
  return 'development';
};

/**
 * Get the API URL using dual-mode configuration
 */
export const getApiUrl = (): string => {
  // Try new API_BASE_URL variable
  const newConfigUrl = getConfig('API_BASE_URL');
  if (newConfigUrl) return newConfigUrl;

  // Backward compatibility with API_URL
  const legacyConfigUrl = getConfig('API_URL');
  if (legacyConfigUrl) {
    console.warn('⚠️  Using deprecated API_URL. Please update to API_BASE_URL');
    return legacyConfigUrl;
  }

  // Fallback to app variant-based defaults
  const appVariant = getAppVariant();
  const fallbackUrls = {
    production: 'https://api.spacewalker.com',
    preview: 'https://backend.spacewalker.littleponies.com',
    development: 'http://localhost:8000'
  };

  return fallbackUrls[appVariant];
};
```

---

## 📱 Platform-Specific Setup

### iOS Development

#### Requirements
- **Xcode**: 14.0 or later
- **iOS Simulator**: 16.0 or later
- **Apple Developer Account**: For device testing and TestFlight

#### Setup Steps

1. **Install Xcode** from the Mac App Store
2. **Install iOS Simulator** and required runtime versions
3. **Configure Apple Team ID** in `app.config.js`:
   ```javascript
   ios: {
     appleTeamId: "F43878J8DN", // Your team ID
     deploymentTarget: "13.0"
   }
   ```

#### Building for iOS

```bash
# Development build (simulator only)
just mobile_build_ios_local

# Preview build (TestFlight)
just mobile_build_ios_dev

# Production build
eas build --platform ios --profile production
```

### Android Development

#### Requirements
- **Android Studio**: Latest version
- **Android SDK**: API level 33 or later
- **Google Play Console**: For Play Store distribution

#### Setup Steps

1. **Install Android Studio** with Android SDK
2. **Configure Android SDK** paths:
   ```bash
   export ANDROID_HOME=$HOME/Library/Android/sdk
   export PATH=$PATH:$ANDROID_HOME/emulator
   export PATH=$PATH:$ANDROID_HOME/tools
   export PATH=$PATH:$ANDROID_HOME/platform-tools
   ```

3. **Setup service account** for automated uploads:
   - Place `service-account-key.json` in `apps/mobile/android/`
   - Configure in `eas.json`:
     ```json
     "android": {
       "serviceAccountKeyPath": "android/service-account-key.json"
     }
     ```

#### Building for Android

```bash
# Development build (APK)
just mobile_build_android_local

# Preview build (AAB for testing)
just mobile_build_android_dev

# Production build
eas build --platform android --profile production
```

---

## 🔄 Environment Switching

### Local Development

For local development, you can switch environments by modifying environment variables:

#### Method 1: Environment Files

Create environment-specific files:

```bash
# .env.local (development)
EXPO_PUBLIC_API_BASE_URL=http://localhost:8000
EXPO_PUBLIC_APP_VARIANT=development

# .env.preview (preview testing)
EXPO_PUBLIC_API_BASE_URL=https://backend.spacewalker.littleponies.com
EXPO_PUBLIC_APP_VARIANT=preview

# .env.production (production testing)
EXPO_PUBLIC_API_BASE_URL=https://api.spacewalker.com
EXPO_PUBLIC_APP_VARIANT=production
```

#### Method 2: Runtime Override

```bash
# Start with specific environment
API_BASE_URL=https://backend.spacewalker.littleponies.com npm start

# Or export before starting
export API_BASE_URL=https://backend.spacewalker.littleponies.com
just expo start --offline
```

### EAS Builds

For EAS builds, the environment is determined by the build profile:

```bash
# Development build
eas build --platform all --profile development

# Preview build
eas build --platform all --profile preview

# Production build
eas build --platform all --profile production
```

---

## 🧪 Testing Configuration

### Environment Validation

The app includes built-in configuration validation:

```bash
# Run configuration validation
just mobile_env_validate

# Or in the app, check console for:
# ✅ Environment validation passed
#   App Variant: development
#   API URL: http://localhost:8000
```

### Testing Different Environments

#### Local Testing

```bash
# Test development environment
just expo start --offline
# Check: Orange "DEV" badge should appear

# Test with preview backend
API_BASE_URL=https://backend.spacewalker.littleponies.com just expo start --offline
# Check: API calls go to preview backend
```

#### Build Testing

```bash
# Build and test preview
eas build --platform ios --profile preview
# Install and check: Blue "PREVIEW" badge should appear

# Build and test production
eas build --platform ios --profile production
# Install and check: No badge should appear (production mode)
```

### Manual Testing Checklist

- [ ] **Environment badge** displays correctly for non-production
- [ ] **API calls** go to the correct backend endpoint
- [ ] **Authentication** works with the target backend
- [ ] **Image uploads** work with the configured storage
- [ ] **Error handling** displays appropriate messages
- [ ] **Network connectivity** is handled gracefully

---

## 🔧 Troubleshooting

### Common Issues

#### 1. API Connection Failed

**Symptoms**: Network errors, failed API calls, 404 responses

**Solutions**:
```bash
# Check current configuration
just mobile_config_debug

# Verify API URL is correct
curl -X GET "$(just mobile_get_api_url)/health/"

# Check backend is running
just health_backend

# Update IP configuration for local development
just expo ip auto
```

#### 2. Wrong Environment Detected

**Symptoms**: Unexpected environment badge, wrong API calls

**Solutions**:
```bash
# Check environment variables
env | grep EXPO_PUBLIC

# Verify app configuration
cat apps/mobile/app.config.js | grep -A5 extra

# Clear Expo cache
cd apps/mobile && npx expo start --clear
```

#### 3. Bundle ID Conflicts

**Symptoms**: Installation failures, certificate errors

**Solutions**:
```bash
# Check bundle IDs in configuration
grep -r BUNDLE_ID apps/mobile/

# Verify different IDs for each environment
cat apps/mobile/eas.json | jq '.build[].env | select(.EXPO_PUBLIC_BUNDLE_ID_IOS)'

# Clean and rebuild
just service clean mobile && just mobile_build_local
```

#### 4. Permission Issues

**Symptoms**: Camera/location not working, permission denied

**Solutions**:
```bash
# Check permission configuration
cat apps/mobile/app.config.js | grep -A10 permissions

# Reset simulator permissions
# iOS: Device > Erase All Content and Settings
# Android: Settings > Apps > Spacewalker > Permissions

# Verify permission descriptions
cat apps/mobile/app.config.js | grep -A5 infoPlist
```

#### 5. Build Failures

**Symptoms**: EAS build fails, compilation errors

**Solutions**:
```bash
# Check build logs
eas build:list --limit 5
eas logs --build-id <build-id>

# Validate configuration
just mobile_validate_config

# Clear dependencies and retry
just service clean mobile && just service install mobile
eas build --platform all --profile development --clear-cache
```

### Environment-Specific Issues

#### Development Environment

```bash
# Backend not responding
just health_backend
# If unhealthy: just up

# IP configuration outdated
just expo ip auto
# Restart: just expo start --offline

# Dependencies out of sync
just service clean mobile && just service install mobile
```

#### Preview Environment

```bash
# Backend deployment issues
just health dev
# Check: https://backend.spacewalker.littleponies.com/health/

# Build configuration errors
cat apps/mobile/eas.json | jq '.build.preview'
# Verify: API URL and bundle IDs are correct
```

#### Production Environment

```bash
# Certificate/provisioning issues
eas credentials

# App Store Connect configuration
# Verify: ascAppId and team settings in eas.json

# Production backend issues
curl -X GET https://api.spacewalker.com/health/
```

---

## 🔍 Debug Commands

### Configuration Debugging

```bash
# Show current environment configuration
just mobile_config_debug

# List all environment variables
just mobile_env_list

# Validate configuration
just mobile_env_validate

# Show API endpoint information
just mobile_api_info
```

### Build Debugging

```bash
# Check EAS build status
just mobile_build_status

# Show recent builds
eas build:list --limit 10

# Download and inspect build
just mobile_download_ios
```

### Runtime Debugging

```bash
# Start with debug logging
DEBUG=* just expo start --offline

# Monitor API calls
# Check network tab in React Native Debugger

# View device logs
# iOS: Xcode > Window > Devices and Simulators > Open Console
# Android: adb logcat
```

---

## 📚 Environment Setup Examples

### Complete Development Setup

```bash
# 1. Clone and install
git clone <repository-url>
cd spacewalker
just env_setup

# 2. Configure mobile environment
cd apps/mobile
cat > .env.local << 'EOF'
EXPO_PUBLIC_API_BASE_URL=http://localhost:8000
EXPO_PUBLIC_APP_VARIANT=development
EXPO_PUBLIC_GEMINI_API_KEY=your_key_here
EOF

# 3. Start services
just up

# 4. Start mobile development
just expo start --offline

# 5. Connect via Expo Go
# iOS: Open Camera app, scan QR code
# Android: Open Expo Go app, scan QR code
```

### Preview Testing Setup

```bash
# 1. Build preview version
eas build --platform ios --profile preview

# 2. Install via TestFlight or direct download
# Check build status: eas build:list

# 3. Verify environment
# Should show: Blue "PREVIEW" badge
# API calls should go to: https://backend.spacewalker.littleponies.com
```

### Production Release Setup

```bash
# 1. Build production version
eas build --platform all --profile production

# 2. Submit to App Store
eas submit --platform ios --profile production

# 3. Submit to Play Store
eas submit --platform android --profile production

# 4. Verify environment
# Should show: No environment badge (production mode)
# API calls should go to: https://api.spacewalker.com
```

---

## 🔒 Security Considerations

### Environment Variable Security

1. **Never commit secrets** to source control
2. **Use `EXPO_PUBLIC_` prefix** only for non-sensitive configuration
3. **Store sensitive keys** in EAS Secrets or CI environment variables
4. **Validate all inputs** from environment variables

### Bundle Security

1. **Use different bundle IDs** for each environment
2. **Enable code signing** for production builds
3. **Validate certificates** before distribution
4. **Monitor for security vulnerabilities** in dependencies

### API Security

1. **Use HTTPS** for all production endpoints
2. **Implement proper authentication** with JWT tokens
3. **Validate API responses** before processing
4. **Handle network errors** gracefully without exposing internals

---

## 📊 Configuration Summary

| Configuration Type | Development | Preview | Production |
|-------------------|-------------|---------|------------|
| **API Endpoint** | localhost:8000 | backend.spacewalker.littleponies.com | api.spacewalker.com |
| **Bundle ID Suffix** | .dev | .preview | (none) |
| **Environment Badge** | Orange "DEV" | Blue "PREVIEW" | Hidden |
| **Build Type** | Development Client | Internal Distribution | App Store |
| **Certificate Source** | Local | Remote | Remote |
| **Auto Increment** | No | Yes | Yes |

---

## 📚 Related Documentation

- **[Mobile Architecture](./architecture.md)** - Dual-mode configuration system details
- **[Build Pipeline Guide](./build-pipeline.md)** - EAS build troubleshooting
- **[TestFlight Deployment](./testflight-guide.md)** - Production deployment process
- **[Mobile Development Workflows](../workflows/mobile-development.md)** - Complete development guide
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General troubleshooting

---

**Last Updated**: {{ current_date }}
**Guide Version**: 2.0 (Dual-Mode Configuration)
