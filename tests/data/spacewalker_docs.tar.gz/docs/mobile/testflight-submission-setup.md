# TestFlight Automatic Submission Setup Guide

## Overview

This guide explains how to set up automatic TestFlight submission from GitHub Actions for SpaceWalker mobile builds. When configured, successful production builds from the main branch will automatically be submitted to TestFlight for beta distribution.

## Prerequisites

- Apple Developer account with Admin or App Manager role
- App Store Connect access
- Configured EAS build pipeline (Task #6)
- Production provisioning profiles and certificates

## Setup Steps

### 1. Generate App Store Connect API Key

App Store Connect API authentication is the recommended method for CI/CD automation as it doesn't require 2FA and has better security.

1. **Navigate to App Store Connect**
   - Go to [App Store Connect](https://appstoreconnect.apple.com)
   - Sign in with your Apple ID

2. **Access API Keys**
   - Click on "Users and Access"
   - Select "Integrations" → "App Store Connect API"
   - Click the "+" button to generate a new API key

3. **Configure the API Key**
   - **Name**: `SpaceWalker CI/CD`
   - **Access**: Choose "App Manager" role (minimum required for TestFlight submission)
   - Click "Generate"

4. **Download and Save Key Information**
   - **Key ID**: Copy and save (e.g., `ABC123DEF4`)
   - **Issuer ID**: Copy and save (e.g., `12345678-1234-1234-1234-123456789012`)
   - **Download .p8 file**: Click "Download API Key" - you can only download this once!
   - Store the .p8 file securely

### 2. Configure GitHub Secrets

Add the following secrets to your GitHub repository:

1. **Navigate to Repository Settings**
   - Go to your repository on GitHub
   - Click "Settings" → "Secrets and variables" → "Actions"

2. **Add Required Secrets**

   ```bash
   # Already configured (from Task #6)
   EXPO_TOKEN=<your-expo-access-token>

   # New secrets for TestFlight submission
   APP_STORE_CONNECT_API_KEY_ID=<key-id-from-step-1>
   APP_STORE_CONNECT_API_ISSUER_ID=<issuer-id-from-step-1>
   APP_STORE_CONNECT_API_KEY=<base64-encoded-p8-file>

   # Optional: For Slack notifications
   SLACK_WEBHOOK_URL=<your-slack-webhook-url>
   ```

3. **Encode the .p8 File**

   To add the API key file as a secret, you need to base64 encode it:

   ```bash
   # On macOS/Linux
   base64 -i AuthKey_ABC123DEF4.p8 | pbcopy

   # On Windows (PowerShell)
   [Convert]::ToBase64String([IO.File]::ReadAllBytes("AuthKey_ABC123DEF4.p8")) | Set-Clipboard
   ```

   Paste the encoded content as the value for `APP_STORE_CONNECT_API_KEY`.

### 3. Verify EAS Configuration

Ensure your `apps/mobile/eas.json` has the correct submit configuration:

```json
{
  "submit": {
    "production": {
      "ios": {
        "appleId": "your-apple-id@example.com",
        "appleTeamId": "F43878J8DN",
        "ascAppId": "6748350302",
        "sku": "spacewalker-001",
        "language": "en-US"
      }
    }
  }
}
```

### 4. Test the Setup

1. **Manual Test (Local)**
   ```bash
   # Test submission locally
   just mobile_submit_testflight
   ```

2. **CI/CD Test**
   - Create a test branch from main
   - Make a small change to trigger the workflow
   - Push to main (or create a PR and merge)
   - Monitor the GitHub Actions workflow

## Workflow Behavior

### Automatic Submission Triggers

TestFlight submission will automatically occur when:
- A push is made to the `main` branch
- The push includes changes to `apps/mobile/**`
- The EAS build completes successfully
- The build profile is `production`

### Submission Process

1. **Build Phase** (~15-30 minutes)
   - EAS builds the iOS app with production profile
   - Build artifacts are created and stored

2. **Wait Phase** (5 minutes)
   - Allows time for EAS to process the build
   - Ensures build is ready for submission

3. **Submission Phase** (~5-10 minutes)
   - Authenticates with App Store Connect
   - Submits the latest build to TestFlight
   - Includes retry logic for transient failures

4. **Processing Phase** (10-15 minutes)
   - Apple processes the submission
   - Beta testers receive email notifications
   - Build becomes available in TestFlight app

### Total Time: ~35-60 minutes from push to TestFlight availability

## Monitoring and Notifications

### GitHub Status Checks

The workflow creates status checks on commits:
- `eas-build/production` - Build status
- `testflight-submission` - Submission status

### Slack Notifications (Optional)

If `SLACK_WEBHOOK_URL` is configured, you'll receive:
- Build completion notifications
- TestFlight submission success/failure alerts
- Direct links to builds and logs

### Build Logs

Access detailed logs:
1. GitHub Actions tab → Workflow runs
2. Download artifacts:
   - `eas-build-logs-*` - Build process logs
   - `testflight-submission-logs-*` - Submission logs

## Troubleshooting

### Common Issues

1. **"App Store Connect API key expired"**
   - API keys don't expire, but check if the key was revoked
   - Regenerate the key in App Store Connect if needed

2. **"Build not found"**
   - The build may still be processing
   - Check EAS dashboard for build status
   - Increase wait time in workflow if needed

3. **"Invalid credentials"**
   - Verify all GitHub secrets are set correctly
   - Check base64 encoding of the .p8 file
   - Ensure API key has correct permissions

4. **"Submission failed with no clear error"**
   - Check if the app has all required metadata in App Store Connect
   - Ensure export compliance is configured
   - Verify TestFlight beta information is complete

### Manual Recovery

If automatic submission fails:

```bash
# Check recent builds
just mobile_build_status

# Submit manually
just mobile_submit_testflight

# Or use EAS CLI directly
cd apps/mobile
eas submit --platform ios --latest --profile production
```

## Security Considerations

- **API Key Storage**: The .p8 file should never be committed to the repository
- **Secret Rotation**: Rotate API keys periodically (every 6-12 months)
- **Access Control**: Limit GitHub secret access to required workflows only
- **Audit Trail**: Monitor App Store Connect for submission activities

## Best Practices

1. **Test Before Production**
   - Always test changes in preview builds first
   - Ensure all tests pass before merging to main

2. **Version Management**
   - Use semantic versioning for releases
   - Update version numbers before production builds
   - Tag releases for easier tracking

3. **Release Notes**
   - The workflow extracts commit messages for basic notes
   - For detailed notes, update TestFlight manually after submission

4. **Beta Testing Groups**
   - Configure internal and external groups in TestFlight
   - Manage tester access through App Store Connect

## Related Documentation

- [Mobile Build Workflow](../../.github/workflows/mobile-smart-build.yml) - Contains mobile build configuration
- [Mobile CI/CD Commands](../../justfile) - Search for `ci_mobile_*`
- [TestFlight Submission Script](../../scripts/submit-to-testflight.sh)
- [Apple Developer Documentation](https://developer.apple.com/documentation/appstoreconnectapi)

## Next Steps

After setting up automatic TestFlight submission:

1. Configure beta testing groups in App Store Connect
2. Set up external beta testing (requires Apple review)
3. Implement version bumping automation
4. Add production release workflow for App Store submission
