# Mobile State Management Architecture

## Purpose
Comprehensive state management architecture for the Spacewalker mobile application including global state patterns, local state strategies, and data persistence approaches.

## When to Use This
- Implementing state management patterns for React Native components
- Managing complex application state across multiple screens
- Designing data flow and state updates for mobile apps
- Keywords: React Context, state management, data flow, React hooks, mobile state

**Version:** 1.0
**Date:** 2025-01-06
**Status:** Current

## Key Concepts
- **Global State**: Application-wide state shared across all screens via React Context
- **Local State**: Component-specific state using React hooks (useState, useReducer)
- **Persistent State**: Data that survives app restarts using MMKV or SecureStore
- **State Synchronization**: Keeping local state in sync with backend data

## Global State Management Strategy

### Context Architecture Overview

The mobile app uses React Context API for global state management, organized into focused contexts for different concerns:

```mermaid
graph TD
    A[App Root] --> B[AuthProvider]
    B --> C[NavigationProvider]
    C --> D[DataProvider]
    D --> E[UIProvider]
    E --> F[Screen Components]

    B -.-> G[SecureStore Token]
    D -.-> H[MMKV Storage]
    E -.-> I[Theme & Preferences]

    classDef provider fill:#E3F2FD,stroke:#1976D2,color:#000000
    classDef storage fill:#F3E5F5,stroke:#7B1FA2,color:#000000
    classDef component fill:#E8F5E8,stroke:#388E3C,color:#000000

    class A,B,C,D,E provider
    class G,H,I storage
    class F component
```

### Authentication Context

```typescript
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (credentials: LoginCredentials) => Promise<AuthResponse>;
  register: (credentials: RegisterCredentials) => Promise<AuthResponse>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const login = useCallback(async (credentials: LoginCredentials) => {
    setIsLoading(true);
    try {
      const response = await authService.login(credentials);
      await TokenManager.setToken(response.token);
      setUser(response.user);
      return response;
    } catch (error) {
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    await TokenManager.clearToken();
    setUser(null);
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const token = await TokenManager.getToken();
      if (token) {
        const user = await authService.getProfile();
        setUser(user);
      }
    } catch (error) {
      await logout();
    } finally {
      setIsLoading(false);
    }
  }, [logout]);

  // Initialize auth state on app start
  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const value = useMemo(() => ({
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
    refreshUser,
  }), [user, isLoading, login, logout, refreshUser]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
```

### Survey Data Context

```typescript
interface SurveyContextType {
  currentSurvey: SurveyData | null;
  surveys: SurveyData[];
  pendingUploads: PendingSurvey[];
  createSurvey: (roomId: number) => void;
  updateSurvey: (surveyData: Partial<SurveyData>) => void;
  submitSurvey: (survey: SurveyData) => Promise<void>;
  loadSurveys: () => Promise<void>;
  syncPendingUploads: () => Promise<void>;
}

export const SurveyProvider = ({ children }: { children: ReactNode }) => {
  const [currentSurvey, setCurrentSurvey] = useState<SurveyData | null>(null);
  const [surveys, setSurveys] = useState<SurveyData[]>([]);
  const [pendingUploads, setPendingUploads] = useState<PendingSurvey[]>([]);

  const createSurvey = useCallback((roomId: number) => {
    const newSurvey: SurveyData = {
      id: generateUniqueId(),
      roomId,
      images: [],
      attributes: {},
      status: 'draft',
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setCurrentSurvey(newSurvey);
  }, []);

  const updateSurvey = useCallback((surveyData: Partial<SurveyData>) => {
    setCurrentSurvey(prev => prev ? {
      ...prev,
      ...surveyData,
      updatedAt: new Date(),
    } : null);
  }, []);

  const submitSurvey = useCallback(async (survey: SurveyData) => {
    try {
      // Attempt immediate upload
      await surveyService.submitSurvey(survey);

      // Success - add to completed surveys
      setSurveys(prev => [...prev, { ...survey, status: 'completed' }]);
      setCurrentSurvey(null);
    } catch (error) {
      // Failed - add to pending uploads queue
      const pendingSurvey: PendingSurvey = {
        ...survey,
        status: 'pending',
        retryCount: 0,
        lastAttempt: new Date(),
      };

      setPendingUploads(prev => [...prev, pendingSurvey]);
      await storageService.savePendingSurvey(pendingSurvey);

      throw error;
    }
  }, []);

  const syncPendingUploads = useCallback(async () => {
    for (const pendingSurvey of pendingUploads) {
      try {
        await surveyService.submitSurvey(pendingSurvey);

        // Success - move to completed
        setSurveys(prev => [...prev, { ...pendingSurvey, status: 'completed' }]);
        setPendingUploads(prev => prev.filter(p => p.id !== pendingSurvey.id));
        await storageService.removePendingSurvey(pendingSurvey.id);

      } catch (error) {
        // Update retry count
        const updatedPending = {
          ...pendingSurvey,
          retryCount: pendingSurvey.retryCount + 1,
          lastAttempt: new Date(),
        };

        setPendingUploads(prev =>
          prev.map(p => p.id === pendingSurvey.id ? updatedPending : p)
        );
        await storageService.savePendingSurvey(updatedPending);
      }
    }
  }, [pendingUploads]);

  // Load persisted data on mount
  useEffect(() => {
    const loadPersistedData = async () => {
      const saved = await storageService.getPendingSurveys();
      setPendingUploads(saved);
    };
    loadPersistedData();
  }, []);

  const value = useMemo(() => ({
    currentSurvey,
    surveys,
    pendingUploads,
    createSurvey,
    updateSurvey,
    submitSurvey,
    loadSurveys: async () => {
      const userSurveys = await surveyService.getUserSurveys();
      setSurveys(userSurveys);
    },
    syncPendingUploads,
  }), [
    currentSurvey,
    surveys,
    pendingUploads,
    createSurvey,
    updateSurvey,
    submitSurvey,
    syncPendingUploads,
  ]);

  return (
    <SurveyContext.Provider value={value}>
      {children}
    </SurveyContext.Provider>
  );
};
```

## Local State Management Patterns

### Screen-Level State

```typescript
interface ScreenStatePattern {
  // UI state
  loading: boolean;
  error: string | null;

  // Form state
  formData: Record<string, any>;
  formErrors: Record<string, string>;

  // List state
  items: any[];
  filteredItems: any[];
  searchQuery: string;
  selectedItems: Set<string>;
}

const useScreenState = <T>() => {
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<T | null>(null);

  const handleAsync = useCallback(async (asyncFn: () => Promise<T>) => {
    setLoading(true);
    setError(null);

    try {
      const result = await asyncFn();
      setData(result);
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    data,
    setData,
    handleAsync,
    clearError: () => setError(null),
  };
};
```

### Form State Management

```typescript
interface FormState<T> {
  values: T;
  errors: Partial<Record<keyof T, string>>;
  touched: Partial<Record<keyof T, boolean>>;
  isValid: boolean;
  isSubmitting: boolean;
}

const useForm = <T extends Record<string, any>>(
  initialValues: T,
  validationSchema: (values: T) => Partial<Record<keyof T, string>>
) => {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<Partial<Record<keyof T, string>>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof T, boolean>>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const setValue = useCallback((field: keyof T, value: any) => {
    setValues(prev => ({ ...prev, [field]: value }));

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  }, [errors]);

  const setFieldTouched = useCallback((field: keyof T) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  }, []);

  const validateForm = useCallback(() => {
    const newErrors = validationSchema(values);
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [values, validationSchema]);

  const submitForm = useCallback(async (onSubmit: (values: T) => Promise<void>) => {
    setIsSubmitting(true);

    try {
      if (validateForm()) {
        await onSubmit(values);
      }
    } finally {
      setIsSubmitting(false);
    }
  }, [values, validateForm]);

  const resetForm = useCallback(() => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
    setIsSubmitting(false);
  }, [initialValues]);

  const isValid = Object.keys(errors).length === 0;

  return {
    values,
    errors,
    touched,
    isValid,
    isSubmitting,
    setValue,
    setFieldTouched,
    validateForm,
    submitForm,
    resetForm,
  };
};
```

### List Management Hooks

```typescript
interface ListState<T> {
  items: T[];
  filteredItems: T[];
  selectedItems: Set<string>;
  searchQuery: string;
  sortConfig: SortConfig<T> | null;
}

const useListState = <T extends { id: string }>(
  initialItems: T[] = [],
  filterFn?: (item: T, query: string) => boolean
) => {
  const [items, setItems] = useState<T[]>(initialItems);
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortConfig, setSortConfig] = useState<SortConfig<T> | null>(null);

  const filteredItems = useMemo(() => {
    let filtered = items;

    // Apply search filter
    if (searchQuery && filterFn) {
      filtered = filtered.filter(item => filterFn(item, searchQuery));
    }

    // Apply sorting
    if (sortConfig) {
      filtered = [...filtered].sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [items, searchQuery, sortConfig, filterFn]);

  const toggleSelection = useCallback((id: string) => {
    setSelectedItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  }, []);

  const selectAll = useCallback(() => {
    setSelectedItems(new Set(filteredItems.map(item => item.id)));
  }, [filteredItems]);

  const clearSelection = useCallback(() => {
    setSelectedItems(new Set());
  }, []);

  return {
    items,
    filteredItems,
    selectedItems,
    searchQuery,
    sortConfig,
    setItems,
    setSearchQuery,
    setSortConfig,
    toggleSelection,
    selectAll,
    clearSelection,
  };
};
```

## Data Persistence Strategies

### Secure Token Storage

```typescript
import * as SecureStore from 'expo-secure-store';

export const TokenManager = {
  async setToken(token: string): Promise<void> {
    await SecureStore.setItemAsync('spacewalker_api_token', token);
  },

  async getToken(): Promise<string | null> {
    return await SecureStore.getItemAsync('spacewalker_api_token');
  },

  async clearToken(): Promise<void> {
    await SecureStore.deleteItemAsync('spacewalker_api_token');
  },
};
```

### Fast Local Storage with MMKV

```typescript
import { MMKV } from 'react-native-mmkv';

const storage = new MMKV({
  id: 'spacewalker-app',
  encryptionKey: 'your-encryption-key',
});

export const StorageService = {
  // Simple key-value storage
  set(key: string, value: string): void {
    storage.set(key, value);
  },

  get(key: string): string | undefined {
    return storage.getString(key);
  },

  // Object storage with JSON serialization
  setObject<T>(key: string, value: T): void {
    storage.set(key, JSON.stringify(value));
  },

  getObject<T>(key: string): T | null {
    const value = storage.getString(key);
    return value ? JSON.parse(value) as T : null;
  },

  // Survey-specific storage
  savePendingSurvey(survey: PendingSurvey): Promise<void> {
    const surveys = this.getPendingSurveys();
    const updated = surveys.filter(s => s.id !== survey.id);
    updated.push(survey);
    this.setObject('pending_surveys', updated);
    return Promise.resolve();
  },

  getPendingSurveys(): PendingSurvey[] {
    return this.getObject<PendingSurvey[]>('pending_surveys') || [];
  },

  removePendingSurvey(surveyId: string): Promise<void> {
    const surveys = this.getPendingSurveys();
    const filtered = surveys.filter(s => s.id !== surveyId);
    this.setObject('pending_surveys', filtered);
    return Promise.resolve();
  },

  // User preferences
  saveUserPreferences(preferences: UserPreferences): void {
    this.setObject('user_preferences', preferences);
  },

  getUserPreferences(): UserPreferences | null {
    return this.getObject<UserPreferences>('user_preferences');
  },

  // Cache management
  setCacheItem<T>(key: string, value: T, ttl: number = 3600000): void {
    const cacheItem = {
      value,
      timestamp: Date.now(),
      ttl,
    };
    this.setObject(`cache_${key}`, cacheItem);
  },

  getCacheItem<T>(key: string): T | null {
    const cacheItem = this.getObject<{value: T, timestamp: number, ttl: number}>(`cache_${key}`);

    if (!cacheItem) return null;

    const isExpired = Date.now() - cacheItem.timestamp > cacheItem.ttl;
    if (isExpired) {
      storage.delete(`cache_${key}`);
      return null;
    }

    return cacheItem.value;
  },

  clearCache(): void {
    const keys = storage.getAllKeys();
    keys.forEach(key => {
      if (key.startsWith('cache_')) {
        storage.delete(key);
      }
    });
  },
};
```

## State Synchronization Patterns

### Network-Aware State Updates

```typescript
import NetInfo from '@react-native-async-storage/async-storage';

const useNetworkSync = () => {
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const { syncPendingUploads } = useSurvey();

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      const wasOffline = !isOnline;
      const isNowOnline = state.isConnected ?? false;

      setIsOnline(isNowOnline);

      // Trigger sync when coming back online
      if (wasOffline && isNowOnline) {
        syncPendingUploads().catch(console.error);
      }
    });

    return unsubscribe;
  }, [isOnline, syncPendingUploads]);

  return { isOnline };
};
```

### Optimistic Updates with Rollback

```typescript
const useOptimisticUpdates = () => {
  const [optimisticUpdates, setOptimisticUpdates] = useState<Map<string, any>>(new Map());

  const performOptimisticUpdate = useCallback(async <T>(
    key: string,
    optimisticValue: T,
    asyncOperation: () => Promise<T>
  ): Promise<T> => {
    // Apply optimistic update immediately
    setOptimisticUpdates(prev => new Map(prev).set(key, optimisticValue));

    try {
      // Perform actual operation
      const result = await asyncOperation();

      // Success - remove optimistic update
      setOptimisticUpdates(prev => {
        const newMap = new Map(prev);
        newMap.delete(key);
        return newMap;
      });

      return result;
    } catch (error) {
      // Failure - rollback optimistic update
      setOptimisticUpdates(prev => {
        const newMap = new Map(prev);
        newMap.delete(key);
        return newMap;
      });

      throw error;
    }
  }, []);

  const getOptimisticValue = useCallback((key: string) => {
    return optimisticUpdates.get(key);
  }, [optimisticUpdates]);

  return {
    performOptimisticUpdate,
    getOptimisticValue,
    hasOptimisticUpdate: (key: string) => optimisticUpdates.has(key),
  };
};
```

## Performance Optimization Patterns

### Memoization Strategies

```typescript
// Expensive selector memoization
const useSurveySelector = (selector: (surveys: SurveyData[]) => any) => {
  const { surveys } = useSurvey();
  return useMemo(() => selector(surveys), [surveys, selector]);
};

// Component memoization with custom comparison
const MemoizedSurveyCard = React.memo(SurveyCard, (prevProps, nextProps) => {
  return (
    prevProps.survey.id === nextProps.survey.id &&
    prevProps.survey.updatedAt === nextProps.survey.updatedAt
  );
});

// Context value memoization to prevent unnecessary re-renders
const AuthProvider = ({ children }: { children: ReactNode }) => {
  // ... state logic ...

  const value = useMemo(() => ({
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
    refreshUser,
  }), [user, isLoading, login, logout, refreshUser]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
```

### State Update Batching

```typescript
const useBatchedUpdates = () => {
  const [pendingUpdates, setPendingUpdates] = useState<Map<string, any>>(new Map());

  const batchUpdate = useCallback((key: string, value: any) => {
    setPendingUpdates(prev => new Map(prev).set(key, value));
  }, []);

  const flushUpdates = useCallback((applyFn: (updates: Map<string, any>) => void) => {
    if (pendingUpdates.size > 0) {
      applyFn(pendingUpdates);
      setPendingUpdates(new Map());
    }
  }, [pendingUpdates]);

  // Auto-flush after a delay
  useEffect(() => {
    if (pendingUpdates.size > 0) {
      const timer = setTimeout(() => {
        flushUpdates((updates) => {
          // Apply batched updates
          console.log('Auto-flushing batched updates:', updates);
        });
      }, 100);

      return () => clearTimeout(timer);
    }
  }, [pendingUpdates, flushUpdates]);

  return { batchUpdate, flushUpdates };
};
```

## Related Documentation
- Mobile Architecture Overview → ../mobile/architecture/README.md
- Mobile Navigation Architecture → ./navigation.md
- Mobile Development Guide → ../mobile/development/README.md
- Backend API Integration → ../backend/architecture/api-contracts.md

---
Last Updated: 2025-06-28
Status: Current
