# Mobile Application Container Architecture

## Purpose
Detailed architecture documentation for the mobile application container in the Spacewalker system, including React Native implementation, offline-first design patterns, MMKV storage integration, and cross-platform deployment strategies. Essential reference for mobile developers working on the survey application.

## When to Use This
- Designing mobile application features and offline capabilities
- Understanding React Native architecture and Expo integration
- Implementing offline storage and synchronization patterns
- Planning mobile performance optimizations and deployment
- Troubleshooting mobile container interactions and data flow
- Keywords: React Native architecture, mobile containers, offline-first, MMKV storage, Expo SDK

**Version:** 2.0 (Extracted from system container documentation)
**Date:** 2025-06-29
**Status:** Current - Production Mobile Architecture

---

## 🏗️ Mobile Container Overview

> 📊 **System Context**: See [System Container Overview](../../architecture/system-container-overview.md) for complete system architecture and container relationships

The mobile application container provides the primary interface for field surveyors, implementing a comprehensive offline-first architecture that ensures survey data collection continues seamlessly regardless of network connectivity.

### Mobile Container Architecture
```
Field Surveyors → Mobile App → Local Storage → Background Sync → Backend API
        ↓             ↓            ↓               ↓              ↓
    User Input → React Native → MMKV Storage → Sync Queue → Data Persistence
        ↓             ↓            ↓               ↓              ↓
    Survey Data → State Management → Offline Cache → API Calls → Server Storage
```

---

## 📱 Mobile Application Container

### Technology Stack
- **Framework**: React Native with Expo SDK 52
- **Language**: TypeScript for type safety and developer experience
- **Storage**: MMKV for high-performance offline data persistence
- **State Management**: React Context API with custom hooks
- **Navigation**: Expo Router for type-safe navigation
- **Camera**: Expo Camera for photo capture and processing
- **Networking**: Fetch API with offline queue management

### Container Responsibilities
- **Survey Data Collection** - Intuitive interface for field data entry and photo capture
- **Offline Operation** - Complete functionality without network connectivity
- **Data Synchronization** - Intelligent background sync when connectivity returns
- **User Authentication** - Secure login and session management
- **Photo Management** - Image capture, storage, and upload coordination
- **Performance Optimization** - Battery-efficient operation and smooth user experience

### Application Architecture Pattern
```typescript
// React Native App Structure
src/
├── app/                       # Expo Router app directory
│   ├── (auth)/               # Authentication flow
│   ├── (tabs)/               # Main tabbed navigation
│   ├── survey/               # Survey creation and editing
│   └── sync/                 # Offline sync management
├── components/               # Reusable UI components
├── contexts/                 # Global state management
├── lib/                      # Services and utilities
│   ├── api/                  # API client and networking
│   ├── storage/              # MMKV storage abstraction
│   └── sync/                 # Background synchronization
├── types/                    # TypeScript type definitions
└── utils/                    # Helper functions and constants
```

### Mobile-Specific Design Patterns
- **Offline-First Architecture** - All operations work offline with background sync
- **Progressive Enhancement** - Features gracefully degrade based on connectivity
- **Optimistic UI Updates** - Immediate UI feedback with eventual consistency
- **Battery Optimization** - Efficient resource usage for extended field use
- **Cross-Platform Compatibility** - Consistent experience on iOS and Android

---

## 🔄 Offline-First Architecture

### Data Flow Strategy
The mobile application implements a sophisticated offline-first pattern that prioritizes user experience and data integrity regardless of network conditions.

```typescript
// Offline-First Data Flow
interface OfflineFirstService {
  // Always save locally first
  saveData(data: any): Promise<void>;

  // Queue for background sync
  queueForSync(operation: SyncOperation): Promise<void>;

  // Process sync queue when online
  processSyncQueue(): Promise<void>;

  // Handle conflicts during sync
  resolveConflicts(conflicts: Conflict[]): Promise<void>;
}
```

### MMKV Storage Integration
```typescript
// High-Performance Storage Implementation
import { MMKV } from 'react-native-mmkv';

class OfflineStorage {
  private storage = new MMKV({
    id: 'spacewalker-storage',
    encryptionKey: 'your-encryption-key',
  });

  // Survey data operations
  storeSurvey(survey: Survey): void {
    this.storage.set(`survey_${survey.id}`, JSON.stringify(survey));
  }

  getSurvey(surveyId: string): Survey | null {
    const data = this.storage.getString(`survey_${surveyId}`);
    return data ? JSON.parse(data) : null;
  }

  getAllSurveys(): Survey[] {
    const keys = this.storage.getAllKeys().filter(key => key.startsWith('survey_'));
    return keys.map(key => JSON.parse(this.storage.getString(key)!));
  }

  // Sync queue management
  addToSyncQueue(operation: SyncOperation): void {
    const queue = this.getSyncQueue();
    queue.push(operation);
    this.storage.set('sync_queue', JSON.stringify(queue));
  }

  getSyncQueue(): SyncOperation[] {
    const data = this.storage.getString('sync_queue');
    return data ? JSON.parse(data) : [];
  }

  clearSyncQueue(): void {
    this.storage.delete('sync_queue');
  }
}
```

### Background Synchronization
```typescript
// Intelligent Sync Management
class SyncService {
  private issyncing = false;
  private retryCount = 0;
  private maxRetries = 3;

  async startBackgroundSync(): Promise<void> {
    if (this.issyncing) return;

    this.issyncing = true;

    try {
      const isOnline = await this.checkConnectivity();
      if (!isOnline) {
        this.scheduleRetry();
        return;
      }

      await this.processSyncQueue();
      this.retryCount = 0; // Reset on success
    } catch (error) {
      this.handleSyncError(error);
    } finally {
      this.issyncing = false;
    }
  }

  private async processSyncQueue(): Promise<void> {
    const queue = offlineStorage.getSyncQueue();

    for (const operation of queue) {
      try {
        await this.syncOperation(operation);
      } catch (error) {
        // Mark operation as failed but continue with others
        await this.markOperationFailed(operation, error);
      }
    }

    // Clear successfully synced operations
    offlineStorage.clearSyncQueue();
  }

  private async syncOperation(operation: SyncOperation): Promise<void> {
    switch (operation.type) {
      case 'CREATE_SURVEY':
        await apiClient.createSurvey(operation.data);
        break;
      case 'UPDATE_SURVEY':
        await apiClient.updateSurvey(operation.id, operation.data);
        break;
      case 'UPLOAD_PHOTO':
        await apiClient.uploadPhoto(operation.data);
        break;
      default:
        throw new Error(`Unknown operation type: ${operation.type}`);
    }
  }
}
```

---

## 📷 Photo Capture & Management

### Camera Integration
```typescript
// Expo Camera Integration
import { Camera, CameraType } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';

class PhotoService {
  async requestCameraPermissions(): Promise<boolean> {
    const { status } = await Camera.requestCameraPermissionsAsync();
    return status === 'granted';
  }

  async capturePhoto(): Promise<string | null> {
    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8, // Optimize for upload size
        exif: false, // Remove EXIF data for privacy
      });

      if (!result.canceled && result.assets[0]) {
        return result.assets[0].uri;
      }

      return null;
    } catch (error) {
      console.error('Photo capture failed:', error);
      return null;
    }
  }

  async optimizeImage(uri: string): Promise<string> {
    // Implement image compression and optimization
    const manipulatedImage = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: 1024 } }], // Resize to max width
      { compress: 0.8, format: ImageManipulator.SaveFormat.JPEG }
    );

    return manipulatedImage.uri;
  }
}
```

### Photo Storage & Upload
```typescript
// Photo Management with Offline Support
class PhotoManager {
  async savePhotoToSurvey(surveyId: string, photoUri: string): Promise<string> {
    // Generate unique photo ID
    const photoId = `photo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Optimize image for storage
    const optimizedUri = await photoService.optimizeImage(photoUri);

    // Save to local storage immediately
    await this.savePhotoLocally(photoId, optimizedUri);

    // Queue for upload when online
    syncService.queueForSync({
      type: 'UPLOAD_PHOTO',
      id: photoId,
      data: { surveyId, photoUri: optimizedUri },
      timestamp: Date.now(),
    });

    return photoId;
  }

  private async savePhotoLocally(photoId: string, uri: string): Promise<void> {
    // Copy photo to app's document directory
    const fileName = `${photoId}.jpg`;
    const destinationUri = `${FileSystem.documentDirectory}photos/${fileName}`;

    await FileSystem.makeDirectoryAsync(
      `${FileSystem.documentDirectory}photos/`,
      { intermediates: true }
    );

    await FileSystem.copyAsync({
      from: uri,
      to: destinationUri,
    });

    // Store photo metadata
    offlineStorage.storePhotoMetadata(photoId, {
      localUri: destinationUri,
      uploadStatus: 'pending',
      timestamp: Date.now(),
    });
  }
}
```

---

## 🔐 Authentication & Security

### JWT Token Management
```typescript
// Secure Token Storage
class AuthService {
  private tokenKey = 'auth_token';
  private refreshTokenKey = 'refresh_token';

  async login(email: string, password: string): Promise<boolean> {
    try {
      const response = await apiClient.post('/auth/login', { email, password });

      if (response.token) {
        // Store tokens securely
        offlineStorage.storeSecurely(this.tokenKey, response.token);
        if (response.refreshToken) {
          offlineStorage.storeSecurely(this.refreshTokenKey, response.refreshToken);
        }

        // Update user context
        userContext.setUser(response.user);

        return true;
      }

      return false;
    } catch (error) {
      console.error('Login failed:', error);
      return false;
    }
  }

  async refreshToken(): Promise<boolean> {
    const refreshToken = offlineStorage.getSecurely(this.refreshTokenKey);
    if (!refreshToken) return false;

    try {
      const response = await apiClient.post('/auth/refresh', { refreshToken });

      if (response.token) {
        offlineStorage.storeSecurely(this.tokenKey, response.token);
        return true;
      }

      return false;
    } catch (error) {
      // Refresh failed, user needs to login again
      await this.logout();
      return false;
    }
  }

  async logout(): Promise<void> {
    offlineStorage.removeSecurely(this.tokenKey);
    offlineStorage.removeSecurely(this.refreshTokenKey);
    userContext.setUser(null);
  }

  getAuthToken(): string | null {
    return offlineStorage.getSecurely(this.tokenKey);
  }

  isAuthenticated(): boolean {
    const token = this.getAuthToken();
    if (!token) return false;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  }
}
```

### Secure Data Transmission
```typescript
// API Client with Security Features
class SecureApiClient {
  private baseUrl: string;
  private maxRetries = 3;

  async request(config: RequestConfig): Promise<any> {
    const token = authService.getAuthToken();

    const requestConfig = {
      ...config,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : '',
        ...config.headers,
      },
    };

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const response = await fetch(`${this.baseUrl}${config.url}`, requestConfig);

        if (response.status === 401) {
          // Token expired, try refresh
          const refreshed = await authService.refreshToken();
          if (refreshed && attempt < this.maxRetries) {
            // Retry with new token
            requestConfig.headers.Authorization = `Bearer ${authService.getAuthToken()}`;
            continue;
          } else {
            // Refresh failed, redirect to login
            await authService.logout();
            throw new AuthError('Authentication required');
          }
        }

        if (!response.ok) {
          throw new ApiError(response.status, await response.text());
        }

        return await response.json();
      } catch (error) {
        if (attempt === this.maxRetries) {
          throw error;
        }

        // Exponential backoff
        await this.delay(Math.pow(2, attempt) * 1000);
      }
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
```

---

## ⚡ Performance Optimization

### Memory Management
```typescript
// Efficient Memory Usage
class MemoryOptimizer {
  private imageCache = new Map<string, string>();
  private maxCacheSize = 50; // Maximum cached images

  cacheImage(id: string, uri: string): void {
    if (this.imageCache.size >= this.maxCacheSize) {
      // Remove oldest entry
      const firstKey = this.imageCache.keys().next().value;
      this.imageCache.delete(firstKey);
    }

    this.imageCache.set(id, uri);
  }

  getCachedImage(id: string): string | undefined {
    return this.imageCache.get(id);
  }

  clearImageCache(): void {
    this.imageCache.clear();
  }
}
```

### Battery Optimization
```typescript
// Battery-Efficient Background Tasks
class BatteryOptimizer {
  private syncInterval: NodeJS.Timeout | null = null;

  startOptimizedSync(): void {
    // Use adaptive sync intervals based on battery level
    const batteryLevel = getBatteryLevel();
    const interval = batteryLevel > 0.5 ? 30000 : 60000; // 30s or 60s

    this.syncInterval = setInterval(async () => {
      if (await this.shouldSync()) {
        await syncService.startBackgroundSync();
      }
    }, interval);
  }

  private async shouldSync(): Promise<boolean> {
    const isCharging = await getBatteryChargingStatus();
    const isWifi = await getNetworkType() === 'wifi';
    const batteryLevel = await getBatteryLevel();

    // Only sync if conditions are favorable
    return (isCharging || batteryLevel > 0.2) && isWifi;
  }

  stopSync(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
  }
}
```

### Network Optimization
```typescript
// Intelligent Network Usage
class NetworkOptimizer {
  async uploadWithOptimization(data: any): Promise<void> {
    const networkType = await getNetworkType();

    if (networkType === 'cellular') {
      // Compress data more aggressively on cellular
      data = await this.compressForCellular(data);
    }

    // Use different batch sizes based on connection
    const batchSize = networkType === 'wifi' ? 10 : 3;
    await this.uploadInBatches(data, batchSize);
  }

  private async compressForCellular(data: any): Promise<any> {
    // Implement aggressive compression for cellular networks
    return data;
  }

  private async uploadInBatches(data: any[], batchSize: number): Promise<void> {
    for (let i = 0; i < data.length; i += batchSize) {
      const batch = data.slice(i, i + batchSize);
      await this.uploadBatch(batch);
    }
  }
}
```

---

## 🔧 Container Configuration & Deployment

### Environment Configuration
```typescript
// Environment-Specific Configuration
interface AppConfig {
  apiUrl: string;
  environment: 'development' | 'staging' | 'production';
  logLevel: 'debug' | 'info' | 'warn' | 'error';
  offlineMode: boolean;
  syncInterval: number;
}

export const getConfig = (): AppConfig => {
  const isDev = __DEV__;

  return {
    apiUrl: isDev
      ? 'http://localhost:8000'
      : 'https://api.spacewalker.com',
    environment: isDev ? 'development' : 'production',
    logLevel: isDev ? 'debug' : 'warn',
    offlineMode: true,
    syncInterval: isDev ? 10000 : 30000, // 10s dev, 30s prod
  };
};
```

### Build Configuration
```json
// app.json - Expo Configuration
{
  "expo": {
    "name": "Spacewalker Survey",
    "slug": "spacewalker-mobile",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "userInterfaceStyle": "light",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#ffffff"
    },
    "assetBundlePatterns": ["**/*"],
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.spacewalker.survey"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#FFFFFF"
      },
      "package": "com.spacewalker.survey"
    },
    "web": {
      "favicon": "./assets/favicon.png"
    },
    "plugins": [
      "expo-camera",
      "expo-image-picker",
      "react-native-mmkv"
    ],
    "extra": {
      "apiUrl": "https://api.spacewalker.com"
    }
  }
}
```

### EAS Build Configuration
```json
// eas.json - Build Profiles
{
  "cli": {
    "version": ">= 3.0.0"
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal",
      "env": {
        "API_URL": "http://localhost:8000"
      }
    },
    "preview": {
      "distribution": "internal",
      "env": {
        "API_URL": "https://api-staging.spacewalker.com"
      }
    },
    "production": {
      "env": {
        "API_URL": "https://api.spacewalker.com"
      }
    }
  },
  "submit": {
    "production": {}
  }
}
```

---

## 🧪 Mobile Testing Strategies

### Unit Testing
```typescript
// React Native Testing Library
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import { SurveyForm } from '../components/SurveyForm';

describe('SurveyForm', () => {
  it('should save survey data offline', async () => {
    const mockSaveOffline = jest.fn();
    jest.spyOn(offlineStorage, 'storeSurvey').mockImplementation(mockSaveOffline);

    const { getByTestId } = render(<SurveyForm />);

    fireEvent.changeText(getByTestId('survey-title'), 'Test Survey');
    fireEvent.press(getByTestId('save-button'));

    await waitFor(() => {
      expect(mockSaveOffline).toHaveBeenCalledWith(
        expect.objectContaining({ title: 'Test Survey' })
      );
    });
  });
});
```

### Integration Testing
```typescript
// End-to-End Testing with Detox
describe('Survey Creation Flow', () => {
  beforeAll(async () => {
    await device.launchApp();
  });

  it('should create survey offline and sync when online', async () => {
    // Navigate to survey creation
    await element(by.id('create-survey-button')).tap();

    // Fill survey data
    await element(by.id('survey-title-input')).typeText('Integration Test Survey');
    await element(by.id('survey-description-input')).typeText('Test description');

    // Save survey (should work offline)
    await element(by.id('save-survey-button')).tap();

    // Verify offline save
    await expect(element(by.text('Survey saved offline'))).toBeVisible();

    // Simulate network reconnection
    await device.enableNetwork();

    // Wait for sync
    await waitFor(element(by.text('Survey synced'))).toBeVisible().withTimeout(10000);
  });
});
```

---

## 📋 Related Mobile Documentation

### Implementation Details
> 📱 **Mobile Components**: See [Mobile App Components](../app-components.md) for detailed React Native component architecture and offline patterns
> 📱 **Offline Architecture**: See [Offline-First Architecture](./offline-first.md) for comprehensive offline implementation strategies

### Development Resources
- **[Mobile Development Setup](../../setup/development-setup.md)** - React Native and Expo development environment configuration
- **[Mobile Testing Guide](../../workflows/testing-guide.md)** - Comprehensive testing strategies for React Native applications
- **[Mobile Deployment Guide](../../workflows/deployment-guide.md)** - Build and distribution configuration for iOS and Android

### System Architecture Context
- **[System Container Overview](../../architecture/system-container-overview.md)** - Complete system architecture with all container relationships
- **[Component Architecture](../../architecture/component-diagrams.md)** - Detailed component relationships within mobile container

---

**Status**: ✅ **PRODUCTION MOBILE ARCHITECTURE**
**Last Updated**: 2025-06-29
**Container Scope**: React Native Mobile App, Offline Storage, Background Sync
**Technology Stack**: React Native, Expo SDK, TypeScript, MMKV

---

*This mobile container architecture documentation provides comprehensive guidance for developers working on the React Native survey application, ensuring robust offline-first functionality and optimal user experience across iOS and Android platforms.*
