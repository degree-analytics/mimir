# Mobile Architecture

## Purpose
React Native mobile application architecture documentation including offline-first design, state management, navigation, and platform-specific implementation details. Primary reference for mobile development and integration.

## When to Use This
- Understanding mobile app architecture and design patterns
- Implementing offline-first data synchronization
- Designing mobile UI components and navigation flows
- Integrating with backend APIs and external services
- Troubleshooting mobile-specific issues and platform compatibility
- Keywords: React Native, mobile architecture, offline-first, state management, navigation

**Version:** 2.0 (Extracted from comprehensive PRD)
**Date:** 2025-06-29
**Status:** Current - Mobile Technical Reference

---

## 📱 Mobile Application Features

### User-Facing Features
- **User Authentication** `[Implemented]`
  - Secure login via email and password, issuing a JWT
  - JWT has a **24-hour expiration**
  - University SSO integration is `[Planned]` as a future enhancement

- **Room Selection & Geolocation** `[Implemented]`
  - Select buildings and floors via geolocation-based suggestions or manual search
  - Includes checks for existing rooms and name correction suggestions

- **Image Capture & AI Analysis** `[Implemented]`
  - Guided photo capture within the mobile app
  - Cloud-based AI (Google Gemini) analyzes images to suggest FICM room types and attributes

- **Data Review & Submission** `[Implemented]`
  - Users confirm or edit AI-suggested data on the mobile app
  - Data is submitted to the backend for storage and review

- **Offline Capability** `[Implemented]`
  - The mobile app fully supports offline data collection
  - Data is stored locally using **AsyncStorage** and synced to the cloud when a connection is available

---

## 🏗️ Mobile Technology Stack

### Core Technologies
- **Framework:** React Native with Expo SDK 54
- **Language:** TypeScript for type safety and developer experience
- **Navigation:** React Navigation for multi-screen app structure
- **State Management:** React Context API with custom hooks
- **Offline Storage:** AsyncStorage for local data persistence
- **Image Handling:** Expo Camera and Image Picker
- **Network Layer:** Axios for HTTP requests with offline queueing

### Platform Support
- **iOS:** Native iOS app via Expo built binaries
- **Android:** Native Android app via Expo built binaries
- **Development:** Expo Go for rapid development and testing
- **Distribution:** App Store and Google Play Store deployment

---

## 💾 Offline-First Architecture

### Data Synchronization Strategy
The mobile app implements a comprehensive offline-first architecture that enables full functionality without network connectivity:

#### Local Storage Structure
```typescript
interface OfflineStorage {
  surveys: {
    [surveyId: string]: {
      id: string;
      roomId: number;
      status: 'draft' | 'pending' | 'synced';
      data: SurveyData;
      images: LocalImageRef[];
      syncAttempts: number;
      lastModified: string;
    }
  };
  buildings: BuildingData[];
  userSession: {
    token: string;
    expiry: string;
    user: UserData;
  };
}
```

#### Sync Process
1. **Data Collection:** All survey data stored locally first
2. **Background Sync:** Automatic sync when network becomes available
3. **Conflict Resolution:** Last-write-wins strategy with user notification
4. **Retry Logic:** Progressive backoff for failed sync attempts
5. **Partial Sync:** Individual surveys sync independently

### Network State Management
- **Online Detection:** Real-time network status monitoring
- **Queue Management:** Pending operations queued for sync
- **Error Handling:** Graceful degradation with user feedback
- **Manual Sync:** User-initiated sync with progress indication

---

## 🧭 Navigation Architecture

### Navigation Structure
```typescript
export type RootStackParamList = {
  Login: undefined;
  Home: undefined;
  BuildingSelection: undefined;
  FloorSelection: { buildingId: number };
  RoomSelection: { floorId: number } | { preselectedRoom?: any };
  Camera: { roomId: number };
  SurveyReview: { surveyId: string };
  SurveySubmission: { surveyId: string };
  Settings: undefined;
  About: undefined;
};
```

### Navigation Patterns
- **Stack Navigation:** Primary navigation pattern for linear workflows
- **Tab Navigation:** Secondary navigation for utility screens
- **Modal Navigation:** Overlay screens for forms and confirmations
- **Deep Linking:** URL-based navigation for external integrations

### User Flow Design
```mermaid
graph TD
    A[Login Screen] --> B[Home Dashboard]
    B --> C[Building Selection]
    C --> D[Floor Selection]
    D --> E[Room Selection]
    E --> F[Camera Capture]
    F --> G[Survey Review]
    G --> H[Survey Submission]
    H --> I[Confirmation]
    I --> B

    B --> J[Settings]
    B --> K[About]
    G --> L[Edit Survey]
    L --> G
```

---

## 🎨 State Management

### Context Architecture
```typescript
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (credentials: LoginCredentials) => Promise<AuthResponse>;
  logout: () => Promise<void>;
  refreshToken: () => Promise<void>;
}

interface SurveyContextType {
  surveys: Survey[];
  currentSurvey: Survey | null;
  createSurvey: (roomId: number) => Promise<Survey>;
  updateSurvey: (surveyId: string, data: Partial<Survey>) => Promise<void>;
  submitSurvey: (surveyId: string) => Promise<void>;
  syncPendingSurveys: () => Promise<void>;
}
```

### State Management Patterns
- **Context Providers:** App-wide state management
- **Custom Hooks:** Component-level state logic
- **Local State:** Component-specific UI state
- **Persistent Storage:** Long-term data storage

---

## 📡 API Integration

### HTTP Client Configuration
```typescript
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for authentication
apiClient.interceptors.request.use((config) => {
  const token = getStoredToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Handle token expiration
      logout();
    }
    return Promise.reject(error);
  }
);
```

### Offline Request Queuing
- **Queue Storage:** Failed requests stored in AsyncStorage
- **Retry Logic:** Automatic retry with exponential backoff
- **Request Deduplication:** Prevent duplicate API calls
- **Progress Tracking:** User feedback for sync operations

---

## 📷 Image Handling

### Camera Integration
- **Expo Camera:** Native camera access with custom UI
- **Image Quality:** Configurable compression and resolution
- **Gallery Access:** Photo selection from device gallery
- **Preview Mode:** Real-time camera preview with overlay guides

### Image Storage and Sync
- **Local Storage:** Images stored locally before upload
- **Upload Queue:** Background upload with progress tracking
- **Compression:** Client-side image optimization
- **Cloud Storage:** S3-compatible storage integration

---

## 🧪 Testing Strategy

### Testing Frameworks
- **Jest:** Unit testing framework
- **React Native Testing Library:** Component testing
- **Detox:** End-to-end testing (planned)
- **Metro:** Bundle testing and optimization

### Testing Patterns
- **Component Tests:** UI component behavior validation
- **Hook Tests:** Custom hook logic verification
- **Integration Tests:** API integration and data flow
- **Offline Tests:** Offline functionality validation

---

## 📚 Related Documentation

### Implementation Details
- **[Mobile Development Guide](../development/README.md)** - Development setup, coding standards, and implementation patterns
- **[Mobile Testing Guide](../../workflows/testing-guide.md)** - Testing strategies and device testing

### System Integration
- **[Backend Architecture](../../backend/architecture/README.md)** - Backend API integration and data contracts
- **[Admin Architecture](../../admin/architecture/README.md)** - Admin dashboard coordination with mobile data

### Workflow Resources
- **[Development Setup](../../setup/development-setup.md)** - Mobile development environment configuration
- **[FICM Specifications](../../setup/environment-configuration.md)** - Room classification standards used in mobile app

### Troubleshooting
- **[Troubleshooting Guide](../../workflows/troubleshooting-guide.md)** - Mobile connectivity and platform issue resolution
- **[Mobile Gotchas](../../gotchas/)** - Common mobile development issues and platform-specific problems

---

**Status**: ✅ Updated and current as of 2025-06-29. Extracted from comprehensive PRD and enhanced with mobile-specific architecture details and technical specifications.
