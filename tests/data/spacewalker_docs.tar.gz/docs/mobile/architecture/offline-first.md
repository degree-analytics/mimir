# Mobile Offline-First Architecture

## Purpose
Comprehensive offline-first architecture and data synchronization strategy for the Spacewalker mobile application including offline storage, sync patterns, and network state handling.

## When to Use This
- Implementing offline functionality for mobile survey data collection
- Designing sync strategies for intermittent network connectivity
- Managing offline storage and data persistence
- Keywords: offline storage, data sync, SQLite, network handling, queue management

**Version:** 1.0
**Date:** 2025-01-06
**Status:** Current

## Key Concepts
- **Offline-First**: App functionality designed to work without network connectivity
- **Sync Queue**: Local queue system for managing data uploads when connectivity returns
- **Conflict Resolution**: Strategies for handling data conflicts during synchronization
- **Progressive Enhancement**: Graceful degradation from online to offline modes

## Offline Storage Strategy

### Data Persistence Architecture

```mermaid
graph TD
    A[Mobile App] --> B[Storage Layer]
    B --> C[MMKV - Fast KV Store]
    B --> D[SQLite - Relational Data]
    B --> E[File System - Images]
    B --> F[SecureStore - Tokens]

    C --> G[User Preferences]
    C --> H[Cache Data]
    C --> I[Sync Metadata]

    D --> J[Survey Data]
    D --> K[Room Inventory]
    D --> L[Attribute Definitions]

    E --> M[Survey Images]
    E --> N[Thumbnails]
    E --> O[Temporary Files]

    F --> P[Auth Tokens]
    F --> Q[API Keys]

    classDef storage fill:#E3F2FD,stroke:#1976D2,color:#000000
    classDef data fill:#F3E5F5,stroke:#7B1FA2,color:#000000
    classDef files fill:#FFF3E0,stroke:#F57C00,color:#000000
    classDef secure fill:#FFEBEE,stroke:#D32F2F,color:#000000

    class A,B storage
    class C,D,G,H,I,J,K,L data
    class E,M,N,O files
    class F,P,Q secure
```

### SQLite Database Schema

```typescript
interface DatabaseSchema {
  surveys: {
    id: string;
    roomId: number;
    status: 'draft' | 'pending' | 'synced';
    data: string; // JSON serialized survey data
    images: string; // JSON array of image paths
    createdAt: number;
    updatedAt: number;
    syncAttempts: number;
    lastSyncAttempt: number | null;
  };

  rooms: {
    id: number;
    buildingId: number;
    floorId: number;
    name: string;
    ficmCode: string;
    metadata: string; // JSON serialized room data
    lastSurveyAt: number | null;
    syncedAt: number;
  };

  buildings: {
    id: number;
    tenantId: number;
    name: string;
    address: string;
    metadata: string; // JSON serialized building data
    syncedAt: number;
  };

  syncQueue: {
    id: string;
    type: 'survey' | 'image' | 'metadata';
    payload: string; // JSON serialized data
    priority: number;
    attempts: number;
    createdAt: number;
    scheduledAt: number;
  };
}
```

### Storage Service Implementation

```typescript
import SQLite from 'react-native-sqlite-storage';
import { MMKV } from 'react-native-mmkv';

class OfflineStorageService {
  private db: SQLite.SQLiteDatabase | null = null;
  private mmkv = new MMKV({ id: 'spacewalker-offline' });

  async initialize(): Promise<void> {
    this.db = await SQLite.openDatabase({
      name: 'spacewalker.db',
      location: 'default',
    });

    await this.createTables();
    await this.runMigrations();
  }

  private async createTables(): Promise<void> {
    const queries = [
      `CREATE TABLE IF NOT EXISTS surveys (
        id TEXT PRIMARY KEY,
        roomId INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'draft',
        data TEXT NOT NULL,
        images TEXT NOT NULL DEFAULT '[]',
        createdAt INTEGER NOT NULL,
        updatedAt INTEGER NOT NULL,
        syncAttempts INTEGER NOT NULL DEFAULT 0,
        lastSyncAttempt INTEGER
      )`,

      `CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY,
        buildingId INTEGER NOT NULL,
        floorId INTEGER NOT NULL,
        name TEXT NOT NULL,
        ficmCode TEXT,
        metadata TEXT NOT NULL DEFAULT '{}',
        lastSurveyAt INTEGER,
        syncedAt INTEGER NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS buildings (
        id INTEGER PRIMARY KEY,
        tenantId INTEGER NOT NULL,
        name TEXT NOT NULL,
        address TEXT,
        metadata TEXT NOT NULL DEFAULT '{}',
        syncedAt INTEGER NOT NULL
      )`,

      `CREATE TABLE IF NOT EXISTS syncQueue (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        payload TEXT NOT NULL,
        priority INTEGER NOT NULL DEFAULT 0,
        attempts INTEGER NOT NULL DEFAULT 0,
        createdAt INTEGER NOT NULL,
        scheduledAt INTEGER NOT NULL
      )`,
    ];

    for (const query of queries) {
      await this.db!.executeSql(query);
    }
  }

  // Survey operations
  async saveSurvey(survey: OfflineSurveyData): Promise<void> {
    const query = `
      INSERT OR REPLACE INTO surveys
      (id, roomId, status, data, images, createdAt, updatedAt, syncAttempts, lastSyncAttempt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    await this.db!.executeSql(query, [
      survey.id,
      survey.roomId,
      survey.status,
      JSON.stringify(survey.data),
      JSON.stringify(survey.images),
      survey.createdAt,
      survey.updatedAt,
      survey.syncAttempts || 0,
      survey.lastSyncAttempt || null,
    ]);
  }

  async getSurvey(id: string): Promise<OfflineSurveyData | null> {
    const [results] = await this.db!.executeSql(
      'SELECT * FROM surveys WHERE id = ?',
      [id]
    );

    if (results.rows.length === 0) return null;

    const row = results.rows.item(0);
    return {
      id: row.id,
      roomId: row.roomId,
      status: row.status,
      data: JSON.parse(row.data),
      images: JSON.parse(row.images),
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
      syncAttempts: row.syncAttempts,
      lastSyncAttempt: row.lastSyncAttempt,
    };
  }

  async getPendingSurveys(): Promise<OfflineSurveyData[]> {
    const [results] = await this.db!.executeSql(
      "SELECT * FROM surveys WHERE status = 'pending' ORDER BY createdAt ASC"
    );

    const surveys: OfflineSurveyData[] = [];
    for (let i = 0; i < results.rows.length; i++) {
      const row = results.rows.item(i);
      surveys.push({
        id: row.id,
        roomId: row.roomId,
        status: row.status,
        data: JSON.parse(row.data),
        images: JSON.parse(row.images),
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
        syncAttempts: row.syncAttempts,
        lastSyncAttempt: row.lastSyncAttempt,
      });
    }

    return surveys;
  }

  // Sync queue operations
  async addToSyncQueue(item: SyncQueueItem): Promise<void> {
    const query = `
      INSERT INTO syncQueue (id, type, payload, priority, attempts, createdAt, scheduledAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    await this.db!.executeSql(query, [
      item.id,
      item.type,
      JSON.stringify(item.payload),
      item.priority,
      0,
      Date.now(),
      item.scheduledAt || Date.now(),
    ]);
  }

  async getNextSyncItems(limit: number = 10): Promise<SyncQueueItem[]> {
    const [results] = await this.db!.executeSql(
      `SELECT * FROM syncQueue
       WHERE scheduledAt <= ?
       ORDER BY priority DESC, createdAt ASC
       LIMIT ?`,
      [Date.now(), limit]
    );

    const items: SyncQueueItem[] = [];
    for (let i = 0; i < results.rows.length; i++) {
      const row = results.rows.item(i);
      items.push({
        id: row.id,
        type: row.type,
        payload: JSON.parse(row.payload),
        priority: row.priority,
        attempts: row.attempts,
        createdAt: row.createdAt,
        scheduledAt: row.scheduledAt,
      });
    }

    return items;
  }

  async removeSyncItem(id: string): Promise<void> {
    await this.db!.executeSql('DELETE FROM syncQueue WHERE id = ?', [id]);
  }

  async updateSyncItemAttempts(id: string, attempts: number, nextRetry: number): Promise<void> {
    await this.db!.executeSql(
      'UPDATE syncQueue SET attempts = ?, scheduledAt = ? WHERE id = ?',
      [attempts, nextRetry, id]
    );
  }
}
```

## Sync Patterns and Strategies

### Network State Monitoring

```typescript
import NetInfo from '@react-native-async-storage/async-storage';

export class NetworkStateManager {
  private isOnline: boolean = true;
  private listeners: Set<(isOnline: boolean) => void> = new Set();
  private syncService: SyncService;

  constructor(syncService: SyncService) {
    this.syncService = syncService;
    this.initialize();
  }

  private initialize() {
    NetInfo.addEventListener(state => {
      const wasOffline = !this.isOnline;
      const isNowOnline = state.isConnected ?? false;

      this.isOnline = isNowOnline;
      this.notifyListeners(isNowOnline);

      // Trigger sync when coming back online
      if (wasOffline && isNowOnline) {
        this.syncService.startSync();
      }
    });
  }

  subscribe(listener: (isOnline: boolean) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners(isOnline: boolean) {
    this.listeners.forEach(listener => listener(isOnline));
  }

  getNetworkState(): boolean {
    return this.isOnline;
  }
}
```

### Sync Service Implementation

```typescript
export class SyncService {
  private storage: OfflineStorageService;
  private networkManager: NetworkStateManager;
  private syncInProgress: boolean = false;
  private syncInterval: NodeJS.Timer | null = null;

  constructor(storage: OfflineStorageService) {
    this.storage = storage;
    this.networkManager = new NetworkStateManager(this);
  }

  async startSync(): Promise<void> {
    if (this.syncInProgress || !this.networkManager.getNetworkState()) {
      return;
    }

    this.syncInProgress = true;
    console.log('Starting sync process...');

    try {
      await this.syncPendingSurveys();
      await this.syncQueuedItems();
      await this.downloadUpdates();
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      this.syncInProgress = false;
    }
  }

  private async syncPendingSurveys(): Promise<void> {
    const pendingSurveys = await this.storage.getPendingSurveys();

    for (const survey of pendingSurveys) {
      try {
        // Upload survey data
        await this.uploadSurvey(survey);

        // Mark as synced
        await this.storage.saveSurvey({
          ...survey,
          status: 'synced',
          updatedAt: Date.now(),
        });

        console.log(`Survey ${survey.id} synced successfully`);
      } catch (error) {
        // Update sync attempts
        const updatedSurvey = {
          ...survey,
          syncAttempts: survey.syncAttempts + 1,
          lastSyncAttempt: Date.now(),
        };

        await this.storage.saveSurvey(updatedSurvey);
        console.error(`Failed to sync survey ${survey.id}:`, error);
      }
    }
  }

  private async syncQueuedItems(): Promise<void> {
    const queueItems = await this.storage.getNextSyncItems(10);

    for (const item of queueItems) {
      try {
        await this.processSyncItem(item);
        await this.storage.removeSyncItem(item.id);
        console.log(`Sync item ${item.id} processed successfully`);
      } catch (error) {
        const nextRetry = this.calculateRetryDelay(item.attempts);
        await this.storage.updateSyncItemAttempts(
          item.id,
          item.attempts + 1,
          Date.now() + nextRetry
        );
        console.error(`Failed to process sync item ${item.id}:`, error);
      }
    }
  }

  private async uploadSurvey(survey: OfflineSurveyData): Promise<void> {
    // Upload images first
    const uploadedImageUrls: string[] = [];
    for (const imagePath of survey.images) {
      const url = await this.uploadImage(imagePath);
      uploadedImageUrls.push(url);
    }

    // Upload survey with image URLs
    const surveyPayload = {
      ...survey.data,
      images: uploadedImageUrls,
    };

    await apiService.submitSurvey(surveyPayload);
  }

  private async uploadImage(imagePath: string): Promise<string> {
    const formData = new FormData();
    formData.append('image', {
      uri: imagePath,
      type: 'image/jpeg',
      name: 'survey-image.jpg',
    } as any);

    const response = await apiService.uploadImage(formData);
    return response.url;
  }

  private calculateRetryDelay(attempts: number): number {
    // Exponential backoff: 1min, 2min, 4min, 8min, max 30min
    const baseDelay = 60000; // 1 minute
    const maxDelay = 1800000; // 30 minutes
    const delay = Math.min(baseDelay * Math.pow(2, attempts), maxDelay);

    // Add jitter to prevent thundering herd
    const jitter = Math.random() * 0.1 * delay;
    return delay + jitter;
  }

  enableAutoSync(): void {
    if (this.syncInterval) return;

    this.syncInterval = setInterval(() => {
      if (this.networkManager.getNetworkState()) {
        this.startSync();
      }
    }, 300000); // Sync every 5 minutes
  }

  disableAutoSync(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
  }
}
```

## Conflict Resolution Strategies

### Timestamp-Based Resolution

```typescript
interface ConflictResolutionStrategy {
  resolveConflict<T>(local: T, remote: T, metadata: ConflictMetadata): T;
}

class TimestampConflictResolver implements ConflictResolutionStrategy {
  resolveConflict<T extends { updatedAt: number }>(
    local: T,
    remote: T,
    metadata: ConflictMetadata
  ): T {
    // Server timestamp wins (last writer wins)
    if (remote.updatedAt > local.updatedAt) {
      console.log('Conflict resolved: Using remote version (newer)');
      return remote;
    }

    console.log('Conflict resolved: Keeping local version (newer)');
    return local;
  }
}

class UserChoiceConflictResolver implements ConflictResolutionStrategy {
  async resolveConflict<T>(
    local: T,
    remote: T,
    metadata: ConflictMetadata
  ): Promise<T> {
    return new Promise((resolve) => {
      // Show conflict resolution UI
      ConflictResolutionModal.show({
        local,
        remote,
        metadata,
        onResolve: (chosen: T) => resolve(chosen),
      });
    });
  }
}
```

### Data Merging Strategies

```typescript
class SurveyDataMerger {
  static mergeSurveyData(
    localSurvey: SurveyData,
    remoteSurvey: SurveyData
  ): SurveyData {
    // Merge strategy: combine attributes, prefer local images
    return {
      ...remoteSurvey,
      attributes: {
        ...remoteSurvey.attributes,
        ...localSurvey.attributes, // Local attributes override
      },
      images: [
        ...new Set([...localSurvey.images, ...remoteSurvey.images])
      ],
      notes: this.mergeNotes(localSurvey.notes, remoteSurvey.notes),
      updatedAt: Math.max(localSurvey.updatedAt, remoteSurvey.updatedAt),
    };
  }

  private static mergeNotes(
    localNotes: string,
    remoteNotes: string
  ): string {
    if (localNotes === remoteNotes) return localNotes;

    // Append notes with merge marker
    return `${remoteNotes}\n\n--- Local Changes ---\n${localNotes}`;
  }
}
```

## Image Handling and Storage

### Image Storage Strategy

```typescript
class ImageStorageService {
  private readonly baseDir = FileSystem.documentDirectory + 'survey_images/';
  private readonly thumbnailDir = FileSystem.documentDirectory + 'thumbnails/';
  private readonly maxCacheSize = 500 * 1024 * 1024; // 500MB

  async saveImage(uri: string, surveyId: string): Promise<string> {
    await this.ensureDirectoryExists(this.baseDir);

    const fileName = `${surveyId}_${Date.now()}.jpg`;
    const filePath = this.baseDir + fileName;

    // Copy and compress image
    const compressedUri = await this.compressImage(uri);
    await FileSystem.copyAsync({
      from: compressedUri,
      to: filePath,
    });

    // Generate thumbnail
    await this.generateThumbnail(filePath, fileName);

    return filePath;
  }

  private async compressImage(uri: string): Promise<string> {
    return await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: 2048 } }], // Max width 2048px
      {
        compress: 0.7,
        format: ImageManipulator.SaveFormat.JPEG,
      }
    ).then(result => result.uri);
  }

  private async generateThumbnail(originalPath: string, fileName: string): Promise<void> {
    await this.ensureDirectoryExists(this.thumbnailDir);

    const thumbnailPath = this.thumbnailDir + `thumb_${fileName}`;

    const thumbnail = await ImageManipulator.manipulateAsync(
      originalPath,
      [{ resize: { width: 300 } }], // 300px thumbnail
      {
        compress: 0.5,
        format: ImageManipulator.SaveFormat.JPEG,
      }
    );

    await FileSystem.copyAsync({
      from: thumbnail.uri,
      to: thumbnailPath,
    });
  }

  async getThumbnailPath(imagePath: string): Promise<string | null> {
    const fileName = imagePath.split('/').pop();
    if (!fileName) return null;

    const thumbnailPath = this.thumbnailDir + `thumb_${fileName}`;
    const info = await FileSystem.getInfoAsync(thumbnailPath);

    return info.exists ? thumbnailPath : null;
  }

  async cleanupImages(surveyId: string): Promise<void> {
    const dir = await FileSystem.readDirectoryAsync(this.baseDir);

    for (const file of dir) {
      if (file.startsWith(`${surveyId}_`)) {
        await FileSystem.deleteAsync(this.baseDir + file);

        // Also delete thumbnail
        const thumbnailPath = this.thumbnailDir + `thumb_${file}`;
        const thumbnailInfo = await FileSystem.getInfoAsync(thumbnailPath);
        if (thumbnailInfo.exists) {
          await FileSystem.deleteAsync(thumbnailPath);
        }
      }
    }
  }

  async getCacheSize(): Promise<number> {
    const [imagesSize, thumbnailsSize] = await Promise.all([
      this.getDirectorySize(this.baseDir),
      this.getDirectorySize(this.thumbnailDir),
    ]);

    return imagesSize + thumbnailsSize;
  }

  async cleanupCache(): Promise<void> {
    const cacheSize = await this.getCacheSize();

    if (cacheSize > this.maxCacheSize) {
      console.log('Cache size exceeded, cleaning up old images...');
      await this.cleanupOldImages();
    }
  }

  private async cleanupOldImages(): Promise<void> {
    // Get all image files sorted by modification time
    const imageFiles = await this.getImageFilesSortedByAge();

    let currentSize = await this.getCacheSize();
    const targetSize = this.maxCacheSize * 0.8; // Clean to 80% of max

    for (const file of imageFiles) {
      if (currentSize <= targetSize) break;

      const fileInfo = await FileSystem.getInfoAsync(file.path);
      await FileSystem.deleteAsync(file.path);

      // Delete corresponding thumbnail
      const thumbnailPath = this.getThumbnailPathFromImage(file.path);
      const thumbnailInfo = await FileSystem.getInfoAsync(thumbnailPath);
      if (thumbnailInfo.exists) {
        await FileSystem.deleteAsync(thumbnailPath);
      }

      currentSize -= fileInfo.size || 0;
    }
  }
}
```

## Testing Offline Functionality

### Offline Testing Patterns

```typescript
class OfflineTestingUtils {
  static async simulateOfflineMode(): Promise<void> {
    // Mock network requests to fail
    const originalFetch = global.fetch;
    global.fetch = jest.fn(() =>
      Promise.reject(new Error('Network request failed - offline mode'))
    );

    return () => {
      global.fetch = originalFetch;
    };
  }

  static async testOfflineSurveyFlow(): Promise<void> {
    const restoreNetwork = await this.simulateOfflineMode();

    try {
      // Test survey creation offline
      const survey = await surveyService.createSurvey(1);
      expect(survey.status).toBe('draft');

      // Test image capture offline
      const imagePath = await cameraService.captureImage();
      await surveyService.addImage(survey.id, imagePath);

      // Test survey submission offline (should queue)
      await surveyService.submitSurvey(survey.id);

      const pendingSurveys = await storageService.getPendingSurveys();
      expect(pendingSurveys).toHaveLength(1);

    } finally {
      restoreNetwork();
    }
  }

  static async testSyncAfterReconnection(): Promise<void> {
    // Start offline
    const restoreNetwork = await this.simulateOfflineMode();

    // Create survey offline
    const survey = await surveyService.createSurvey(1);
    await surveyService.submitSurvey(survey.id);

    // Restore network
    restoreNetwork();

    // Trigger sync
    await syncService.startSync();

    // Verify survey was uploaded
    const pendingSurveys = await storageService.getPendingSurveys();
    expect(pendingSurveys).toHaveLength(0);
  }
}
```

## Related Documentation
- Mobile Architecture Overview → ../mobile/architecture/README.md
- Mobile State Management → ./state-management.md
- Mobile Development Guide → ../mobile/development/README.md
- Backend API Integration → ../backend/architecture/api-contracts.md

---
Last Updated: 2025-06-28
Status: Current
