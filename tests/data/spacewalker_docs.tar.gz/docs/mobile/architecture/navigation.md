# Mobile Navigation Architecture

## Purpose
Comprehensive navigation architecture and user flow design for the Spacewalker mobile application including screen hierarchy, state management, and navigation patterns.

## When to Use This
- Understanding mobile app navigation structure and user flows
- Implementing new screens and navigation transitions
- Designing navigation state management and routing
- Keywords: React Navigation, mobile navigation, user flow, screen routing, navigation state

**Version:** 1.0
**Date:** 2025-01-06
**Status:** Current

## Key Concepts
- **Stack Navigation**: Hierarchical screen navigation with back button support
- **Tab Navigation**: Bottom tab navigation for main app sections
- **Modal Navigation**: Overlay screens for forms and detailed views
- **Deep Linking**: URL-based navigation for notifications and sharing

## Navigation Architecture Overview

### Main User Flow

```mermaid
flowchart TD
    %% Authentication Flow
    Login[Login Screen<br/>Email/Password authentication]

    %% Main Navigation
    Home[Home Screen<br/>Dashboard, quick actions]

    %% Survey Flow
    BuildingSelect[Building Selection<br/>Choose from tenant buildings]
    FloorSelect[Floor Selection<br/>Navigate building floors]
    RoomSelect[Room Selection<br/>Choose or search rooms]
    Camera[Camera Screen<br/>Photo capture & gallery]
    Analysis[Analysis Results<br/>AI processing results]
    AttributeReview[Attribute Review<br/>Manual editing & validation]
    AISuggestions[AI Suggestions<br/>Confidence scoring & selection]
    SurveySubmit[Survey Submit<br/>Final review & submission]

    %% Inventory Flow
    RoomInventory[Room Inventory<br/>Browse existing data]
    RoomDetail[Room Detail<br/>Historical survey data]

    %% Navigation Relationships
    Login -->|Successful auth| Home

    Home -->|Start Survey| BuildingSelect
    Home -->|View Inventory| RoomInventory
    Home -->|Logout| Login

    BuildingSelect -->|Select building| FloorSelect
    FloorSelect -->|Select floor| RoomSelect
    RoomSelect -->|Select room| Camera

    Camera -->|Capture photos| Analysis
    Analysis -->|Review AI results| AttributeReview
    AttributeReview -->|Get AI suggestions| AISuggestions
    AISuggestions -->|Finalize attributes| SurveySubmit
    AttributeReview -->|Skip AI suggestions| SurveySubmit

    SurveySubmit -->|Submit success| Home
    SurveySubmit -->|Try again| AttributeReview

    RoomInventory -->|Select room| RoomDetail
    RoomDetail -->|Start new survey| Camera

    %% Back Navigation
    BuildingSelect -.->|Back| Home
    FloorSelect -.->|Back| BuildingSelect
    RoomSelect -.->|Back| FloorSelect
    Camera -.->|Back| RoomSelect
    Analysis -.->|Back| Camera
    AttributeReview -.->|Back| Analysis
    AISuggestions -.->|Back| AttributeReview
    SurveySubmit -.->|Back| AttributeReview
    RoomInventory -.->|Back| Home
    RoomDetail -.->|Back| RoomInventory

    %% Styling
    classDef auth fill:#FFE4B5,stroke:#D4A574,color:#000000
    classDef main fill:#98FB98,stroke:#6BAD6B,color:#000000
    classDef survey fill:#87CEEB,stroke:#5F9FBF,color:#000000
    classDef inventory fill:#DDA0DD,stroke:#B8860B,color:#000000

    class Login auth
    class Home main
    class BuildingSelect,FloorSelect,RoomSelect,Camera,Analysis,AttributeReview,AISuggestions,SurveySubmit survey
    class RoomInventory,RoomDetail inventory
```

## Navigation Stack Structure

### Root Stack Configuration

```typescript
export type RootStackParamList = {
  Login: undefined;
  Home: undefined;
  BuildingSelection: undefined;
  FloorSelection: { buildingId: number };
  RoomSelection: { floorId: number } | { preselectedRoom?: any };
  Camera: { roomId: number };
  AnalysisResults: {
    roomId: number;
    images: string[];
    analysisResult: any;
    imageDetails?: ImageDetail[];
  };
  AttributeReview: {
    roomId: number;
    images: string[];
    imageDetails?: ImageDetail[];
    initialAnalysisResult?: any;
  };
  AISuggestions: {
    roomId: number;
    attributes: AttributeData[];
    suggestions: AISuggestion[];
  };
  SurveySubmit: {
    roomId: number;
    surveyData: SurveyData;
    images: string[];
  };
  RoomInventory: undefined;
  RoomDetail: { roomId: number };
};
```

### Navigation Implementation

```typescript
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  const { isAuthenticated } = useAuth();

  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={isAuthenticated ? "Home" : "Login"}
        screenOptions={{
          headerStyle: {
            backgroundColor: '#1a237e',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        {!isAuthenticated ? (
          <Stack.Screen
            name="Login"
            component={LoginScreen}
            options={{ headerShown: false }}
          />
        ) : (
          <>
            <Stack.Screen
              name="Home"
              component={HomeScreen}
              options={{ title: 'Spacewalker' }}
            />
            <Stack.Screen
              name="BuildingSelection"
              component={BuildingSelectionScreen}
              options={{ title: 'Select Building' }}
            />
            <Stack.Screen
              name="FloorSelection"
              component={FloorSelectionScreen}
              options={{ title: 'Select Floor' }}
            />
            {/* Additional screens... */}
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
```

## Screen Navigation Patterns

### Authentication Flow
- **Entry Point**: Login screen for unauthenticated users
- **Token Validation**: Automatic navigation based on stored authentication token
- **Session Management**: Automatic logout on token expiration

### Survey Flow (Linear Progression)
1. **Home** → Building Selection → Floor Selection → Room Selection
2. **Room Selection** → Camera → Analysis → Attribute Review
3. **Attribute Review** → AI Suggestions (optional) → Survey Submit
4. **Survey Submit** → Home (success) or back to review (retry)

### Inventory Flow (Exploratory)
1. **Home** → Room Inventory (browsing)
2. **Room Inventory** → Room Detail (specific room)
3. **Room Detail** → Camera (start new survey)

## State Management Integration

### Navigation State Persistence

```typescript
import { useNavigation, useRoute } from '@react-navigation/native';

const useNavigationState = () => {
  const navigation = useNavigation();
  const route = useRoute();

  const navigateToSurvey = (roomId: number) => {
    navigation.navigate('Camera', { roomId });
  };

  const navigateWithSurveyData = (surveyData: SurveyData) => {
    navigation.navigate('AttributeReview', {
      roomId: surveyData.roomId,
      images: surveyData.images,
      imageDetails: surveyData.imageDetails,
      initialAnalysisResult: surveyData.analysisResult,
    });
  };

  return {
    navigation,
    route,
    navigateToSurvey,
    navigateWithSurveyData,
  };
};
```

### Context Integration with Navigation

```typescript
interface NavigationContextType {
  currentFlow: 'survey' | 'inventory' | 'auth';
  surveyProgress: SurveyProgress;
  navigationHistory: NavigationHistoryItem[];
  canGoBack: boolean;
  resetToHome: () => void;
  resetSurveyFlow: () => void;
}

export const NavigationProvider = ({ children }: { children: ReactNode }) => {
  const [currentFlow, setCurrentFlow] = useState<'survey' | 'inventory' | 'auth'>('auth');
  const [surveyProgress, setSurveyProgress] = useState<SurveyProgress>(initialSurveyProgress);

  const resetToHome = useCallback(() => {
    setCurrentFlow('survey');
    setSurveyProgress(initialSurveyProgress);
    // Reset navigation to Home screen
  }, []);

  const resetSurveyFlow = useCallback(() => {
    setSurveyProgress(initialSurveyProgress);
    // Navigate back to building selection
  }, []);

  return (
    <NavigationContext.Provider value={{
      currentFlow,
      surveyProgress,
      resetToHome,
      resetSurveyFlow,
    }}>
      {children}
    </NavigationContext.Provider>
  );
};
```

## Navigation Guards and Validation

### Route Protection

```typescript
const useRouteProtection = () => {
  const { isAuthenticated, user } = useAuth();
  const navigation = useNavigation();

  const checkRouteAccess = useCallback((routeName: string, params?: any) => {
    // Authentication check
    if (!isAuthenticated && routeName !== 'Login') {
      navigation.navigate('Login');
      return false;
    }

    // Survey flow validation
    if (routeName === 'Camera' && !params?.roomId) {
      navigation.navigate('BuildingSelection');
      return false;
    }

    // Inventory access validation
    if (routeName === 'RoomDetail' && !params?.roomId) {
      navigation.navigate('RoomInventory');
      return false;
    }

    return true;
  }, [isAuthenticated, navigation]);

  return { checkRouteAccess };
};
```

### Parameter Validation

```typescript
const validateNavigationParams = (routeName: string, params: any): boolean => {
  switch (routeName) {
    case 'FloorSelection':
      return params?.buildingId && typeof params.buildingId === 'number';

    case 'RoomSelection':
      return params?.floorId && typeof params.floorId === 'number';

    case 'Camera':
      return params?.roomId && typeof params.roomId === 'number';

    case 'AnalysisResults':
      return params?.roomId && params?.images && Array.isArray(params.images);

    default:
      return true;
  }
};
```

## Deep Linking and URL Handling

### URL Scheme Configuration

```typescript
const linkingConfig = {
  prefixes: ['spacewalker://'],
  config: {
    screens: {
      Home: '',
      BuildingSelection: 'buildings',
      FloorSelection: 'buildings/:buildingId/floors',
      RoomSelection: 'buildings/:buildingId/floors/:floorId/rooms',
      Camera: 'survey/:roomId/camera',
      RoomDetail: 'inventory/rooms/:roomId',
    },
  },
};
```

### Dynamic Link Handling

```typescript
const useDynamicLinks = () => {
  const navigation = useNavigation();

  const handleDeepLink = useCallback((url: string) => {
    // Parse URL and extract parameters
    const route = parseDeepLinkURL(url);

    if (route) {
      navigation.navigate(route.screen, route.params);
    }
  }, [navigation]);

  useEffect(() => {
    // Listen for deep link events
    const subscription = Linking.addEventListener('url', ({ url }) => {
      handleDeepLink(url);
    });

    return () => subscription?.remove();
  }, [handleDeepLink]);

  return { handleDeepLink };
};
```

## Navigation Performance Optimization

### Lazy Loading Implementation

```typescript
import { lazy, Suspense } from 'react';

// Lazy load heavy screens
const CameraScreen = lazy(() => import('../screens/CameraScreen'));
const AnalysisResultsScreen = lazy(() => import('../screens/AnalysisResultsScreen'));

const LazyScreen = ({ component: Component, ...props }) => (
  <Suspense fallback={<LoadingSpinner />}>
    <Component {...props} />
  </Suspense>
);
```

### Navigation Preloading

```typescript
const useNavigationPreloading = () => {
  const navigation = useNavigation();

  const preloadNextScreen = useCallback(async (screenName: string, params?: any) => {
    // Preload data for next screen
    switch (screenName) {
      case 'FloorSelection':
        await preloadFloorData(params?.buildingId);
        break;
      case 'RoomSelection':
        await preloadRoomData(params?.floorId);
        break;
      // Additional preloading logic
    }
  }, []);

  return { preloadNextScreen };
};
```

## Navigation Accessibility

### Screen Reader Support

```typescript
const navigationConfig = {
  screenOptions: {
    headerAccessibilityLabel: 'Navigation header',
    gestureEnabled: true,
    screenReaderEnabled: true,
  },
};
```

### Keyboard Navigation

```typescript
const useKeyboardNavigation = () => {
  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', () => {
      // Adjust navigation behavior for keyboard
    });

    const keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', () => {
      // Reset navigation behavior
    });

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);
};
```

## Navigation Testing Patterns

### Navigation Testing Utilities

```typescript
import { fireEvent, waitFor } from '@testing-library/react-native';

export const navigationTestUtils = {
  async navigateToScreen(component: any, screenName: string, params?: any) {
    const navigation = component.props.navigation;
    navigation.navigate(screenName, params);
    await waitFor(() => {
      expect(navigation.navigate).toHaveBeenCalledWith(screenName, params);
    });
  },

  async goBack(component: any) {
    const navigation = component.props.navigation;
    navigation.goBack();
    await waitFor(() => {
      expect(navigation.goBack).toHaveBeenCalled();
    });
  },
};
```

## Related Documentation
- Mobile Architecture Overview → ../mobile/architecture/README.md
- Mobile State Management → ./state-management.md
- Mobile Development Guide → ../mobile/development/README.md
- Mobile Screen Components → ../development/screen-components.md

---
Last Updated: 2025-06-28
Status: Current
