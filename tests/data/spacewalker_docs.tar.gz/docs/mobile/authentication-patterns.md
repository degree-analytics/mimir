# Mobile Authentication Patterns

## Purpose
Comprehensive authentication patterns for React Native mobile applications including biometric integration, secure token storage, session management, and multi-factor authentication strategies for the Spacewalker mobile app.

## When to Use This
- Implementing secure authentication flows in React Native applications
- Integrating biometric authentication (fingerprint, face recognition)
- Managing secure token storage and session lifecycle
- Implementing multi-factor authentication patterns
- Keywords: React Native authentication, biometric auth, secure storage, session management, JWT tokens

**Version:** 1.0
**Date:** 2025-07-09
**Status:** Current

## Key Concepts
- **Biometric Authentication**: Device-based authentication using fingerprint, face recognition, or other biometric methods
- **Secure Token Storage**: Encrypted storage of authentication tokens using device security features
- **Session Management**: Handling token lifecycle, refresh, and expiration
- **Multi-Factor Authentication**: Combining multiple authentication methods for enhanced security

## Authentication Architecture Overview

```mermaid
graph TD
    A[App Launch] --> B[Check Stored Credentials]
    B --> C{Has Valid Token?}
    C -->|Yes| D[Biometric Check Available?]
    C -->|No| E[Login Screen]

    D -->|Yes| F[Prompt Biometric Auth]
    D -->|No| G[Auto Login]

    F -->|Success| G
    F -->|Fail| H[Fallback to Password]

    E --> I[Email/Password Login]
    I --> J[Server Authentication]
    J -->|Success| K[Store Token Securely]
    J -->|Fail| L[Show Error]

    K --> M[Setup Biometric if Available]
    M --> N[Navigate to App]

    G --> O[Validate Token]
    O -->|Valid| N
    O -->|Invalid| P[Token Refresh]
    P -->|Success| N
    P -->|Fail| E

    classDef auth fill:#E3F2FD,stroke:#1976D2,color:#000000
    classDef biometric fill:#F3E5F5,stroke:#7B1FA2,color:#000000
    classDef storage fill:#E8F5E8,stroke:#388E3C,color:#000000
    classDef flow fill:#FFF3E0,stroke:#F57C00,color:#000000

    class A,B,C,E,I,J auth
    class D,F,M biometric
    class K,O,P storage
    class G,N,L,H flow
```

## Biometric Authentication Integration

### Setup and Configuration

```typescript
// Install required dependency
// npm install expo-local-authentication

import * as LocalAuthentication from 'expo-local-authentication';

export class BiometricAuthService {
  private static instance: BiometricAuthService;
  private isSupported: boolean = false;
  private availableTypes: LocalAuthentication.AuthenticationType[] = [];

  private constructor() {
    this.initialize();
  }

  static getInstance(): BiometricAuthService {
    if (!BiometricAuthService.instance) {
      BiometricAuthService.instance = new BiometricAuthService();
    }
    return BiometricAuthService.instance;
  }

  private async initialize(): Promise<void> {
    try {
      this.isSupported = await LocalAuthentication.hasHardwareAsync();
      if (this.isSupported) {
        this.availableTypes = await LocalAuthentication.supportedAuthenticationTypesAsync();
      }
    } catch (error) {
      console.error('Error initializing biometric authentication:', error);
      this.isSupported = false;
    }
  }

  async isBiometricAvailable(): Promise<boolean> {
    if (!this.isSupported) return false;

    const isEnrolled = await LocalAuthentication.isEnrolledAsync();
    return isEnrolled;
  }

  async getBiometricTypes(): Promise<string[]> {
    return this.availableTypes.map(type => {
      switch (type) {
        case LocalAuthentication.AuthenticationType.FINGERPRINT:
          return 'fingerprint';
        case LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION:
          return 'face';
        case LocalAuthentication.AuthenticationType.IRIS:
          return 'iris';
        default:
          return 'biometric';
      }
    });
  }

  async authenticateWithBiometrics(
    promptMessage: string = 'Authenticate to access Spacewalker'
  ): Promise<BiometricAuthResult> {
    try {
      if (!await this.isBiometricAvailable()) {
        return {
          success: false,
          error: 'Biometric authentication not available',
          fallbackAvailable: true,
        };
      }

      const result = await LocalAuthentication.authenticateAsync({
        promptMessage,
        cancelLabel: 'Cancel',
        fallbackLabel: 'Use Password',
        disableDeviceFallback: false,
      });

      if (result.success) {
        return {
          success: true,
          method: this.availableTypes[0] ? this.getBiometricTypeString(this.availableTypes[0]) : 'biometric',
        };
      } else {
        return {
          success: false,
          error: result.error || 'Authentication failed',
          cancelled: result.error === 'UserCancel',
          fallbackAvailable: true,
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Authentication error',
        fallbackAvailable: true,
      };
    }
  }

  private getBiometricTypeString(type: LocalAuthentication.AuthenticationType): string {
    switch (type) {
      case LocalAuthentication.AuthenticationType.FINGERPRINT:
        return 'fingerprint';
      case LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION:
        return 'face';
      case LocalAuthentication.AuthenticationType.IRIS:
        return 'iris';
      default:
        return 'biometric';
    }
  }
}

interface BiometricAuthResult {
  success: boolean;
  method?: string;
  error?: string;
  cancelled?: boolean;
  fallbackAvailable?: boolean;
}
```

### Enhanced AuthContext with Biometric Support

```typescript
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { BiometricAuthService } from '../services/BiometricAuthService';
import { SecureStorageService } from '../services/SecureStorageService';
import { authApi } from '../lib/api';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  biometricAvailable: boolean;
  biometricEnabled: boolean;
  login: (credentials: LoginCredentials) => Promise<AuthResponse>;
  loginWithBiometrics: () => Promise<AuthResponse>;
  logout: () => Promise<void>;
  enableBiometrics: () => Promise<boolean>;
  disableBiometrics: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);

  const biometricService = BiometricAuthService.getInstance();
  const storageService = SecureStorageService.getInstance();

  useEffect(() => {
    initializeAuth();
  }, []);

  const initializeAuth = async () => {
    try {
      setIsLoading(true);

      // Check biometric availability
      const available = await biometricService.isBiometricAvailable();
      setBiometricAvailable(available);

      // Check if biometrics are enabled for this user
      const enabled = await storageService.getBiometricEnabled();
      setBiometricEnabled(enabled);

      // Try to restore user session
      if (enabled && available) {
        // Attempt biometric authentication for returning users
        const biometricResult = await biometricService.authenticateWithBiometrics(
          'Authenticate to access your account'
        );

        if (biometricResult.success) {
          const token = await storageService.getToken();
          if (token) {
            await validateAndRestoreSession(token);
          }
        }
      } else {
        // Standard token validation
        const token = await storageService.getToken();
        if (token) {
          await validateAndRestoreSession(token);
        }
      }
    } catch (error) {
      console.error('Error initializing auth:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const validateAndRestoreSession = async (token: string) => {
    try {
      const response = await authApi.getCurrentUser();
      if (response.success && response.data) {
        setUser(response.data);
        return response.data;
      } else {
        await storageService.clearToken();
        return null;
      }
    } catch (error) {
      console.error('Error validating session:', error);
      await storageService.clearToken();
      return null;
    }
  };

  const login = async (credentials: LoginCredentials): Promise<AuthResponse> => {
    try {
      const response = await authApi.login(credentials.email, credentials.password);

      if (response.success && response.data) {
        const { user, token } = response.data;

        // Store token securely
        await storageService.setToken(token);
        setUser(user);

        // Offer biometric setup if available and not already enabled
        if (biometricAvailable && !biometricEnabled) {
          // This would typically trigger a UI prompt
          console.log('Biometric authentication available - offer setup');
        }

        return {
          success: true,
          user,
          token,
        };
      } else {
        return {
          success: false,
          error: response.error || 'Login failed',
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Login failed',
      };
    }
  };

  const loginWithBiometrics = async (): Promise<AuthResponse> => {
    try {
      if (!biometricAvailable) {
        return {
          success: false,
          error: 'Biometric authentication not available',
        };
      }

      if (!biometricEnabled) {
        return {
          success: false,
          error: 'Biometric authentication not enabled',
        };
      }

      const biometricResult = await biometricService.authenticateWithBiometrics(
        'Authenticate to access Spacewalker'
      );

      if (biometricResult.success) {
        const token = await storageService.getToken();
        if (token) {
          const validatedUser = await validateAndRestoreSession(token);
          if (validatedUser) {
            return {
              success: true,
              user: validatedUser,
              method: 'biometric',
            };
          } else {
            return {
              success: false,
              error: 'Failed to validate session',
            };
          }
        } else {
          return {
            success: false,
            error: 'No stored credentials found',
          };
        }
      } else {
        return {
          success: false,
          error: biometricResult.error || 'Biometric authentication failed',
          cancelled: biometricResult.cancelled,
          fallbackAvailable: biometricResult.fallbackAvailable,
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Authentication failed',
      };
    }
  };

  const enableBiometrics = async (): Promise<boolean> => {
    try {
      if (!biometricAvailable) {
        return false;
      }

      const result = await biometricService.authenticateWithBiometrics(
        'Authenticate to enable biometric login'
      );

      if (result.success) {
        await storageService.setBiometricEnabled(true);
        setBiometricEnabled(true);
        return true;
      }

      return false;
    } catch (error) {
      console.error('Error enabling biometrics:', error);
      return false;
    }
  };

  const disableBiometrics = async (): Promise<void> => {
    await storageService.setBiometricEnabled(false);
    setBiometricEnabled(false);
  };

  const logout = async (): Promise<void> => {
    try {
      await authApi.logout();
    } catch (error) {
      console.error('Error during logout:', error);
    } finally {
      await storageService.clearToken();
      await storageService.setBiometricEnabled(false);
      setUser(null);
      setBiometricEnabled(false);
    }
  };

  const refreshUser = async (): Promise<void> => {
    const token = await storageService.getToken();
    if (token) {
      await validateAndRestoreSession(token);
    }
  };

  const value = {
    user,
    isLoading,
    isAuthenticated: !!user,
    biometricAvailable,
    biometricEnabled,
    login,
    loginWithBiometrics,
    logout,
    enableBiometrics,
    disableBiometrics,
    refreshUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
```

## Secure Token Storage Service

```typescript
import * as SecureStore from 'expo-secure-store';
import { MMKV } from 'react-native-mmkv';

export class SecureStorageService {
  private static instance: SecureStorageService;
  private mmkv: MMKV;

  private constructor() {
    this.mmkv = new MMKV({
      id: 'spacewalker-auth',
      encryptionKey: 'spacewalker-auth-encryption-key',
    });
  }

  static getInstance(): SecureStorageService {
    if (!SecureStorageService.instance) {
      SecureStorageService.instance = new SecureStorageService();
    }
    return SecureStorageService.instance;
  }

  // Secure token storage (uses device keychain/keystore)
  async setToken(token: string): Promise<void> {
    try {
      await SecureStore.setItemAsync('auth_token', token);

      // Store token metadata in MMKV for quick access
      this.mmkv.set('token_stored', true);
      this.mmkv.set('token_timestamp', Date.now());
    } catch (error) {
      console.error('Error storing token:', error);
      throw new Error('Failed to store authentication token');
    }
  }

  async getToken(): Promise<string | null> {
    try {
      const token = await SecureStore.getItemAsync('auth_token');
      return token;
    } catch (error) {
      console.error('Error retrieving token:', error);
      return null;
    }
  }

  async clearToken(): Promise<void> {
    try {
      await SecureStore.deleteItemAsync('auth_token');
      this.mmkv.delete('token_stored');
      this.mmkv.delete('token_timestamp');
    } catch (error) {
      console.error('Error clearing token:', error);
    }
  }

  // Biometric preferences (stored in MMKV)
  async setBiometricEnabled(enabled: boolean): Promise<void> {
    this.mmkv.set('biometric_enabled', enabled);
  }

  async getBiometricEnabled(): Promise<boolean> {
    return this.mmkv.getBoolean('biometric_enabled') ?? false;
  }

  // Session management
  async setLastLoginTime(timestamp: number): Promise<void> {
    this.mmkv.set('last_login_time', timestamp);
  }

  async getLastLoginTime(): Promise<number | null> {
    return this.mmkv.getNumber('last_login_time') ?? null;
  }

  async setSessionTimeout(minutes: number): Promise<void> {
    this.mmkv.set('session_timeout', minutes);
  }

  async getSessionTimeout(): Promise<number> {
    return this.mmkv.getNumber('session_timeout') ?? 60; // Default 60 minutes
  }

  // Token refresh metadata
  async setTokenRefreshTime(timestamp: number): Promise<void> {
    this.mmkv.set('token_refresh_time', timestamp);
  }

  async getTokenRefreshTime(): Promise<number | null> {
    return this.mmkv.getNumber('token_refresh_time') ?? null;
  }

  // User preferences
  async setUserPreferences(preferences: UserPreferences): Promise<void> {
    this.mmkv.set('user_preferences', JSON.stringify(preferences));
  }

  async getUserPreferences(): Promise<UserPreferences | null> {
    const preferences = this.mmkv.getString('user_preferences');
    return preferences ? JSON.parse(preferences) : null;
  }

  // Clear all user data
  async clearAllUserData(): Promise<void> {
    await this.clearToken();
    this.mmkv.delete('biometric_enabled');
    this.mmkv.delete('last_login_time');
    this.mmkv.delete('session_timeout');
    this.mmkv.delete('token_refresh_time');
    this.mmkv.delete('user_preferences');
  }
}

interface UserPreferences {
  theme: 'light' | 'dark' | 'system';
  language: string;
  notifications: boolean;
  offlineMode: boolean;
}
```

## Session Management Patterns

### Automatic Token Refresh

```typescript
export class TokenManager {
  private static instance: TokenManager;
  private refreshTimer: NodeJS.Timeout | null = null;
  private isRefreshing = false;

  private constructor() {}

  static getInstance(): TokenManager {
    if (!TokenManager.instance) {
      TokenManager.instance = new TokenManager();
    }
    return TokenManager.instance;
  }

  async scheduleTokenRefresh(tokenExpiryTime: number): Promise<void> {
    if (this.refreshTimer) {
      clearTimeout(this.refreshTimer);
    }

    // Schedule refresh 5 minutes before expiry
    const refreshTime = tokenExpiryTime - (5 * 60 * 1000);
    const currentTime = Date.now();

    if (refreshTime > currentTime) {
      this.refreshTimer = setTimeout(() => {
        this.refreshToken();
      }, refreshTime - currentTime);
    }
  }

  private async refreshToken(): Promise<void> {
    if (this.isRefreshing) return;

    this.isRefreshing = true;
    const storageService = SecureStorageService.getInstance();

    try {
      const currentToken = await storageService.getToken();
      if (!currentToken) {
        throw new Error('No current token found');
      }

      const response = await authApi.refreshToken(currentToken);

      if (response.success && response.data) {
        await storageService.setToken(response.data.token);
        await storageService.setTokenRefreshTime(Date.now());

        // Schedule next refresh
        if (response.data.expiresAt) {
          await this.scheduleTokenRefresh(response.data.expiresAt);
        }
      } else {
        // Token refresh failed - user needs to re-authenticate
        await storageService.clearToken();
        this.handleAuthenticationRequired();
      }
    } catch (error) {
      console.error('Token refresh failed:', error);
      await storageService.clearToken();
      this.handleAuthenticationRequired();
    } finally {
      this.isRefreshing = false;
    }
  }

  private handleAuthenticationRequired(): void {
    // Navigate to login screen or show authentication prompt
    // This would typically be handled by the AuthContext
    console.log('Authentication required - navigating to login');
  }

  clearTokenRefresh(): void {
    if (this.refreshTimer) {
      clearTimeout(this.refreshTimer);
      this.refreshTimer = null;
    }
  }
}
```

### Session Validation Hook

```typescript
import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

export const useSessionValidation = () => {
  const { user, logout } = useAuth();
  const [sessionValid, setSessionValid] = useState(true);

  useEffect(() => {
    if (!user) return;

    const validateSession = async () => {
      const storageService = SecureStorageService.getInstance();
      const lastLoginTime = await storageService.getLastLoginTime();
      const sessionTimeout = await storageService.getSessionTimeout();

      if (lastLoginTime) {
        const sessionAge = Date.now() - lastLoginTime;
        const maxSessionAge = sessionTimeout * 60 * 1000; // Convert to milliseconds

        if (sessionAge > maxSessionAge) {
          setSessionValid(false);
          await logout();
        }
      }
    };

    // Validate session every 5 minutes
    const validationInterval = setInterval(validateSession, 5 * 60 * 1000);

    // Initial validation
    validateSession();

    return () => clearInterval(validationInterval);
  }, [user, logout]);

  return { sessionValid };
};
```

## Multi-Factor Authentication Patterns

### MFA Setup Component

```typescript
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useAuth } from '../contexts/AuthContext';

export const MFASetupScreen: React.FC = () => {
  const { biometricAvailable, biometricEnabled, enableBiometrics } = useAuth();
  const [settingUp, setSettingUp] = useState(false);

  const handleEnableBiometrics = async () => {
    setSettingUp(true);

    try {
      const success = await enableBiometrics();

      if (success) {
        Alert.alert(
          'Success',
          'Biometric authentication has been enabled for your account.',
          [{ text: 'OK' }]
        );
      } else {
        Alert.alert(
          'Setup Failed',
          'Unable to enable biometric authentication. Please try again.',
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      Alert.alert(
        'Error',
        'An error occurred while setting up biometric authentication.',
        [{ text: 'OK' }]
      );
    } finally {
      setSettingUp(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Secure Your Account</Text>

      {biometricAvailable && !biometricEnabled && (
        <TouchableOpacity
          style={styles.setupButton}
          onPress={handleEnableBiometrics}
          disabled={settingUp}
        >
          <Text style={styles.setupButtonText}>
            {settingUp ? 'Setting up...' : 'Enable Biometric Authentication'}
          </Text>
        </TouchableOpacity>
      )}

      {biometricEnabled && (
        <Text style={styles.enabledText}>
          ✓ Biometric authentication is enabled
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  setupButton: {
    backgroundColor: '#2196F3',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  setupButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  enabledText: {
    color: 'green',
    fontSize: 16,
    textAlign: 'center',
  },
});
```

## Testing Authentication Patterns

### Authentication Testing Utilities

```typescript
// Test utilities for authentication patterns
export class AuthTestUtils {
  static mockBiometricAuthService(available: boolean = true, success: boolean = true) {
    const mockService = {
      isBiometricAvailable: jest.fn().mockResolvedValue(available),
      getBiometricTypes: jest.fn().mockResolvedValue(['fingerprint']),
      authenticateWithBiometrics: jest.fn().mockResolvedValue({
        success,
        method: 'fingerprint',
        error: success ? undefined : 'Authentication failed',
      }),
    };

    return mockService;
  }

  static mockSecureStorageService() {
    const storage = new Map();

    return {
      setToken: jest.fn((token) => storage.set('auth_token', token)),
      getToken: jest.fn(() => storage.get('auth_token') || null),
      clearToken: jest.fn(() => storage.delete('auth_token')),
      setBiometricEnabled: jest.fn((enabled) => storage.set('biometric_enabled', enabled)),
      getBiometricEnabled: jest.fn(() => storage.get('biometric_enabled') || false),
    };
  }

  static async testBiometricFlow() {
    const mockService = this.mockBiometricAuthService();

    // Test availability check
    expect(await mockService.isBiometricAvailable()).toBe(true);

    // Test authentication
    const result = await mockService.authenticateWithBiometrics();
    expect(result.success).toBe(true);
    expect(result.method).toBe('fingerprint');
  }
}
```

### Authentication Integration Tests

```typescript
// AuthContext.test.tsx
import React from 'react';
import { render, act } from '@testing-library/react-native';
import { AuthProvider, useAuth } from '../contexts/AuthContext';
import { AuthTestUtils } from '../utils/AuthTestUtils';

describe('AuthContext with Biometric Authentication', () => {
  it('should enable biometric authentication when available', async () => {
    const mockBiometricService = AuthTestUtils.mockBiometricAuthService();
    const mockStorageService = AuthTestUtils.mockSecureStorageService();

    const TestComponent = () => {
      const { biometricAvailable, enableBiometrics } = useAuth();

      return (
        <button
          testID="enable-biometric"
          onPress={enableBiometrics}
          disabled={!biometricAvailable}
        >
          Enable Biometric
        </button>
      );
    };

    const { getByTestId } = render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      const button = getByTestId('enable-biometric');
      expect(button).toBeTruthy();

      // Simulate enabling biometrics
      await button.props.onPress();
    });

    expect(mockBiometricService.authenticateWithBiometrics).toHaveBeenCalled();
  });

  it('should handle biometric authentication failure gracefully', async () => {
    const mockBiometricService = AuthTestUtils.mockBiometricAuthService(true, false);

    const TestComponent = () => {
      const { loginWithBiometrics } = useAuth();

      return (
        <button testID="biometric-login" onPress={loginWithBiometrics}>
          Login with Biometric
        </button>
      );
    };

    const { getByTestId } = render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await act(async () => {
      const button = getByTestId('biometric-login');
      const result = await button.props.onPress();

      expect(result.success).toBe(false);
      expect(result.error).toBe('Authentication failed');
    });
  });
});
```

## Related Documentation
- [Mobile Development Patterns](./development-patterns.md) - Core React Native patterns and best practices
- [Mobile State Management](./architecture/state-management.md) - Context and state management patterns
- [Mobile Offline Architecture](./architecture/offline-first.md) - Offline storage and sync patterns
- [Security Architecture](../architecture/security-architecture.md) - Overall security patterns and requirements

---
**Status**: ✅ Current
**Last Updated**: 2025-07-09
**Technology Stack**: React Native, Expo, TypeScript, expo-local-authentication, expo-secure-store, MMKV
