# Mobile Emulators and Simulators

This guide covers installing and using iOS Simulator and Android Emulator with SpaceWalker’s `just expo` workflow.

## Prerequisites
- macOS recommended for iOS Simulator
- Node.js 20.19.4 (per apps/mobile/package.json engines)
- Expo CLI or `npx expo`, EAS CLI or `npx eas-cli`

## iOS Simulator (macOS)
1. Install Xcode from the App Store.
2. Install Command Line Tools: open Xcode once, accept license, then run `xcode-select --install` if needed.
3. Verify tools:
   ```bash
   xcrun --version
   xcodebuild -version
   ```
4. List available devices:
   ```bash
   just expo simulator list
   ```
5. Boot a device:
   ```bash
   just expo simulator boot <udid-or-name>
   ```
6. Start the dev server and open Simulator:
   ```bash
   just expo start --ios
   # Or with dev client:
   just expo start --dev-client --ios
   ```

Notes:
- Expo Go works seamlessly in Simulator. For native module debugging, use a Dev Client build first (`just expo build ios development`).

## Android Emulator (macOS, Linux, Windows)
1. Install Android Studio.
2. Through SDK Manager, install:
   - Android SDK Platform (latest stable)
   - Android SDK Platform-Tools
   - Android Emulator
   - A system image (e.g., Android 15, Pixel device)
3. Create an AVD via AVD Manager (e.g., Pixel 7/8).
4. Ensure `emulator` and `adb` are on PATH (Android Studio typically configures this).
5. List AVDs:
   ```bash
   just expo emulator list
   ```
6. Start an AVD:
   ```bash
   just expo emulator start <name>
   ```
7. Start dev server and open the emulator:
   ```bash
   just expo start --android
   ```

Optional networking tips:
- If your mobile app calls a host service, use `adb reverse` to map host ports:
  ```bash
  adb reverse tcp:8000 tcp:8000
  ```

### Windows PATH setup
If `emulator` or `adb` are not recognized on Windows, ensure the Android SDK tools are on PATH and `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) is set.

1. Determine your SDK location (default):
   - `C:\\Users\\<you>\\AppData\\Local\\Android\\Sdk`
2. Set environment variables (System Properties → Environment Variables):
   - `ANDROID_HOME` or `ANDROID_SDK_ROOT` → `C:\\Users\\<you>\\AppData\\Local\\Android\\Sdk`
   - Add to `Path`:
     - `%ANDROID_HOME%\platform-tools`  (adb)
     - `%ANDROID_HOME%\emulator`        (emulator)
     - `%ANDROID_HOME%\tools` and `%ANDROID_HOME%\tools\bin` (legacy avdmanager)
3. Open a new terminal (PowerShell or Command Prompt) and verify:
   ```powershell
   adb --version
   emulator -version
   avdmanager --help
   ```

Notes:
- iOS Simulator is not available on Windows.
- WSL does not support iOS Simulator; use Android Emulator in Windows instead.

## Daily Dev Flow (with Emulator)
```bash
# Start backend + admin, configure mobile IP, then Expo Go offline
just up local

# Alternatively start directly with desired target
just expo ip auto
just expo start --dev-client --ios   # iOS Dev Client
# or
just expo start --android            # Android Emulator
```

## Building Dev Clients
Dev client builds are required to test native modules outside of Expo Go.
```bash
just expo build ios development --wait
just expo build android development --wait
```
After installing the dev client on your device/emulator, use `just expo start --dev-client --ios|--android`.

## Troubleshooting
- iOS: If `xcrun` not found, install Command Line Tools or ensure Xcode is installed.
- Android: If `emulator` command fails, verify Android SDK tools are installed and on PATH. Start from Android Studio if needed.
- Network: If device cannot reach backend, run `just expo ip auto` and prefer `--offline` for Expo Go, or `adb reverse` for Android.
