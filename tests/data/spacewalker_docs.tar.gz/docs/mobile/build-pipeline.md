# Mobile Build Pipeline & Troubleshooting Guide

**SpaceWalker Mobile App** - Complete guide to EAS build pipeline, troubleshooting common build issues, and optimization strategies

---

## 📋 Overview

This guide covers the complete EAS (Expo Application Services) build pipeline for the SpaceWalker mobile application, including:
- **Build pipeline architecture** and stages
- **Common build failures** and solutions
- **Performance optimization** strategies
- **CI/CD integration** troubleshooting
- **Platform-specific issues** (iOS and Android)

---

## 🏗️ Build Pipeline Architecture

### Build Profiles Overview

| Profile | Purpose | Platform | Build Type | Distribution | Auto Increment |
|---------|---------|----------|------------|--------------|----------------|
| **development** | Local testing | iOS/Android | Simulator/APK | Internal | No |
| **preview** | QA testing | iOS/Android | Device/AAB | Internal | Yes |
| **production** | App store | iOS/Android | Store/AAB | Public | Yes |

### Build Process Flow

```mermaid
flowchart TD
    A[Git Push] --> B[GitHub Actions Trigger]
    B --> C[Setup Environment]
    C --> D[Install Dependencies]
    D --> E[Run Tests]
    E --> F[EAS Build]
    F --> G[Apple/Google Processing]
    G --> H[Distribution]

    F --> F1[Compile Code]
    F --> F2[Bundle Assets]
    F --> F3[Sign App]
    F --> F4[Generate Artifacts]

    H --> H1[TestFlight]
    H --> H2[Play Store]
    H --> H3[Direct Download]
```

### Build Stages in Detail

#### 1. Environment Setup (2-5 minutes)
```bash
# Node.js and dependencies installation
node: 20.19.4 (exact version)
npm: >=10.0.0
expo-cli: latest
eas-cli: >=12.0.0

# Platform-specific tools
iOS: Xcode, iOS SDK
Android: Android SDK, Build Tools
```

#### 2. Dependency Installation (3-8 minutes)
```bash
# Clean dependency installation
npm ci --prefer-offline --no-audit

# Platform-specific dependencies
# iOS: CocoaPods, iOS libraries
# Android: Gradle dependencies
```

#### 3. Code Compilation (5-15 minutes)
```bash
# TypeScript compilation
tsc --noEmit --skipLibCheck

# Metro bundling
npx expo export --platform [ios|android]

# Platform builds
# iOS: Xcode build process
# Android: Gradle build process
```

#### 4. Asset Processing (2-10 minutes)
```bash
# Image optimization
# Icon generation (all required sizes)
# Splash screen generation
# Font embedding
# Asset bundling
```

#### 5. Code Signing (1-5 minutes)
```bash
# iOS: Provisioning profiles, certificates
# Android: Keystore signing
# EAS credential management
```

#### 6. Artifact Generation (1-3 minutes)
```bash
# iOS: .ipa file generation
# Android: .apk or .aab generation
# Source maps and debugging symbols
```

#### Managed Prebuild Workflow (Local Native Runs)
```bash
# Generate native projects only when you need them locally
just expo prebuild --platform android -- --skip-dependency-install

# …run your native command(s)…

# After you're done, remove the generated folders
just expo clean-native
```

> 💡 **Why:** In Expo’s managed workflow the native folders are ephemeral. Leaving them in git prevents Expo/EAS from syncing
> values such as splash screens or icons from `app.config.js`. Use the helper commands to regenerate on demand and then
> clean up so the repo stays in managed mode.

---

## 🚨 Common Build Failures

### 0. EAS Build Archive Size Issues

#### **"Your project archive is 3.2 GB" Error**

**Symptoms:**
```
Your project archive is 3.2 GB. You can reduce its size and the time it takes to upload by excluding files that are unnecessary for the build process in .easignore file.
Failed to upload project tarball to EAS Build - Maximum allowed size is 2.0 GB
```

**Root Cause:**
EAS uploads the entire monorepo including:
- Large `.git` directory from `fetch-depth: 0` in GitHub Actions
- All `node_modules` directories across the monorepo
- Backend virtual environments and other project directories

**Solution:**
Use "deny all, then allow specific" pattern in root `.easignore`:

```bash
# Root directory .easignore
*                          # Deny everything
!/package.json            # Allow root package files
!/apps/mobile/            # Allow mobile app
!/packages/               # Allow shared packages
/apps/mobile/node_modules  # Re-exclude node_modules
/packages/**/node_modules  # Re-exclude nested node_modules
```

**Key Points:**
- Place `.easignore` in repository root (not in `apps/mobile/`)
- Start with `*` to exclude everything by default
- Use `!` prefix to whitelist specific files/directories
- Re-exclude `node_modules` even in whitelisted directories

**See**: [EAS Build Archive Optimization](../gotchas/eas-build-archive-optimization.md) for complete solution details.

### 1. Dependency Issues

#### **"Module not found" Errors**

**Symptoms:**
```
Error: Unable to resolve module `@react-native-async-storage/async-storage`
Error: Cannot resolve dependency
```

**Solutions:**
```bash
# Check package.json consistency
cd apps/mobile
npm ls --depth=0

# Clean and reinstall
just service clean mobile
just service install mobile

# Check for peer dependency issues
npm ls --depth=1 | grep UNMET

# Manual dependency check
just env_check
```

#### **Version Conflicts**

**Symptoms:**
```
npm ERR! peer dep missing
npm ERR! conflicting peer dependency
WARN package.json: Expo SDK version mismatch
```

**Solutions:**
```bash
# Check Expo SDK compatibility
npx expo doctor

# Update to compatible versions
npx expo upgrade

# Force resolution in package.json (last resort)
"overrides": {
  "problematic-package": "^1.0.0"
}
```

#### **Missing Platform Dependencies**

**Symptoms:**
```
iOS: 'React/React.h' file not found
Android: Failed to resolve: com.facebook.react:react-native
```

**Solutions:**
```bash
# iOS: Clean and reinstall pods
cd apps/mobile/ios && rm -rf Pods Podfile.lock
cd .. && npx pod-install ios

# Android: Clean Gradle cache
cd apps/mobile/android
./gradlew clean
./gradlew --stop
```

### 2. Configuration Issues

#### **Bundle ID Validation Errors**

**Symptoms:**
```
Error: Invalid bundle identifier format
iOS: Bundle ID contains invalid characters
Android: Package name must be lowercase
```

**Solutions:**
```bash
# Check bundle ID format in app.config.js
rg -A5 "bundleIdentifier" apps/mobile/app.config.js

# Validate with regex pattern
# Valid: com.company.app.variant
# Invalid: com.company.app-variant (hyphens not allowed)

# Fix bundle ID validation
export EXPO_PUBLIC_BUNDLE_ID_IOS=com.degreeanalytics.spacewalker.dev
export EXPO_PUBLIC_BUNDLE_ID_ANDROID=com.degreeanalytics.spacewalker.dev
```

#### **Environment Variable Issues**

**Symptoms:**
```
TypeError: Cannot read property 'API_BASE_URL' of undefined
Configuration validation failed
```

**Solutions:**
```bash
# Check environment variables in EAS build
cat apps/mobile/eas.json | jq '.build.preview.env'

# Validate configuration locally
just mobile_env_validate

# Debug configuration sources
just mobile_config_debug

# Test configuration loading
cd apps/mobile
node -e "const config = require('./app.config.js'); console.log(config)"
```

#### **EAS Configuration Problems**

**Symptoms:**
```
eas.json validation failed
Invalid build configuration
Unsupported configuration option
```

**Solutions:**
```bash
# Validate EAS configuration
cd apps/mobile
eas build:configure
eas config

# Check configuration format
npx expo config --type public

# Validate against schema
npm run validate:eas  # If script exists
```

### 3. Code Signing Issues

#### **iOS Provisioning Profile Problems**

**Symptoms:**
```
No profiles for 'com.degreeanalytics.spacewalker' were found
Provisioning profile doesn't match bundle identifier
Certificate not found in keychain
```

**Solutions:**
```bash
# Check EAS credentials
eas credentials --platform ios

# Reset credentials (if needed)
eas credentials --platform ios --clear-provisioning-profile
eas credentials --platform ios --clear-cert

# Manual credential setup
eas build --platform ios --clear-credentials

# Verify Apple Developer account
# Check: developer.apple.com → Certificates, IDs & Profiles
```

#### **Android Signing Problems**

**Symptoms:**
```
Keystore file not found
Key alias not found in keystore
Invalid keystore format
```

**Solutions:**
```bash
# Check Android credentials
eas credentials --platform android

# Setup service account
# Follow: apps/mobile/android/SERVICE_ACCOUNT_SETUP.md

# Generate new keystore (if needed)
eas credentials --platform android --clear-keystore

# Verify service account
# Check: Google Play Console → Setup → API access
```

### 4. Build Timeout Issues

#### **Slow Build Performance**

**Symptoms:**
```
Build timeout after 45 minutes
Metro bundler taking too long
Gradle build exceeding time limits
```

**Solutions:**
```bash
# Optimize build performance
# In eas.json, increase resource class:
"ios": {
  "resourceClass": "large"  # Premium feature
}

# Clear build cache
eas build --clear-cache

# Optimize dependencies
# Remove unused packages from package.json
npm ls --depth=0 | grep extraneous

# Split large bundles
# Use dynamic imports for heavy libraries
```

#### **Memory Issues**

**Symptoms:**
```
JavaScript heap out of memory
OOM killed
Build process terminated
```

**Solutions:**
```bash
# Increase memory limits in eas.json
"env": {
  "NODE_OPTIONS": "--max-old-space-size=4096"
}

# Optimize bundle size
npx expo export --dump-sourcemap
npx @expo/metro-config analyze bundle.map

# Remove large dependencies
# Consider lighter alternatives for heavy libraries
```

### 5. Platform-Specific Issues

#### **iOS Build Failures**

**Common iOS Issues:**
```bash
# Xcode version compatibility
# Solution: Update Xcode in build environment

# Swift/Objective-C compilation errors
# Solution: Check native iOS dependencies

# Info.plist configuration errors
# Solution: Verify app.config.js iOS settings

# Simulator vs Device builds
# Solution: Use correct build profile
```

**iOS Debugging:**
```bash
# Check iOS logs in EAS build
eas logs --build-id <build-id> --platform ios

# Local iOS debugging
just mobile_ios
# Check Xcode simulator console for errors

# Verify iOS configuration
cd apps/mobile
npx expo config --type introspect | jq '.ios'
```

#### **Android Build Failures**

**Common Android Issues:**
```bash
# Gradle version conflicts
# Solution: Update Gradle wrapper

# Android SDK version issues
# Solution: Update compileSdkVersion, targetSdkVersion

# ProGuard/R8 optimization errors
# Solution: Configure proguard-rules.pro

# Play Store requirements
# Solution: Use AAB format, update target API
```

**Android Debugging:**
```bash
# Check Android logs in EAS build
eas logs --build-id <build-id> --platform android

# Local Android debugging
just mobile_android
adb logcat | rg -i "expo"

# Verify Android configuration
cd apps/mobile
npx expo config --type introspect | jq '.android'
```

---

## 🔧 Troubleshooting Workflows

### Build Failure Diagnosis

#### 1. Initial Assessment
```bash
# Check build status
just mobile_build_status

# Get recent builds
eas build:list --platform all --limit 5

# Check specific build
eas logs --build-id <failed-build-id>
```

#### 2. Local Reproduction
```bash
# Try to reproduce locally
just mobile_build_ios_local
just mobile_build_android_local

# Check for configuration differences
just mobile_env_validate
just mobile_config_debug
```

#### 3. Systematic Debugging
```bash
# Step 1: Validate dependencies
just env_check
npm audit --audit-level=moderate

# Step 2: Test configuration
cd apps/mobile
npx expo doctor
eas build:configure --platform all

# Step 3: Clean build
just service clean mobile
just service install mobile
eas build --platform all --clear-cache
```

#### 4. Isolation Testing
```bash
# Test individual platforms
eas build --platform ios --profile development
eas build --platform android --profile development

# Test without EAS (local only)
cd apps/mobile
npx expo export --platform ios
npx expo export --platform android
```

### CI/CD Pipeline Debugging

#### GitHub Actions Issues
```bash
# Check workflow status
# GitHub → Actions → Workflow runs

# Download artifacts
# GitHub → Actions → Run → Artifacts section

# Review environment setup
# Check: Node.js version, dependency installation logs

# Validate secrets
# Ensure: EXPO_TOKEN, APP_STORE_CONNECT_* secrets
```

#### EAS CLI Issues
```bash
# Update EAS CLI
npm install -g eas-cli@latest

# Check authentication
eas whoami
eas login  # If not authenticated

# Validate EAS project
cd apps/mobile
eas project:info
```

### Performance Debugging

#### Build Time Analysis
```bash
# Profile build times
# Check EAS dashboard for stage-by-stage timing

# Identify bottlenecks:
# - Dependency installation: package.json optimization
# - Compilation: TypeScript/Metro configuration
# - Asset processing: Image optimization
# - Signing: Credential caching
```

#### Bundle Size Analysis
```bash
# Analyze bundle composition
cd apps/mobile
npx expo export --dump-sourcemap
npx @expo/metro-config analyze sourcemap.json

# Identify large dependencies
npm ls --depth=0 --long

# Check for duplicate dependencies
npm ls --depth=1 | rg "(├─|└─).*@.*" | sort
```

---

## ⚡ Performance Optimization

### Build Speed Optimization

#### 1. Dependency Optimization
```bash
# Remove unused dependencies
npm ls --depth=0 | grep extraneous
npm uninstall <unused-package>

# Use lighter alternatives
# lodash → lodash/es (tree-shaking)
# moment → date-fns (smaller bundle)
# axios → fetch (native)

# Optimize package.json
# Move devDependencies appropriately
# Use exact versions for stability
```

#### 2. Metro Configuration
```javascript
// metro.config.js optimizations
module.exports = {
  transformer: {
    minifierConfig: {
      keep_fargs: true,
      mangle: {
        keep_classnames: true,
      },
    },
  },
  resolver: {
    alias: {
      // Add path aliases to reduce resolution time
      '@components': './src/components',
      '@utils': './src/utils',
    },
  },
  serializer: {
    getModulesRunBeforeMainModule: () => [
      // Optimize module loading order
    ],
  },
};
```

#### 3. EAS Build Optimization
```json
// eas.json optimizations
{
  "build": {
    "production": {
      "env": {
        "NODE_ENV": "production",
        "NODE_OPTIONS": "--max-old-space-size=4096"
      },
      "cache": {
        "disabled": false,
        "customPaths": ["node_modules"]
      }
    }
  }
}
```

### Bundle Size Optimization

#### 1. Import Optimization
```typescript
// Prefer specific imports
import { debounce } from 'lodash/debounce';  // Good
import _ from 'lodash';  // Avoid

// Use tree-shaking friendly libraries
import { format } from 'date-fns';  // Good
import moment from 'moment';  // Larger bundle
```

#### 2. Dynamic Imports
```typescript
// Lazy load heavy components
const HeavyComponent = React.lazy(() => import('./HeavyComponent'));

// Conditional library loading
const loadLibrary = async () => {
  if (condition) {
    const lib = await import('heavy-library');
    return lib.default;
  }
};
```

#### 3. Asset Optimization
```bash
# Optimize images
# Use appropriate formats: WebP for photos, PNG for graphics
# Compress images before bundling
# Use different resolutions for different screen densities

# Minimize font loading
# Include only necessary font weights and styles
# Consider system fonts for better performance
```

---

## 🔍 Advanced Debugging

### Build Environment Analysis

#### Environment Variables Debug
```bash
# Check all environment variables during build
# Add to eas.json env section:
"DEBUG_ENV": "true",
"NODE_ENV": "production"

# Create debug script
# apps/mobile/debug-env.js:
console.log('Environment variables:', {
  NODE_ENV: process.env.NODE_ENV,
  EXPO_PUBLIC_API_BASE_URL: process.env.EXPO_PUBLIC_API_BASE_URL,
  // ... other variables
});
```

#### Build Cache Analysis
```bash
# Check cache effectiveness
eas build --platform ios --profile development --verbose

# Clear specific cache types
eas build --clear-cache  # All caches
# Or manually clear EAS cache in dashboard

# Verify cache configuration
# EAS Dashboard → Project → Settings → Build cache
```

### Network and Connectivity Issues

#### Build Network Problems
```bash
# Network timeout during dependency installation
# Solution: Retry build, check npm registry status

# Credential download failures
# Solution: Verify EAS credentials, check network

# Asset download timeouts
# Solution: Optimize asset sizes, use CDN
```

#### Regional Build Issues
```bash
# Build servers in different regions may have different behavior
# Check EAS status page for regional issues
# Try building at different times of day

# Temporary workarounds:
# Use local builds: just mobile_build_local
# Manual submission: eas submit --latest
```

### Memory and Resource Debugging

#### Memory Usage Analysis
```bash
# Monitor build memory usage
# Available in EAS build logs

# Optimize for memory constraints
# Reduce concurrent operations
# Split large files
# Use streaming operations
```

#### Resource Class Selection
```json
// eas.json resource optimization
{
  "build": {
    "production": {
      "ios": {
        "resourceClass": "default",  // Free tier
        // "resourceClass": "large"  // Premium (faster builds)
      },
      "android": {
        "resourceClass": "default"
      }
    }
  }
}
```

---

## 📊 Monitoring and Alerts

### Build Success Metrics

#### Key Performance Indicators
```bash
# Build success rate: >95%
# Average build time: <30 minutes
# Cache hit rate: >80%
# Test pass rate: 100%
```

#### Monitoring Dashboard
```bash
# EAS Dashboard metrics:
# - Build queue times
# - Success/failure rates
# - Build duration trends
# - Resource usage patterns

# GitHub Actions metrics:
# - Workflow success rates
# - Action execution times
# - Artifact generation
```

### Alerting Setup

#### Build Failure Notifications
```bash
# GitHub Actions notifications
# Settings → Notifications → Actions

# Slack integration (if configured)
# Webhook notifications for build failures

# Email notifications
# EAS build completion emails
# Critical failure alerts
```

#### Proactive Monitoring
```bash
# Weekly build health check
# Monthly dependency updates
# Quarterly performance review
# Annual security audit
```

---

## 🛠️ Recovery Procedures

### Emergency Build Recovery

#### Critical Build Failure
```bash
# Step 1: Assess impact
eas build:list --status=errored --limit 5

# Step 2: Quick fix attempt
just service clean mobile
just mobile_build_local  # Test locally first

# Step 3: Emergency bypass
# Manual local build and upload
# Direct submission to stores

# Step 4: Root cause analysis
# Review build logs
# Identify and fix underlying issue
```

#### Rollback Procedures
```bash
# Rollback to previous working build
eas build:list --status=finished --limit 10
eas submit --build-id <previous-working-build>

# Revert problematic changes
git revert <problematic-commit>
git push origin main

# Emergency hotfix
git checkout -b hotfix/emergency-fix
# ... implement fix ...
git checkout main && git merge hotfix/emergency-fix
```

### Data Recovery

#### Build Artifacts Recovery
```bash
# Download build artifacts
eas build:download --build-id <build-id>

# GitHub Actions artifacts
# Download from workflow run page

# Local backup procedures
# Regular backup of important builds
# Version tagging for releases
```

#### Configuration Recovery
```bash
# Backup important configurations
cp apps/mobile/eas.json apps/mobile/eas.json.backup
cp apps/mobile/app.config.js apps/mobile/app.config.js.backup

# Version control for configurations
git tag -a config-v1.0 -m "Working EAS configuration"

# Recovery procedures
git checkout config-v1.0 -- apps/mobile/eas.json
```

---

## 📚 Best Practices Summary

### Build Pipeline Best Practices

#### 1. Configuration Management
```bash
# ✅ Use environment-specific configurations
# ✅ Validate configurations before builds
# ✅ Version control all configuration files
# ✅ Regular configuration backups

# ❌ Avoid hardcoded values
# ❌ Don't commit sensitive credentials
# ❌ Avoid manual configuration changes
```

#### 2. Build Reliability
```bash
# ✅ Test builds locally first
# ✅ Use exact dependency versions
# ✅ Implement retry mechanisms
# ✅ Monitor build success rates

# ❌ Skip local testing
# ❌ Use loose version ranges
# ❌ Ignore build warnings
```

#### 3. Performance Optimization
```bash
# ✅ Regular dependency audits
# ✅ Bundle size monitoring
# ✅ Build time optimization
# ✅ Cache utilization

# ❌ Ignore performance metrics
# ❌ Add dependencies without review
# ❌ Skip optimization steps
```

### Troubleshooting Best Practices

#### 1. Systematic Approach
```bash
# 1. Reproduce locally
# 2. Check recent changes
# 3. Review build logs
# 4. Test incrementally
# 5. Document solutions
```

#### 2. Documentation and Knowledge Sharing
```bash
# ✅ Document all fixes
# ✅ Share knowledge with team
# ✅ Update troubleshooting guides
# ✅ Maintain runbooks

# Update this guide with new issues:
# docs/mobile/build-pipeline.md
```

#### 3. Proactive Maintenance
```bash
# Weekly: Check build success rates
# Monthly: Update dependencies
# Quarterly: Review build performance
# Annually: Audit entire pipeline
```

---

## 📚 Related Documentation

- **[Mobile Architecture](./architecture.md)** - Configuration system details
- **[Environment Configuration](./environment-config.md)** - Environment setup
- **[TestFlight Guide](./testflight-guide.md)** - Distribution process
- **[Mobile Development Workflows](../workflows/mobile-development.md)** - Development guide
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General troubleshooting

### External Resources
- **[EAS Build Documentation](https://docs.expo.dev/build/introduction/)**
- **[Expo Troubleshooting](https://docs.expo.dev/troubleshooting/build-errors/)**
- **[React Native Build Issues](https://reactnative.dev/docs/troubleshooting)**
- **[Xcode Build Issues](https://developer.apple.com/documentation/xcode)**
- **[Android Build Issues](https://developer.android.com/studio/build/)**

---

**Last Updated**: {{ current_date }}
**Pipeline Version**: 2.0 (EAS Build Integration)
**Status**: ✅ Comprehensive Troubleshooting Guide Active
