# Mobile Survey Upload Patterns

## Purpose
Comprehensive survey upload patterns for React Native mobile applications including image compression, progress tracking, batch upload strategies, and network-aware upload optimization for the Spacewalker mobile app.

## When to Use This
- Implementing efficient image and data upload workflows in mobile applications
- Managing large file uploads with progress tracking and error handling
- Implementing batch upload strategies for offline-first applications
- Optimizing uploads based on network conditions and device capabilities
- Keywords: mobile uploads, image compression, progress tracking, batch uploads, network optimization

**Version:** 1.0
**Date:** 2025-07-09
**Status:** Current

## Key Concepts
- **Progressive Upload**: Uploading data in chunks to manage memory and network usage
- **Compression Pipeline**: Multi-stage image compression and optimization
- **Upload Queue**: Prioritized queue system for managing upload operations
- **Progress Tracking**: Real-time progress monitoring and user feedback
- **Network Adaptation**: Adjusting upload strategies based on connection quality

## Upload Architecture Overview

```mermaid
graph TD
    A[Survey Data Ready] --> B[Image Compression Pipeline]
    B --> C[Upload Queue Management]
    C --> D[Network Quality Assessment]
    D --> E[Upload Strategy Selection]

    E --> F{Upload Type}
    F -->|Single| G[Direct Upload]
    F -->|Batch| H[Batch Upload]
    F -->|Progressive| I[Chunked Upload]

    G --> J[Progress Tracking]
    H --> J
    I --> J

    J --> K{Upload Success?}
    K -->|Yes| L[Update Local Status]
    K -->|No| M[Error Handling]

    M --> N{Retry Logic}
    N -->|Retry| O[Exponential Backoff]
    N -->|Fail| P[Queue for Later]

    O --> E
    P --> Q[Offline Storage]
    L --> R[Sync Complete]

    classDef compression fill:#E3F2FD,stroke:#1976D2,color:#000000
    classDef upload fill:#F3E5F5,stroke:#7B1FA2,color:#000000
    classDef progress fill:#E8F5E8,stroke:#388E3C,color:#000000
    classDef error fill:#FFF3E0,stroke:#F57C00,color:#000000

    class A,B,C compression
    class D,E,F,G,H,I upload
    class J,L,R progress
    class M,N,O,P,Q error
```

## Image Compression Pipeline

### Advanced Image Compression Service

```typescript
import { ImageManipulator } from 'expo-image-manipulator';
import * as FileSystem from 'expo-file-system';
import { Platform } from 'react-native';

export interface CompressionOptions {
  maxWidth: number;
  maxHeight: number;
  quality: number;
  format: 'jpeg' | 'png' | 'webp';
  generateThumbnail: boolean;
  preserveExif: boolean;
}

export interface CompressionResult {
  uri: string;
  width: number;
  height: number;
  fileSize: number;
  thumbnailUri?: string;
  compressionRatio: number;
  originalSize: number;
  metadata?: any;
}

export class ImageCompressionService {
  private static instance: ImageCompressionService;
  private compressionQueue: Map<string, Promise<CompressionResult>> = new Map();

  static getInstance(): ImageCompressionService {
    if (!ImageCompressionService.instance) {
      ImageCompressionService.instance = new ImageCompressionService();
    }
    return ImageCompressionService.instance;
  }

  async compressImage(
    uri: string,
    options: Partial<CompressionOptions> = {}
  ): Promise<CompressionResult> {
    const compressionId = `${uri}_${JSON.stringify(options)}`;

    // Check if compression is already in progress
    if (this.compressionQueue.has(compressionId)) {
      return this.compressionQueue.get(compressionId)!;
    }

    const compressionPromise = this.performCompression(uri, options);
    this.compressionQueue.set(compressionId, compressionPromise);

    try {
      const result = await compressionPromise;
      return result;
    } finally {
      this.compressionQueue.delete(compressionId);
    }
  }

  private async performCompression(
    uri: string,
    options: Partial<CompressionOptions>
  ): Promise<CompressionResult> {
    const defaultOptions: CompressionOptions = {
      maxWidth: 2048,
      maxHeight: 2048,
      quality: 0.8,
      format: 'jpeg',
      generateThumbnail: true,
      preserveExif: true,
    };

    const finalOptions = { ...defaultOptions, ...options };

    try {
      // Get original file info
      const originalInfo = await FileSystem.getInfoAsync(uri);
      const originalSize = originalInfo.size || 0;

      // Get image dimensions
      const imageInfo = await this.getImageDimensions(uri);

      // Calculate optimal compression settings
      const compressionSettings = this.calculateCompressionSettings(
        imageInfo,
        finalOptions
      );

      // Perform compression
      const compressedResult = await ImageManipulator.manipulateAsync(
        uri,
        compressionSettings.manipulations,
        {
          compress: compressionSettings.quality,
          format: finalOptions.format === 'jpeg' ?
            ImageManipulator.SaveFormat.JPEG :
            ImageManipulator.SaveFormat.PNG,
        }
      );

      // Get compressed file size
      const compressedInfo = await FileSystem.getInfoAsync(compressedResult.uri);
      const compressedSize = compressedInfo.size || 0;

      // Generate thumbnail if requested
      let thumbnailUri;
      if (finalOptions.generateThumbnail) {
        thumbnailUri = await this.generateThumbnail(compressedResult.uri);
      }

      return {
        uri: compressedResult.uri,
        width: compressedResult.width,
        height: compressedResult.height,
        fileSize: compressedSize,
        thumbnailUri,
        compressionRatio: originalSize > 0 ? compressedSize / originalSize : 1,
        originalSize,
        metadata: finalOptions.preserveExif ? await this.extractMetadata(uri) : undefined,
      };
    } catch (error) {
      console.error('Image compression failed:', error);
      throw new Error(`Image compression failed: ${error.message}`);
    }
  }

  private async getImageDimensions(uri: string): Promise<{ width: number; height: number }> {
    const result = await ImageManipulator.manipulateAsync(uri, [], {});
    return { width: result.width, height: result.height };
  }

  private calculateCompressionSettings(
    imageInfo: { width: number; height: number },
    options: CompressionOptions
  ): { manipulations: any[]; quality: number } {
    const { width, height } = imageInfo;
    const { maxWidth, maxHeight, quality } = options;

    const manipulations = [];

    // Calculate resize if needed
    if (width > maxWidth || height > maxHeight) {
      const aspectRatio = width / height;
      let newWidth = maxWidth;
      let newHeight = maxHeight;

      if (aspectRatio > 1) {
        // Landscape
        newHeight = maxWidth / aspectRatio;
      } else {
        // Portrait
        newWidth = maxHeight * aspectRatio;
      }

      manipulations.push({
        resize: {
          width: Math.round(newWidth),
          height: Math.round(newHeight),
        },
      });
    }

    // Adjust quality based on image size
    let adjustedQuality = quality;
    const imageSize = width * height;

    if (imageSize > 4000000) { // > 4MP
      adjustedQuality = Math.min(quality, 0.7);
    } else if (imageSize > 2000000) { // > 2MP
      adjustedQuality = Math.min(quality, 0.8);
    }

    return {
      manipulations,
      quality: adjustedQuality,
    };
  }

  private async generateThumbnail(uri: string): Promise<string> {
    const result = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: 150, height: 150 } }],
      {
        compress: 0.5,
        format: ImageManipulator.SaveFormat.JPEG,
      }
    );

    return result.uri;
  }

  private async extractMetadata(uri: string): Promise<any> {
    try {
      // This would use a library like react-native-image-picker
      // or expo-media-library to extract EXIF data
      return {};
    } catch (error) {
      console.warn('Failed to extract image metadata:', error);
      return {};
    }
  }

  // Batch compression for multiple images
  async compressImages(
    uris: string[],
    options: Partial<CompressionOptions> = {}
  ): Promise<CompressionResult[]> {
    const compressionPromises = uris.map(uri => this.compressImage(uri, options));
    return Promise.all(compressionPromises);
  }

  // Get compression statistics
  getCompressionStats(results: CompressionResult[]): {
    totalOriginalSize: number;
    totalCompressedSize: number;
    averageCompressionRatio: number;
    totalSavings: number;
  } {
    const totalOriginalSize = results.reduce((sum, r) => sum + r.originalSize, 0);
    const totalCompressedSize = results.reduce((sum, r) => sum + r.fileSize, 0);
    const averageCompressionRatio = results.reduce((sum, r) => sum + r.compressionRatio, 0) / results.length;
    const totalSavings = totalOriginalSize - totalCompressedSize;

    return {
      totalOriginalSize,
      totalCompressedSize,
      averageCompressionRatio,
      totalSavings,
    };
  }
}
```

### Network-Aware Upload Strategy

```typescript
import NetInfo from '@react-native-community/netinfo';

export enum UploadStrategy {
  SINGLE = 'single',
  BATCH = 'batch',
  PROGRESSIVE = 'progressive',
  ADAPTIVE = 'adaptive',
}

export interface UploadConfig {
  strategy: UploadStrategy;
  batchSize: number;
  chunkSize: number;
  maxConcurrentUploads: number;
  retryAttempts: number;
  compressionOptions: Partial<CompressionOptions>;
}

export class NetworkAwareUploadService {
  private static instance: NetworkAwareUploadService;
  private currentConfig: UploadConfig;
  private networkState: any = null;

  static getInstance(): NetworkAwareUploadService {
    if (!NetworkAwareUploadService.instance) {
      NetworkAwareUploadService.instance = new NetworkAwareUploadService();
    }
    return NetworkAwareUploadService.instance;
  }

  constructor() {
    this.currentConfig = this.getDefaultConfig();
    this.initializeNetworkMonitoring();
  }

  private getDefaultConfig(): UploadConfig {
    return {
      strategy: UploadStrategy.ADAPTIVE,
      batchSize: 5,
      chunkSize: 1024 * 1024, // 1MB chunks
      maxConcurrentUploads: 3,
      retryAttempts: 3,
      compressionOptions: {
        maxWidth: 2048,
        maxHeight: 2048,
        quality: 0.8,
        format: 'jpeg',
        generateThumbnail: true,
      },
    };
  }

  private initializeNetworkMonitoring(): void {
    NetInfo.addEventListener(state => {
      this.networkState = state;
      this.updateConfigForNetwork(state);
    });
  }

  private updateConfigForNetwork(networkState: any): void {
    const { type, effectiveType } = networkState;

    if (!networkState.isConnected) {
      // No network - uploads will be queued
      return;
    }

    // Adjust configuration based on network type
    if (effectiveType === 'slow-2g' || effectiveType === '2g') {
      this.currentConfig = {
        ...this.currentConfig,
        strategy: UploadStrategy.SINGLE,
        batchSize: 1,
        chunkSize: 512 * 1024, // 512KB chunks
        maxConcurrentUploads: 1,
        compressionOptions: {
          ...this.currentConfig.compressionOptions,
          maxWidth: 1024,
          maxHeight: 1024,
          quality: 0.6,
        },
      };
    } else if (effectiveType === '3g') {
      this.currentConfig = {
        ...this.currentConfig,
        strategy: UploadStrategy.BATCH,
        batchSize: 3,
        chunkSize: 1024 * 1024, // 1MB chunks
        maxConcurrentUploads: 2,
        compressionOptions: {
          ...this.currentConfig.compressionOptions,
          maxWidth: 1536,
          maxHeight: 1536,
          quality: 0.7,
        },
      };
    } else if (effectiveType === '4g' || type === 'wifi') {
      this.currentConfig = {
        ...this.currentConfig,
        strategy: UploadStrategy.PROGRESSIVE,
        batchSize: 5,
        chunkSize: 2 * 1024 * 1024, // 2MB chunks
        maxConcurrentUploads: 3,
        compressionOptions: {
          ...this.currentConfig.compressionOptions,
          maxWidth: 2048,
          maxHeight: 2048,
          quality: 0.8,
        },
      };
    }
  }

  getCurrentConfig(): UploadConfig {
    return { ...this.currentConfig };
  }

  getNetworkQuality(): 'poor' | 'moderate' | 'good' | 'excellent' {
    if (!this.networkState?.isConnected) return 'poor';

    const { effectiveType, type } = this.networkState;

    if (effectiveType === 'slow-2g' || effectiveType === '2g') return 'poor';
    if (effectiveType === '3g') return 'moderate';
    if (effectiveType === '4g') return 'good';
    if (type === 'wifi') return 'excellent';

    return 'moderate';
  }

  estimateUploadTime(fileSizeBytes: number): number {
    const networkQuality = this.getNetworkQuality();

    // Estimated speeds in bytes per second
    const speeds = {
      poor: 25000,      // ~25KB/s
      moderate: 375000,  // ~375KB/s
      good: 1500000,    // ~1.5MB/s
      excellent: 5000000, // ~5MB/s
    };

    const speed = speeds[networkQuality];
    return Math.ceil(fileSizeBytes / speed); // Time in seconds
  }
}
```

## Progressive Upload Implementation

### Chunked Upload Service

```typescript
export interface UploadProgress {
  uploadId: string;
  totalSize: number;
  uploadedSize: number;
  percentage: number;
  currentChunk: number;
  totalChunks: number;
  speed: number; // bytes per second
  estimatedTimeRemaining: number; // seconds
  status: 'uploading' | 'paused' | 'completed' | 'failed';
}

export class ProgressiveUploadService {
  private static instance: ProgressiveUploadService;
  private activeUploads: Map<string, UploadProgress> = new Map();
  private progressListeners: Map<string, Set<(progress: UploadProgress) => void>> = new Map();

  static getInstance(): ProgressiveUploadService {
    if (!ProgressiveUploadService.instance) {
      ProgressiveUploadService.instance = new ProgressiveUploadService();
    }
    return ProgressiveUploadService.instance;
  }

  async uploadFile(
    uri: string,
    uploadUrl: string,
    options: {
      chunkSize?: number;
      metadata?: any;
      onProgress?: (progress: UploadProgress) => void;
    } = {}
  ): Promise<string> {
    const uploadId = `upload_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const chunkSize = options.chunkSize || 1024 * 1024; // 1MB default

    try {
      // Get file info
      const fileInfo = await FileSystem.getInfoAsync(uri);
      const fileSize = fileInfo.size || 0;
      const totalChunks = Math.ceil(fileSize / chunkSize);

      // Initialize progress tracking
      const progress: UploadProgress = {
        uploadId,
        totalSize: fileSize,
        uploadedSize: 0,
        percentage: 0,
        currentChunk: 0,
        totalChunks,
        speed: 0,
        estimatedTimeRemaining: 0,
        status: 'uploading',
      };

      this.activeUploads.set(uploadId, progress);

      if (options.onProgress) {
        this.subscribeToProgress(uploadId, options.onProgress);
      }

      // Initialize multipart upload
      const uploadSession = await this.initializeUpload(uploadUrl, {
        fileName: uri.split('/').pop() || 'file',
        fileSize,
        chunkSize,
        totalChunks,
        metadata: options.metadata,
      });

      // Upload chunks
      const startTime = Date.now();
      for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
        const start = chunkIndex * chunkSize;
        const end = Math.min(start + chunkSize, fileSize);
        const chunkSize_actual = end - start;

        // Read chunk data
        const chunkData = await this.readFileChunk(uri, start, chunkSize_actual);

        // Upload chunk
        await this.uploadChunk(uploadSession.uploadId, chunkIndex, chunkData);

        // Update progress
        const currentTime = Date.now();
        const elapsedTime = (currentTime - startTime) / 1000;
        const uploadedSize = (chunkIndex + 1) * chunkSize;
        const speed = uploadedSize / elapsedTime;
        const remainingSize = fileSize - uploadedSize;
        const estimatedTimeRemaining = remainingSize / speed;

        progress.uploadedSize = Math.min(uploadedSize, fileSize);
        progress.percentage = (progress.uploadedSize / fileSize) * 100;
        progress.currentChunk = chunkIndex + 1;
        progress.speed = speed;
        progress.estimatedTimeRemaining = estimatedTimeRemaining;

        this.updateProgress(uploadId, progress);
      }

      // Complete upload
      const result = await this.completeUpload(uploadSession.uploadId);

      progress.status = 'completed';
      progress.percentage = 100;
      this.updateProgress(uploadId, progress);

      return result.fileUrl;
    } catch (error) {
      const progress = this.activeUploads.get(uploadId);
      if (progress) {
        progress.status = 'failed';
        this.updateProgress(uploadId, progress);
      }
      throw error;
    } finally {
      // Clean up after a delay
      setTimeout(() => {
        this.activeUploads.delete(uploadId);
        this.progressListeners.delete(uploadId);
      }, 30000);
    }
  }

  private async initializeUpload(
    uploadUrl: string,
    fileInfo: any
  ): Promise<{ uploadId: string; uploadUrls: string[] }> {
    const response = await fetch(`${uploadUrl}/initialize`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(fileInfo),
    });

    if (!response.ok) {
      throw new Error(`Failed to initialize upload: ${response.statusText}`);
    }

    return response.json();
  }

  private async readFileChunk(
    uri: string,
    start: number,
    size: number
  ): Promise<ArrayBuffer> {
    // This would use a native module to read file chunks
    // For now, we'll simulate with a placeholder
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
      position: start,
      length: size,
    });

    return this.base64ToArrayBuffer(base64);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }

  private async uploadChunk(
    uploadId: string,
    chunkIndex: number,
    chunkData: ArrayBuffer
  ): Promise<void> {
    const response = await fetch(`/api/upload/${uploadId}/chunk/${chunkIndex}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Length': chunkData.byteLength.toString(),
      },
      body: chunkData,
    });

    if (!response.ok) {
      throw new Error(`Failed to upload chunk ${chunkIndex}: ${response.statusText}`);
    }
  }

  private async completeUpload(uploadId: string): Promise<{ fileUrl: string }> {
    const response = await fetch(`/api/upload/${uploadId}/complete`, {
      method: 'POST',
    });

    if (!response.ok) {
      throw new Error(`Failed to complete upload: ${response.statusText}`);
    }

    return response.json();
  }

  // Progress tracking methods
  subscribeToProgress(
    uploadId: string,
    callback: (progress: UploadProgress) => void
  ): () => void {
    if (!this.progressListeners.has(uploadId)) {
      this.progressListeners.set(uploadId, new Set());
    }

    this.progressListeners.get(uploadId)!.add(callback);

    return () => {
      this.progressListeners.get(uploadId)?.delete(callback);
    };
  }

  private updateProgress(uploadId: string, progress: UploadProgress): void {
    this.activeUploads.set(uploadId, progress);

    const listeners = this.progressListeners.get(uploadId);
    if (listeners) {
      listeners.forEach(callback => callback(progress));
    }
  }

  getActiveUploads(): UploadProgress[] {
    return Array.from(this.activeUploads.values());
  }

  pauseUpload(uploadId: string): void {
    const progress = this.activeUploads.get(uploadId);
    if (progress) {
      progress.status = 'paused';
      this.updateProgress(uploadId, progress);
    }
  }

  resumeUpload(uploadId: string): void {
    const progress = this.activeUploads.get(uploadId);
    if (progress) {
      progress.status = 'uploading';
      this.updateProgress(uploadId, progress);
    }
  }

  cancelUpload(uploadId: string): void {
    const progress = this.activeUploads.get(uploadId);
    if (progress) {
      progress.status = 'failed';
      this.updateProgress(uploadId, progress);
    }

    this.activeUploads.delete(uploadId);
    this.progressListeners.delete(uploadId);
  }
}
```

## Survey Upload Orchestrator

### Complete Survey Upload Service

```typescript
export interface SurveyUploadData {
  surveyId: string;
  roomId: number;
  images: string[];
  attributes: Record<string, any>;
  metadata: {
    timestamp: number;
    userId: string;
    deviceInfo: any;
  };
}

export interface SurveyUploadResult {
  success: boolean;
  surveyId: string;
  uploadedImages: string[];
  errors: string[];
  totalTime: number;
  compressionStats: any;
}

export class SurveyUploadOrchestrator {
  private static instance: SurveyUploadOrchestrator;
  private compressionService: ImageCompressionService;
  private networkService: NetworkAwareUploadService;
  private progressiveService: ProgressiveUploadService;
  private syncQueue: AdvancedSyncQueue;

  static getInstance(): SurveyUploadOrchestrator {
    if (!SurveyUploadOrchestrator.instance) {
      SurveyUploadOrchestrator.instance = new SurveyUploadOrchestrator();
    }
    return SurveyUploadOrchestrator.instance;
  }

  constructor() {
    this.compressionService = ImageCompressionService.getInstance();
    this.networkService = NetworkAwareUploadService.getInstance();
    this.progressiveService = ProgressiveUploadService.getInstance();
    this.syncQueue = new AdvancedSyncQueue();
  }

  async uploadSurvey(
    surveyData: SurveyUploadData,
    options: {
      onProgress?: (progress: SurveyUploadProgress) => void;
      immediate?: boolean;
    } = {}
  ): Promise<SurveyUploadResult> {
    const startTime = Date.now();
    const uploadId = `survey_${surveyData.surveyId}_${Date.now()}`;

    try {
      // Check network connectivity
      const networkQuality = this.networkService.getNetworkQuality();

      if (networkQuality === 'poor' && !options.immediate) {
        // Queue for later upload
        await this.queueForLaterUpload(surveyData);
        return {
          success: false,
          surveyId: surveyData.surveyId,
          uploadedImages: [],
          errors: ['Queued for upload when network improves'],
          totalTime: Date.now() - startTime,
          compressionStats: null,
        };
      }

      // Initialize progress tracking
      const progress: SurveyUploadProgress = {
        surveyId: surveyData.surveyId,
        phase: 'compression',
        totalImages: surveyData.images.length,
        processedImages: 0,
        uploadedImages: 0,
        compressionProgress: 0,
        uploadProgress: 0,
        overallProgress: 0,
        currentOperation: 'Starting compression...',
        estimatedTimeRemaining: 0,
      };

      options.onProgress?.(progress);

      // Phase 1: Compress images
      const compressionResults = await this.compressImages(
        surveyData.images,
        (compressionProgress) => {
          progress.phase = 'compression';
          progress.compressionProgress = compressionProgress;
          progress.overallProgress = compressionProgress * 0.3; // 30% of total
          progress.currentOperation = `Compressing images... ${compressionProgress.toFixed(1)}%`;
          options.onProgress?.(progress);
        }
      );

      // Phase 2: Upload images
      progress.phase = 'upload';
      progress.currentOperation = 'Uploading images...';
      options.onProgress?.(progress);

      const uploadedImages = await this.uploadImages(
        compressionResults,
        (uploadProgress) => {
          progress.uploadProgress = uploadProgress;
          progress.overallProgress = 30 + (uploadProgress * 0.6); // 60% of total
          progress.uploadedImages = Math.floor((uploadProgress / 100) * surveyData.images.length);
          progress.currentOperation = `Uploading images... ${uploadProgress.toFixed(1)}%`;
          options.onProgress?.(progress);
        }
      );

      // Phase 3: Upload survey data
      progress.phase = 'survey';
      progress.currentOperation = 'Uploading survey data...';
      progress.overallProgress = 90;
      options.onProgress?.(progress);

      const surveyResult = await this.uploadSurveyData({
        ...surveyData,
        images: uploadedImages,
      });

      // Complete
      progress.phase = 'complete';
      progress.overallProgress = 100;
      progress.currentOperation = 'Upload complete!';
      options.onProgress?.(progress);

      const compressionStats = this.compressionService.getCompressionStats(compressionResults);

      return {
        success: true,
        surveyId: surveyData.surveyId,
        uploadedImages,
        errors: [],
        totalTime: Date.now() - startTime,
        compressionStats,
      };

    } catch (error) {
      console.error('Survey upload failed:', error);

      // Queue for retry
      await this.queueForRetry(surveyData, error);

      return {
        success: false,
        surveyId: surveyData.surveyId,
        uploadedImages: [],
        errors: [error.message],
        totalTime: Date.now() - startTime,
        compressionStats: null,
      };
    }
  }

  private async compressImages(
    imageUris: string[],
    onProgress: (progress: number) => void
  ): Promise<CompressionResult[]> {
    const config = this.networkService.getCurrentConfig();
    const results: CompressionResult[] = [];

    for (let i = 0; i < imageUris.length; i++) {
      const uri = imageUris[i];
      const result = await this.compressionService.compressImage(uri, config.compressionOptions);
      results.push(result);

      const progress = ((i + 1) / imageUris.length) * 100;
      onProgress(progress);
    }

    return results;
  }

  private async uploadImages(
    compressionResults: CompressionResult[],
    onProgress: (progress: number) => void
  ): Promise<string[]> {
    const config = this.networkService.getCurrentConfig();
    const uploadedUrls: string[] = [];

    if (config.strategy === UploadStrategy.PROGRESSIVE) {
      return this.uploadImagesProgressively(compressionResults, onProgress);
    } else {
      return this.uploadImagesBatch(compressionResults, onProgress);
    }
  }

  private async uploadImagesProgressively(
    compressionResults: CompressionResult[],
    onProgress: (progress: number) => void
  ): Promise<string[]> {
    const uploadedUrls: string[] = [];

    for (let i = 0; i < compressionResults.length; i++) {
      const result = compressionResults[i];

      const uploadUrl = await this.progressiveService.uploadFile(
        result.uri,
        '/api/upload/progressive',
        {
          onProgress: (uploadProgress) => {
            const totalProgress = ((i + uploadProgress.percentage / 100) / compressionResults.length) * 100;
            onProgress(totalProgress);
          },
          metadata: {
            surveyId: result.metadata?.surveyId,
            compression: {
              originalSize: result.originalSize,
              compressedSize: result.fileSize,
              ratio: result.compressionRatio,
            },
          },
        }
      );

      uploadedUrls.push(uploadUrl);
    }

    return uploadedUrls;
  }

  private async uploadImagesBatch(
    compressionResults: CompressionResult[],
    onProgress: (progress: number) => void
  ): Promise<string[]> {
    const config = this.networkService.getCurrentConfig();
    const uploadedUrls: string[] = [];
    const batchSize = config.batchSize;

    for (let i = 0; i < compressionResults.length; i += batchSize) {
      const batch = compressionResults.slice(i, i + batchSize);

      const batchPromises = batch.map(result => this.uploadSingleImage(result));
      const batchResults = await Promise.all(batchPromises);

      uploadedUrls.push(...batchResults);

      const progress = ((i + batch.length) / compressionResults.length) * 100;
      onProgress(progress);
    }

    return uploadedUrls;
  }

  private async uploadSingleImage(compressionResult: CompressionResult): Promise<string> {
    const formData = new FormData();
    formData.append('image', {
      uri: compressionResult.uri,
      type: 'image/jpeg',
      name: 'survey_image.jpg',
    } as any);

    const response = await fetch('/api/upload/image', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Image upload failed: ${response.statusText}`);
    }

    const result = await response.json();
    return result.url;
  }

  private async uploadSurveyData(surveyData: SurveyUploadData): Promise<void> {
    const response = await fetch('/api/surveys', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(surveyData),
    });

    if (!response.ok) {
      throw new Error(`Survey upload failed: ${response.statusText}`);
    }
  }

  private async queueForLaterUpload(surveyData: SurveyUploadData): Promise<void> {
    await this.syncQueue.addOperation({
      type: 'survey',
      priority: SyncPriority.HIGH,
      status: SyncStatus.PENDING,
      payload: surveyData,
      metadata: {
        userId: surveyData.metadata.userId,
        timestamp: Date.now(),
        retryCount: 0,
        maxRetries: 3,
      },
    });
  }

  private async queueForRetry(surveyData: SurveyUploadData, error: any): Promise<void> {
    await this.syncQueue.addOperation({
      type: 'survey',
      priority: SyncPriority.NORMAL,
      status: SyncStatus.PENDING,
      payload: surveyData,
      metadata: {
        userId: surveyData.metadata.userId,
        timestamp: Date.now(),
        retryCount: 0,
        maxRetries: 5,
        lastError: error.message,
      },
    });
  }
}

export interface SurveyUploadProgress {
  surveyId: string;
  phase: 'compression' | 'upload' | 'survey' | 'complete';
  totalImages: number;
  processedImages: number;
  uploadedImages: number;
  compressionProgress: number;
  uploadProgress: number;
  overallProgress: number;
  currentOperation: string;
  estimatedTimeRemaining: number;
}
```

## Upload Progress UI Components

### Upload Progress Indicator

```typescript
import React from 'react';
import { View, Text, StyleSheet, ProgressBarAndroid, ProgressViewIOS, Platform } from 'react-native';

const ProgressBar = Platform.OS === 'ios' ? ProgressViewIOS : ProgressBarAndroid;

interface UploadProgressIndicatorProps {
  progress: SurveyUploadProgress;
  visible: boolean;
}

export const UploadProgressIndicator: React.FC<UploadProgressIndicatorProps> = ({
  progress,
  visible,
}) => {
  if (!visible) return null;

  const getPhaseColor = (phase: string) => {
    switch (phase) {
      case 'compression': return '#FF9800';
      case 'upload': return '#2196F3';
      case 'survey': return '#4CAF50';
      case 'complete': return '#4CAF50';
      default: return '#757575';
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Uploading Survey</Text>
        <Text style={styles.phase}>{progress.phase.toUpperCase()}</Text>
      </View>

      <View style={styles.progressContainer}>
        <ProgressBar
          progress={progress.overallProgress / 100}
          color={getPhaseColor(progress.phase)}
          style={styles.progressBar}
        />
        <Text style={styles.progressText}>
          {progress.overallProgress.toFixed(1)}%
        </Text>
      </View>

      <Text style={styles.operation}>{progress.currentOperation}</Text>

      <View style={styles.stats}>
        <Text style={styles.statText}>
          Images: {progress.uploadedImages} / {progress.totalImages}
        </Text>
        {progress.estimatedTimeRemaining > 0 && (
          <Text style={styles.statText}>
            ETA: {Math.ceil(progress.estimatedTimeRemaining)}s
          </Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 8,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  phase: {
    fontSize: 12,
    color: '#666',
    fontWeight: 'bold',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressBar: {
    flex: 1,
    height: 4,
    marginRight: 12,
  },
  progressText: {
    fontSize: 14,
    fontWeight: 'bold',
    minWidth: 45,
    textAlign: 'right',
  },
  operation: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statText: {
    fontSize: 12,
    color: '#999',
  },
});
```

## Testing Survey Upload Patterns

### Upload Testing Utilities

```typescript
export class SurveyUploadTestUtils {
  static createMockSurveyData(): SurveyUploadData {
    return {
      surveyId: 'test-survey-1',
      roomId: 123,
      images: [
        'file:///path/to/image1.jpg',
        'file:///path/to/image2.jpg',
        'file:///path/to/image3.jpg',
      ],
      attributes: {
        room_type: 'office',
        capacity: 10,
        area: 150,
      },
      metadata: {
        timestamp: Date.now(),
        userId: 'test-user',
        deviceInfo: {
          platform: 'ios',
          version: '14.0',
        },
      },
    };
  }

  static async testImageCompression(): Promise<void> {
    const service = ImageCompressionService.getInstance();

    const mockUri = 'file:///path/to/test-image.jpg';
    const result = await service.compressImage(mockUri, {
      maxWidth: 1024,
      maxHeight: 1024,
      quality: 0.8,
    });

    expect(result.uri).toBeDefined();
    expect(result.compressionRatio).toBeLessThan(1);
    expect(result.fileSize).toBeLessThan(result.originalSize);
  }

  static async testProgressiveUpload(): Promise<void> {
    const service = ProgressiveUploadService.getInstance();

    const mockUri = 'file:///path/to/test-file.jpg';
    const progressUpdates: UploadProgress[] = [];

    const result = await service.uploadFile(mockUri, '/api/upload/test', {
      onProgress: (progress) => {
        progressUpdates.push(progress);
      },
    });

    expect(result).toBeDefined();
    expect(progressUpdates).toHaveLength.greaterThan(0);
    expect(progressUpdates[progressUpdates.length - 1].percentage).toBe(100);
  }

  static async testSurveyUploadOrchestration(): Promise<void> {
    const orchestrator = SurveyUploadOrchestrator.getInstance();
    const mockData = this.createMockSurveyData();

    const progressUpdates: SurveyUploadProgress[] = [];

    const result = await orchestrator.uploadSurvey(mockData, {
      onProgress: (progress) => {
        progressUpdates.push(progress);
      },
    });

    expect(result.success).toBe(true);
    expect(result.uploadedImages).toHaveLength(mockData.images.length);
    expect(progressUpdates).toHaveLength.greaterThan(0);
    expect(progressUpdates[progressUpdates.length - 1].overallProgress).toBe(100);
  }
}
```

## Related Documentation
- [Mobile Authentication Patterns](./authentication-patterns.md) - Secure authentication for upload operations
- [Mobile Offline Sync Patterns](./offline-sync-patterns.md) - Offline queue and sync strategies
- [Mobile Offline-First Patterns](./offline-first-patterns.md) - UX patterns for offline scenarios
- [Mobile Development Patterns](./development-patterns.md) - Core React Native patterns and best practices

---
**Status**: ✅ Current
**Last Updated**: 2025-07-09
**Technology Stack**: React Native, TypeScript, Expo, FileSystem, ImageManipulator, NetInfo
