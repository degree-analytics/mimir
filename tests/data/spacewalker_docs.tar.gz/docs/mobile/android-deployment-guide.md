# Android Deployment Guide

**Last Updated:** 2025-07-08  
**Configuration Version:** 2.0  
**Status:** ✅ Production Ready with CI/CD Automation

## Overview

This guide covers the complete Android deployment process for Spacewalker, from initial Google Play Console setup through automated CI/CD distribution. The system now features fully automated builds and submissions through GitHub Actions, with safety features like staged rollouts and draft submissions.

## 🚀 Quick Start

If you just need to deploy quickly:

```bash
# 1. Build production Android app
just android_build_prod

# 2. Submit to Google Play Store
just android_submit_playstore production

# 3. Check submission status
just android_release_status
```

For full setup and CI/CD automation, continue reading.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Google Play Console Setup](#google-play-console-setup)
- [Android Signing Configuration](#android-signing-configuration)
- [EAS Build Configuration](#eas-build-configuration)
- [CI/CD Pipeline Setup](#cicd-pipeline-setup)
- [Manual Deployment Commands](#manual-deployment-commands)
- [Automated Deployment Workflow](#automated-deployment-workflow)
- [Troubleshooting](#troubleshooting)
- [Security Considerations](#security-considerations)

## Prerequisites

### Required Accounts and Tools
- Google Play Console Developer Account ($25 one-time fee)
- Google Cloud Console account (for service account creation)
- EAS CLI installed: `npm install -g eas-cli`
- Java 8+ (for keystore generation)

### Repository Setup
```bash
# Ensure you're in the project root
cd spacewalker

# Install dependencies
just service install all

# Verify mobile setup
cd apps/mobile && npm run validate:eas
```

## Google Play Console Setup

### 1. Create App Listing

1. **Access Google Play Console**
   - Go to [Google Play Console](https://play.google.com/console)
   - Sign in with your developer account

2. **Create New App**
   - Click "Create app"
   - App name: `Spacewalker`
   - Default language: English (US)
   - App or game: App
   - Free or paid: Free (or as appropriate)

3. **Configure App Details**
   ```
   Category: Business
   Content rating: Complete questionnaire (typically Everyone)
   Target audience: 13+ (adjust as needed)
   ```

### 2. Store Listing Requirements

#### App Information
- **Short description (80 chars):** "Professional workspace management and analytics platform"
- **Full description (4000 chars):** Comprehensive app description
- **App icon:** 512x512 PNG (apps/mobile/assets/icon.png)
- **Feature graphic:** 1024x500 PNG

#### Screenshots (Required)
- **Phone:** Minimum 2 screenshots (1080x1920 or 1080x2340)
- **7-inch tablet:** Minimum 1 screenshot (1200x1920)
- **10-inch tablet:** Minimum 1 screenshot (1920x1200)

#### Additional Information
- **Developer contact:** Your email address
- **Privacy policy URL:** https://spacewalker.com/privacy
- **App category:** Business
- **Content rating:** Complete questionnaire

### 3. App Content and Compliance
- Complete the content rating questionnaire
- Add privacy policy URL
- Complete target audience settings
- Set up app access (if authentication required)

## Android Signing Configuration

### 1. Generate Upload Keystore

```bash
# Create keystore directory
mkdir -p apps/mobile/android

# Generate upload keystore (do this ONCE and store securely)
keytool -genkeypair -v \
  -keystore apps/mobile/android/upload-keystore.jks \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias upload \
  -storetype JKS

# You'll be prompted for:
# - Keystore password (store securely!)
# - Key password (can be same as keystore password)
# - Distinguished name information
```

**⚠️ CRITICAL:** Store keystore password securely - if lost, you cannot update your app!

### 2. Configure EAS Credentials

```bash
cd apps/mobile

# Configure EAS credentials
eas credentials:configure --platform android

# Select options:
# 1. "Use existing keystore"
# 2. Provide path to upload-keystore.jks
# 3. Enter keystore password and alias
```

### 3. Enable Google Play App Signing

1. In Google Play Console, go to: **Release > Setup > App integrity**
2. Under "App signing," click **"Choose signing key"**
3. Select **"Use Google-generated key"** (recommended)
4. Google will manage the app signing key for you

## EAS Build Configuration

The EAS configuration is already optimized in `apps/mobile/eas.json`:

### Build Profiles
- **Development:** Local APK builds for testing
- **Preview:** Internal testing builds (AAB format)
- **Production:** Production builds with staged rollouts

### Submit Configuration
- **Preview track:** `internal` (auto-publish to internal testers)
- **Production track:** `production` (draft submissions, 20% rollout)

### Automatic Features
- ✅ **Auto-increment version codes** - prevents "version already exists" errors
- ✅ **App Bundle (AAB) format** - required by Google Play Store
- ✅ **Staged rollouts** - production releases start at 20%
- ✅ **Draft submissions** - manual review required for production

### Verify Configuration
```bash
cd apps/mobile

# Validate EAS configuration
npm run validate:eas

# Test submission configuration
npm run test:submission
```

## CI/CD Pipeline Setup

### 1. GitHub Secrets Configuration

Add these secrets to your GitHub repository (**Settings > Secrets and variables > Actions**):

#### Required Secrets
```
EXPO_TOKEN=your_expo_access_token
```

To get your EXPO_TOKEN:
```bash
# Login to Expo
npx expo login

# Get access token
npx expo whoami
# Follow the instructions to generate a token
```

### 2. Service Account Setup (For Automated Submissions)

This enables fully automated Android submissions via CI/CD:

#### 2.1 Create Service Account in Google Cloud Console

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Select your project or create one
3. Navigate to **IAM & Admin > Service Accounts**
4. Click **"Create Service Account"**
   - Name: `spacewalker-play-store-api`
   - Description: "Service account for Spacewalker Play Store submissions"
   - No additional roles needed at Google Cloud level

#### 2.2 Generate Service Account Key

1. Click on the created service account
2. Go to **"Keys"** tab
3. Click **"Add Key" > "Create new key"**
4. Choose **JSON format**
5. Download the key file

#### 2.3 Add Permissions in Google Play Console

1. Go to [Google Play Console](https://play.google.com/console)
2. Navigate to: **Users and permissions**
3. Click **"Invite new users"**
4. Enter the service account email (ends with @your-project.iam.gserviceaccount.com)
5. Grant permissions:
   - **App permissions:** Select Spacewalker app
   - **Account permissions:** 
     - Release apps to testing tracks: ✅
     - Release apps to production: ✅

#### 2.4 Store Service Account Key

```bash
# Copy the downloaded JSON key to the mobile directory
cp ~/Downloads/service-account-key.json apps/mobile/android/

# Verify the file is properly ignored by git
git status  # should not show the service account key

# The file should be in .gitignore already
rg "service-account-key.json" apps/mobile/.gitignore
```

### 3. CI/CD Workflow Features

The GitHub Actions workflow (`.github/workflows/eas-build.yml`) now includes:

#### Automatic Triggers
- **Pull Requests:** Development builds (no submission)
- **Push to `dev` branch:** Preview builds → internal testing track
- **Push to `main` branch:** Production builds → production track (draft)
- **Manual trigger:** Any profile, any platform via GitHub UI

#### Android-Specific Features
- **Build completion waiting** - waits for EAS build to complete before submission
- **Service account validation** - checks for required credentials
- **Automatic submission** - submits to appropriate Play Store track
- **Status reporting** - updates PR comments and commit status
- **Error handling** - graceful failures with helpful messages

#### Submission Logic
```yaml
# Preview builds (dev branch) → internal track
Profile: preview
Track: internal
Release Status: completed (auto-publish)

# Production builds (main branch) → production track  
Profile: production
Track: production
Release Status: draft (manual review required)
Rollout: 20% (staged rollout)
```

## Manual Deployment Commands

The justfile now includes comprehensive Android deployment commands:

### Build Commands
```bash
# Build for different profiles
just android_build_prod                    # Production build
cd apps/mobile && eas build --profile preview       # Preview build
cd apps/mobile && eas build --profile development   # Development build
```

### Submission Commands
```bash
# Submit to Play Store
just android_submit_playstore production   # Submit to production track
just android_submit_playstore preview      # Submit to internal track

# Check submission status
just android_release_status                # View recent builds and submissions
```

### Release Management
```bash
# Generate release notes from git commits
just android_generate_release_notes        # From last tag
just android_generate_release_notes v1.0.0 # From specific tag

# Validate configuration
just android_validate_config               # Run validation tests
```

### Track Promotion
```bash
# Get manual promotion instructions
just android_promote_track internal production 0.1
# This provides step-by-step instructions for Google Play Console
```

## Automated Deployment Workflow

### 1. Development Cycle

```bash
# 1. Make changes to mobile app
cd apps/mobile
# ... make your changes ...

# 2. Test locally
just mobile_dev

# 3. Create pull request
git checkout -b feature/my-feature
git add . && git commit -m "feat: add new feature"
git push origin feature/my-feature
# Create PR on GitHub

# 4. CI automatically builds development version for testing
# No submission occurs for PRs
```

### 2. Internal Testing (Preview Track)

```bash
# 1. Merge to dev branch triggers preview build
git checkout dev
git merge feature/my-feature
git push origin dev

# 2. GitHub Actions automatically:
#    - Builds with preview profile
#    - Submits to internal track in Google Play
#    - Notifies team of completion

# 3. Internal testers get automatic notification
# 4. Test the build via Google Play internal testing
```

### 3. Production Release

```bash
# 1. Merge to main branch triggers production build
git checkout main
git merge dev
git push origin main

# 2. GitHub Actions automatically:
#    - Builds with production profile
#    - Submits to production track as DRAFT
#    - Sets 20% rollout percentage
#    - Requires manual promotion in Google Play Console

# 3. Manual steps in Google Play Console:
#    - Review the draft release
#    - Update release notes if needed
#    - Promote to production
#    - Monitor crash reports and reviews
#    - Gradually increase rollout (50%, 100%)
```

### 4. Emergency Procedures

```bash
# Halt a rollout (if issues detected)
# 1. Go to Google Play Console
# 2. Find the release in Production track
# 3. Click "Halt rollout"
# 4. Fix issues and create new release

# Manual rollback
# 1. Previous version automatically becomes available for rollback
# 2. Use Google Play Console to activate previous release
```

## Troubleshooting

### CI/CD Pipeline Issues

#### ❌ "EXPO_TOKEN not configured"
**Solution:** Add EXPO_TOKEN to GitHub repository secrets
```bash
# Get token
npx expo whoami

# Add to GitHub: Settings > Secrets > Actions > EXPO_TOKEN
```

#### ❌ "Service account authentication failed"
**Cause:** Service account key missing or incorrect permissions
**Solution:**
1. Verify file exists: `apps/mobile/android/service-account-key.json`
2. Check Google Play Console permissions for service account
3. Ensure service account has "Release apps" permissions

#### ❌ "Build timeout after 30 minutes"
**Cause:** EAS build is taking longer than expected
**Solution:**
- Check EAS dashboard for build status
- Builds will be submitted when they complete
- Consider increasing timeout in workflow if consistently needed

### Build Issues

#### ❌ "Version already exists" Error
**Solution:** Auto-increment is enabled - this shouldn't happen
```bash
# If it does occur, check eas.json configuration
cd apps/mobile && npm run validate:eas
```

#### ❌ "Signing key mismatch" Error
**Cause:** Upload keystore has changed or is incorrect
**Solution:**
```bash
# Re-configure EAS credentials
cd apps/mobile
eas credentials:configure --platform android
```

#### ❌ "Track not found" Error
**Cause:** App doesn't exist in Google Play Console or track is incorrect
**Solution:**
1. Verify app exists in Google Play Console
2. Check track names in `eas.json` (internal, production)
3. Ensure app has been submitted to the track at least once manually

### Google Play Console Issues

#### Release Stuck in "Pending Publication"
- Check for policy violations in Google Play Console
- Ensure content rating is complete
- Verify target audience settings
- Review app content compliance

#### "App not available in your country"
- Check distribution settings in Google Play Console
- Verify target countries are selected
- Ensure pricing is set correctly

### Debugging Commands

```bash
# Check EAS credentials
cd apps/mobile && eas credentials --platform android

# View recent builds
eas build:list --platform android --limit=5

# Get detailed build info
eas build:view BUILD_ID

# Check submission history
eas submit:list --platform android

# Test configuration
npm run validate:eas
npm run test:submission

# Check CI/CD status
just mobile_ci_status
```

## Security Considerations

### Keystore Security
- **Never commit keystores to git** (protected by .gitignore)
- Store keystore password in secure password manager
- Keep backup of keystore in secure location
- Use Google Play App Signing for additional security

### Service Account Security
- **Never commit service account keys** (protected by .gitignore)
- Use least-privilege permissions in Google Play Console
- Rotate service account keys annually
- Monitor API usage for suspicious activity

### CI/CD Security
- Store sensitive secrets in GitHub Secrets (encrypted)
- Use EXPO_TOKEN instead of username/password
- Enable branch protection rules for main/dev branches
- Review GitHub Actions logs for sensitive data exposure
- Service account keys are only accessible during CI/CD execution

### Build Security
- All builds use remote EAS credentials
- Automatic security scanning via EAS
- Staged rollouts limit blast radius of security issues
- Draft submissions allow security review before release

## Release Management Best Practices

### Version Management
- Use semantic versioning (e.g., 1.2.3)
- Tag releases in git for traceability
- Generate release notes from git commits
- Automatic version code increment prevents conflicts

### Testing Strategy
1. **Development builds:** Local testing and development
2. **Preview/Internal track:** Team and stakeholder testing
3. **Production drafts:** Final review before public release
4. **Staged rollouts:** 20% → 50% → 100% for production

### Monitoring and Rollback
- Monitor crash reports in Google Play Console
- Watch user reviews and ratings
- Set up alerts for abnormal crash rates
- Have rollback plan ready for critical issues
- Use staged rollouts to limit impact

## Advanced Configuration

### Custom Release Tracks
You can create additional testing tracks:
1. Go to **Release > Testing > Create new track**
2. Update `eas.json` submit configuration:
   ```json
   "submit": {
     "beta": {
       "android": {
         "track": "beta",
         "releaseStatus": "completed"
       }
     }
   }
   ```

### Automated Release Notes
The system generates release notes from git commits:
```bash
# Commit prefixes that generate release notes:
feat: ✨ New feature
fix: 🐛 Bug fix  
improvement: 🔧 Enhancement
android: 🤖 Android-specific changes
mobile: 📱 Mobile app changes
```

### Multiple Environment Support
Current configuration supports:
- **Development:** Local testing (localhost API)
- **Preview:** Staging environment (backend.spacewalker.littleponies.com)
- **Production:** Live environment (api.spacewalker.com)

### GitHub Actions Customization
Customize triggers in `.github/workflows/eas-build.yml`:
```yaml
# Add custom triggers
on:
  push:
    tags:
      - 'v*'  # Trigger on version tags
  schedule:
    - cron: '0 6 * * 1'  # Weekly builds on Monday 6 AM
```

## Resources

### Documentation Links
- [Google Play Console](https://play.google.com/console)
- [EAS Submit Documentation](https://docs.expo.dev/submit/introduction/)
- [Android App Signing](https://developer.android.com/studio/publish/app-signing)
- [Google Play Developer Policy](https://play.google.com/about/developer-content-policy/)

### Internal Documentation
- [Mobile Architecture Guide](./architecture/README.md)
- [EAS Configuration Summary](./build-pipeline.md)
- [GitHub Actions Mobile CI](./deployment/github-actions-config.md)
- [Mobile Development Patterns](./development-patterns.md)

### Quick Reference Files
- **EAS Config:** `apps/mobile/eas.json`
- **Package Scripts:** `apps/mobile/package.json`
- **CI/CD Workflow:** `.github/workflows/eas-build.yml`
- **Validation Scripts:** `apps/mobile/scripts/`

---

## 📋 Quick Command Reference

### Essential Commands
```bash
# Build and deploy
just android_build_prod                 # Build production
just android_submit_playstore production # Submit to Play Store
just android_release_status             # Check status

# CI/CD simulation  
cd apps/mobile && eas build --profile production    # Production build
just mobile_ci_status                   # Check EAS status

# Configuration
just android_validate_config            # Validate setup
npm run validate:eas                    # Validate EAS config
npm run test:submission                 # Test submission config

# Release management
just android_generate_release_notes     # Generate release notes
```

### GitHub Actions Triggers
- **PR to main/dev:** Development build (no submission)
- **Push to dev:** Preview build → internal track
- **Push to main:** Production build → production track (draft)
- **Manual:** Any profile via GitHub Actions UI

---

## 🚀 Next Steps Checklist

- [ ] Complete Google Play Console app setup
- [ ] Generate upload keystore and configure EAS credentials
- [ ] Set up service account and configure GitHub secrets
- [ ] Test with preview build to internal track
- [ ] Configure automated release notes
- [ ] Set up monitoring and alerting
- [ ] Document team-specific procedures
- [ ] Test emergency rollback procedures

---

*Last updated: 2025-07-08 | Version: 2.0 | Status: Production Ready with CI/CD*  
*Next review: 2025-08-08 (monthly review recommended)*