# Mobile Development Troubleshooting Guide

**SpaceWalker Mobile App** - Comprehensive troubleshooting guide for common development issues, build failures, and debugging strategies

---

## 📋 Overview

This guide provides solutions to common mobile development issues encountered while working with the SpaceWalker React Native/Expo application. It covers:

- **Development server issues** (Expo, Metro bundler)
- **Build failures** (EAS builds, native dependencies)
- **Environment configuration** problems
- **Platform-specific issues** (iOS and Android)
- **Debugging workflows** and tools
- **Preventive measures** and best practices

---

## 🚨 Quick Reference Troubleshooting Matrix

| Symptom | Likely Cause | Quick Fix | Detailed Section |
|---------|--------------|-----------|------------------|
| QR code not scanning | Network/IP issues | `just expo ip auto` | [Connection Issues](#-development-server-connection-issues) |
| Metro bundler timeout | Cache corruption | `just service clean mobile` | [Metro Issues](#metro-bundler-problems) |
| EAS build failing | Dependencies/config | Check build logs | [Build Failures](#-build-failure-scenarios) |
| EAS archive too large | Monorepo size | Root .easignore | [Archive Optimization](#eas-build-archive-size) |
| Wrong environment | Config variables | Check env vars | [Environment Debug](#-environment-configuration-debugging) |
| iOS simulator crash | Native dependencies | Clean/rebuild | [iOS Issues](#ios-specific-issues) |
| Android emulator slow | AVD configuration | Increase RAM/CPU | [Android Issues](#android-specific-issues) |
| API calls failing | Network/CORS | Check URL/proxy | [Network Debug](#network-request-debugging) |
| Tests failing | Dependencies | `npm ci` | [Testing Issues](#testing-problems) |

---

## 🔌 Development Server Connection Issues

### Metro Bundler Connection Problems

#### **Cannot connect to development server**

**Symptoms:**
```
Unable to connect to development server
Network request failed
Connection refused on port 8081
```

**Solutions:**
```bash
# 1. Restart Metro bundler
just service clean mobile
just expo start --offline

# 2. Clear all caches
cd apps/mobile
npx expo start --clear

# 3. Fix IP configuration
just expo ip auto

# 4. Check port conflicts
lsof -i :8081
# Kill conflicting process if needed
kill -9 <PID>

# 5. Restart with tunnel
cd apps/mobile
npx expo start --tunnel
```

#### **QR Code not scanning/connecting**

**Symptoms:**
```
QR code appears but doesn't connect
"Unable to open project" in Expo Go
Connection timeout after scanning
```

**Solutions:**
```bash
# 1. Update IP configuration (most common fix)
just expo ip auto

# 2. Check firewall settings
# Ensure port 8081 is open on your firewall

# 3. Use tunnel mode for difficult networks
cd apps/mobile
npx expo start --tunnel

# 4. Manual connection
# In Expo Go: tap "Enter URL manually"
# Enter: exp://YOUR_IP:8081

# 5. Check network connectivity
ping $(rg -n "EXPO_PUBLIC_LOCAL_API_HOST" apps/mobile/.env.local >/dev/null && awk -F= '/EXPO_PUBLIC_LOCAL_API_HOST/{print $2}' apps/mobile/.env.local)
```

#### **Hot reload not working**

**Symptoms:**
```
Changes not reflecting in app
Manual refresh required for updates
Fast refresh disabled
```

**Solutions:**
```bash
# 1. Clear Metro cache
cd apps/mobile
npx expo start --clear

# 2. Reset Metro configuration
rm -rf .expo
rm -rf node_modules
just service install mobile

# 3. Check for circular dependencies
# Look for import cycles in your code

# 4. Restart development server
just service clean mobile && just expo start --offline

# 5. Verify React DevTools connection
# Enable "Fast Refresh" in developer menu
```

### Network Configuration Issues

#### **API connection failures**

**Symptoms:**
```
Network request failed
CORS policy error
Timeout connecting to backend
```

**Solutions:**
```bash
# 1. Verify backend is running
just health
curl http://localhost:8000/health/

# 2. Check API URL configuration
just mobile_config_debug

# 3. Verify environment variables
cd apps/mobile
npx expo config --type public | grep API

# 4. Test direct API connection
curl -X GET "$(just mobile_get_api_url)/health/"

# 5. Check proxy/VPN settings
# Disable VPN if causing connection issues
```

#### **CORS (Cross-Origin Resource Sharing) errors**

**Symptoms:**
```
Access to fetch blocked by CORS policy
Preflight request failed
CORS header missing
```

**Solutions:**
```bash
# 1. Check backend CORS configuration
# Backend should allow requests from mobile origins

# 2. Use localhost instead of 127.0.0.1
export API_BASE_URL=http://localhost:8000
just expo start --offline

# 3. For development, use tunnel mode
cd apps/mobile
npx expo start --tunnel

# 4. Verify mobile app API URL
just mobile_config_debug | grep API_BASE_URL
```

---

## 📦 Cache-Related Issues

### Metro Bundler Cache Problems

#### **Stale cache causing issues**

**Symptoms:**
```
Old version of code running
Import errors after adding dependencies
Module resolution failures
```

**Solutions:**
```bash
# 1. Clear Metro cache (recommended first step)
cd apps/mobile
npx expo start --clear

# 2. Clear all mobile caches
just service clean mobile

# 3. Clear system caches
npm cache clean --force
npx expo install --fix

# 4. Nuclear option - complete reset
just service clean mobile
rm -rf apps/mobile/node_modules
rm -rf apps/mobile/.expo
just service install mobile
just expo start --offline

# 5. Clear watchman cache (if installed)
watchman watch-del-all
```

### Expo Cache Issues

#### **Expo configuration cache problems**

**Symptoms:**
```
Configuration not updating
Old bundle ID persisting
Environment variables not changing
```

**Solutions:**
```bash
# 1. Clear Expo cache
cd apps/mobile
rm -rf .expo
npx expo start --clear

# 2. Reset Expo configuration
npx expo export:clear
rm -rf dist/

# 3. Verify configuration changes
npx expo config --type public

# 4. Force configuration reload
cd apps/mobile
rm -rf .expo
npx expo start

# 5. Check app.config.js syntax
node -c app.config.js
```

### Node Modules Cache Issues

#### **Dependency resolution problems**

**Symptoms:**
```
Module not found errors
Version conflicts
Peer dependency warnings
```

**Solutions:**
```bash
# 1. Clean install dependencies
cd apps/mobile
rm -rf node_modules package-lock.json
npm install

# 2. Use exact dependency installation
just service clean mobile
just service install mobile

# 3. Check for dependency conflicts
npm ls --depth=0

# 4. Verify critical mobile dependencies
just env_check

# 5. Fix peer dependency issues
npm install --save-peer <missing-peer-dependency>
```

---

## 🏗️ Build Failure Scenarios

### EAS Build Failures

#### **EAS Build Archive Size Issues**

**Symptoms:**
```
Your project archive is 3.2 GB. You can reduce its size and the time it takes to upload by excluding files that are unnecessary for the build process in .easignore file.
Failed to upload project tarball to EAS Build - Maximum allowed size is 2.0 GB
```

**Root Cause:**
In monorepos, EAS uploads the entire repository including all apps, packages, and dependencies. This can easily exceed the 2GB limit.

**Solution:**
```bash
# Create .easignore in repository root (not in apps/mobile/)
# Use "deny all, then allow specific" pattern:

# 1. Ignore everything by default
*

# 2. Whitelist essential files and mobile app
!/package.json
!/package-lock.json
!/apps/mobile/
!/packages/

# 3. Re-exclude node_modules even in whitelisted directories
/apps/mobile/node_modules
/packages/**/node_modules
```

**Testing:**
```bash
# Test archive size from repository root
tar --exclude-from=.easignore -czf test-archive.tar.gz .
ls -lh test-archive.tar.gz
# Should show <500MB instead of 3.2GB

# Verify EAS build
cd apps/mobile
eas build --profile preview --platform android
```

**See**: [EAS Build Archive Optimization](../gotchas/eas-build-archive-optimization.md) for complete details.

#### **Build configuration errors**

**Symptoms:**
```
eas.json validation failed
Invalid build profile
Configuration not found
```

**Solutions:**
```bash
# 1. Validate EAS configuration
cd apps/mobile
eas build:configure

# 2. Check eas.json syntax
cat eas.json | jq .
# Should parse without errors

# 3. Verify profiles exist
eas build:list --status=finished --limit 5

# 4. Test configuration locally
npx expo config --type public

# 5. Check for missing environment variables
cat eas.json | grep -A5 '"env"'
```

#### **Native dependency build failures**

**Symptoms:**
```
Native module compilation failed
Gradle build error (Android)
Xcode build error (iOS)
```

**Solutions:**
```bash
# 1. Check for incompatible dependencies
cd apps/mobile
npm ls | grep -E "(WARN|ERROR)"

# 2. Clear EAS build cache
eas build --platform all --clear-cache

# 3. Check dependency compatibility
npx expo doctor

# 4. Review build logs
eas logs --build-id <failed-build-id>

# 5. Test local build
just mobile_build_local
```

#### **Memory/resource limit errors**

**Symptoms:**
```
JavaScript heap out of memory
Build timeout after 45 minutes
OOM killed
```

**Solutions:**
```bash
# 1. Increase Node.js memory limit
# Add to eas.json env section:
# "NODE_OPTIONS": "--max-old-space-size=4096"

# 2. Use larger resource class (premium)
# In eas.json:
# "resourceClass": "large"

# 3. Optimize bundle size
cd apps/mobile
npx expo export --dump-sourcemap
npx @expo/metro-config analyze bundle.map

# 4. Clear build cache
eas build --clear-cache

# 5. Split large components
# Use React.lazy() for code splitting
```

### Code Signing Issues

#### **iOS provisioning profile problems**

**Symptoms:**
```
No profiles for bundle identifier found
Certificate not found in keychain
Provisioning profile doesn't match
```

**Solutions:**
```bash
# 1. Check EAS credentials
cd apps/mobile
eas credentials --platform ios

# 2. Clear and reconfigure credentials
eas credentials --platform ios --clear-provisioning-profile
eas credentials --platform ios --clear-cert

# 3. Verify Apple Developer account
# Check: developer.apple.com → Certificates, IDs & Profiles

# 4. Manual credential setup
eas build --platform ios --clear-credentials

# 5. Check bundle ID consistency
grep -r "bundleIdentifier" .
grep -r "EXPO_PUBLIC_BUNDLE_ID_IOS" .
```

#### **Android keystore issues**

**Symptoms:**
```
Keystore file not found
Key alias not found
Invalid keystore format
```

**Solutions:**
```bash
# 1. Check Android credentials
cd apps/mobile
eas credentials --platform android

# 2. Generate new keystore
keytool -genkeypair -v -keystore upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias upload

# 3. Configure EAS credentials
eas credentials --platform android

# 4. Verify keystore
keytool -list -v -keystore upload-keystore.jks

# 5. Check Google Play Console setup
# Verify app signing is enabled in Play Console
```

---

## ⚙️ Environment Configuration Debugging

### Determining Current Environment

#### **How to verify which environment the app is using**

```bash
# 1. Check configuration debug output
just mobile_config_debug

# 2. Inspect resolved configuration
cd apps/mobile
npx expo config --type public | grep -A10 extra

# 3. Check environment variables
echo $EXPO_PUBLIC_API_BASE_URL
echo $EXPO_PUBLIC_APP_VARIANT

# 4. Look for environment indicator in app
# App should show colored badge (DEV/PREVIEW/PROD)

# 5. Check API endpoint in logs
# Look for API calls in Metro bundler logs
```

### EXPO_PUBLIC_ Variable Issues

#### **Variables not being recognized**

**Symptoms:**
```
Environment variables undefined
API_BASE_URL not found
Configuration falling back to defaults
```

**Solutions:**
```bash
# 1. Check variable naming
# Must start with EXPO_PUBLIC_ for build-time access
export EXPO_PUBLIC_API_BASE_URL=http://localhost:8000

# 2. Verify in eas.json
cat apps/mobile/eas.json | grep -A5 '"env"'

# 3. Test variable access
cd apps/mobile
node -e "console.log(process.env.EXPO_PUBLIC_API_BASE_URL)"

# 4. Clear configuration cache
rm -rf .expo
npx expo start

# 5. Check app.config.js processing
cd apps/mobile
node -e "const config = require('./app.config.js'); console.log(config({}).extra)"
```

### App Configuration Problems

#### **app.config.js and environment.ts issues**

**Symptoms:**
```
Configuration not loading
Environment detection failing
API URLs incorrect
```

**Solutions:**
```bash
# 1. Validate app.config.js syntax
cd apps/mobile
node -c app.config.js

# 2. Test configuration function
node -e "
const config = require('./app.config.js');
console.log(JSON.stringify(config({}), null, 2));
"

# 3. Check environment.ts logic
cd apps/mobile/src/config
node -e "
const env = require('./environment.ts');
console.log('API URL:', env.getApiUrl());
console.log('App Variant:', env.getAppVariant());
"

# 4. Verify dual-mode configuration
# Check both EXPO_PUBLIC_ and Constants.expoConfig.extra paths

# 5. Test environment switching
export API_BASE_URL=https://backend.spacewalker.littleponies.com
export APP_VARIANT=preview
just expo start --offline
```

### Common Environment Variable Mistakes

#### **Naming and formatting issues**

**Common mistakes:**
```bash
# ❌ Wrong: Missing EXPO_PUBLIC_ prefix
API_URL=http://localhost:8000

# ✅ Correct: Proper prefix for build-time variables
EXPO_PUBLIC_API_URL=http://localhost:8000

# ❌ Wrong: Inconsistent naming
EXPO_PUBLIC_API_URL
API_BASE_URL

# ✅ Correct: Consistent naming
EXPO_PUBLIC_API_BASE_URL
API_BASE_URL

# ❌ Wrong: Invalid URL format
EXPO_PUBLIC_API_BASE_URL=localhost:8000

# ✅ Correct: Full URL with protocol
EXPO_PUBLIC_API_BASE_URL=http://localhost:8000
```

**Debugging steps:**
```bash
# 1. List all environment variables
env | grep -E "(API|APP_|EXPO_)"

# 2. Check variable precedence
just mobile_config_debug

# 3. Test URL validation
node -e "
try {
  new URL('$EXPO_PUBLIC_API_BASE_URL');
  console.log('URL valid');
} catch(e) {
  console.log('URL invalid:', e.message);
}
"

# 4. Verify configuration loading
cd apps/mobile
npx expo config | grep -A20 extra
```

---

## 🛠️ Debugging Workflows and Tools

### React Native Debugger

#### **Setting up and using React Native Debugger**

```bash
# 1. Install React Native Debugger
# Download from: https://github.com/jhen0409/react-native-debugger/releases

# 2. Start debugger on correct port
react-native-debugger --port 8081

# 3. Enable debugging in app
# Device: Shake device → "Debug JS Remotely"
# Simulator: Cmd+D (iOS) / Cmd+M (Android) → "Debug JS Remotely"

# 4. Inspect Redux state (if using Redux)
# Redux DevTools should appear automatically

# 5. Debug network requests
# View all API calls in Network tab
```

### Flipper Integration

#### **Using Flipper for advanced debugging**

```bash
# 1. Install Flipper
# Download from: https://fbflipper.com/

# 2. Install Flipper in project (if not already done)
cd apps/mobile
npx expo install react-native-flipper

# 3. Start Flipper and connect device
# Device should appear in Flipper automatically

# 4. Available plugins:
# - Logs: View console logs
# - Network: Inspect API requests
# - Layout: Inspect component hierarchy
# - AsyncStorage: View stored data

# 5. Debugging React Navigation
# Install react-navigation-devtools for route debugging
```

### Network Request Inspection

#### **Debugging API calls and network issues**

```bash
# 1. Enable network logging in app
# Add to App.tsx or root component:
# if (__DEV__) {
#   global.XMLHttpRequest = global.originalXMLHttpRequest || global.XMLHttpRequest;
# }

# 2. Use proxy tools
# Install and configure Proxyman or Charles Proxy

# 3. View requests in Metro logs
just expo start --offline
# Look for API calls in terminal output

# 4. Add request logging to API client
# Log all requests/responses in development

# 5. Test API independently
curl -X GET "$(just mobile_get_api_url)/health/" -v
```

### Performance Profiling

#### **Identifying performance bottlenecks**

```bash
# 1. Enable performance monitoring
# Add to App.tsx:
# import { enableScreens } from 'react-native-screens';
# enableScreens();

# 2. Use React DevTools Profiler
# Install React DevTools browser extension
# Connect to React Native debugger

# 3. Monitor memory usage
# Use Xcode Instruments (iOS) or Android Studio Profiler

# 4. Bundle analysis
cd apps/mobile
npx expo export --dump-sourcemap
npx @expo/metro-config analyze sourcemap.json

# 5. Performance metrics
# Add react-native-performance for detailed metrics
```

### Crash Report Analysis

#### **Debugging crashes and errors**

```bash
# 1. TestFlight crash reports
# Access via App Store Connect → TestFlight → Crash Reports

# 2. Enable crash reporting (if configured)
# Crashlytics, Bugsnag, or Sentry integration

# 3. Local crash debugging
# Check device logs:
# iOS: Xcode → Window → Devices → View Device Logs
# Android: adb logcat

# 4. Symbolicate crash reports
# Use Expo or React Native crash symbolication

# 5. JavaScript error tracking
# Add error boundary components
# Log errors to console in development
```

---

## 📱 Platform-Specific Issues

### iOS-Specific Issues

#### **Xcode version compatibility**

**Symptoms:**
```
Build tools version not supported
iOS SDK not found
Xcode command line tools error
```

**Solutions:**
```bash
# 1. Check Xcode version
xcode-select --print-path
xcodebuild -version

# 2. Install command line tools
xcode-select --install

# 3. Switch Xcode version
sudo xcode-select -s /Applications/Xcode.app/Contents/Developer

# 4. Clear Xcode cache
rm -rf ~/Library/Developer/Xcode/DerivedData/*

# 5. Update Xcode to compatible version
# Check EAS build requirements for Xcode version
```

#### **CocoaPods issues**

**Symptoms:**
```
[!] CocoaPods could not find compatible versions
Pod install failed
Native iOS dependencies not found
```

**Solutions:**
```bash
# 1. Update CocoaPods
sudo gem install cocoapods
pod --version

# 2. Clear CocoaPods cache
pod cache clean --all
rm -rf ~/.cocoapods

# 3. Reset iOS dependencies
cd apps/mobile/ios
rm -rf Pods Podfile.lock
cd ..
npx pod-install ios

# 4. Check Podfile compatibility
cd apps/mobile
npx expo run:ios --clean

# 5. Manual pod installation
cd apps/mobile/ios
pod install --repo-update
```

#### **iOS Simulator issues**

**Symptoms:**
```
Simulator not responding
App crashes on launch
Build succeeds but app won't install
```

**Solutions:**
```bash
# 1. Reset iOS Simulator
xcrun simctl erase all

# 2. Restart simulator
killall Simulator
open -a Simulator

# 3. Clean build
cd apps/mobile
npx expo run:ios --clean

# 4. Check simulator logs
xcrun simctl spawn booted log stream --level debug

# 5. Install on different simulator
xcrun simctl list devices
npx expo run:ios --device "iPhone 14 Pro"
```

### Android-Specific Issues

#### **Gradle version conflicts**

**Symptoms:**
```
Gradle build failed
Version conflict with Android plugin
Build tools not compatible
```

**Solutions:**
```bash
# 1. Check Gradle wrapper version
cd apps/mobile/android
./gradlew --version

# 2. Update Gradle wrapper
./gradlew wrapper --gradle-version=7.5.1

# 3. Clean Gradle cache
./gradlew clean
./gradlew --stop

# 4. Update Android Gradle Plugin
# Check apps/mobile/android/build.gradle
# Update com.android.tools.build:gradle version

# 5. Reset Android dependencies
rm -rf ~/.gradle/caches
cd apps/mobile
npx expo run:android --clean
```

#### **Android SDK version mismatches**

**Symptoms:**
```
compileSdkVersion not found
Target SDK version error
Build tools version not supported
```

**Solutions:**
```bash
# 1. Check Android SDK installation
echo $ANDROID_HOME
ls $ANDROID_HOME/platforms/

# 2. Install required SDK versions
$ANDROID_HOME/tools/bin/sdkmanager "platforms;android-33"
$ANDROID_HOME/tools/bin/sdkmanager "build-tools;33.0.0"

# 3. Update Android configuration
# Check apps/mobile/android/build.gradle
# Update compileSdkVersion, targetSdkVersion

# 4. Sync Android project
cd apps/mobile/android
./gradlew sync

# 5. Use Android Studio to resolve
# Open android/ folder in Android Studio
# Let it auto-fix SDK issues
```

#### **Android Emulator problems**

**Symptoms:**
```
Emulator not starting
App installation failed
Poor performance
```

**Solutions:**
```bash
# 1. List available emulators
emulator -list-avds

# 2. Start emulator manually
emulator -avd <emulator-name>

# 3. Create new AVD with more resources
# Android Studio → AVD Manager → Create Virtual Device
# Increase RAM to 4GB+, enable hardware acceleration

# 4. Enable hardware acceleration
# Check BIOS virtualization settings
# Install Intel HAXM (macOS) or enable Hyper-V (Windows)

# 5. Cold boot emulator
emulator -avd <emulator-name> -cold-boot

# 6. Check adb connection
adb devices
adb kill-server && adb start-server
```

---

## 🧪 Testing Problems

### Unit Test Failures

#### **Jest configuration issues**

**Symptoms:**
```
Test suites failing to run
Module not found in tests
Transform errors
```

**Solutions:**
```bash
# 1. Clear Jest cache
cd apps/mobile
npx jest --clearCache

# 2. Check Jest configuration
cat jest.config.js
cat package.json | jq .jest

# 3. Verify test setup
npm test -- --init

# 4. Check mock configuration
ls __mocks__/
cat __mocks__/*.js

# 5. Run specific test to debug
npm test -- --testPathPattern="specific-test.test.tsx" --verbose
```

#### **React Native Testing Library issues**

**Symptoms:**
```
Render errors in tests
Component not found
Mock component failures
```

**Solutions:**
```bash
# 1. Check testing library versions
npm ls @testing-library/react-native

# 2. Update testing dependencies
npm install --save-dev @testing-library/react-native@latest

# 3. Check test setup file
cat jest-setup.js

# 4. Mock React Native components
# Add to __mocks__/react-native.js

# 5. Run tests with debug
npm test -- --runInBand --verbose
```

### Integration Test Issues

#### **API integration test failures**

**Symptoms:**
```
Network requests failing in tests
Timeout errors
Mock not working
```

**Solutions:**
```bash
# 1. Check if backend is running for integration tests
just health

# 2. Use proper test environment
NODE_ENV=test npm test

# 3. Mock network requests
# Use msw (Mock Service Worker) for API mocking

# 4. Increase test timeouts
jest.setTimeout(30000);

# 5. Run integration tests separately
npm test -- --testPathPattern="integration"
```

---

## 🚀 Performance Issues

### Metro Bundler Performance

#### **Slow bundling and compilation**

**Symptoms:**
```
Metro taking too long to bundle
App startup very slow
Development server freezing
```

**Solutions:**
```bash
# 1. Enable Metro cache
cd apps/mobile
npx expo start --max-workers 4

# 2. Optimize Metro configuration
# Update metro.config.js with cache settings

# 3. Use faster transformer
# Configure Hermes engine in app.json

# 4. Reduce bundle size
# Remove unused dependencies
npm ls --depth=0 | grep extraneous

# 5. Increase Node.js memory
export NODE_OPTIONS="--max-old-space-size=4096"
just expo start --offline
```

### Runtime Performance Problems

#### **App running slowly or freezing**

**Symptoms:**
```
UI freezing during interactions
Slow navigation between screens
High memory usage
```

**Solutions:**
```bash
# 1. Enable Hermes engine
# In app.json: "jsEngine": "hermes"

# 2. Optimize FlatList performance
# Use getItemLayout, keyExtractor
# Enable removeClippedSubviews

# 3. Reduce re-renders
# Use React.memo, useMemo, useCallback

# 4. Profile performance
# Use React DevTools Profiler
# Enable react-native-performance

# 5. Check for memory leaks
# Use Flipper memory profiler
# Monitor component mount/unmount cycles
```

---

## 🔒 Preventive Measures

### Development Environment Setup

#### **Recommended development environment**

```bash
# 1. Node.js version management
# Use nvm or fnm for consistent Node.js versions
nvm use 20.19.4

# 2. Global tool installation
npm install -g @expo/cli@latest
npm install -g eas-cli@latest

# 3. IDE setup
# VS Code with React Native extensions
# React Native Tools, ES7+ React/Redux snippets

# 4. Environment variables
# Create .env.local for local development
# Never commit .env files to git

# 5. Device setup
# iOS: Install Xcode and iOS simulators
# Android: Install Android Studio and emulators
```

### Pre-flight Checklist

#### **Before starting development**

```bash
# ✅ Check all services are running
just health

# ✅ Verify mobile configuration
just mobile_config_debug

# ✅ Update IP configuration
just expo ip auto

# ✅ Clear caches if needed
just service clean mobile  # Only if issues

# ✅ Verify environment variables
env | grep -E "(API|APP_|EXPO_)"

# ✅ Test API connectivity
curl $(just mobile_get_api_url)/health/
```

#### **Before building**

```bash
# ✅ Run all tests
just test all all_mobile

# ✅ Lint code
just lint_mobile

# ✅ Check dependencies
just env_check

# ✅ Verify build configuration
cd apps/mobile
eas build:configure

# ✅ Test local build first
just mobile_build_local
```

### Version Pinning Strategies

#### **Dependency management best practices**

```bash
# 1. Pin exact versions for critical dependencies
# In package.json, use exact versions (no ^ or ~)
"expo": "50.0.0",
"react-native": "0.73.0"

# 2. Use lockfile for consistency
# Commit package-lock.json to git
# Use 'npm ci' in CI/CD instead of 'npm install'

# 3. Regular dependency updates
# Weekly: Check for security updates
npm audit
npm update

# 4. Test dependency updates thoroughly
# Update one dependency at a time
# Run full test suite after updates

# 5. Monitor breaking changes
# Subscribe to React Native and Expo release notes
# Test beta versions in separate branch
```

### Monitoring and Alerts

#### **Proactive issue detection**

```bash
# 1. Build monitoring
# Monitor EAS build success rates
eas build:list --status=errored --limit 10

# 2. Performance monitoring
# Track app startup time
# Monitor bundle size growth

# 3. Error tracking
# Implement crash reporting
# Monitor API error rates

# 4. Dependency monitoring
# Use tools like Dependabot
# Monitor for security vulnerabilities

# 5. Team communication
# Set up build failure notifications
# Share troubleshooting solutions
```

---

## 📚 Additional Resources

### Command Reference

```bash
# Development commands
just expo start --offline      # Start development server
just mobile_ios               # Run on iOS simulator
just mobile_android           # Run on Android emulator
just expo ip auto             # Update IP configuration
just service clean mobile             # Clean caches and reset

# Debugging commands
just mobile_config_debug      # Show configuration debug info
just mobile_env_validate      # Validate environment setup
just mobile_logs              # View mobile service logs
just health                   # Check all services

# Build commands
just mobile_build_local       # Test build locally
just mobile_build_dev         # Build for dev backend
just mobile_build_status      # Check build status

# Testing commands
just test unit all_mobile         # Run unit tests
just test integration all_mobile  # Run integration tests
just lint_mobile              # Code quality check
```

### External Documentation

- **[Expo Troubleshooting](https://docs.expo.dev/troubleshooting/overview/)**
- **[React Native Debugging](https://reactnative.dev/docs/debugging)**
- **[EAS Build Troubleshooting](https://docs.expo.dev/troubleshooting/build-errors/)**
- **[Metro Bundler Configuration](https://metrobundler.dev/docs/configuration)**
- **[React Native Performance](https://reactnative.dev/docs/performance)**

### Related Documentation

- **[Mobile Architecture](./architecture.md)** - Understanding dual-mode configuration
- **[Environment Configuration](./environment-config.md)** - Environment setup guide
- **[Build Pipeline](./build-pipeline.md)** - Build process and optimization
- **[Mobile Development Workflows](../workflows/mobile-development.md)** - Development processes
- **[TestFlight Guide](./testflight-guide.md)** - Distribution and testing

---

## 🆘 Getting Help

### When to seek additional help

1. **Issue not covered in this guide** - Create a GitHub issue with detailed reproduction steps
2. **Platform-specific problems** - Check platform-specific documentation first
3. **Build failures with unclear logs** - Share build ID and error details with team
4. **Performance issues** - Provide profiling data and specific symptoms
5. **New error patterns** - Document and add to this troubleshooting guide

### Information to provide when reporting issues

```bash
# System information
node --version
npm --version
npx expo --version
eas --version

# Project information
cd apps/mobile
git rev-parse HEAD
cat package.json | grep version

# Configuration debug
just mobile_config_debug

# Build information (if applicable)
eas build:list --limit 5
```

---

**Last Updated**: 2025-01-09
**Troubleshooting Guide Version**: 1.0
**Status**: ✅ Comprehensive Mobile Troubleshooting Guide Active

---

**Remember**: This guide is living documentation. Please update it when you discover new issues or solutions!
