# Mobile Offline-First UX Patterns

## Purpose
Comprehensive user experience patterns for offline-first React Native mobile applications including offline indicators, loading states, error recovery, sync progress feedback, and conflict resolution UX for the Spacewalker mobile app.

## When to Use This
- Implementing user-friendly offline experiences in mobile applications
- Creating intuitive feedback for sync states and network conditions
- Designing error recovery flows for offline scenarios
- Managing user expectations during data synchronization
- Keywords: offline UX, sync indicators, error recovery, network status, user feedback

**Version:** 1.0
**Date:** 2025-07-09
**Status:** Current

## Key Concepts
- **Offline Indicators**: Visual feedback about network connectivity and offline mode
- **Progressive Disclosure**: Gradually revealing information about sync status and conflicts
- **Graceful Degradation**: Maintaining functionality when network is unavailable
- **Recovery Patterns**: User-friendly ways to handle sync errors and conflicts
- **Optimistic UI**: Immediately reflecting user actions while syncing in background

## Offline UX Architecture Overview

```mermaid
graph TD
    A[User Action] --> B{Network Status}
    B -->|Online| C[Immediate Sync]
    B -->|Offline| D[Show Offline Mode]

    C --> E{Sync Success?}
    E -->|Yes| F[Success Feedback]
    E -->|No| G[Error Handling]

    D --> H[Queue Action]
    H --> I[Offline Confirmation]
    I --> J[Auto-Sync When Online]

    G --> K{Error Type}
    K -->|Network| L[Retry Options]
    K -->|Conflict| M[Conflict Resolution UI]
    K -->|Server| N[Error Message]

    J --> O{Sync Success?}
    O -->|Yes| P[Background Success]
    O -->|No| Q[Notification + Retry]

    classDef online fill:#E8F5E8,stroke:#388E3C,color:#000000
    classDef offline fill:#FFF3E0,stroke:#F57C00,color:#000000
    classDef error fill:#FFEBEE,stroke:#D32F2F,color:#000000
    classDef success fill:#E3F2FD,stroke:#1976D2,color:#000000

    class A,C,E,F online
    class B,D,H,I,J offline
    class G,K,L,M,N,Q error
    class P success
```

## Network Status Indicators

### Network Status Hook

```typescript
import { useState, useEffect } from 'react';
import NetInfo from '@react-native-community/netinfo';

export interface NetworkState {
  isConnected: boolean;
  isInternetReachable: boolean | null;
  type: string;
  strength: 'poor' | 'good' | 'excellent' | null;
  isOfflineMode: boolean;
}

export const useNetworkStatus = () => {
  const [networkState, setNetworkState] = useState<NetworkState>({
    isConnected: true,
    isInternetReachable: null,
    type: 'unknown',
    strength: null,
    isOfflineMode: false,
  });

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      // Determine connection strength based on network details
      let strength: 'poor' | 'good' | 'excellent' | null = null;

      if (state.isConnected) {
        if (state.type === 'wifi') {
          strength = 'excellent';
        } else if (state.type === 'cellular') {
          const details = state.details as any;
          if (details?.cellularGeneration) {
            switch (details.cellularGeneration) {
              case '2g':
                strength = 'poor';
                break;
              case '3g':
                strength = 'good';
                break;
              case '4g':
              case '5g':
                strength = 'excellent';
                break;
              default:
                strength = 'good';
            }
          } else {
            strength = 'good';
          }
        }
      }

      setNetworkState({
        isConnected: state.isConnected || false,
        isInternetReachable: state.isInternetReachable,
        type: state.type || 'unknown',
        strength,
        isOfflineMode: !state.isConnected || state.isInternetReachable === false,
      });
    });

    return unsubscribe;
  }, []);

  return networkState;
};
```

### Network Status Banner

```typescript
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Animated, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNetworkStatus } from '../hooks/useNetworkStatus';

export const NetworkStatusBanner: React.FC = () => {
  const networkState = useNetworkStatus();
  const [bannerHeight] = useState(new Animated.Value(0));
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    const shouldShow = !networkState.isConnected || networkState.isInternetReachable === false;

    Animated.timing(bannerHeight, {
      toValue: shouldShow ? (showDetails ? 80 : 50) : 0,
      duration: 300,
      useNativeDriver: false,
    }).start();
  }, [networkState.isConnected, networkState.isInternetReachable, showDetails]);

  const getStatusInfo = () => {
    if (!networkState.isConnected) {
      return {
        icon: 'wifi-off' as const,
        message: 'No internet connection',
        detail: 'Working offline - changes will sync when connection is restored',
        color: '#f44336',
        backgroundColor: '#ffebee',
      };
    } else if (networkState.isInternetReachable === false) {
      return {
        icon: 'warning' as const,
        message: 'Limited connectivity',
        detail: 'Connected to network but internet may not be available',
        color: '#ff9800',
        backgroundColor: '#fff3e0',
      };
    } else if (networkState.strength === 'poor') {
      return {
        icon: 'cellular' as const,
        message: 'Slow connection',
        detail: 'Data usage will be optimized for better performance',
        color: '#ff9800',
        backgroundColor: '#fff3e0',
      };
    }

    return null;
  };

  const statusInfo = getStatusInfo();
  if (!statusInfo) return null;

  return (
    <Animated.View style={[styles.banner, { height: bannerHeight, backgroundColor: statusInfo.backgroundColor }]}>
      <TouchableOpacity
        style={styles.bannerContent}
        onPress={() => setShowDetails(!showDetails)}
        activeOpacity={0.7}
      >
        <View style={styles.mainRow}>
          <Ionicons name={statusInfo.icon} size={16} color={statusInfo.color} />
          <Text style={[styles.message, { color: statusInfo.color }]}>
            {statusInfo.message}
          </Text>
          <Ionicons
            name={showDetails ? 'chevron-up' : 'chevron-down'}
            size={16}
            color={statusInfo.color}
          />
        </View>

        {showDetails && (
          <Text style={[styles.detail, { color: statusInfo.color }]}>
            {statusInfo.detail}
          </Text>
        )}
      </TouchableOpacity>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  banner: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.1)',
  },
  bannerContent: {
    flex: 1,
  },
  mainRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  message: {
    flex: 1,
    fontSize: 14,
    fontWeight: '500',
  },
  detail: {
    fontSize: 12,
    marginTop: 4,
    marginLeft: 24,
    opacity: 0.8,
  },
});
```

## Offline Loading States

### Enhanced Loading Component

```typescript
import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export interface LoadingState {
  type: 'loading' | 'syncing' | 'queued' | 'error' | 'success';
  message?: string;
  progress?: number;
  canRetry?: boolean;
  onRetry?: () => void;
}

interface SmartLoadingIndicatorProps {
  state: LoadingState;
  size?: 'small' | 'large';
  showProgress?: boolean;
}

export const SmartLoadingIndicator: React.FC<SmartLoadingIndicatorProps> = ({
  state,
  size = 'small',
  showProgress = false,
}) => {
  const getIndicatorContent = () => {
    switch (state.type) {
      case 'loading':
        return {
          icon: <ActivityIndicator size={size} color="#2196F3" />,
          message: state.message || 'Loading...',
          color: '#2196F3',
        };

      case 'syncing':
        return {
          icon: <ActivityIndicator size={size} color="#4CAF50" />,
          message: state.message || 'Syncing...',
          color: '#4CAF50',
        };

      case 'queued':
        return {
          icon: <Ionicons name="time-outline" size={size === 'large' ? 24 : 16} color="#FF9800" />,
          message: state.message || 'Queued for sync',
          color: '#FF9800',
        };

      case 'error':
        return {
          icon: <Ionicons name="alert-circle-outline" size={size === 'large' ? 24 : 16} color="#F44336" />,
          message: state.message || 'Sync failed',
          color: '#F44336',
        };

      case 'success':
        return {
          icon: <Ionicons name="checkmark-circle-outline" size={size === 'large' ? 24 : 16} color="#4CAF50" />,
          message: state.message || 'Synced',
          color: '#4CAF50',
        };
    }
  };

  const content = getIndicatorContent();

  return (
    <View style={[styles.container, size === 'large' && styles.containerLarge]}>
      {content.icon}
      <Text style={[styles.message, { color: content.color }, size === 'large' && styles.messageLarge]}>
        {content.message}
      </Text>

      {showProgress && state.progress !== undefined && (
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                { width: `${state.progress}%`, backgroundColor: content.color }
              ]}
            />
          </View>
          <Text style={styles.progressText}>{Math.round(state.progress)}%</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 8,
  },
  containerLarge: {
    flexDirection: 'column',
    padding: 16,
    gap: 12,
  },
  message: {
    fontSize: 14,
    fontWeight: '500',
  },
  messageLarge: {
    fontSize: 16,
    textAlign: 'center',
  },
  progressContainer: {
    marginTop: 8,
    width: '100%',
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#e0e0e0',
    borderRadius: 2,
    marginBottom: 4,
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 12,
    color: '#666',
  },
});
```

### Contextual Loading States

```typescript
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { SmartLoadingIndicator, LoadingState } from './SmartLoadingIndicator';
import { useNetworkStatus } from '../hooks/useNetworkStatus';

interface ContextualActionButtonProps {
  onPress: () => void;
  loadingState: LoadingState;
  label: string;
  disabled?: boolean;
}

export const ContextualActionButton: React.FC<ContextualActionButtonProps> = ({
  onPress,
  loadingState,
  label,
  disabled,
}) => {
  const networkState = useNetworkStatus();

  const getButtonState = () => {
    if (disabled) {
      return { disabled: true, label, showLoading: false };
    }

    if (loadingState.type === 'loading' || loadingState.type === 'syncing') {
      return { disabled: true, label: loadingState.message || label, showLoading: true };
    }

    if (loadingState.type === 'queued') {
      if (networkState.isOfflineMode) {
        return { disabled: false, label: `${label} (will sync when online)`, showLoading: false };
      } else {
        return { disabled: true, label: 'Syncing...', showLoading: true };
      }
    }

    if (loadingState.type === 'error') {
      return { disabled: false, label: 'Retry', showLoading: false };
    }

    return { disabled: false, label, showLoading: false };
  };

  const buttonState = getButtonState();

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={[
          styles.button,
          buttonState.disabled && styles.buttonDisabled,
          loadingState.type === 'error' && styles.buttonError,
        ]}
        onPress={onPress}
        disabled={buttonState.disabled}
      >
        {buttonState.showLoading && (
          <SmartLoadingIndicator state={loadingState} size="small" />
        )}
        <Text style={[
          styles.buttonText,
          buttonState.disabled && styles.buttonTextDisabled,
          loadingState.type === 'error' && styles.buttonTextError,
        ]}>
          {buttonState.label}
        </Text>
      </TouchableOpacity>

      {loadingState.type === 'queued' && networkState.isOfflineMode && (
        <Text style={styles.helperText}>
          Your changes are saved and will be uploaded when you're back online
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
  button: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    minHeight: 48,
  },
  buttonDisabled: {
    backgroundColor: '#e0e0e0',
  },
  buttonError: {
    backgroundColor: '#f44336',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
  buttonTextDisabled: {
    color: '#9e9e9e',
  },
  buttonTextError: {
    color: 'white',
  },
  helperText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 16,
  },
});
```

## Error Recovery Patterns

### Error Recovery Component

```typescript
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export interface ErrorInfo {
  type: 'network' | 'server' | 'conflict' | 'validation' | 'unknown';
  message: string;
  details?: string;
  retryable: boolean;
  timestamp: number;
}

interface ErrorRecoveryProps {
  error: ErrorInfo;
  onRetry?: () => Promise<void>;
  onDismiss?: () => void;
  onShowDetails?: () => void;
}

export const ErrorRecoveryComponent: React.FC<ErrorRecoveryProps> = ({
  error,
  onRetry,
  onDismiss,
  onShowDetails,
}) => {
  const [isRetrying, setIsRetrying] = useState(false);

  const getErrorIcon = () => {
    switch (error.type) {
      case 'network':
        return 'wifi-off';
      case 'server':
        return 'server-outline';
      case 'conflict':
        return 'git-merge-outline';
      case 'validation':
        return 'alert-circle-outline';
      default:
        return 'warning-outline';
    }
  };

  const getErrorColor = () => {
    switch (error.type) {
      case 'network':
        return '#ff9800';
      case 'conflict':
        return '#9c27b0';
      default:
        return '#f44336';
    }
  };

  const getRetryLabel = () => {
    switch (error.type) {
      case 'network':
        return 'Try Again';
      case 'server':
        return 'Retry';
      case 'conflict':
        return 'Resolve Conflict';
      case 'validation':
        return 'Fix and Retry';
      default:
        return 'Retry';
    }
  };

  const handleRetry = async () => {
    if (!onRetry || isRetrying) return;

    setIsRetrying(true);
    try {
      await onRetry();
    } catch (retryError) {
      Alert.alert(
        'Retry Failed',
        'Unable to complete the operation. Please try again later.',
        [{ text: 'OK' }]
      );
    } finally {
      setIsRetrying(false);
    }
  };

  const formatTimestamp = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;

    if (diff < 60000) {
      return 'Just now';
    } else if (diff < 3600000) {
      const minutes = Math.floor(diff / 60000);
      return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else {
      const hours = Math.floor(diff / 3600000);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    }
  };

  return (
    <View style={[styles.container, { borderLeftColor: getErrorColor() }]}>
      <View style={styles.header}>
        <Ionicons name={getErrorIcon()} size={24} color={getErrorColor()} />
        <View style={styles.messageContainer}>
          <Text style={styles.message}>{error.message}</Text>
          <Text style={styles.timestamp}>{formatTimestamp(error.timestamp)}</Text>
        </View>
      </View>

      {error.details && (
        <TouchableOpacity
          style={styles.detailsButton}
          onPress={onShowDetails}
        >
          <Text style={styles.detailsText}>Show Details</Text>
          <Ionicons name="chevron-down" size={16} color="#666" />
        </TouchableOpacity>
      )}

      <View style={styles.actions}>
        {error.retryable && (
          <TouchableOpacity
            style={[styles.retryButton, { backgroundColor: getErrorColor() }]}
            onPress={handleRetry}
            disabled={isRetrying}
          >
            {isRetrying ? (
              <ActivityIndicator size="small" color="white" />
            ) : (
              <Text style={styles.retryButtonText}>{getRetryLabel()}</Text>
            )}
          </TouchableOpacity>
        )}

        <TouchableOpacity
          style={styles.dismissButton}
          onPress={onDismiss}
        >
          <Text style={styles.dismissButtonText}>Dismiss</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 8,
    borderLeftWidth: 4,
    padding: 16,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  messageContainer: {
    flex: 1,
  },
  message: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 4,
  },
  timestamp: {
    fontSize: 12,
    color: '#666',
  },
  detailsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
    marginBottom: 12,
  },
  detailsText: {
    fontSize: 14,
    color: '#666',
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
  },
  retryButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 6,
    alignItems: 'center',
    minHeight: 40,
    justifyContent: 'center',
  },
  retryButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
  dismissButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 6,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  dismissButtonText: {
    color: '#666',
    fontSize: 14,
  },
});
```

## Sync Progress Feedback

### Sync Progress Modal

```typescript
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SmartLoadingIndicator } from './SmartLoadingIndicator';

export interface SyncItem {
  id: string;
  type: 'survey' | 'image' | 'user_data';
  name: string;
  status: 'pending' | 'syncing' | 'completed' | 'failed';
  progress?: number;
  error?: string;
}

interface SyncProgressModalProps {
  visible: boolean;
  onClose: () => void;
  items: SyncItem[];
  overallProgress: number;
  onRetryItem?: (itemId: string) => void;
  canCancel?: boolean;
  onCancel?: () => void;
}

export const SyncProgressModal: React.FC<SyncProgressModalProps> = ({
  visible,
  onClose,
  items,
  overallProgress,
  onRetryItem,
  canCancel = false,
  onCancel,
}) => {
  const [expanded, setExpanded] = useState(false);

  const getStatusCounts = () => {
    const counts = {
      completed: items.filter(item => item.status === 'completed').length,
      failed: items.filter(item => item.status === 'failed').length,
      pending: items.filter(item => item.status === 'pending').length,
      syncing: items.filter(item => item.status === 'syncing').length,
    };
    return counts;
  };

  const counts = getStatusCounts();
  const isComplete = counts.syncing === 0 && counts.pending === 0;

  const renderSyncItem = ({ item }: { item: SyncItem }) => (
    <View style={styles.syncItem}>
      <View style={styles.syncItemHeader}>
        <Text style={styles.syncItemName}>{item.name}</Text>
        <SmartLoadingIndicator
          state={{
            type: item.status === 'pending' ? 'queued' :
                  item.status === 'syncing' ? 'syncing' :
                  item.status === 'completed' ? 'success' : 'error',
            progress: item.progress,
          }}
          size="small"
        />
      </View>

      {item.error && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{item.error}</Text>
          {onRetryItem && (
            <TouchableOpacity
              style={styles.retryButton}
              onPress={() => onRetryItem(item.id)}
            >
              <Text style={styles.retryButtonText}>Retry</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </View>
  );

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={styles.modal}>
        <View style={styles.header}>
          <Text style={styles.title}>
            {isComplete ? 'Sync Complete' : 'Syncing Data'}
          </Text>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={24} color="#333" />
          </TouchableOpacity>
        </View>

        <View style={styles.progressSection}>
          <View style={styles.progressBar}>
            <View
              style={[styles.progressFill, { width: `${overallProgress}%` }]}
            />
          </View>
          <Text style={styles.progressText}>
            {Math.round(overallProgress)}% complete
          </Text>
        </View>

        <View style={styles.summarySection}>
          <View style={styles.summaryRow}>
            <Ionicons name="checkmark-circle" size={16} color="#4CAF50" />
            <Text style={styles.summaryText}>{counts.completed} completed</Text>
          </View>

          {counts.failed > 0 && (
            <View style={styles.summaryRow}>
              <Ionicons name="alert-circle" size={16} color="#f44336" />
              <Text style={styles.summaryText}>{counts.failed} failed</Text>
            </View>
          )}

          {counts.syncing > 0 && (
            <View style={styles.summaryRow}>
              <Ionicons name="sync" size={16} color="#2196F3" />
              <Text style={styles.summaryText}>{counts.syncing} syncing</Text>
            </View>
          )}

          {counts.pending > 0 && (
            <View style={styles.summaryRow}>
              <Ionicons name="time" size={16} color="#ff9800" />
              <Text style={styles.summaryText}>{counts.pending} queued</Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          style={styles.detailsToggle}
          onPress={() => setExpanded(!expanded)}
        >
          <Text style={styles.detailsToggleText}>
            {expanded ? 'Hide Details' : 'Show Details'}
          </Text>
          <Ionicons
            name={expanded ? 'chevron-up' : 'chevron-down'}
            size={16}
            color="#2196F3"
          />
        </TouchableOpacity>

        {expanded && (
          <FlatList
            data={items}
            keyExtractor={item => item.id}
            renderItem={renderSyncItem}
            style={styles.itemList}
            showsVerticalScrollIndicator={false}
          />
        )}

        <View style={styles.actions}>
          {canCancel && !isComplete && onCancel && (
            <TouchableOpacity style={styles.cancelButton} onPress={onCancel}>
              <Text style={styles.cancelButtonText}>Cancel Sync</Text>
            </TouchableOpacity>
          )}

          {isComplete && (
            <TouchableOpacity style={styles.doneButton} onPress={onClose}>
              <Text style={styles.doneButtonText}>Done</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modal: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  progressSection: {
    padding: 20,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#e0e0e0',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#2196F3',
    borderRadius: 4,
  },
  progressText: {
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  summarySection: {
    paddingHorizontal: 20,
    gap: 8,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  summaryText: {
    fontSize: 14,
    color: '#666',
  },
  detailsToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    gap: 8,
  },
  detailsToggleText: {
    fontSize: 14,
    color: '#2196F3',
    fontWeight: '500',
  },
  itemList: {
    flex: 1,
    paddingHorizontal: 20,
  },
  syncItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  syncItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  syncItemName: {
    flex: 1,
    fontSize: 14,
    color: '#333',
  },
  errorContainer: {
    marginTop: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  errorText: {
    flex: 1,
    fontSize: 12,
    color: '#f44336',
  },
  retryButton: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    backgroundColor: '#f44336',
    borderRadius: 4,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  actions: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  cancelButton: {
    padding: 16,
    borderWidth: 1,
    borderColor: '#f44336',
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#f44336',
    fontSize: 16,
    fontWeight: '500',
  },
  doneButton: {
    padding: 16,
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    alignItems: 'center',
  },
  doneButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
});
```

## Conflict Resolution UX

### Conflict Resolution Modal

```typescript
import React, { useState } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export interface ConflictField {
  field: string;
  localValue: any;
  remoteValue: any;
  displayName: string;
  description?: string;
}

interface ConflictResolutionModalProps {
  visible: boolean;
  onResolve: (resolutions: Record<string, 'local' | 'remote'>) => void;
  onCancel: () => void;
  conflicts: ConflictField[];
  itemName: string;
  itemType: string;
}

export const ConflictResolutionModal: React.FC<ConflictResolutionModalProps> = ({
  visible,
  onResolve,
  onCancel,
  conflicts,
  itemName,
  itemType,
}) => {
  const [resolutions, setResolutions] = useState<Record<string, 'local' | 'remote'>>({});

  const handleFieldChoice = (field: string, choice: 'local' | 'remote') => {
    setResolutions(prev => ({
      ...prev,
      [field]: choice,
    }));
  };

  const handleResolveAll = (choice: 'local' | 'remote') => {
    const allResolutions: Record<string, 'local' | 'remote'> = {};
    conflicts.forEach(conflict => {
      allResolutions[conflict.field] = choice;
    });
    setResolutions(allResolutions);
  };

  const canResolve = conflicts.every(conflict =>
    resolutions[conflict.field] !== undefined
  );

  const handleResolve = () => {
    if (canResolve) {
      onResolve(resolutions);
    }
  };

  const formatValue = (value: any): string => {
    if (value === null || value === undefined) {
      return '(empty)';
    }
    if (typeof value === 'object') {
      return JSON.stringify(value, null, 2);
    }
    return String(value);
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onCancel}
    >
      <View style={styles.modal}>
        <View style={styles.header}>
          <View style={styles.titleContainer}>
            <Ionicons name="git-merge-outline" size={24} color="#9c27b0" />
            <Text style={styles.title}>Resolve Conflicts</Text>
          </View>
          <TouchableOpacity onPress={onCancel}>
            <Ionicons name="close" size={24} color="#333" />
          </TouchableOpacity>
        </View>

        <View style={styles.infoSection}>
          <Text style={styles.itemName}>{itemName}</Text>
          <Text style={styles.description}>
            This {itemType} was modified both locally and remotely.
            Please choose which version to keep for each conflicting field.
          </Text>
        </View>

        <View style={styles.quickActions}>
          <TouchableOpacity
            style={styles.quickActionButton}
            onPress={() => handleResolveAll('local')}
          >
            <Text style={styles.quickActionText}>Keep All Local</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.quickActionButton}
            onPress={() => handleResolveAll('remote')}
          >
            <Text style={styles.quickActionText}>Keep All Remote</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.conflictList} showsVerticalScrollIndicator={false}>
          {conflicts.map((conflict, index) => (
            <View key={conflict.field} style={styles.conflictItem}>
              <Text style={styles.fieldName}>{conflict.displayName}</Text>
              {conflict.description && (
                <Text style={styles.fieldDescription}>{conflict.description}</Text>
              )}

              <View style={styles.choicesContainer}>
                <TouchableOpacity
                  style={[
                    styles.choiceCard,
                    resolutions[conflict.field] === 'local' && styles.choiceCardSelected,
                  ]}
                  onPress={() => handleFieldChoice(conflict.field, 'local')}
                >
                  <View style={styles.choiceHeader}>
                    <Text style={styles.choiceLabel}>Your Version</Text>
                    <View style={[
                      styles.choiceRadio,
                      resolutions[conflict.field] === 'local' && styles.choiceRadioSelected,
                    ]} />
                  </View>
                  <ScrollView style={styles.valueContainer} nestedScrollEnabled>
                    <Text style={styles.valueText}>
                      {formatValue(conflict.localValue)}
                    </Text>
                  </ScrollView>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.choiceCard,
                    resolutions[conflict.field] === 'remote' && styles.choiceCardSelected,
                  ]}
                  onPress={() => handleFieldChoice(conflict.field, 'remote')}
                >
                  <View style={styles.choiceHeader}>
                    <Text style={styles.choiceLabel}>Server Version</Text>
                    <View style={[
                      styles.choiceRadio,
                      resolutions[conflict.field] === 'remote' && styles.choiceRadioSelected,
                    ]} />
                  </View>
                  <ScrollView style={styles.valueContainer} nestedScrollEnabled>
                    <Text style={styles.valueText}>
                      {formatValue(conflict.remoteValue)}
                    </Text>
                  </ScrollView>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </ScrollView>

        <View style={styles.actions}>
          <TouchableOpacity style={styles.cancelButton} onPress={onCancel}>
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.resolveButton,
              !canResolve && styles.resolveButtonDisabled,
            ]}
            onPress={handleResolve}
            disabled={!canResolve}
          >
            <Text style={[
              styles.resolveButtonText,
              !canResolve && styles.resolveButtonTextDisabled,
            ]}>
              Resolve Conflicts
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modal: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  infoSection: {
    padding: 20,
    backgroundColor: '#f8f9fa',
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  description: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  quickActions: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
  },
  quickActionButton: {
    flex: 1,
    padding: 12,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    alignItems: 'center',
  },
  quickActionText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  conflictList: {
    flex: 1,
    paddingHorizontal: 20,
  },
  conflictItem: {
    marginBottom: 24,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  fieldName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  fieldDescription: {
    fontSize: 12,
    color: '#666',
    marginBottom: 12,
  },
  choicesContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  choiceCard: {
    flex: 1,
    borderWidth: 2,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
  },
  choiceCardSelected: {
    borderColor: '#2196F3',
    backgroundColor: '#f3f8ff',
  },
  choiceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  choiceLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  choiceRadio: {
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#e0e0e0',
  },
  choiceRadioSelected: {
    borderColor: '#2196F3',
    backgroundColor: '#2196F3',
  },
  valueContainer: {
    maxHeight: 100,
    backgroundColor: '#f8f9fa',
    borderRadius: 4,
    padding: 8,
  },
  valueText: {
    fontSize: 12,
    fontFamily: 'monospace',
    color: '#333',
  },
  actions: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  cancelButton: {
    flex: 1,
    padding: 16,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#666',
    fontSize: 16,
    fontWeight: '500',
  },
  resolveButton: {
    flex: 2,
    padding: 16,
    backgroundColor: '#2196F3',
    borderRadius: 8,
    alignItems: 'center',
  },
  resolveButtonDisabled: {
    backgroundColor: '#e0e0e0',
  },
  resolveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resolveButtonTextDisabled: {
    color: '#9e9e9e',
  },
});
```

## Optimistic UI Patterns

### Optimistic Update Hook

```typescript
import { useState, useCallback } from 'react';

export interface OptimisticState<T> {
  data: T;
  isOptimistic: boolean;
  isLoading: boolean;
  error: string | null;
}

export const useOptimisticUpdate = <T>(
  initialData: T,
  syncFn: (data: T) => Promise<T>
) => {
  const [state, setState] = useState<OptimisticState<T>>({
    data: initialData,
    isOptimistic: false,
    isLoading: false,
    error: null,
  });

  const updateOptimistically = useCallback(async (newData: T) => {
    // Apply optimistic update immediately
    setState(prev => ({
      ...prev,
      data: newData,
      isOptimistic: true,
      error: null,
    }));

    try {
      // Start background sync
      setState(prev => ({ ...prev, isLoading: true }));

      const syncedData = await syncFn(newData);

      // Replace optimistic data with server response
      setState({
        data: syncedData,
        isOptimistic: false,
        isLoading: false,
        error: null,
      });

      return { success: true, data: syncedData };
    } catch (error) {
      // Keep optimistic data but show error
      setState(prev => ({
        ...prev,
        isOptimistic: true,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Sync failed',
      }));

      return { success: false, error };
    }
  }, [syncFn]);

  const revert = useCallback(() => {
    setState(prev => ({
      ...prev,
      data: initialData,
      isOptimistic: false,
      error: null,
    }));
  }, [initialData]);

  return {
    ...state,
    updateOptimistically,
    revert,
  };
};
```

### Optimistic List Component

```typescript
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useOptimisticUpdate } from '../hooks/useOptimisticUpdate';

interface OptimisticListItemProps {
  item: any;
  onUpdate: (item: any) => Promise<any>;
  onRemove?: (item: any) => Promise<void>;
  renderContent: (item: any) => React.ReactNode;
}

export const OptimisticListItem: React.FC<OptimisticListItemProps> = ({
  item,
  onUpdate,
  onRemove,
  renderContent,
}) => {
  const { data, isOptimistic, isLoading, error, updateOptimistically, revert } =
    useOptimisticUpdate(item, onUpdate);

  const handleRemove = async () => {
    if (onRemove) {
      try {
        await onRemove(data);
      } catch (error) {
        // Handle remove error
        console.error('Failed to remove item:', error);
      }
    }
  };

  return (
    <View style={[
      styles.container,
      isOptimistic && styles.containerOptimistic,
      error && styles.containerError,
    ]}>
      <View style={styles.content}>
        {renderContent(data)}
      </View>

      <View style={styles.statusContainer}>
        {isLoading && (
          <View style={styles.statusIndicator}>
            <Ionicons name="sync" size={14} color="#2196F3" />
            <Text style={styles.statusText}>Syncing...</Text>
          </View>
        )}

        {isOptimistic && !isLoading && !error && (
          <View style={styles.statusIndicator}>
            <Ionicons name="time-outline" size={14} color="#ff9800" />
            <Text style={styles.statusText}>Pending sync</Text>
          </View>
        )}

        {error && (
          <View style={styles.errorContainer}>
            <View style={styles.statusIndicator}>
              <Ionicons name="alert-circle-outline" size={14} color="#f44336" />
              <Text style={[styles.statusText, styles.errorText]}>Sync failed</Text>
            </View>
            <TouchableOpacity
              style={styles.retryButton}
              onPress={() => updateOptimistically(data)}
            >
              <Text style={styles.retryButtonText}>Retry</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.revertButton}
              onPress={revert}
            >
              <Text style={styles.revertButtonText}>Undo</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 8,
    marginVertical: 4,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  containerOptimistic: {
    borderLeftWidth: 4,
    borderLeftColor: '#ff9800',
  },
  containerError: {
    borderLeftColor: '#f44336',
  },
  content: {
    padding: 16,
  },
  statusContainer: {
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statusText: {
    fontSize: 12,
    color: '#666',
  },
  errorText: {
    color: '#f44336',
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  retryButton: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: '#f44336',
    borderRadius: 4,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 11,
    fontWeight: '500',
  },
  revertButton: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
  },
  revertButtonText: {
    color: '#666',
    fontSize: 11,
  },
});
```

## Testing Offline UX Patterns

### UX Testing Utilities

```typescript
export class OfflineUXTestUtils {
  static simulateNetworkConditions(condition: 'offline' | 'slow' | 'fast') {
    // Mock NetInfo for testing
    const mockNetInfo = {
      offline: {
        isConnected: false,
        isInternetReachable: false,
        type: 'none',
      },
      slow: {
        isConnected: true,
        isInternetReachable: true,
        type: 'cellular',
        details: { cellularGeneration: '2g' },
      },
      fast: {
        isConnected: true,
        isInternetReachable: true,
        type: 'wifi',
      },
    };

    return mockNetInfo[condition];
  }

  static async testOptimisticUpdate() {
    const mockSyncFn = jest.fn().mockResolvedValue({ id: 1, updated: true });
    const initialData = { id: 1, name: 'test' };

    // Test would use useOptimisticUpdate hook
    // Verify optimistic state is applied immediately
    // Verify sync function is called
    // Verify final state after sync
  }

  static testErrorRecoveryFlow() {
    const mockError = {
      type: 'network' as const,
      message: 'Network connection lost',
      retryable: true,
      timestamp: Date.now(),
    };

    // Test error display
    // Test retry functionality
    // Test error dismissal
  }
}
```

## Related Documentation
- [Mobile Authentication Patterns](./authentication-patterns.md) - Secure authentication and session management
- [Mobile Offline Sync Patterns](./offline-sync-patterns.md) - Advanced sync queue and conflict resolution
- [Mobile Survey Upload Patterns](./survey-upload-patterns.md) - Image compression and upload optimization
- [Mobile Development Patterns](./development-patterns.md) - Core React Native patterns and best practices

---
**Status**: ✅ Current
**Last Updated**: 2025-07-09
**Technology Stack**: React Native, TypeScript, Expo, NetInfo, expo-local-authentication, MMKV
