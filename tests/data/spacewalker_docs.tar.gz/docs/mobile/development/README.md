# Mobile Development Guide

## Purpose
Comprehensive development guide for the React Native/Expo mobile application including environment setup, development workflows, and production building.

## When to Use This
- Setting up mobile development environment with Expo and React Native
- Daily mobile development workflows and debugging
- Building and deploying mobile app to app stores
- Keywords: React Native development, Expo development, mobile debugging, app deployment

## Prerequisites
- [ ] Docker and Docker Compose installed
- [ ] Project cloned and `just` command available
- [ ] Expo Go app installed on mobile device for testing
- [ ] Basic familiarity with React Native and TypeScript

## Technology Stack

### Core Technologies
- **Framework**: React Native 0.76.6
- **SDK**: Expo SDK 52
- **Language**: TypeScript
- **UI Library**: React Native Paper
- **Navigation**: React Navigation
- **State Management**: React Context
- **Offline Storage**: MMKV

### Development Tools
- **Metro**: JavaScript bundler for React Native
- **Expo CLI**: Development and build tooling
- **Jest**: Testing framework
- **TypeScript**: Type checking and development experience

## Quick Start

### Essential Commands
```bash
# Start everything for local mobile development (backend+admin, then Expo Go)
just up local

# Or start Expo Go/dev client directly
just expo start --offline           # Expo Go (offline)
just expo start --dev-client --ios  # Dev client + iOS Simulator

# Run mobile tests
just test unit mobile

# Open shell into mobile container (if running via services)
just shell mobile

# Build binaries via EAS
just expo build ios preview --wait
just expo build android preview --wait
just expo build all production-testing --wait --json
```

## Development Environment

The mobile app runs via the Expo development server, orchestrated by `just` and Docker. All commands should be run from the **project root**.

### Development Features
- **Hot Reloading**: Fast Refresh for instant code updates
- **Cross-Platform**: Single codebase for iOS and Android
- **Expo Go**: Quick testing on physical devices
- **TypeScript**: Type safety and better development experience

### Environment Setup
1. **Start Development Server**: `just up local` or `just expo start --offline`
2. **View QR Code**: Displayed in terminal for device connection
3. **Connect Device**: Use Expo Go app to scan QR code
4. **Network Requirements**: Device and development machine on same Wi-Fi

## Device and Emulator Connection

### Physical Device Setup
1. **Install Expo Go**:
   - iOS: Download from App Store
   - Android: Download from Google Play Store

2. **Connect Device**:
```bash
# Start development server
just expo start --offline

# Scan QR code with Expo Go app
# Ensure same Wi-Fi network as development machine
```

3. **Network Troubleshooting**:
```bash
# Fix IP address issues
just expo ip auto

# Check network connectivity
# Ensure firewall allows Metro (8081) connection
```

### Emulator Setup
- **iOS Simulator (macOS)**: Install Xcode (App Store) and Command Line Tools
  - List devices: `just expo simulator list`
  - Boot a device: `just expo simulator boot <udid-or-name>`
  - Start with dev server: `just expo start --ios`
- **Android Emulator**: Install Android Studio and create an AVD
  - List AVDs: `just expo emulator list`
  - Start AVD: `just expo emulator start <name>`
  - Start with dev server: `just expo start --android`
  - Optional: `adb reverse tcp:8000 tcp:8000` for host API access when needed
  
See also: `docs/mobile/emulators.md` for full installation steps.

## Development Workflow

### Daily Development Process
1. **Start Server**: `just up local` (or `just expo start --offline`)
2. **Connect Device**: Scan QR code with Expo Go
3. **Make Changes**: Edit files in `apps/mobile/src/`
4. **Auto-Reload**: Changes appear instantly via Fast Refresh
5. **Test Features**: Use app on device/emulator
6. **Run Tests**: `just test unit mobile` for verification

### Hot Reloading and Debugging
- **Fast Refresh**: Automatic code updates without losing state
- **Developer Menu**: Shake device or press `d` in terminal
- **JavaScript Debugger**: Access Chrome DevTools for debugging
- **Element Inspector**: Visual component inspection
- **Performance Monitor**: Real-time performance metrics

### Offline Development and Testing

#### Testing Offline Functionality
```bash
# 1. Start app and let it load completely
just expo start --offline

# 2. Perform online actions (surveys, data sync)

# 3. Disable device connectivity:
#    - Turn off Wi-Fi
#    - Turn off cellular data

# 4. Test offline features:
#    - Create surveys
#    - Capture photos
#    - Navigate app

# 5. Re-enable connectivity and verify sync
```

#### Offline Storage Patterns
- **MMKV Storage**: Fast, synchronous key-value storage
- **Survey Data**: Local storage with sync queue
- **Photo Management**: Local file system with upload queue
- **State Persistence**: App state survival across restarts

## Project Structure

```
apps/mobile/
├── src/
│   ├── components/     # Reusable UI components
│   ├── screens/        # App screen components
│   ├── navigation/     # Navigation configuration
│   ├── services/       # API and storage services
│   ├── hooks/          # Custom React hooks
│   ├── utils/          # Utility functions
│   └── types/          # TypeScript type definitions
├── assets/            # Images, fonts, static assets
├── __tests__/         # Jest test files
├── app.config.js      # Expo configuration
└── package.json       # Dependencies and scripts
```

### Code Organization Patterns
- **Screen Components**: Page-level components in `screens/`
- **Reusable Components**: Shared UI components in `components/`
- **Service Layer**: API calls and data management in `services/`
- **Custom Hooks**: React hooks for reusable logic in `hooks/`

## Testing Strategy

### Test Types and Tools
- **Unit Tests**: Jest for component and utility testing
- **Integration Tests**: Screen-level component testing
- **E2E Testing**: Manual testing with Expo Go
- **Performance Testing**: Metro bundler analysis

### Running Tests
```bash
# Run all mobile tests
just test unit mobile

# Run tests in watch mode
cd apps/mobile && npm test -- --watch

# Run tests with coverage
cd apps/mobile && npm test -- --coverage

# Run specific test file
cd apps/mobile && npm test -- SurveyScreen.test.tsx
```

### Testing Patterns
- **Component Testing**: Render and interaction testing
- **Hook Testing**: Custom hook behavior verification
- **Service Testing**: API call and storage testing
- **Navigation Testing**: Screen transition testing

## Production Building and Deployment

### Build Configuration

#### Current Build Methods (Expo CLI)
```bash
# Development Builds
expo build:ios --type simulator
expo build:android --type apk

# Production Builds (using Expo Build Service)
expo build:ios --type archive
expo build:android --type app-bundle
```

#### Future Just Commands (Planned Implementation)
```bash
# iOS Production Build (coming in future release)
# just expo build ios preview --wait

# Android Production Build (coming in future release)  
# just expo build android preview --wait
```

These commands will streamline the build process by wrapping Expo CLI commands with project-specific configuration and automation.

### Over-the-Air (OTA) Updates
```bash
# Publish update to existing builds
expo publish

# Publish to specific release channel
expo publish --release-channel production

# Publish with message
expo publish --message "Bug fixes and performance improvements"
```

### App Store Deployment
#### iOS App Store
1. **Build for iOS**: `expo build:ios --type archive`
2. **Download IPA**: From Expo build dashboard
3. **Upload to App Store**: Use Transporter or Application Loader
4. **App Store Review**: Submit for Apple review process

#### Google Play Store
1. **Build for Android**: `expo build:android --type app-bundle`
2. **Download AAB**: From Expo build dashboard
3. **Upload to Play Console**: Use Google Play Console
4. **Play Store Review**: Submit for Google review process

## Common Issues and Solutions

### Development Environment Issues

| Symptom | Cause | Solution |
|---------|-------|----------|
| **QR Code Not Scanning** | Network connectivity issues | Run `just expo ip auto` and ensure same Wi-Fi network |
| **Metro Bundle Error** | Port conflict or cache issues | Clear Metro cache: `npx react-native start --reset-cache` |
| **Expo Go Connection Failed** | Firewall or network restrictions | Check firewall settings, try USB connection |
| **Hot Reload Not Working** | Fast Refresh disabled or error | Enable in developer menu, check for syntax errors |

### Build and Deployment Issues

| Symptom | Cause | Solution |
|---------|-------|----------|
| **Build Timeout** | Large bundle size or slow network | Optimize bundle, check network connection |
| **Missing Dependencies** | Package not installed or outdated | Run `npm install` and check package.json |
| **Platform-Specific Errors** | iOS/Android configuration issues | Check app.config.js and platform-specific settings |
| **OTA Update Not Appearing** | Cache or version mismatch | Clear app cache, check release channel |

### Performance Issues

| Symptom | Cause | Solution |
|---------|-------|----------|
| **Slow App Startup** | Large bundle or excessive imports | Analyze bundle with Metro, implement code splitting |
| **Memory Leaks** | Uncleaned subscriptions or listeners | Review useEffect cleanup, check for memory leaks |
| **Slow Navigation** | Heavy screens or blocking operations | Optimize screen components, use lazy loading |
| **Photo Upload Issues** | Large file sizes or network issues | Implement image compression, retry logic |

## Development Best Practices

### Code Quality
- **TypeScript**: Use strict typing for all components and services
- **Component Structure**: Keep components small and focused
- **Custom Hooks**: Extract reusable logic into custom hooks
- **Error Boundaries**: Implement error boundaries for graceful error handling

### Performance Optimization
- **Image Optimization**: Compress images and use appropriate formats
- **Bundle Size**: Monitor and optimize bundle size regularly
- **State Management**: Use React Context efficiently, avoid unnecessary re-renders
- **Navigation**: Implement lazy loading for screens

### Platform Considerations
- **iOS Guidelines**: Follow Apple Human Interface Guidelines
- **Android Guidelines**: Follow Material Design principles
- **Responsive Design**: Test on various screen sizes and orientations
- **Accessibility**: Implement proper accessibility labels and navigation

## Planned Features

### Crash Reporting Integration
- **Service**: Sentry integration for crash monitoring
- **Real-time Monitoring**: Production crash tracking and analysis
- **Performance Metrics**: App performance monitoring and optimization
- **User Feedback**: Crash report collection and user feedback

## Screen-by-Screen Implementation Specifications

### Authentication Screens

#### Login Screen Implementation
- **Purpose**: User authentication and tenant access
- **Key Features**:
  - Email/password form validation with real-time feedback
  - Secure token storage via Expo SecureStore
  - Auto-navigation on successful authentication
  - Error handling for invalid credentials with user-friendly messages
- **Implementation**: Entry point → Home Screen on success
- **Offline Support**: Token presence check with planned full offline validation

### Core Navigation Screens

#### Home Screen Implementation
- **Purpose**: Main dashboard and navigation hub
- **Key Features**:
  - Quick action buttons (Start Survey, View Inventory) with touch feedback
  - User profile display with avatar and tenant information
  - Logout functionality with confirmation dialog
  - App branding and personalized welcome message
- **State Management**: Authentication state, user profile persistence

#### Building Selection Screen Implementation
- **Purpose**: Choose building for survey with tenant filtering
- **Key Features**:
  - Tenant-filtered building list with search and filter capabilities
  - Building metadata display (address, floor count, survey status)
  - Pull-to-refresh functionality for data updates
  - Loading states and error handling
- **API Integration**: `/api/buildings/` endpoint with pagination
- **Navigation Flow**: Home → Floor Selection

#### Room Selection Screen Implementation
- **Purpose**: Choose specific room for survey with advanced filtering
- **Key Features**:
  - Room list with search functionality (name, FICM code)
  - Room status indicators (surveyed/pending) with visual badges
  - FICM code display and room metadata
  - Room capacity and type information display
- **API Integration**: `/api/rooms/?floor_id={id}` endpoint
- **Navigation Flow**: Floor Selection → Camera Screen

### Survey Workflow Implementation

#### Camera Screen Implementation
- **Purpose**: Photo capture and image management with optimization
- **Key Features**:
  - Expo Camera integration with permission handling
  - Multiple photo capture with preview gallery
  - Image gallery access for existing photos
  - Photo preview and deletion capabilities
  - Image metadata collection (location, timestamp, device info)
  - Real-time image compression and optimization
- **Device Integration**: Camera permissions, image picker, file system access
- **Performance**: Image compression, thumbnail generation, memory management

#### Analysis Results Screen Implementation
- **Purpose**: Display AI analysis results with confidence visualization
- **Key Features**:
  - AI-generated attribute display with confidence scores
  - Processing status indicators with progress animation
  - Error handling for AI failures with retry options
  - Image thumbnail gallery with zoom capability
  - Results export and sharing functionality
- **AI Integration**: Real-time processing via `/api/ai/analyze-image`
- **UX Patterns**: Loading states, error boundaries, progressive disclosure

#### Attribute Review Screen Implementation
- **Purpose**: Manual attribute editing and validation with AI assistance
- **Key Features**:
  - Editable attribute forms with validation feedback
  - FICM code integration and classification assistance
  - Confidence score display with visual indicators
  - Add/remove custom attributes functionality
  - AI suggestion integration with accept/reject options
- **State Management**: Form state, validation state, undo/redo functionality
- **Accessibility**: Screen reader support, keyboard navigation, high contrast mode

### UX Patterns and Guidelines

#### Form Design Patterns
- **Input Validation**: Real-time validation with clear error messages
- **Touch Targets**: Minimum 44pt touch targets for accessibility
- **Visual Feedback**: Loading states, success/error indicators, progress bars
- **Error Handling**: Graceful error recovery with actionable error messages

#### Navigation UX Patterns
- **Breadcrumb Navigation**: Clear navigation hierarchy with back button support
- **Tab Navigation**: Bottom tab navigation for main app sections
- **Stack Navigation**: Hierarchical navigation with gesture support
- **Deep Linking**: URL-based navigation for notifications and sharing

#### Accessibility Implementation
- **Screen Reader Support**: Comprehensive accessibility labels and hints
- **Voice Control**: Integration with device voice control features
- **Motor Accessibility**: Support for external switches and alternative input methods
- **Visual Accessibility**: High contrast themes, font scaling, focus indicators

#### Performance UX Patterns
- **Progressive Loading**: Skeleton screens and progressive image loading
- **Optimistic Updates**: Immediate UI feedback with rollback on failure
- **Background Sync**: Silent data synchronization with status indicators
- **Memory Management**: Efficient image caching and cleanup strategies

## Related Documentation
- Mobile Architecture Overview → ../mobile/architecture/README.md
- Mobile Navigation Patterns → ./navigation.md
- Mobile State Management → ./state-management.md
- Mobile Offline Strategy → ./offline-first.md
- Backend API Integration → ../backend/architecture/api-contracts.md

---
Last Updated: 2025-06-28
Status: Current
