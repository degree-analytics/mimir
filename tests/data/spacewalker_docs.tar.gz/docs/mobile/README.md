# Mobile App Documentation

**Spacewalker Mobile Application**  
**Platform:** React Native with Expo  
**Last Updated:** 2025-07-08

## Overview

The Spacewalker mobile application is a cross-platform mobile app built with React Native and Expo, designed to provide on-the-go access to workspace management and analytics features.

## 🚀 Quick Start

### Prerequisites
- Node.js 20.19.4+
- Expo CLI: `npm install -g expo-cli`
- EAS CLI: `npm install -g eas-cli`

### Local Development
```bash
# Start the mobile development server
just mobile_dev

# Or manually
cd apps/mobile
npm start
```

### Platform-Specific Development
```bash
# iOS Simulator
just mobile_ios

# Android Emulator
just mobile_android

# Web Browser
just mobile_web
```

## 📱 Platform Support

### iOS
- **Minimum Version:** iOS 13.0+
- **TestFlight Distribution:** Automated via CI/CD
- **App Store:** Production deployment via EAS
- **Bundle ID:** com.degreeanalytics.spacewalker

### Android
- **Minimum Version:** Android 8.0+ (API 26)
- **Google Play Store:** Automated distribution
- **Bundle ID:** com.degreeanalytics.spacewalker
- **Architecture:** ARM64, ARMv7, x86_64

## 📚 Documentation Structure

### Core Documentation
- **[Architecture](./architecture/README.md)** - App architecture and design patterns
- **[Development Patterns](./development-patterns.md)** - Coding standards and patterns
- **[Requirements](./requirements.md)** - Functional and technical requirements

### Deployment & CI/CD
- **[Android Deployment Guide](./android-deployment-guide.md)** - Complete Android deployment process
- **[GitHub Actions Configuration](./deployment/github-actions-config.md)** - CI/CD pipeline setup
- **[Deployment Overview](./deployment/README.md)** - General deployment information

### Development
- **[Development Setup](./development/README.md)** - Local development environment
- **[Testing Guide](./testing/README.md)** - Testing strategies and tools
- **[Security Guidelines](./security/README.md)** - Security best practices

### Components & Features
- **[App Components](./app-components.md)** - Component library and usage
- **[Navigation](./architecture/navigation.md)** - App navigation structure
- **[State Management](./architecture/state-management.md)** - Global state patterns
- **[Offline-First Architecture](./architecture/offline-first.md)** - Offline capabilities

## 🛠️ Development Commands

### Essential Commands
```bash
# Development
just mobile_dev                    # Start development server
just mobile_test                   # Run mobile tests
just mobile_lint                   # Lint mobile code

# Building
just android_build_prod            # Build Android production
# For mobile builds, use EAS directly:
cd apps/mobile && eas build --profile preview       # Build preview version
cd apps/mobile && eas build --profile development   # Build development version

# Deployment
just android_submit_playstore production  # Submit to Google Play
just android_release_status              # Check deployment status
just android_validate_config             # Validate EAS configuration
```

### Advanced Commands
```bash
# Release Management
just android_generate_release_notes      # Generate release notes
just android_promote_track internal production  # Get promotion guide

# CI/CD Testing
just test unit mobile                  # Test mobile unit tests
just mobile_ci_status                    # Check EAS build status

# Configuration
just mobile_health                       # Check mobile health
npm run validate:eas                     # Validate EAS config
npm run test:submission                  # Test submission config
```

## 🏗️ Architecture Overview

### Technology Stack
- **Framework:** React Native 0.81.4
- **Platform:** Expo SDK 54
- **Language:** TypeScript 5.8.3
- **State Management:** React Context + Hooks
- **Navigation:** React Navigation 7
- **UI Components:** React Native Paper
- **Testing:** Jest + React Native Testing Library

### Key Features
- **Dual-Mode Configuration** - Supports both build-time (EXPO_PUBLIC_) and runtime configuration
- **Environment-Specific Builds** - Development, Preview, and Production environments
- **Automated CI/CD** - GitHub Actions with EAS Build integration
- **Offline-First Design** - Local data caching and sync capabilities
- **Cross-Platform** - Single codebase for iOS and Android

### Environment Configuration
| Environment | API Endpoint | Bundle ID | Use Case |
|-------------|-------------|-----------|----------|
| Development | localhost:8000 | .dev | Local development |
| Preview | backend.spacewalker.littleponies.com | .preview | Internal testing |
| Production | api.spacewalker.com | (base) | Public release |

## 🚀 Deployment Process

### Automated Deployment (Recommended)
1. **Development:** Create PR → Triggers development build
2. **Preview:** Merge to `dev` → Builds and submits to internal testing
3. **Production:** Merge to `main` → Builds and submits to production track (draft)

### Manual Deployment
1. **Build:** `just android_build_prod`
2. **Submit:** `just android_submit_playstore production`
3. **Monitor:** `just android_release_status`

### Release Tracks
- **Internal:** Team testing and QA
- **Production:** Public app store release with staged rollout

## 🧪 Testing Strategy

### Test Types
- **Unit Tests:** Component and utility testing
- **Integration Tests:** API and navigation testing
- **E2E Tests:** Critical user flow testing
- **Manual Testing:** Device testing via TestFlight/Internal Track

### Running Tests
```bash
# All tests
just mobile_test

# Specific test types
cd apps/mobile
npm test                    # Unit tests
npm run test:watch          # Watch mode
npm run test:coverage       # Coverage report
```

## 🔧 Configuration Management

### Environment Variables
The app uses a dual-mode configuration system:

#### Build-Time Variables (EXPO_PUBLIC_)
```bash
EXPO_PUBLIC_API_BASE_URL=https://api.spacewalker.com
EXPO_PUBLIC_APP_VARIANT=production
EXPO_PUBLIC_BUNDLE_ID_ANDROID=com.degreeanalytics.spacewalker
```

#### Runtime Variables (app.config.js)
```javascript
export default {
  extra: {
    API_URL: process.env.API_URL || 'http://localhost:8000',
    ENVIRONMENT: process.env.ENVIRONMENT || 'development'
  }
}
```

### Configuration Files
- **eas.json** - EAS build and submission configuration
- **app.config.js** - Dynamic Expo configuration
- **package.json** - Dependencies and scripts
- **tsconfig.json** - TypeScript configuration

## 🛡️ Security Considerations

### Build Security
- Remote credential management via EAS
- Keystore protection with .gitignore
- Service account key security
- Staged rollouts for production releases

### Code Security
- TypeScript for type safety
- ESLint for code quality
- Dependency vulnerability scanning
- Secure API communication (HTTPS only)

### Data Security
- Local data encryption for sensitive information
- Secure token storage via SecureStore
- Network security with certificate pinning
- Privacy-first data handling

## 🚨 Troubleshooting

### Common Issues
- **Build Failures:** Check [Android Deployment Guide](./android-deployment-guide.md#troubleshooting)
- **Configuration Issues:** Run `just android_validate_config`
- **Environment Problems:** Verify `npm run validate:eas`
- **CI/CD Issues:** Check GitHub Actions logs

### Debug Commands
```bash
# Configuration validation
just android_validate_config
npm run validate:eas
npm run test:submission

# Build status
just mobile_ci_status
just android_release_status

# Health checks
just mobile_health
just health
```

### Getting Help
1. Check the troubleshooting sections in specific guides
2. Validate configuration with provided commands
3. Review GitHub Actions logs for CI/CD issues
4. Consult the [Android Deployment Guide](./android-deployment-guide.md) for deployment issues

## 📋 Production Checklist

### Pre-Deployment
- [ ] All tests passing (`just mobile_test`)
- [ ] Configuration validated (`just android_validate_config`)
- [ ] Environment variables configured
- [ ] Build succeeds locally (`just android_build_prod`)

### Deployment
- [ ] Code reviewed and approved
- [ ] Merged to appropriate branch (dev/main)
- [ ] CI/CD pipeline completes successfully
- [ ] Build appears in appropriate track (internal/production)

### Post-Deployment
- [ ] App installs and launches correctly
- [ ] Core functionality verified
- [ ] Crash reports monitored
- [ ] User feedback reviewed
- [ ] Gradual rollout (20% → 50% → 100%)

## 🔗 External Resources

### Expo & React Native
- [Expo Documentation](https://docs.expo.dev/)
- [React Native Documentation](https://reactnative.dev/docs/getting-started)
- [EAS Build Documentation](https://docs.expo.dev/build/introduction/)

### App Stores
- [Google Play Console](https://play.google.com/console)
- [App Store Connect](https://appstoreconnect.apple.com)

### Development Tools
- [React Navigation](https://reactnavigation.org/)
- [React Native Paper](https://reactnativepaper.com/)
- [TypeScript](https://www.typescriptlang.org/)

---

## 📱 Platform-Specific Guides

### Android Development
- **[Complete Android Deployment Guide](./android-deployment-guide.md)** - Step-by-step Google Play Store deployment
- **[Android Architecture Notes](./architecture/mobile-container-architecture.md)** - Android-specific implementation details

### iOS Development
- iOS deployment guide (coming soon)
- TestFlight distribution setup
- App Store submission process

---

**🚀 Quick Links:**
- [Android Deployment](./android-deployment-guide.md)
- [Architecture Overview](./architecture/README.md)
- [Development Patterns](./development-patterns.md)
- [GitHub Actions CI/CD](./deployment/github-actions-config.md)

---

*Last updated: 2025-07-08 | Next review: 2025-08-08*