# AdminLayout Component Guide

## Purpose
Comprehensive guide for using the AdminLayout component in SpaceWalker admin pages. The AdminLayout component provides standardized layout patterns, responsive design, cross-browser compatibility, and consistent user experience across all administrative interfaces.

## When to Use This
- Implementing new admin pages or components
- Converting existing pages to AdminLayout standard
- Understanding layout variants and configuration options
- Troubleshooting layout issues and browser compatibility
- Following established design patterns and responsive behavior

**Keywords:** AdminLayout component, layout standards, responsive design, admin pages, Material-UI

---

## 🎯 Quick Start

### Basic Implementation
```typescript
import { AdminLayout } from '../components/AdminLayout';

export default function MyAdminPage() {
  return (
    <AdminLayout title="Page Title">
      <div>Your page content here</div>
    </AdminLayout>
  );
}
```

### Table Layout Example
```typescript
import { AdminLayout } from '../components/AdminLayout';
import { TableContainer, Table, Paper } from '@mui/material';

export default function DataTablePage() {
  return (
    <AdminLayout variant="table" title="Data Management">
      <TableContainer component={Paper}>
        <Table>
          {/* Table content */}
        </Table>
      </TableContainer>
    </AdminLayout>
  );
}
```

---

## 🏗️ Component Architecture

### AdminLayout Interface
```typescript
interface AdminLayoutProps {
  children: React.ReactNode;
  title?: string;
  variant?: 'default' | 'table' | 'form';
  maxWidth?: 'xl' | false;
  disablePadding?: boolean;
  className?: string;
  'data-testid'?: string;
}
```

### Component Features
- **Responsive Container**: Material-UI Container with maxWidth="xl" (1536px) for optimal screen utilization
- **Responsive Padding**: Automatically adjusts padding based on screen size (xs: 16px, sm: 24px, md: 32px)
- **Layout Variants**: Specialized styling for tables, forms, and default content
- **Error Boundaries**: Built-in error handling with development/production error displays
- **Safari Compatibility**: Cross-browser optimizations for WebKit-based browsers
- **DashboardLayout Integration**: Seamless integration with existing navigation structure

---

## 📐 Layout Variants

### Default Variant
Standard layout for general content pages:
```typescript
<AdminLayout variant="default" title="General Page">
  <div>
    <h1>Page Content</h1>
    <p>Standard content layout</p>
  </div>
</AdminLayout>
```

### Table Variant
Optimized for data tables with Safari-specific fixes:
```typescript
<AdminLayout variant="table" title="Data Tables">
  <TableContainer component={Paper}>
    <Table sx={{ minWidth: 650 }}>
      {/* Table automatically gets Safari scroll fixes */}
    </Table>
  </TableContainer>
</AdminLayout>
```

**Table Variant Features:**
- WebkitOverflowScrolling: 'touch' for smooth scrolling
- Automatic table width optimization
- Responsive table behavior on mobile

### Form Variant
Enhanced spacing and styling for form layouts:
```typescript
<AdminLayout variant="form" title="Form Page">
  <form>
    <TextField fullWidth label="Input Field" />
    <Button variant="contained">Submit</Button>
  </form>
</AdminLayout>
```

**Form Variant Features:**
- Optimized spacing for form elements
- Enhanced focus management
- Consistent form field alignment

---

## 🎨 Styling and Customization

### Responsive Padding Function
AdminLayout uses intelligent responsive padding:
```typescript
const getResponsivePadding = () => ({
  xs: 2,  // 16px on mobile
  sm: 3,  // 24px on small tablets
  md: 4   // 32px on desktop
});
```

### Custom Styling
```typescript
<AdminLayout
  className="custom-page-styles"
  sx={{ backgroundColor: 'background.paper' }}
>
  <div>Custom styled content</div>
</AdminLayout>
```

### Disabling Padding
For full-width content that needs custom spacing:
```typescript
<AdminLayout disablePadding>
  <Box sx={{ p: 0 }}>
    {/* Custom padding control */}
  </Box>
</AdminLayout>
```

---

## 🌍 Cross-Browser Compatibility

### Safari-Specific Optimizations
AdminLayout includes automatic Safari fixes:
```typescript
// Applied automatically in table variant
WebkitOverflowScrolling: 'touch',
'& *[style*="overflow"]': {
  WebkitOverflowScrolling: 'touch',
}
```

### Browser Testing Matrix
| Browser | Version Support | AdminLayout Status |
|---------|----------------|-------------------|
| Chrome | Latest 2 versions | ✅ Full support |
| Firefox | Latest 2 versions | ✅ Full support |
| Safari | Latest 2 versions | ✅ Full support with fixes |
| Edge | Latest 2 versions | ✅ Full support |

### Mobile Browser Support
- iOS Safari: Optimized touch scrolling
- Android Chrome: Full responsive behavior
- Mobile viewport: 375px to 1920px+ support

---

## 🛠️ Error Handling

### Built-in Error Boundary
AdminLayout includes comprehensive error handling:
```typescript
// Development mode shows detailed errors
if (process.env.NODE_ENV === 'development') {
  return (
    <div>
      <h2>Layout Error</h2>
      <p>Something went wrong with the page layout.</p>
      <details>
        <summary>Error Details</summary>
        <pre>{error.message}</pre>
      </details>
    </div>
  );
}

// Production mode shows user-friendly message
return (
  <div>
    <h2>Layout Error</h2>
    <p>Something went wrong with the page layout. Please refresh the page.</p>
  </div>
);
```

### Error Recovery
- Automatic error boundary isolation
- Graceful fallback UI
- Development vs production error displays
- Maintains navigation functionality during errors

---

## 📱 Responsive Behavior

### Breakpoint Behavior
AdminLayout adapts to all screen sizes:

**Mobile (xs: 0-599px)**
- Single column layout
- Reduced padding (16px)
- Touch-optimized interactions
- Collapsible navigation

**Tablet (sm: 600-899px)**
- Increased padding (24px)
- Optimized for touch/mouse hybrid
- Responsive table scrolling

**Desktop (md: 900px+)**
- Maximum padding (32px)
- Full feature layout
- Optimal data density

### Container Width Behavior
```typescript
// xl = 1536px maximum width
<Container maxWidth="xl">
  {/* Content utilizes full available screen width up to 1536px */}
</Container>

// false = 100% width (use carefully)
<AdminLayout maxWidth={false}>
  {/* Content uses full viewport width */}
</AdminLayout>
```

---

## 🧪 Testing AdminLayout

### Component Testing
```typescript
import { render, screen } from '@testing-library/react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { AdminLayout } from '../AdminLayout';

const theme = createTheme();

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('AdminLayout', () => {
  it('renders children correctly', () => {
    renderWithTheme(
      <AdminLayout>
        <div data-testid="test-content">Test Content</div>
      </AdminLayout>
    );

    expect(screen.getByTestId('test-content')).toBeInTheDocument();
  });

  it('applies table variant styles', () => {
    renderWithTheme(
      <AdminLayout variant="table" data-testid="admin-layout">
        <div>Table content</div>
      </AdminLayout>
    );

    const layout = screen.getByTestId('admin-layout');
    expect(layout).toBeInTheDocument();
  });
});
```

### Integration Testing
Test AdminLayout with actual page components:
```typescript
describe('AdminLayout Integration', () => {
  it('integrates correctly with data tables', () => {
    renderWithTheme(
      <AdminLayout variant="table" title="Buildings">
        <TableContainer component={Paper}>
          <Table>
            <tbody>
              <tr><td>Test Data</td></tr>
            </tbody>
          </Table>
        </TableContainer>
      </AdminLayout>
    );

    expect(screen.getByText('Test Data')).toBeInTheDocument();
  });
});
```

---

## ✅ Implementation Checklist

### New Page Development
- [ ] Import AdminLayout from correct path
- [ ] Choose appropriate variant (default/table/form)
- [ ] Set meaningful page title
- [ ] Test on mobile, tablet, and desktop
- [ ] Verify Safari compatibility
- [ ] Add appropriate data-testid for testing

### Existing Page Migration
- [ ] Replace existing layout components with AdminLayout
- [ ] Remove duplicate responsive padding code
- [ ] Remove custom Safari fixes (handled by AdminLayout)
- [ ] Update imports and dependencies
- [ ] Test for functionality regression
- [ ] Verify improved screen space utilization

### Code Review Requirements
- [ ] AdminLayout variant appropriate for content type
- [ ] No duplicate layout code or custom padding
- [ ] Proper TypeScript prop usage
- [ ] Error boundaries not overridden
- [ ] Testing includes AdminLayout integration

---

## 🔗 Migration from Legacy Layouts

### Before (Legacy Pattern)
```typescript
// ❌ OLD: Legacy layout pattern
import { ProtectedRoute } from '../components/ProtectedRoute';
import { DashboardLayout } from '../components/DashboardLayout';

export default function OldPage() {
  return (
    <ProtectedRoute>
      <DashboardLayout title="Page Title">
        <Container maxWidth="md" sx={{ p: 3 }}>
          <TableContainer component={Paper}>
            <Table>
              {/* Content */}
            </Table>
          </TableContainer>
        </Container>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
```

### After (AdminLayout Pattern)
```typescript
// ✅ NEW: AdminLayout pattern
import { AdminLayout } from '../components/AdminLayout';

export default function NewPage() {
  return (
    <AdminLayout variant="table" title="Page Title">
      <TableContainer component={Paper}>
        <Table>
          {/* Content */}
        </Table>
      </TableContainer>
    </AdminLayout>
  );
}
```

### Migration Benefits
- **Reduced Code**: 50% less layout boilerplate
- **Better Screen Utilization**: Container maxWidth="xl" instead of "md"
- **Cross-browser Compatibility**: Built-in Safari fixes
- **Consistent Responsive Behavior**: Standardized padding and breakpoints
- **Error Handling**: Built-in error boundaries

---

## 🚨 Common Issues and Solutions

### Issue: Table Not Using Full Width
```typescript
// ❌ Problem
<Table sx={{ width: 'auto' }}>

// ✅ Solution
<AdminLayout variant="table">
  <TableContainer component={Paper}>
    <Table sx={{ minWidth: 650 }}>
```

### Issue: Custom Padding Conflicts
```typescript
// ❌ Problem
<AdminLayout>
  <Container sx={{ p: 5 }}>  {/* Conflicts with AdminLayout padding */}

// ✅ Solution
<AdminLayout disablePadding>
  <Box sx={{ p: 5 }}>  {/* Custom padding with disabled default */}
```

### Issue: Safari Scrolling Problems
```typescript
// ❌ Problem - Manual Safari fixes conflict
<TableContainer sx={{ WebkitOverflowScrolling: 'auto' }}>

// ✅ Solution - Use table variant
<AdminLayout variant="table">
  <TableContainer component={Paper}>  {/* Safari fixes automatic */}
```

---

## 📋 Related Documentation

### Layout Standards
- **[Layout Standards](../../frontend/layout-standards.md)** - Complete layout standards and responsive patterns
- **[Layout Migration Complete](../../workflows/)** - All layout migrations have been successfully completed ✅

### Architecture References
- **[Admin Container Architecture](../architecture/admin-container-architecture.md)** - Complete admin architecture patterns
- **[Component Architecture](../../architecture/component-diagrams.md)** - System component relationships

### Testing and Development
- **[Testing Guide](../../workflows/testing-guide.md)** - Comprehensive component testing strategies

---

**Last Updated:** 2025-07-02
**Status:** Current
**Version:** 1.0
**Component Location:** `apps/admin/src/components/AdminLayout.tsx`
**Test Location:** `apps/admin/src/components/__tests__/AdminLayout.test.tsx`

---

*This guide provides comprehensive documentation for using AdminLayout effectively across all admin interface development, ensuring consistent user experience and maintainable code patterns.*
