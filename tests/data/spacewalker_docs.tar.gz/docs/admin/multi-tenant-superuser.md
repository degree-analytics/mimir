# Multi-Tenant Superuser Features

## Purpose
Documents the superuser capabilities for managing and switching between multiple tenants in the Spacewalker admin interface, including the X-Selected-Tenant-Id header mechanism.

## When to Use This
- Superusers needing to access different tenant contexts
- Debugging tenant-specific issues
- Testing multi-tenant functionality
- Viewing data across different organizations

**Keywords:** superuser, multi-tenant, tenant switching, X-Selected-Tenant-Id, context switching

## Overview

Superusers in Spacewalker have special privileges to view and manage data across all tenants. This document explains how superusers can switch between tenant contexts and the technical implementation details.

## Superuser Tenant Selection

### Frontend Implementation

The admin interface provides a tenant selector in the header for superusers:

1. **Tenant Dropdown**: Located in the top navigation bar
2. **Automatic Detection**: Only visible when logged in as a superuser
3. **Persistent Selection**: Stored in localStorage as `selectedTenantId`

### API Header Mechanism

When a superuser selects a tenant, all API requests include the `X-Selected-Tenant-Id` header:

```typescript
// From apps/admin/src/lib/api.ts
// Add X-Selected-Tenant-Id header for superusers
if (typeof window !== 'undefined') {
  const selectedTenantId = localStorage.getItem('selectedTenantId');
  if (selectedTenantId) {
    config.headers['X-Selected-Tenant-Id'] = selectedTenantId;
  }
}
```

### Backend Processing

The backend processes this header in the `get_current_tenant_id` function:

```python
# From apps/backend/src/spacecargo/api/routers/auth.py
def get_current_tenant_id(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    x_selected_tenant_id: Optional[str] = Header(None),
) -> int:
    # Super users can select a tenant via header
    if current_user.is_super_user:
        if x_selected_tenant_id:
            selected_tenant_id = int(x_selected_tenant_id)
            # Verify tenant exists
            tenant = db.query(Tenant).filter(Tenant.id == selected_tenant_id).first()
            if not tenant:
                raise HTTPException(status_code=400, detail=f"Tenant {selected_tenant_id} not found")
            return selected_tenant_id
        else:
            # Default to first available tenant if no selection
            first_tenant = db.query(Tenant).first()
            if not first_tenant:
                raise HTTPException(status_code=404, detail="No tenants available")
            return first_tenant.id
```

## Common Use Cases

### 1. Viewing Tenant-Specific Data

Superusers can switch between tenants to:
- View buildings, rooms, and surveys for each organization
- Check FICM codes and attributes configured per tenant
- Review AI prompt configurations

### 2. Debugging Tenant Issues

When investigating tenant-specific problems:
1. Select the affected tenant from the dropdown
2. Navigate to the relevant section (e.g., dev-admin)
3. All data will be filtered to that tenant's context

### 3. Testing Multi-Tenant Features

For testing:
1. Create test data in different tenants
2. Switch between tenants to verify data isolation
3. Confirm Row Level Security (RLS) is working correctly

## Important Considerations

### Security
- Only users with `is_super_user = true` can use this feature
- The header is validated on every request
- Invalid tenant IDs return 400 errors

### Data Isolation
- Even as a superuser, data is still filtered by the selected tenant
- This ensures you see exactly what regular users of that tenant would see
- RLS policies are bypassed only for superuser queries

### Default Behavior
- If no tenant is selected, the first available tenant is used
- Regular users ignore this header and always see their assigned tenant

## Troubleshooting

### Tenant Selection Not Working

1. **Check localStorage**: 
   ```javascript
   localStorage.getItem('selectedTenantId')
   ```

2. **Verify API Headers**: Check browser DevTools Network tab for `X-Selected-Tenant-Id`

3. **Confirm Superuser Status**: Ensure the user has `is_super_user = true`

### FICM Codes Not Loading

If FICM codes show "0 loaded" after tenant switch:
1. Refresh the page to reload data with new tenant context
2. Check that the selected tenant has FICM data populated
3. Verify using: `just ficm_status <tenant_id>`

## Related Documentation
- [Tenant Management](../backend/tenant-management.md)
- [Authentication API](../backend/authentication-api.md)
- [FICM API](../backend/ficm-api.md)
- [AI Testing Tools](./ai-testing-tools.md)

## Version History
- **v1.0** (2025-01-16): Initial documentation of superuser tenant selection features