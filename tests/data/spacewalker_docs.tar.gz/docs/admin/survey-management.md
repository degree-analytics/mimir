# Survey Management Workflows

## Purpose
Comprehensive guide for administrators managing survey review workflows, bulk operations, and analytics in the SpaceWalker admin dashboard. Essential reference for survey approval processes and administrative operations.

## When to Use This
- Reviewing and approving survey submissions
- Managing pending survey queues and workflow processes
- Performing bulk operations on multiple surveys
- Using advanced filtering and search capabilities
- Generating survey analytics and reports
- Keywords: survey review, approval workflows, bulk operations, admin dashboard, survey analytics

**Version:** 1.0 (Initial comprehensive guide)
**Date:** 2025-07-03
**Status:** Current - Survey Management Operations

---

## 🎯 Survey Review Workflow Overview

The SpaceWalker admin interface provides comprehensive tools for managing survey submissions through a complete approval workflow. Administrators can review, approve, reject, or request revisions for survey submissions while maintaining quality standards and efficient processing.

### Review Process States
- **Pending**: Newly submitted surveys awaiting review
- **Approved**: Surveys that have passed review and are accepted
- **Rejected**: Surveys that failed review with documented reasons
- **Completed**: Fully processed surveys in the system

### Workflow Progression
```
Survey Submitted → Pending Review → Admin Review → Approved/Rejected/Revision → Completed
```

---

## 📋 Survey Management Interface

### Accessing Survey Management
1. **Login** to the admin dashboard
2. **Navigate** to "Surveys" in the main sidebar
3. **Select** the appropriate view:
   - **All Surveys**: Complete survey list with filtering
   - **Pending**: Surveys awaiting review (primary workflow)
   - **Approved**: Completed successful reviews
   - **Rejected**: Rejected surveys with reasons

### Main Survey List Interface
- **Table View**: Displays surveys with key information columns
- **Status Indicators**: Visual chips showing current survey status
- **Action Buttons**: Quick access to review, view, and manage functions
- **Pagination Controls**: Navigate through large survey sets
- **Bulk Selection**: Multi-select for batch operations

---

## 🔍 Advanced Filtering System

The survey management interface provides sophisticated filtering to help administrators efficiently locate and manage specific surveys.

### Filter Categories

#### 1. Status Filter
- **All Statuses**: View surveys in any state
- **Pending**: Surveys awaiting review (most common filter)
- **Approved**: Successfully reviewed surveys
- **Rejected**: Surveys that failed review
- **Completed**: Fully processed surveys

#### 2. Building Filter
- **All Buildings**: No building restriction
- **Specific Building**: Filter to surveys from a particular building
- **Auto-population**: Dynamically loads buildings from your tenant

#### 3. Floor Filter
- **All Floors**: No floor restriction
- **Specific Floor**: Filter to surveys from a particular floor
- **Dependency**: Only available after selecting a building
- **Dynamic Loading**: Floors populate based on selected building

#### 4. Room Filter
- **All Rooms**: No room restriction  
- **Specific Room**: Filter to surveys from a particular room
- **Dependency**: Only available after selecting a floor
- **Precise Targeting**: Allows drilling down to specific room surveys

#### 5. Search Filter
- **Text Search**: Search across survey content and metadata
- **Search Fields**: Searches room names, building names, survey content
- **Real-time**: Updates results as you type
- **Combined Filtering**: Works in conjunction with other filters

### Using Filters Effectively

#### Cascading Filter Strategy
1. **Start Broad**: Begin with status filter (usually "Pending")
2. **Narrow by Location**: Select building, then floor, then room as needed
3. **Refine with Search**: Use text search for specific criteria
4. **Reset as Needed**: Clear filters to start fresh

#### Common Filter Combinations
- **Pending + Building**: Review all pending surveys for a specific building
- **Rejected + Date Range**: Analyze rejection patterns over time
- **Approved + Room**: Verify completion status for specific rooms
- **Search + Status**: Find specific surveys within a status category

---

## 👁️ Individual Survey Review

### Opening Survey Details
1. **Click** the "View" icon (eye symbol) in the survey table
2. **Review Modal** opens with comprehensive survey information
3. **Navigate** between sections using the interface tabs

### Survey Review Interface Components

#### Image Gallery
- **Primary Images**: Main survey photos with AI analysis overlay
- **Thumbnail Navigation**: Quick access to all survey images
- **Zoom Capability**: Detailed examination of image content
- **AI Annotations**: Visual indicators of AI-detected features

#### AI Analysis Results
- **FICM Code Suggestions**: AI-recommended facility classification codes
- **Attribute Detection**: Automatically identified room attributes
- **Confidence Scores**: AI certainty levels for each detection
- **Comparison View**: Original vs. AI-suggested values

#### Attribute Editing
- **Direct Editing**: Modify survey attributes during review
- **Smart Controls**: Context-aware input fields for different attribute types
- **Validation**: Real-time validation of attribute values
- **Change Tracking**: Clear indication of modifications made

#### Review Actions
- **Approve**: Accept the survey as submitted or with modifications
- **Reject**: Decline the survey with mandatory reason
- **Comment**: Add internal notes for collaboration
- **Save Changes**: Preserve modifications without final approval

### Review Decision Process

#### Approval Criteria
- **Image Quality**: Clear, well-lit photos showing room features
- **Completeness**: All required attributes and information present
- **Accuracy**: AI suggestions align with visual evidence
- **FICM Compliance**: Proper facility classification code assignment

#### Rejection Reasons
- **Poor Image Quality**: Blurry, dark, or inadequate photos
- **Incomplete Data**: Missing required attributes or information
- **Classification Errors**: Incorrect FICM code or attribute assignments
- **Technical Issues**: System errors or data corruption

---

## ⚡ Bulk Operations

Bulk operations enable efficient processing of multiple surveys simultaneously, essential for managing large volumes of submissions.

### Bulk Selection
1. **Select Multiple**: Use checkboxes to select surveys for bulk operation
2. **Select All**: Use header checkbox to select all visible surveys
3. **Filter First**: Apply filters to target specific survey groups
4. **Verify Selection**: Review selected count before proceeding

### Bulk Approval Process
1. **Select Surveys**: Choose surveys ready for approval
2. **Bulk Approve**: Click the bulk approve button
3. **Confirmation**: Review the action in the confirmation dialog
4. **Execute**: Confirm to approve all selected surveys
5. **Results**: Review completion status and any errors

### Bulk Rejection Process
1. **Select Surveys**: Choose surveys to reject
2. **Bulk Reject**: Click the bulk reject button
3. **Rejection Reason**: Provide mandatory reason for rejection
4. **Standard Reasons**: Select from common rejection reasons or write custom
5. **Execute**: Confirm to reject all selected surveys with the same reason

### Bulk Operation Best Practices

#### Pre-Operation Validation
- **Review Sample**: Manually review a representative sample before bulk action
- **Consistent Criteria**: Ensure all selected surveys meet the same criteria
- **Filter Accuracy**: Verify filters are correctly targeting intended surveys
- **Backup Plan**: Understand how to reverse actions if needed

#### Quality Control
- **Batch Size**: Process manageable batches (50-100 surveys) rather than thousands
- **Status Verification**: Confirm all surveys are in the correct status for the operation
- **Reason Standardization**: Use consistent rejection reasons for similar issues
- **Documentation**: Maintain records of bulk operations performed

---

## 📊 Survey Analytics and Reporting

### Analytics Dashboard
Access survey analytics through the main dashboard to monitor review performance and survey trends.

#### Key Performance Indicators (KPIs)
- **Total Surveys**: Overall survey count in the system
- **Pending Reviews**: Surveys awaiting administrative action
- **Approval Rate**: Percentage of surveys approved vs. rejected
- **Review Time**: Average time from submission to review completion

#### Analytics Charts
- **Survey Progress Over Time**: Trend analysis of survey submissions
- **Status Distribution**: Visual breakdown of survey statuses
- **Review Performance**: Reviewer productivity and quality metrics
- **Building Coverage**: Survey completion by building and floor

### Generating Reports

#### Standard Reports
- **Survey Status Report**: Complete status breakdown with counts
- **Review Activity Report**: Administrative action history
- **Quality Metrics Report**: Approval rates and rejection reasons
- **Coverage Report**: Building and room survey completion status

#### Custom Filtering for Reports
- **Date Range**: Limit reports to specific time periods
- **Building Scope**: Focus on particular buildings or areas
- **Reviewer**: Track individual administrator performance
- **Status Focus**: Analyze specific workflow stages

### Export Capabilities
- **CSV Export**: Structured data for analysis in external tools
- **Filtered Exports**: Export data matching current filter criteria
- **Comprehensive Data**: Include all survey attributes and metadata
- **Scheduled Reports**: Set up recurring exports for regular analysis

---

## 🎨 Status Management

### Status Indicators
- **Color Coding**: Consistent color scheme across the interface
  - 🟢 **Green**: Approved surveys
  - 🔴 **Red**: Rejected surveys  
  - 🟡 **Yellow**: Pending review
  - 🔵 **Blue**: Completed/processed
- **Icons**: Visual symbols accompanying status colors
- **Labels**: Clear text descriptions of each status

### Status Transitions
- **Linear Progression**: Surveys move through defined workflow stages
- **Status History**: Track all status changes with timestamps
- **Audit Trail**: Complete record of who changed status and when
- **Notifications**: Automatic notifications for status changes

### Managing Status Changes
- **Individual Changes**: Update status during survey review
- **Bulk Updates**: Change status for multiple surveys simultaneously
- **Validation Rules**: System prevents invalid status transitions
- **Rollback Capability**: Ability to reverse status changes when needed

---

## 🛠️ Administrative Controls

### User Permissions
- **Review Permissions**: Control who can approve/reject surveys
- **Bulk Operation Access**: Restrict bulk operations to senior administrators
- **Export Permissions**: Control access to survey data exports
- **Administrative Override**: Super admin capabilities for special cases

### Quality Assurance
- **Review Standards**: Maintain consistent review criteria
- **Inter-reviewer Calibration**: Tools for ensuring consistency between reviewers
- **Sample Review**: Random sampling for quality control
- **Performance Monitoring**: Track reviewer accuracy and efficiency

### System Configuration
- **Workflow Settings**: Configure review process parameters
- **Notification Rules**: Set up alerts for various survey events
- **Integration Settings**: Connect with external systems as needed
- **Backup Procedures**: Ensure survey data protection and recovery

---

## 🔧 Troubleshooting Common Issues

### Survey Loading Problems
- **Slow Loading**: Check network connection and server status
- **Missing Images**: Verify image storage and access permissions
- **Filter Not Working**: Clear browser cache and refresh
- **Search Issues**: Verify search terms and try different keywords

### Review Process Issues
- **Cannot Approve**: Check user permissions and survey status
- **Bulk Operations Failing**: Reduce batch size and retry
- **Status Not Updating**: Refresh page and verify changes
- **Export Problems**: Check file permissions and browser settings

### Performance Optimization
- **Large Datasets**: Use filters to reduce data load
- **Slow Interface**: Close unused browser tabs and clear cache
- **Timeout Errors**: Break large operations into smaller batches
- **Memory Issues**: Restart browser session periodically

---

## 📚 Related Documentation

### Administrative Resources
- **[Admin Requirements](./requirements.md)** - Complete administrative interface requirements
- **[Admin Architecture](./architecture/README.md)** - Technical architecture and design patterns
- **[Configuration UI Guide](./configuration-ui.md)** - System configuration and settings management

### System Integration
- **[API Development Guide](../backend/api-development.md)** - Backend integration for survey data
- **[Mobile Development Patterns](../mobile/development-patterns.md)** - Mobile survey submission workflows
- **[Testing Guide](../workflows/testing-guide.md)** - Quality assurance and testing procedures

### Operational Resources
- **[Deployment Guide](../workflows/deployment-guide.md)** - System deployment and maintenance
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General system troubleshooting

---

**Status**: ✅ Complete comprehensive guide as of 2025-07-03. Covers all survey management workflows, filtering, bulk operations, and administrative procedures for the SpaceWalker admin interface.