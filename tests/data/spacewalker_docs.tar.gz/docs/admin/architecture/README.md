# Admin Architecture

## Purpose
Next.js admin dashboard architecture documentation including admin workflows, survey review processes, user management, and web application design patterns. Primary reference for admin dashboard development and management workflows.

## When to Use This
- Understanding admin dashboard architecture and design patterns
- Implementing admin review workflows and approval processes
- Designing user management and tenant administration features
- Integrating with backend APIs for administrative operations
- Troubleshooting admin dashboard issues and web application problems
- Keywords: Next.js, admin dashboard, survey review, user management, web application

**Version:** 2.0 (Extracted from comprehensive PRD)
**Date:** 2025-06-29
**Status:** Current - Admin Technical Reference

---

## 💻 Admin Dashboard Features

### Administrative & Backend Features
- **Admin Review Dashboard** `[Implemented]`
  - Web dashboard for administrators to review, approve, or reject survey submissions
  - Comprehensive survey data visualization with image galleries
  - Bulk operations for efficient review workflows
  - Filter and search capabilities for managing large survey volumes

- **Multi-Tenant Data Management** `[Implemented]`
  - Data securely isolated between university tenants using PostgreSQL's Row-Level Security
  - Tenant-specific configuration and customization options
  - Cross-tenant administrative capabilities for super users
  - Tenant onboarding and management workflows

- **User Management** `[Implemented]`
  - User account creation, modification, and deactivation
  - Role-based access control (Admin, Manager, Surveyor)
  - Tenant-specific user permissions and restrictions
  - User activity monitoring and audit trails

- **Reporting** `[Planned]`
  - Future capability to generate reports on room usage, condition, and other metrics
  - Export capabilities for CSV and PDF formats
  - Dashboard analytics and data visualization
  - Custom report builders for tenant-specific needs

---

## 🏗️ Admin Technology Stack

### Core Technologies
- **Framework:** Next.js 15.5.3 with React 19.1.0
- **Language:** TypeScript for type safety and developer experience
- **Styling:** CSS Modules with responsive design patterns
- **State Management:** React Context API with custom hooks
- **HTTP Client:** Axios for API communication with error handling
- **Authentication:** JWT token-based authentication with secure storage

### Web Application Features
- **Server-Side Rendering:** Next.js SSR for optimal performance
- **Responsive Design:** Mobile-friendly admin interface
- **Progressive Web App:** PWA capabilities for offline admin access
- **SEO Optimization:** Meta tags and structured data for discoverability

---

## 🔐 Authentication & Authorization

### Admin Authentication Flow
```typescript
interface AdminAuthContextType {
  admin: AdminUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  permissions: Permission[];
  login: (credentials: AdminCredentials) => Promise<AuthResponse>;
  logout: () => Promise<void>;
  checkPermission: (permission: Permission) => boolean;
}
```

### Role-Based Access Control
- **Super User:** Cross-tenant administrative access
- **Tenant Admin:** Full tenant management capabilities
- **Manager:** Survey review and reporting access
- **Read-Only:** View-only access for auditing purposes

### Permission System
```typescript
enum Permission {
  REVIEW_SURVEYS = 'review_surveys',
  MANAGE_USERS = 'manage_users',
  MANAGE_BUILDINGS = 'manage_buildings',
  EXPORT_DATA = 'export_data',
  SYSTEM_ADMIN = 'system_admin',
}
```

---

## 📊 Survey Review Workflows

### Review Dashboard Architecture
```typescript
interface SurveyReviewState {
  surveys: PendingSurvey[];
  selectedSurvey: Survey | null;
  reviewStatus: 'pending' | 'approved' | 'rejected' | 'needs_revision';
  bulkOperations: {
    selectedIds: string[];
    operation: BulkOperation;
  };
}

interface ReviewActions {
  approveSurvey: (surveyId: string, comments?: string) => Promise<void>;
  rejectSurvey: (surveyId: string, reason: string) => Promise<void>;
  requestRevision: (surveyId: string, feedback: string) => Promise<void>;
  bulkApprove: (surveyIds: string[]) => Promise<void>;
  bulkReject: (surveyIds: string[], reason: string) => Promise<void>;
}
```

### Review Process Flow
```mermaid
graph TD
    A[Survey Submitted] --> B[Admin Review Queue]
    B --> C[Individual Review]
    C --> D{Review Decision}

    D -->|Approve| E[Mark Approved]
    D -->|Reject| F[Mark Rejected + Reason]
    D -->|Needs Revision| G[Request Changes]

    E --> H[Update Survey Status]
    F --> H
    G --> I[Notify Surveyor]

    I --> J[Surveyor Revises]
    J --> B

    H --> K[Generate Reports]
    K --> L[Export Data]
```

### Bulk Operations
- **Bulk Approval:** Approve multiple surveys simultaneously
- **Bulk Rejection:** Reject surveys with standardized reasons
- **Batch Export:** Export survey data in various formats
- **Status Updates:** Update survey statuses across multiple records

---

## 🏢 Multi-Tenant Architecture

### Tenant Management
```typescript
interface TenantManagement {
  tenants: Tenant[];
  currentTenant: Tenant | null;
  switchTenant: (tenantId: string) => Promise<void>;
  createTenant: (tenantData: CreateTenantRequest) => Promise<Tenant>;
  updateTenant: (tenantId: string, updates: TenantUpdate) => Promise<void>;
  deactivateTenant: (tenantId: string) => Promise<void>;
}

interface Tenant {
  id: string;
  name: string;
  domain: string;
  settings: TenantSettings;
  subscription: SubscriptionInfo;
  users: TenantUser[];
  buildings: Building[];
}
```

### Tenant Isolation
- **Data Separation:** Complete isolation of tenant data at database level
- **UI Context:** Tenant-specific branding and customization
- **Feature Flags:** Tenant-specific feature enablement
- **Resource Limits:** Configurable limits per tenant subscription

---

## 📈 Reporting & Analytics

### Report Generation
```typescript
interface ReportGenerator {
  generateSurveyReport: (filters: SurveyFilters) => Promise<Report>;
  generateUserActivityReport: (dateRange: DateRange) => Promise<Report>;
  generateBuildingUtilizationReport: (buildingId: string) => Promise<Report>;
  exportToCSV: (reportData: ReportData) => Promise<string>;
  exportToPDF: (reportData: ReportData) => Promise<Buffer>;
}
```

### Analytics Dashboard
- **Survey Metrics:** Completion rates, approval rates, time-to-review
- **User Activity:** Login frequency, survey submissions, review actions
- **Building Analytics:** Room utilization, survey coverage, data quality
- **System Health:** Performance metrics, error rates, user satisfaction

---

## 🎨 UI/UX Architecture

### Component Architecture
```typescript
// Admin Dashboard Component Hierarchy
AdminApp
├── AuthProvider
├── TenantProvider
├── AdminLayout
│   ├── NavigationSidebar
│   ├── TopNavigation
│   └── MainContent
│       ├── Dashboard
│       ├── SurveyReview
│       ├── UserManagement
│       ├── BuildingManagement
│       ├── Reports
│       └── Settings
```

### Design System
- **Component Library:** Reusable UI components with consistent styling
- **Responsive Grid:** Flexible layout system for various screen sizes
- **Accessibility:** WCAG 2.1 AA compliance with keyboard navigation
- **Theme System:** Customizable themes with tenant-specific branding

### Navigation Patterns
- **Sidebar Navigation:** Primary navigation for main sections
- **Breadcrumb Navigation:** Hierarchical navigation for deep pages
- **Tab Navigation:** Section-specific navigation within pages
- **Modal Navigation:** Overlay navigation for forms and detail views

---

## 📡 API Integration

### API Client Configuration
```typescript
const adminApiClient = axios.create({
  baseURL: `${API_BASE_URL}/admin`,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for admin authentication
adminApiClient.interceptors.request.use((config) => {
  const token = getAdminToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor for admin error handling
adminApiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 403) {
      // Handle insufficient permissions
      redirectToAccessDenied();
    }
    return Promise.reject(error);
  }
);
```

### Admin API Endpoints
- **Survey Management:** CRUD operations for survey data
- **User Management:** User account administration
- **Tenant Management:** Multi-tenant configuration
- **Report Generation:** Analytics and export endpoints
- **System Administration:** Configuration and monitoring

---

## 🧪 Testing Strategy

### Testing Frameworks
- **Jest:** Unit testing for components and utilities
- **React Testing Library:** Component integration testing
- **Playwright:** End-to-end testing for admin workflows
- **MSW (Mock Service Worker):** API mocking for testing

### Testing Patterns
- **Component Tests:** UI component behavior and rendering
- **Integration Tests:** Page-level functionality and API integration
- **E2E Tests:** Complete admin workflows and user journeys
- **Accessibility Tests:** Automated accessibility compliance testing

---

## 📚 Related Documentation

### Implementation Details
- **[Development Setup](../../setup/development-setup.md)** - Development setup, coding standards, and implementation patterns
- **[Testing Guide](../../workflows/testing-guide.md)** - Testing strategies and admin workflow testing

### System Integration
- **[API Development Guide](../../backend/api-development.md)** - Backend API integration and admin endpoints
- **[Development Patterns](../../mobile/development-patterns.md)** - Mobile survey data reviewed in admin dashboard

### Workflow Resources
- **[Development Setup](../../setup/development-setup.md)** - Admin development environment configuration
- **[Environment Configuration](../../setup/environment-configuration.md)** - Room classification standards used in admin review

### Troubleshooting
- **[Troubleshooting Guide](../../workflows/troubleshooting-guide.md)** - Admin dashboard diagnostics and web application issues

---

**Status**: ✅ Updated and current as of 2025-06-29. Extracted from comprehensive PRD and enhanced with admin-specific architecture details and management workflows.
