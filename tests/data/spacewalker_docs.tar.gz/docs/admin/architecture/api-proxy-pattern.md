# Admin Dashboard API Proxy Architecture

## Purpose
Architecture documentation for the runtime API proxy pattern implemented in the Spacewalker admin dashboard. This pattern solves the fundamental challenge of build-once, deploy-anywhere Docker deployments for Next.js applications requiring dynamic backend connectivity across development, staging, and production environments.

## When to Use This
- Understanding admin dashboard API routing architecture
- Implementing similar proxy patterns for Next.js applications in Docker
- Troubleshooting admin dashboard API connectivity issues across environments
- Designing containerized frontend applications with dynamic backend discovery
- Keywords: Next.js proxy, Docker deployment, runtime configuration, API routing architecture

**Version:** 2.0 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production Architecture Pattern

---

## 🎯 Architectural Challenge

### The Core Problem
The admin dashboard encountered a critical deployment issue where the containerized application attempted to connect to `localhost:8000` despite having correct backend URLs configured in ECS environment variables.

**Root Cause Analysis:**
1. **Build-once, Deploy-anywhere Constraint** - Docker images are built in CI/CD without knowledge of target environment (dev, staging, prod)
2. **Next.js Rewrites Limitation** - Rewrites are evaluated at build time, not runtime, making them incompatible with container deployment patterns
3. **Environment Variables Timing** - ECS injects environment variables at container runtime, after Docker build completion

### Traditional Approach (Inadequate)
```javascript
// next.config.js - Build-time configuration (doesn't work in containers)
module.exports = {
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:8000/api/:path*', // Fixed at build time!
      },
    ];
  },
};
```

**Problem**: Build-time destination hardcoding prevents environment-specific backend routing.

---

## 🏗️ Runtime API Proxy Solution

### Architecture Overview
Replaced build-time rewrites with a runtime catch-all API route that dynamically determines backend URL based on container environment detection.

**Implementation Components:**
1. **Catch-all Route**: `app/api/[...path]/route.ts` - Handles all `/api/*` requests
2. **Environment Detection Logic** - Smart backend URL determination
3. **Proxy Forwarding** - Transparent request/response proxying with header preservation

### Smart Environment Detection Algorithm
```typescript
function getBackendUrl(): string {
  // Docker Environment Detection
  if (process.env.BACKEND_HEALTH_URL) {
    return 'http://backend:8000'; // Internal Docker service networking
  }

  // ECS/Cloud Environment
  if (process.env.API_URL) {
    return process.env.API_URL; // ALB URL injected at runtime
  }

  // Local Development Fallback
  return process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';
}
```

**Detection Hierarchy:**
1. **Docker Internal Networking** - Uses service names when `BACKEND_HEALTH_URL` is present
2. **Cloud Environment URLs** - Uses injected ALB URLs from `API_URL`
3. **Local Development Fallback** - Defaults to localhost for development

---

## 🔄 Request Flow Patterns

### Local Development (Non-Docker)
```
Browser Request:     localhost:3000/api/users
↓ Proxy Detection:   Environment = Local Development
↓ Backend Target:    localhost:8000/api/users
↓ Response:          Direct forwarding with CORS headers
```

### Docker Development Environment
```
Browser Request:     localhost:3000/api/users
↓ Proxy Detection:   Environment = Docker (BACKEND_HEALTH_URL present)
↓ Backend Target:    backend:8000/api/users (internal service name)
↓ Response:          Container-to-container communication
```

### ECS Production Deployment
```
Browser Request:     admin.spacewalker.com/api/users
↓ Proxy Detection:   Environment = ECS (API_URL injected)
↓ Backend Target:    backend-alb.amazonaws.com/api/users
↓ Response:          ALB load-balanced backend services
```

---

## ⚙️ Implementation Details

### Proxy Route Implementation
**Location**: `apps/admin/app/api/[...path]/route.ts`

**Key Features:**
- **Method Preservation** - Forwards GET, POST, PUT, DELETE, PATCH requests
- **Header Forwarding** - Preserves authentication and content-type headers
- **Error Handling** - Graceful degradation with meaningful error responses
- **Request Body Support** - Handles JSON payloads for mutations

### Environment Variable Configuration

**Development Environment:**
```bash
# Local development (optional - uses localhost fallback)
NEXT_PUBLIC_API_URL=http://localhost:8000/api
```

**Docker Environment:**
```bash
# Docker Compose automatically sets this for service discovery
BACKEND_HEALTH_URL=http://backend:8000/health
```

**ECS Environment:**
```bash
# Injected by CloudFormation stack
API_URL=https://backend-{environment}.spacewalker.com
```

### Request/Response Processing
```typescript
// Simplified proxy logic
export async function GET(request: Request, { params }: { params: { path: string[] } }) {
  const backendUrl = getBackendUrl();
  const targetPath = params.path.join('/');
  const targetUrl = `${backendUrl}/${targetPath}`;

  const response = await fetch(targetUrl, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': request.headers.get('Authorization') || '',
    },
  });

  return new Response(response.body, {
    status: response.status,
    headers: response.headers,
  });
}
```

---

## 🧪 Testing & Validation

### Development Testing
```bash
# Test proxy endpoint health
curl http://localhost:3000/api/health

# Test authentication flow
curl -X POST http://localhost:3000/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@demo.university.edu", "password": "demo123"}'

# Test data retrieval
curl -H "Authorization: Bearer <token>" \
  http://localhost:3000/api/buildings
```

### Environment-Specific Validation
```bash
# Docker environment testing
just docker-start
curl http://localhost:3000/api/health
# Should route to backend:8000 internally

# ECS environment testing (requires deployment)
curl https://admin.spacewalker.com/api/health
# Should route to ALB backend
```

---

## 🎯 Architecture Benefits

### Deployment Flexibility
1. **Single Docker Image** - Same container works across all environments
2. **Runtime Configuration** - Environment variables control backend routing
3. **Zero Code Changes** - Existing API calls continue working unchanged
4. **Infrastructure Agnostic** - Works with any container orchestration platform

### Development Experience
1. **Local Development Support** - Automatic localhost fallback
2. **Docker Compatibility** - Seamless service-to-service communication
3. **Debugging Friendly** - Clear proxy routing with request tracing
4. **Hot Reload Support** - Environment changes apply without rebuilds

### Operational Advantages
1. **Service Discovery** - Automatic backend URL detection
2. **Graceful Degradation** - Fallback routing when environment variables missing
3. **Security Compliance** - Backend URLs not embedded in frontend code
4. **Monitoring Integration** - Request routing visible in application logs

---

## 🔮 Future Architecture Considerations

### Alternative Patterns (For Reference)
While the current proxy solution provides optimal simplicity-to-functionality ratio, future architectural evolution might consider:

**Service Mesh Integration:**
- **AWS App Mesh** - Advanced traffic management and observability
- **Istio/Linkerd** - Comprehensive service communication management
- **Trade-off** - Significantly increased operational complexity

**ALB Path-Based Routing:**
- **Dedicated Backend ALB** - Direct browser-to-backend communication
- **Path Routing Rules** - `/api/*` routes directly to backend services
- **Trade-off** - Requires additional infrastructure and CORS complexity

**GraphQL Gateway Pattern:**
- **Apollo Federation** - Unified API schema across services
- **Backend-for-Frontend** - Service aggregation at infrastructure level
- **Trade-off** - Major architectural restructuring required

### Current Solution Assessment
The runtime proxy pattern represents the **optimal balance** of:
- **Minimal Infrastructure Complexity** - No additional services required
- **Maximum Deployment Flexibility** - Works in any container environment
- **Zero Migration Overhead** - Drop-in replacement for build-time rewrites
- **Clear Debugging Experience** - Transparent request routing with logging

---

## 📋 Related Architecture Documentation

### Deployment & Infrastructure
- **[AWS Deployment Guide](../../workflows/aws-deployment-guide.md)** - ECS deployment patterns and ALB configuration
- **[Development Setup](../../setup/development-setup.md)** - Container development patterns

### Backend Integration
> 🚀 **API Documentation**: See [API Contracts](../../backend/architecture/api-contracts.md) for endpoint specifications and authentication patterns

### Troubleshooting Resources
- **[Troubleshooting Guide](../../workflows/troubleshooting-guide.md)** - General problem resolution including environment and networking issues

---

**Status**: ✅ **PRODUCTION ARCHITECTURE PATTERN**
**Last Updated**: 2025-06-29
**Architecture Scope**: Admin Dashboard API Communication
**Implementation**: Runtime proxy pattern with environment detection

---

*This runtime API proxy architecture enables the admin dashboard to function seamlessly across development, staging, and production environments while maintaining the build-once, deploy-anywhere Docker paradigm essential for modern containerized applications.*
