# Admin Dashboard Container Architecture

## Purpose
Detailed architecture documentation for the admin dashboard container in the Spacewalker system, including Next.js application design, frontend architecture patterns, API integration strategies, and deployment configurations. Essential reference for frontend developers working on the web-based administration interface.

## When to Use This
- Designing admin dashboard features and UI components
- Understanding Next.js application architecture and routing patterns
- Implementing API integration and state management
- Planning frontend performance optimizations and deployment
- Troubleshooting admin dashboard container interactions
- Keywords: Next.js architecture, admin dashboard, frontend containers, web application, React components

**Version:** 2.0 (Extracted from system container documentation)
**Date:** 2025-06-29
**Status:** Current - Production Admin Architecture

---

## 🏗️ Admin Container Overview

> 📊 **System Context**: See [System Container Overview](../../architecture/system-container-overview.md) for complete system architecture and container relationships

The admin dashboard container provides the web-based management interface for the Spacewalker system, enabling administrators to manage users, review surveys, and oversee system operations through a modern React-based web application.

### Admin Container Architecture
```
Users → Admin Dashboard → Backend API → Data Layer
  ↓           ↓              ↓           ↓
Web UI → Next.js App → REST API → Database
  ↓           ↓              ↓           ↓
React Components → State Management → Business Logic → Data Persistence
```

---

## 💻 Admin Dashboard Container

### Technology Stack
- **Framework**: Next.js 15.5.3 with App Router
- **UI Library**: React 18 with TypeScript
- **Styling**: Tailwind CSS for responsive design
- **State Management**: React Context API with custom hooks
- **API Client**: Fetch API with custom wrapper for backend communication
- **Authentication**: JWT token storage and validation

### Container Responsibilities
- **User Interface** - Responsive web interface for system administration
- **Survey Management** - Review, approve, and manage survey submissions
- **User Administration** - User account management and role assignment
- **System Monitoring** - Dashboard views and system status monitoring
- **Data Visualization** - Charts and reports for survey analytics
- **Content Management** - Administrative content and configuration

### Application Architecture Pattern
```typescript
// Next.js App Router Structure
app/
├── (auth)/                    # Authentication layouts
│   ├── login/                 # Login page
│   └── layout.tsx             # Auth-specific layout
├── (dashboard)/               # Protected dashboard routes
│   ├── surveys/               # Survey management
│   ├── users/                 # User administration
│   ├── analytics/             # Data visualization
│   └── layout.tsx             # Dashboard layout
├── api/                       # API proxy routes
│   └── [...path]/route.ts     # Runtime API proxy
├── components/                # Reusable UI components
├── lib/                       # Utilities and services
└── globals.css                # Global styles
```

### Frontend Architecture Patterns
- **Component-Based Design** - Modular, reusable React components
- **Server-Side Rendering** - Next.js SSR for performance and SEO
- **Runtime API Proxy** - Dynamic backend URL resolution for containerized deployments
- **Responsive Design** - Mobile-first design with Tailwind CSS
- **Type Safety** - Full TypeScript integration across the application

### API Integration Architecture
```typescript
// Runtime API Proxy Pattern
export async function GET(request: Request, { params }: { params: { path: string[] } }) {
  const backendUrl = getBackendUrl(); // Dynamic URL resolution
  const targetPath = params.path.join('/');
  const targetUrl = `${backendUrl}/${targetPath}`;

  const response = await fetch(targetUrl, {
    method: 'GET',
    headers: {
      'Authorization': request.headers.get('Authorization') || '',
      'Content-Type': 'application/json',
    },
  });

  return new Response(response.body, {
    status: response.status,
    headers: response.headers,
  });
}
```

---

## 🎨 Frontend Component Architecture

### UI Component Organization
```typescript
// Component Hierarchy
components/
├── layout/
│   ├── AdminLayout.tsx        # Standardized admin page layout (NEW)
│   ├── DashboardLayout.tsx    # Navigation and shell layout
│   ├── Header.tsx             # Navigation header
│   ├── Sidebar.tsx            # Navigation sidebar
│   └── Footer.tsx             # Page footer
├── forms/
│   ├── SurveyForm.tsx         # Survey editing form
│   ├── UserForm.tsx           # User management form
│   └── LoginForm.tsx          # Authentication form
├── ui/
│   ├── Button.tsx             # Consistent button component
│   ├── Modal.tsx              # Modal dialog component
│   ├── Table.tsx              # Data table component
│   └── LoadingSpinner.tsx     # Loading state indicator
└── charts/
    ├── SurveyChart.tsx        # Survey analytics visualization
    └── DashboardMetrics.tsx   # Key performance indicators
```

### Component Design Principles
- **Atomic Design** - Components built from small, focused pieces
- **Props Interface** - Clear TypeScript interfaces for all component props
- **Accessibility** - WCAG compliance with proper ARIA attributes
- **Performance** - React.memo and useMemo for optimization
- **Theming** - Consistent design tokens through Tailwind CSS
- **Layout Standardization** - AdminLayout component enforces consistent responsive patterns

### AdminLayout Integration
The AdminLayout component provides standardized layout patterns across all admin pages:

```typescript
// AdminLayout Component Features
interface AdminLayoutProps {
  children: React.ReactNode;
  title?: string;
  variant?: 'default' | 'table' | 'form';
  maxWidth?: 'xl' | false;
  disablePadding?: boolean;
}

// Standardized Layout Implementation
export default function AdminPage() {
  return (
    <AdminLayout variant="table" title="Data Management">
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }}>
          {/* Content */}
        </Table>
      </TableContainer>
    </AdminLayout>
  );
}
```

**AdminLayout Benefits:**
- **Screen Utilization**: Container maxWidth="xl" (1536px) vs legacy "md" (900px)
- **Responsive Padding**: Automatic scaling (xs: 16px, sm: 24px, md: 32px)
- **Cross-Browser Compatibility**: Built-in Safari fixes for smooth scrolling
- **Error Boundaries**: Comprehensive error handling with dev/prod modes
- **Code Reduction**: 50% less layout boilerplate per page
- **Consistency**: Standardized responsive behavior across all admin interfaces

### State Management Patterns
```typescript
// Global State Management with Context
interface AppContextType {
  user: User | null;
  surveys: Survey[];
  isLoading: boolean;
  setUser: (user: User | null) => void;
  updateSurvey: (survey: Survey) => void;
  loadSurveys: () => Promise<void>;
}

export const AppContext = createContext<AppContextType | undefined>(undefined);

// Custom Hook for Context Usage
export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};
```

---

## 🔄 API Communication Patterns

### Backend Integration Strategy
The admin dashboard integrates with the backend API through a runtime proxy pattern that handles environment-specific URL resolution and authentication token forwarding.

### Environment-Aware API Routing
```typescript
// Dynamic Backend URL Resolution
function getBackendUrl(): string {
  // Docker environment detection
  if (process.env.BACKEND_HEALTH_URL) {
    return 'http://backend:8000'; // Internal Docker networking
  }

  // ECS/Cloud environment
  if (process.env.API_URL) {
    return process.env.API_URL; // Injected ALB URL
  }

  // Local development fallback
  return process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
}
```

### API Client Implementation
```typescript
// Type-Safe API Client
class ApiClient {
  private baseUrl = '/api'; // Proxy endpoint

  async get<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      headers: {
        'Authorization': `Bearer ${this.getAuthToken()}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new ApiError(response.status, await response.text());
    }

    return response.json();
  }

  async post<T>(endpoint: string, data: any): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.getAuthToken()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new ApiError(response.status, await response.text());
    }

    return response.json();
  }

  private getAuthToken(): string {
    return localStorage.getItem('auth_token') || '';
  }
}
```

### Error Handling & User Feedback
```typescript
// Global Error Handling
export const ErrorBoundary: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <ErrorBoundaryComponent
      FallbackComponent={ErrorFallback}
      onError={(error, errorInfo) => {
        console.error('Application error:', error, errorInfo);
        // Send to error tracking service
      }}
    >
      {children}
    </ErrorBoundaryComponent>
  );
};

const ErrorFallback: React.FC<{ error: Error; resetErrorBoundary: () => void }> = ({
  error,
  resetErrorBoundary,
}) => (
  <div className="p-8 text-center">
    <h2 className="text-xl font-bold text-red-600 mb-4">Something went wrong</h2>
    <p className="text-gray-600 mb-4">{error.message}</p>
    <Button onClick={resetErrorBoundary}>Try Again</Button>
  </div>
);
```

---

## 🔐 Authentication & Security

### JWT Token Management
```typescript
// Authentication Service
class AuthService {
  private tokenKey = 'spacewalker_auth_token';

  setToken(token: string): void {
    localStorage.setItem(this.tokenKey, token);
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  removeToken(): void {
    localStorage.removeItem(this.tokenKey);
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) return false;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  }
}
```

### Route Protection
```typescript
// Protected Route Wrapper
export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/login');
    }
  }, [user, isLoading, router]);

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (!user) {
    return null;
  }

  return <>{children}</>;
};
```

### CSRF Protection
```typescript
// CSRF Token Handling
export const withCSRFProtection = (handler: NextApiHandler): NextApiHandler => {
  return async (req, res) => {
    if (req.method !== 'GET') {
      const csrfToken = req.headers['x-csrf-token'];
      const sessionToken = req.session?.csrfToken;

      if (!csrfToken || csrfToken !== sessionToken) {
        return res.status(403).json({ error: 'CSRF token mismatch' });
      }
    }

    return handler(req, res);
  };
};
```

---

## 🚀 Performance Optimization

### Code Splitting & Lazy Loading
```typescript
// Dynamic Component Loading
const SurveyManagement = dynamic(() => import('../components/SurveyManagement'), {
  loading: () => <LoadingSpinner />,
  ssr: false, // Client-side only for heavy components
});

const AnalyticsDashboard = dynamic(() => import('../components/AnalyticsDashboard'), {
  loading: () => <div>Loading analytics...</div>,
});
```

### Image Optimization
```typescript
// Next.js Image Optimization
import Image from 'next/image';

export const SurveyImage: React.FC<{ src: string; alt: string }> = ({ src, alt }) => (
  <Image
    src={src}
    alt={alt}
    width={400}
    height={300}
    placeholder="blur"
    blurDataURL="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ..." // Base64 placeholder
    className="rounded-lg shadow-md"
  />
);
```

### Caching Strategies
```typescript
// API Response Caching
const useCachedApiData = <T>(endpoint: string, cacheTime: number = 5 * 60 * 1000) => {
  const [data, setData] = useState<T | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const cachedData = getCachedData(endpoint);
    if (cachedData && Date.now() - cachedData.timestamp < cacheTime) {
      setData(cachedData.data);
      setIsLoading(false);
      return;
    }

    apiClient.get<T>(endpoint)
      .then(response => {
        setCachedData(endpoint, response);
        setData(response);
      })
      .finally(() => setIsLoading(false));
  }, [endpoint, cacheTime]);

  return { data, isLoading };
};
```

---

## 🔧 Container Configuration & Deployment

### Environment Configuration
```bash
# Admin Dashboard Environment Variables
NEXT_PUBLIC_API_URL=http://localhost:8000
API_URL=https://backend-prod.spacewalker.com
NEXTAUTH_SECRET=your-secret-key
NEXTAUTH_URL=https://admin.spacewalker.com
NODE_ENV=production
```

### Docker Configuration
```dockerfile
# Multi-stage build for Next.js
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

FROM node:18-alpine AS runner
WORKDIR /app

COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static

EXPOSE 3000
CMD ["node", "server.js"]
```

### Deployment Configuration
```yaml
# Docker Compose Admin Service
admin:
  build:
    context: ./apps/admin
    dockerfile: Dockerfile
  ports:
    - "3000:3000"
  environment:
    - API_URL=http://backend:8000
    - NODE_ENV=production
  depends_on:
    - backend
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
    interval: 30s
    timeout: 10s
    retries: 3
```

---

## 📊 Admin Dashboard Features

### Survey Management Interface
- **Survey Review** - Comprehensive survey viewing and approval workflow
- **Batch Operations** - Bulk approve/reject/delete survey submissions
- **Search & Filtering** - Advanced search with date ranges and status filters
- **Export Functionality** - CSV/PDF export of survey data and reports
- **Audit Trail** - Complete history of survey modifications and approvals

### User Administration
- **User Management** - Create, edit, and deactivate user accounts
- **Role Assignment** - Role-based permissions and access control
- **Organization Management** - Multi-tenant organization structure
- **Access Monitoring** - User activity tracking and session management
- **Bulk Import** - CSV import for user account creation

### Analytics Dashboard
- **Key Metrics** - Survey completion rates, user activity, system performance
- **Data Visualization** - Interactive charts and graphs using Chart.js
- **Custom Reports** - Configurable reports with date ranges and filters
- **Real-time Updates** - Live dashboard updates using WebSocket connections
- **Data Export** - Export analytics data in multiple formats

---

## 🧪 Frontend Testing Strategies

### Component Testing
```typescript
// React Testing Library
import { render, screen, fireEvent } from '@testing-library/react';
import { SurveyForm } from '../components/SurveyForm';

describe('SurveyForm', () => {
  it('should submit survey data correctly', async () => {
    const mockOnSubmit = jest.fn();

    render(<SurveyForm onSubmit={mockOnSubmit} />);

    fireEvent.change(screen.getByLabelText(/survey title/i), {
      target: { value: 'Test Survey' }
    });

    fireEvent.click(screen.getByRole('button', { name: /submit/i }));

    await waitFor(() => {
      expect(mockOnSubmit).toHaveBeenCalledWith({
        title: 'Test Survey'
      });
    });
  });
});
```

### Integration Testing
```typescript
// API Integration Testing
describe('Admin API Integration', () => {
  it('should fetch and display surveys', async () => {
    const mockSurveys = [
      { id: '1', title: 'Test Survey', status: 'pending' }
    ];

    fetchMock.get('/api/surveys', mockSurveys);

    render(<SurveyManagement />);

    await waitFor(() => {
      expect(screen.getByText('Test Survey')).toBeInTheDocument();
    });
  });
});
```

### End-to-End Testing
```typescript
// Playwright E2E Testing
import { test, expect } from '@playwright/test';

test('admin can review and approve survey', async ({ page }) => {
  await page.goto('/login');
  await page.fill('[data-testid=email]', 'admin@test.com');
  await page.fill('[data-testid=password]', 'password');
  await page.click('[data-testid=login-button]');

  await page.goto('/surveys');
  await page.click('[data-testid=survey-row]:first-child');
  await page.click('[data-testid=approve-button]');

  await expect(page.locator('[data-testid=success-message]')).toBeVisible();
});
```

---

## 📋 Related Admin Documentation

### Layout and Component Implementation
> 🎯 **AdminLayout Usage**: See [AdminLayout Component Guide](../components/admin-layout-guide.md) for comprehensive implementation patterns
> ✅ **Migration Complete**: All legacy pages have been successfully converted to use proper layout patterns
> 📐 **Layout Standards**: See [Layout Standards](../../frontend/layout-standards.md) for responsive design patterns and browser compatibility

### Implementation Details
> 🎯 **API Integration**: See [API Proxy Pattern](./api-proxy-pattern.md) for runtime API routing implementation

### Development Resources
- **[Development Setup](../../setup/development-setup.md)** - Development environment configuration for Next.js
- **[Testing Guide](../../workflows/testing-guide.md)** - Comprehensive testing strategies for React components
- **[AWS Deployment Guide](../../workflows/aws-deployment-guide.md)** - Container deployment and production configuration

### System Architecture Context
- **[System Container Overview](../../architecture/system-container-overview.md)** - Complete system architecture with all container relationships
- **[Component Architecture](../../architecture/component-diagrams.md)** - Detailed component relationships within admin container

---

**Status**: ✅ **PRODUCTION ADMIN ARCHITECTURE**
**Last Updated**: 2025-06-29
**Container Scope**: Next.js Admin Dashboard, React Components, API Integration
**Technology Stack**: Next.js, React, TypeScript, Tailwind CSS

---

*This admin container architecture documentation provides comprehensive guidance for frontend developers working on the web-based administration interface, ensuring consistent patterns and optimal user experience across all admin features.*
