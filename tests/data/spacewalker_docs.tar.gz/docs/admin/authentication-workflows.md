# Admin Authentication Workflows

## Purpose
Comprehensive documentation for admin dashboard authentication workflows, session management, and role-based access control patterns for the Spacewalker admin application.

## When to Use This
- Implementing authentication in admin dashboard components
- Understanding session management and user context
- Implementing role-based access control in admin interfaces
- Managing authentication state in React applications
- Keywords: admin authentication, session management, AuthContext, protected routes, RBAC workflows

**Version:** 1.0
**Date:** 2025-07-09
**Status:** Current

## Key Concepts
- **AuthContext**: React context for managing authentication state across admin components
- **Session Management**: Automatic token handling, refresh, and user session lifecycle
- **Protected Routes**: Component-based route protection with authentication checks
- **Role-Based Access**: Hierarchical permissions and admin-specific functionality
- **Tenant Context**: Admin users can view and manage tenant-specific data

## Authentication Architecture Overview

```mermaid
graph TB
    Login[Login Page] --> AuthContext[AuthContext Provider]
    AuthContext --> TokenCheck[Token Validation]
    TokenCheck --> |Valid| Dashboard[Dashboard Layout]
    TokenCheck --> |Invalid| Login

    Dashboard --> ProtectedRoute[Protected Route]
    ProtectedRoute --> AdminCheck[Admin Permission Check]
    AdminCheck --> |Authorized| Component[Admin Component]
    AdminCheck --> |Unauthorized| Forbidden[403 Forbidden]

    AuthContext --> SessionManager[Session Manager]
    SessionManager --> TokenRefresh[Token Refresh]
    SessionManager --> TenantContext[Tenant Context]

    Component --> APICall[API Call]
    APICall --> AuthHeader[Authorization Header]
    APICall --> TenantHeader[X-Selected-Tenant-Id Header]

    classDef auth fill:#E3F2FD,stroke:#1976D2,color:#000000
    classDef component fill:#F3E5F5,stroke:#7B1FA2,color:#000000
    classDef api fill:#E8F5E8,stroke:#388E3C,color:#000000
    classDef error fill:#FFEBEE,stroke:#F44336,color:#000000

    class Login,AuthContext,TokenCheck,SessionManager auth
    class Dashboard,ProtectedRoute,Component component
    class APICall,AuthHeader,TenantHeader api
    class Forbidden error
```

## Authentication Flow

### 1. Login Workflow

**Login Page Component:**
```typescript
// src/app/login/page.tsx
'use client';

import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(email, password);
      // AuthContext automatically redirects to dashboard
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto mt-8 space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          Email
        </label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Password
        </label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          required
        />
      </div>

      {error && (
        <div className="text-red-600 text-sm">{error}</div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'Signing in...' : 'Sign In'}
      </button>
    </form>
  );
}
```

**Login API Integration:**
```typescript
// src/lib/api.ts - Auth API methods
export const auth = {
  async login(email: string, password: string): Promise<void> {
    const response = await api.post('/login', {
      email,
      password
    });

    const { access_token } = response.data;

    // Store token securely
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', access_token);
    }

    // Token will be automatically included in future requests
    return response.data;
  },

  async getCurrentUser(): Promise<User> {
    const response = await api.get('/me');
    return response.data;
  },

  async logout(): Promise<void> {
    // Clear token from storage
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token');
    }
  },

  getToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('auth_token');
    }
    return null;
  },

  initializeToken(): void {
    // Initialize token from localStorage on app start
    // This is called in AuthContext useEffect
  }
};
```

### 2. AuthContext Implementation

**AuthContext Provider:**
```typescript
// src/contexts/AuthContext.tsx
'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { auth, tenants } from '@/lib/api';
import { User, Tenant } from '@/types';

interface AuthContextType {
  user: User | null;
  tenant: Tenant | null;
  loading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isHydrated, setIsHydrated] = useState(false);
  const router = useRouter();

  // Initialize authentication state
  useEffect(() => {
    setIsHydrated(true);
    auth.initializeToken();
  }, []);

  // Check authentication status after hydration
  useEffect(() => {
    if (!isHydrated) return;
    checkAuth();
  }, [isHydrated]);

  const checkAuth = async () => {
    try {
      const token = auth.getToken();

      if (!token) {
        setIsAuthenticated(false);
        setLoading(false);
        return;
      }

      // Validate token by fetching user data
      const userData = await auth.getCurrentUser();
      setUser(userData);
      setIsAuthenticated(true);

      // Fetch tenant information
      try {
        const tenantData = await tenants.getCurrent();
        setTenant(tenantData);
      } catch (error) {
        console.error('Failed to fetch tenant:', error);
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      auth.logout();
      setIsAuthenticated(false);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      await auth.login(email, password);
      await checkAuth();
      router.push('/dashboard');
    } catch (error) {
      if (error instanceof Error && 'response' in error) {
        const axiosError = error as { response?: { data?: { detail?: string } } };
        throw new Error(axiosError.response?.data?.detail || 'Login failed');
      }
      throw new Error('Login failed');
    }
  };

  const logout = () => {
    auth.logout();
    setUser(null);
    setTenant(null);
    setIsAuthenticated(false);
    router.push('/login');
  };

  const refreshUser = async () => {
    await checkAuth();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        tenant,
        loading,
        isAuthenticated,
        login,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
```

### 3. Protected Routes Implementation

**ProtectedRoute Component:**
```typescript
// src/components/ProtectedRoute.tsx
'use client';

import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
  requireSuperUser?: boolean;
}

export default function ProtectedRoute({
  children,
  requireAdmin = false,
  requireSuperUser = false
}: ProtectedRouteProps) {
  const { user, loading, isAuthenticated } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;

    if (!isAuthenticated) {
      router.push('/login');
      return;
    }

    if (requireSuperUser && !user?.is_super_user) {
      router.push('/unauthorized');
      return;
    }

    if (requireAdmin && !user?.is_admin) {
      router.push('/unauthorized');
      return;
    }
  }, [loading, isAuthenticated, user, requireAdmin, requireSuperUser, router]);

  // Show loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Show nothing while redirecting
  if (!isAuthenticated) {
    return null;
  }

  // Check permissions
  if (requireSuperUser && !user?.is_super_user) {
    return null;
  }

  if (requireAdmin && !user?.is_admin) {
    return null;
  }

  return <>{children}</>;
}
```

**Usage in Page Components:**
```typescript
// src/app/(dashboard)/admin/page.tsx
import ProtectedRoute from '@/components/ProtectedRoute';
import AdminDashboard from '@/components/AdminDashboard';

export default function AdminPage() {
  return (
    <ProtectedRoute requireAdmin>
      <AdminDashboard />
    </ProtectedRoute>
  );
}

// src/app/(dashboard)/super-admin/page.tsx
import ProtectedRoute from '@/components/ProtectedRoute';
import SuperAdminDashboard from '@/components/SuperAdminDashboard';

export default function SuperAdminPage() {
  return (
    <ProtectedRoute requireSuperUser>
      <SuperAdminDashboard />
    </ProtectedRoute>
  );
}
```

### 4. Dashboard Layout Integration

**Dashboard Layout with Authentication:**
```typescript
// src/components/DashboardLayout.tsx
'use client';

import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import Navigation from './Navigation';
import UserMenu from './UserMenu';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const { user, tenant, logout } = useAuth();
  const router = useRouter();

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-semibold text-gray-900">
                Spacewalker Admin
              </h1>
              {tenant && (
                <span className="ml-4 text-sm text-gray-500">
                  {tenant.name}
                </span>
              )}
            </div>

            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-700">
                {user?.name || user?.email}
              </span>

              {user?.is_super_user && (
                <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded">
                  Super User
                </span>
              )}

              {user?.is_admin && (
                <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                  Admin
                </span>
              )}

              <UserMenu user={user} onLogout={logout} />
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        <Navigation user={user} />

        <main className="flex-1 p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
```

## Session Management

### Token Management

**Automatic Token Inclusion:**
```typescript
// src/lib/api.ts - Request interceptor
api.interceptors.request.use(
  (config) => {
    // Add auth token to all requests
    const token = auth.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for handling auth errors
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      auth.logout();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);
```

**Session Persistence:**
```typescript
// Session validation hook
export const useSessionValidation = () => {
  const { user, logout } = useAuth();

  useEffect(() => {
    if (!user) return;

    const validateSession = async () => {
      try {
        await auth.getCurrentUser();
      } catch (error) {
        console.error('Session validation failed:', error);
        logout();
      }
    };

    // Validate session every 5 minutes
    const interval = setInterval(validateSession, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [user, logout]);
};
```

### Tenant Context Management

**Tenant Context Provider:**
```typescript
// src/contexts/TenantContext.tsx
'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { tenants } from '@/lib/api';
import { Tenant } from '@/types';

interface TenantContextType {
  currentTenant: Tenant | null;
  availableTenants: Tenant[];
  switchTenant: (tenantId: number) => Promise<void>;
  loading: boolean;
}

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export function TenantProvider({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated } = useAuth();
  const [currentTenant, setCurrentTenant] = useState<Tenant | null>(null);
  const [availableTenants, setAvailableTenants] = useState<Tenant[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isAuthenticated && user?.is_super_user) {
      loadAvailableTenants();
    }
  }, [isAuthenticated, user]);

  const loadAvailableTenants = async () => {
    try {
      setLoading(true);
      const tenantList = await tenants.getAll();
      setAvailableTenants(tenantList);

      // Set current tenant if not already set
      if (!currentTenant && tenantList.length > 0) {
        setCurrentTenant(tenantList[0]);
      }
    } catch (error) {
      console.error('Failed to load tenants:', error);
    } finally {
      setLoading(false);
    }
  };

  const switchTenant = async (tenantId: number) => {
    try {
      await tenants.select(tenantId);
      const selectedTenant = availableTenants.find(t => t.id === tenantId);
      if (selectedTenant) {
        setCurrentTenant(selectedTenant);
      }
    } catch (error) {
      console.error('Failed to switch tenant:', error);
      throw error;
    }
  };

  return (
    <TenantContext.Provider
      value={{
        currentTenant,
        availableTenants,
        switchTenant,
        loading,
      }}
    >
      {children}
    </TenantContext.Provider>
  );
}

export function useTenant() {
  const context = useContext(TenantContext);
  if (context === undefined) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return context;
}
```

**Tenant Selection Component:**
```typescript
// src/components/TenantSelector.tsx
'use client';

import { useTenant } from '@/contexts/TenantContext';
import { useAuth } from '@/contexts/AuthContext';

export default function TenantSelector() {
  const { user } = useAuth();
  const { currentTenant, availableTenants, switchTenant, loading } = useTenant();

  if (!user?.is_super_user || availableTenants.length <= 1) {
    return null;
  }

  return (
    <div className="relative">
      <select
        value={currentTenant?.id || ''}
        onChange={(e) => switchTenant(parseInt(e.target.value))}
        disabled={loading}
        className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
      >
        {availableTenants.map((tenant) => (
          <option key={tenant.id} value={tenant.id}>
            {tenant.name}
          </option>
        ))}
      </select>
    </div>
  );
}
```

## Role-Based Access Control

### Permission Checking Hooks

**usePermissions Hook:**
```typescript
// src/hooks/usePermissions.ts
import { useAuth } from '@/contexts/AuthContext';
import { useTenant } from '@/contexts/TenantContext';

export interface Permissions {
  canViewUsers: boolean;
  canManageUsers: boolean;
  canViewTenants: boolean;
  canManageTenants: boolean;
  canViewSurveys: boolean;
  canManageSurveys: boolean;
  canAccessAdminPanel: boolean;
  canSwitchTenants: boolean;
}

export function usePermissions(): Permissions {
  const { user } = useAuth();
  const { currentTenant } = useTenant();

  if (!user) {
    return {
      canViewUsers: false,
      canManageUsers: false,
      canViewTenants: false,
      canManageTenants: false,
      canViewSurveys: false,
      canManageSurveys: false,
      canAccessAdminPanel: false,
      canSwitchTenants: false,
    };
  }

  const isSuperUser = user.is_super_user;
  const isAdmin = user.is_admin;

  return {
    canViewUsers: isAdmin || isSuperUser,
    canManageUsers: isAdmin || isSuperUser,
    canViewTenants: isSuperUser,
    canManageTenants: isSuperUser,
    canViewSurveys: true, // All authenticated users can view surveys
    canManageSurveys: isAdmin || isSuperUser,
    canAccessAdminPanel: isAdmin || isSuperUser,
    canSwitchTenants: isSuperUser,
  };
}
```

**Permission-Based Component Rendering:**
```typescript
// src/components/ConditionalRender.tsx
import { usePermissions } from '@/hooks/usePermissions';

interface ConditionalRenderProps {
  children: React.ReactNode;
  permission: keyof ReturnType<typeof usePermissions>;
  fallback?: React.ReactNode;
}

export default function ConditionalRender({
  children,
  permission,
  fallback = null
}: ConditionalRenderProps) {
  const permissions = usePermissions();

  if (!permissions[permission]) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}

// Usage example
<ConditionalRender permission="canManageUsers">
  <button onClick={handleDeleteUser}>Delete User</button>
</ConditionalRender>

<ConditionalRender
  permission="canViewTenants"
  fallback={<div>Access denied</div>}
>
  <TenantList />
</ConditionalRender>
```

### Navigation with Role-Based Access

**Navigation Component:**
```typescript
// src/components/Navigation.tsx
'use client';

import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { usePermissions } from '@/hooks/usePermissions';
import { useRouter } from 'next/navigation';

export default function Navigation() {
  const { user } = useAuth();
  const permissions = usePermissions();
  const router = useRouter();

  const navigationItems = [
    {
      name: 'Dashboard',
      href: '/dashboard',
      permission: null, // Always visible
    },
    {
      name: 'Surveys',
      href: '/surveys',
      permission: 'canViewSurveys' as const,
    },
    {
      name: 'Users',
      href: '/users',
      permission: 'canViewUsers' as const,
    },
    {
      name: 'Tenants',
      href: '/tenants',
      permission: 'canViewTenants' as const,
    },
    {
      name: 'Admin Panel',
      href: '/admin',
      permission: 'canAccessAdminPanel' as const,
    },
  ];

  const visibleItems = navigationItems.filter(item =>
    !item.permission || permissions[item.permission]
  );

  return (
    <nav className="bg-gray-800 w-64 min-h-screen">
      <div className="p-4">
        <ul className="space-y-2">
          {visibleItems.map((item) => (
            <li key={item.name}>
              <Link
                href={item.href}
                className="block px-4 py-2 text-gray-300 hover:bg-gray-700 hover:text-white rounded"
              >
                {item.name}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
}
```

## API Integration Patterns

### Authenticated API Calls

**Standard API Call Pattern:**
```typescript
// src/lib/api.ts - API methods with authentication
export const surveys = {
  async getAll(): Promise<Survey[]> {
    const response = await api.get('/surveys');
    return response.data;
  },

  async getById(id: number): Promise<Survey> {
    const response = await api.get(`/surveys/${id}`);
    return response.data;
  },

  async create(survey: CreateSurveyRequest): Promise<Survey> {
    const response = await api.post('/surveys', survey);
    return response.data;
  },

  async update(id: number, survey: UpdateSurveyRequest): Promise<Survey> {
    const response = await api.put(`/surveys/${id}`, survey);
    return response.data;
  },

  async delete(id: number): Promise<void> {
    await api.delete(`/surveys/${id}`);
  },
};

// Usage in components
const SurveyList = () => {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadSurveys = async () => {
      try {
        const data = await surveys.getAll();
        setSurveys(data);
      } catch (error) {
        console.error('Failed to load surveys:', error);
      } finally {
        setLoading(false);
      }
    };

    loadSurveys();
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      {surveys.map((survey) => (
        <div key={survey.id}>{survey.title}</div>
      ))}
    </div>
  );
};
```

### Tenant-Specific API Calls

**Super User Tenant Selection:**
```typescript
// src/lib/api.ts - Tenant-specific API calls
export const tenants = {
  async getAll(): Promise<Tenant[]> {
    const response = await api.get('/tenants');
    return response.data;
  },

  async select(tenantId: number): Promise<void> {
    await api.post(`/auth/select-tenant/${tenantId}`);
  },

  async getCurrent(): Promise<Tenant> {
    const response = await api.get('/tenants/current');
    return response.data;
  },

  // API calls with tenant context
  async getSurveysForTenant(tenantId: number): Promise<Survey[]> {
    const response = await api.get('/surveys', {
      headers: {
        'X-Selected-Tenant-Id': tenantId.toString(),
      },
    });
    return response.data;
  },
};
```

**Tenant-Aware Component:**
```typescript
// src/components/TenantAwareSurveyList.tsx
'use client';

import { useState, useEffect } from 'react';
import { useTenant } from '@/contexts/TenantContext';
import { surveys } from '@/lib/api';

export default function TenantAwareSurveyList() {
  const { currentTenant } = useTenant();
  const [surveyList, setSurveyList] = useState<Survey[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentTenant) return;

    const loadSurveys = async () => {
      try {
        setLoading(true);
        const data = await surveys.getAll(); // Automatically uses current tenant context
        setSurveyList(data);
      } catch (error) {
        console.error('Failed to load surveys:', error);
      } finally {
        setLoading(false);
      }
    };

    loadSurveys();
  }, [currentTenant]);

  if (loading) return <div>Loading surveys...</div>;

  return (
    <div>
      <h2>Surveys for {currentTenant?.name}</h2>
      {surveyList.map((survey) => (
        <div key={survey.id} className="border p-4 mb-2">
          <h3>{survey.title}</h3>
          <p>{survey.description}</p>
        </div>
      ))}
    </div>
  );
}
```

## Testing Authentication Workflows

### Unit Tests

**AuthContext Tests:**
```typescript
// src/contexts/__tests__/AuthContext.test.tsx
import React from 'react';
import { render, screen, waitFor, act } from '@testing-library/react';
import { useRouter } from 'next/navigation';
import { AuthProvider, useAuth } from '../AuthContext';
import { auth, tenants } from '@/lib/api';

// Mock dependencies
jest.mock('next/navigation');
jest.mock('@/lib/api');

const mockAuth = auth as jest.Mocked<typeof auth>;
const mockTenants = tenants as jest.Mocked<typeof tenants>;

const TestComponent = () => {
  const { user, isAuthenticated, login, logout } = useAuth();
  return (
    <div>
      <div data-testid="authenticated">{isAuthenticated.toString()}</div>
      <div data-testid="user">{user?.email || 'none'}</div>
      <button onClick={() => login('test@example.com', 'password')}>
        Login
      </button>
      <button onClick={logout}>Logout</button>
    </div>
  );
};

describe('AuthContext', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should handle successful login', async () => {
    mockAuth.login.mockResolvedValueOnce(undefined);
    mockAuth.getCurrentUser.mockResolvedValueOnce({
      id: 1,
      email: 'test@example.com',
      name: 'Test User',
      is_admin: false,
      is_super_user: false,
    } as User);

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    const loginButton = screen.getByText('Login');

    await act(async () => {
      loginButton.click();
    });

    await waitFor(() => {
      expect(screen.getByTestId('authenticated')).toHaveTextContent('true');
      expect(screen.getByTestId('user')).toHaveTextContent('test@example.com');
    });
  });

  it('should handle logout', async () => {
    // Setup authenticated state first
    mockAuth.getToken.mockReturnValue('valid-token');
    mockAuth.getCurrentUser.mockResolvedValueOnce({
      id: 1,
      email: 'test@example.com',
      name: 'Test User',
      is_admin: false,
      is_super_user: false,
    } as User);

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );

    await waitFor(() => {
      expect(screen.getByTestId('authenticated')).toHaveTextContent('true');
    });

    const logoutButton = screen.getByText('Logout');

    await act(async () => {
      logoutButton.click();
    });

    await waitFor(() => {
      expect(screen.getByTestId('authenticated')).toHaveTextContent('false');
      expect(screen.getByTestId('user')).toHaveTextContent('none');
    });
  });
});
```

### Integration Tests

**Authentication Flow Tests:**
```typescript
// src/__tests__/integration/auth-workflow.integration.test.tsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { AuthProvider } from '@/contexts/AuthContext';
import LoginPage from '@/app/login/page';
import { auth } from '@/lib/api';

// Mock API
jest.mock('@/lib/api');
const mockAuth = auth as jest.Mocked<typeof auth>;

describe('Authentication Workflow Integration', () => {
  it('should complete full login workflow', async () => {
    // Mock successful login
    mockAuth.login.mockResolvedValueOnce(undefined);
    mockAuth.getCurrentUser.mockResolvedValueOnce({
      id: 1,
      email: 'admin@example.com',
      name: 'Admin User',
      is_admin: true,
      is_super_user: false,
    } as User);

    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );

    // Fill login form
    const emailInput = screen.getByLabelText(/email/i);
    const passwordInput = screen.getByLabelText(/password/i);
    const submitButton = screen.getByRole('button', { name: /sign in/i });

    fireEvent.change(emailInput, { target: { value: 'admin@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(submitButton);

    // Verify API calls
    await waitFor(() => {
      expect(mockAuth.login).toHaveBeenCalledWith('admin@example.com', 'password123');
    });

    // Verify navigation would occur (mocked)
    expect(mockAuth.getCurrentUser).toHaveBeenCalled();
  });

  it('should handle login errors', async () => {
    // Mock failed login
    mockAuth.login.mockRejectedValueOnce(new Error('Invalid credentials'));

    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );

    const emailInput = screen.getByLabelText(/email/i);
    const passwordInput = screen.getByLabelText(/password/i);
    const submitButton = screen.getByRole('button', { name: /sign in/i });

    fireEvent.change(emailInput, { target: { value: 'wrong@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'wrongpassword' } });
    fireEvent.click(submitButton);

    // Verify error message appears
    await waitFor(() => {
      expect(screen.getByText(/invalid credentials/i)).toBeInTheDocument();
    });
  });
});
```

## Troubleshooting

### Common Issues

**Authentication Not Persisting:**
```typescript
// Check token storage
console.log('Token in localStorage:', localStorage.getItem('auth_token'));

// Verify token format
import jwt from 'jsonwebtoken';
const token = localStorage.getItem('auth_token');
if (token) {
  const decoded = jwt.decode(token);
  console.log('Token payload:', decoded);
}
```

**Protected Routes Not Working:**
```typescript
// Debug authentication state
const DebugAuth = () => {
  const { user, loading, isAuthenticated } = useAuth();

  return (
    <div>
      <p>Loading: {loading.toString()}</p>
      <p>Authenticated: {isAuthenticated.toString()}</p>
      <p>User: {JSON.stringify(user)}</p>
    </div>
  );
};
```

**API Authentication Errors:**
```typescript
// Check request headers
api.interceptors.request.use(
  (config) => {
    console.log('Request headers:', config.headers);
    return config;
  }
);

// Check response errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error.response?.data);
    return Promise.reject(error);
  }
);
```

### Debug Commands

**Browser Console Debug:**
```javascript
// Check authentication state
window.localStorage.getItem('auth_token');

// Decode JWT token
function parseJwt(token) {
  const base64Url = token.split('.')[1];
  const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
  }).join(''));
  return JSON.parse(jsonPayload);
}

parseJwt(localStorage.getItem('auth_token'));
```

**Network Debug:**
```bash
# Test API endpoints
curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost:3000/me

# Test login
curl -X POST http://localhost:3000/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password"}'
```

## Related Documentation
- [Backend Authentication API](../backend/authentication-api.md) - API endpoint documentation
- [Super User Security](../backend/super-user-security.md) - Elevated permission management
- [Admin Architecture](./architecture/admin-container-architecture.md) - Overall admin application architecture
- [Security Architecture](../architecture/security-architecture.md) - System-wide security design

---
**Status**: ✅ Current
**Last Updated**: 2025-07-09
**Technology Stack**: Next.js, React, TypeScript, Tailwind CSS
