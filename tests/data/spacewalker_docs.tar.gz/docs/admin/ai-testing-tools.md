# AI Testing Tools & Admin Dashboard

## Purpose
Comprehensive guide for AI testing interfaces, validation dashboards, and diagnostic tools within the admin web application. Essential reference for validating AI analysis workflows, monitoring performance, and troubleshooting issues through the admin interface.

## When to Use This
- Testing AI analysis endpoints through admin dashboard
- Validating AI response quality and consistency
- Monitoring cost analysis and performance metrics
- Troubleshooting AI integration issues via web interface
- Conducting A/B tests for prompt optimization
- Keywords: AI testing, admin dashboard, validation interfaces, cost analysis, debugging tools

**Version:** 1.0
**Date:** 2025-07-10
**Status:** Current - AI Testing Tools Technical Reference

---

## 🚀 Quick Start

### Accessing AI Testing Tools
Navigate to the AI Testing section in the admin dashboard:
```
https://admin.spacewalker.littleponies.com/dev-admin/ai-testing
```

### Basic AI Analysis Test
1. Upload a test image
2. Select AI model (flash_lite, flash, flash_8b)
3. Choose analysis type (standard, detailed, quick)
4. Click "Analyze Image"
5. Review results including cost analysis

### Key Testing Interfaces
- **Single Image Analysis**: Test individual images with different models
- **Batch Testing**: Process multiple images for comparison
- **A/B Testing Dashboard**: Compare different prompt templates
- **Cost Analysis Monitor**: Track token usage and costs
- **Response Validation**: Verify response format compliance

---

## 🎛️ Admin Dashboard Interface Overview

### AI Testing Dashboard Layout

#### Main Navigation
```typescript
interface AITestingNavigation {
    sections: {
        singleTest: "Single Image Analysis";
        batchTest: "Batch Testing";
        abTesting: "A/B Testing";
        costMonitor: "Cost Analysis";
        responseValidation: "Response Validation";
        promptManagement: "Prompt Templates";
    };
}
```

#### Dashboard Components
```typescript
// Main dashboard component structure
interface AITestingDashboard {
    header: {
        title: "AI Analysis Testing Tools";
        subtitle: "Test, validate, and monitor AI analysis performance";
        quickStats: {
            totalTests: number;
            avgConfidence: number;
            totalCost: number;
            errorRate: number;
        };
    };

    testingPanels: {
        imageUpload: ImageUploadComponent;
        modelSelection: ModelSelectionComponent;
        resultsDisplay: ResultsDisplayComponent;
        costAnalysis: CostAnalysisComponent;
    };

    monitoringWidgets: {
        performanceChart: PerformanceChartComponent;
        costTrends: CostTrendsComponent;
        errorLog: ErrorLogComponent;
        confidenceDistribution: ConfidenceDistributionComponent;
    };
}
```

### Component Integration

#### Image Upload Component
```typescript
interface ImageUploadComponent {
    features: {
        dragAndDrop: boolean;
        multipleFiles: boolean;
        previewThumbnails: boolean;
        formatValidation: boolean;
        sizeValidation: boolean;
    };

    supportedFormats: ['JPEG', 'PNG', 'GIF'];
    maxFileSize: '10MB';
    maxFiles: 10;

    validationRules: {
        imageFormat: (file: File) => boolean;
        fileSize: (file: File) => boolean;
        imageQuality: (file: File) => Promise<QualityScore>;
    };
}

// Implementation example
const ImageUploadPanel: React.FC = () => {
    const [uploadedImages, setUploadedImages] = useState<File[]>([]);
    const [validationResults, setValidationResults] = useState<ValidationResult[]>([]);

    const handleImageUpload = async (files: File[]) => {
        const validatedFiles = await Promise.all(
            files.map(async (file) => {
                const validation = await validateImageForAI(file);
                return { file, validation };
            })
        );

        setUploadedImages(files);
        setValidationResults(validatedFiles.map(v => v.validation));
    };

    return (
        <UploadArea
            onFilesSelected={handleImageUpload}
            accept="image/*"
            multiple
            maxSize={10 * 1024 * 1024} // 10MB
        >
            <ImagePreviewGrid images={uploadedImages} />
            <ValidationSummary results={validationResults} />
        </UploadArea>
    );
};
```

#### Model Selection Component
```typescript
interface ModelSelectionConfig {
    models: {
        flash_lite: {
            name: "Gemini Flash Lite";
            description: "Fast, cost-effective analysis";
            costPerToken: 0.000015;
            avgProcessingTime: "1-2 seconds";
            useCase: "Quick classification, high volume";
        };
        flash: {
            name: "Gemini Flash";
            description: "Balanced performance and accuracy";
            costPerToken: 0.00015;
            avgProcessingTime: "2-4 seconds";
            useCase: "Standard analysis, balanced needs";
        };
        flash_8b: {
            name: "Gemini Flash 8B";
            description: "High accuracy, detailed analysis";
            costPerToken: 0.0003;
            avgProcessingTime: "4-8 seconds";
            useCase: "Complex analysis, high accuracy required";
        };
    };

    analysisTypes: {
        standard: "Standard room analysis";
        detailed: "Comprehensive analysis with all attributes";
        quick: "Fast classification only";
    };
}

const ModelSelectionPanel: React.FC = () => {
    const [selectedModel, setSelectedModel] = useState<string>('flash_lite');
    const [analysisType, setAnalysisType] = useState<string>('standard');
    const [estimatedCost, setEstimatedCost] = useState<number>(0);

    useEffect(() => {
        // Update cost estimation when model or analysis type changes
        const estimate = calculateEstimatedCost(selectedModel, analysisType);
        setEstimatedCost(estimate);
    }, [selectedModel, analysisType]);

    return (
        <SelectionPanel>
            <ModelSelector
                models={ModelSelectionConfig.models}
                selected={selectedModel}
                onChange={setSelectedModel}
            />
            <AnalysisTypeSelector
                types={ModelSelectionConfig.analysisTypes}
                selected={analysisType}
                onChange={setAnalysisType}
            />
            <CostEstimator
                model={selectedModel}
                analysisType={analysisType}
                estimatedCost={estimatedCost}
            />
        </SelectionPanel>
    );
};
```

---

## 🧪 Single Image Analysis Testing

### Test Execution Workflow

#### Analysis Request Interface
```typescript
interface AnalysisRequest {
    imageFile: File;
    modelConfig: {
        model: 'flash_lite' | 'flash' | 'flash_8b';
        analysisType: 'standard' | 'detailed' | 'quick';
        includeRawResponse: boolean;
        customPrompt?: string;
    };
    testMetadata: {
        testName: string;
        description: string;
        expectedResults?: Partial<AIResponse>;
    };
}

const SingleImageTester: React.FC = () => {
    const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
    const [analysisResult, setAnalysisResult] = useState<AIResponse | null>(null);
    const [error, setError] = useState<string | null>(null);

    const executeAnalysis = async (request: AnalysisRequest) => {
        setIsAnalyzing(true);
        setError(null);

        try {
            // Convert image to base64
            const imageBase64 = await fileToBase64(request.imageFile);

            // Call AI analysis API
            const response = await fetch('/api/ai/analyze-image', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${authToken}`
                },
                body: JSON.stringify({
                    image_base64: imageBase64,
                    model: request.modelConfig.model,
                    analysis_type: request.modelConfig.analysisType,
                    include_raw_response: request.modelConfig.includeRawResponse,
                    custom_prompt: request.modelConfig.customPrompt
                })
            });

            if (!response.ok) {
                throw new Error(`Analysis failed: ${response.statusText}`);
            }

            const result = await response.json();
            setAnalysisResult(result);

            // Log test result for tracking
            logTestResult(request, result);

        } catch (err) {
            setError(err instanceof Error ? err.message : 'Unknown error');
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <TestingPanel>
            <AnalysisRequestForm onSubmit={executeAnalysis} />
            {isAnalyzing && <LoadingIndicator />}
            {error && <ErrorDisplay error={error} />}
            {analysisResult && <ResultsViewer result={analysisResult} />}
        </TestingPanel>
    );
};
```

#### Results Visualization

```typescript
interface ResultsViewer {
    sections: {
        overview: OverviewSection;
        detailedResults: DetailedResultsSection;
        costAnalysis: CostAnalysisSection;
        performanceMetrics: PerformanceMetricsSection;
        validationStatus: ValidationStatusSection;
    };
}

const ResultsViewer: React.FC<{result: AIResponse}> = ({ result }) => {
    return (
        <ResultsContainer>
            {/* Overview Section */}
            <OverviewCard>
                <ResultSummary>
                    <RoomType value={result.room_type} />
                    <FICMCode value={result.ficm_code} />
                    <ConfidenceScore
                        value={result.confidence}
                        threshold={0.8}
                    />
                </ResultSummary>

                <QuickStats>
                    <Stat label="Capacity" value={result.capacity} />
                    <Stat label="Square Footage" value={result.square_footage} />
                    <Stat label="Processing Time" value={`${result.processing_time_ms}ms`} />
                </QuickStats>
            </OverviewCard>

            {/* Detailed Results */}
            <DetailedResultsPanel>
                <FurnitureInventory furniture={result.furniture} />
                <EquipmentList equipment={result.equipment} />
                <AttributesGrid attributes={result.attributes} />
            </DetailedResultsPanel>

            {/* Cost Analysis */}
            <CostAnalysisPanel>
                <TokenUsage
                    inputTokens={result.token_usage.input_tokens}
                    outputTokens={result.token_usage.output_tokens}
                    totalTokens={result.token_usage.total_tokens}
                />
                <CostBreakdown
                    inputCost={result.cost_analysis.input_cost}
                    outputCost={result.cost_analysis.output_cost}
                    totalCost={result.cost_analysis.total_cost}
                />
            </CostAnalysisPanel>

            {/* Performance Metrics */}
            <PerformancePanel>
                <ProcessingTime value={result.processing_time_ms} />
                <ModelUsed value={result.model_used} />
                <ResponseValidation result={validateResponseFormat(result)} />
            </PerformancePanel>
        </ResultsContainer>
    );
};
```

### Response Validation Tools

#### Format Compliance Checker
```typescript
interface ValidationResult {
    isValid: boolean;
    errors: ValidationError[];
    warnings: ValidationWarning[];
    score: number; // 0-100
}

interface ValidationError {
    field: string;
    expected: string;
    actual: string;
    severity: 'error' | 'warning';
}

const validateResponseFormat = (response: AIResponse): ValidationResult => {
    const errors: ValidationError[] = [];
    const warnings: ValidationWarning[] = [];

    // Check required fields
    const requiredFields = ['room_type', 'ficm_code', 'confidence'];
    for (const field of requiredFields) {
        if (!(field in response) || response[field] === null || response[field] === undefined) {
            errors.push({
                field,
                expected: 'Required field',
                actual: 'Missing or null',
                severity: 'error'
            });
        }
    }

    // Validate capacity format
    if ('capacity' in response) {
        if (typeof response.capacity === 'object') {
            errors.push({
                field: 'capacity',
                expected: 'Simple integer',
                actual: 'Nested object',
                severity: 'error'
            });
        } else if (typeof response.capacity !== 'number' || response.capacity < 0) {
            errors.push({
                field: 'capacity',
                expected: 'Positive integer',
                actual: `${typeof response.capacity}: ${response.capacity}`,
                severity: 'error'
            });
        }
    }

    // Validate confidence range
    if (response.confidence < 0 || response.confidence > 1) {
        errors.push({
            field: 'confidence',
            expected: 'Number between 0 and 1',
            actual: `${response.confidence}`,
            severity: 'error'
        });
    }

    // Check furniture structure
    if (response.furniture) {
        for (const [itemType, data] of Object.entries(response.furniture)) {
            if (!data.count || !data.confidence) {
                errors.push({
                    field: `furniture.${itemType}`,
                    expected: 'Object with count and confidence',
                    actual: JSON.stringify(data),
                    severity: 'error'
                });
            }
        }
    }

    // Calculate validation score
    const totalChecks = requiredFields.length + 5; // Additional specific checks
    const passedChecks = totalChecks - errors.length;
    const score = Math.round((passedChecks / totalChecks) * 100);

    return {
        isValid: errors.length === 0,
        errors,
        warnings,
        score
    };
};

const ValidationStatusDisplay: React.FC<{result: ValidationResult}> = ({ result }) => {
    return (
        <ValidationPanel>
            <ValidationScore
                score={result.score}
                isValid={result.isValid}
            />

            {result.errors.length > 0 && (
                <ErrorsList>
                    {result.errors.map((error, index) => (
                        <ErrorItem key={index} error={error} />
                    ))}
                </ErrorsList>
            )}

            {result.warnings.length > 0 && (
                <WarningsList>
                    {result.warnings.map((warning, index) => (
                        <WarningItem key={index} warning={warning} />
                    ))}
                </WarningsList>
            )}

            <ValidationSummary>
                <SummaryItem
                    label="Format Compliance"
                    value={`${result.score}%`}
                    status={result.isValid ? 'pass' : 'fail'}
                />
                <SummaryItem
                    label="Errors Found"
                    value={result.errors.length}
                    status={result.errors.length === 0 ? 'pass' : 'fail'}
                />
                <SummaryItem
                    label="Data Quality"
                    value={result.score > 80 ? 'Good' : 'Needs Review'}
                    status={result.score > 80 ? 'pass' : 'warning'}
                />
            </ValidationSummary>
        </ValidationPanel>
    );
};
```

---

## 📊 Batch Testing Interface

### Multi-Image Analysis

#### Batch Test Configuration
```typescript
interface BatchTestConfig {
    testName: string;
    description: string;
    images: File[];
    modelConfigs: {
        models: ('flash_lite' | 'flash' | 'flash_8b')[];
        analysisType: 'standard' | 'detailed' | 'quick';
        includeComparison: boolean;
    };
    expectedResults?: {
        [imageName: string]: Partial<AIResponse>;
    };
    testCriteria: {
        minConfidence: number;
        maxProcessingTime: number;
        maxCostPerImage: number;
    };
}

const BatchTestingInterface: React.FC = () => {
    const [testConfig, setTestConfig] = useState<BatchTestConfig | null>(null);
    const [isRunning, setIsRunning] = useState<boolean>(false);
    const [results, setResults] = useState<BatchTestResults | null>(null);
    const [progress, setProgress] = useState<number>(0);

    const executeBatchTest = async (config: BatchTestConfig) => {
        setIsRunning(true);
        setProgress(0);

        const results: BatchTestResults = {
            testId: generateTestId(),
            config,
            startTime: new Date(),
            imageResults: [],
            summary: null
        };

        try {
            const totalOperations = config.images.length * config.modelConfigs.models.length;
            let completedOperations = 0;

            for (const image of config.images) {
                const imageResults: ImageTestResult[] = [];

                for (const model of config.modelConfigs.models) {
                    try {
                        const result = await analyzeImageWithModel(image, model, config.modelConfigs.analysisType);
                        const validation = validateResponseFormat(result);

                        imageResults.push({
                            model,
                            result,
                            validation,
                            meetsCriteria: checkTestCriteria(result, config.testCriteria)
                        });

                    } catch (error) {
                        imageResults.push({
                            model,
                            error: error.message,
                            meetsCriteria: false
                        });
                    }

                    completedOperations++;
                    setProgress((completedOperations / totalOperations) * 100);
                }

                results.imageResults.push({
                    imageName: image.name,
                    imageSize: image.size,
                    results: imageResults
                });
            }

            // Generate summary
            results.summary = generateBatchSummary(results);
            results.endTime = new Date();

            setResults(results);

        } catch (error) {
            console.error('Batch test failed:', error);
        } finally {
            setIsRunning(false);
        }
    };

    return (
        <BatchTestingPanel>
            <TestConfigurationForm
                onConfigSubmit={setTestConfig}
                onExecute={executeBatchTest}
            />

            {isRunning && (
                <ProgressTracker
                    progress={progress}
                    status="Running batch analysis..."
                />
            )}

            {results && (
                <BatchResultsViewer results={results} />
            )}
        </BatchTestingPanel>
    );
};
```

#### Results Comparison Tools

```typescript
interface ComparisonAnalysis {
    modelComparison: ModelComparisonData;
    consistencyAnalysis: ConsistencyAnalysisData;
    performanceComparison: PerformanceComparisonData;
    costAnalysis: CostComparisonData;
}

const ModelComparisonViewer: React.FC<{results: BatchTestResults}> = ({ results }) => {
    const comparisonData = useMemo(() => {
        return generateComparisonAnalysis(results);
    }, [results]);

    return (
        <ComparisonContainer>
            {/* Model Performance Comparison */}
            <ModelPerformanceChart>
                <ChartTitle>Model Performance Comparison</ChartTitle>
                <BarChart
                    data={comparisonData.modelComparison.performanceMetrics}
                    xAxis="model"
                    yAxis="avgConfidence"
                    colorScheme="performance"
                />
                <MetricsSummary>
                    {comparisonData.modelComparison.models.map(model => (
                        <ModelSummaryCard key={model.name}>
                            <ModelName>{model.name}</ModelName>
                            <MetricGrid>
                                <Metric label="Avg Confidence" value={`${model.avgConfidence.toFixed(2)}`} />
                                <Metric label="Avg Time" value={`${model.avgProcessingTime}ms`} />
                                <Metric label="Avg Cost" value={`$${model.avgCost.toFixed(4)}`} />
                                <Metric label="Success Rate" value={`${model.successRate.toFixed(1)}%`} />
                            </MetricGrid>
                        </ModelSummaryCard>
                    ))}
                </MetricsSummary>
            </ModelPerformanceChart>

            {/* Consistency Analysis */}
            <ConsistencyAnalysisPanel>
                <PanelTitle>Response Consistency Analysis</PanelTitle>
                <ConsistencyMetrics>
                    <ConsistencyScore
                        score={comparisonData.consistencyAnalysis.overallScore}
                        threshold={0.8}
                    />
                    <VarianceAnalysis
                        data={comparisonData.consistencyAnalysis.varianceMetrics}
                    />
                </ConsistencyMetrics>

                <InconsistentResultsTable>
                    <TableHeader>
                        <th>Image</th>
                        <th>Inconsistent Field</th>
                        <th>Model Variations</th>
                        <th>Confidence Range</th>
                    </TableHeader>
                    {comparisonData.consistencyAnalysis.inconsistencies.map(inconsistency => (
                        <InconsistencyRow key={inconsistency.id} data={inconsistency} />
                    ))}
                </InconsistentResultsTable>
            </ConsistencyAnalysisPanel>

            {/* Cost-Effectiveness Analysis */}
            <CostEffectivenessPanel>
                <PanelTitle>Cost-Effectiveness Analysis</PanelTitle>
                <CostVsPerformanceChart>
                    <ScatterPlot
                        data={comparisonData.costAnalysis.costVsPerformance}
                        xAxis="cost"
                        yAxis="performance"
                        colorBy="model"
                        title="Cost vs Performance Trade-off"
                    />
                </CostVsPerformanceChart>

                <RecommendationEngine>
                    <RecommendationCard>
                        <RecommendationTitle>Optimal Model Selection</RecommendationTitle>
                        <RecommendationList>
                            {comparisonData.costAnalysis.recommendations.map(rec => (
                                <RecommendationItem key={rec.id}>
                                    <UseCase>{rec.useCase}</UseCase>
                                    <RecommendedModel>{rec.recommendedModel}</RecommendedModel>
                                    <Justification>{rec.justification}</Justification>
                                </RecommendationItem>
                            ))}
                        </RecommendationList>
                    </RecommendationCard>
                </RecommendationEngine>
            </CostEffectivenessPanel>
        </ComparisonContainer>
    );
};
```

---

## 🎯 A/B Testing Dashboard

### Test Management Interface

#### Creating A/B Tests
```typescript
interface ABTestCreationForm {
    basicInfo: {
        testName: string;
        description: string;
        hypothesis: string;
        duration: number; // days
        minimumSampleSize: number;
    };

    templateConfiguration: {
        controlTemplate: PromptTemplate;
        variantTemplates: PromptTemplate[];
        trafficSplit: {
            control: number;
            variants: number[];
        };
    };

    successMetrics: {
        primaryMetric: 'confidence' | 'processing_time' | 'cost_efficiency';
        secondaryMetrics: string[];
        thresholds: {
            [metric: string]: number;
        };
    };
}

const ABTestCreationWizard: React.FC = () => {
    const [currentStep, setCurrentStep] = useState<number>(1);
    const [testConfig, setTestConfig] = useState<Partial<ABTestCreationForm>>({});

    const steps = [
        { title: "Basic Information", component: BasicInfoStep },
        { title: "Template Configuration", component: TemplateConfigStep },
        { title: "Success Metrics", component: MetricsConfigStep },
        { title: "Review & Launch", component: ReviewStep }
    ];

    const handleStepComplete = (stepData: any) => {
        setTestConfig(prev => ({ ...prev, ...stepData }));

        if (currentStep < steps.length) {
            setCurrentStep(prev => prev + 1);
        } else {
            // Launch test
            launchABTest(testConfig as ABTestCreationForm);
        }
    };

    return (
        <WizardContainer>
            <WizardProgress
                currentStep={currentStep}
                totalSteps={steps.length}
                steps={steps.map(s => s.title)}
            />

            <StepContainer>
                {React.createElement(steps[currentStep - 1].component, {
                    data: testConfig,
                    onComplete: handleStepComplete,
                    onBack: () => setCurrentStep(prev => Math.max(1, prev - 1))
                })}
            </StepContainer>
        </WizardContainer>
    );
};
```

#### Live Test Monitoring
```typescript
interface ABTestMonitor {
    testStatus: 'running' | 'paused' | 'completed';
    progress: {
        currentSampleSize: number;
        targetSampleSize: number;
        daysRemaining: number;
        estimatedCompletion: Date;
    };

    realtimeMetrics: {
        controlGroup: GroupMetrics;
        variantGroups: GroupMetrics[];
    };

    statisticalSignificance: {
        [metric: string]: {
            pValue: number;
            isSignificant: boolean;
            confidenceInterval: [number, number];
        };
    };
}

const ABTestMonitorDashboard: React.FC<{testId: string}> = ({ testId }) => {
    const [monitorData, setMonitorData] = useState<ABTestMonitor | null>(null);
    const [autoRefresh, setAutoRefresh] = useState<boolean>(true);

    useEffect(() => {
        const fetchMonitorData = async () => {
            try {
                const response = await fetch(`/api/admin/ab-tests/${testId}/monitor`);
                const data = await response.json();
                setMonitorData(data);
            } catch (error) {
                console.error('Failed to fetch monitor data:', error);
            }
        };

        fetchMonitorData();

        if (autoRefresh) {
            const interval = setInterval(fetchMonitorData, 30000); // 30 seconds
            return () => clearInterval(interval);
        }
    }, [testId, autoRefresh]);

    if (!monitorData) {
        return <LoadingSpinner />;
    }

    return (
        <MonitorDashboard>
            {/* Test Status Header */}
            <StatusHeader>
                <TestStatus status={monitorData.testStatus} />
                <ProgressIndicator
                    current={monitorData.progress.currentSampleSize}
                    target={monitorData.progress.targetSampleSize}
                />
                <TimeRemaining days={monitorData.progress.daysRemaining} />

                <ControlButtons>
                    <PauseResumeButton testId={testId} status={monitorData.testStatus} />
                    <StopTestButton testId={testId} />
                    <ExportDataButton testId={testId} />
                </ControlButtons>
            </StatusHeader>

            {/* Real-time Metrics */}
            <MetricsContainer>
                <GroupComparisonChart>
                    <ChartTitle>Real-time Performance Comparison</ChartTitle>
                    <MultiLineChart
                        data={formatTimeSeriesData(monitorData.realtimeMetrics)}
                        lines={['control', ...monitorData.variantGroups.map((_, i) => `variant_${i}`)]}
                        xAxis="timestamp"
                        yAxis="confidence"
                    />
                </GroupComparisonChart>

                <StatisticalSignificancePanel>
                    <PanelTitle>Statistical Significance</PanelTitle>
                    {Object.entries(monitorData.statisticalSignificance).map(([metric, stats]) => (
                        <SignificanceIndicator
                            key={metric}
                            metric={metric}
                            pValue={stats.pValue}
                            isSignificant={stats.isSignificant}
                            confidenceInterval={stats.confidenceInterval}
                        />
                    ))}
                </StatisticalSignificancePanel>
            </MetricsContainer>

            {/* Group Performance Details */}
            <GroupDetailsGrid>
                <GroupCard group="control" metrics={monitorData.realtimeMetrics.controlGroup} />
                {monitorData.realtimeMetrics.variantGroups.map((group, index) => (
                    <GroupCard
                        key={index}
                        group={`variant_${index}`}
                        metrics={group}
                    />
                ))}
            </GroupDetailsGrid>
        </MonitorDashboard>
    );
};
```

---

## 💰 Cost Analysis & Monitoring

### Cost Tracking Dashboard

#### Real-time Cost Monitoring
```typescript
interface CostMonitoringDashboard {
    overview: {
        dailyCost: number;
        monthlyCost: number;
        projectedMonthlyCost: number;
        costPerRequest: number;
        budgetUtilization: number;
    };

    breakdowns: {
        byModel: ModelCostBreakdown[];
        byTenant: TenantCostBreakdown[];
        byTimeOfDay: TimeBasedCostData[];
    };

    trends: {
        costTrend: CostTrendData[];
        usageTrend: UsageTrendData[];
        efficiencyTrend: EfficiencyTrendData[];
    };

    alerts: CostAlert[];
}

const CostMonitoringWidget: React.FC = () => {
    const [costData, setCostData] = useState<CostMonitoringDashboard | null>(null);
    const [timeRange, setTimeRange] = useState<string>('24h');

    return (
        <CostDashboardContainer>
            {/* Overview Cards */}
            <OverviewMetrics>
                <CostCard
                    title="Daily Cost"
                    value={`$${costData?.overview.dailyCost.toFixed(2)}`}
                    trend={calculateDailyTrend(costData)}
                    target="< $100/day"
                />
                <CostCard
                    title="Monthly Projection"
                    value={`$${costData?.overview.projectedMonthlyCost.toFixed(2)}`}
                    trend={calculateMonthlyTrend(costData)}
                    target="< $2,500/month"
                />
                <CostCard
                    title="Cost per Request"
                    value={`$${costData?.overview.costPerRequest.toFixed(4)}`}
                    trend={calculateCostPerRequestTrend(costData)}
                    target="< $0.05"
                />
                <CostCard
                    title="Budget Utilization"
                    value={`${costData?.overview.budgetUtilization.toFixed(1)}%`}
                    trend={calculateBudgetTrend(costData)}
                    target="< 80%"
                />
            </OverviewMetrics>

            {/* Cost Breakdown Charts */}
            <BreakdownChartsGrid>
                <ModelCostChart>
                    <ChartTitle>Cost by Model</ChartTitle>
                    <PieChart
                        data={costData?.breakdowns.byModel}
                        valueKey="cost"
                        labelKey="model"
                        colorScheme="cost"
                    />
                    <CostTable data={costData?.breakdowns.byModel} />
                </ModelCostChart>

                <TenantCostChart>
                    <ChartTitle>Cost by Tenant</ChartTitle>
                    <BarChart
                        data={costData?.breakdowns.byTenant}
                        xAxis="tenantName"
                        yAxis="cost"
                        colorScheme="tenant"
                    />
                </TenantCostChart>

                <TimeBasedCostChart>
                    <ChartTitle>Cost by Time of Day</ChartTitle>
                    <LineChart
                        data={costData?.breakdowns.byTimeOfDay}
                        xAxis="hour"
                        yAxis="cost"
                        colorScheme="time"
                    />
                </TimeBasedCostChart>
            </BreakdownChartsGrid>

            {/* Cost Optimization Recommendations */}
            <OptimizationPanel>
                <PanelTitle>Cost Optimization Recommendations</PanelTitle>
                <RecommendationsList>
                    {generateCostOptimizationRecommendations(costData).map(rec => (
                        <RecommendationCard key={rec.id}>
                            <RecommendationType>{rec.type}</RecommendationType>
                            <RecommendationText>{rec.description}</RecommendationText>
                            <PotentialSavings>
                                Potential savings: ${rec.potentialSavings.toFixed(2)}/month
                            </PotentialSavings>
                            <ImplementButton
                                onClick={() => implementRecommendation(rec)}
                                disabled={!rec.implementable}
                            >
                                {rec.implementable ? 'Implement' : 'Manual Action Required'}
                            </ImplementButton>
                        </RecommendationCard>
                    ))}
                </RecommendationsList>
            </OptimizationPanel>
        </CostDashboardContainer>
    );
};
```

#### Budget Management Tools
```typescript
interface BudgetManagementConfig {
    budgets: {
        daily: number;
        monthly: number;
        tenantLimits: {
            [tenantId: string]: number;
        };
    };

    alerts: {
        thresholds: number[]; // [50, 75, 90, 95] percent
        recipients: string[];
        channels: ('email' | 'slack' | 'dashboard')[];
    };

    controls: {
        autoThrottling: boolean;
        emergencyStop: boolean;
        modelDowngrading: boolean;
    };
}

const BudgetManagementPanel: React.FC = () => {
    const [budgetConfig, setBudgetConfig] = useState<BudgetManagementConfig | null>(null);
    const [currentUtilization, setCurrentUtilization] = useState<number>(0);

    const handleBudgetUpdate = async (newBudget: Partial<BudgetManagementConfig>) => {
        try {
            await fetch('/api/admin/budget-config', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newBudget)
            });

            setBudgetConfig(prev => ({ ...prev, ...newBudget }));
        } catch (error) {
            console.error('Failed to update budget configuration:', error);
        }
    };

    return (
        <BudgetManagementContainer>
            {/* Budget Configuration */}
            <BudgetConfigSection>
                <SectionTitle>Budget Limits</SectionTitle>
                <BudgetInputGrid>
                    <BudgetInput
                        label="Daily Budget"
                        value={budgetConfig?.budgets.daily}
                        onChange={(value) => handleBudgetUpdate({
                            budgets: { ...budgetConfig?.budgets, daily: value }
                        })}
                        unit="USD"
                    />
                    <BudgetInput
                        label="Monthly Budget"
                        value={budgetConfig?.budgets.monthly}
                        onChange={(value) => handleBudgetUpdate({
                            budgets: { ...budgetConfig?.budgets, monthly: value }
                        })}
                        unit="USD"
                    />
                </BudgetInputGrid>

                <TenantBudgetTable>
                    <TableHeader>
                        <th>Tenant</th>
                        <th>Monthly Limit</th>
                        <th>Current Usage</th>
                        <th>Utilization</th>
                        <th>Actions</th>
                    </TableHeader>
                    {Object.entries(budgetConfig?.budgets.tenantLimits || {}).map(([tenantId, limit]) => (
                        <TenantBudgetRow
                            key={tenantId}
                            tenantId={tenantId}
                            limit={limit}
                            onLimitChange={(newLimit) => updateTenantLimit(tenantId, newLimit)}
                        />
                    ))}
                </TenantBudgetTable>
            </BudgetConfigSection>

            {/* Alert Configuration */}
            <AlertConfigSection>
                <SectionTitle>Budget Alerts</SectionTitle>
                <AlertThresholds>
                    {budgetConfig?.alerts.thresholds.map((threshold, index) => (
                        <ThresholdInput
                            key={index}
                            value={threshold}
                            onChange={(newThreshold) => updateAlertThreshold(index, newThreshold)}
                            label={`Alert ${index + 1}`}
                        />
                    ))}
                </AlertThresholds>

                <AlertChannels>
                    {['email', 'slack', 'dashboard'].map(channel => (
                        <ChannelToggle
                            key={channel}
                            channel={channel}
                            enabled={budgetConfig?.alerts.channels.includes(channel)}
                            onChange={(enabled) => toggleAlertChannel(channel, enabled)}
                        />
                    ))}
                </AlertChannels>
            </AlertConfigSection>

            {/* Automatic Controls */}
            <AutoControlsSection>
                <SectionTitle>Automatic Cost Controls</SectionTitle>
                <ControlsGrid>
                    <ControlToggle
                        label="Auto-throttling"
                        description="Automatically reduce request rate when approaching budget limits"
                        enabled={budgetConfig?.controls.autoThrottling}
                        onChange={(enabled) => updateControl('autoThrottling', enabled)}
                    />
                    <ControlToggle
                        label="Emergency Stop"
                        description="Automatically disable AI requests when budget exceeded"
                        enabled={budgetConfig?.controls.emergencyStop}
                        onChange={(enabled) => updateControl('emergencyStop', enabled)}
                    />
                    <ControlToggle
                        label="Model Downgrading"
                        description="Automatically use cheaper models when approaching limits"
                        enabled={budgetConfig?.controls.modelDowngrading}
                        onChange={(enabled) => updateControl('modelDowngrading', enabled)}
                    />
                </ControlsGrid>
            </AutoControlsSection>
        </BudgetManagementContainer>
    );
};
```

---

## 🔧 Debugging & Diagnostic Tools

### Request Debugging Interface

#### Detailed Request Analysis
```typescript
interface RequestDebugger {
    requestTrace: {
        requestId: string;
        timestamp: Date;
        userAgent: string;
        ipAddress: string;
        tenantId: number;
        userId: string;
    };

    requestFlow: {
        stages: DebugStage[];
        totalDuration: number;
        bottlenecks: BottleneckAnalysis[];
    };

    aiAnalysisDetails: {
        promptUsed: string;
        modelConfiguration: ModelConfig;
        tokenBreakdown: TokenBreakdown;
        rawResponse: any;
        normalizedResponse: any;
    };
}

interface DebugStage {
    name: string;
    startTime: number;
    endTime: number;
    duration: number;
    status: 'success' | 'error' | 'warning';
    details: any;
    subStages?: DebugStage[];
}

const RequestDebuggerPanel: React.FC<{requestId: string}> = ({ requestId }) => {
    const [debugData, setDebugData] = useState<RequestDebugger | null>(null);
    const [selectedStage, setSelectedStage] = useState<string | null>(null);

    useEffect(() => {
        const fetchDebugData = async () => {
            try {
                const response = await fetch(`/api/admin/debug/requests/${requestId}`);
                const data = await response.json();
                setDebugData(data);
            } catch (error) {
                console.error('Failed to fetch debug data:', error);
            }
        };

        fetchDebugData();
    }, [requestId]);

    return (
        <DebuggerContainer>
            {/* Request Overview */}
            <RequestOverview>
                <OverviewHeader>
                    <RequestId>{debugData?.requestTrace.requestId}</RequestId>
                    <Timestamp>{debugData?.requestTrace.timestamp.toISOString()}</Timestamp>
                    <TotalDuration>{debugData?.requestFlow.totalDuration}ms</TotalDuration>
                </OverviewHeader>

                <RequestMetadata>
                    <MetadataItem label="Tenant" value={debugData?.requestTrace.tenantId} />
                    <MetadataItem label="User" value={debugData?.requestTrace.userId} />
                    <MetadataItem label="IP" value={debugData?.requestTrace.ipAddress} />
                    <MetadataItem label="User Agent" value={debugData?.requestTrace.userAgent} />
                </RequestMetadata>
            </RequestOverview>

            {/* Request Flow Timeline */}
            <FlowTimeline>
                <TimelineHeader>Request Processing Timeline</TimelineHeader>
                <TimelineVisualization>
                    {debugData?.requestFlow.stages.map((stage, index) => (
                        <TimelineStage
                            key={index}
                            stage={stage}
                            isSelected={selectedStage === stage.name}
                            onClick={() => setSelectedStage(stage.name)}
                        />
                    ))}
                </TimelineVisualization>

                {/* Bottleneck Analysis */}
                <BottleneckAnalysis>
                    <AnalysisTitle>Performance Bottlenecks</AnalysisTitle>
                    {debugData?.requestFlow.bottlenecks.map((bottleneck, index) => (
                        <BottleneckItem key={index}>
                            <BottleneckStage>{bottleneck.stage}</BottleneckStage>
                            <BottleneckImpact>{bottleneck.impact}</BottleneckImpact>
                            <BottleneckRecommendation>{bottleneck.recommendation}</BottleneckRecommendation>
                        </BottleneckItem>
                    ))}
                </BottleneckAnalysis>
            </FlowTimeline>

            {/* Stage Details */}
            {selectedStage && (
                <StageDetailsPanel>
                    <StageDetails
                        stage={debugData?.requestFlow.stages.find(s => s.name === selectedStage)}
                    />
                </StageDetailsPanel>
            )}

            {/* AI Analysis Details */}
            <AIAnalysisDetails>
                <DetailsHeader>AI Analysis Breakdown</DetailsHeader>

                <PromptSection>
                    <SectionTitle>Prompt Used</SectionTitle>
                    <PromptDisplay>
                        <SyntaxHighlighter language="text">
                            {debugData?.aiAnalysisDetails.promptUsed}
                        </SyntaxHighlighter>
                    </PromptDisplay>
                </PromptSection>

                <TokenBreakdownSection>
                    <SectionTitle>Token Analysis</SectionTitle>
                    <TokenBreakdownTable>
                        <TokenRow label="Input Tokens" value={debugData?.aiAnalysisDetails.tokenBreakdown.input} />
                        <TokenRow label="Output Tokens" value={debugData?.aiAnalysisDetails.tokenBreakdown.output} />
                        <TokenRow label="Total Tokens" value={debugData?.aiAnalysisDetails.tokenBreakdown.total} />
                        <TokenRow label="Cost" value={`$${debugData?.aiAnalysisDetails.tokenBreakdown.cost?.toFixed(4)}`} />
                    </TokenBreakdownTable>
                </TokenBreakdownSection>

                <ResponseComparisonSection>
                    <SectionTitle>Response Comparison</SectionTitle>
                    <ResponseTabs>
                        <TabButton>Raw Response</TabButton>
                        <TabButton>Normalized Response</TabButton>
                        <TabButton>Diff</TabButton>
                    </ResponseTabs>
                    <ResponseDisplay>
                        <SyntaxHighlighter language="json">
                            {JSON.stringify(debugData?.aiAnalysisDetails.rawResponse, null, 2)}
                        </SyntaxHighlighter>
                    </ResponseDisplay>
                </ResponseComparisonSection>
            </AIAnalysisDetails>
        </DebuggerContainer>
    );
};
```

### Error Analysis Tools

#### Error Pattern Detection
```typescript
interface ErrorAnalysisData {
    errorSummary: {
        totalErrors: number;
        errorRate: number;
        mostCommonErrors: ErrorTypeCount[];
        errorTrends: ErrorTrendData[];
    };

    errorCategories: {
        aiServiceErrors: AIServiceError[];
        validationErrors: ValidationError[];
        systemErrors: SystemError[];
        userErrors: UserError[];
    };

    impactAnalysis: {
        affectedUsers: number;
        affectedTenants: number;
        costImpact: number;
        performanceImpact: PerformanceImpact;
    };
}

const ErrorAnalysisPanel: React.FC = () => {
    const [errorData, setErrorData] = useState<ErrorAnalysisData | null>(null);
    const [timeRange, setTimeRange] = useState<string>('24h');
    const [filterBy, setFilterBy] = useState<string>('all');

    return (
        <ErrorAnalysisContainer>
            {/* Error Summary Cards */}
            <ErrorSummaryCards>
                <ErrorCard
                    title="Total Errors"
                    value={errorData?.errorSummary.totalErrors}
                    trend="down"
                    severity="medium"
                />
                <ErrorCard
                    title="Error Rate"
                    value={`${errorData?.errorSummary.errorRate.toFixed(2)}%`}
                    trend="stable"
                    severity={errorData?.errorSummary.errorRate > 5 ? "high" : "low"}
                />
                <ErrorCard
                    title="Affected Users"
                    value={errorData?.impactAnalysis.affectedUsers}
                    trend="down"
                    severity="medium"
                />
                <ErrorCard
                    title="Cost Impact"
                    value={`$${errorData?.impactAnalysis.costImpact.toFixed(2)}`}
                    trend="stable"
                    severity="low"
                />
            </ErrorSummaryCards>

            {/* Error Trends Chart */}
            <ErrorTrendsChart>
                <ChartTitle>Error Trends Over Time</ChartTitle>
                <TimeSeriesChart
                    data={errorData?.errorSummary.errorTrends}
                    xAxis="timestamp"
                    yAxis="errorCount"
                    colorBy="errorType"
                />
            </ErrorTrendsChart>

            {/* Common Errors Table */}
            <CommonErrorsTable>
                <TableTitle>Most Common Errors</TableTitle>
                <ErrorTable>
                    <TableHeader>
                        <th>Error Type</th>
                        <th>Count</th>
                        <th>Percentage</th>
                        <th>Last Seen</th>
                        <th>Resolution Status</th>
                        <th>Actions</th>
                    </TableHeader>
                    {errorData?.errorSummary.mostCommonErrors.map(error => (
                        <ErrorRow
                            key={error.type}
                            error={error}
                            onViewDetails={() => viewErrorDetails(error.type)}
                            onCreateIssue={() => createIssueForError(error.type)}
                        />
                    ))}
                </ErrorTable>
            </CommonErrorsTable>

            {/* Error Categories */}
            <ErrorCategoriesGrid>
                <CategoryPanel title="AI Service Errors" errors={errorData?.errorCategories.aiServiceErrors} />
                <CategoryPanel title="Validation Errors" errors={errorData?.errorCategories.validationErrors} />
                <CategoryPanel title="System Errors" errors={errorData?.errorCategories.systemErrors} />
                <CategoryPanel title="User Errors" errors={errorData?.errorCategories.userErrors} />
            </ErrorCategoriesGrid>
        </ErrorAnalysisContainer>
    );
};
```

---

## 📚 Related Documentation

### AI System Architecture
- **[AI Analysis API](../backend/ai-analysis-api.md)** - Core API endpoints and integration patterns
- **[AI Performance Monitoring](../backend/ai-performance.md)** - Performance optimization and monitoring
- **[AI Prompt Management](../backend/ai-prompt-management.md)** - Prompt template management and versioning

### Admin Dashboard Development
- **[Admin Architecture](../architecture/README.md)** - Admin dashboard architecture overview
- **[Admin Architecture](../admin/architecture/README.md)** - Admin dashboard architecture overview
- **[Admin Development](../admin/architecture/README.md)** - Admin dashboard development patterns

### Testing & Quality Assurance
- **[Testing Guide](../workflows/testing-guide.md)** - Comprehensive testing approaches

### Operational Procedures
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment procedures
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General troubleshooting guidance
- **[System Monitoring](../workflows/troubleshooting-guide.md)** - System monitoring and operational procedures

---

**Status**: ✅ Production Ready - Comprehensive AI testing tools documentation with admin dashboard interfaces, validation procedures, cost analysis displays, and troubleshooting guides
