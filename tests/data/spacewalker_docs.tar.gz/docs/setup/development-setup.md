# Spacewalker Development Setup

## Purpose
Comprehensive development environment setup and daily workflow documentation for Spacewalker monorepo. Essential reference for setting up local development environment and understanding the development workflow.

## When to Use This
- Initial project setup and environment configuration
- Understanding development workflows and daily commands
- Troubleshooting development environment issues
- Setting up new developer workstations
- Configuring CI/CD and automated development workflows
- Keywords: development setup, environment configuration, monorepo, daily workflow, prerequisites

**Version:** 2.0 (Extracted from comprehensive PRD)
**Date:** 2025-06-29
**Status:** Current - Development Environment Reference

---

## 🏗️ Project Structure

The monorepo contains the backend, mobile, and admin applications, along with shared packages.

```
.
├── apps/
│   ├── admin/      # Next.js admin dashboard
│   ├── backend/    # FastAPI backend API
│   └── mobile/     # React Native (Expo) mobile app
├── docs/           # Project documentation
├── packages/
│   └── shared-types/ # Shared TypeScript types
├── docker/
├── justfile
└── package.json
```

### Monorepo Architecture
- **Shared Dependencies:** Common packages managed at root level
- **App-Specific Dependencies:** Application-specific packages in individual app directories
- **Shared Types:** TypeScript type definitions shared across applications
- **Development Tools:** Unified tooling for linting, testing, and building

---

## 📋 Prerequisites

| Tool              | Required Version | Installation                               |
| ----------------- | ---------------- | ------------------------------------------ |
| **`just`**        | `1.0.0+`         | [Official Install Guide](https://github.com/casey/just#installation) |
| **Node.js**       | `20.19.4`        | Use `nvm use` (see `.nvmrc`)               |
| **Python**        | `3.11+`          | [python.org](https://www.python.org/downloads/) |
| **PostgreSQL**    | `14+`            | [Postgres.app](https://postgresapp.com/) or `brew install postgresql` |
| **Docker**        | `20.10+`         | [Docker Desktop](https://www.docker.com/products/docker-desktop) |

### Platform-Specific Setup
#### macOS
```bash
# Install Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install prerequisites
brew install just node python@3.11 postgresql docker
```

#### Windows
```bash
# Install chocolatey
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# Install prerequisites
choco install just nodejs python postgresql docker-desktop
```

#### Linux (Ubuntu/Debian)
```bash
# Update package manager
sudo apt update

# Install prerequisites
sudo apt install nodejs npm python3.11 postgresql docker.io
curl --proto '=https' --tlsv1.2 -sSf https://just.systems/install.sh | bash
```

---

## ⚙️ First-Time Setup

### 1. Environment Configuration
Copy the example `.env` file and customize it for your local development environment:

```bash
cp .env.example .env
```

#### Required Environment Variables
```bash
# Database Configuration
DATABASE_URL=postgresql://user:password@localhost:5432/spacewalker_dev

# JWT Authentication
JWT_SECRET=your-super-secret-jwt-key-here

# Google Gemini AI (Optional for development)
GEMINI_API_KEY=your-gemini-api-key

# File Storage (Development uses local MinIO)
S3_BUCKET_NAME=spacewalker-dev
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin
S3_ENDPOINT=http://localhost:9000

# Development URLs
API_BASE_URL=http://localhost:8000
ADMIN_BASE_URL=http://localhost:3000
MOBILE_BASE_URL=http://localhost:8081
```

### 2. Install Dependencies
Install all `npm` and `pip` dependencies across the monorepo:

```bash
just service install all
```

This command:
- Installs root-level dependencies with `pnpm`
- Installs backend Python dependencies with `uv`
- Installs app-specific dependencies for admin and mobile
- Sets up development tools

### 2a. Install Pre-commit Hooks (Important!)
Install git pre-commit hooks to catch linting issues before commits:

```bash
pre-commit install
```

This ensures:
- Code is automatically linted before each commit
- Prevents committing code with linting errors
- Maintains consistent code quality across the team
- Avoids CI failures due to linting issues

### 3. Database Setup
Start the database container, run migrations, and seed development data:

```bash
just db_reset
```

This command:
- Starts PostgreSQL container with PostGIS extension
- Runs Alembic migrations to create database schema
- Seeds development data including demo users and buildings
- Creates necessary database indexes and constraints

---

## 🚀 Daily Development Workflow

### Start All Services
Start the complete development environment with all services:

```bash
just up
```

**Services Started:**
- **Backend API:** `http://localhost:8000`
- **Admin Dashboard:** `http://localhost:3000`
- **Mobile App (Expo):** `http://localhost:8081`
- **PostgreSQL Database:** `localhost:5432`
- **MinIO File Storage:** `http://localhost:9000`

### Development Cycle
Run tests and linters for all applications to ensure code quality:

```bash
# Quick development cycle (recommended for daily use)
just dev_cycle

# Complete test suite including integration tests
just test_with_infra
```

#### Development Cycle Commands
```bash
# Individual application testing
just test unit all                # Fast unit tests across all apps
just test integration all         # Integration tests with infrastructure
just lint                     # Auto-fix linting issues
just lint check all               # Read-only linting validation

# Application-specific commands
just backend_test             # Backend-only testing
just admin_test               # Admin dashboard testing
just mobile_test              # Mobile app testing
```

---

## 🗄️ Database Development

### Database Migrations
After changing a SQLAlchemy model in `apps/backend/src/spacewalker/models/`:

```bash
# 1. Generate a new migration script
just backend_alembic_revision "Your descriptive message"

# 2. Apply the migration to the local database
just backend_alembic_upgrade
```

### Database Management
```bash
# Database operations
just db shell               # Direct database access with psql
just db_backup                # Create timestamped database backup
just db_restore backup.sql    # Restore from backup file
just db verify              # Check database consistency

# Development data management
just db_seed_safe             # Add demo data (preserves existing)
just db_seed_users            # Add only demo users
just db_clean_demo            # Remove demo data only
```

---

## 📱 Mobile Development

### Mobile Setup
Configure mobile development environment for React Native and Expo:

```bash
# Automatic IP configuration for mobile development
just expo ip auto

# Start mobile development server
just up local
```

### Mobile Development Workflow
```bash
# Mobile-specific commands
just expo start --offline     # Start Expo development server
just mobile_ios               # Start iOS simulator
just mobile_android           # Start Android emulator
just mobile_web               # Start web version of mobile app

# Mobile testing
just mobile_test              # Run mobile unit tests
just mobile_lint              # Mobile-specific linting
```

---

## 🔧 Development Tools

### Code Quality
```bash
# Linting and formatting
just lint                     # Auto-fix all linting issues
just lint check all               # Read-only linting validation
just lint check all --ci    # CI-style linting (warnings as errors)

# Application-specific linting
just lint check backend     # Backend Python linting
just lint check admin       # Admin TypeScript linting
just lint check mobile      # Mobile TypeScript linting
```

### Testing Strategy
```bash
# Testing workflows
just test unit all                # Fast unit tests (< 30 seconds)
just test integration all         # Integration tests with services
just test all all                 # Complete test suite
just test_with_infra          # Tests with infrastructure setup

# Continuous integration simulation
just test unit all          # Run all unit tests
just test integration all   # Run all integration tests
```

---

## 🐳 Docker Development

### Container Management
```bash
# Docker operations
just up                       # Start all development containers
just down                     # Stop all containers
just service restart [service] # Restart specific service
just logs [service]           # View service logs

# Docker maintenance
just docker_clean             # Clean Docker state
just docker_rebuild           # Rebuild all containers
just docker_status            # Container resource usage
```

### Service-Specific Operations
```bash
# Individual service management
just backend                  # Start only backend service
just admin                    # Start only admin service
just expo start --offline     # Start only mobile dev server
just db                       # Start only database service
```

---

## 🚦 Development Environment Validation

### Health Checks
```bash
# Environment validation
just health                   # Overall system health check
just env_check                # Environment configuration validation
just env_status               # Current environment status

# Service-specific health
just backend_health           # Backend API health
just db_health                # Database connectivity
just docker_health            # Container health status
```

### Troubleshooting Commands
```bash
# Diagnostic commands
just info                     # Complete environment information
just status                   # All services status overview
just debug [service]          # Debug specific service

# Recovery commands
just fresh_dev                # Fresh development environment
just reset_env                # Reset environment to clean state
```

---

## 🔗 Integration Development

### External Services
```bash
# API integration testing
just test unit backend --ai-real  # Test real Gemini API integration
just test_storage             # Test file storage integration

# External service configuration
just config_gemini            # Configure Gemini API integration
just config_storage           # Configure S3/MinIO storage
```

---

## 📚 Development Resources

### Daily Commands Reference
```bash
# Essential daily commands
just up                       # Start development environment
just dev_cycle                # Run tests and linting
just health                   # Check system status
just down                     # Stop development environment

# Database workflow
just db shell               # Database access
just db_backup                # Backup database
just backend_alembic_revision # Create migration
just backend_alembic_upgrade  # Apply migration

# Mobile workflow
just expo ip auto             # Configure mobile IP
just expo start --offline     # Start mobile development
```

### Configuration Files
- **`.env`** - Environment variables for development
- **`.nvmrc`** - Node.js version specification
- **`justfile`** - Development command definitions
- **`package.json`** - Root package configuration
- **`docker-compose.yml`** - Development container configuration

---

## Related Documentation

### Setup Guides
- **[Getting Started Guide](../setup/getting-started.md)** - Step-by-step onboarding for new developers
- **[Environment Configuration](../setup/environment-setup.md)** - Detailed environment variable reference
- **[Project Structure](../development/project-structure.md)** - Monorepo organization and dependencies

### Architecture References
- **[Backend Architecture](../backend/architecture/README.md)** - Backend development architecture
- **[Mobile Architecture](../mobile/architecture/README.md)** - Mobile development architecture
- **[Admin Architecture](../admin/architecture/README.md)** - Admin dashboard architecture

### Troubleshooting
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Development environment problem resolution
- **[Common Gotchas](../gotchas/)** - Development-specific issues and solutions

---

**Status**: ✅ Updated and current as of 2025-06-29. Extracted from comprehensive PRD and enhanced with detailed development workflows and command references.
