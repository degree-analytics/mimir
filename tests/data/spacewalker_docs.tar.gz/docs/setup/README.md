# Environment Setup Documentation

Initial setup, environment configuration, and getting started guides for Spacewalker development.

## Purpose
Comprehensive environment setup and configuration documentation for all development scenarios. Essential reference for onboarding new developers, configuring development environments, and understanding project structure.

## When to Use This
- Initial project setup and environment configuration
- Onboarding new team members and developers
- Troubleshooting development environment issues
- Understanding development workflows and prerequisites

**Keywords:** development setup, environment configuration, onboarding, getting started

---

## Contents

### Quick Start & Getting Started
- **[Developer Prerequisites](./developer-prerequisites.md)** - Complete list of ALL required tools and configurations ⭐ NEW
- **[Quick Start](../setup/quick-start.md)** - 5-minute automated setup for immediate productivity ⭐
- **[Getting Started](../setup/getting-started.md)** - Comprehensive step-by-step onboarding guide ⭐
- **[Development Setup](../setup/development-setup.md)** - Complete development environment configuration and daily workflow ⭐

### Environment Configuration
- **[Environment Setup](../setup/environment-setup.md)** - Basic environment configuration and prerequisites
- **[Environment Configuration](./environment-configuration.md)** - Advanced environment settings and customization
- **[Shared Environment Variables](./shared-environment-variables.md)** - Variable naming standards

### Specialized Setup
- **[AI Development Setup](./ai-development-setup.md)** - Claude Code, MCP servers, and AI development tools
- **[Production Infrastructure](./production-infrastructure.md)** - Production deployment setup

---

## Setup Paths by Role

### 🆕 New Developer (First Time)
1. **[Getting Started](../setup/getting-started.md)** - Complete onboarding (30 minutes)
2. **[Development Setup](../setup/development-setup.md)** - Daily workflow understanding
3. **[Environment Configuration](./environment-configuration.md)** - Advanced customization

### ⚡ Experienced Developer (Quick Setup)
1. **[Quick Start](../setup/quick-start.md)** - Automated setup (5 minutes)
2. **[Development Setup](../setup/development-setup.md)** - Development workflow reference

### 🤖 AI/ML Developer
1. **[Development Setup](../setup/development-setup.md)** - Core environment
2. **[AI Development Setup](./ai-development-setup.md)** - AI tooling and Claude Code integration

### 🏗️ DevOps Engineer
1. **[Environment Configuration](./environment-configuration.md)** - Infrastructure configuration
2. **[Getting Started](../setup/getting-started.md)** - Complete system understanding

---

## Setup Overview

### Prerequisites
| Tool | Version | Purpose | Required |
|------|---------|---------|----------|
| **just** | `1.0.0+` | Command runner | ✅ |
| **Docker** | `20.10+` | Containerization | ✅ |
| **Git** | `2.0+` | Version control | ✅ |
| **Python** | `3.11+` | Backend API development | ✅ |
| **Node.js** | `18.0+` | Frontend and mobile development | ✅ |
| **PostgreSQL** | `14+` | Database client tools | ✅ |
| **AWS CLI** | `2.0+` | Cloud operations | ✅ |
| **uv** | Latest | Python package manager | Recommended |
| **jq** | Latest | JSON processor | Recommended |

For the complete list of prerequisites and installation instructions, see **[Developer Prerequisites](./developer-prerequisites.md)**.

### Development Environment
```bash
# Verify prerequisites first!
just env_status  # Check all requirements

# Quick automated setup
just up          # Start all services
just dev_cycle   # Run tests and linting
just health      # Verify environment
just docs_validate # Validate documentation (when editing docs)
```

### Key Services
- **Backend API:** `http://localhost:8000` (FastAPI)
- **Admin Dashboard:** `http://localhost:3000` (Next.js)
- **Mobile App:** `http://localhost:8081` (Expo)
- **Database:** `localhost:5432` (PostgreSQL)

---

## Common Setup Scenarios

### ✅ Fresh Machine Setup
```bash
# 1. Install prerequisites (OS-specific)
# 2. Clone repository
# 3. Follow Quick Start guide
# 4. Verify with health checks
```

### 🔄 Existing Environment Updates
```bash
# 1. Pull latest changes
# 2. Run dependency updates
# 3. Database migration (if needed)
# 4. Restart services
```

### 🐛 Environment Troubleshooting
```bash
# 1. Check health status
# 2. Review environment variables
# 3. Restart problematic services
# 4. Consult troubleshooting guide
```

---

## Related Documentation

### Development Workflows
- **[Development Workflows](../workflows/)** - Daily operational procedures and git workflows
- **[Development Tools](../development/)** - IDE setup, debugging, and development tooling

### Architecture Context
- **[System Architecture](../architecture/)** - Understanding what you're setting up
- **[Project Structure](../development/project-structure.md)** - Monorepo organization

### Component Setup
- **[Backend Development](../backend/development/)** - Backend-specific development setup
- **[Mobile Development](../mobile/development/)** - React Native development environment
- **[Admin Development](../admin/development/)** - Dashboard development setup

### Troubleshooting
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Environment issue resolution
- **[Common Gotchas](../gotchas/)** - Setup-specific issues and solutions

---

**Last Updated:** 2025-06-29
**Status:** Current - Reorganized from workflows directory with role-based navigation
