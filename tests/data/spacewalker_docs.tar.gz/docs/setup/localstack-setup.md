# LocalStack Setup Documentation

## Purpose
Comprehensive guide for setting up and configuring LocalStack in the Spacewalker development environment, including Docker configuration, service initialization, and troubleshooting.

## When to Use This
- Setting up local development environment with AWS service emulation
- Troubleshooting LocalStack connectivity issues
- Understanding S3, SES, and Secrets Manager configuration
- Configuring LocalStack for integration testing

**Keywords:** LocalStack, AWS emulation, S3, SES, Docker, local development

---

## Overview

LocalStack is a fully functional local AWS cloud stack that enables Spacewalker to develop and test AWS services offline. Our setup emulates S3 (file storage), SES (email service), and Secrets Manager (credential management) services.

**🏗️ Current Status**: Production-ready LocalStack setup for all development environments
**📅 Last Updated**: 2025-08-04
**🔧 Version**: LocalStack 3.8.1

---

## Prerequisites

### Required Software
- **Docker**: Functional Docker environment (verify with `docker info`)
- **Docker Compose**: For orchestrated service management
- **Python 3.8+**: For AWS CLI tools and LocalStack CLI
- **AWS CLI**: For `awslocal` command wrapper

### System Requirements
- **RAM**: Minimum 4GB available for Docker
- **Storage**: 2GB free space for LocalStack volumes
- **Network**: Port 4566 available (LocalStack Gateway)
- **Platform**: Optimized for Apple Silicon Macs (M1/M2/M3)

---

## Installation Methods

### Method 1: Integrated Setup (Recommended)

LocalStack is pre-configured in Spacewalker's Docker Compose setup:

```bash
# Start all services including LocalStack
just up

# Verify LocalStack health
just localstack health
```

### Method 2: Standalone LocalStack CLI

```bash
# Install LocalStack CLI
pip install localstack

# Or via Homebrew (macOS)
brew install localstack/tap/localstack-cli

# Start LocalStack standalone
localstack start -d
```

---

## Configuration

### Docker Compose Configuration

LocalStack is configured in `docker-compose.yml`:

```yaml
localstack:
  image: localstack/localstack:3.8.1
  networks:
    - spacewalker_dev_network
  environment:
    # Enabled services
    SERVICES: s3,ses,secretsmanager
    # Enable data persistence
    PERSISTENCE: 1
    # Development debug mode
    DEBUG: ${DEBUG:-0}
    # LocalStack hostname
    LOCALSTACK_HOST: localstack
    # Disable analytics
    DISABLE_EVENTS: 1
    # AWS credentials (dummy values for local dev)
    AWS_ACCESS_KEY_ID: test
    AWS_SECRET_ACCESS_KEY: test
    AWS_DEFAULT_REGION: us-east-1
  ports:
    - "4566:4566"            # LocalStack Gateway
    - "4510-4559:4510-4559"  # External services port range
  volumes:
    # Persistence volume
    - ./.build/localstack:/var/lib/localstack
    # Docker socket for container services
    - "/var/run/docker.sock:/var/run/docker.sock"
    # Initialization scripts
    - ./scripts/localstack:/etc/localstack/init:ro
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:4566/_localstack/health"]
    interval: 10s
    timeout: 5s
    retries: 5
    start_period: 30s
```

### Environment Variables

Configure in `.env` file:

```bash
# LocalStack Configuration
LOCALSTACK_HOSTNAME=localstack
LOCALSTACK_SERVICES=s3,ses,secretsmanager
LOCALSTACK_ENDPOINT_URL=http://localhost:4566

# AWS Configuration for LocalStack
AWS_ACCESS_KEY_ID=test
AWS_SECRET_ACCESS_KEY=test
AWS_DEFAULT_REGION=us-east-1

# S3 Configuration
S3_BUCKET_NAME=local-spacewalker-photos
S3_REGION=us-east-1
S3_ENDPOINT_URL=http://localstack:4566

# Email Configuration
EMAIL_FROM_ADDRESS=spacewalker@campusiq.com
EMAIL_FROM_NAME=SpaceWalker
```

---

## Service Configuration

### S3 Service Setup

LocalStack automatically creates required S3 buckets via initialization script:

**Auto-configured buckets:**
- `local-spacewalker-photos` - Primary file storage bucket

**CORS Configuration:**
```json
{
    "CORSRules": [
        {
            "AllowedHeaders": ["*"],
            "AllowedMethods": ["GET", "PUT", "POST", "DELETE", "HEAD"],
            "AllowedOrigins": ["http://localhost:3000", "http://localhost:8081"],
            "ExposeHeaders": ["ETag"],
            "MaxAgeSeconds": 3000
        }
    ]
}
```

### SES Service Setup

Pre-verified email addresses for testing:
- `dev@spacecargo.ai`
- `admin@demo.university.edu`
- `user@demo.university.edu`
- `spacewalker@campusiq.com`

**Verified domains:**
- `spacecargo.ai`
- `demo.university.edu`
- `spacewalker.com`
- `campusiq.com`

### Secrets Manager Setup

Automatically configured via `scripts/localstack/ready.d/03-secrets-manager.sh` for secure credential management.

---

## Usage

### Health Checks

```bash
# Check LocalStack service health
just localstack health

# Manual health check
curl -f http://localhost:4566/_localstack/health

# Check specific service status
awslocal s3 ls                    # S3 service
awslocal ses list-verified-email-addresses  # SES service
```

### Working with S3

```bash
# List buckets
awslocal s3 ls

# Create additional bucket
awslocal s3api create-bucket --bucket my-test-bucket

# Upload file
awslocal s3 cp ./file.txt s3://local-spacewalker-photos/

# List bucket contents
awslocal s3 ls s3://local-spacewalker-photos/
```

### Working with SES

```bash
# List verified email addresses
awslocal ses list-verified-email-addresses

# Send test email
awslocal ses send-email \
  --from dev@spacecargo.ai \
  --to admin@demo.university.edu \
  --message '{
    "Subject": {"Data": "Test Email"},
    "Body": {"Text": {"Data": "This is a test email from LocalStack"}}
  }'

# Check sending quota
awslocal ses get-send-quota
```

### Email Testing Utilities

**Get Last Email and Invitation Link:**
Spacewalker includes a utility script for testing invitation functionality:

```bash
# Retrieve most recent invitation email and construct link
./scripts/localstack/get-last-email.sh
```

**What this script does:**
- ✅ Checks LocalStack and backend service health
- 📧 Shows recent email send history from LocalStack logs
- 🔍 Queries database for most recent invitation token
- 🔗 Constructs ready-to-test invitation link for localhost:3000
- 💡 Provides debug information and testing instructions

**Usage workflow:**
1. Send invitation through admin interface
2. Run `./scripts/localstack/get-last-email.sh`
3. Copy the generated invitation link
4. Test invitation acceptance flow in browser

**Sample output:**
```
🔗 INVITATION LINK (Ready to test!):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  http://localhost:3000/invite/accept?token=abc123...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Integration with Spacewalker

### Backend Integration

The backend automatically connects to LocalStack services:

**S3 Integration:**
```python
# Backend automatically uses LocalStack S3
# Configuration via environment variables:
# S3_ENDPOINT_URL=http://localstack:4566
```

**SES Integration:**
```python
# Email service automatically uses LocalStack SES
# Configuration via environment variables:
# AWS_SES_REGION_DEV=us-east-1
```

### Testing Integration

LocalStack health utilities are available for integration tests:

```python
from apps.backend.tests.utils.localstack_health import LocalStackHealthChecker

# Check service readiness
health_checker = LocalStackHealthChecker()
assert health_checker.check_service_availability("s3")
assert health_checker.check_service_availability("ses")
```

---

## Troubleshooting

### Common Issues

**1. LocalStack container won't start**
```bash
# Check Docker daemon status
docker info

# Check port availability
lsof -i :4566

# Restart with clean state
just down && just up
```

**2. Services not responding**
```bash
# Check service health
just localstack health

# Restart LocalStack service only
docker-compose restart localstack

# Check logs for errors
docker-compose logs localstack
```

**3. Permission errors with Docker socket**
```bash
# Ensure Docker socket permissions (macOS)
sudo chmod 666 /var/run/docker.sock

# Or add user to docker group (Linux)
sudo usermod -aG docker $USER
```

**4. S3 bucket access denied**
```bash
# Verify bucket exists
awslocal s3 ls

# Check CORS configuration
awslocal s3api get-bucket-cors --bucket local-spacewalker-photos

# Recreate bucket if needed
just down && just up  # Triggers initialization scripts
```

**5. SES email sending fails**
```bash
# Verify email addresses
awslocal ses list-verified-email-addresses

# Check SES service status
awslocal ses get-send-quota

# Re-verify email if needed
awslocal ses verify-email-identity --email-address test@example.com
```

### Debug Mode

Enable debug logging for detailed troubleshooting:

```bash
# Set debug mode in .env
DEBUG=1

# Restart services
just down && just up

# Check debug logs
docker-compose logs localstack | grep DEBUG
```

### Health Check Utilities

Use the built-in health checker for systematic diagnosis:

```python
from apps.backend.tests.utils.localstack_health import create_localstack_health_checker

# Get comprehensive health summary
health_checker = create_localstack_health_checker()
summary = health_checker.get_health_summary()
print(summary)

# Wait for specific services
services_ready, status = health_checker.wait_for_services(["s3", "ses"], timeout=60)
```

---

## Performance Considerations

### Startup Time
- **Cold start**: 30-45 seconds for all services
- **Warm start**: 10-15 seconds with persistence enabled
- **Health check**: 5-10 seconds for readiness verification

### Resource Usage
- **RAM**: ~500MB for standard services
- **CPU**: Low during idle, moderate during initialization
- **Storage**: ~100MB for persistence data

### Optimization Tips

1. **Enable Persistence**: Reduces re-initialization time
   ```yaml
   environment:
     PERSISTENCE: 1
   ```

2. **Limit Services**: Only enable required services
   ```yaml
   environment:
     SERVICES: s3,ses  # Remove unused services
   ```

3. **Use Health Checks**: Wait for readiness before tests
   ```bash
   just localstack health
   ```

---

## Development Workflow

### Daily Development Cycle

```bash
# 1. Start development environment
just up

# 2. Verify LocalStack health
just localstack health

# 3. Run tests requiring AWS services
just test integration backend

# 4. Develop with live reload
# LocalStack persists data across container restarts

# 5. Clean shutdown
just down
```

### Testing Workflow

```bash
# 1. Ensure clean LocalStack state
just down && just up

# 2. Wait for services to be ready
just localstack health

# 3. Run integration tests
just test integration backend

# 4. Check test results and LocalStack logs if needed
docker-compose logs localstack
```

---

## Advanced Configuration

### Custom Initialization Scripts

Add custom setup scripts to `scripts/localstack/ready.d/`:

```bash
# Example: 04-custom-setup.sh
#!/bin/bash
echo "Running custom LocalStack setup..."

# Create additional S3 buckets
awslocal s3api create-bucket --bucket custom-bucket

# Add SES configuration
awslocal ses verify-email-identity --email-address custom@example.com
```

### Network Configuration

For advanced networking needs:

```yaml
# Custom network configuration
networks:
  spacewalker_dev_network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

### Volume Management

Manage LocalStack persistence data:

```bash
# View persistence data
ls -la .build/localstack/

# Clear persistence data (fresh start)
rm -rf .build/localstack/*
just up
```

---

## Security Considerations

### Development Environment
- Uses dummy AWS credentials (`test`/`test`)
- No real AWS charges incurred
- Data stored locally in Docker volumes
- Network isolated to development containers

### Production Considerations
- **Never use LocalStack in production**
- LocalStack is for development and testing only
- Use real AWS services for production deployments
- Ensure proper credential management for production

---

## Related Documentation

- **[Environment Setup](./environment-setup.md)** - Overall development environment
- **[Development Setup](./development-setup.md)** - Complete development configuration
- **[Docker Configuration](../development/docker.md)** - Docker and containerization
- **[Testing Guide](../workflows/testing-guide.md)** - Integration testing with LocalStack
- **[Backend Testing Patterns](../backend/testing/)** - Backend-specific testing

---

## Support

### Quick Reference
- **Health Check**: `just localstack health`
- **Service Restart**: `docker-compose restart localstack`
- **Debug Logs**: `docker-compose logs localstack`
- **Clean Restart**: `just down && just up`

### Common Commands
```bash
# Start LocalStack
just up

# Check health
just localstack health

# View logs
docker-compose logs localstack

# Restart service
docker-compose restart localstack

# Clean restart
just down && just up
```

---

**Last Updated:** 2025-08-04
**Status:** Current
**Version:** LocalStack 3.8.1
