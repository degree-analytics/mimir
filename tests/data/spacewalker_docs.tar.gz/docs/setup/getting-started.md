# Getting Started with Spacewalker

## Purpose
Comprehensive onboarding guide to get new developers from zero to running the complete Spacewalker development environment in about 10 minutes.

## When to Use This
- First-time setup of Spacewalker development environment
- Onboarding new team members to the project
- Setting up development environment after system changes
- Verifying complete system functionality after updates
- Keywords: getting started, onboarding, setup, development environment, first run

**Version:** 2.0 (Updated for new documentation structure)
**Date:** 2025-06-29
**Status:** Current - Primary Onboarding Guide

---

## Prerequisites

### Fresh Machine Setup

If this is your first time setting up Spacewalker:

```bash
# Run bootstrap script to install prerequisites
./scripts/bootstrap.sh
```

This will check for required tools and install Python dependencies needed by helper scripts.

### Verify Prerequisites

Check that you have everything needed:

```bash
just env_check
```

This command validates all dependencies and tells you exactly what to install if anything is missing.

**Required Dependencies:**
- Node.js `v20.19.4` (see `.nvmrc`)
- Python `3.11+`
- PostgreSQL `14+`
- Redis
- `just` command runner
- Docker and Docker Compose

---

## Quick Setup

Choose your preferred setup approach:

### Option A: One-Command Setup (Recommended)
```bash
just workflow_setup
```

This automatically handles dependency installation, Docker setup, service startup, and validation testing.

### Option B: Step-by-Step Setup
If you prefer manual control:

```bash
# Install dependencies
just service install all

# Start all services
just up

# Verify everything works
just health
```

---

## Verify Installation

After setup completes, you should see:

1. **All services running**: `just health` shows green status for all services
2. **Backend API responding**: Visit `http://localhost:8000/api/health`
3. **Admin dashboard accessible**: Visit `http://localhost:3000`
4. **Mobile development ready**: `just expo ip auto` configures your network IP

### Verification Commands
```bash
# Quick health check
just health

# Detailed service status
just status

# Environment validation
just env_status
```

---

## Access Your Applications

### Admin Dashboard
- **URL**: http://localhost:3000
- **Demo credentials**: Run `just db_seed_safe` first, then use:
  - Admin: `admin@demo.university.edu` / `demo123`
  - Manager: `manager@demo.university.edu` / `demo123`

**Related Documentation:** [Admin Architecture Guide](../admin/architecture/README.md)

### Mobile App (React Native)
```bash
# Configure network connection
just expo ip auto

# Start mobile development
cd apps/mobile && npx expo start
```

Use the Expo app on your phone to scan the QR code.

**Related Documentation:** [Mobile Development Guide](../mobile/development/README.md)

### Backend API
- **URL**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/api/health

**Related Documentation:** [Backend Development Guide](../backend/development/README.md)

---

## What's Next

Now that everything is running, choose your path based on your role:

### For Developers
- **[Environment Configuration](../setup/environment-setup.md)** - Variable references and troubleshooting
- **[Development Workflows](./README.md)** - Project overview and navigation hub
- **[AI Development Setup](./ai-development-setup.md)** - Claude Code and MCP server configuration

### For Architects
- **[System Architecture](../architecture/system-architecture.md)** - Overall system design and patterns
- **[Backend Architecture](../backend/architecture/README.md)** - FastAPI service architecture
- **[Mobile Architecture](../mobile/architecture/README.md)** - React Native app architecture
- **[Admin Architecture](../admin/architecture/README.md)** - Dashboard architecture

### For DevOps
- **[Deployment Guide](../workflows/deployment-guide.md)** - Comprehensive deployment workflows
- **[Testing Guide](../workflows/testing-guide.md)** - Testing strategies and automation
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Problem resolution workflows

### For Understanding the Project
- **[Project Structure](../development/project-structure.md)** - Understand the codebase organization
- **[Development Tools](../development/development-tools.md)** - Testing, linting, and database operations
- **[Common Gotchas](../gotchas/)** - Known issues and solutions

---

## Development Commands Quick Reference

### Daily Development
```bash
# Start all services
just up

# Run all tests
just test

# Check code quality
just lint

# View logs
just logs

# Stop all services
just down
```

### Database Operations
```bash
# Reset with fresh data
just db_reset_safe

# Apply migrations
alembic upgrade head  # Run in backend directory

# Open database shell
just db shell
```

### Application-Specific
```bash
# Backend development
just dev_backend

# Admin development
just dev_admin

# Mobile IP fix (when network changes)
just expo ip auto
```

**Complete Command Reference:** Run `just help` to see all available commands

---

## Need Help?

### Common Issues
- **Services won't start**: Check [Environment Configuration Troubleshooting](./environment-setup.md#troubleshooting)
- **Network connectivity issues**: Run `just expo ip auto` and check firewall settings
- **Database connection errors**: Verify PostgreSQL is running with `just up`
- **Permission errors**: Check Docker permissions and file ownership

### Additional Resources
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Comprehensive problem resolution
- **[Common Gotchas](../gotchas/)** - Known issues and workarounds
- **[Environment Setup](../setup/environment-setup.md)** - Detailed configuration reference

### Getting Support
- Run `just help` for command reference
- Check service logs with `just logs [service_name]`
- Validate environment with `just env_check`
- Review health status with `just health`

---

## Success Indicators

✅ **You're ready to develop when:**
- All health checks pass: `just health`
- Admin dashboard loads at http://localhost:3000
- Backend API responds at http://localhost:8000/api/health
- Mobile environment shows correct IP: `just expo ip auto`
- Demo data loads successfully: `just db_seed_safe`

---

## Related Documentation

- **[Development Workflows](./README.md)** - Main system overview and navigation
- **[Environment Configuration](../setup/environment-setup.md)** - Complete environment setup guide
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment procedures
- **[Testing Guide](../workflows/testing-guide.md)** - Testing strategies and automation
- **[Project Structure](../development/project-structure.md)** - Codebase organization

---

**Status**: ✅ Updated and current as of 2025-06-29. Reorganized for improved navigation and enhanced with role-based next steps.
