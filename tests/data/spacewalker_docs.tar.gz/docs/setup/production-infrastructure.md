# Production Infrastructure Setup

## Overview
Production infrastructure differs from development in several key areas: SSL certificates, DNS configuration, AWS regions, and security requirements. This guide covers production-specific setup and differences.

## Key Differences from Development

| Component | Development | Production |
|-----------|-------------|------------|
| AWS Account | 881490112168 | 352676346183 |
| AWS Region | us-east-2 | us-east-1 |
| AWS Profile | default | production |
| Domain | spacewalker.littleponies.com | spacewalker.degreeanalytics.com |
| SSL Certificate | Created in DNS stack | Separate certificates stack |
| Bastion Host | Enabled by default | Enabled by default |
| Demo Data | Loaded automatically | Loaded automatically (configurable) |
| Production Safety | Not required | Required via `prod_enable` |

## Initial Production Setup

### 1. Prerequisites
- AWS CLI configured with production profile
- Production AWS account access (352676346183)
- SSH key for production bastion

### 2. Enable Production Mode
```bash
# Enable for 2 hours
(just prod enable --minutes=120)
```

### 3. Deploy Infrastructure Stacks
Deploy in this specific order:
```bash
# 1. Foundation (VPC, bastion, S3 buckets)
just aws_deploy_foundation prod

# 2. Create SSH key for bastion
AWS_PROFILE=production aws ec2 create-key-pair \
  --key-name prod-spacewalker-key \
  --query 'KeyMaterial' \
  --output text > ~/.ssh/prod-spacewalker-key.pem
chmod 400 ~/.ssh/prod-spacewalker-key.pem

# 3. Certificates (SSL/TLS)
just aws_deploy_certificates prod

# 4. Database
just aws_deploy_database prod

# 5. ECS Cluster
just aws_deploy_cluster prod

# 6. Backend Service
just aws_deploy_backend prod

# 7. Admin Dashboard
just aws_deploy_admin prod

# 8. Mobile API
just aws_deploy_mobile prod

# 9. DNS Configuration
just aws_deploy_dns prod

# 10. Monitoring (optional)
just aws_deploy_monitoring prod
```

### 4. Grant Bastion Access
```bash
# Add your IP to bastion security group
just bastion_allow_me prod 8
```

### 5. Initialize Database
The backend will automatically run migrations on startup. Demo data is also loaded automatically if `LOAD_DEMO_DATA=true` in the backend task definition.

To manually verify or initialize:
```bash
# Check database status
just aws_db_status prod

# Initialize if needed
just aws_init_demo_db prod
```

## SSL Certificate Architecture

### Production Certificate Requirements
Production uses a wildcard certificate for `*.spacewalker.degreeanalytics.com` to support:
- admin.spacewalker.degreeanalytics.com
- backend.spacewalker.degreeanalytics.com
- mobile.spacewalker.degreeanalytics.com

### Certificate Management
```yaml
# sam/certificates/template.yaml
prod:
  BaseDomain: "degreeanalytics.com"
  HostedZoneId: "Z36YXO7V7E1F92"
  ExistingCertArn: "arn:aws:acm:us-east-1:352676346183:certificate/9927906d-2407-4847-9a33-18dbdabe2dde"
```

The production certificate is pre-created and referenced by ARN. This differs from dev where certificates are created dynamically.

### Why Separate Certificates Stack?
- Production often has pre-existing wildcard certificates
- Allows certificate management independent of DNS
- Prevents circular dependencies between stacks
- Enables certificate sharing across multiple services

## DNS Configuration

### Domain Mapping
```yaml
# sam/dns/template.yaml
Mappings:
  EnvironmentConfig:
    dev:
      BaseDomain: "littleponies.com"
      HostedZoneId: "Z015719326PJOEZC2U8PO"
    prod:
      BaseDomain: "degreeanalytics.com"
      HostedZoneId: "Z36YXO7V7E1F92"
```

### DNS Records Created
- admin.spacewalker.degreeanalytics.com → Admin ALB
- backend.spacewalker.degreeanalytics.com → Backend ALB
- mobile.spacewalker.degreeanalytics.com → Mobile ALB

## Security Considerations

### Production Safety
All destructive operations require production mode:
```bash
# Enable production mode
(just prod enable --minutes=30)

# Now you can run prod commands
just aws_deploy_backend prod
just aws_db_demo_full prod
```

### Bastion Access Control
- IPs must be explicitly whitelisted
- Temporary access tracked with timestamps
- Regular cleanup recommended
```bash
# Add access
just bastion_allow_me prod 8

# Review access
just bastion_list_ips prod

# Clean temporary IPs
just bastion_cleanup_temp_ips prod
```

### Secrets Management
Production secrets are stored in AWS Secrets Manager:
- `AURORA/prod-spacewalker` - Database credentials
- `prod/SPACEWALKER/*` - Application secrets

## Deployment Patterns

### Code Changes
Always use PR workflow for code changes:
```bash
# Create feature branch
gt create --all -m "feat: description"

# Submit PR to dev
gt submit

# After testing, merge to main
gt checkout main && gt sync
gt create --all -m "merge: dev to main"
gt submit
```

### Infrastructure Changes
- Pure infrastructure changes can be deployed directly
- Changes affecting running services should follow PR workflow

### Stack Dependencies
```
foundation → certificates → database → ecs-cluster → [backend, admin, mobile] → dns → monitoring
```

## Monitoring and Logs

### CloudWatch Logs
All services log to CloudWatch:
- `/ecs/prod-spacewalker-backend`
- `/ecs/prod-spacewalker-admin`
- `/ecs/prod-spacewalker-mobile`

### View Logs
```bash
# Tail backend logs
AWS_PROFILE=production aws logs tail /ecs/prod-spacewalker-backend --follow

# Search logs
AWS_PROFILE=production aws logs filter-log-events \
  --log-group-name /ecs/prod-spacewalker-backend \
  --filter-pattern "ERROR"
```

## Troubleshooting Production

### SSL Certificate Issues
If you see "This Connection Is Not Private":
1. Check certificate domain: `just bastion_list_ips prod`
2. Verify certificate ARN in `sam/certificates/template.yaml`
3. Ensure services are using correct certificate

### DNS Not Resolving
1. Check Route53 records: `just health prod`
2. Verify DNS stack deployed: `just stack_status prod`
3. Allow time for DNS propagation (up to 5 minutes)

### Service Not Accessible
1. Check service health: `curl https://backend.spacewalker.degreeanalytics.com/health/`
2. Verify security groups allow traffic
3. Check ECS service status in AWS Console
4. Review CloudWatch logs for errors

### Database Connection Issues
1. Verify bastion access: `just bastion_list_ips prod`
2. Test tunnel: `just db_test prod`
3. Check RDS security group
4. Verify secrets in Secrets Manager

## Production Checklist

Before going live:
- [ ] All stacks deployed successfully
- [ ] SSL certificates working (https:// URLs load)
- [ ] DNS resolves correctly
- [ ] Database initialized with schema
- [ ] Health checks passing
- [ ] Monitoring configured
- [ ] Bastion access restricted
- [ ] Production safety enabled in justfile
- [ ] Backup strategy in place
- [ ] Incident response plan documented

## Related Documentation
- [Environment Configuration](./environment-configuration.md)
- [Bastion Management](../workflows/bastion-management.md)
- [Deployment Guide](../workflows/deployment-guide.md)
- [Troubleshooting Guide](../workflows/troubleshooting-guide.md)
