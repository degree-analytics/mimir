# Email DNS Configuration for SpaceWalker

## Purpose
Configure SPF and DKIM DNS records for the campusiq.com domain to improve email deliverability and authenticate outgoing emails from SpaceWalker's invitation system.

## When to Use This
- Before deploying email functionality to production
- When setting up AWS SES for email delivery
- To improve email deliverability rates and avoid spam filters
- When troubleshooting email delivery issues

**Keywords:** SPF, DKIM, DNS, email authentication, AWS SES, deliverability

---

## 🔐 Email Authentication Overview

### Why Email Authentication Matters
- **SPF (Sender Policy Framework)** - Prevents email spoofing by specifying which servers can send emails from your domain
- **DKIM (DomainKeys Identified Mail)** - Cryptographically signs emails to verify they haven't been tampered with
- **Improved Deliverability** - Authenticated emails are less likely to be marked as spam
- **Brand Protection** - Prevents others from sending emails that appear to come from your domain

### Current Configuration
- **Sending Domain**: campusiq.com
- **Email Address**: spacewalker@campusiq.com
- **AWS SES Regions**: us-east-2 (dev), us-east-1 (prod)
- **Environment-Specific URLs**: Based on BASE_URL_DEV and BASE_URL_PROD

---

## 📋 Required DNS Records

### 1. SPF Record Configuration

#### Current SPF Record Check
```bash
# Check existing SPF record
dig TXT campusiq.com | grep -i spf
```

#### Required SPF Record
```dns
TXT "v=spf1 include:amazonses.com ~all"
```

**Explanation:**
- `v=spf1` - SPF version 1
- `include:amazonses.com` - Allow AWS SES to send emails for this domain
- `~all` - Soft fail for other servers (recommended for initial setup)

#### Production SPF Record (more restrictive)
```dns
TXT "v=spf1 include:amazonses.com -all"
```
**Note:** Use `-all` (hard fail) only after testing to ensure no legitimate emails are blocked.

### 2. DKIM Record Configuration

#### AWS SES DKIM Setup Steps

1. **Verify Domain in AWS SES**
   ```bash
   # Dev environment (us-east-2)
   aws ses verify-domain-identity --domain campusiq.com --region us-east-2
   
   # Prod environment (us-east-1)
   aws ses verify-domain-identity --domain campusiq.com --region us-east-1
   ```

2. **Generate DKIM Tokens**
   ```bash
   # Dev environment
   aws ses verify-domain-dkim --domain campusiq.com --region us-east-2
   
   # Prod environment
   aws ses verify-domain-dkim --domain campusiq.com --region us-east-1
   ```

3. **DKIM DNS Records Format**
   AWS SES will provide 3 CNAME records in this format:
   ```dns
   [token1]._domainkey.campusiq.com CNAME [token1].dkim.amazonses.com
   [token2]._domainkey.campusiq.com CNAME [token2].dkim.amazonses.com
   [token3]._domainkey.campusiq.com CNAME [token3].dkim.amazonses.com
   ```

### 3. Additional Recommended Records

#### DMARC Record (Optional but Recommended)
```dns
_dmarc.campusiq.com TXT "v=DMARC1; p=quarantine; rua=mailto:admin@campusiq.com"
```

**Explanation:**
- `v=DMARC1` - DMARC version 1
- `p=quarantine` - Quarantine emails that fail authentication
- `rua=mailto:admin@campusiq.com` - Send aggregate reports to this email

---

## 🛠️ Implementation Steps

### Phase 1: DNS Record Setup

1. **Access DNS Management**
   - Log into the DNS provider for campusiq.com domain
   - Navigate to DNS record management section

2. **Add SPF Record**
   ```dns
   Type: TXT
   Host: @
   Value: v=spf1 include:amazonses.com ~all
   TTL: 300 (5 minutes for testing, increase to 3600 after verification)
   ```

3. **Verify SPF Implementation**
   ```bash
   # Check SPF record propagation
   dig TXT campusiq.com
   
   # Validate SPF syntax
   spf-syntax-check campusiq.com
   ```

### Phase 2: AWS SES Configuration

1. **Verify Domain in Both Regions**
   ```bash
   # Development region (us-east-2)
   aws ses verify-domain-identity --domain campusiq.com --region us-east-2
   
   # Production region (us-east-1)  
   aws ses verify-domain-identity --domain campusiq.com --region us-east-1
   ```

2. **Enable DKIM**
   ```bash
   # Development region
   aws ses put-identity-dkim-attributes --identity campusiq.com --dkim-enabled --region us-east-2
   
   # Production region
   aws ses put-identity-dkim-attributes --identity campusiq.com --dkim-enabled --region us-east-1
   ```

3. **Get DKIM Tokens**
   ```bash
   # Development region tokens
   aws ses get-identity-dkim-attributes --identities campusiq.com --region us-east-2
   
   # Production region tokens
   aws ses get-identity-dkim-attributes --identities campusiq.com --region us-east-1
   ```

### Phase 3: DKIM DNS Records

1. **Add DKIM CNAME Records**
   For each token provided by AWS SES, add a CNAME record:
   ```dns
   Type: CNAME
   Host: [token]._domainkey
   Value: [token].dkim.amazonses.com
   TTL: 300 (for testing)
   ```

2. **Verify DKIM Implementation**
   ```bash
   # Check DKIM record propagation
   dig CNAME [token1]._domainkey.campusiq.com
   dig CNAME [token2]._domainkey.campusiq.com
   dig CNAME [token3]._domainkey.campusiq.com
   ```

### Phase 4: Verification and Testing

1. **AWS SES Verification Status**
   ```bash
   # Check verification status
   aws ses get-identity-verification-attributes --identities campusiq.com --region us-east-2
   aws ses get-identity-verification-attributes --identities campusiq.com --region us-east-1
   ```

2. **Send Test Email**
   Use the email service test script:
   ```bash
   cd apps/backend
   TEST_EMAIL_ADDRESS=your-test@email.com PYTHONPATH=src python src/spacecargo/api/scripts/test_email_service.py
   ```

3. **Check Email Headers**
   Verify SPF and DKIM authentication in received email headers:
   ```
   Authentication-Results: spf=pass smtp.mailfrom=campusiq.com;
                          dkim=pass header.i=@campusiq.com;
   ```

---

## 🔍 Verification Commands

### DNS Propagation Check
```bash
# Check SPF record
dig TXT campusiq.com | grep -i spf
# Expected output: campusiq.com. 300 IN TXT "v=spf1 include:amazonses.com ~all"

# Check DKIM records (replace [token] with actual tokens from AWS)
dig CNAME [token1]._domainkey.campusiq.com
# Expected output: [token1]._domainkey.campusiq.com. 300 IN CNAME [token1].dkim.amazonses.com.

dig CNAME [token2]._domainkey.campusiq.com
# Expected output: [token2]._domainkey.campusiq.com. 300 IN CNAME [token2].dkim.amazonses.com.

dig CNAME [token3]._domainkey.campusiq.com
# Expected output: [token3]._domainkey.campusiq.com. 300 IN CNAME [token3].dkim.amazonses.com.

# Check DMARC record
dig TXT _dmarc.campusiq.com
# Expected output: _dmarc.campusiq.com. 300 IN TXT "v=DMARC1; p=quarantine; rua=mailto:admin@campusiq.com"
```

### AWS SES Status Check
```bash
# Check domain verification status
aws ses get-identity-verification-attributes --identities campusiq.com --region us-east-2
# Expected output: "VerificationStatus": "Success"

aws ses get-identity-verification-attributes --identities campusiq.com --region us-east-1
# Expected output: "VerificationStatus": "Success"

# Check DKIM status
aws ses get-identity-dkim-attributes --identities campusiq.com --region us-east-2
# Expected output: "DkimEnabled": true, "DkimVerificationStatus": "Success"

aws ses get-identity-dkim-attributes --identities campusiq.com --region us-east-1
# Expected output: "DkimEnabled": true, "DkimVerificationStatus": "Success"

# Check sending quota and rate
aws ses get-send-quota --region us-east-2
# Expected output: Shows Max24HourSend, MaxSendRate, SentLast24Hours

aws ses get-send-quota --region us-east-1
# Expected output: Shows Max24HourSend, MaxSendRate, SentLast24Hours
```

### Email Authentication Testing
```bash
# Online tools for testing
# 1. MXToolbox SPF Checker: https://mxtoolbox.com/spf.aspx
# 2. DKIM Validator: https://dkimvalidator.com/
# 3. Mail Tester: https://www.mail-tester.com/

# Command line testing
echo "Test email content" | mail -s "SPF/DKIM Test" -r spacewalker@campusiq.com test@mail-tester.com
```

---

## 🚨 Troubleshooting Common Issues

### SPF Record Issues

#### Problem: SPF record not found
```bash
# Check current DNS records
dig TXT campusiq.com

# Verify SPF syntax
nslookup -type=TXT campusiq.com
```

**Solution:** Ensure TXT record is properly added with correct syntax.

#### Problem: Multiple SPF records
**Error:** More than one SPF record found
**Solution:** Combine all SPF mechanisms into a single TXT record.

### DKIM Issues

#### Problem: DKIM tokens not generated
```bash
# Force DKIM token regeneration
aws ses put-identity-dkim-attributes --identity campusiq.com --dkim-enabled --region us-east-2
```

#### Problem: DKIM verification failed
**Check CNAME records:**
```bash
# Verify each DKIM CNAME record
for token in [token1] [token2] [token3]; do
  echo "Checking $token:"
  dig CNAME ${token}._domainkey.campusiq.com
done
```

### Email Delivery Issues

#### Problem: Emails marked as spam
**Solution Steps:**
1. Verify SPF authentication passes
2. Confirm DKIM signatures are valid
3. Check sender reputation
4. Implement DMARC policy

#### Problem: Emails not delivered
**Diagnostic Steps:**
```bash
# Check AWS SES bounce/complaint metrics
aws ses get-identity-notification-attributes --identities campusiq.com --region us-east-2

# Review CloudWatch logs for send failures
aws logs describe-log-groups --log-group-name-prefix "/aws/ses"
```

---

## 📊 Monitoring and Maintenance

### Regular Checks
1. **Monthly:** Review SPF/DKIM authentication rates
2. **Quarterly:** Check DMARC reports for authentication failures
3. **Annually:** Rotate DKIM keys (AWS SES handles this automatically)

### Key Metrics to Monitor
- **SPF Pass Rate** - Should be >95%
- **DKIM Pass Rate** - Should be >95% 
- **Bounce Rate** - Should be <5%
- **Complaint Rate** - Should be <0.1%

### AWS SES Sending Limits
- **Development:** Initial limit (typically 200 emails/day, 1 email/second)
- **Production:** Request limit increase through AWS Support
- **Sandbox Mode:** Limited to verified email addresses only

---

## 🔗 Related Documentation

### Email Service Configuration
- **[Email Service Implementation](../backend/api-development.md#email-services)** - Technical implementation details
- **[Environment Configuration](./environment-configuration.md)** - Environment-specific settings

### AWS SES Resources
- **[AWS SES Documentation](https://docs.aws.amazon.com/ses/)** - Official AWS SES documentation
- **[SES Best Practices](https://docs.aws.amazon.com/ses/latest/dg/best-practices.html)** - AWS recommended practices

### DNS and Email Standards
- **[SPF RFC 7208](https://tools.ietf.org/html/rfc7208)** - SPF specification
- **[DKIM RFC 6376](https://tools.ietf.org/html/rfc6376)** - DKIM specification
- **[DMARC RFC 7489](https://tools.ietf.org/html/rfc7489)** - DMARC specification

---

**Status:** ✅ **CONFIGURATION READY**
**Last Updated:** 2025-07-10
**Next Steps:** DNS administrator must implement the records described above
**Environment Impact:** Required for production email delivery

---

*This documentation provides the complete configuration needed for SPaceWalker email authentication. The actual DNS record implementation must be performed by the domain administrator for campusiq.com.*