# 🔍 ast-grep Onboarding Checklist and Exercises

## Purpose
Structured onboarding guide to get new developers proficient with ast-grep security scanning and code analysis in SpaceWalker, with hands-on exercises and validation checkpoints.

## When to Use This
- Onboarding new team members to ast-grep workflows
- Training developers on security scanning and code analysis
- Verifying ast-grep proficiency for existing team members
- Setting up ast-grep development environment for the first time
- Keywords: ast-grep onboarding, security scanning, code analysis, training exercises

**Version:** 1.0
**Date:** 2025-09-10
**Status:** Active - Training Guide

---

## 🎯 Learning Objectives

By completing this onboarding, you will:
- ✅ Understand ast-grep's role in SpaceWalker's security pipeline
- ✅ Master essential ast-grep commands and workflows
- ✅ Create and test custom security rules
- ✅ Interpret and resolve security findings
- ✅ Integrate ast-grep into your daily development workflow
- ✅ Troubleshoot common ast-grep issues independently

**Estimated time**: 45-60 minutes for complete onboarding

---

## 📋 Prerequisites Checklist

### ✅ Environment Setup
Before starting ast-grep training, verify your development environment:

```bash
# 1. Verify SpaceWalker is properly set up
just health                          # All services should be healthy

# 2. Check ast-grep installation
ast-grep --version                  # Should show v0.28.0 or higher
which ast-grep                      # Should show installation path

# 3. Verify SpaceWalker ast-grep integration
ls -la .ast-grep/                   # Should show configuration directory
cat .ast-grep/sgconfig.yml          # Should show SpaceWalker configuration
```

### ✅ Required Knowledge
- Basic familiarity with SpaceWalker development workflow
- Understanding of code security concepts
- Experience with command-line tools
- Basic knowledge of Python, TypeScript, or JavaScript

---

## 🚀 Onboarding Phase 1: Understanding ast-grep

### Exercise 1.1: Explore SpaceWalker's ast-grep Configuration

**Goal**: Understand how ast-grep is configured in SpaceWalker

```bash
# 1. Examine the ast-grep configuration
cat .ast-grep/sgconfig.yml

# 2. Explore security rules structure
ls -la .ast-grep/rules/
ls -la .ast-grep/rules/security/

# 3. Review a sample security rule
cat .ast-grep/rules/security/hardcoded-secrets.yml
```

**✅ Checkpoint**: Can you explain:
- What languages ast-grep scans in SpaceWalker?
- Where security rules are stored?
- What file patterns are included/excluded?

### Exercise 1.2: Run Your First ast-grep Scan

**Goal**: Execute ast-grep and understand the output

```bash
# 1. Run a basic security scan
just lint astgrep

# 2. Run ast-grep manually with verbose output
ast-grep --config .ast-grep/sgconfig.yml scan .

# 3. Run a specific rule category
ast-grep --config .ast-grep/sgconfig.yml scan . --rule .ast-grep/rules/security/
```

**✅ Checkpoint**: Can you:
- Execute ast-grep through SpaceWalker's justfile?
- Interpret the scan output and findings?
- Understand the difference between warnings and errors?

---

## 🔧 Onboarding Phase 2: Hands-On Security Analysis

### Exercise 2.1: Analyze Real Security Findings

**Goal**: Practice interpreting and resolving security issues

```bash
# 1. Create a test file with security issues for practice
mkdir -p .build/tmp/ast-grep-training
cat > .build/tmp/ast-grep-training/security-test.py << 'EOF'
import os

# Example 1: Hardcoded secret
API_KEY = "sk-1234567890abcdef"

# Example 2: SQL injection vulnerability
def get_user(user_id):
    query = f"SELECT * FROM users WHERE id = {user_id}"
    return execute_query(query)

# Example 3: Path traversal vulnerability
def read_file(filename):
    with open(f"/app/data/{filename}", 'r') as f:
        return f.read()
EOF

# 2. Scan the test file
ast-grep --config .ast-grep/sgconfig.yml scan .build/tmp/ast-grep-training/

# 3. Run with specific patterns
ast-grep --pattern 'f"SELECT * FROM $TABLE WHERE $CONDITION"' .build/tmp/ast-grep-training/
```

**✅ Checkpoint**: Can you:
- Identify the security issues in the test file?
- Understand why each issue is flagged?
- Suggest fixes for each vulnerability?

### Exercise 2.2: Practice with Different File Types

**Goal**: Understand how ast-grep analyzes different languages

```bash
# 1. Create a TypeScript test file
cat > .build/tmp/ast-grep-training/security-test.ts << 'EOF'
// Example 1: Hardcoded token
const JWT_SECRET = "super-secret-key-12345";

// Example 2: Unsafe eval usage
function processCode(userInput: string) {
    return eval(userInput);
}

// Example 3: Missing input validation
function deleteUser(userId: any) {
    const query = `DELETE FROM users WHERE id = ${userId}`;
    return database.execute(query);
}
EOF

# 2. Scan TypeScript files
ast-grep --config .ast-grep/sgconfig.yml scan .build/tmp/ast-grep-training/ --lang ts

# 3. Use pattern matching for specific issues
ast-grep --pattern 'eval($ARG)' .build/tmp/ast-grep-training/
```

**✅ Checkpoint**: Can you:
- Identify language-specific security patterns?
- Use language filters effectively?
- Understand cross-language security concerns?

---

## 🛠️ Onboarding Phase 3: Creating Custom Rules

### Exercise 3.1: Write Your First Security Rule

**Goal**: Create a custom ast-grep rule for SpaceWalker-specific security requirements

```bash
# 1. Create a custom rule directory
mkdir -p .build/tmp/ast-grep-training/custom-rules

# 2. Create a SpaceWalker-specific rule
cat > .build/tmp/ast-grep-training/custom-rules/tenant-isolation.yml << 'EOF'
id: spacewalker-tenant-isolation
message: "Potential tenant isolation bypass - ensure proper tenant_id filtering"
severity: error
language: python
rule:
  pattern: |
    def $FUNC($$$PARAMS):
        $$$BODY
        query = $QUERY
        $$$REST
  constraints:
    QUERY:
      regex: "SELECT.*FROM.*WHERE(?!.*tenant_id).*"
    FUNC:
      regex: "get_.*|find_.*|list_.*"
note: "Database queries in data access functions must include tenant_id filtering for proper tenant isolation"
EOF

# 3. Test your custom rule
ast-grep --config .build/tmp/ast-grep-training/custom-rules/tenant-isolation.yml scan apps/backend/
```

**✅ Checkpoint**: Can you:
- Write a basic ast-grep rule from scratch?
- Test your rule against the SpaceWalker codebase?
- Understand rule syntax and constraints?

### Exercise 3.2: Advanced Rule Development

**Goal**: Create more sophisticated rules with multiple patterns

```bash
# 1. Create an advanced security rule
cat > .build/tmp/ast-grep-training/custom-rules/api-security.yml << 'EOF'
id: spacewalker-api-security
message: "API endpoint missing authentication check"
severity: warning
language: python
rule:
  any:
    - pattern: |
        @app.post("$PATH")
        def $FUNC($$$PARAMS):
            $$$BODY
    - pattern: |
        @app.get("$PATH")
        def $FUNC($$$PARAMS):
            $$$BODY
  constraints:
    BODY:
      not:
        any:
          - contains:
              pattern: "get_current_user"
          - contains:
              pattern: "verify_token"
          - contains:
              pattern: "require_auth"
note: "FastAPI endpoints should include authentication checks unless explicitly public"
EOF

# 2. Test the advanced rule
ast-grep --config .build/tmp/ast-grep-training/custom-rules/api-security.yml scan apps/backend/api/
```

**✅ Checkpoint**: Can you:
- Use complex pattern matching with `any` and `not`?
- Create rules that check for missing security controls?
- Understand how to balance rule sensitivity?

---

## ⚡ Onboarding Phase 4: Integration Workflows

### Exercise 4.1: Git Pre-commit Integration

**Goal**: Integrate ast-grep into your daily development workflow

```bash
# 1. Test ast-grep in the justfile workflow
just lint check all                 # Should include ast-grep checks
just dev_cycle                     # Fast development cycle with security checks

# 2. Run ast-grep as part of pre-commit
# (ast-grep runs automatically in SpaceWalker's lint workflow)
just lint format all               # Auto-fix issues where possible

# 3. Check CI integration
cat .github/workflows/ast-grep-security.yml
```

**✅ Checkpoint**: Can you:
- Run ast-grep as part of standard development workflows?
- Understand when ast-grep runs in CI/CD?
- Use justfile commands instead of direct ast-grep calls?

### Exercise 4.2: Performance Optimization

**Goal**: Understand ast-grep performance characteristics and optimization

```bash
# 1. Run performance benchmark
python scripts/helpers/benchmark_astgrep.py

# 2. Check memory usage
/usr/bin/time -l ast-grep --config .ast-grep/sgconfig.yml scan .

# 3. Test file filtering effectiveness
ast-grep --config .ast-grep/sgconfig.yml scan . --debug 2>&1 | grep "files scanned"
```

**✅ Checkpoint**: Can you:
- Understand ast-grep performance characteristics?
- Identify when performance tuning might be needed?
- Use benchmarking tools to measure improvements?

---

## 🔍 Onboarding Phase 5: Troubleshooting Skills

### Exercise 5.1: Debugging Common Issues

**Goal**: Practice diagnosing and resolving ast-grep problems

```bash
# 1. Test with invalid configuration
cp .ast-grep/sgconfig.yml .build/tmp/ast-grep-training/invalid-config.yml
echo "invalid_yaml_syntax: [" >> .build/tmp/ast-grep-training/invalid-config.yml
ast-grep --config .build/tmp/ast-grep-training/invalid-config.yml scan . || echo "Expected failure"

# 2. Test with malformed rules
cat > .build/tmp/ast-grep-training/broken-rule.yml << 'EOF'
id: broken-rule
message: "This rule has syntax errors"
severity: error
language: python
rule:
  pattern: "invalid pattern syntax $$$$"
EOF
ast-grep --config .build/tmp/ast-grep-training/broken-rule.yml scan . || echo "Expected failure"

# 3. Practice using debug output
ast-grep --config .ast-grep/sgconfig.yml scan apps/backend/ --debug 2>&1 | head -20
```

**✅ Checkpoint**: Can you:
- Recognize common ast-grep error patterns?
- Use debug output to diagnose issues?
- Recover from configuration problems?

### Exercise 5.2: Performance Troubleshooting

**Goal**: Identify and resolve performance issues

```bash
# 1. Simulate performance problems
timeout 5s ast-grep --config .ast-grep/sgconfig.yml scan / || echo "Timeout expected"

# 2. Use file filtering to improve performance
ast-grep --config .ast-grep/sgconfig.yml scan . --glob='**/*.py' --glob='**/*.ts'

# 3. Check memory usage patterns
python -c "
import psutil
import subprocess
import time

process = subprocess.Popen(['ast-grep', '--config', '.ast-grep/sgconfig.yml', 'scan', '.'])
time.sleep(1)
proc = psutil.Process(process.pid)
print(f'Memory usage: {proc.memory_info().rss / 1024 / 1024:.1f} MB')
process.wait()
"
```

**✅ Checkpoint**: Can you:
- Identify performance bottlenecks?
- Apply appropriate optimization strategies?
- Monitor resource usage during scans?

---

## 📚 Onboarding Phase 6: Advanced Integration

### Exercise 6.1: CI/CD Pipeline Understanding

**Goal**: Master ast-grep in automated pipelines

```bash
# 1. Review the GitHub Actions workflow
cat .github/workflows/ast-grep-security.yml

# 2. Simulate CI environment locally
docker run --rm -v $(pwd):/workspace -w /workspace \
  ubuntu:22.04 bash -c "
    apt-get update -qq
    apt-get install -y curl
    curl -L https://github.com/ast-grep/ast-grep/releases/latest/download/ast-grep-x86_64-unknown-linux-gnu.tar.gz | tar xz
    ./ast-grep --config .ast-grep/sgconfig.yml scan .
  "

# 3. Test different exit codes
ast-grep --config .ast-grep/sgconfig.yml scan .build/tmp/ast-grep-training/
echo "Exit code: $?"
```

**✅ Checkpoint**: Can you:
- Understand how ast-grep integrates with CI/CD?
- Interpret exit codes and their meanings?
- Troubleshoot pipeline failures?

### Exercise 6.2: Team Workflow Integration

**Goal**: Integrate ast-grep into collaborative development

```bash
# 1. Practice rule sharing and validation
cp .ast-grep/rules/security/hardcoded-secrets.yml .build/tmp/ast-grep-training/
ast-grep --config .build/tmp/ast-grep-training/hardcoded-secrets.yml scan .

# 2. Test rule versioning and updates
git log --oneline .ast-grep/rules/ | head -5

# 3. Validate rule consistency
find .ast-grep/rules/ -name "*.yml" -exec ast-grep check {} \; 2>&1 | grep -E "(error|warning)"
```

**✅ Checkpoint**: Can you:
- Share and validate security rules with the team?
- Understand rule versioning and maintenance?
- Contribute to the rule base effectively?

---

## ✅ Final Validation and Certification

### Comprehensive Skills Assessment

Complete this assessment to validate your ast-grep proficiency:

#### Assessment 1: Security Analysis (15 points)
```bash
# Scan SpaceWalker codebase and analyze findings
just lint astgrep 2>&1 | tee .build/tmp/ast-grep-training/assessment-results.txt

# Answer these questions:
# 1. How many security findings were reported? (3 points)
# 2. What are the most common vulnerability types? (4 points)
# 3. Which files have the highest security risk? (4 points)
# 4. Are there any false positives? How can you tell? (4 points)
```

#### Assessment 2: Rule Development (10 points)
```bash
# Create a custom rule for SpaceWalker's authentication patterns
# Your rule should detect API endpoints that bypass authentication
# Requirements:
# - Detect FastAPI route decorators (@app.get, @app.post, etc.)
# - Flag endpoints that don't use Depends(get_current_user) or similar
# - Exclude public endpoints (health checks, docs, etc.)
# - Provide helpful remediation guidance

# Save your rule as: .build/tmp/ast-grep-training/assessment-auth-check.yml
# Test it against: apps/backend/api/
```

#### Assessment 3: Performance Analysis (5 points)
```bash
# Benchmark ast-grep performance and optimization
python scripts/helpers/benchmark_astgrep.py > .build/tmp/ast-grep-training/performance-assessment.txt

# Answer these questions:
# 1. What is the current scan time for the full codebase?
# 2. How many files are scanned vs. total files?
# 3. What is the memory usage during scanning?
# 4. How does performance scale with rule count?
```

### ✅ Certification Checklist

Mark each item as complete when you can demonstrate the skill:

**Core Competencies:**
- [ ] Execute ast-grep scans using SpaceWalker justfile commands
- [ ] Interpret security findings and assess their severity
- [ ] Create custom security rules for SpaceWalker-specific requirements
- [ ] Resolve false positives and tune rule sensitivity
- [ ] Integrate ast-grep into daily development workflow

**Advanced Skills:**
- [ ] Troubleshoot ast-grep configuration and rule issues
- [ ] Optimize ast-grep performance for large codebases
- [ ] Understand CI/CD pipeline integration and failure modes
- [ ] Contribute to team rule library and security standards
- [ ] Train other developers on ast-grep usage

**Team Integration:**
- [ ] Use ast-grep effectively in code reviews
- [ ] Share security findings and remediation strategies
- [ ] Participate in security rule development and maintenance
- [ ] Escalate complex security issues appropriately

---

## 🎓 Next Steps After Onboarding

### Immediate Actions
1. **Add ast-grep to your daily workflow**:
   ```bash
   # Include in your standard development cycle
   just dev_cycle                  # Fast iteration with security checks
   just dev_cycle_full            # Comprehensive pre-commit validation
   ```

2. **Set up IDE integration** (if available):
   - VS Code: ast-grep extension for real-time feedback
   - Vim/Neovim: ast-grep language server integration

3. **Join security review processes**:
   - Participate in security rule reviews
   - Help triage and resolve security findings
   - Contribute to security knowledge sharing

### Ongoing Learning
- **[ast-grep FAQ and Reference](../workflows/ast-grep-faq-and-reference.md)** - Quick answers and patterns
- **[ast-grep Troubleshooting Guide](../workflows/ast-grep-troubleshooting.md)** - Problem resolution
- **[ast-grep Optimization Guide](../development/ast-grep-optimization-guide.md)** - Performance tuning
- **[SpaceWalker Security Architecture](../architecture/security-architecture.md)** - Team security practices

### Advanced Topics
- Custom rule development for complex security patterns
- Performance profiling and optimization techniques
- Integration with external security tools and workflows
- Security metrics and reporting automation

---

## 🚨 Getting Help

### Quick Support
- **Documentation**: Use `just docs search "ast-grep"` for SpaceWalker-specific guidance
- **Commands**: Run `ast-grep --help` for usage information
- **Configuration**: Check `.ast-grep/sgconfig.yml` for current settings

### Team Support
- **Security Team**: For complex vulnerability assessment and rule development
- **DevOps Team**: For CI/CD integration and performance optimization
- **Development Team**: For workflow integration and tool usage questions

### External Resources
- **Official Documentation**: [ast-grep.github.io](https://ast-grep.github.io/)
- **Community Support**: GitHub discussions and issues
- **Best Practices**: Industry security scanning guidelines

---

**🎉 Congratulations!** You're now ready to use ast-grep effectively in SpaceWalker development. Remember to practice regularly and stay updated with new security patterns and rules.

---

## 🔗 Related Documentation

- **[ast-grep FAQ and Reference](../workflows/ast-grep-faq-and-reference.md)** - Quick reference and common questions
- **[ast-grep Troubleshooting Guide](../workflows/ast-grep-troubleshooting.md)** - Problem resolution procedures
- **[Quick Start Guide](../setup/quick-start.md)** - SpaceWalker development setup
- **[Development Workflows](../workflows/README.md)** - Team development processes
- **[Security Architecture](../architecture/security-architecture.md)** - SpaceWalker security practices

---

**Status**: ✅ Active training guide - Updated 2025-09-10. Comprehensive hands-on onboarding for ast-grep security scanning proficiency in SpaceWalker development environment.
