# Environment Configuration Reference

## Purpose
Comprehensive reference for configuring environment variables and troubleshooting environment setup issues across all Spacewalker applications and environments.

## When to Use This
- Setting up local development environment for any application
- Configuring production deployment environment variables
- Troubleshooting environment-related issues during development
- Understanding secret management across development and production
- Keywords: environment variables, configuration, setup, troubleshooting, secrets

**Version:** 2.0 (Updated for new documentation structure)
**Date:** 2025-06-29
**Status:** Current - Comprehensive Reference

---

## Quick Start

### For New Developers
- **First-time setup?** Start with the [Getting Started Guide](../setup/getting-started.md) for step-by-step instructions
- **Need environment variable details?** Use this document as your complete reference
- **Having environment issues?** Check the [Troubleshooting](#troubleshooting) section below

### For Production Setup
- **Setting up for production?** See the [Secret Management](#secret-management) section
- **CI/CD configuration?** Review the [CI/CD Environment](#cicd-environment) section

## Quick Reference

| Variable | Service | Required | Purpose |
|----------|---------|----------|---------|
| `DATABASE_URL` | Backend | **Yes** | PostgreSQL connection string |
| `JWT_SECRET_KEY` | Backend | **Yes** | JWT signing key |
| `GEMINI_API_KEY` | Backend | No | Google Gemini AI integration |
| `NEXT_PUBLIC_API_BASE_URL` | Admin | **Yes** | Backend API endpoint |
| `EXPO_PUBLIC_API_URL` | Mobile | **Yes** | Backend API endpoint (with IP) |
| `SENTRY_DSN` | Backend | No | Error tracking |
| `ENVIRONMENT` | Backend | No | Runtime environment |

## Centralized `.env` File

For local development using `just` and Docker Compose, this project uses a single, centralized `.env` file located at the project root. This file is loaded by `docker-compose.yml` and provides configuration to all services.

To get started, copy the example file:
```bash
cp .env.example .env
```
Then, edit the `.env` file to set your local configuration. This file is included in `.gitignore` and should not be committed to source control.

---

## Application-Specific Configuration

### Backend (`apps/backend`)

The backend service requires the following variables:

| Variable           | Required | Description                                                                 | Development Default               |
| ------------------ | -------- | --------------------------------------------------------------------------- | --------------------------------- |
| `DATABASE_URL`     | **Yes**  | The full connection string for the PostgreSQL database.                     | `postgresql://user:pass@db:5432/db` |
| `JWT_SECRET_KEY`   | **Yes**  | A secret key for signing JWTs. Should be long and random in production.     | `a_very_secret_key`               |
| `GEMINI_API_KEY`   | No       | Your API key for Google Gemini, required for AI-powered survey analysis.    | `""` (empty string)               |
| `SENTRY_DSN`       | No       | The DSN for connecting to Sentry for error tracking.                        | `""` (empty string)               |
| `ENVIRONMENT`      | No       | The runtime environment (`development`, `staging`, `production`).           | `development`                     |

#### Example `apps/backend/.env` (For Standalone Use)
While the root `.env` is preferred, if running the backend standalone, you can create a `.env` file inside `apps/backend/`:
```env
DATABASE_URL=postgresql://spacewalker_user:spacewalker_dev@db:5432/spacewalker
JWT_SECRET_KEY=a_very_secret_key_for_local_dev
GEMINI_API_KEY="your-google-gemini-api-key"
```

**Related Documentation:** [Backend Development Guide](../backend/development/README.md)

### Admin Dashboard (`apps/admin`)

The admin dashboard requires one primary build-time environment variable to know where the backend API is located.

| Variable                  | Required | Description                                      | Development Default         |
| ------------------------- | -------- | ------------------------------------------------ | --------------------------- |
| `NEXT_PUBLIC_API_BASE_URL` | **Yes**  | The base URL for the backend API.                | `http://localhost:8000/api` |

This variable is "public" (exposed to the browser) and is typically set in an `.env.local` file inside `apps/admin/`.

#### Example `apps/admin/.env.local`
```env
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000/api
```

**Related Documentation:** [Admin Development Guide](../admin/architecture/README.md)

### Mobile App (`apps/mobile`)

The mobile app needs to know the IP address of your development machine to connect to the backend API.

| Variable        | Required | Description                                                |
| --------------- | -------- | ---------------------------------------------------------- |
| `EXPO_PUBLIC_API_URL` | **Yes**  | The full URL to the backend API, including your LAN IP. |

This is managed automatically by the `just expo ip auto` command, which detects your local network IP and creates an `.env.local` file in `apps/mobile/`.

#### Example `apps/mobile/.env`
```env
EXPO_PUBLIC_API_URL=http://192.168.1.100:8000/api
```
**Note:** Do not edit this file manually. Run `just expo ip auto` if your network address changes.

**Related Documentation:** [Mobile Development Guide](../mobile/development/README.md)

---

## Secret Management

### Development Environment
- Use the root `.env` file for local development
- Do not commit this file to version control
- Copy from `.env.example` and customize for your setup
- All development secrets should use non-production values

### Production Environment
Secrets should be managed through your hosting provider's secret management system:
- **AWS**: AWS Secrets Manager or Parameter Store
- **Docker**: Docker Secrets or environment variables injected by CI/CD
- **Kubernetes**: Kubernetes Secrets or external secret operators

The production Docker images are built to expect these variables at runtime.

### Security Best Practices
- Use different JWT keys for each environment
- Rotate secrets regularly in production
- Never log secret values
- Use least-privilege access for secret retrieval

---

## Troubleshooting

### Common Issues

#### "Database connection failed"
**Symptoms:** Backend fails to start, connection errors in logs
**Solutions:**
- **Check**: `DATABASE_URL` is correctly formatted
- **Verify**: PostgreSQL service is running (`just up` or `docker-compose up db`)
- **Test**: Connect directly: `psql $DATABASE_URL`
- **Debug**: Check if database exists and user has proper permissions

#### "JWT errors" or "Authentication failed"
**Symptoms:** Login fails, token validation errors
**Solutions:**
- **Check**: `JWT_SECRET_KEY` is set and consistent across all services
- **Note**: Key must be the same for all backend instances
- **Verify**: Key is sufficiently long and random for production

#### Mobile app can't connect to backend
**Symptoms:** Network errors, API calls fail from mobile app
**Solutions:**
- **Run**: `just expo ip auto` to update your network IP address
- **Check**: Backend is accessible at the IP shown in `apps/mobile/.env`
- **Verify**: No firewall blocking port 8000
- **Test**: Try accessing `http://YOUR_IP:8000/api/health` from browser

#### Admin dashboard "API calls fail"
**Symptoms:** Dashboard loads but data doesn't appear, network errors
**Solutions:**
- **Check**: `NEXT_PUBLIC_API_BASE_URL` points to running backend
- **Verify**: Backend is running and accessible at that URL
- **Note**: This must be set at build time for Next.js
- **Rebuild**: Run `just build_admin` after environment changes

#### Permission denied errors
**Symptoms:** File access errors, Docker permission issues
**Solutions:**
- **Linux/Mac**: Check file permissions on `.env` files (`chmod 644 .env`)
- **Windows**: Run terminal as administrator if needed
- **Docker**: Ensure Docker has proper file access permissions
- **SELinux**: Check SELinux policies if enabled

### Platform-Specific Notes

#### Windows
- Use forward slashes in paths within `.env` files
- Docker Desktop must be running for database services
- Consider using WSL2 for better Docker performance
- PowerShell may require different syntax for environment variables

#### macOS
- No special requirements for environment setup
- Docker Desktop works reliably
- Use `just expo ip auto` if your network changes
- M1/M2 Macs should use native Docker images when available

#### Linux
- Docker may require `sudo` unless user is in docker group
- Add user to docker group: `sudo usermod -aG docker $USER`
- Logout and login again after adding to docker group
- Check systemd services for PostgreSQL/Redis if running natively

### Debugging Environment Issues

#### Verification Commands
```bash
# Check all environment files exist
find . -name ".env*" -type f

# Verify environment variables are loaded
docker-compose exec backend env | grep -E "(DATABASE_URL|JWT_SECRET)"

# Test database connectivity
docker-compose exec backend python -c "
import os
from sqlalchemy import create_engine
try:
    engine = create_engine(os.environ['DATABASE_URL'])
    with engine.connect() as conn:
        print('Database connection successful')
except Exception as e:
    print(f'Database connection failed: {e}')
"

# Check API endpoints
curl http://localhost:8000/api/health
```

#### Common Environment Patterns
```bash
# Development pattern
ENVIRONMENT=development
LOG_LEVEL=debug
DEBUG=true

# Staging pattern
ENVIRONMENT=staging
LOG_LEVEL=info
DEBUG=false

# Production pattern
ENVIRONMENT=production
LOG_LEVEL=warning
DEBUG=false
```

---

## CI/CD Environment

The CI/CD pipeline (defined in `.github/workflows/`) requires secrets to be configured in your repository's GitHub Actions settings. These include:

### Required GitHub Secrets
- `DOCKERHUB_USERNAME` - Docker Hub registry access
- `DOCKERHUB_TOKEN` - Docker Hub authentication token
- `DATABASE_URL` - Production database connection string
- `JWT_SECRET_KEY` - Production JWT signing key
- Additional environment-specific secrets as needed

### Environment-Specific Deployments
```yaml
# Example GitHub Actions environment configuration
production:
  DATABASE_URL: ${{ secrets.PROD_DATABASE_URL }}
  JWT_SECRET_KEY: ${{ secrets.PROD_JWT_SECRET }}
  ENVIRONMENT: production

staging:
  DATABASE_URL: ${{ secrets.STAGING_DATABASE_URL }}
  JWT_SECRET_KEY: ${{ secrets.STAGING_JWT_SECRET }}
  ENVIRONMENT: staging
```

---

## Related Documentation

- **[Getting Started Guide](../setup/getting-started.md)** - Complete project setup
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment workflows
- **[Backend Development](../backend/development/README.md)** - Backend-specific setup
- **[Mobile Development](../mobile/development/README.md)** - Mobile development environment
- **[Admin Development](../admin/architecture/README.md)** - Admin dashboard setup
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General problem resolution

---

**Need Help?** If you're still having issues after checking this guide, please check the [Getting Started Guide](../setup/getting-started.md) or create an issue in the repository.

---
**Status**: ✅ Updated and current as of 2025-06-29. Reorganized for improved discoverability and enhanced with troubleshooting workflows.
