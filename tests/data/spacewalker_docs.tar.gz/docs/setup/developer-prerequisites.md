# Developer Prerequisites for Spacewalker

This document covers **all prerequisites** needed to successfully use the justfile commands and develop on the Spacewalker project.

> **Note**: The environment validator uses a configuration file at `scripts/helpers/env_validator_config.yaml` to define tool requirements for each environment. This allows easy updates to tool versions and requirements without modifying code.

## Table of Contents
- [Tool Requirements Policy](#tool-requirements-policy)
- [Core Tools](#core-tools)
- [AWS Configuration](#aws-configuration)
- [Python Environment](#python-environment)
- [Node.js Environment](#nodejs-environment)
- [Mobile Development](#mobile-development)
- [Database Tools](#database-tools)
- [Additional Tools](#additional-tools)
- [Environment Files](#environment-files)
- [Verification](#verification)

## Tool Requirements Policy

> **⚠️ All Tools Required**: At Spacewalker, we maintain a unified development environment where **all tools listed in this document are required for all developers**, regardless of their primary focus area. This ensures:
> - Any developer can work on any part of the system
> - Consistent development environments across the team
> - Reduced "works on my machine" issues
> - Simplified onboarding and support
>
> The bootstrap script (`./scripts/bootstrap.sh`) enforces these requirements and will exit with an error if any tool is missing.

## Quick Bootstrap (Recommended)

For fresh machines, we provide a bootstrap script that checks prerequisites and installs required dependencies:

```bash
# Clone the repository first
git clone https://github.com/degree-analytics/spacewalker.git
cd spacewalker

# Run bootstrap script
./scripts/bootstrap.sh
```

The bootstrap script will:
- ✅ Check for required tools (Python, Node.js, Docker, Just, AWS CLI, GitHub CLI, SAM CLI, PostgreSQL client, jq, ripgrep, ast-grep)
- ✅ Verify AWS profiles and credentials (development, production)
- ✅ Check GitHub CLI authentication status
- ✅ Install Python prerequisites (uv, PyYAML, python-dotenv, pre-commit)
- ✅ Verify SSH keys for Git operations
- ✅ Check for API keys in environment (OpenAI, Anthropic)
- ✅ Validate .env and .envrc files
- ✅ Check EAS credentials for mobile builds
- ✅ Provide specific instructions for any missing components

## Core Tools

### 1. Just (Command Runner)
**Required for:** Running any `just` commands

```bash
# macOS
brew install just

# Linux
curl --proto '=https' --tlsv1.2 -sSf https://just.systems/install.sh | bash -s -- --to ~/bin

# Verify
just --version
```

### 2. Docker & Docker Compose
**Required for:** Local development, running services

```bash
# macOS
brew install --cask docker

# Linux
# Follow official Docker installation guide for your distribution
# https://docs.docker.com/engine/install/

# Verify
docker --version
docker compose version
```

### 3. Git
**Required for:** Version control

```bash
# macOS
brew install git

# Linux
sudo apt-get install git  # Ubuntu/Debian
sudo yum install git      # RedHat/CentOS

# Verify
git --version
```

## AWS Configuration

### 1. AWS CLI
**Required for:** AWS deployments, health checks, logs

```bash
# macOS
brew install awscli

# Linux
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Verify
aws --version
```

### 2. AWS Profiles
**Required for:** Environment-specific AWS operations

> **🔐 Production Access Note**: As a small team, we currently provide all developers with both development and production AWS access. This simplifies our development workflow and allows any team member to assist with production issues. This approach will be revisited as the team grows.

You MUST configure two AWS profiles:

```bash
# Development profile (for dev/staging environments)
aws configure --profile development
# Enter your AWS Access Key ID
# Enter your AWS Secret Access Key
# Default region: us-east-2
# Default output format: json

# Production profile (required for all developers)
aws configure --profile production
# Enter your AWS Access Key ID
# Enter your AWS Secret Access Key
# Default region: us-east-1
# Default output format: json
```

**Verify profiles:**
```bash
aws configure list-profiles
# Should show:
# development
# production
```

## Python Environment

### 1. Python 3.11+
**Required for:** Backend development, scripts

```bash
# macOS
brew install python@3.11

# Linux
sudo apt-get install python3.11 python3.11-venv  # Ubuntu/Debian
sudo yum install python3.11                       # RedHat/CentOS

# Verify
python3 --version  # Should show 3.11.x or higher
```

### 2. UV (Python Package Manager)
**Required for:** Fast Python dependency management

```bash
# macOS
brew install uv

# Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Verify
uv --version
```

### 3. Helper Script Prerequisites
**Required for:** Running justfile helper scripts

The Spacewalker helper scripts require these Python packages:

```bash
# Use the bootstrap script for comprehensive environment setup:
./scripts/bootstrap.sh
```

The bootstrap script will:
- Check for all required tools (Python, Node.js, Docker, Just, AWS CLI, GitHub CLI, SAM CLI, PostgreSQL client, jq, ripgrep, ast-grep)
- Verify AWS profiles (development, production) and credentials
- Check GitHub CLI authentication
- Install Python prerequisites (uv, PyYAML, python-dotenv, pre-commit)
- Verify SSH keys for Git operations
- Check for API keys and environment configuration
- Provide specific instructions for any missing components

### 4. Virtual Environment
**Created automatically by justfile, but for reference:**

```bash
# This is handled by `just install`
python3 -m venv .venv
source .venv/bin/activate  # Linux/macOS
# or
.venv\Scripts\activate     # Windows
```

## Node.js Environment

### 1. Node.js & NPM
**Required for:** Frontend development (admin, mobile)

```bash
# macOS
brew install node

# Linux (using NodeSource repository)
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify
node --version  # Should be 18.x or higher
npm --version   # Should be 8.x or higher
```

### 2. Global NPM Packages
**Required for:** Various build and deployment tasks

```bash
# JSON CLI tool (required for version scripts)
npm install -g json

# EAS CLI (required for mobile builds)
npm install -g eas-cli

# Expo CLI (optional, for local mobile development)
npm install -g expo-cli
```

## Mobile Development

### 1. EAS CLI
**Required for:** Mobile app builds and submissions

```bash
npm install -g eas-cli

# Verify
eas --version

# Login (requires Expo account)
eas login
```

### 2. Mobile Development Tools
**Optional but recommended for local testing:**

- **iOS Development:**
  - macOS only
  - Xcode (from App Store)
  - iOS Simulator (comes with Xcode)

- **Android Development:**
  - Android Studio
  - Android SDK
  - Android Emulator or physical device

## Database Tools

### 1. PostgreSQL Client
**Required for:** Database operations, health checks

```bash
# macOS
brew install postgresql

# Linux
sudo apt-get install postgresql-client  # Ubuntu/Debian
sudo yum install postgresql             # RedHat/CentOS

# Verify
psql --version
```

## Additional Tools

### 1. jq (JSON Processor)
**Required for:** JSON manipulation in scripts

```bash
# macOS
brew install jq

# Linux
sudo apt-get install jq  # Ubuntu/Debian
sudo yum install jq      # RedHat/CentOS

# Verify
jq --version
```

### 2. ripgrep (rg)
**Required for:** High-performance text search in development workflows

```bash
# macOS
brew install ripgrep

# Linux
sudo apt-get install ripgrep  # Ubuntu/Debian
cargo install ripgrep         # Alternative via Rust

# Verify
rg --version
```

### 3. ast-grep (sg)
**Required for:** Structural code analysis and pattern matching

```bash
# macOS
brew install ast-grep

# Linux  
cargo install ast-grep  # Via Rust
# OR download from: https://github.com/ast-grep/ast-grep/releases

# Verify
sg --version
```

### 4. direnv (Optional)
**Recommended for:** Automatic environment variable loading

```bash
# macOS
brew install direnv

# Linux
curl -sfL https://direnv.net/install.sh | bash

# Add to your shell RC file (.bashrc, .zshrc, etc.)
eval "$(direnv hook bash)"  # or zsh
```

### 5. GitHub CLI (Optional)
**Useful for:** PR operations, secret management

```bash
# macOS
brew install gh

# Linux
# Follow: https://github.com/cli/cli/blob/trunk/docs/install_linux.md

# Verify and authenticate
gh --version
gh auth login
```

## Environment Files

### 1. Root .env File
**Required for:** Local development

```bash
# Copy template
cp .env.example .env

# Edit with your configuration
# Key variables to set:
# - DATABASE_URL
# - API tokens and secrets
# - Service URLs
```

### 2. Production Mode File
**Automatically created by:** `just prod enable`

The `.prod_mode_expires` file is used for production safety:
- Created when you run `(just prod enable --minutes=30)` (30 minutes)
- Prevents accidental production operations
- Auto-expires after the specified time
- Check status with `just prod status`

## Verification

### Automated Verification
The project includes a comprehensive environment validator that checks all prerequisites:

```bash
# Check all prerequisites for your environment
just env_status        # Checks local environment by default
just env_status dev    # Check dev environment requirements
just env_status prod   # Check production environment requirements
```

The validator provides:
- ✅ Detailed verbose output with tool versions and paths
- ✅ Platform-specific installation instructions
- ✅ AWS profile and credential verification
- ✅ Docker daemon status checks
- ✅ Project structure validation
- ✅ Clear error messages with remediation steps

### Manual Verification
You can also manually verify key tools:

```bash
echo "Checking prerequisites..."
command -v just && echo "✅ just installed" || echo "❌ just missing"
command -v docker && echo "✅ docker installed" || echo "❌ docker missing"
command -v aws && echo "✅ aws-cli installed" || echo "❌ aws-cli missing"
command -v python3 && echo "✅ python3 installed" || echo "❌ python3 missing"
command -v node && echo "✅ node installed" || echo "❌ node missing"
command -v psql && echo "✅ psql installed" || echo "❌ psql missing"
command -v uv && echo "✅ uv installed" || echo "❌ uv missing"
command -v jq && echo "✅ jq installed" || echo "❌ jq missing"
command -v rg && echo "✅ ripgrep installed" || echo "❌ ripgrep missing"
command -v sg && echo "✅ ast-grep installed" || echo "❌ ast-grep missing"

# Check AWS profiles
aws configure list-profiles | grep -q "development" && echo "✅ development profile" || echo "❌ development profile missing"
aws configure list-profiles | grep -q "production" && echo "✅ production profile" || echo "❌ production profile missing"

# Check Node global packages
npm list -g json &>/dev/null && echo "✅ json package" || echo "❌ json package missing"
npm list -g eas-cli &>/dev/null && echo "✅ eas-cli" || echo "❌ eas-cli missing"
```

### Full Setup Verification
After installing all prerequisites:

```bash
# 1. Install project dependencies
just service install all

# 2. Set up environment
just env_setup

# 3. Verify everything is working
just env_status
just health local
```

## Troubleshooting

### Common Issues

1. **"command not found: just"**
   - Ensure just is installed and in your PATH
   - Try `brew install just` or check installation docs

2. **"AWS profile 'development' not found"**
   - Run `aws configure --profile development`
   - Ensure you have valid AWS credentials

3. **"Docker daemon is not running"**
   - Start Docker Desktop (macOS) or Docker service (Linux)
   - Run `docker info` to verify

4. **"psql: command not found"**
   - Install PostgreSQL client tools
   - On macOS: `brew install postgresql`

5. **Python/Node version issues**
   - Use version managers like pyenv or nvm for multiple versions
   - Ensure you're using Python 3.11+ and Node 18+

### Getting Help

If you encounter issues:
1. Check `docs/workflows/troubleshooting-guide.md`
2. Run `just help` for available commands
3. Check GitHub issues for known problems
4. Ask in the team Slack channel

## Next Steps

Once all prerequisites are installed:
1. Follow `docs/setup/quick-start.md` for project setup
2. Read `docs/workflows/` for development workflows
3. Check `docs/development/justfile-help-system.md` for command documentation
