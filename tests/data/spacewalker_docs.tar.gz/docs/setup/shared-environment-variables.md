# Shared Environment Variables Reference

## Purpose
Authoritative documentation for environment variable names used across multiple services in the Spacewalker platform. This document serves as the single source of truth to prevent configuration drift and ensure consistency between backend, frontend, and infrastructure deployments.

## When to Use This
- Setting up environment variables for any service
- Resolving variable name conflicts between services
- Adding new shared configuration
- Reviewing environment variable usage in code
- Troubleshooting configuration-related deployment issues

**Keywords:** environment variables, configuration standards, shared variables, naming conventions

**Version:** 1.0
**Date:** 2025-06-29
**Status:** Current - Authoritative Reference

---

## 🚀 Quick Reference

| Category | Standard Format | ❌ Deprecated Names |
|----------|----------------|---------------------|
| Storage | `S3_BUCKET_NAME` | `IMAGE_BUCKET`, `IMAGES_BUCKET` |
| API | `API_BASE_URL` | `API_URL`, `BACKEND_URL` |
| Database | `DATABASE_*` | `DB_*` |
| Auth | `JWT_SECRET_KEY` | `JWT_SECRET`, `JWT_TOKEN` |

---

## 🎯 Standard Environment Variables

### 📦 Storage Configuration

Use these variable names for all storage-related configuration:

| Variable Name | Required | Description | Example Value |
|---------------|----------|-------------|---------------|
| `S3_BUCKET_NAME` | Yes | Primary S3 bucket for file storage | `prod-spacewalker-photos-123456789` |
| `S3_REGION` | No | AWS region for S3 operations | `us-east-1` |
| `S3_ENDPOINT_URL` | No | Custom S3 endpoint (for MinIO/local dev) | `http://localhost:9000` |
| `STORAGE_PROVIDER` | No | Storage backend type | `s3` or `local` |
| `STORAGE_VALIDATION_ENABLED` | No | Enable storage validation middleware | `true` |

**Usage Example:**
```python
# ✅ CORRECT - Use these standard names
bucket_name = os.getenv('S3_BUCKET_NAME')
region = os.getenv('S3_REGION', 'us-east-1')
provider = os.getenv('STORAGE_PROVIDER', 'local')
```

### 🌐 API Configuration

Use these variable names for all API endpoint configuration:

| Variable Name | Required | Description | Example Value |
|---------------|----------|-------------|---------------|
| `API_BASE_URL` | Yes | Base URL for backend API services | `https://api.spacewalker.com` |
| `API_TIMEOUT` | No | Request timeout in seconds | `30` |
| `API_VERSION` | No | API version identifier | `v1` |

**Usage Example:**
```typescript
// ✅ CORRECT - Use these standard names
const apiUrl = process.env.API_BASE_URL;
const timeout = parseInt(process.env.API_TIMEOUT || '30');
```

### 🗄️ Database Configuration

Use these variable names for all database-related configuration:

| Variable Name | Required | Description | Example Value |
|---------------|----------|-------------|---------------|
| `DATABASE_URL` | Yes | Complete PostgreSQL connection string | `postgresql://spacewalker_user:spacewalker_dev@db:5432/spacewalker` |
| `DATABASE_HOST` | No | Database server hostname | `db` (Docker) or `localhost` (local) |
| `DATABASE_PORT` | No | Database server port | `5432` |
| `DATABASE_NAME` | No | Database name | `spacewalker` |
| `DATABASE_USER` | No | Database username | `spacewalker_user` |
| `DATABASE_PASSWORD` | No | Database password | `spacewalker_dev` |
| `POSTGRES_USER` | Yes | PostgreSQL superuser (Docker) | `spacewalker_user` |
| `POSTGRES_PASSWORD` | Yes | PostgreSQL superuser password (Docker) | `spacewalker_dev` |
| `POSTGRES_DB` | Yes | Initial database name (Docker) | `spacewalker` |
| `DATABASE_POOL_SIZE` | No | Connection pool size | `10` |
| `DATABASE_MAX_CONNECTIONS` | No | Maximum connections | `20` |

**Usage Example:**
```python
# ✅ CORRECT - Use these standard names
database_url = os.getenv('DATABASE_URL')
# OR for component-based configuration:
db_host = os.getenv('DATABASE_HOST')
db_port = int(os.getenv('DATABASE_PORT', '5432'))
db_name = os.getenv('DATABASE_NAME')
```

### 🔐 Authentication Configuration

Use these variable names for all authentication and security configuration:

| Variable Name | Required | Description | Example Value |
|---------------|----------|-------------|---------------|
| `JWT_SECRET_KEY` | Yes | Secret key for JWT token signing | `your-256-bit-secret-key-here` |
| `JWT_ALGORITHM` | No | JWT signing algorithm | `HS256` |
| `JWT_EXPIRATION_HOURS` | No | Token expiration time in hours | `24` |
| `SESSION_SECRET` | No | Session signing secret | `session-secret-key` |

**Usage Example:**
```python
# ✅ CORRECT - Use these standard names
jwt_secret = os.getenv('JWT_SECRET_KEY')
jwt_algorithm = os.getenv('JWT_ALGORITHM', 'HS256')
expiration = int(os.getenv('JWT_EXPIRATION_HOURS', '24'))
```

### ☁️ AWS Configuration

Use these variable names for AWS service configuration:

| Variable Name | Required | Description | Example Value |
|---------------|----------|-------------|---------------|
| `AWS_REGION` | No | Default AWS region | `us-east-1` |
| `AWS_ACCESS_KEY_ID` | No | AWS access key (local dev only) | `AKIAIOSFODNN7EXAMPLE` |
| `AWS_SECRET_ACCESS_KEY` | No | AWS secret key (local dev only) | `wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY` |
| `AWS_SECRETS_NAME` | No | Secrets Manager secret name pattern | `{env}/spacewalker/api-keys` |

**Usage Example:**
```python
# ✅ CORRECT - Use these standard names
aws_region = os.getenv('AWS_REGION', 'us-east-1')
secrets_name = os.getenv('AWS_SECRETS_NAME', 'dev/spacewalker/api-keys')
```

### 🤖 External API Integration

Use these variable names for external service integrations:

| Variable Name | Required | Description | Example Value |
|---------------|----------|-------------|---------------|
| `GEMINI_API_KEY` | Yes | Google Gemini API key for AI analysis | `AIzaSyC_api_key_here` |

**🔒 SECURITY IMPLEMENTATION:**
- **Backend**: ✅ AWS Secrets Manager (`${Environment}/spacewalker/api-keys:GEMINI_API_KEY`)
- **Mobile**: ✅ AWS Secrets Manager (`${Environment}/spacewalker/api-keys:GEMINI_API_KEY`)
- **Admin**: ✅ Uses backend API proxy (no direct Gemini access)
- **Local Dev**: Environment variables in `.env` files
- **⚠️ CRITICAL**: Never commit API keys to source code

### 🏥 Health Check Configuration

Use these variable names for health check behavior configuration:

| Variable Name | Required | Description | Example Value | Default |
|---------------|----------|-------------|---------------|---------|
| `BACKEND_HEALTH_URL` | No | Override backend health check URL | `http://backend:8000/health` | Service-specific |
| `HEALTH_CHECK_TIMEOUT_MS` | No | Health check timeout in milliseconds | `5000` | `5000` |
| `BOOTSTRAP_MODE` | No | **Deprecated** - No longer needed after circular dependency fix | `true` | N/A |

**Usage Notes:**
- **`BACKEND_HEALTH_URL`**: Typically set in ECS task definitions to override default backend URL
- **`HEALTH_CHECK_TIMEOUT_MS`**: Prevents health checks from hanging on slow connections
- **`BOOTSTRAP_MODE`**: Previously used to bypass backend checks during initial deployment - removed in favor of always-healthy pattern

**Implementation Details:**
- Health checks now always return HTTP 200 for ALB compatibility
- Backend connectivity reported as 'degraded' status when unreachable
- Prevents circular dependency: services can start without backend being available

---

## ❌ Deprecated Variables (DO NOT USE)

The following variable names should **NEVER** be used. Use the standard names above instead:

### 🚫 Storage - Deprecated Names
- `IMAGE_BUCKET` → Use `S3_BUCKET_NAME`
- `IMAGES_BUCKET` → Use `S3_BUCKET_NAME`
- `BUCKET_NAME` → Use `S3_BUCKET_NAME`
- `FILE_BUCKET` → Use `S3_BUCKET_NAME`
- `UPLOAD_BUCKET` → Use `S3_BUCKET_NAME`

### 🚫 API - Deprecated Names
- `API_URL` → Use `API_BASE_URL`
- `BACKEND_URL` → Use `API_BASE_URL`
- `BACKEND_API_URL` → Use `API_BASE_URL`
- `SERVER_URL` → Use `API_BASE_URL`
- `API_ENDPOINT` → Use `API_BASE_URL`

### 🚫 Database - Deprecated Names
- `DB_HOST` → Use `DATABASE_HOST`
- `DB_PORT` → Use `DATABASE_PORT`
- `DB_NAME` → Use `DATABASE_NAME`
- `DB_USER` → Use `DATABASE_USER`
- `DB_PASSWORD` → Use `DATABASE_PASSWORD`
- `POSTGRES_HOST` → Use `DATABASE_HOST`
- `POSTGRES_USER` → Use `DATABASE_USER`

### 🚫 Authentication - Deprecated Names
- `JWT_SECRET` → Use `JWT_SECRET_KEY`
- `JWT_TOKEN` → Use `JWT_SECRET_KEY`
- `SECRET_KEY` → Use `JWT_SECRET_KEY`
- `AUTH_SECRET` → Use `JWT_SECRET_KEY`

---

## 📝 Usage Guidelines

### Environment File Examples

#### ✅ CORRECT .env file:
```bash
# Storage
S3_BUCKET_NAME=dev-spacewalker-photos
S3_REGION=us-east-1
STORAGE_PROVIDER=s3

# API
API_BASE_URL=https://api-dev.spacewalker.com

# Database
DATABASE_URL=postgresql://spacewalker_user:spacewalker_dev@db:5432/spacewalker

# Authentication
JWT_SECRET_KEY=your-256-bit-secret-key-here

# External APIs
GEMINI_API_KEY=your-gemini-api-key
```

#### ❌ INCORRECT .env file:
```bash
# ❌ DON'T USE THESE DEPRECATED NAMES
IMAGE_BUCKET=dev-spacewalker-photos
API_URL=https://api-dev.spacewalker.com
DB_HOST=localhost
JWT_SECRET=your-secret-key
```

### Code Usage Examples

#### ✅ CORRECT Python code:
```python
import os
from typing import Optional

# Storage configuration
S3_BUCKET_NAME = os.getenv('S3_BUCKET_NAME')
S3_REGION = os.getenv('S3_REGION', 'us-east-1')

# API configuration
API_BASE_URL = os.getenv('API_BASE_URL')

# Database configuration
DATABASE_URL = os.getenv('DATABASE_URL')

# Authentication
JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY')
```

#### ✅ CORRECT TypeScript code:
```typescript
// Storage configuration
const s3BucketName = process.env.S3_BUCKET_NAME;
const s3Region = process.env.S3_REGION || 'us-east-1';

// API configuration
const apiBaseUrl = process.env.API_BASE_URL;

// Authentication
const jwtSecretKey = process.env.JWT_SECRET_KEY;
```

### Docker Compose Examples

#### ✅ CORRECT docker-compose.yml:
```yaml
environment:
  - S3_BUCKET_NAME=${S3_BUCKET_NAME}
  - API_BASE_URL=${API_BASE_URL}
  - DATABASE_URL=${DATABASE_URL}
  - JWT_SECRET_KEY=${JWT_SECRET_KEY}
```

---

## 🔍 Validation and Enforcement

### Manual Validation
Before deploying, verify all environment variables use standard names:

```bash
# Check for deprecated variable usage
grep -r "IMAGE_BUCKET\|IMAGES_BUCKET" --include="*.py" --include="*.ts" --include="*.js" .
grep -r "API_URL\|BACKEND_URL" --include="*.py" --include="*.ts" --include="*.js" .
grep -r "DB_HOST\|DB_PORT\|DB_NAME" --include="*.py" --include="*.ts" --include="*.js" .
grep -r "JWT_SECRET[^_]" --include="*.py" --include="*.ts" --include="*.js" .
```

### Automated Validation
The lint command validates environment variable names:

```bash
# Run environment variable validation
just lint

# This will fail if deprecated variable names are found
```

---

## 🛠️ Migration Guide

### Updating Existing Code

1. **Find deprecated usage:**
```bash
grep -r "IMAGE_BUCKET" --include="*.py" .
```

2. **Replace with standard names:**
```bash
# Replace deprecated names with standard names
sed -i 's/IMAGE_BUCKET/S3_BUCKET_NAME/g' **/*.py
sed -i 's/API_URL/API_BASE_URL/g' **/*.ts
sed -i 's/DB_HOST/DATABASE_HOST/g' **/*.py
```

3. **Update environment files:**
```bash
# Update .env files
sed -i 's/IMAGE_BUCKET=/S3_BUCKET_NAME=/g' .env*
sed -i 's/API_URL=/API_BASE_URL=/g' .env*
```

4. **Verify changes:**
```bash
just lint
just test unit all
```

---

## 📚 Related Documentation

### Environment Setup
- **[Environment Configuration](./environment-configuration.md)** - Complete environment setup guide
- **[Development Setup](./development-setup.md)** - Local development configuration

### Troubleshooting
- **[Variable Name Mismatches](../gotchas/variable-name-mismatches.md)** - Common naming issues and solutions
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General troubleshooting procedures

### Architecture
- **[System Architecture](../architecture/system-architecture.md)** - Overall system design
- **[Security Architecture](../architecture/security-architecture.md)** - Security configuration patterns

---

**Status**: ✅ **AUTHORITATIVE REFERENCE**
**Last Updated**: 2025-06-29
**Scope**: Environment Variable Standards, Configuration Consistency
**Enforcement**: Automated via `just lint` command

---

*This document is the single source of truth for environment variable naming in the Spacewalker platform. All services, documentation, and infrastructure must use these standard names to ensure consistent configuration and prevent deployment failures.*
