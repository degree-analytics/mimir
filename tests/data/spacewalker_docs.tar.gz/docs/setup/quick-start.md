# ⚡ Spacewalker Quick Start Guide

## Purpose
Rapid setup guide to get Spacewalker running in minutes using intelligent automation and professional-grade workflows. Perfect for developers who want to start quickly and efficiently.

## When to Use This
- Quick setup when you want to start development immediately
- Demonstrating Spacewalker to stakeholders or new team members
- Setting up development environment for testing or experimentation
- Learning the development workflow and available commands
- Keywords: quick start, rapid setup, development workflow, automation, demo

**Version:** 2.0 (Updated for new documentation structure)
**Date:** 2025-06-29
**Status:** Current - Rapid Setup Guide

---

## 🎯 What You'll Achieve

By the end of this guide, you'll have:
- ✅ A fully configured development environment
- ✅ All services running (Backend API, Admin Dashboard, Mobile App)
- ✅ Tests passing to verify everything works
- ✅ Mobile app connected to your local backend

**Estimated time**: 5-8 minutes for complete setup

---

## 📋 Prerequisites (First Time Only)

### System Requirements

⚠️ **IMPORTANT: Apple Silicon Mac Required**
- This setup is optimized for **Apple Silicon Macs (M1/M2/M3)**
- Intel Mac users: This ECR-based setup will NOT work for you - use legacy local builds

### First Time Setup

If this is your first time setting up Spacewalker:

```bash
# Run our bootstrap script to install minimal prerequisites
./scripts/bootstrap.sh
```

This installs the tools needed for our helper scripts (uv, PyYAML, python-dotenv).

## 🚀 Quick Setup

### Automated Setup (Recommended)

Run these commands in sequence for a complete setup:

```bash
# 1. Bootstrap and check environment
just bootstrap

# 2. Install all dependencies and configure environment
just install && just env_setup

# 3. Start all services
just service up
```

This sequence:
- 🔍 **Validates** your environment (Python, Node.js, Docker, AWS CLI, GitHub CLI, etc.)
- 📦 **Installs** all dependencies intelligently
- 🔧 **Configures** mobile IP automatically
- 🐳 **Starts** all services with health checks
- 🔐 **Checks** for required credentials and API keys

### Manual Step-by-Step

If you prefer manual control:

```bash
# 1. Check your environment
just env_check

# 2. Install dependencies
just service install all

# 3. Configure mobile networking
just expo ip auto

# 4. Start all services
just up

# 5. Create demo data (users, buildings, etc.) - SAFE method
just db seed

# 6. Verify everything works
just health && just test unit all
```

**For More Detail:** See the [Complete Getting Started Guide](../setup/getting-started.md) for comprehensive setup instructions.

---

## 📱 Mobile App Connection

Once setup is complete, connect your mobile device:

### iPhone/iOS
1. **Open Safari** on your iPhone
2. **Navigate to**: `exp://YOUR_IP:8081`
   - Your IP is displayed by `just info` or during `just expo ip auto`
   - Example: `exp://192.168.1.100:8081`
3. **Verify connection**: Look for "Connected to: http://YOUR_IP:8000" at bottom of login screen

### Android
1. **Install Expo Go** from Google Play Store
2. **Scan QR code** shown by `just expo start --offline` command
3. **Verify connection**: Check backend URL in app settings

### Demo Credentials

After running `just db seed` to create demo data, you can login with:
- **Admin**: `admin@demo.university.edu` / `demo123`
- **Surveyor**: `surveyor1@demo.university.edu` / `demo123`
- **Manager**: `manager@demo.university.edu` / `demo123`
- **Platform Admin**: `dev@spacewalker.ai` / `dev123`

**Note**: These users are only created after running `just db seed` (safe method) or during the automated `just workflow_setup`. The safe seeding method preserves data from other tenants.

---

## 🧪 Verify Everything Works

### Quick Health Check
```bash
just health                    # Service health overview
```

### Run Tests
```bash
just dev_cycle                 # Fast: unit tests + linting (30-60 sec)
just dev_cycle_full            # Comprehensive: all tests + security (2-3 min)
just test all all              # Complete: all tests + coverage (5-8 min)
```

### Verify Security Scanning
```bash
just lint astgrep              # Security scanning with ast-grep (~2 sec)
ast-grep --version             # Verify ast-grep installation
```

### Check Service Status
```bash
just status                    # Complete environment status
just docker_status             # Detailed Docker information
```

**Detailed Testing:** See the [Testing Guide](../workflows/testing-guide.md) for comprehensive testing workflows.

---

## 🎨 Development Workflow

### Daily Development Cycle
```bash
# Morning routine
just health                    # Quick health check
just dev_cycle                 # Run tests before starting work

# During development
just dev_cycle                 # After each change (fast feedback)
just dev_cycle_full            # Before committing (comprehensive check)
just logs backend local      # Debug issues

# Before committing
just dev_cycle                 # Validate changes (30-60 sec)
```

### Common Commands

#### Service Management
```bash
just up                        # Start all services
just down                      # Stop all services
just service restart backend # Restart specific service
just logs backend local      # View backend logs
just logs admin local        # View admin logs
just logs mobile local       # View mobile logs
just logs db local           # View database logs
```

#### Testing & Quality
```bash
just test unit all             # Quick unit tests
just test integration all      # Integration tests
just lint                      # Auto-fix code style
just lint astgrep              # Security scanning
just format                    # Format all code
```

#### Database Operations
```bash
just db shell                  # Interactive PostgreSQL shell
just sql "SELECT * FROM users" # Execute SQL queries
just db seed                   # Safely seed demo data (recommended)
just db clean                  # Remove ONLY demo tenant data
just db reset                  # ⚠️  Full reset: clean + init + seed
```

---

## 🔧 Troubleshooting

### Environment Issues
```bash
just env_check                 # Diagnose environment problems
just workflow_setup            # Complete re-setup
```

### Service Problems
```bash
just health                    # Check service status
just docker_status             # Docker diagnostics
just docker_clean && just up   # Clean restart
```

### Mobile Connection Issues
```bash
just expo ip auto              # Reconfigure IP
just info                      # Show current configuration
just expo start --offline      # Restart Expo dev server
```

### Database Issues
```bash
just db verify                 # Check migrations
just db seed                   # Re-seed demo data safely
just db clean                  # Clean only demo data
just db reset                  # Full reset: clean + init + seed
```

### Emergency Recovery
```bash
# Nuclear option: complete reset
just clean && just workflow_setup
```

**Comprehensive Troubleshooting:** See the [Troubleshooting Guide](../workflows/troubleshooting-guide.md) for detailed problem resolution.

---

## 🎯 Next Steps

### For New Developers
- **[Getting Started Guide](../setup/getting-started.md)** - Comprehensive development setup and orientation
- **[ast-grep Onboarding Checklist](../setup/ast-grep-onboarding-checklist.md)** - Security scanning training and exercises
- **[Environment Configuration](../setup/environment-setup.md)** - Detailed variable setup and troubleshooting
- **[Project Structure](../development/project-structure.md)** - Understanding the codebase organization

### For Application Development
- **[Backend Development](../backend/development/README.md)** - FastAPI application development
- **[Admin Architecture](../admin/architecture/README.md)** - Next.js dashboard architecture
- **[Mobile Development](../mobile/development/README.md)** - React Native app development

### For Operations and Deployment
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment procedures
- **[Testing Guide](../workflows/testing-guide.md)** - Comprehensive testing workflows
- **[AI Development Setup](./ai-development-setup.md)** - Claude Code and MCP server configuration

### Key Features to Explore
```bash
just help                      # See all available commands
just workflow_ci               # Full CI pipeline
just workflow_prod_check       # Production validation
```

---

## 💡 Pro Tips

### Command Shortcuts
```bash
just service up all          # Start all services
just service down all        # Stop all services
just status                    # Alias for `just env_status`
just quick_test                # Alias for `just test unit all`
just rebuild                   # Alias for `just docker_rebuild`
```

### Development Efficiency
- Use `just dev_cycle` for fast iteration (30-60 seconds)
- Use `just dev_cycle_full` for comprehensive checks (2-3 minutes)
- Use `just dev_cycle` before committing (30-60 seconds)
- Use `just workflow_ci` for comprehensive validation (8-12 minutes)

### Monitoring & Debugging
- `just health` for quick service overview
- `just docker_status` for detailed Docker info
- `just logs <service> local` for real-time debugging
- `just env_check` for environment validation

---

## 🚀 You're Ready!

Congratulations! You now have:

✅ **Spacewalker running locally** with all services
✅ **Mobile app connected** to your development backend
✅ **Professional workflows** for efficient development
✅ **Intelligent automation** that handles complexity for you

**Start building amazing software** with Spacewalker's modern development platform! 🎉

---

## Application Access Points

### Admin Dashboard
- **URL**: http://localhost:3000
- **Documentation**: [Admin Architecture Guide](../admin/architecture/README.md)

### Backend API
- **URL**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/api/health
- **Documentation**: [Backend Development Guide](../backend/development/README.md)

### Mobile App
- **Expo URL**: exp://YOUR_IP:8081
- **Development**: `just up local` or `just expo start --offline`
- **Documentation**: [Mobile Development Guide](../mobile/development/README.md)

---

## Related Documentation

- **[Getting Started Guide](../setup/getting-started.md)** - Comprehensive setup and orientation
- **[Development Workflows](./README.md)** - Main system overview and navigation
- **[Environment Configuration](../setup/environment-setup.md)** - Variable setup and configuration
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment procedures
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Problem resolution workflows

---

## 📞 Getting Help

- **Command Help**: `just help` or `just --list`
- **Environment Issues**: Run `just env_check` for diagnostics
- **Service Status**: Use `just health` for quick overview
- **Detailed Troubleshooting**: See [Troubleshooting Guide](../workflows/troubleshooting-guide.md)

**Happy coding!** 🚀

---
**Status**: ✅ Updated and current as of 2025-06-29. Reorganized for improved navigation and enhanced with comprehensive cross-references to new documentation structure.
