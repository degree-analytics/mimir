# AI Development Environment Setup

## Purpose
Comprehensive guide for setting up an AI-enhanced development workflow using Claude Code, MCP servers, and integrated development tools to maximize productivity and consistency.

## When to Use This
- Setting up AI-enhanced development environment
- Configuring Claude Code with MCP server integrations
- Standardizing development workflows and tool usage
- Keywords: AI development, Claude Code, MCP servers, development workflow, tool integration

**Version:** 4.0 (Current Iteration)
**Date:** 2025-06-28
**Status:** Active - Standardized Approach

---

## Current Philosophy & Approach

This represents the 4th major iteration of an AI-enhanced development workflow, settled on a philosophy that works: **"Keep it lean on the robot side, feed it the right context at the right time."**

After countless hours of experimentation, tool switching, and debugging sessions, this setup has been refined with the goal of standardizing the approach moving forward.

### Core Principles
1. **Claude Code (CC) as both brain and hands** - Primary driver for planning AND implementation
2. **Cursor as the deep-dive tool** - When you need to get in and do focused code work
3. **Context is king** - The right information at the right time beats any amount of AI sophistication
4. **Standardize everything** - Commands, patterns, documentation structure - consistency reduces cognitive load

## Prerequisites

### Required for Full Capabilities
- **Claude Code Pro Max** subscription (professional plan)
- Node.js and npm for MCP server management
- Git for version control
- Just command runner installed
- Basic understanding of Model Context Protocol (MCP)

### Claude Code Pro Max Features
The professional plan enables:
- Multiple MCP server connections
- Extended context windows
- Priority processing
- Advanced features like Projects
- Enhanced tool integrations

## Primary Tools

### Claude Code (CC) - Brain AND Hands
- **Role**: Main driver for ALL development work - both planning and implementation
- **Capabilities**: Handles architecture decisions, writes code, manages workflow
- **Integration**: Connected to multiple MCP servers for enhanced capabilities
- **Usage**: Does 80%+ of the actual development work

### Cursor - The Deep Dive Tool
- **Role**: Used when you need to "get in and do focused work"
- **Use Cases**: Complex debugging, intricate refactoring, when CC needs assistance
- **Integration**: Has MCP integration but used sparingly
- **Usage**: Maybe 10-20% of actual coding time

## MCP Server Integrations

### 1. Zen MCP Server - Multi-Model AI Collaboration
**Source**: [BeehiveInnovations/zen_mcp](https://github.com/BeehiveInnovations/zen_mcp)
**Purpose**: Enables Claude to collaborate with other AI models for complex decisions

#### Key Commands
- **`precommit`** - Runs pre-commit checks without committing. Catches linting errors, formatting issues
- **`consensus`** - Gets multiple AI models (GPT-4, Claude, Gemini) to review code/decisions and highlights disagreements. Great for critical architectural choices
- **`thinkdeep`** - Triggers deep analysis mode for step-by-step problem solving. Huge benefits for complex debugging
- **`chat`** - Direct conversation with specific models
- **`planner`** - Creates detailed implementation plans with task breakdown
- **`debug`** - Specialized debugging assistance with error analysis
- **`analyze`** - Code quality and performance analysis
- **`refactor`** - Suggests and implements code improvements
- **`testgen`** - Generates comprehensive test suites
- **`secaudit`** - Security vulnerability scanning
- **`docgen`** - Generates documentation from code
- **`codereview`** - Performs thorough code review

**Value**: When hitting tough problems, being able to say "use consensus to review this approach" or "use thinkdeep to figure out why this is failing" provides multiple perspectives and deeper analysis.

### 2. Linear MCP - Project Management
**Sources**:
- [Linear's official MCP implementation](https://linear.app/docs/mcp)
- [Community version](https://github.com/modelcontextprotocol/servers/tree/main/src/linear)

**Features**:
- Pull issue details directly into Claude's context
- Update issue status and comments
- Create new issues from Claude
- Link code changes to tickets

### 3. Playwright MCP - Browser Automation
**Sources**:
- [Microsoft's official version](https://github.com/microsoft/playwright-mcp)
- [ExecuteAutomation's community version](https://github.com/executeautomation/playwright-mcp-server)

**Purpose**: Browser testing and automation directly from Claude

### 4. Notion MCP - Knowledge Base
**Source**: Notion's official hosted MCP service ([documentation](https://developers.notion.com/docs/get-started-with-mcp))
**Endpoint**: `https://mcp.notion.com/mcp` (OAuth-enabled hosted service)

**Setup Process**:
1. **OAuth Authentication**: Complete OAuth flow when first connecting
2. **Workspace Permissions**: Based on your Notion workspace access
3. **AI-Optimized Tools**: Uses "Notion-flavored" Markdown for reduced token consumption

**Features**:
- No manual API token configuration required
- Real-time access to pages, databases, and comments
- Optimized for AI agents with efficient context handling
- Respects user permissions through OAuth scope-based access control

**Purpose**: Read/write to Notion databases and pages with enhanced AI integration

### 5. Task Master AI - Task Management
**Source**: [eyaltoledano/task-master-ai](https://github.com/eyaltoledano/task-master-ai)
**Purpose**: Sophisticated task breakdown and management

**Usage Pattern**: Best for large features needing many subtasks. Create PRD, generate tasks, then use CC to work through them.

### 6. AI Telemetry System - Monitoring & Cost Tracking
**Purpose**: Unified telemetry system for monitoring AI usage, costs, and performance across all AI tools

**Features**:
- **Session correlation** - Track AI usage by developer session and user
- **Token usage monitoring** - Cost analysis across different AI providers
- **Performance tracking** - Duration and success rates for all AI operations
- **Error monitoring** - Automatic failure detection and reporting
- **Pushgateway integration** - Prometheus metrics for monitoring systems

**Integration**: All AI tools (git-info, Mímir, GitHub Actions analyzer) automatically include telemetry tracking.

## Command Standardization Strategy

### The Command Drift Problem

**Common Scenario**:
1. **Every project starts with good intentions** - npm scripts, make commands, shell scripts
2. **Commands evolve differently** - Developer A adds `npm run test-unit`, Developer B adds `make test`, Developer C creates `./scripts/test.sh`
3. **AI gets confused** - When you tell Claude "run tests", which command should it use?
4. **Muscle memory diverges** - Each developer remembers different commands
5. **Documentation lies** - README says one thing, reality is another

**Real Example**: 12-hour debug session caused by:
- Told Claude to "deploy to staging"
- Claude used `npm run deploy:staging` (from old README)
- Actual command was `just deploy staging` (current standard)
- Deployment ran but used wrong environment variables
- Everything looked fine but was actually broken

### The Justfile Solution

```makefile
# One command interface to rule them all
test:          # ALWAYS runs all tests the right way
deploy ENV:    # ALWAYS deploys correctly to any environment
dev:           # ALWAYS starts the dev environment properly
lint:          # ALWAYS runs all linters in the right order
```

**Key Insight**: It's incredibly hard to keep AI looking at the justfile and understanding all available commands. This is why we keep CLAUDE.md minimal - we explicitly tell the AI to check the justfile when it needs to run commands rather than trying to document everything.

## Core Infrastructure Components

### 1. Justfile - Command Central
Every project gets a Justfile. No exceptions. All commands go through `just`.

**Why this matters**: When you tell Claude "run the tests", it should ALWAYS use `just test`, not try to figure out if it's `npm test`, `pytest`, `make test`, or something else.

### 2. CLAUDE.md - Minimal AI Rules
Keep it lean. Only include:
- Critical project-specific patterns
- "Don't touch this" warnings
- Explicit instruction to check justfile for commands
- Links to find detailed documentation

**The key**: Don't try to document everything. Tell the AI WHERE to look when it needs information.

### 3. Smart Documentation Structure
```
docs_new/
├── workflows/         # System-wide processes and guides
├── backend/          # Backend-specific documentation
├── admin/            # Admin dashboard documentation
├── mobile/           # Mobile app documentation
└── gotchas/          # Common issues and troubleshooting
```

## Development Workflow

### 1. Start with Linear
Look at the ticket in Linear to understand what needs to be done.

### 2. Decide on Approach
- **Small/Medium tasks**: Work directly in Claude Code
- **Large features**: Create a PRD in Task Master, generate tasks and subtasks

### 3. Enable Smart Assistance
Either:
- Give CC permission to use Zen MCP tools (`consensus`, `thinkdeep`, etc.)
- Manually invoke Zen tools when hitting complex problems

### 4. Execute with Task Master
- Have CC work from the Task Master task
- Complete implementation
- Update task status in Task Master
- Move to next task
- Repeat until feature complete

### 5. Deep Dives with Cursor
When you need to "get in and do focused work" - complex debugging, performance optimization, or when CC needs help understanding something specific.

### 6. Monitor AI Usage and Costs
The integrated telemetry system automatically tracks:
- **Token usage** across all AI operations for cost analysis
- **Session correlation** to understand AI usage patterns by developer
- **Performance metrics** including operation duration and success rates
- **Error monitoring** for AI tool reliability tracking

**Available AI Tools with Telemetry**:
- `just git-info commit` - Generate commit messages with cost tracking
- `just git-info pr-desc 290` - Generate PR descriptions with usage monitoring
- `just docs ask "question"` - AI documentation queries with cost analysis
- **GitHub Actions analyzer** - Automatic CI/CD failure analysis with telemetry

All metrics are sent to the monitoring system for cost optimization and usage analysis.

## Evolution History

### Iteration 1: "More Tools = Better"
Tried every AI tool available. Chaos ensued.

### Iteration 2: "Cursor Can Do Everything"
Overloaded the IDE. Constant context switching.

### Iteration 3: "Custom Everything"
Built too many custom tools. Maintenance nightmare.

### Iteration 4: "Lean & Focused" (Current)
Right tool for the right job. Clear workflows. Standardized interfaces.

## Known Issues and Solutions

### The Variable Naming Problem (Work in Progress)

**The Problem**: Same resource, different names everywhere:
- Backend calls it `IMAGE_BUCKET`
- Frontend calls it `IMAGES_BUCKET`
- Terraform calls it `image_storage_bucket`
- Docs call it "the S3 bucket for images"

This caused a 12-hour debug session where the AI kept using different names for the same thing.

**The Solution (Coming Soon)**: A shared resource registry that will live in the project root. This will be the single source of truth for all resource names across the entire stack.

### The Documentation Problem
Studies show developers spend 50% of their time looking for information. With AI, this problem gets worse - you need to find the right docs AND format them correctly for the AI. This drove our documentation structure decisions.

## Setup Instructions

### Quick Start Checklist
For new projects:
- [ ] Get Claude Code Pro Max subscription
- [ ] Install MCP server integrations from sources above
- [ ] Create Justfile with ALL project commands
- [ ] Set up minimal CLAUDE.md (under 50 lines)
- [ ] Configure MCP servers in Claude Code
- [ ] Create initial documentation structure
- [ ] Set up Linear integration
- [ ] Run `just init` to verify everything works

### MCP Server Configuration
1. **Install required MCP servers** using npm or direct installation
2. **Configure Claude Code settings** to connect to MCP servers
3. **Test connections** with basic commands
4. **Set up authentication** for integrated services (Linear, Notion, etc.)

#### Notion MCP Setup Steps
The official Notion MCP uses OAuth authentication, making setup much simpler than legacy implementations:

1. **Add Notion MCP Server**:
   ```bash
   just mcp add notion
   ```

2. **Restart Claude Code** to activate the server

3. **First Authentication**: 
   - Make your first Notion query (e.g., "Show me my Notion pages")
   - Claude will prompt for OAuth authentication
   - You'll be redirected to Notion to grant permissions

4. **Grant Workspace Permissions**:
   - Select which Notion workspace(s) to connect
   - Choose specific pages/databases or grant full workspace access
   - Permissions can be modified later in Notion settings

5. **Verify Connection**:
   ```bash
   just mcp list
   # Should show "notion: ✓ Connected" status
   ```

**Troubleshooting OAuth**:

**Common Issues & Solutions**:
- **"Authentication failed"** → Ensure you're logged into the correct Notion workspace before starting OAuth flow
- **"Insufficient permissions"** → Check that you have admin or content permissions in the target workspace
- **"OAuth timeout"** → Clear browser cookies for `notion.com` and `mcp.notion.com`, then retry
- **"Workspace not found"** → Verify workspace URL matches your active Notion workspace
- **"Connection refused"** → Check that `https://mcp.notion.com/mcp` is accessible (not behind corporate firewall)

**Step-by-Step Recovery Process**:
1. **Reset Authentication**: Clear all Notion-related cookies and localStorage
2. **Verify Account Access**: Log into Notion web interface to confirm workspace access
3. **Check Permissions**: Ensure you can create/edit pages in the workspace you're trying to connect
4. **Retry Connection**: Make a fresh Notion query to trigger new OAuth flow
5. **Test Basic Access**: Try reading a simple page before attempting complex operations

**Advanced Troubleshooting**:
- **Multiple Workspaces**: If you belong to multiple Notion workspaces, explicitly select the correct one during OAuth
- **Corporate Networks**: OAuth may fail behind strict firewalls - test from personal network if possible
- **Browser Issues**: Try OAuth flow in incognito/private browsing mode to rule out extension conflicts
- **Permission Changes**: If access suddenly stops working, check if workspace admin changed your permissions

**Error Message Reference**:
- `"invalid_grant"` → OAuth token expired, need to re-authenticate
- `"access_denied"` → User declined permission or insufficient workspace access
- `"invalid_client"` → MCP server configuration issue, verify endpoint URL
- `"server_error"` → Temporary Notion API issue, wait 5-10 minutes and retry

### Environment Variables
```bash
# AI service integration
export LINEAR_API_KEY="your-linear-api-key"
# Note: Notion MCP uses OAuth - no manual API key needed
export CLAUDE_MCP_SERVERS="zen,linear,playwright,notion,taskmaster"

# AI telemetry system (monitoring & cost tracking)
export PUSHGATEWAY_URL="http://monitoring.spacewalker.littleponies.com:9091"
export DISABLE_AI_TELEMETRY="false"  # Set to "true" to disable telemetry
export CLAUDE_SESSION_ID="auto"      # Usually auto-detected, can override

# AI provider API keys (for telemetry-enabled tools)
export ANTHROPIC_API_KEY="your-anthropic-key"  # git-info, Mímir
export OPENROUTER_API_KEY="your-openrouter-key"  # GitHub Actions analyzer
```

## Best Practices

### Command Consistency
- Always use `just` for project commands
- Document new commands immediately in justfile
- Avoid ad-hoc scripts that bypass the standard interface

### Context Management
- Keep CLAUDE.md minimal and focused
- Use documentation links rather than embedding everything
- Provide specific paths to relevant information

### Tool Selection Criteria
Before adding a new tool, ask:
1. Does it solve a real problem we're experiencing?
2. Does it integrate well with our existing workflow?
3. Will it add more value than complexity?
4. Can we standardize its usage across projects?

## Future Considerations

As of June 2025, committed to this setup for standardization, but keeping an eye on:

1. **Shared Resource Registry** - Critical problem that needs solving
2. **Documentation Patterns** - Still evolving the optimal structure
3. **Task Master vs CC Planner Balance** - Finding the sweet spot
4. **New Tool Criteria** - What makes a tool worth adding?

## Troubleshooting

### Common MCP Connection Issues
- **Server not responding**: Check MCP server status and restart if needed
- **Authentication failures**: Verify API keys and permissions
- **Tool commands not working**: Ensure latest MCP server versions installed

### Performance Optimization
- **Slow responses**: Check context window size and reduce if necessary
- **Memory issues**: Restart Claude Code sessions periodically
- **Tool conflicts**: Disable unused MCP servers to reduce overhead

## Related Documentation

### AI System Documentation
- **[AI Telemetry System](../development/ai-telemetry-system.md)** - Complete telemetry integration guide for monitoring teams ⭐ NEW
- **[Helpers Directory Structure](../development/helpers-directory-structure.md)** - AI tool organization and architecture

### Development Workflows
- [Getting Started Guide](../setup/getting-started.md) - Basic project setup
- [Development Workflows](./README.md) - General development processes
- [Project Structure](../development/project-structure.md) - Codebase organization
- [Troubleshooting Guide](../workflows/troubleshooting-guide.md) - Problem resolution

---

**Final Thoughts**: This setup isn't perfect, but it's the result of hundreds of hours of real-world usage. The key insight: AI tools are multipliers, not magic. Give them the right context, consistent interfaces, and clear boundaries, and they'll amplify your productivity. Try to make them do everything, and you'll spend more time fighting the tools than building your product.

**Remember**: Keep it lean on the robot side, feed it the right context at the right time.

---
**Status**: Standardized approach as of June 2025
**Iteration**: 4th major version
**Last Updated**: 2025-06-28
