# Environment Configuration Workflows

## Purpose
Comprehensive environment configuration documentation for the Spacewalker system across all deployment scenarios, including local development, staging, and production environments. Essential reference for DevOps teams, backend developers, and infrastructure engineers managing multi-environment deployments with proper security and tenant isolation.

## When to Use This
- Setting up local development environments with proper configuration
- Deploying to staging and production environments using AWS infrastructure
- Configuring environment variables and secrets management
- Troubleshooting environment-specific deployment issues
- Implementing secure multi-tenant infrastructure configuration
- Keywords: environment configuration, deployment workflows, AWS infrastructure, secrets management, multi-environment setup

**Version:** 2.3 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production Environment Configuration

---

## 🌍 Configuration Strategy Overview

Spacewalker implements a comprehensive multi-layer configuration approach designed to provide flexibility in development while maintaining security and consistency across all deployment environments.

### Configuration Principles
- **Local Development** - Environment variables with sensible fallbacks for developer productivity
- **Production Deployment** - AWS Secrets Manager for sensitive data with environment variables for non-sensitive configuration
- **Container Orchestration** - ECS with proper IAM roles and complete tenant isolation
- **Infrastructure as Code** - Consistent configuration management across all environments

### Environment Architecture
```
Local Development → Docker Compose → Environment Variables → Local Storage/MinIO
        ↓                ↓                    ↓                    ↓
Staging Environment → ECS Tasks → Secrets Manager → S3 Storage
        ↓                ↓                    ↓                    ↓
Production Environment → ECS Tasks → Secrets Manager → S3 Storage
```

---

## 🔧 Core Environment Variables

### AWS Environment Configuration

| Environment | AWS Account | AWS Region | AWS Profile | Domain |
|-------------|-------------|------------|-------------|---------|
| Development | 881490112168 | us-east-2 | default | spacewalker.littleponies.com |
| Production | 352676346183 | us-east-1 | production | spacewalker.degreeanalytics.com |

### Backend Service Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DATABASE_URL` | Yes | - | PostgreSQL connection string for data persistence |
| `JWT_SECRET_KEY` | Yes | - | Secret key for JWT token signing and validation |
| `UNSUBSCRIBE_SECRET_KEY` | Yes | - | Secret key for generating email unsubscribe tokens. Generate with: `openssl rand -hex 32` |
| `PYTHONPATH` | No | `/app/src` | Python module search path for application code |
| `LOAD_DEMO_DATA` | No | `true` (dev), `false` (prod) | Whether to load demo data on service startup |
| `AWS_REGION` | No | Auto-detected | AWS region (us-east-2 for dev, us-east-1 for prod) |
| `AWS_PROFILE` | No | Auto-detected | AWS profile (default for dev, production for prod) |

### SSH and Bastion Access Configuration

| Component | Development | Production |
|-----------|-------------|------------|
| SSH Key Location | `~/.ssh/dev-spacewalker-key.pem` | `~/.ssh/prod-spacewalker-key.pem` |
| Key Name in AWS | dev-spacewalker-key | prod-spacewalker-key |
| Bastion Security Group | Dynamic IP management | Dynamic IP management |
| Access Control | No production safety required | Requires `just prod enable` |

### Storage and File Management Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `S3_BUCKET_NAME` | No | `local-spacewalker-photos` | S3 bucket for photo and file storage |
| `S3_REGION` | No | `us-east-1` | AWS region for S3 operations and resources |
| `S3_ENDPOINT_URL` | No | - | Custom endpoint for MinIO (local development only) |
| `AWS_ACCESS_KEY_ID` | No | - | AWS access key (local development only) |
| `AWS_SECRET_ACCESS_KEY` | No | - | AWS secret key (local development only) |
| `STORAGE_PROVIDER` | No | `local` (dev), `s3` (prod) | Storage backend (`local` or `s3`) |
| `STORAGE_VALIDATION_ENABLED` | No | `true` | Enable storage validation middleware |
| `AWS_SECRETS_NAME` | No | `{env}/spacewalker/api-keys` | Secrets Manager secret name pattern |

### External API Integration Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `GEMINI_API_KEY` | No | - | Google Gemini API key for AI image analysis |
| `POSTHOG_API_KEY` | No | - | PostHog analytics API key for product analytics |
| `POSTHOG_HOST` | No | `https://us.posthog.com` | PostHog API endpoint (US or EU instance) |
| `POSTHOG_ENABLED` | No | `false` (dev), `true` (prod) | Enable PostHog analytics tracking |

---

## 🐳 Local Development Configuration

### Docker Compose Environment Setup

**Configuration File**: `docker-compose.yml`

```yaml
# Local Development Environment Variables
environment:
  # Core Backend Configuration
  - DATABASE_URL=${DATABASE_URL}
  - JWT_SECRET_KEY=${JWT_SECRET_KEY}
  - PYTHONPATH=/app/src
  - LOAD_DEMO_DATA=true

  # Storage and File Management
  - S3_BUCKET_NAME=${S3_BUCKET_NAME:-local-spacewalker-photos}
  - S3_REGION=${S3_REGION:-us-east-1}
  - S3_ENDPOINT_URL=${S3_ENDPOINT_URL:-}  # For MinIO simulation
  - AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID:-}
  - AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY:-}
  - GEMINI_API_KEY=${GEMINI_API_KEY:-}  # Local development fallback
  - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY:-}  # PR analysis tools
  - STORAGE_PROVIDER=${STORAGE_PROVIDER:-local}
  - STORAGE_VALIDATION_ENABLED=${STORAGE_VALIDATION_ENABLED:-true}
  - AWS_SECRETS_NAME=${AWS_SECRETS_NAME:-dev/spacewalker/api-keys}
```

### Local Development Storage Options

#### Option 1: Local File Storage (Default)
```bash
# .env file configuration
STORAGE_PROVIDER=local
GEMINI_API_KEY=your-api-key-here
ANTHROPIC_API_KEY=your-anthropic-key-here  # For PR analysis tools

# Benefits:
# - No cloud dependencies required
# - Fast file operations
# - Simplified development setup
# - Perfect for offline development
```

#### Option 2: S3 Development Environment
```bash
# .env file configuration
STORAGE_PROVIDER=s3
S3_BUCKET_NAME=your-dev-bucket
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
GEMINI_API_KEY=your-api-key-here
ANTHROPIC_API_KEY=your-anthropic-key-here  # For PR analysis tools

# Benefits:
# - Production-like storage behavior
# - Cloud integration testing
# - Shared development assets
# - Multi-developer file sharing
```

#### Option 3: MinIO Local Simulation
```bash
# .env file configuration
STORAGE_PROVIDER=s3
S3_BUCKET_NAME=spacewalker-local
S3_ENDPOINT_URL=http://localhost:9000
AWS_ACCESS_KEY_ID=minioadmin
AWS_SECRET_ACCESS_KEY=minioadmin

# Benefits:
# - S3-compatible local storage
# - No cloud costs during development
# - Production-like API behavior
# - Container-based storage simulation
```

---

## ☁️ Production Environment Configuration

### AWS ECS Deployment Configuration

**Configuration File**: `sam/ecs/backend.yaml`

#### Environment Variables for Production
```yaml
Environment:
  - Name: ENVIRONMENT
    Value: !Ref Environment
  - Name: PORT
    Value: "8000"
  - Name: LOAD_DEMO_DATA
    Value: !If [IsDevelopment, "true", "false"]

  # S3 Storage Configuration
  - Name: S3_BUCKET_NAME
    Value: !Sub '${Environment}-spacewalker-photos-${AWS::AccountId}'
  - Name: S3_REGION
    Value: !Ref AWS::Region
  - Name: STORAGE_PROVIDER
    Value: "s3"
  - Name: STORAGE_VALIDATION_ENABLED
    Value: "true"
  - Name: AWS_SECRETS_NAME
    Value: !Sub '${Environment}/spacewalker/api-keys'
```

#### Secrets Management (AWS Secrets Manager)
```yaml
Secrets:
  # Database Connection Secrets
  - Name: DATABASE_HOST
    ValueFrom: !Sub '${DbSecretArn}:URL::'
  - Name: DATABASE_PASSWORD
    ValueFrom: !Sub '${DbSecretArn}:password::'

  # External API Keys from Secrets Manager
  - Name: GEMINI_API_KEY
    ValueFrom: !Sub '${StorageSecretsArn}:GEMINI_API_KEY::'
```

---

## 🔐 AWS IAM Security Configuration

### ECS Task Role Permissions

#### S3 Storage Access Permissions
```json
{
  "Effect": "Allow",
  "Action": [
    "s3:GetObject",
    "s3:PutObject",
    "s3:DeleteObject",
    "s3:GetObjectVersion"
  ],
  "Resource": "arn:aws:s3:::${Environment}-spacewalker-photos-${AccountId}/tenant_*/*"
}
```

#### Secrets Manager Access Permissions
```json
{
  "Effect": "Allow",
  "Action": [
    "secretsmanager:GetSecretValue",
    "secretsmanager:DescribeSecret"
  ],
  "Resource": "arn:aws:secretsmanager:${Region}:${AccountId}:secret:${Environment}/spacewalker/api-keys*"
}
```

### Multi-Tenant Security Features
- **Tenant Isolation** - All S3 objects use `tenant_*/*` prefix for complete data separation
- **Least Privilege IAM** - Task roles limited to specific resources and tenant prefixes
- **Network Security** - ECS tasks deployed in private subnets with controlled access
- **Storage Validation** - All file uploads validated for security and tenant compliance

---

## 🗂️ AWS Secrets Manager Configuration

### Secret Naming Patterns
- **Development Environment**: `dev/spacewalker/api-keys`
- **Staging Environment**: `staging/spacewalker/api-keys`
- **Production Environment**: `prod/spacewalker/api-keys`

### Secret Value Structure (JSON)
```json
{
  "GEMINI_API_KEY": "actual-gemini-api-key-value",
  "OTHER_API_KEY": "placeholder-for-future-integrations",
  "THIRD_PARTY_SECRET": "additional-api-keys-as-needed"
}
```

### Secrets Management Best Practices
- **Rotation Strategy** - Regular rotation of API keys and sensitive credentials
- **Access Logging** - All secret access logged for security auditing
- **Environment Separation** - Separate secrets for each environment with no cross-access
- **Principle of Least Privilege** - Secrets accessible only to services that require them

### Slack Webhook Configuration (Monitoring)

For monitoring and alerting integration, Slack webhooks are stored in separate secrets:

**Secret Names:**
- **Development**: `dev/spacewalker/slack-webhook`
- **Production**: `prod/spacewalker/slack-webhook`

**Secret Structure:**
```json
{
  "webhook_url": "https://hooks.slack.com/services/T2NT6RK6X/B094U5KPV2N/..."
}
```

**Important Notes:**
- Use `webhook_url` (lowercase with underscore), not `WEBHOOK_URL`
- Each environment should use separate Slack channels:
  - Development: `#spacewalker-dev-alerts`
  - Production: `#spacewalker-prod-alerts`
- Webhooks are consumed by Lambda functions in the monitoring stack

**Management Commands:**
```bash
# Create Slack webhook secret
just secrets_create_slack [env] [webhook_url]

# Test Slack integration
just monitor slack-test [env]

# Validate monitoring setup
just monitor validate [env]
```

---

## ⚠️ Migration Notes for Existing Deployments

### Breaking Change: UNSUBSCRIBE_SECRET_KEY Required (Added 2025-08-06)

**CRITICAL**: The email service now requires the `UNSUBSCRIBE_SECRET_KEY` environment variable to be set. This is a security enhancement to properly secure email unsubscribe tokens.

**Required Actions for Existing Deployments:**

1. **Generate a secure secret key:**
   ```bash
   openssl rand -hex 32
   ```

2. **Add to environment configuration:**
   - **Local Development**: Add to `.env` file
   - **ECS Deployments**: Add to task definition environment variables
   - **Docker Compose**: Add to `docker-compose.yml` environment section

3. **Example configuration:**
   ```bash
   # .env file
   UNSUBSCRIBE_SECRET_KEY=your-generated-64-character-hex-string
   ```

**Impact if not configured:**
- Email sending will fail with error: "UNSUBSCRIBE_SECRET_KEY environment variable is required"
- This affects all invitation emails and other email functionality

**Timeline:**
- This change was introduced in commit 759015bd
- All deployments must be updated before deploying this version

---

## 🏗️ Infrastructure Dependencies

### Required AWS Resources

Before deploying the Spacewalker system, ensure the following AWS resources exist:

1. **S3 Storage Bucket**
   - **Name Pattern**: `${Environment}-spacewalker-photos-${AWS::AccountId}`
   - **Purpose**: Secure file storage with tenant isolation
   - **Configuration**: Versioning enabled, encryption at rest

2. **AWS Secrets Manager**
   - **Secret Name**: `${Environment}/spacewalker/api-keys`
   - **Purpose**: Secure storage of API keys and sensitive configuration
   - **Access**: Limited to ECS task roles only

3. **SSL Certificates**
   - **Development**: Wildcard certificate `*.spacewalker.littleponies.com` (managed by DNS stack)
   - **Production**: Wildcard certificate `*.spacewalker.degreeanalytics.com` (external, hardcoded ARN)
   - **Purpose**: HTTPS termination at Application Load Balancer level

4. **IAM Roles and Policies**
   - **ECS Task Execution Role**: For container startup and secrets access
   - **ECS Task Runtime Role**: For S3 and Secrets Manager operations
   - **Tenant-Specific Policies**: For multi-tenant data isolation

5. **VPC and Networking**
   - **Private Subnets**: For ECS task deployment
   - **Security Groups**: Controlled access between services
   - **NAT Gateways**: For external API access from private subnets

### Infrastructure Deployment Order
```bash
# 1. Deploy core infrastructure (VPC, subnets, security groups)
just aws_deploy_infrastructure --environment production

# 2. Deploy storage and secrets resources
just aws_deploy_storage --environment production

# 3. Deploy application services
just aws_deploy_backend --environment production

# 4. Verify deployment and configuration
just aws_status production
```

---

## ✅ Deployment Verification Workflows

### Health Check Endpoints

| Endpoint | Purpose | Expected Response |
|----------|---------|-------------------|
| `GET /api/storage/healthcheck` | Storage system verification | `200 OK` with storage status |
| `GET /health/` | Backend service health | `200 OK` with service status |
| `GET /health/db` | Database connectivity | `200 OK` with database status |

### Configuration Validation Commands

```bash
# Verify environment variables in running container
just ecs env backend dev

# Check secrets access and configuration loading
just aws_logs_service dev backend 2 | grep -i "secret\|config"

# Test storage operations and file upload capability
curl -X POST https://api-dev.spacewalker.com/api/storage/presigned-url \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"filename": "test.jpg"}'

# Validate multi-tenant isolation
just aws_test_tenant_isolation dev
```

### End-to-End Verification Workflow
```bash
# Complete deployment verification
just aws_verify_deployment production

# This comprehensive check:
# 1. Verifies all health endpoints respond correctly
# 2. Tests storage upload/download operations
# 3. Validates secrets access and API key functionality
# 4. Confirms multi-tenant isolation is working
# 5. Checks all external API integrations
```

---

## 🗄️ Database Access Configuration

### SSH Key Setup for Database Access

**Critical Setup Requirement (Enhanced 2025-07-03):**
Database access requires proper SSH key configuration for secure bastion host connectivity:

#### SSH Key Installation
```bash
# Download SSH keys from AWS EC2 console or team lead
# Keys must be environment-specific for security isolation

# Development environment
chmod 400 ~/.ssh/dev-spacewalker-key.pem

# Staging environment (if applicable)
chmod 400 ~/.ssh/staging-spacewalker-key.pem

# Production environment (restricted access)
chmod 400 ~/.ssh/prod-spacewalker-key.pem
```

#### Environment-Specific Known Hosts

**Security Enhancement:** Environment-specific known_hosts files prevent cross-environment attacks:

```bash
# Create environment-specific known_hosts files
touch ~/.ssh/known_hosts.dev
touch ~/.ssh/known_hosts.staging
touch ~/.ssh/known_hosts.prod

# Set appropriate permissions
chmod 644 ~/.ssh/known_hosts.*
```

**Security Benefits:**
- **Environment Isolation**: Prevents accidental connections to wrong environment
- **Host Key Verification**: Protects against man-in-the-middle attacks
- **Key Rotation Support**: Enables secure host key updates per environment

### Database Access Validation

#### Prerequisites Validation
```bash
# Verify all database access requirements
just db_test dev        # Full validation with connectivity test
just db_test_quick dev  # Quick validation (AWS + SSH keys only)
```

#### Required AWS Permissions
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "secretsmanager:GetSecretValue"
            ],
            "Resource": "arn:aws:secretsmanager:region:account:secret:AURORA/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "cloudformation:DescribeStacks"
            ],
            "Resource": "arn:aws:cloudformation:region:account:stack/*-spacewalker-foundation/*"
        }
    ]
}
```

### Database Configuration Secrets

#### Secret Structure (AWS Secrets Manager)
```json
{
    "username": "spacewalker_user",
    "password": "secure-generated-password",
    "host": "dev-spacewalker-db.region.rds.amazonaws.com",
    "port": 5432,
    "dbname": "spacewalker"
}
```

#### Secret Naming Convention
- **Development**: `AURORA/dev-spacewalker`
- **Staging**: `AURORA/staging-spacewalker`
- **Production**: `AURORA/prod-spacewalker`

### SSH Security Configuration

#### Enhanced Security Features (2025-07-03)
```bash
# Secure SSH configuration used by database helper
SSH_OPTIONS=(
    -o StrictHostKeyChecking=accept-new
    -o UserKnownHostsFile=~/.ssh/known_hosts.${ENVIRONMENT}
    -i ~/.ssh/${ENVIRONMENT}-spacewalker-key.pem
)
```

**Security Improvements:**
- **Host Key Verification**: Replaced insecure `StrictHostKeyChecking=no`
- **Environment Isolation**: Separate known_hosts files per environment
- **Input Validation**: Port range validation (1024-65535)
- **Credential Caching**: Secure session-based credential caching

---

## 🔍 Troubleshooting Common Issues

### S3 Storage Access Problems

#### Issue: S3 Access Denied Errors
```bash
# Diagnosis commands
aws s3 ls s3://production-spacewalker-photos-123456789/tenant_demo/
just aws_logs_service production backend 5 | grep -i "s3\|access"

# Common solutions:
# 1. Check IAM permissions for tenant prefix access
# 2. Verify bucket policy allows ECS task role
# 3. Ensure S3_BUCKET_NAME matches actual bucket name
# 4. Validate AWS region configuration
```

#### Issue: MinIO Connection Failures (Local Development)
```bash
# Check MinIO service status
docker-compose ps minio
docker-compose logs minio

# Verify endpoint configuration
curl http://localhost:9000/minio/health/live

# Reset MinIO data if needed
docker-compose down -v
docker-compose up minio
```

### Secrets Manager Access Issues

#### Issue: Secrets Access Failed
```bash
# Check IAM permissions for Secrets Manager
aws iam get-role-policy --role-name ECSTaskRole --policy-name SecretsManagerAccess

# Verify secret exists and is accessible
aws secretsmanager get-secret-value --secret-id dev/spacewalker/api-keys

# Check ECS task logs for secrets loading
just aws_logs_service dev backend 5 | grep -i "secret\|credential"
```

#### Issue: API Key Configuration Problems
```bash
# Validate Gemini API key functionality
curl -X POST https://api-dev.spacewalker.com/api/surveys/analyze \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"image_url": "test-image.jpg"}'

# Check API key format and permissions in secrets
aws secretsmanager get-secret-value --secret-id dev/spacewalker/api-keys \
  --query SecretString --output text | jq '.GEMINI_API_KEY'
```

### Database Connection Issues

#### Issue: Database Connection Failures
```bash
# Test database connectivity directly
just aws_task_exec dev backend "python -c 'from src.database import engine; print(engine.url)'"

# Check database credentials and connection string
just aws_logs_service dev backend 5 | grep -i "database\|connection"

# Verify database security group allows ECS access
aws ec2 describe-security-groups --group-ids sg-database-access
```

### Development Environment Issues

#### Issue: Local Storage Permission Problems
```bash
# Check local storage directory permissions
ls -la ./local_storage/
sudo chown -R $(whoami):$(whoami) ./local_storage/

# Verify STORAGE_PROVIDER configuration
grep STORAGE_PROVIDER .env
docker-compose exec backend env | grep STORAGE
```

### Advanced Debugging Commands

```bash
# Comprehensive environment status check
just aws_status dev

# Deep dive into backend service logs
just aws_logs_service dev backend 10

# Check environment variables in running tasks
just ecs env backend dev

# Test complete storage configuration
just aws debug dev

# Validate multi-tenant isolation
just aws_test_isolation dev

# Check external API connectivity
just aws_test_external_apis dev
```

---

## 🛡️ Security Best Practices

### Configuration Security
- **No Hardcoded Secrets** - All sensitive values stored in AWS Secrets Manager or environment variables
- **Environment Separation** - Complete isolation between development, staging, and production configurations
- **Least Privilege Access** - IAM roles limited to minimum required permissions
- **Audit Logging** - All configuration access and changes logged for security review

### Tenant Isolation Security
- **S3 Prefix Enforcement** - All file operations restricted to tenant-specific prefixes
- **Database Row-Level Security** - PostgreSQL RLS ensures tenant data isolation
- **API Authentication** - JWT tokens include tenant context for all operations
- **Network Segmentation** - ECS tasks deployed in isolated private subnets

### Secrets Management Security
- **Rotation Strategy** - Regular rotation of all API keys and sensitive credentials
- **Access Monitoring** - CloudTrail logging of all Secrets Manager access
- **Encryption at Rest** - All secrets encrypted using AWS KMS
- **Version Control** - Secret versions maintained for rollback capabilities

---

## 📋 Related Configuration Documentation

### Infrastructure and Deployment
> 🚀 **AWS Infrastructure**: See [AWS Deployment Guide](../workflows/aws-deployment-guide.md) for complete infrastructure setup and deployment procedures
> 🚀 **Container Configuration**: See [Container Deployment](../workflows/deployment-guide.md) for Docker and ECS container configuration details

### Development Setup
- **[Development Environment Setup](../setup/development-setup.md)** - Complete local development environment configuration
- **[Demo Data Management](../workflows/demo-data-management.md)** - Safe demo data setup and management workflows
- **[Testing Guide](../workflows/testing-guide.md)** - Testing strategies and environment setup

### Security and Compliance
- **[Security Architecture](../architecture/security-architecture.md)** - Comprehensive security architecture and best practices
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Multi-tenant and security deployment patterns
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Security and configuration troubleshooting

---

**Status**: ✅ **PRODUCTION ENVIRONMENT CONFIGURATION**
**Last Updated**: 2025-06-29
**Scope**: Multi-Environment Configuration, AWS Infrastructure, Secrets Management, Security
**Key Components**: Docker Compose, ECS, IAM, S3, Secrets Manager

---

*This environment configuration documentation provides comprehensive guidance for setting up and managing Spacewalker deployments across all environments, ensuring consistent security, proper tenant isolation, and reliable infrastructure management.*
