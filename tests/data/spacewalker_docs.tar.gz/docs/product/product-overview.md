# Spacewalker: Product Overview

## Purpose
High-level product vision, business goals, and system architecture overview for all stakeholders. Central reference for product strategy and system-wide architecture decisions.

## When to Use This
- Understanding product vision and business objectives
- Getting oriented with system architecture and technology stack
- Planning roadmap and feature development
- Onboarding new team members and stakeholders
- Keywords: product vision, business goals, roadmap, system architecture, technology stack

**Version:** 2.2 (Reorganized from comprehensive PRD)
**Date:** 2025-06-29
**Status:** Current - Core Product Reference

---

## 🎯 Vision & Scope

Spacewalker is an AI-powered mobile and web platform that revolutionizes university facility management by enabling rapid, accurate room inventory collection. By leveraging advanced AI image analysis and intuitive mobile interfaces, facilities staff can complete comprehensive room surveys in under 25 seconds with ≥80% accuracy.

### Business Goals
- **Efficiency:** Reduce room inventory time from hours to seconds. `[Implemented]`
- **Accuracy:** Achieve ≥80% AI accuracy in room type and attribute identification. `[Implemented]`
- **Scalability:** Support multiple universities through a robust multi-tenant architecture. `[Implemented]`
- **Compliance:** Ensure FICM (Facilities Inventory and Classification Manual) standard adherence. `[Implemented]`
- **Accessibility:** Enable offline data collection with seamless cloud synchronization. `[Implemented]`

---

## 🏗️ System Architecture Overview

The system is comprised of three primary applications working together, built on a modern, containerized architecture designed for scalability and maintainability.

### Technology Stack
| Component         | Technology                               |
| ----------------- | ---------------------------------------- |
| **Backend**       | Python ≥3.11, FastAPI 0.111.0, SQLAlchemy 2.0.23, PostgreSQL |
| **Mobile App**    | TypeScript, React Native, Expo SDK 54    |
| **Admin Dashboard** | TypeScript, Next.js 15.5.3, React 19.1.0          |
| **Database**      | PostgreSQL 15 (PostGIS)                            |
| **Dev Toolkit**   | Docker, just, pnpm                       |

### System Context (C4 Level 1)
This diagram shows how the Spacewalker system fits into its operating environment, its users, and its key external dependencies.

```mermaid
graph TB
    %% External Actors
    Surveyor["👤 Field Surveyor<br/><i>University facilities staff</i>"]
    Admin["👤 System Administrator<br/><i>IT staff</i>"]
    Manager["👤 Facilities Manager<br/><i>Department head</i>"]
    SuperUser["👤 Super User<br/><i>Enterprise admin</i>"]

    %% Spacewalker System (Single Box)
    Spacewalker[["🏢 Spacewalker System<br/><b>Multi-tenant Facility Inventory Platform</b>"]]

    %% External Systems
    Gemini["🤖 Google Gemini API<br/><i>External AI Service</i>"]
    SSO["🔐 University SSO<br/><i>[PLANNED] Authentication Provider</i>"]
    Storage["📁 Cloud Storage<br/><i>S3-compatible</i>"]
    Email["📧 Email Service<br/><i>[UNDER CONSTRUCTION] SMTP</i>"]

    %% Relationships
    Surveyor -->|"Captures photos & submits surveys `[Implemented]`"| Spacewalker
    Admin -->|"Manages users & buildings `[Implemented]`"| Spacewalker
    Manager -->|"Approves surveys & exports reports `[Implemented]`"| Spacewalker
    SuperUser -->|"Manages tenants & system settings `[Implemented]`"| Spacewalker

    Spacewalker -.->|"Authenticates users `[Planned]`"| SSO

    Spacewalker -->|"Analyzes room images `[Implemented]`"| Gemini
    Gemini -->|"Returns FICM codes & attributes `[Implemented]`"| Spacewalker

    Spacewalker -->|"Stores survey images `[Implemented]`"| Storage

    Spacewalker -.->|"Sends notifications `[Under Construction]`"| Email

    %% Styling
    classDef person fill:#1168BD,stroke:#0B4884,color:#ffffff
    classDef system fill:#438DD5,stroke:#2E6295,color:#ffffff
    classDef external fill:#999999,stroke:#666666,color:#ffffff

    class Surveyor,Admin,Manager,SuperUser person
    class Spacewalker system
    class SSO,Storage,Email external
```

### Container Diagram (C4 Level 2)
This diagram breaks down the system into its major deployable units: applications and data stores.

```mermaid
graph TB
    %% External Actors
    Surveyor["👤 Field Surveyor"]
    Admin["👤 System Admin / Manager"]

    %% External Systems
    Gemini["🤖 Google Gemini API"]
    Email["📧 Email Service"]

    %% Spacewalker Containers
    subgraph "Spacewalker System [Live Environment]"
        direction LR

        subgraph "Clients"
            direction TB
            Mobile["📱 Mobile Application<br/><b>React Native / Expo SDK 54</b><br/><i>[Implemented]</i>"]
            AdminWeb["💻 Admin Dashboard<br/><b>Next.js 15.5.3</b><br/><i>[Implemented]</i>"]
        end

        subgraph "Backend Services"
            direction TB
            Backend["⚙️ Backend API<br/><b>FastAPI 0.111.0</b><br/><i>[Implemented]</i>"]
        end

        subgraph "Data Stores"
            direction TB
            Database["🗄️ PostgreSQL Database<br/><b>PostgreSQL 15 (PostGIS)</b><br/><i>[Implemented]</i>"]
            FileStore["📁 File Storage<br/><b>S3-compatible</b><br/><i>[Implemented]</i>"]
        end
    end

    %% User Interactions
    Surveyor -->|Uses via HTTPS| Mobile
    Admin -->|Uses via HTTPS| AdminWeb

    %% Container Communications
    Mobile -->|REST API (JSON/HTTPS)| Backend
    AdminWeb -->|REST API (JSON/HTTPS)| Backend

    Backend -->|"SQLAlchemy (TCP)"| Database
    Backend -->|"S3 API"| FileStore

    %% External Integrations
    Backend -->|"REST API (HTTPS)"| Gemini
    Backend -.->|"SMTP (Planned)"| Email

    %% Style Definitions
    classDef person fill:#1168BD,stroke:#0B4884,color:#ffffff
    classDef system fill:#438DD5,stroke:#2E6295,color:#ffffff
    classDef external fill:#999999,stroke:#666666,color:#ffffff
    class Surveyor,Admin person
    class Mobile,AdminWeb,Backend,Database,FileStore system
    class Gemini,Email external
```

---

## 🚀 Project Roadmap

### Completed Milestones (v2.0 - v2.1)
- [x] **Containerized Development Environment**
- [x] **Monorepo Setup** (`pnpm` workspaces)
- [x] **CI/CD Foundation** (GitHub Actions)
- [x] **Database & Migrations** (PostgreSQL with Alembic)
- [x] **Multi-Tenant Architecture** (RLS)
- [x] **JWT Authentication**
- [x] **Core API Endpoints**
- [x] **Mobile Survey Workflow** (React Native with Offline Support)
- [x] **Admin Review Workflow** (Next.js)

### Planned Features (Next 6 Months)
- **Enhanced Reporting**: Flexible reporting engine in the admin dashboard (CSV/PDF).
- **Advanced AI Prompt Engineering UI**: Interface to manage AI prompts without code changes.
- **Full ADA/WCAG 2.1 AA Compliance**: Accessibility audit and remediation.
- **Bulk Data Import/Export**: Import/export room inventories from CSV/Excel.
- **Advanced Analytics Dashboard**: Visualizations for space trends and data accuracy.

---

## 🎯 Core Features Overview

### User-Facing Features
- **User Authentication** `[Implemented]` - Secure login via email and password, issuing a JWT with 24-hour expiration
- **Room Selection & Geolocation** `[Implemented]` - Select buildings and floors via geolocation-based suggestions or manual search
- **Image Capture & AI Analysis** `[Implemented]` - Guided photo capture with cloud-based AI (Google Gemini) analysis
- **Data Review & Submission** `[Implemented]` - Users confirm or edit AI-suggested data on the mobile app
- **Offline Capability** `[Implemented]` - Mobile app fully supports offline data collection with AsyncStorage sync

### Administrative & Backend Features
- **Admin Review Dashboard** `[Implemented]` - Web dashboard for administrators to review, approve, or reject survey submissions
- **Multi-Tenant Data Management** `[Implemented]` - Data securely isolated between university tenants using PostgreSQL's Row-Level Security
- **Reporting** `[Planned]` - Future capability to generate reports on room usage, condition, and other metrics

---

## 📚 Related Documentation

### Architecture Details
- **[Backend Architecture](../backend/architecture/README.md)** - FastAPI service architecture, database design, and API contracts
- **[Mobile Architecture](../mobile/architecture/README.md)** - React Native app architecture and offline-first design
- **[Admin Architecture](../admin/architecture/README.md)** - Next.js dashboard architecture and admin workflows

### Development Resources
- **[Development Setup](../setup/development-setup.md)** - Development environment configuration and daily workflow
- **[FICM Specifications](../backend/ficm-specifications.md)** - Room classification standards and domain knowledge
- **[Getting Started Guide](../setup/getting-started.md)** - Complete setup validation and onboarding
- **[Project Structure](../development/project-structure.md)** - Monorepo organization and component relationships

### Workflow Guides
- **[Deployment Guide](../workflows/deployment-guide.md)** - Infrastructure setup and deployment workflows
- **[Testing Guide](../workflows/testing-guide.md)** - Quality assurance and testing strategies
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Problem resolution and diagnostics

---

**Status**: ✅ Updated and current as of 2025-06-29. Reorganized from comprehensive PRD into focused product overview with clear navigation to detailed documentation.
