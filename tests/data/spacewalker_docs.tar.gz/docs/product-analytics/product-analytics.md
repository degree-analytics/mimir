# SpaceWalker Product Analytics Implementation

## Overview

SpaceWalker uses PostHog for product analytics to track user behavior, measure feature adoption, and drive data-informed product decisions. The implementation is currently deployed in the **Admin Dashboard** application only, with a focus on privacy, performance, and tenant isolation.

## Architecture

### Current Scope
- **Admin Dashboard**: Full PostHog integration with event tracking
- **Mobile App**: No analytics (planned)

### Implementation Stack

```
┌─────────────────────────────────────────────────────────┐
│                    Frontend (Admin)                       │
├─────────────────────────────────────────────────────────┤
│ PostHog Service     │ apps/admin/src/lib/posthog.ts     │
│ Analytics Context   │ src/contexts/AnalyticsContext.tsx  │
│ Page Tracking       │ src/hooks/usePageTracking.ts      │
│ Error Handling      │ src/utils/analyticsErrorHandler.ts│
│ Debug Interface     │ src/components/AnalyticsDebugger  │
└─────────────────────────────────────────────────────────┘
```

## Core Features

### 1. Environment-Aware Configuration
The system automatically adjusts behavior based on the environment:

- **Production**: Events sent to PostHog when `POSTHOG_ENABLED=true`
- **Development/Staging**: Debug mode with console logging, no API calls
- **Environment Tagging**: All events include `environment` property for filtering

### 2. Tenant Isolation
Every event automatically includes tenant context for proper data isolation:

```javascript
{
  tenant_id: "123",
  tenant_name: "Demo University",
  user_id: "456",
  user_role: "admin",
  environment: "production"
}
```

### 3. Error Resilience
Comprehensive error handling ensures analytics never impact app functionality:

- **Circuit Breaker**: Disables analytics after 10 failures (5-minute reset)
- **Safe Wrappers**: All analytics operations wrapped in try-catch
- **Graceful Degradation**: App continues working even if PostHog fails

### 4. Privacy & Security
- No PII in event properties
- User IDs use internal identifiers, not emails
- Tenant isolation for multi-tenant security
- API keys stored in AWS SSM Parameter Store

## Events Currently Tracked

### Automatic Events

#### 1. Page Views (`page_view`)
Automatically tracked on every route change with intelligent page naming.

**Properties:**
- `page`: Human-readable page name (e.g., "Survey Detail", "Buildings")
- `page_path`: Actual URL path (e.g., "/surveys/123")
- `environment`: Current environment
- `tenant_id`: Current tenant
- `user_id`: Current user

**Page Name Mapping:**
| Route Pattern | Page Name |
|--------------|-----------|
| `/dashboard` | Dashboard |
| `/surveys` | Surveys |
| `/surveys/[id]` | Survey Detail |
| `/buildings` | Buildings |
| `/buildings/[id]` | Building Detail |
| `/buildings/[id]/edit` | Building Edit |
| `/rooms` | Rooms |
| `/rooms/[id]` | Room Detail |
| `/settings` | Settings |
| `/profile` | Profile |
| `/superuser/tenants` | Superuser - Tenants |
| `/superuser/invitations` | Superuser - Invitations |

### Manual Events

#### 2. Filter Applied (`filter_applied`)
Tracked when users apply filters to data tables.

**Locations:** 
- Surveys page
- Rooms page

**Properties:**
```javascript
{
  page_path: "/surveys",
  data_type: "surveys", // or "rooms"
  filters_applied: {
    status: ["pending", "approved"],
    building: "Building A"
  },
  filter_count: 2,
  tenant_id: "123",
  user_id: "456"
}
```

#### 3. Data Exported (`data_exported`)
Tracked when users export data to CSV.

**Locations:**
- Rooms page

**Properties:**
```javascript
{
  export_type: "csv",
  data_type: "rooms",
  file_format: "csv",
  row_count: 150,
  filter_active: true,
  tenant_id: "123",
  user_id: "456"
}
```

#### 4. Bulk Action Performed (`bulk_action_performed`)
Tracked when users perform bulk operations on multiple items.

**Locations:**
- Rooms page

**Properties:**
```javascript
{
  action_type: "delete",
  data_type: "rooms",
  item_count: 5,
  page_path: "/rooms",
  tenant_id: "123",
  user_id: "456"
}
```

#### 5. Survey Reviewed (`survey_reviewed`)
Tracked when an admin views a survey detail page.

**Locations:**
- Survey detail page

**Properties:**
```javascript
{
  survey_id: "survey_123",
  survey_status: "pending",
  room_id: "room_456",
  room_name: "Conference Room A",
  has_images: true,
  image_count: 3,
  tenant_id: "123",
  user_id: "456"
}
```

### User Identification

Users are automatically identified when they log in with the following properties:

```javascript
{
  distinct_id: "user_123",  // Internal user ID
  email: "admin@demo.edu",
  tenant_id: "456",
  tenant_name: "Demo University",
  user_role: "admin",
  is_admin: true,
  is_super_user: false,
  first_name: "John",
  last_name: "Doe"
}
```

## Configuration

### Environment Variables

#### Required for PostHog
```bash
# PostHog Configuration (Admin Dashboard)
NEXT_PUBLIC_POSTHOG_API_KEY=phc_your_api_key_here
NEXT_PUBLIC_POSTHOG_HOST=https://app.posthog.com
NEXT_PUBLIC_POSTHOG_ENABLED=false  # true only in production
NEXT_PUBLIC_ENVIRONMENT_NAME=development  # or staging, production
```

### AWS Parameter Store Configuration

Production values are stored in AWS SSM Parameter Store:

```yaml
/${Environment}/posthog/api_key    # PostHog API key
/${Environment}/posthog/host       # PostHog host URL
/${Environment}/posthog/enabled    # Enable/disable flag
```

### CloudFormation Integration

The admin ECS task definition pulls PostHog config from SSM:

```yaml
# sam/ecs/admin.yaml
Environment:
  - Name: NEXT_PUBLIC_POSTHOG_API_KEY
    Value: !Sub '{{resolve:ssm:/${Environment}/posthog/api_key}}'
  - Name: NEXT_PUBLIC_POSTHOG_HOST
    Value: !Sub '{{resolve:ssm:/${Environment}/posthog/host}}'
  - Name: NEXT_PUBLIC_POSTHOG_ENABLED
    Value: !Sub '{{resolve:ssm:/${Environment}/posthog/enabled}}'
```

## Quota Management

PostHog Cloud Free Tier provides 1,000,000 events/month.

### Current Allocation Strategy
```
Production:     99.0% (~990,000 events)
Staging:         0.8% (~8,000 events)
Development:     0.2% (~2,000 events)
```

### Quota Protection
- **Development/Staging**: Debug mode prevents API calls
- **Production**: Circuit breaker limits failure impact
- **Kill Switch**: Can disable via AWS SSM instantly

## Debug Mode

In development/staging environments, all events are logged to console:

```javascript
🔍 PostHog Debug Event: {
  "event_type": "capture",
  "event": "filter_applied",
  "user_id": "user_123",
  "properties": {
    "environment": "development",
    "timestamp": "2024-01-15T14:30:00Z",
    "page_path": "/surveys",
    "data_type": "surveys",
    "filters_applied": {...}
  },
  "would_send_to_posthog": false,
  "debug_timestamp": "2024-01-15T14:30:00Z"
}
```

### Debug Interface
The admin app includes an Analytics Debugger component (dev only) that displays:
- Current configuration
- Circuit breaker status
- Recent events
- Test event interface

## Implementation Details

### Service Architecture

#### PostHogService (`src/lib/posthog.ts`)
- Singleton service managing PostHog SDK
- Environment-aware initialization
- Debug logging in non-production
- Circuit breaker integration

#### AnalyticsContext (`src/contexts/AnalyticsContext.tsx`)
- React context providing analytics to components
- Automatic user identification on auth
- Tenant context injection
- Session management (reset on logout)

#### PageTracker (`src/components/PageTracker.tsx`)
- Automatic page view tracking
- Debounced to prevent duplicates (300ms)
- Intelligent page name detection

#### Error Handler (`src/utils/analyticsErrorHandler.ts`)
- Circuit breaker (10 failures = 5-minute disable)
- Safe operation wrappers
- Health check utilities
- Graceful degradation

### Key Implementation Features

1. **Automatic Context Enrichment**
   - Every event includes tenant_id, user_id, environment
   - No manual property passing needed

2. **Debounced Operations**
   - Page views: 300ms debounce
   - User reset: 1000ms debounce
   - Prevents duplicate events

3. **Error Boundaries**
   - Analytics wrapped in try-catch
   - Failures logged but not propagated
   - App functionality never impacted

4. **Feature Flags Support**
   - Built-in but not currently used
   - Ready for gradual rollouts

## Testing

### Manual Testing
```bash
# Run admin with debug mode
cd apps/admin
npm run dev

# Check console for debug events
# Look for 🔍 PostHog Debug Event logs
```

### Verification Checklist
- [ ] Page views tracked on navigation
- [ ] User identified on login
- [ ] Session reset on logout
- [ ] Filters tracked when applied
- [ ] Exports tracked when triggered
- [ ] Tenant context in all events
- [ ] Debug logs in development
- [ ] No API calls in dev/staging

## PostHog Dashboard Setup

### Recommended Dashboards

1. **User Activity**
   - Daily active users by tenant
   - Most viewed pages
   - Feature adoption rates

2. **Data Operations**
   - Filter usage patterns
   - Export frequency
   - Bulk action usage

3. **Survey Management**
   - Survey review frequency
   - Review patterns by status
   - Time to review metrics

### Key Filters
```javascript
// Production only
properties.environment = "production"

// Specific tenant
properties.tenant_id = "123"

// Admin users only
properties.user_role = "admin"

// Feature-specific
event = "survey_reviewed"
```

## Future Enhancements

### Planned Events
- User authentication (login, logout, register)
- Form submissions (buildings, rooms, surveys)
- API errors and performance metrics
- Search queries and results
- Navigation patterns

### Planned Features
- Session recordings (with consent)
- Feature flags for A/B testing
- Cohort analysis
- Funnel analysis for workflows
- Custom dashboards per tenant

### Mobile Integration
**Status**: Implemented for authentication events

#### Authentication Events
The mobile app now tracks comprehensive authentication events using a dedicated `typedAnalytics` service:

##### 1. User Login (`user_login`)
Tracked on successful authentication.

**Properties:**
```javascript
{
  email: "user@example.com",      // User email
  tenant_id: 123,                 // Tenant identifier
  method: "email",                // Authentication method
  duration_ms: 1250,              // Login request duration
  timestamp: "2024-01-15T10:30:00Z"
}
```

##### 2. User Logout (`user_logout`)
Tracked when user logs out or session ends.

**Properties:**
```javascript
{
  reason: "manual",               // "manual", "session_expired", "error"
  session_duration_ms: 1800000,  // Session duration (30 minutes)
  timestamp: "2024-01-15T11:00:00Z"
}
```

##### 3. Session Expired (`session_expired`)
Tracked when session expires due to token expiry, server invalidation, or inactivity.

**Properties:**
```javascript
{
  last_activity: "2024-01-15T10:55:00Z",  // ISO timestamp of last activity
  session_duration_ms: 1500000,           // Total session duration (25 minutes)
  reason: "token_expired",                 // "token_expired", "server_invalidation", "inactivity"
  timestamp: "2024-01-15T11:00:00Z"
}
```

##### 4. Authentication Error (`auth_error`)
Tracked when authentication fails.

**Properties:**
```javascript
{
  error_type: "invalid_credentials",       // Error type
  error_message: "Invalid email/password", // Human-readable message
  screen: "LoginScreen",                   // Source screen
  method: "email",                         // Auth method attempted
  timestamp: "2024-01-15T10:30:00Z"
}
```

#### Implementation Details

**Service Location**: `apps/mobile/src/lib/typedAnalytics.ts`

**Session Tracking**: 
- Session duration calculated from login timestamp
- Last activity updated only on successful API calls
- Session expiry reasons: `token_expired` (401), `server_invalidation` (403), `inactivity`

**Error Handling**: 
- All analytics calls are wrapped with internal error handling
- Analytics failures don't impact app functionality
- Console warnings for debugging failed analytics

**Future Mobile Events**:
- Survey submission and image uploads  
- Offline/online state transitions
- App lifecycle events (background/foreground)
- Device context (OS, version)

## Security & Privacy

### Data Handling
- **No PII**: Use IDs not emails/names in properties
- **Tenant Isolation**: Every event tagged with tenant_id
- **Secure Storage**: API keys in AWS SSM
- **Access Control**: PostHog dashboard limited to authorized users

### Compliance
- GDPR/CCPA ready architecture
- User consent management (planned)
- Data retention policies (planned)
- Right to deletion support (planned)

## Troubleshooting

### Events Not Appearing
1. Check `NEXT_PUBLIC_POSTHOG_ENABLED=true` in production
2. Verify API key in AWS SSM Parameter Store
3. Check network tab for PostHog API calls
4. Review circuit breaker status in debug interface

### Debug Logs Missing
1. Ensure `NEXT_PUBLIC_POSTHOG_ENABLED=false` in dev
2. Check browser console log level
3. Verify AnalyticsProvider is mounted

### Quota Issues
1. Check PostHog dashboard usage
2. Verify environment filtering working
3. Ensure dev/staging not sending events
4. Consider upgrading PostHog plan

### Circuit Breaker Triggered
1. Check analytics error handler logs
2. Verify PostHog service health
3. Wait 5 minutes for auto-reset
4. Check network connectivity

## Quick Reference

### Add New Event
```javascript
import { useAnalytics } from "@/contexts/AnalyticsContext";

function MyComponent() {
  const { capture } = useAnalytics();
  
  const handleAction = () => {
    capture("my_custom_event", {
      action_type: "click",
      target: "button",
      // tenant_id and user_id added automatically
    });
  };
}
```

### Check Feature Flag
```javascript
const { isFeatureEnabled } = useAnalytics();

if (isFeatureEnabled("new-feature", false)) {
  // Show new feature
}
```

### Track Page View Manually
```javascript
const { pageView } = useAnalytics();

pageView("Custom Page", {
  section: "admin",
  custom_property: "value"
});
```

### Mobile Event Reference
```javascript
// User Login (mobile)
typedAnalytics.trackUserLogin(email, tenantId, method, durationMs);

// User Logout (mobile)  
typedAnalytics.trackUserLogout(reason, sessionDurationMs);

// Session Expired (mobile)
typedAnalytics.trackSessionExpired(lastActivity, sessionDurationMs, reason);

// Authentication Error (mobile)
typedAnalytics.trackAuthError(errorType, errorMessage, screen, method);
```

## Related Documentation
- [Frontend Architecture](../frontend/)
- [Admin App Guide](../admin/)
- [Mobile Architecture](../mobile/architecture.md)
- [Environment Configuration](../setup/environment-configuration.md)
- [AWS Deployment Guide](../workflows/aws-deployment-guide.md)