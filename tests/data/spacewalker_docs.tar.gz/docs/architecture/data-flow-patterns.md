# Spacewalker Data Flow Patterns

## Purpose
Comprehensive documentation of data flow patterns across the Spacewalker system, illustrating how information moves between mobile apps, backend services, and databases during critical operations. Essential reference for understanding cross-system workflows, offline synchronization, authentication flows, and multi-tenant data isolation patterns.

## When to Use This
- Understanding end-to-end data flows across system boundaries
- Implementing offline synchronization and data sync patterns
- Designing authentication and authorization workflows
- Planning multi-tenant data isolation strategies
- Troubleshooting cross-system data flow issues
- Keywords: data flow, offline sync, authentication flow, multi-tenant isolation, cross-system workflows

**Version:** 2.3 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production Data Flow Patterns

---

## 🔄 Overview

This document illustrates the key data flows within the Spacewalker system, showing how information moves between components during critical operations. These patterns form the foundation for understanding system behavior across mobile applications, backend services, and data persistence layers.

### Core Data Flow Principles
- **Offline-First Design** - Mobile applications work seamlessly without network connectivity
- **Secure Authentication** - JWT-based stateless authentication across all clients
- **Multi-Tenant Isolation** - Database-level security ensures complete data separation
- **Eventual Consistency** - Background synchronization maintains data integrity

---

## 🌐 End-to-End Survey Data Flow (Online)

This diagram shows the complete, end-to-end flow for a room survey when the user has an active internet connection.

```mermaid
sequenceDiagram
    participant Surveyor
    participant MobileApp as Mobile App
    participant BackendAPI as Backend API
    participant GeminiAPI as Google Gemini
    participant Database

    Surveyor->>MobileApp: Captures Photos & Enters Data
    MobileApp->>BackendAPI: POST /api/surveys (with image URLs)
    note right of MobileApp: Payload includes survey data and references to images to be uploaded.

    BackendAPI->>GeminiAPI: Analyze Images
    GeminiAPI-->>BackendAPI: Returns Analysis (FICM codes, attributes)

    BackendAPI->>Database: INSERT INTO surveys, room_attributes
    note left of Database: Survey data and AI analysis are saved.
    Database-->>BackendAPI: Confirm Save

    BackendAPI-->>MobileApp: HTTP 201 Created (with Survey ID)
    MobileApp->>Surveyor: Show "Survey Submitted Successfully"
```

### Online Flow Characteristics
- **Real-time Processing** - Immediate AI analysis and data persistence
- **Synchronous Validation** - Instant feedback on data quality and completeness
- **Immediate Persistence** - Data saved to database with survey ID returned
- **AI Integration** - Google Gemini analysis integrated into submission workflow

---

## 📱 Offline Data Synchronization Flow

This flow describes how the mobile app handles data collection while offline and syncs it once a connection is re-established.

```mermaid
sequenceDiagram
    participant Surveyor
    participant MobileApp as Mobile App
    participant OfflineDB as MMKV (Local Storage)
    participant BackendAPI as Backend API

    Note over Surveyor, BackendAPI: User is offline.

    Surveyor->>MobileApp: Captures Photos & Enters Data
    MobileApp->>OfflineDB: Save Survey to Sync Queue
    note right of MobileApp: The entire survey payload, including image data, is stored locally.
    OfflineDB-->>MobileApp: Confirm Queued
    MobileApp->>Surveyor: Show "Survey Queued for Sync"

    Note over Surveyor, BackendAPI: User comes online.

    MobileApp->>MobileApp: Background Sync Process Starts
    MobileApp->>OfflineDB: Read next Survey from Queue
    MobileApp->>BackendAPI: POST /api/surveys (sends queued data)
    BackendAPI-->>MobileApp: HTTP 201 Created

    MobileApp->>OfflineDB: Remove Survey from Queue
    MobileApp->>Surveyor: Notification: "Synced 1 survey"
```

### Offline Synchronization Features
- **Complete Offline Operation** - Full survey functionality without network connectivity
- **MMKV Storage** - High-performance local storage for survey data and images
- **Background Sync Queue** - Automatic synchronization when connectivity returns
- **Conflict Resolution** - Intelligent handling of data conflicts during sync
- **Progress Notifications** - User feedback on synchronization status

---

## 🔐 JWT Authentication Flow

This diagram illustrates how a user authenticates with the system and uses the JWT for subsequent API requests.

```mermaid
sequenceDiagram
    participant User
    participant Client as Mobile or Admin App
    participant BackendAPI as Backend API
    participant Database

    User->>Client: Enters Email & Password
    Client->>BackendAPI: POST /auth/token (with credentials)
    BackendAPI->>Database: SELECT user WHERE email=...
    Database-->>BackendAPI: Returns User Record (with hashed password)

    alt Credentials are valid
        BackendAPI->>BackendAPI: Generate JWT (payload: user_id, tenant_id, exp)
        BackendAPI-->>Client: HTTP 200 OK (with access_token)
        Client->>Client: Store JWT securely
    else Credentials are invalid
        BackendAPI-->>Client: HTTP 401 Unauthorized
    end

    User->>Client: Accesses a protected resource
    Client->>BackendAPI: GET /api/surveys (Header: "Authorization: Bearer <JWT>")
    BackendAPI->>BackendAPI: Validate JWT signature and expiration
    BackendAPI->>Database: Query for surveys (with user_id from JWT)
    Database-->>BackendAPI: Returns survey data
    BackendAPI-->>Client: HTTP 200 OK (with data)
```

### Authentication Security Features
- **Stateless Design** - JWT tokens contain all necessary authentication information
- **Cross-Platform Support** - Same authentication flow for mobile and admin applications
- **Secure Storage** - Platform-appropriate secure token storage (Keychain/Keystore)
- **Automatic Expiration** - Time-based token expiration for security
- **Multi-Tenant Context** - Tenant ID embedded in JWT for data isolation

---

## 🏢 Multi-Tenant Data Isolation

Data isolation is enforced at the database level using PostgreSQL's Row-Level Security (RLS). The `tenant_id` from the user's JWT is used to transparently filter all queries.

### Multi-Tenant Architecture Flow
```mermaid
graph TB
    subgraph "Authentication Layer"
        JWT[JWT Token with tenant_id]
    end

    subgraph "Application Layer"
        Middleware[Backend Middleware]
        Session[Database Session]
    end

    subgraph "Database Layer"
        RLS[Row-Level Security Policies]
        Tables[Multi-Tenant Tables]
    end

    JWT --> Middleware
    Middleware --> Session
    Session --> RLS
    RLS --> Tables

    Tables --> |Filtered Data| RLS
    RLS --> |Tenant Data Only| Session
    Session --> |Secure Response| Middleware
    Middleware --> |JSON Response| JWT
```

### Data Isolation Implementation

1. **JWT Token Generation** - When a user logs in, their `tenant_id` is embedded in the JWT payload
2. **Middleware Processing** - Backend middleware extracts `tenant_id` from JWT on every request
3. **Database Session Setup** - The `tenant_id` is set as a session variable: `SET app.current_tenant_id = '...'`
4. **RLS Policy Enforcement** - Pre-defined RLS policies automatically filter all database operations

### Row-Level Security Policy Example
```sql
-- Example RLS policy for surveys table
CREATE POLICY survey_tenant_isolation ON surveys
    FOR ALL TO application_role
    USING (tenant_id = current_setting('app.current_tenant_id'));
```

### Multi-Tenant Security Benefits
- **Database-Level Enforcement** - Security enforced by PostgreSQL, not just application code
- **Automatic Filtering** - All queries automatically filtered by tenant without code changes
- **Zero-Trust Architecture** - Even application bugs cannot access cross-tenant data
- **Performance Optimized** - Database indexes optimized for tenant-based queries

---

## 🔄 Cross-System Data Flow Patterns

### Survey Processing Pipeline
```
Mobile Capture → Local Storage → Background Sync → Backend API → AI Processing → Database Storage → Admin Review
      ↓               ↓               ↓              ↓              ↓               ↓              ↓
  Offline Mode → MMKV Queue → Network Available → Authentication → Gemini API → PostgreSQL → Web Dashboard
```

### Authentication Propagation
```
User Login → JWT Generation → Token Storage → API Requests → Middleware Validation → Database Authorization → Response
    ↓             ↓              ↓              ↓              ↓                   ↓                  ↓
Credentials → Backend Auth → Secure Storage → Bearer Header → JWT Verification → RLS Enforcement → Filtered Data
```

### File Upload Flow
```
Photo Capture → Local Optimization → S3 Upload → Metadata Storage → AI Analysis → Results Persistence
     ↓               ↓                   ↓              ↓               ↓              ↓
Mobile Camera → Image Compression → Signed URL → Database Record → Gemini API → Survey Association
```

---

## 📋 Related Data Flow Documentation

### Implementation Details
> 📱 **Mobile Data Patterns**: See [Offline-First Architecture](../mobile/architecture/offline-first.md) for detailed offline storage and sync implementation
> 🎯 **Admin Dashboard Flow**: See [Admin Architecture](../admin/architecture/README.md) for web application data patterns
> 🚀 **Backend Processing**: See [API Development Guide](../backend/api-development.md) for server-side data orchestration

### System Architecture Context
- **[System Container Overview](./system-container-overview.md)** - Complete system architecture showing all container relationships
- **[Component Architecture](./component-diagrams.md)** - Detailed component interactions within each container
- **[Runtime Sequences](./runtime-sequences.md)** - Detailed workflow implementations and integration patterns

### Development Resources
- **[API Development Guide](../backend/api-development.md)** - Backend API design patterns and integration strategies
- **[Offline-First Architecture](../mobile/architecture/offline-first.md)** - Comprehensive offline-first implementation strategies
- **[Admin Architecture](../admin/architecture/README.md)** - Detailed JWT and security implementation patterns

---

**Status**: ✅ **PRODUCTION DATA FLOW PATTERNS**
**Last Updated**: 2025-06-29
**Scope**: Cross-System Data Flows, Authentication, Offline Sync, Multi-Tenant Isolation
**Use Cases**: End-to-end workflows, offline synchronization, authentication flows, data isolation

---

*This data flow documentation provides essential patterns for understanding how information moves through the Spacewalker system, ensuring proper implementation of offline capabilities, secure authentication, and multi-tenant data isolation across all system components.*
