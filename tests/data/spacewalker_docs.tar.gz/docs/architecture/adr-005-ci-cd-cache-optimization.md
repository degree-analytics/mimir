# ADR-005: CI/CD Cache-Only Architecture for Dependency Distribution

## Status
**Accepted** - 2025-07-18

## Context
During ENG-736 analysis, we discovered that our CI/CD setup stage consumed 9.2 minutes (552.6 seconds) on average, with 82% of this time spent on artifact creation and upload operations. This created a significant bottleneck affecting developer productivity and CI/CD pipeline efficiency.

### Performance Analysis Findings
- **Artifact Creation**: 342 seconds (61.9% of total time)
- **Artifact Upload**: 111 seconds (20.2% of total time)  
- **Combined Overhead**: 453 seconds (82% of total setup time)
- **Local vs CI Performance**: CI was 6.7x slower at creating tar.gz archives

### Root Cause
The pipeline used an artifact-based dependency distribution pattern:
1. Setup job creates tar.gz archives of `node_modules` and `.venv`
2. Setup job uploads these artifacts to GitHub Actions storage
3. All dependent jobs download and extract these artifacts

This pattern created a sequential bottleneck where all jobs waited for setup completion.

## Decision
We will **eliminate artifacts entirely** and implement a **cache-only architecture** where each job accesses GitHub Actions cache directly.

### Implementation Details

#### Before (Artifact-Based)
```yaml
# Setup job
- name: Create dependency artifacts
  run: |
    tar -czf node_modules.tar.gz node_modules
    tar -czf python_env.tar.gz .venv
- name: Upload dependency artifacts
  uses: actions/upload-artifact@v4

# Dependent jobs  
- name: Download dependency artifacts
  uses: actions/download-artifact@v4
- name: Extract dependencies
  run: |
    tar -xzf node_modules.tar.gz
    tar -xzf python_env.tar.gz
```

#### After (Cache-Only)
```yaml
# All jobs use this pattern
- name: Cache dependencies
  id: cache-deps
  uses: actions/cache@v4
  with:
    path: |
      ~/.npm
      ~/.cache/pip
      .venv
      node_modules
      apps/*/node_modules
    key: ${{ runner.os }}-deps-${{ hashFiles('**/package.json', '**/package-lock.json', '**/requirements.txt') }}

- name: Install dependencies if needed
  run: |
    if [ ! -d "node_modules" ] || [ ! -d ".venv" ]; then
      echo "🔄 Installing dependencies..."
      just install
    else
      echo "📦 Using cached dependencies"
    fi
```

## Rationale

### Why Cache-Only Architecture
1. **Eliminates Sequential Bottleneck**: Jobs can start immediately after checkout
2. **Aligns with GitHub Best Practices**: GitHub Actions cache is designed for this use case
3. **Reduces Complexity**: No artifact creation/upload/download steps
4. **Better Debugging**: Per-job cache hit/miss visibility
5. **Prevents Data Duplication**: No redundant storage of same dependencies

### Why Not Conditional Artifacts
We initially considered making artifact creation conditional (only on cache miss), but this approach failed because:
- Dependent jobs were tightly coupled to specific artifact files
- Missing artifacts forced full dependency reinstallation across all jobs
- This made the pipeline slower, not faster
- Added significant complexity without performance benefit

### Technical Implementation Decisions

#### Cache Key Optimization
```yaml
# Complete cache key includes ALL dependency sources
key: ${{ runner.os }}-deps-${{ hashFiles('**/package.json', '**/package-lock.json', '**/requirements.txt') }}
```

#### UV Binary Caching
```yaml
# Prevent race conditions during parallel installs
- name: Cache UV binary
  uses: actions/cache@v4
  with:
    path: ~/.local/bin
    key: ${{ runner.os }}-uv-${{ hashFiles('**/requirements.txt') }}
```

#### Standardized Dependency Verification
All jobs use consistent logic for dependency checking with proper logging for debugging.

## Consequences

### Positive
- **82% Setup Time Reduction**: From 9.2 minutes to ~30 seconds
- **Immediate Job Parallelization**: No waiting for setup job completion
- **Simplified Architecture**: Fewer moving parts, easier to debug
- **Better Monitoring**: Cache hit/miss status visible per job
- **Reduced Resource Usage**: No artifact compression/upload operations

### Negative
- **Cache Dependency**: Pipeline performance now depends on GitHub Actions cache availability
- **Increased Cache Usage**: Each job accesses cache independently (minor cost increase)
- **New Failure Mode**: Cache corruption could affect all jobs (but automatic fallback exists)

### Mitigation Strategies
- **Automatic Fallback**: All jobs install dependencies when cache misses
- **Cache Key Versioning**: Can force cache invalidation if needed
- **Monitoring**: Track cache hit rates to identify performance regressions
- **Documentation**: Clear troubleshooting guides for cache-related issues

## Implementation Timeline
- **Analysis**: ENG-736 identified bottleneck (2025-07-18)
- **Investigation**: Tested conditional artifacts approach (failed)
- **Design**: Cache-only architecture designed (2025-07-18)
- **Implementation**: Cache-only pattern implemented (2025-07-18)
- **Validation**: Performance improvement verified (82% reduction)

## Metrics and Success Criteria

### Performance Targets
- ✅ **Setup Time**: <1 minute (achieved ~30 seconds)
- ✅ **Job Start Delay**: Eliminated (achieved immediate start)
- ✅ **Overall Pipeline Time**: Reduced by setup bottleneck elimination

### Monitoring
- Cache hit rates across different jobs
- Job start times after cache implementation
- Total workflow duration improvements
- Cache storage usage patterns

## Alternatives Considered

### 1. Faster Compression (zstd)
- **Pros**: Potentially faster than gzip compression
- **Cons**: Still sequential bottleneck, doesn't solve core architecture issue
- **Decision**: Rejected in favor of eliminating compression entirely

### 2. Larger GitHub Runners
- **Pros**: Better CPU for compression operations
- **Cons**: Higher cost, doesn't solve sequential bottleneck
- **Decision**: Rejected as it addresses symptom, not root cause

### 3. Parallel Artifact Creation
- **Pros**: Could reduce setup time through parallelization
- **Cons**: Complex implementation, still requires upload/download overhead
- **Decision**: Rejected due to complexity and remaining bottlenecks

### 4. Custom Dependency Distribution
- **Pros**: Could optimize for specific use case
- **Cons**: High complexity, maintenance burden, reinventing GitHub capabilities
- **Decision**: Rejected in favor of platform-native solution

## Related ADRs
- ADR-001: Monorepo Structure (establishes need for shared dependency management)
- ADR-003: Docker-based Development Environment (dependency isolation patterns)

## References
- **Linear Issue**: ENG-736 - CI/CD Setup Stage Performance Analysis
- **GitHub Actions Cache Documentation**: [GitHub Actions Caching Guide](https://docs.github.com/en/actions/using-workflows/caching-dependencies-to-speed-up-workflows)
- **Performance Analysis**: [CI/CD Performance Anti-Patterns](../gotchas/ci-cd-performance-anti-patterns.md)
- **Implementation Guide**: [CI/CD Build Guide](../workflows/ci-cd-build-guide.md)

---

**Status**: ✅ Implemented and validated. 82% performance improvement achieved.