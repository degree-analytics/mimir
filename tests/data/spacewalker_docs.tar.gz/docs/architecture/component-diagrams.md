# Spacewalker Component Architecture (C4 Level-3)

## Purpose
Comprehensive C4 Level-3 Component diagrams showing the major building blocks inside each container and their interactions across the Spacewalker system. Essential architecture reference for understanding component relationships, data flow, and cross-system interactions between backend, mobile, and admin components.

## When to Use This
- Understanding overall system component architecture and relationships
- Designing new features that span multiple system components
- Analyzing data flow and component interactions across containers
- Onboarding developers to the system architecture
- Planning component-level changes and impact assessment
- Keywords: C4 architecture, component diagrams, system interactions, data flow, architectural overview

**Version:** 2.1 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production Architecture Reference

---

## 🏗️ Architectural Overview

This document provides C4 Level-3 Component diagrams, breaking down each container into its major building blocks. It answers the question: **"What are the main logical components inside each part of the system and how do they interact?"**

### Component Architecture Principles
- **Separation of Concerns** - Each component has a single, well-defined responsibility
- **Clear Boundaries** - Components interact through defined interfaces
- **Cross-Container Communication** - Components communicate via APIs and message passing
- **Offline-First Design** - Mobile components support offline operation with sync capabilities

---

## 🖥️ Backend API Components

The Backend API is a monolithic service built with FastAPI, organized by function with clear separation between API, business logic, and data access layers.

```mermaid
graph TD
    subgraph "Backend API Container (FastAPI)"
        direction LR

        subgraph "API Layer"
            APIRouters["API Routers<br/><i>[Implemented]</i><br/>Handles HTTP requests, auth, and validation."]
        end

        subgraph "Business Logic"
            AIService["AI Service<br/><i>[Implemented]</i><br/>Orchestrates calls to Google Gemini."]
            SurveyService["Survey Service<br/><i>[Implemented]</i><br/>Core logic for survey processing."]
        end

        subgraph "Data Access Layer"
            Models["SQLAlchemy Models<br/><i>[Implemented]</i><br/>Defines database schema and relationships."]
            Database["Database Session<br/><i>[Implemented]</i><br/>Manages DB connections."]
        end

    end

    APIRouters --> AIService
    APIRouters --> SurveyService
    SurveyService --> Models
    Models --> Database
```

### Backend Component Interactions
- **API Routers** serve as the entry point for all HTTP requests, handling authentication and validation
- **Business Logic** components (AI Service, Survey Service) process domain-specific operations
- **Data Access Layer** provides abstraction over database operations with SQLAlchemy ORM
- **Clear Separation** ensures testability and maintainability across all layers

> 🚀 **Backend Teams**: See [Backend API Components](../backend/api-components.md) for detailed implementation information and source code paths

---

## 📱 Mobile App Components

The mobile app is built with React Native and Expo, emphasizing clean separation between UI, state management, and services with strong offline-first capabilities.

```mermaid
graph TD
    subgraph "Mobile App Container (React Native)"
        direction TB

        subgraph "UI Layer"
            Screens["Screens<br/><i>[Implemented]</i><br/>User-facing views for each step of the survey workflow."]
            Components["Reusable Components<br/><i>[Implemented]</i><br/>Shared UI elements like buttons and inputs."]
        end

        subgraph "State & Logic Layer"
            State["React Context<br/><i>[Implemented]</i><br/>Manages global state for auth and session."]
            Services["Services & API Client<br/><i>[Implemented]</i><br/>Handles API calls, offline sync logic, and business rules."]
        end

        subgraph "Storage Layer"
            OfflineDB["MMKV Storage<br/><i>[Implemented]</i><br/>High-performance key-value store for offline data."]
        end
    end

    Screens --> Services
    Screens --> Components
    Services --> OfflineDB
    State --> Screens
```

### Mobile Component Architecture Highlights
- **UI Layer** provides modular, reusable interface components following React Native best practices
- **State Management** uses React Context for global state with Zustand planned for complex forms
- **Services Layer** handles all external communication and business logic with offline-first design
- **Storage Layer** uses MMKV for high-performance offline data persistence

> 📱 **Mobile Teams**: See [Mobile App Components](../mobile/app-components.md) for detailed implementation information and React Native specific patterns

---

## 🌐 Cross-System Component Interactions

### Survey Submission Flow (Online Mode)

This sequence shows how components interact across containers during normal online operation:

```mermaid
sequenceDiagram
    participant Surveyor
    participant MobileApp as Mobile App
    participant BackendAPI as Backend API
    participant GeminiAPI as Google Gemini
    participant Database

    Surveyor->>MobileApp: Captures Photos & Data
    MobileApp->>BackendAPI: POST /api/surveys (with image URLs)
    BackendAPI->>GeminiAPI: Analyze Images
    GeminiAPI-->>BackendAPI: Returns Analysis
    BackendAPI->>Database: Save Survey & Analysis
    Database-->>BackendAPI: Confirm Save
    BackendAPI-->>MobileApp: Success Response
    MobileApp->>Surveyor: Show "Submitted"
```

**Key Component Interactions:**
- Mobile UI Components collect user input and trigger service calls
- Mobile Services handle API communication and response processing
- Backend API Routers receive and validate requests
- Backend Business Logic coordinates external API calls and data processing
- Database components persist survey data and AI analysis results

### Survey Submission Flow (Offline to Online Sync)

This sequence demonstrates the offline-first architecture's sync capabilities:

```mermaid
sequenceDiagram
    participant Surveyor
    participant MobileApp as Mobile App
    participant OfflineDB as MMKV Storage
    participant BackendAPI as Backend API

    Note over Surveyor, BackendAPI: User is offline
    Surveyor->>MobileApp: Captures Photos & Data
    MobileApp->>OfflineDB: Save Survey to Queue
    OfflineDB-->>MobileApp: Confirm Queued
    MobileApp->>Surveyor: Show "Queued for Sync"

    Note over Surveyor, BackendAPI: User comes online
    MobileApp->>MobileApp: Background Sync Starts
    MobileApp->>OfflineDB: Read Queued Survey
    MobileApp->>BackendAPI: POST /api/surveys
    BackendAPI-->>MobileApp: Success Response
    MobileApp->>OfflineDB: Remove Survey from Queue
```

**Offline Architecture Highlights:**
- MMKV Storage component provides immediate persistence during offline operation
- Mobile Services include intelligent sync logic for queue management
- Background sync processes ensure data consistency when connectivity returns
- State management components track sync status and provide user feedback

---

## 🎯 Component Design Patterns

### API Layer Patterns
- **Router-Service Separation** - API routers handle HTTP concerns, services handle business logic
- **Dependency Injection** - Services are injected into routers for testability
- **Error Handling** - Consistent error formatting across all API endpoints

### Mobile Architecture Patterns
- **Offline-First Design** - All data operations work offline with background sync
- **Component Composition** - Reusable UI components reduce code duplication
- **State Management** - Global state for authentication, local state for forms

### Data Flow Patterns
- **Unidirectional Flow** - Data flows down through components, events flow up
- **Service Layer Abstraction** - Business logic separated from UI and persistence
- **Async Operations** - All external communication handled asynchronously

---

## 📊 Component Interaction Matrix

| Source Component | Target Component | Interaction Type | Protocol |
|------------------|------------------|------------------|----------|
| Mobile Screens | Mobile Services | Method Calls | JavaScript |
| Mobile Services | Backend API | HTTP Requests | REST API |
| Backend Routers | Backend Services | Method Calls | Python |
| Backend Services | Database | ORM Operations | SQLAlchemy |
| Backend Services | External APIs | HTTP Requests | REST/GraphQL |
| Mobile Services | Offline Storage | Read/Write | MMKV |

---

## 🔧 Component Development Guidelines

### Adding New Components
1. **Identify Layer** - Determine which architectural layer the component belongs to
2. **Define Interface** - Specify clear input/output contracts
3. **Consider Dependencies** - Minimize coupling to other components
4. **Plan Testing** - Design components for easy unit and integration testing

### Component Communication Rules
- **API Layer** - Only communicate with business logic services
- **Business Logic** - May call external APIs and data access layer
- **Data Access** - Only communicate with database and storage systems
- **UI Components** - Only communicate with services and state management

### Performance Considerations
- **Mobile Components** - Optimize for battery and memory usage
- **Backend Components** - Design for horizontal scaling and caching
- **Database Components** - Use connection pooling and query optimization

---

## 📋 Related Architecture Documentation

### Detailed Component Information
> 🚀 **Backend Teams**: See [Backend API Components](../backend/api-components.md) for FastAPI implementation details and source code organization
> 📱 **Mobile Teams**: See [Mobile App Components](../mobile/app-components.md) for React Native architecture and offline-first patterns
> 🎯 **Admin Teams**: See [Admin Dashboard Components](../admin/architecture/README.md) for Next.js frontend architecture

### System Architecture Context
- **[Container Architecture](./system-container-overview.md)** - C4 Level-2 view showing system containers and their relationships
- **[System Context](../architecture/system-context.md)** - C4 Level-1 view of external systems and users
- **[Data Flow Architecture](./data-flow-patterns.md)** - Comprehensive data flow patterns across all components

### Implementation Workflows
- **[Testing Guide](../workflows/testing-guide.md)** - Comprehensive testing strategies including component testing
- **[Development Setup](../setup/development-setup.md)** - Environment setup for component development

---

**Status**: ✅ **PRODUCTION ARCHITECTURE REFERENCE**
**Last Updated**: 2025-06-29
**Architecture Level**: C4 Level-3 (Component Architecture)
**Scope**: Cross-system component interactions and relationships

---

*This component architecture documentation provides the essential reference for understanding how Spacewalker's major building blocks work together to deliver survey functionality across mobile, backend, and admin systems with robust offline-first capabilities.*
