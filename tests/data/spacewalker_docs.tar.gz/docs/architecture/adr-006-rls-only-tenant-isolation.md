# ADR-006: RLS-Only Architecture for Multi-Tenant Data Isolation

## Status
**Accepted** - 2025-08-05

## Context
During ENG-345 tenant isolation debugging, we discovered that our multi-tenant architecture used a hybrid approach combining both Row Level Security (RLS) policies at the database level AND explicit tenant filtering at the application level. This dual-layer approach created architectural inconsistency, maintenance complexity, and introduced a critical race condition bug where `get_db()` dependency was prematurely setting RLS context before user authentication.

### Problem Analysis Findings
- **65+ Explicit Tenant Filters**: Scattered across all router files with patterns like `.filter(Building.tenant_id == current_tenant_id)`
- **RLS Policies Ignored**: Application code bypassed database-level security by adding redundant filtering
- **Race Condition Bug**: `get_db()` dependency set super user RLS context before authentication, breaking tenant isolation
- **Maintenance Burden**: Changes required updates in both database policies AND application code
- **Security Risk**: Inconsistent filtering patterns could lead to tenant data leakage

### Root Cause
The hybrid architecture pattern violated the principle of single responsibility:
1. Database RLS policies provided tenant isolation at the storage layer
2. Application code duplicated this logic with explicit tenant filtering
3. FastAPI dependency injection created separate database sessions, causing RLS context race conditions
4. Explicit filtering masked RLS policy failures, reducing security visibility

## Decision
We will **eliminate explicit tenant filtering entirely** and implement a **RLS-only architecture** where tenant isolation is enforced exclusively at the database level through Row Level Security policies.

### Implementation Details

#### Before (Hybrid RLS + Explicit Filtering)
```python
# Application-level explicit filtering (REMOVED)
@router.get("/buildings")
def get_buildings(
    current_tenant_id: int = Depends(get_current_tenant_id),
    db: Session = Depends(get_db),
):
    buildings = (
        db.query(Building)
        .filter(Building.tenant_id == current_tenant_id)  # ❌ Redundant
        .all()
    )
    return buildings
```

#### After (RLS-Only)
```python
# RLS-only approach (CURRENT)
@router.get("/buildings")
def get_buildings(
    current_tenant_id: int = Depends(get_current_tenant_id),  # Sets RLS context
    db: Session = Depends(get_db),
):
    # RLS handles tenant filtering automatically - no explicit filters needed
    buildings = db.query(Building).all()  # ✅ Secure through RLS
    return buildings
```

### Database RLS Policies
```sql
-- Buildings table RLS policy (EXISTING)
CREATE POLICY tenant_isolation_policy ON buildings
USING (tenant_id = get_current_tenant_id() OR get_current_tenant_id() = -1);

-- Super user mode (-1) bypasses RLS for cross-tenant access
-- Regular users only see their tenant's data
```

### Critical Dependency Pattern
```python
# CRITICAL: get_current_tenant_id dependency sets RLS context per session
def get_current_tenant_id(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    x_selected_tenant_id: Optional[str] = Header(None),
) -> int:
    # ... tenant logic ...
    
    # CRITICAL: Ensure RLS context is properly set for this database session
    set_rls_context(db, effective_tenant_id)  # Line 722 in auth.py
    
    return effective_tenant_id
```

## Rationale

### Why RLS-Only Architecture
1. **Single Source of Truth**: Tenant isolation enforced exclusively at database level
2. **Eliminates Race Conditions**: RLS context set once per authenticated session
3. **Reduces Maintenance**: No need to update both policies AND application code
4. **Improves Security**: Database-level enforcement cannot be bypassed by application bugs
5. **Simplifies Code**: Removes 65+ redundant explicit filtering statements
6. **Better Monitoring**: RLS policy violations are logged at database level

### Why Not Hybrid Approach
The hybrid approach failed because:
- **Redundant Security**: Both layers performed the same function
- **Race Conditions**: Multiple database sessions with inconsistent RLS context
- **Maintenance Complexity**: Changes required updates in multiple locations
- **Hidden Failures**: Explicit filtering masked RLS policy issues
- **Performance Overhead**: Unnecessary query complexity

### Technical Implementation Decisions

#### Tables with RLS Policies (RLS-Only)
```sql
-- These tables rely EXCLUSIVELY on RLS for tenant isolation
users, buildings, surveys, ficm_categories, ficm_base_codes, 
ficm_design_types, attribute_categories, attribute_definitions, 
tenant_members, tenant_invitations, tenant_domains
```

#### Tables without RLS (Inherit through Relationships)
```sql
-- These tables inherit tenant isolation through Building relationships
floors, rooms -- No tenant_id column, secured through Building RLS
```

#### Special Cases Preserved
```python
# User queries preserved for cross-tenant superuser access
query = query.filter(User.tenant_id == current_tenant_id)  # ✅ Intentional
```

## Consequences

### Positive
- **65+ Lines Removed**: Eliminated redundant explicit tenant filtering
- **Architectural Consistency**: Single responsibility for tenant isolation
- **Race Condition Fixed**: RLS context properly synchronized per session
- **Security Improvement**: Database-level enforcement cannot be bypassed
- **Maintenance Reduction**: Changes only need database policy updates
- **Performance Optimization**: Simplified queries with fewer filter conditions

### Negative
- **Database Dependency**: Security now entirely dependent on RLS policies being correct
- **Debugging Complexity**: Tenant filtering happens at database level (less visible)
- **Context Management**: Critical dependency on proper RLS context setting

### Mitigation Strategies
- **Comprehensive Testing**: Integration tests verify tenant isolation at all levels
- **RLS Context Monitoring**: Log RLS context setting operations for debugging
- **Database Policy Testing**: Test RLS policies directly with different tenant contexts
- **Documentation**: Clear ADR explaining the architectural decision and dependencies

## Implementation Timeline
- **Bug Discovery**: ENG-345 identified tenant isolation race condition (2025-08-05)
- **Root Cause Analysis**: Discovered hybrid architecture causing complexity (2025-08-05)  
- **Database Fix**: Fixed get_db() premature RLS context setting (2025-08-05)
- **Application Update**: Removed 65+ explicit tenant filters across all routers (2025-08-05)
- **Testing**: Verified tenant isolation with integration tests (2025-08-05)
- **Documentation**: Created ADR-006 documenting architectural decision (2025-08-05)

## Metrics and Success Criteria

### Security Targets
- ✅ **Tenant Isolation**: All tables with RLS policies enforce tenant separation
- ✅ **Race Condition**: Fixed RLS context race condition in dependency injection
- ✅ **Cross-Tenant Access**: Superusers can access all tenants via X-Selected-Tenant-Id header

### Code Quality
- ✅ **Explicit Filters Removed**: 65→2 explicit tenant filters (only User.tenant_id preserved)
- ✅ **Architectural Consistency**: All routers follow same RLS-only pattern
- ✅ **Code Simplification**: Eliminated redundant filtering logic

### Testing
- Integration tests validate tenant isolation end-to-end
- RLS policy testing at database level
- Cross-tenant superuser access verification

## Alternatives Considered

### 1. Fix Hybrid Approach
- **Pros**: Keep existing dual-layer security
- **Cons**: Maintains complexity, doesn't solve race conditions, redundant logic
- **Decision**: Rejected due to architectural complexity

### 2. Application-Only Filtering
- **Pros**: All logic in application layer, easier to debug
- **Cons**: Security can be bypassed by application bugs, no database-level protection
- **Decision**: Rejected due to security concerns

### 3. Middleware-Based Filtering
- **Pros**: Centralized tenant filtering logic
- **Cons**: Still redundant with RLS, adds middleware complexity
- **Decision**: Rejected in favor of database-native solution

### 4. Dynamic Query Modification
- **Pros**: Automatic tenant filter injection
- **Cons**: Complex implementation, performance overhead, debugging difficulty
- **Decision**: Rejected due to implementation complexity

## Related ADRs
- ADR-003: Multi-Tenant Architecture (establishes tenant isolation requirements)
- ADR-004: Database Security Patterns (establishes RLS as security standard)

## References
- **Linear Issue**: ENG-345 - Tenant isolation integration test failures
- **PostgreSQL RLS Documentation**: [Row Level Security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)
- **Migration Files**: 
  - `11a60a9d6337_implement_row_level_security_for_tenant_.py` - Initial RLS policies
  - `ed4a61c4c4c3_fix_users_rls_policy_strict_null_.py` - Users table RLS fix
- **Implementation Details**: 
  - `auth.py:722` - Critical RLS context setting in get_current_tenant_id
  - `database.py:122-131` - Fixed get_db() dependency to remove premature RLS setting

---

**Status**: ✅ Implemented and validated. 65+ explicit tenant filters removed, architectural consistency achieved, tenant isolation security maintained through RLS-only approach.