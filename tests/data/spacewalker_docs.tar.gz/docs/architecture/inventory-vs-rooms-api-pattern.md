# Inventory API vs Rooms API Architecture Pattern

## Executive Summary

SpaceWalker uses two complementary APIs for room management that serve different purposes:
- **Inventory API** (`/inventory/*`): READ operations for survey data, analytics, and reporting
- **Rooms API** (`/rooms/*`): WRITE operations for CRUD management

**Golden Rule: "Read from Inventory, Write to Rooms"**

## The Problem This Solves

Initially, there was confusion about which API to use for room operations, leading to:
- Mixed API usage within the same client
- Unclear boundaries between survey/analytics vs management operations
- Developer confusion about which endpoint serves which purpose

## Architecture Pattern: Unified Read, Separate Write

### Pattern Definition

```typescript
// ALL READ operations use Inventory API (richer data)
rooms.getAll()        → GET /inventory/rooms
rooms.getById()       → GET /inventory/rooms/{id}
rooms.export()        → GET /inventory/rooms/export
rooms.getStatistics() → GET /inventory/statistics

// ALL WRITE operations use Rooms API (CRUD management)
rooms.create()        → POST /rooms
rooms.update()        → PUT /rooms/{id}
rooms.delete()        → DELETE /rooms/{id}

// Special case: Attributes can be updated via inventory
rooms.updateAttributes() → POST /inventory/rooms/{id}/attributes
```

### Why This Pattern?

1. **Inventory API is READ-ONLY** (except attributes)
   - Designed for reporting, analytics, and survey management
   - Returns rich data including survey status, FICM codes, images
   - Cannot handle room creation, updates, or deletion

2. **Rooms API is CRUD-focused**
   - Designed for building structure management
   - Handles create, update, delete operations
   - Returns basic structural data

3. **They complement each other**
   - Not "crossing streams" - using APIs for their intended purposes
   - Inventory = "Reporting View", Rooms = "Management View"

## API Capabilities Comparison

### Inventory API (`/inventory/*`)

**Purpose**: Survey management, analytics, reporting, export

**Endpoints**:
```
GET  /inventory/rooms        - List with survey data
GET  /inventory/rooms/{id}   - Room with survey details
GET  /inventory/rooms/export - Export functionality
GET  /inventory/statistics   - Analytics dashboard
POST /inventory/rooms/{id}/attributes - Update survey attributes
```

**Data Includes**:
- Survey status and history
- FICM classification codes
- Survey images
- Analytics and statistics
- Export formats (CSV, etc.)
- Rich attribute data with confidence scores

**When to Use**:
- Displaying room lists with survey information
- Showing survey completion status
- Exporting room data
- Analytics and reporting
- Viewing historical survey data

### Rooms API (`/rooms/*`)

**Purpose**: Building structure management, CRUD operations

**Endpoints**:
```
GET    /rooms        - List basic room data
GET    /rooms/{id}   - Individual room details
POST   /rooms        - Create new room
PUT    /rooms/{id}   - Update room information
DELETE /rooms/{id}   - Delete room
POST   /rooms/{id}/attributes - Add attributes
DELETE /rooms/{id}/attributes/{id} - Remove attributes
```

**Data Includes**:
- Basic room structure (number, name, type)
- Floor and building relationships
- Area and space type
- Basic attributes

**When to Use**:
- Creating new rooms
- Updating room information
- Deleting rooms
- Managing building structure
- Basic room configuration

## Implementation Guidelines

### Frontend API Client

The `rooms` object in `apps/admin/src/lib/api.ts` follows this pattern:

```typescript
export const rooms = {
  // READ operations → Inventory API
  getAll: async (params) => {
    // Uses /inventory/rooms for rich survey data
    const response = await api.get("/inventory/rooms", { params });
    return response.data;
  },

  // WRITE operations → Rooms API
  create: async (data) => {
    // Uses /rooms for structure management
    const response = await api.post("/rooms", data);
    return response.data;
  },

  update: async (id, data) => {
    // Uses /rooms/{id} for updates
    const response = await api.put(`/rooms/${id}`, data);
    return response.data;
  },

  delete: async (id) => {
    // Uses /rooms/{id} for deletion
    const response = await api.delete(`/rooms/${id}`);
    return response.data;
  },
};
```

### Component Usage

**Room List Page** (showing survey data):
```typescript
// Correct: Uses inventory for rich display
const roomsData = await rooms.getAll({
  building_id,
  survey_status: 'pending'
});
```

**Room Creation Modal**:
```typescript
// Correct: Uses rooms API for creation
const newRoom = await rooms.create({
  floor_id: selectedFloor,
  number: "101",
  name: "Conference Room"
});
```

**Room Management**:
```typescript
// Correct: Uses rooms API for updates
await rooms.update(roomId, {
  name: "Updated Name",
  space_type: "office"
});
```

## Common Pitfalls to Avoid

### ❌ DON'T: Mix APIs inconsistently
```typescript
// BAD: Unpredictable mixing
const room = await api.get("/rooms/123");  // Wrong API for display
await api.post("/inventory/rooms", data);  // Inventory can't create
```

### ❌ DON'T: Assume data models are the same
```typescript
// BAD: Inventory and Rooms return different structures
const room = await rooms.getById(id);  // Returns inventory format
await rooms.update(id, room);          // Expects rooms format
```

### ✅ DO: Transform data when needed
```typescript
// GOOD: Transform between formats if necessary
const inventoryRoom = await rooms.getById(id);
const updateData = {
  name: inventoryRoom.name,
  space_type: inventoryRoom.space_type,
  // Only include fields the rooms API expects
};
await rooms.update(id, updateData);
```

## Migration Path

### Current State (PR #500)
- Mixed API usage causing confusion
- Some operations using wrong endpoints
- Unclear documentation

### Short Term (This Implementation)
- Clear "Read from Inventory, Write to Rooms" pattern
- Comprehensive documentation
- Code comments explaining the pattern

### Long Term Options
1. **Backend Unification**: Extend inventory API to support CRUD
2. **Complete Separation**: Separate frontend clients for clarity
3. **GraphQL Layer**: Unified API gateway abstracting both backends

## Testing Considerations

### Unit Tests
```typescript
// Test that reads use inventory
expect(mockApi.get).toHaveBeenCalledWith("/inventory/rooms", ...);

// Test that writes use rooms
expect(mockApi.post).toHaveBeenCalledWith("/rooms", ...);
```

### Integration Tests
- Verify inventory endpoints return survey-enriched data
- Verify rooms endpoints handle CRUD operations
- Test data transformation between formats

## Developer Checklist

When working with rooms:

- [ ] **Need to display rooms?** → Use `rooms.getAll()` (inventory)
- [ ] **Need survey/FICM data?** → Use inventory endpoints
- [ ] **Creating a room?** → Use `rooms.create()` (rooms API)
- [ ] **Updating room info?** → Use `rooms.update()` (rooms API)
- [ ] **Deleting a room?** → Use `rooms.delete()` (rooms API)
- [ ] **Exporting data?** → Use `rooms.export()` (inventory)
- [ ] **Analytics/stats?** → Use inventory endpoints

## References

- PR #500: Initial discovery of API mixing issue
- Backend Inventory API: `apps/backend/src/spacecargo/api/routers/inventory.py`
- Backend Rooms API: `apps/backend/src/spacecargo/api/routers/rooms.py`
- Frontend API Client: `apps/admin/src/lib/api.ts`

## Questions?

If you're unsure which API to use:
1. Check this document's developer checklist
2. Remember: "Read from Inventory, Write to Rooms"
3. When in doubt, check what data you need:
   - Survey/analytics data? → Inventory
   - Basic CRUD operations? → Rooms
