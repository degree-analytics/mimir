# System Architecture Overview

## Purpose
Comprehensive overview of Spacewalker's system architecture using the C4 model for multi-platform property surveying application.

## When to Use This
- Understanding overall system design and component relationships
- Architectural decisions and technology rationale
- Cross-app architecture patterns and principles
- Keywords: C4 model, system context, architecture principles, technology choices

## Key Concepts
- **C4 Model**: Lightweight architecture visualization at multiple levels (Context, Container, Component)
- **Service-Based Architecture**: Logical decomposition into API, Admin, and Mobile services
- **Containerization First**: Docker-based deployment strategy for consistency
- **Multi-Tenant Security**: Row-level security and tenant isolation patterns

## Architecture Framework

### C4 Model Implementation
We use a lightweight version of the **[C4 model](https://c4model.com/)** to visualize and describe architecture:

- **Level 1: System Context** → ../backend/architecture/system-context.md
- **Level 2: Container Diagram** → ../backend/architecture/container-diagram.md
- **Level 3: Component Diagrams** → ../backend/architecture/component-diagrams.md

### Architecture Principles
Our architectural decisions follow these core principles:

1. **Simplicity & Maintainability**: Prefer simple, well-understood technologies and patterns over complex or novel ones.
2. **Service-Based Architecture**: Decompose the system into logical services (API, Admin, Mobile) with clear responsibilities.
3. **Containerization First**: All services must be containerized with Docker for consistency across development, CI, and production.
4. **Automate Everything**: Use `just` for command running, Alembic for migrations, and GitHub Actions for CI/CD to automate repetitive tasks.
5. **Secure by Design**: Implement security at every layer, from database RLS to authenticated API endpoints.

## Technology Choices

| Area           | Technology                                  | Rationale & ADR                                                                                                  |
| -------------- | ------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| **Backend**    | FastAPI, Python 3.11+                      | High performance, modern Python features, excellent developer experience |
| **Database**   | PostgreSQL                                  | Robust, reliable, and powerful RLS capabilities for multi-tenancy |
| **Mobile App** | React Native (Expo)                         | Cross-platform development with a single codebase |
| **Admin UI**   | Next.js                                     | Powerful React framework for building fast, server-rendered web applications |
| **Auth**       | JWT                                         | Stateless, standard, and well-supported for token-based authentication |

These technology choices are documented and reviewed as part of our architecture evolution process.

## Implementation Guides by Platform

### Backend Architecture
- **API Design Patterns** → ./api-design.md
- **Database Design** → ../backend/architecture/database.md
- **Security Implementation** → ./security-architecture.md
- **Demo Data Management** → ./demo-data-management.md

### Admin Dashboard Architecture
- **Component Structure** → ../admin/architecture/README.md
- **State Management** → ../admin/architecture/state-management.md
- **API Integration** → ../admin/architecture/api-client.md

### Mobile Application Architecture
- **App Structure** → ../mobile/architecture/README.md
- **Navigation Patterns** → ./navigation.md
- **Offline-First Strategy** → ./offline-first.md

## Architecture Evolution Process

Architectural documentation is living and should evolve with the codebase. To make changes:

1. Propose the architectural change and document the rationale.
2. Implement and test the code changes.
3. Update the relevant diagrams and documentation to reflect the new architecture.
4. Review and validate the documentation updates with the team.

## Related Documentation
- Deployment Workflows → ../../workflows/deployment-procedures.md
- Security Architecture Details → ./security-architecture.md
- API Proxy Solution → ./api-proxy-solution.md

---
Last Updated: 2025-06-28
Status: Current
