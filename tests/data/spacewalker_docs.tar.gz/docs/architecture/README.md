# System Architecture Documentation

Technical architecture, design patterns, and system-wide specifications for Spacewalker.

## Purpose
Comprehensive technical architecture documentation using C4 model principles, covering system design patterns, security architecture, and cross-component specifications. Essential reference for architects, senior developers, and technical decision-making.

## When to Use This
- Understanding overall system design and architecture patterns
- Making technical architecture decisions and trade-offs
- Designing new features and system components
- Cross-team architecture coordination and alignment

**Keywords:** system architecture, C4 model, technical design, architecture patterns

---

## Contents

### System Architecture (C4 Model)
- **[System Architecture](../architecture/system-architecture.md)** - Overall system design and technology architecture overview ⭐
- **[System Context](../architecture/system-context.md)** - C4 Level-1 system overview and external dependencies ⭐
- **[System Container Overview](./system-container-overview.md)** - C4 Level-2 container architecture and relationships
- **[Component Diagrams](./component-diagrams.md)** - Detailed component relationships and interactions

### Architecture Patterns & Design
- **[Runtime Sequences](../architecture/runtime-sequences.md)** - Cross-system interaction patterns and data flow ⭐
- **[Data Flow Patterns](./data-flow-patterns.md)** - Data movement and transformation patterns
- **[Security Architecture](./security-architecture.md)** - Security patterns, authentication, and authorization design

### Architecture Standards
- **[Architecture Requirements](../architecture/architecture-requirements.md)** - Technical architecture standards and constraints

### Architecture Decision Records (ADRs)
- **[ADR-005: CI/CD Cache-Only Architecture](./adr-005-ci-cd-cache-optimization.md)** - Dependency distribution optimization
- **[ADR-006: RLS-Only Tenant Isolation](./adr-006-rls-only-tenant-isolation.md)** - Multi-tenant data isolation approach ⭐

---

## Architecture Overview

The Spacewalker system follows a **service-based architecture** with clear separation of concerns:

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Mobile App    │    │ Admin Dashboard │    │   Backend API   │
│ React Native    │────│     Next.js     │────│     FastAPI     │
│   (Expo)        │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
                              ┌─────────────────────────┼─────────────────────────┐
                              │                         │                         │
                    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
                    │   PostgreSQL    │    │      Redis      │    │    S3 Storage   │
                    │   Database      │    │     Cache       │    │   File Store    │
                    └─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Key Architecture Principles
- **Multi-Tenant Design**: Row-level security and tenant isolation
- **Offline-First Mobile**: Local storage with cloud synchronization
- **Containerized Deployment**: Docker-based deployment strategy
- **API-First Development**: RESTful APIs with clear contracts

---

## Quick Navigation

### For Architects
- **System Overview:** [System Architecture](../architecture/system-architecture.md) - Complete technical architecture
- **External Dependencies:** [System Context](../architecture/system-context.md) - Integration landscape

### For Developers
- **Component Design:** [Component Diagrams](./component-diagrams.md) - Implementation guidance
- **Data Flow:** [Runtime Sequences](../architecture/runtime-sequences.md) - Cross-system interactions

### For Security Teams
- **Security Design:** [Security Architecture](./security-architecture.md) - Comprehensive security patterns
- **Data Protection:** [Data Flow Patterns](./data-flow-patterns.md) - Data handling and privacy

### For DevOps Teams
- **Requirements:** [Architecture Requirements](../architecture/architecture-requirements.md) - Infrastructure constraints
- **Container Design:** [System Container Overview](./system-container-overview.md) - Deployment architecture

---

## Related Documentation

### Component-Specific Architecture
- **[Backend Architecture](../backend/architecture/)** - FastAPI service architecture and database design
- **[Mobile Architecture](../mobile/architecture/)** - React Native app architecture and offline patterns
- **[Admin Architecture](../admin/architecture/)** - Next.js dashboard architecture and admin workflows

### Implementation Guides
- **[Development Setup](../setup/)** - Environment configuration for architectural components
- **[Deployment Workflows](../workflows/)** - Infrastructure deployment and operational procedures

---

**Last Updated:** 2025-06-29
**Status:** Current - Reorganized from workflows directory with enhanced navigation
