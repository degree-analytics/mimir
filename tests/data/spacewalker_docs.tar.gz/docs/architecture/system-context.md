# System Context Diagram

## Purpose
Foundational C4 Level-1 system context view of the Spacewalker platform, showing the system as a unified solution with its external actors and dependencies. Essential reference for understanding system boundaries, trust zones, external integrations, and actor relationships across all system components. Critical context for all development teams (backend, mobile, admin) to understand their component's role within the broader system architecture.

## When to Use This
- Understanding overall system architecture and external dependencies
- Onboarding new developers to the Spacewalker platform
- Planning integrations with external systems and services
- Defining security boundaries and trust zones
- Architecting features that span multiple system components
- Keywords: C4 architecture, system context, external dependencies, trust boundaries, integration architecture

**Version:** 2.3 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production System Context Reference

---

## 🏗️ C4 Level-1 System Context Overview

The following diagram presents Spacewalker as a single system box, highlighting its position within the broader ecosystem of users, external services, and organizational systems.

```mermaid
graph TB
    %% External Actors
    Surveyor["👤 Field Surveyor<br/><i>University facilities staff</i>"]
    Admin["👤 System Administrator<br/><i>IT staff</i>"]
    Manager["👤 Facilities Manager<br/><i>Department head</i>"]
    SuperUser["👤 Super User<br/><i>Enterprise admin</i>"]

    %% Spacewalker System (Single Box)
    SpaceCargo[["🏢 Spacewalker System<br/><b>Multi-tenant Facility Inventory Platform</b><br/><i>React Native Mobile + Next.js Admin + FastAPI Backend</i>"]]

    %% External Systems
    Gemini["🤖 Google Gemini API<br/><i>External AI Service</i><br/><i>Vision analysis & FICM classification</i>"]
    SSO["🔐 University SSO<br/><i>[PLANNED] Authentication Provider</i><br/><i>SAML / OAuth 2.0</i>"]
    Storage["📁 AWS S3 Storage<br/><i>Image & Document Storage</i><br/><i>Multi-tenant isolation</i>"]
    Email["📧 Email Service<br/><i>SMTP Notifications</i><br/><i>Survey & approval alerts</i>"]
    CloudWatch["📊 AWS CloudWatch<br/><i>Monitoring & Observability</i><br/><i>Metrics & log aggregation</i>"]

    %% User Interactions
    Surveyor -->|"Captures photos & submits surveys<br/>📱 Mobile App [Implemented]"| SpaceCargo
    Admin -->|"Manages users & buildings<br/>🌐 Admin Dashboard [Implemented]"| SpaceCargo
    Manager -->|"Approves surveys & exports reports<br/>🌐 Admin Dashboard [Implemented]"| SpaceCargo
    SuperUser -->|"Manages tenants & system settings<br/>🌐 Admin Dashboard [Implemented]"| SpaceCargo

    %% External System Integrations
    SpaceCargo -.->|"User authentication<br/>🔄 SSO Integration [Planned]"| SSO

    SpaceCargo -->|"AI image analysis requests<br/>🤖 REST API [Implemented]"| Gemini
    Gemini -->|"FICM codes & room attributes<br/>📋 Structured responses [Implemented]"| SpaceCargo

    SpaceCargo -->|"Survey image storage<br/>📁 S3 API [Implemented]"| Storage
    Storage -->|"Secure image retrieval<br/>🔗 Signed URLs [Implemented]"| SpaceCargo

    SpaceCargo -->|"Survey & approval notifications<br/>📧 SMTP [Implemented]"| Email

    SpaceCargo -->|"Application metrics & logs<br/>📊 CloudWatch API [Implemented]"| CloudWatch

    %% Styling
    classDef person fill:#1168BD,stroke:#0B4884,color:#ffffff
    classDef system fill:#438DD5,stroke:#2E6295,color:#ffffff
    classDef external fill:#999999,stroke:#666666,color:#ffffff
    classDef planned fill:#FFB366,stroke:#E6901A,color:#ffffff

    class Surveyor,Admin,Manager,SuperUser person
    class SpaceCargo system
    class Gemini,Storage,Email,CloudWatch external
    class SSO planned
```

---

## 👥 Primary System Actors

### User Categories and Access Patterns

| Actor Type | Organizational Role | Primary Interface | Core Responsibilities | Access Level |
|------------|-------------------|------------------|---------------------|--------------|
| **Field Surveyor** | Facilities staff | 📱 Mobile App | Room data capture, photo submission, offline surveys | Tenant-scoped |
| **System Administrator** | IT staff | 🌐 Admin Dashboard | User management, building configuration, system settings | Admin-level |
| **Facilities Manager** | Department heads | 🌐 Admin Dashboard | Survey approval, data validation, report generation | Manager-level |
| **Super User** | Enterprise administrators | 🌐 Admin Dashboard | Multi-tenant oversight, system-wide configuration | Super-user |

### User Journey Patterns

#### Field Surveyor Workflow
1. **Authentication** → Mobile app login with tenant context
2. **Room Selection** → Building and room navigation interface
3. **Data Capture** → Photo capture with device camera integration
4. **Offline Support** → Local storage with background synchronization
5. **Submission** → Survey upload with AI analysis triggering

#### Administrative Workflow
1. **Dashboard Access** → Web interface with role-based navigation
2. **Survey Review** → AI-assisted data validation and approval
3. **Report Generation** → Data export and analytics interface
4. **User Management** → Tenant-scoped administrative operations
5. **System Configuration** → Platform settings and customization

---

## 🔗 External System Dependencies

### Current Integrations (Implemented)

| External System | Purpose | Integration Method | Status | SLA/Limits |
|----------------|---------|-------------------|--------|------------|
| **Google Gemini API** | AI-powered room image analysis | REST API with structured prompts | ✅ Implemented | 60 req/min, 2-5s response |
| **AWS S3** | Survey image and document storage | S3 API with signed URL access | ✅ Implemented | 99.999999999% durability |
| **SMTP Email Service** | Survey notifications and alerts | SMTP protocol | ✅ Implemented | Async delivery |
| **AWS CloudWatch** | Application monitoring and logging | CloudWatch API | ✅ Implemented | Real-time metrics |

### Planned Integrations

| External System | Purpose | Integration Method | Timeline | Dependencies |
|----------------|---------|-------------------|----------|--------------|
| **University SSO** | Single Sign-On authentication | SAML 2.0 / OAuth 2.0 | Q2 2025 | Customer requirements |
| **Enterprise Directory** | User provisioning and management | LDAP / Active Directory | Q3 2025 | SSO integration |
| **Business Intelligence** | Advanced analytics and reporting | REST API / Data export | Q4 2025 | Data warehouse |

### Integration Architecture Patterns

#### AI Service Integration (Gemini API)
- **Authentication**: API key-based authentication with rate limiting
- **Error Handling**: Exponential backoff with fallback to cached responses
- **Data Flow**: Image → Structured prompt → AI analysis → FICM classification
- **Performance**: 24-hour response caching for identical image/prompt combinations

#### Storage Integration (AWS S3)
- **Security**: Tenant-isolated buckets with signed URL access
- **Performance**: Multi-part upload for large images with CDN distribution
- **Backup**: Cross-region replication for disaster recovery
- **Access Control**: IAM-based bucket policies with time-limited access

---

## 🔒 Trust Boundaries and Security Architecture

### Security Zone Definitions

#### Internal Zone (High Trust)
- **Backend Services**: FastAPI application servers and database connections
- **Database Communication**: PostgreSQL with encrypted connections
- **Service Mesh**: Internal service-to-service communication
- **Monitoring**: CloudWatch agents and internal metrics collection

#### Authenticated Zone (Medium Trust)
- **Mobile Applications**: React Native apps with JWT authentication
- **Admin Dashboard**: Next.js web interface with session management
- **API Gateway**: Request validation and rate limiting
- **User Context**: Tenant-scoped data access and role-based permissions

#### External Zone (Low Trust)
- **Third-party APIs**: Google Gemini and other external service integrations
- **Public Internet**: CDN and public-facing load balancers
- **External Authentication**: SSO providers and identity federation
- **Monitoring Services**: External observability and security scanning

### Security Implementation Patterns

#### Authentication and Authorization
- **JWT Tokens**: Stateless authentication with tenant context
- **Role-Based Access Control**: Granular permissions per user type
- **Multi-tenant Isolation**: Strict data separation at the database level
- **Session Management**: Secure token storage with automatic renewal

#### Data Protection
- **Encryption in Transit**: TLS 1.3 for all external communications
- **Encryption at Rest**: AES-256 encryption for stored data
- **Tenant Isolation**: Logical separation with row-level security
- **Audit Logging**: Comprehensive activity tracking for compliance

---

## 📊 High-Level Data Flow Patterns

### 1. Room Survey Workflow (End-to-End)

**Actors**: Field Surveyor → System → Facilities Manager

**Flow Overview**:
1. **Mobile Capture** → Photo capture with device camera and metadata collection
2. **Local Processing** → Image compression and offline storage with MMKV
3. **Backend Submission** → Survey creation with multi-part image upload
4. **AI Analysis** → Automated Gemini API integration for room classification
5. **Review Process** → Administrative review and approval workflow
6. **Notification** → Automated stakeholder notification via email

> 📱 **Detailed Flow**: See [Runtime Sequences - Room Survey Upload](./runtime-sequences.md#room-survey-upload) for complete sequence diagram

### 2. Administrative Review Workflow

**Actors**: System Administrator/Manager → System → Surveyor

**Flow Overview**:
1. **Dashboard Access** → Role-based administrative interface
2. **Survey Review** → AI-assisted data validation and manual verification
3. **Approval Decision** → Accept/reject with detailed feedback
4. **Data Updates** → Room attribute updates and FICM classification
5. **Audit Trail** → Complete activity logging for compliance

> 🌐 **Detailed Flow**: See [Runtime Sequences - Admin Survey Review](./runtime-sequences.md#admin-survey-review--approval) for complete sequence diagram

### 3. Multi-tenant Data Isolation

**Actors**: All Users → System → Database

**Flow Overview**:
1. **Authentication** → JWT token with tenant context establishment
2. **Request Processing** → Automatic tenant filtering at middleware level
3. **Database Access** → Row-level security with tenant ID filtering
4. **Response Scoping** → Data limited to authenticated tenant context
5. **Audit Compliance** → Cross-tenant access prevention and logging

> 🏢 **Detailed Implementation**: See [Runtime Sequences - Super User Tenant Switching](./runtime-sequences.md#super-user-tenant-switching) for tenant management flows

---

## 🔄 System Integration Architecture

### Horizontal Integration (Cross-System)

#### Mobile ↔ Backend Integration
- **Protocol**: HTTPS REST API with JSON payloads
- **Authentication**: JWT bearer tokens with tenant context
- **Offline Support**: Local MMKV storage with background synchronization
- **Error Handling**: Retry logic with exponential backoff

#### Admin Dashboard ↔ Backend Integration
- **Protocol**: HTTPS REST API with real-time WebSocket updates
- **Authentication**: Session-based authentication with CSRF protection
- **State Management**: React Context with optimistic UI updates
- **Performance**: Query optimization with result caching

### Vertical Integration (External Services)

#### AI Service Integration (Gemini)
- **Purpose**: Automated room image analysis and FICM classification
- **Protocol**: HTTPS REST API with multipart image upload
- **Rate Limiting**: 60 requests per minute with intelligent queuing
- **Caching**: 24-hour response cache for performance optimization

#### Storage Integration (AWS S3)
- **Purpose**: Scalable image and document storage with CDN distribution
- **Protocol**: S3 API with signed URL access for security
- **Performance**: Multi-part upload with parallel processing
- **Backup**: Cross-region replication for disaster recovery

---

## 📋 Related System Architecture Documentation

### Detailed Architecture Views
> 🏗️ **Container Architecture**: See [System Container Overview](./system-container-overview.md) for C4 Level-2 container architecture
> 🔄 **Runtime Sequences**: See [Runtime Sequences](../architecture/runtime-sequences.md) for detailed cross-system interaction patterns
> 🔗 **Integration Patterns**: See [Integration Architecture](./system-container-overview.md) for comprehensive integration implementation

### Component-Specific Architecture
- **[Mobile Architecture](../mobile/architecture/mobile-container-architecture.md)** - React Native application architecture and offline-first patterns
- **[Backend Architecture](../backend/architecture/backend-container-architecture.md)** - FastAPI services, database design, and API architecture
- **[Admin Architecture](../admin/architecture/admin-container-architecture.md)** - Next.js dashboard architecture and component organization

### Infrastructure and Operations
- **[AWS Infrastructure Guide](../workflows/aws-deployment-guide.md)** - Complete AWS deployment architecture and infrastructure as code
- **[Security Architecture](./security-architecture.md)** - Comprehensive security implementation across all system boundaries
- **[Monitoring and Observability](../workflows/deployment-guide.md)** - System-wide monitoring, logging, and performance tracking

---

**Status**: ✅ **PRODUCTION SYSTEM CONTEXT REFERENCE**
**Last Updated**: 2025-06-29
**Scope**: System-wide Architecture, External Dependencies, Trust Boundaries, Integration Patterns
**Architecture Level**: C4 Level-1 (System Context)

---

*This system context documentation provides the foundational architectural overview for understanding Spacewalker's position within the broader ecosystem of users, external services, and organizational systems, serving as essential context for all development teams and architectural decisions.*
