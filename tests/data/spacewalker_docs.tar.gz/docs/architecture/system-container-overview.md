# Spacewalker System Container Architecture (C4 Level-2)

## Purpose
Comprehensive C4 Level-2 Container diagram showing all major deployable units (containers) of the Spacewalker system and their interactions. Essential architectural reference for understanding system boundaries, technology stack distribution, data flow patterns, and security architecture across the entire platform.

## When to Use This
- Understanding overall system architecture and container relationships
- Planning cross-system features and integration points
- Analyzing data flow and security boundaries
- Onboarding developers to the complete system architecture
- Making architectural decisions that affect multiple containers
- Keywords: C4 architecture, system containers, technology stack, data flow, security boundaries

**Version:** 2.1 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production System Architecture

---

## 🏗️ System Architecture Overview

This diagram shows the major deployable units (containers) of the Spacewalker system, illustrating how applications and data stores work together to deliver the platform's survey functionality across mobile, web, and backend services.

### Architectural Principles
- **Container Isolation** - Each container has a single, well-defined responsibility
- **API-First Design** - All communication through well-defined REST interfaces
- **Security Gateway Pattern** - Backend API acts as secure gateway to data layer
- **Technology Diversity** - Each container optimized for its specific purpose

---

## 📊 Complete System Container Diagram

```mermaid
graph TB
    %% External Actors
    Surveyor["👤 Field Surveyor"]
    Admin["👤 System Admin / Manager"]

    %% External Systems
    Gemini["🤖 Google Gemini API"]
    Email["📧 Email Service"]

    %% Spacewalker Containers
    subgraph "Spacewalker System [Live Environment]"
        direction LR

        subgraph "Clients"
            direction TB
            Mobile["📱 Mobile Application<br/><b>React Native / Expo 52</b><br/><i>[Implemented]</i>"]
            AdminWeb["💻 Admin Dashboard<br/><b>Next.js 15.5.3</b><br/><i>[Implemented]</i>"]
        end

        subgraph "Backend Services"
            direction TB
            Backend["⚙️ Backend API<br/><b>FastAPI 0.115.6</b><br/><i>[Implemented]</i>"]
        end

        subgraph "Data Stores"
            direction TB
            Database["🗄️ PostgreSQL Database<br/><b>PostgreSQL 17</b><br/><i>[Implemented]</i>"]
            FileStore["📁 File Storage<br/><b>S3-compatible</b><br/><i>[Implemented]</i>"]
        end
    end

    %% User Interactions
    Surveyor -->|Uses via HTTPS| Mobile
    Admin -->|Uses via HTTPS| AdminWeb

    %% Container Communications
    Mobile -->|REST API (JSON/HTTPS)| Backend
    AdminWeb -->|REST API (JSON/HTTPS)| Backend

    Backend -->|"SQLAlchemy (TCP)"| Database
    Backend -->|"S3 API"| FileStore

    %% External Integrations
    Backend -->|"REST API (HTTPS)"| Gemini
    Backend -->|"SMTP"| Email

    %% Style Definitions
    classDef person fill:#1168BD,stroke:#0B4884,color:#ffffff
    classDef system fill:#438DD5,stroke:#2E6295,color:#ffffff
    classDef external fill:#999999,stroke:#666666,color:#ffffff
    class Surveyor,Admin person
    class Mobile,AdminWeb,Backend,Database,FileStore system
    class Gemini,Email external
```

---

## 🎯 Container Responsibilities

### Client Containers
- **📱 Mobile Application** - Field surveyor interface with offline capabilities
- **💻 Admin Dashboard** - System administration and survey management web interface

### Service Containers
- **⚙️ Backend API** - Core business logic, authentication, and data orchestration

### Data Containers
- **🗄️ PostgreSQL Database** - Structured data persistence with multi-tenancy
- **📁 File Storage** - Unstructured data storage for survey images and documents

### External Systems
- **🤖 Google Gemini API** - AI-powered image analysis and survey processing
- **📧 Email Service** - Notification and communication delivery

---

## 🔄 Cross-Container Data Flow

### Survey Submission Workflow
```
Mobile App → Backend API → PostgreSQL Database
     ↓           ↓              ↓
Photo Upload → File Storage → AI Analysis (Gemini)
     ↓           ↓              ↓
Admin Dashboard ← Backend API ← Analysis Results
```

### Authentication & Authorization Flow
```
User Login → Mobile/Admin → Backend API → PostgreSQL
    ↓            ↓              ↓            ↓
JWT Token ← JSON Response ← Auth Service ← User Validation
    ↓            ↓              ↓            ↓
Stored Local ← Client Storage ← Token Issue ← Session Create
```

### Offline Synchronization Pattern
```
Mobile (Offline) → Local Storage (MMKV) → Background Sync Queue
       ↓                   ↓                      ↓
Network Available → Sync Service → Backend API → Database
       ↓                   ↓              ↓         ↓
Status Update ← Mobile UI ← Response ← Data Persistence
```

---

## 🔐 Security Architecture

### Security Boundaries
- **Client Layer** - JWT token storage and validation
- **API Gateway** - Backend API acts as secure gateway for all data access
- **Data Layer** - No direct client access to database or file storage
- **External Integration** - Secure API communication with external services

### Communication Security
- **HTTPS Everywhere** - All client-to-backend communication encrypted
- **JWT Authentication** - Stateless authentication with token expiration
- **API Authorization** - Role-based access control at endpoint level
- **Database Security** - Connection pooling with credential management

### Data Protection
- **Row-Level Security** - Multi-tenant data isolation in PostgreSQL
- **File Access Control** - Signed URLs for S3 file access
- **API Rate Limiting** - Protection against abuse and DoS attacks
- **Audit Logging** - Comprehensive logging of all data access

---

## 🚀 Technology Stack Distribution

### Frontend Technologies
- **Mobile**: React Native, Expo SDK 52, TypeScript, MMKV Storage
- **Admin**: Next.js 15.5.3, React, TypeScript, Tailwind CSS

### Backend Technologies
- **API Server**: FastAPI 0.115.6, Python 3.12, SQLAlchemy, Pydantic
- **Database**: PostgreSQL 17 with Row-Level Security
- **File Storage**: S3-compatible object store (AWS S3/MinIO)

### External Integrations
- **AI Processing**: Google Gemini API for image analysis
- **Email Delivery**: SMTP service for notifications
- **Authentication**: JWT-based stateless authentication

### DevOps & Infrastructure
- **Containerization**: Docker and Docker Compose
- **Development**: Justfile automation, development scripts
- **Testing**: Comprehensive unit and integration test suites

---

## 📈 Container Scaling Patterns

### Horizontal Scaling Capabilities
- **Backend API** - Stateless design supports multiple instances
- **Mobile Application** - Client-side scaling through app distribution
- **Admin Dashboard** - Static assets with CDN distribution
- **Database** - Read replicas and connection pooling
- **File Storage** - S3-compatible storage auto-scales

### Performance Optimization
- **API Caching** - Response caching at backend layer
- **Database Optimization** - Query optimization and indexing strategies
- **File Delivery** - CDN integration for image delivery
- **Client Optimization** - Offline-first design reduces server load

---

## 🔧 Container Interaction Protocols

### API Communication Standards
- **REST API** - RESTful endpoints with JSON payloads
- **HTTP Methods** - Standard GET, POST, PUT, DELETE operations
- **Response Formats** - Consistent JSON response structure
- **Error Handling** - Standardized error codes and messages

### Data Synchronization Protocols
- **Real-time Updates** - WebSocket connections for live data
- **Batch Operations** - Bulk data transfer for efficiency
- **Conflict Resolution** - Last-write-wins with timestamp validation
- **Retry Logic** - Exponential backoff for failed operations

### File Transfer Protocols
- **Upload Process** - Direct S3 upload with signed URLs
- **Download Access** - Temporary access URLs for security
- **Image Processing** - Automatic thumbnail generation
- **Storage Lifecycle** - Automated cleanup and archival policies

---

## 📋 Container-Specific Documentation

### Detailed Container Architecture
> 📱 **Mobile Teams**: See [Mobile Container Architecture](../mobile/architecture/mobile-container-architecture.md) for React Native implementation details
> 🎯 **Admin Teams**: See [Admin Container Architecture](../admin/architecture/admin-container-architecture.md) for Next.js dashboard architecture
> 🚀 **Backend Teams**: See [Backend Container Architecture](../backend/architecture/backend-container-architecture.md) for FastAPI and database design

### Cross-Container Workflows
- **[Cross-Container Workflows](./data-flow-patterns.md)** - Detailed authentication flow, data sync patterns, and integration procedures
- **[Component Architecture](./component-diagrams.md)** - C4 Level-3 view of components within each container

### System Architecture Context
- **[System Context Diagram](../architecture/system-context.md)** - C4 Level-1 view showing external systems and users
- **[Deployment Architecture](../workflows/aws-deployment-guide.md)** - Infrastructure and deployment container configurations

### Implementation Resources
- **[Development Setup](../setup/development-setup.md)** - Environment configuration for all containers
- **[Testing Strategy](../workflows/testing-strategy.md)** - Container testing and integration verification
- **[Security Implementation](./security-architecture.md)** - Detailed security patterns and configurations

---

**Status**: ✅ **PRODUCTION SYSTEM ARCHITECTURE**
**Last Updated**: 2025-06-29
**Architecture Level**: C4 Level-2 (Container Architecture)
**Scope**: Complete Spacewalker system container relationships and interactions

---

*This system container overview provides the essential architectural reference for understanding how all Spacewalker components work together to deliver survey functionality across mobile, web, and backend services with robust security and scalability.*
