# Runtime Sequence Diagrams

## Purpose
Comprehensive runtime sequence diagrams for Spacewalker's critical business processes, showing how distributed components interact during key user workflows. Essential reference for understanding cross-system integration patterns, debugging distributed operations, and validating end-to-end system behavior across mobile, backend, and external service boundaries.

## When to Use This
- Understanding complete end-to-end user workflows across system boundaries
- Debugging issues that span multiple system components
- Designing new features that require cross-system coordination
- Validating system integration patterns and data flow consistency
- Onboarding developers to understand system interaction patterns
- Keywords: sequence diagrams, integration patterns, cross-system flows, distributed architecture, workflow orchestration

**Version:** 2.3 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production Runtime Sequence Reference

---

## 📋 Use Case Overview

The following table provides an overview of critical business processes and their implementation complexity across the Spacewalker system:

| Use Case | Priority | Actors | Primary Flow | Complexity | Section |
|----------|----------|--------|--------------|------------|---------|
| **User Login & Authentication** | High | Surveyor, Admin, Manager | Login → Token → Dashboard | Low | [Section 1](#user-login--authentication) |
| **Room Survey Upload** | High | Surveyor | Photo capture → Upload → Metadata | Medium | [Section 2](#room-survey-upload) |
| **AI Image Analysis** | High | System, Surveyor | Image → Gemini API → Attributes | Medium | [Section 3](#ai-image-analysis) |
| **Survey Review & Approval** | High | Manager | Review → Approve/Reject → Notifications | Medium | [Section 4](#admin-survey-review--approval) |
| **AI Prompt Engineering** | Medium | Super User | Prompt → Test → Deploy | Medium | [Section 5](#ai-prompt-engineering) |
| **Super User Tenant Switching** | High | Super User | Select → Context → Data Filter | Low | [Section 6](#super-user-tenant-switching) |
| **Dynamic Attribute Management** | Medium | Admin | Create → Configure → Deploy | Medium | [Section 7](#dynamic-attribute-management) |
| **Offline Survey Sync** | Medium | Surveyor | Offline Storage → Connectivity → Sync | High | [Section 8](#offline-survey-synchronization) |
| **Report Export** | Medium | Admin, Manager | Query → Aggregate → Generate → Download | Medium | [Planned] |
| **Multi-tenant Data Isolation** | High | All Users | Request → Tenant Context → Filtered Data | Low | [Integrated] |

---

## 1. User Login & Authentication

### Authentication Flow Overview

Cross-platform authentication supporting both mobile and web applications with JWT-based security and tenant context establishment.

> 📱 **Mobile Implementation**: See [Development Patterns](../mobile/development-patterns.md) for React Native-specific login implementation
> 🌐 **Admin Implementation**: See [Admin Architecture](../admin/architecture/README.md) for web dashboard authentication patterns
> 🔒 **Backend Implementation**: See [API Development Guide](../backend/api-development.md) for FastAPI authentication endpoint details

```mermaid
sequenceDiagram
    participant User as User (Mobile/Web)
    participant Frontend as Frontend App
    participant AuthRouter as Auth Router
    participant DB as PostgreSQL
    participant TenantMiddleware as Tenant Middleware

    User->>Frontend: Enter credentials
    Frontend->>AuthRouter: POST /login
    AuthRouter->>DB: Query user by email
    DB-->>AuthRouter: User record
    AuthRouter->>AuthRouter: Verify password (bcrypt)

    alt Password Valid
        AuthRouter->>DB: Query tenant membership
        DB-->>AuthRouter: Tenant roles
        AuthRouter->>AuthRouter: Generate JWT token
        AuthRouter-->>Frontend: Token + user data
        Frontend->>Frontend: Store token (SecureStore/localStorage)
        Frontend->>TenantMiddleware: Set tenant context
        Frontend-->>User: Dashboard/Home screen
    else Password Invalid
        AuthRouter-->>Frontend: 401 Unauthorized
        Frontend-->>User: Error message
    end

    Note over AuthRouter: JWT includes user_id, tenant_id, roles, exp
    Note over Frontend: Token auto-renewal before expiration
```

### Authentication Security Features

- **JWT Token Structure**: Includes user_id, tenant_id, roles, and expiration
- **Password Security**: bcrypt hashing with salt rounds
- **Token Storage**: SecureStore (mobile) / localStorage (web) with automatic renewal
- **Multi-tenant Context**: Automatic tenant context establishment post-authentication
- **Session Management**: 15-minute access tokens with 7-day refresh tokens

---

## 2. Room Survey Upload

### Mobile Survey Workflow

Complete survey capture and upload process supporting offline-first operation with automatic synchronization.

> 📱 **Mobile Implementation**: See [Offline-First Architecture](../mobile/architecture/offline-first.md) for React Native camera integration and local storage
> 📂 **File Handling**: See [API Development Guide](../backend/api-development.md) for backend file processing and storage implementation
> 🔄 **Offline Support**: See [Offline-First Architecture](../mobile/architecture/offline-first.md) for local storage and queue management

```mermaid
sequenceDiagram
    participant Surveyor as Surveyor
    participant Mobile as Mobile App
    participant Camera as Device Camera
    participant Storage as Local Storage
    participant Backend as Backend API
    participant FileSystem as File Storage
    participant DB as PostgreSQL

    Surveyor->>Mobile: Select room for survey
    Mobile->>Mobile: Load room details & FICM codes
    Surveyor->>Mobile: Tap "Capture Photos"
    Mobile->>Camera: Request camera access
    Camera-->>Mobile: Permission granted

    loop For each photo
        Surveyor->>Camera: Take photo
        Camera-->>Mobile: Image data + metadata
        Mobile->>Mobile: Compress & validate image
        Mobile->>Storage: Store locally (offline support)
    end

    Surveyor->>Mobile: Review & submit survey
    Mobile->>Mobile: Validate required fields

    alt Online
        Mobile->>Backend: POST /api/surveys (create survey)
        Backend->>DB: Insert survey record
        DB-->>Backend: Survey ID

        loop For each image
            Mobile->>Backend: POST /api/surveys/{survey_id}/images
            Backend->>FileSystem: Save image file
            Backend->>DB: Insert survey_image record
        end

        Backend-->>Mobile: Survey created successfully
        Mobile->>Storage: Clear local cache
        Mobile-->>Surveyor: Success confirmation
    else Offline
        Mobile->>Storage: Queue for sync
        Mobile-->>Surveyor: Saved locally (will sync)
    end
```

### Survey Upload Performance Optimization

- **Image Compression**: Client-side compression before upload
- **Parallel Upload**: Up to 3 concurrent image uploads
- **Local Validation**: Client-side validation to reduce server load
- **Progressive Upload**: Survey metadata uploaded before images
- **Offline Queue**: MMKV-based local storage for offline operation

---

## 3. AI Image Analysis

### Gemini API Integration Workflow

Automated room image analysis using Google's Gemini API with intelligent caching and attribute extraction.

> 🤖 **AI Implementation**: See [API Development Guide](../backend/api-development.md) for Gemini API integration and prompt management
> 📝 **Prompt Engineering**: See [Backend Architecture](../backend/architecture/backend-container-architecture.md) for prompt template administration
> ⚡ **Performance**: See [API Development Guide](../backend/api-development.md) for caching and rate limiting strategies

```mermaid
sequenceDiagram
    participant System as System
    participant AIRouter as AI Router
    participant PromptService as Prompt Service
    participant GeminiAPI as Gemini API
    participant AttributeService as Attribute Service
    participant DB as PostgreSQL
    participant Cache as Prompt Cache

    System->>AIRouter: POST /api/ai/analyze-room-image
    AIRouter->>PromptService: Get analysis prompt template
    PromptService->>DB: Query tenant-specific prompts
    DB-->>PromptService: Prompt template

    AIRouter->>AttributeService: Get tenant attribute definitions
    AttributeService->>DB: Query attribute categories
    DB-->>AttributeService: Attribute schema

    AIRouter->>AIRouter: Build analysis prompt
    AIRouter->>Cache: Check prompt cache

    alt Cache Miss
        AIRouter->>GeminiAPI: POST /generateContent
        Note over GeminiAPI: Image + structured prompt
        GeminiAPI-->>AIRouter: Analysis JSON response
        AIRouter->>Cache: Store response
    else Cache Hit
        Cache-->>AIRouter: Cached response
    end

    AIRouter->>AttributeService: Validate & normalize attributes
    AttributeService->>AttributeService: Apply FICM mappings
    AIRouter->>DB: Store AI-generated attributes
    Note over AIRouter: Stores via Survey/Room attribute models

    AIRouter-->>System: Structured attribute data

    Note over GeminiAPI: Rate limiting: 60 requests/minute
    Note over Cache: TTL: 24 hours for identical prompts
```

### AI Analysis Performance Characteristics

- **Response Time**: 2-5 seconds per image analysis
- **Rate Limiting**: 60 requests per minute (Gemini API)
- **Cache Strategy**: 24-hour Redis cache for identical prompts
- **Batch Processing**: Queue-based processing for high-volume scenarios
- **FICM Integration**: Automatic mapping to Facility Inventory Classification Method codes

---

## 4. Admin Survey Review & Approval

### Administrative Workflow Management

Complete survey review and approval process for quality assurance and data validation.

> 🌐 **Admin Dashboard**: See [Admin Architecture](../admin/architecture/README.md) for web interface implementation
> 📧 **Notifications**: See [API Development Guide](../backend/api-development.md) for automated notification workflows
> 🔍 **Audit Trails**: See [Database Design](../backend/database-design.md) for comprehensive activity tracking

```mermaid
sequenceDiagram
    actor Admin as Admin/Manager
    participant Web as Admin Dashboard
    participant API as Backend API
    participant Auth as Auth Middleware
    participant DB as PostgreSQL
    participant Email as Email Service
    participant Storage as File Storage

    Admin->>Web: Navigate to surveys
    Web->>API: GET /api/surveys?status=pending
    API->>Auth: Validate JWT + role
    Auth-->>API: Authorized (is_admin=true)

    API->>DB: SELECT surveys WHERE status='pending'
    DB-->>API: Survey list
    API-->>Web: Paginated results
    Web-->>Admin: Display survey table

    %% Review Details
    Admin->>Web: Click survey to review
    Web->>API: GET /api/surveys/{id}
    API->>DB: Get survey + images + AI results
    DB-->>API: Complete survey data

    par Get images
        API->>Storage: Generate signed URLs
        Storage-->>API: Temporary URLs
    and Get room info
        API->>DB: Get room details
        DB-->>API: Room + building data
    end

    API-->>Web: Survey details
    Web-->>Admin: Show images + AI suggestions

    %% Decision
    alt Approve
        Admin->>Web: Click "Approve"
        Web->>Web: Optional: Edit attributes
        Web->>API: PUT /api/surveys/{id}/approve
        Note over API: {status: 'approved',<br/>updated_attributes}

        API->>DB: BEGIN TRANSACTION
        API->>DB: UPDATE survey status
        API->>DB: UPDATE room attributes
        API->>DB: INSERT audit log
        API->>DB: COMMIT

        API->>Email: Send notification
        Email-->>API: Sent

        API-->>Web: 200 OK
        Web-->>Admin: "Survey approved"

    else Reject
        Admin->>Web: Click "Reject"
        Web->>Web: Enter rejection reason
        Web->>API: PUT /api/surveys/{id}/reject
        Note over API: {status: 'rejected',<br/>rejection_reason}

        API->>DB: UPDATE survey
        API->>Email: Notify surveyor
        API-->>Web: 200 OK
        Web-->>Admin: "Survey rejected"
    end
```

### Review Workflow Features

- **Batch Operations**: Review multiple surveys efficiently
- **AI Assistance**: AI-suggested attributes with manual override capability
- **Audit Compliance**: Complete audit trail for all approval decisions
- **Notification System**: Automated email notifications to stakeholders
- **Transaction Safety**: Database transactions ensure data consistency

---

## 5. AI Prompt Engineering

### Prompt Template Management Workflow

Advanced prompt engineering interface for super users to optimize AI analysis accuracy.

> 🤖 **AI Configuration**: See [API Development Guide](../backend/api-development.md) for prompt versioning and deployment
> 🧪 **Testing Framework**: See [Testing Guide](../workflows/testing-guide.md) for prompt validation and performance testing

```mermaid
sequenceDiagram
    actor SuperUser
    participant Admin as Dev Admin Page
    participant API as Backend API
    participant Auth as Auth Middleware
    participant Prompt as Prompt Service
    participant DB as PostgreSQL
    participant Test as Test Service

    SuperUser->>Admin: Open AI Prompt Workspace
    Admin->>API: GET /api/dev-admin/prompts/active
    API->>Auth: Validate super_user role
    Auth-->>API: Authorized

    API->>DB: Get active prompt template
    DB-->>API: Current prompt
    API-->>Admin: Prompt details

    %% Edit Prompt
    SuperUser->>Admin: Edit prompt template
    Note over Admin: Modify instructions,<br/>add examples,<br/>adjust parameters

    %% Test Prompt
    SuperUser->>Admin: Test with sample image
    Admin->>API: POST /api/dev-admin/test-prompt
    Note over API: {prompt_template,<br/>test_image, model}

    API->>Test: Run test analysis
    Test->>Test: Build full prompt
    Test->>API: Call Gemini API
    API-->>Test: AI response
    Test->>Test: Parse & format
    Test-->>API: Test results

    API-->>Admin: Show results + metrics
    Note over Admin: Response time,<br/>token usage,<br/>extracted attributes

    %% Save New Version
    SuperUser->>Admin: Save as new version
    Admin->>API: POST /api/dev-admin/prompts
    Note over API: {name, template,<br/>model_preference}

    API->>DB: BEGIN TRANSACTION
    API->>DB: Deactivate current
    API->>DB: INSERT new prompt
    API->>DB: INSERT prompt_history
    API->>DB: COMMIT

    API-->>Admin: Prompt saved
    Admin-->>SuperUser: "Prompt v2 active"

    Note over DB: Maintains version history<br/>for rollback capability
```

### Prompt Engineering Features

- **Version Control**: Complete history of prompt changes with rollback capability
- **A/B Testing**: Compare prompt performance across different versions
- **Real-time Testing**: Immediate validation with sample images
- **Performance Metrics**: Token usage, response time, and accuracy tracking
- **Super User Security**: Role-based access control for prompt modifications

---

## 6. Super User Tenant Switching

### Multi-Tenant Administration Workflow

Super user capability to switch between tenant contexts for system administration and support.

> 🏢 **Multi-tenancy**: See [Database Design](../backend/database-design.md) for comprehensive tenant isolation and switching implementation
> 🔐 **Security Model**: See [Security Architecture](../architecture/security-architecture.md) for privileged access controls and audit logging

```mermaid
sequenceDiagram
    actor SuperUser
    participant Admin as Admin Dashboard
    participant Selector as Tenant Selector
    participant API as Backend API
    participant Context as Tenant Context
    participant DB as PostgreSQL

    SuperUser->>Admin: Click tenant selector
    Admin->>Selector: Open dropdown

    Selector->>API: GET /api/tenants/available
    API->>DB: Get user's tenants
    Note over DB: WHERE is_super_user=true<br/>returns ALL tenants
    DB-->>API: Tenant list
    API-->>Selector: Available tenants

    Selector-->>SuperUser: Show all tenants

    SuperUser->>Selector: Select "University B"
    Selector->>API: POST /api/tenants/switch
    Note over API: {tenant_id: 'univ-b'}

    API->>DB: Validate access
    DB-->>API: Authorized

    API->>API: Generate new JWT
    Note over API: Claims updated with<br/>new tenant_id

    API-->>Selector: New token + tenant info

    Selector->>Context: Update tenant context
    Context->>Context: Set X-Selected-Tenant-Id
    Context->>Admin: Broadcast change

    Admin->>Admin: Refresh all components
    Admin->>API: Refetch data with new context
    Note over API: All queries now filtered<br/>by new tenant_id

    API-->>Admin: Tenant-specific data
    Admin-->>SuperUser: UI updated for University B

    Note over Context: All subsequent API calls<br/>include tenant header
```

### Tenant Switching Security

- **Privilege Validation**: Super user role verification before tenant list access
- **JWT Refresh**: New token generation with updated tenant context
- **Audit Logging**: Complete tracking of tenant switching activities
- **Context Propagation**: Automatic context update across all UI components
- **Data Isolation**: Guaranteed tenant data separation at the database level

---

## 7. Dynamic Attribute Management

### Custom Attribute Configuration Workflow

Administrative interface for defining custom room attributes and categories specific to tenant requirements.

> ⚙️ **Attribute System**: See [API Development Guide](../backend/api-development.md) for dynamic attribute definition and validation
> 🎨 **UI Configuration**: See [Admin Architecture](../admin/architecture/README.md) for attribute management interface implementation

```mermaid
sequenceDiagram
    actor Admin
    participant Web as Settings Page
    participant API as Backend API
    participant Attr as Attribute Service
    participant DB as PostgreSQL
    participant Cache as Attribute Cache

    %% View Current Attributes
    Admin->>Web: Open attribute settings
    Web->>API: GET /api/attributes/definitions
    API->>Attr: Get tenant attributes
    Attr->>DB: SELECT FROM attribute_definitions
    DB-->>Attr: Current definitions
    Attr-->>API: Categorized attributes
    API-->>Web: Attribute list

    %% Create Custom Category
    Admin->>Web: Add new category
    Web->>Web: Enter "Sustainability"
    Web->>API: POST /api/attributes/categories
    Note over API: {name: 'Sustainability',<br/>icon: 'eco'}

    API->>Attr: Create category
    Attr->>DB: INSERT category
    DB-->>Attr: category_id
    Attr->>Cache: Invalidate cache
    Attr-->>API: Category created

    %% Add Custom Attribute
    Admin->>Web: Add attribute to category
    Web->>Web: Configure attribute
    Note over Web: Name: "Solar Panels"<br/>Type: boolean<br/>Required: false

    Web->>API: POST /api/attributes/definitions
    Note over API: {category_id,<br/>name, type, metadata}

    API->>Attr: Create attribute
    Attr->>Attr: Validate uniqueness
    Attr->>DB: INSERT attribute_definition
    Attr->>Cache: Update cache

    %% Update Mobile/AI
    API->>API: Trigger sync
    Note over API: Mobile apps fetch<br/>updated definitions<br/>on next sync

    API-->>Web: Attribute created
    Web-->>Admin: Show new attribute

    Note over Cache: Attributes cached<br/>for performance
```

### Attribute Management Features

- **Dynamic Configuration**: Runtime creation of custom attribute categories and fields
- **Type System**: Support for boolean, text, numeric, and enum attribute types
- **Cache Management**: Automatic cache invalidation and updates for performance
- **Mobile Synchronization**: Automatic propagation of attribute changes to mobile apps
- **Validation Framework**: Built-in validation for attribute uniqueness and constraints

---

## 8. Offline Survey Synchronization

### Mobile Offline-First Synchronization

Robust offline survey capability with intelligent conflict resolution and background synchronization.

> 📱 **Offline Architecture**: See [Offline-First Architecture](../mobile/architecture/offline-first.md) for MMKV storage and queue management implementation
> 🔄 **Sync Strategies**: See [Offline-First Architecture](../mobile/architecture/offline-first.md) for network detection and data synchronization patterns
> ⚠️ **Conflict Resolution**: See [Troubleshooting Guide](../workflows/troubleshooting-guide.md) for common offline sync issues and solutions

```mermaid
sequenceDiagram
    participant Queue as Offline Queue
    participant Mobile as Mobile App
    participant Sync as Sync Service
    participant API as Backend API
    participant DB as PostgreSQL
    participant Storage as File Storage

    Note over Queue: Background task runs<br/>when connectivity detected

    Queue->>Mobile: Network available
    Mobile->>Sync: Start sync process

    Sync->>Queue: Get pending surveys
    Queue-->>Sync: 3 surveys queued

    loop For each survey
        Sync->>Sync: Prepare survey data
        Sync->>API: POST /api/surveys/create

        alt Success
            API->>DB: Create survey
            DB-->>API: survey_id

            %% Upload images
            loop For each image
                Sync->>Sync: Read from local storage
                Sync->>API: POST /api/images/upload
                API->>Storage: Store image
                API->>DB: Link to survey
            end

            API-->>Sync: Survey created
            Sync->>Queue: Remove from queue
            Sync->>Mobile: Update UI

        else Conflict
            API-->>Sync: 409 Conflict
            Note over Sync: Room already surveyed<br/>by another user

            Sync->>Sync: Handle conflict
            Sync->>Mobile: Notify user
            Sync->>Queue: Mark as conflict
        else Error
            API-->>Sync: 500 Error
            Sync->>Queue: Retry later
            Note over Queue: Exponential backoff
        end
    end

    Sync->>Mobile: Sync complete
    Mobile->>Mobile: Update survey list
    Mobile->>Mobile: Show notifications

    Note over Sync: Preserves survey timestamp<br/>from original capture
```

### Offline Synchronization Features

- **Background Processing**: Automatic sync when network connectivity is restored
- **Conflict Detection**: Intelligent handling of concurrent survey submissions
- **Exponential Backoff**: Retry logic for temporary network or server failures
- **Timestamp Preservation**: Maintains original capture time for accurate reporting
- **Queue Persistence**: MMKV-based offline queue survives app restarts

---

## 📊 Performance Characteristics

### API Response Time Targets

| Operation Type | Target Response Time | Implementation Notes |
|----------------|---------------------|---------------------|
| **Authentication** | <100ms | Cached JWT validation with Redis |
| **Survey Creation** | <200ms | Excluding image upload processing |
| **Image Upload** | <5s per image | 10MB limit with parallel processing |
| **AI Analysis** | 2-5s per image | Gemini API dependency with caching |
| **Data Queries** | <50ms | Optimized indexing and query patterns |
| **Tenant Switching** | <300ms | JWT regeneration and context update |

### Concurrency and Scalability Patterns

- **Parallel Image Upload**: Up to 3 concurrent uploads per user session
- **Batch AI Processing**: Queue-based processing with rate limiting (60 req/min)
- **Database Connection Pool**: 20-100 connections based on load
- **Tenant Isolation**: Row-level security with minimal performance overhead
- **Background Sync**: Non-blocking offline synchronization processes

### Caching Strategy Implementation

| Cache Type | Duration | Implementation | Use Case |
|------------|----------|----------------|----------|
| **JWT Tokens** | 15min access, 7-day refresh | In-memory + secure storage | Authentication state |
| **AI Responses** | 24-hour TTL | Redis cache | Identical image analysis |
| **Attribute Definitions** | Application lifetime | Application-level cache | Dynamic attribute access |
| **FICM Hierarchy** | Application startup | In-memory cache | Classification mapping |
| **Prompt Templates** | Until changed | Redis with invalidation | AI prompt management |

---

## 🔗 Related Runtime Documentation

### System-Specific Implementation Guides
> 📱 **Mobile Workflows**: See [Mobile Development Patterns](../mobile/development-patterns.md) for React Native implementation of these sequences
> 🌐 **Admin Workflows**: See [Admin Architecture](../admin/architecture/README.md) for web interface implementation of administrative sequences
> ⚙️ **Backend APIs**: See [API Development Guide](../backend/api-development.md) for FastAPI implementation of backend sequences

### Integration and Architecture
- **[Integration Architecture](./system-container-overview.md)** - Cross-system integration patterns and protocols
- **[System Container Overview](./system-container-overview.md)** - High-level system architecture supporting these sequences
- **[Data Flow Patterns](./data-flow-patterns.md)** - Data movement patterns across system boundaries

### Performance and Monitoring
- **[Performance Optimization](../workflows/deployment-guide.md)** - System-wide performance optimization strategies
- **[Monitoring and Observability](../workflows/deployment-guide.md)** - Runtime monitoring and debugging tools for sequence flows
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Comprehensive error handling across distributed sequences

---

**Status**: ✅ **PRODUCTION RUNTIME SEQUENCE REFERENCE**
**Last Updated**: 2025-06-29
**Scope**: Cross-System Integration, Workflow Orchestration, Distributed Architecture, Performance Analysis
**Coverage**: Authentication, Survey Management, AI Processing, Admin Workflows, Offline Synchronization

---

*This runtime sequence documentation provides essential understanding of how Spacewalker's distributed components collaborate to deliver complete user workflows, serving as the definitive reference for system integration patterns and end-to-end process flows.*
