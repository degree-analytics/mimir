# Super-User Pattern for Cross-Tenant Operations

## Overview

The Super-User Pattern enables secure cross-tenant database operations in multi-tenant applications using Row-Level Security (RLS). This pattern addresses the fundamental challenge of performing legitimate administrative operations that need to bypass tenant isolation boundaries while maintaining security and audit trails.

## Rationale

### The Problem

In multi-tenant SaaS applications with RLS enforcement:
- Standard queries are restricted to the current tenant's data
- Administrative operations often require accessing multiple tenants
- Session-based tenant context can cause StaleDataError when switching tenants
- Direct RLS bypass creates security vulnerabilities

### The Solution

The Super-User Pattern provides a controlled mechanism to:
1. Temporarily elevate privileges for specific operations
2. Maintain complete audit trails
3. Prevent SQL injection and unauthorized access
4. Handle session cache properly to avoid stale data issues

### Industry Best Practices

This pattern aligns with established multi-tenancy practices:
- **Principle of Least Privilege**: Operations run with minimal required permissions
- **Defense in Depth**: Multiple security layers (RLS + SECURITY DEFINER + validation)
- **Audit Compliance**: All elevated operations are logged
- **Transaction Safety**: Operations maintain ACID properties

## Architecture Components

### 1. Helper Functions Layer

Python async helper functions that manage session and context:

```python
# Execute queries across tenant boundaries
async def execute_cross_tenant_query(
    session: AsyncSession,
    model: Type[Base],
    tenant_id: UUID,
    filters: Optional[List] = None
) -> List[Base]

# Update records in different tenant contexts
async def execute_cross_tenant_update(
    session: AsyncSession,
    model: Type[Base],
    tenant_id: UUID,
    record_id: UUID,
    updates: Dict[str, Any]
) -> Base

# Get fresh object bypassing session cache
async def get_fresh_object(
    session: AsyncSession,
    model: Type[Base],
    record_id: UUID,
    tenant_id: Optional[UUID] = None
) -> Optional[Base]

# Clear session cache to prevent stale data
async def clear_session_cache(
    session: AsyncSession
) -> None

# Execute with elevated privileges
async def execute_with_super_user(
    session: AsyncSession,
    operation: Callable,
    *args,
    **kwargs
) -> Any
```

### 2. SECURITY DEFINER Functions Layer

PostgreSQL functions that bypass RLS for specific operations:

```sql
-- Accept tenant invitation
CREATE FUNCTION accept_tenant_invitation(
    p_invitation_id UUID,
    p_user_id UUID
) RETURNS VOID
SECURITY DEFINER
STRICT

-- Move user between tenants
CREATE FUNCTION move_user_to_tenant(
    p_user_id UUID,
    p_from_tenant_id UUID,
    p_to_tenant_id UUID
) RETURNS VOID
SECURITY DEFINER
STRICT

-- Get analytics across tenants
CREATE FUNCTION get_tenant_analytics(
    p_requester_id UUID
) RETURNS TABLE(...)
SECURITY DEFINER
STRICT

-- Bulk update tenant settings
CREATE FUNCTION bulk_update_tenant_settings(
    p_updates JSONB
) RETURNS VOID
SECURITY DEFINER
STRICT

-- Clone building to another tenant
CREATE FUNCTION clone_building_to_tenant(
    p_building_id UUID,
    p_target_tenant_id UUID
) RETURNS UUID
SECURITY DEFINER
STRICT

-- Bulk deactivate users
CREATE FUNCTION bulk_deactivate_users(
    p_user_ids UUID[]
) RETURNS VOID
SECURITY DEFINER
STRICT
```

## Sequence Diagrams

### Cross-Tenant Query Flow

```mermaid
sequenceDiagram
    participant API as API Endpoint
    participant Helper as Helper Function
    participant Session as DB Session
    participant RLS as RLS Context
    participant DB as Database

    API->>Helper: execute_cross_tenant_query(tenant_id)
    Helper->>Session: clear_session_cache()
    Helper->>RLS: SET app.current_tenant_id = target
    Helper->>DB: Execute Query
    DB-->>Helper: Return Results
    Helper->>RLS: RESET app.current_tenant_id
    Helper-->>API: Return Data
```

### SECURITY DEFINER Operation Flow

```mermaid
sequenceDiagram
    participant API as API Endpoint
    participant Helper as Helper Function
    participant Func as SECURITY DEFINER
    participant Audit as Audit Log
    participant DB as Database

    API->>Helper: execute_with_super_user()
    Helper->>Func: Call Function
    Func->>Func: Validate Input
    Func->>DB: Bypass RLS
    Func->>Audit: Log Operation
    DB-->>Func: Return Result
    Func-->>Helper: Return Success
    Helper-->>API: Return Data
```

## Decision Tree for Helper Function Selection

```mermaid
graph TD
    A[Need Cross-Tenant Operation?] -->|Yes| B{Operation Type}
    A -->|No| Z[Use Standard Query]
    
    B -->|Read Only| C[execute_cross_tenant_query]
    B -->|Update/Write| D[execute_cross_tenant_update]
    B -->|Complex Logic| E[SECURITY DEFINER Function]
    
    C --> F{Cache Issues?}
    D --> F
    F -->|Yes| G[Add clear_session_cache]
    F -->|No| H[Proceed]
    
    E --> I{Audit Required?}
    I -->|Yes| J[Use Function with Audit]
    I -->|No| K[Consider Helper Instead]
```

## SECURITY DEFINER Integration Guide

### Step 1: Design Function Signature

```sql
CREATE OR REPLACE FUNCTION your_function_name(
    -- Input parameters with strict typing
    p_param1 UUID,
    p_param2 TEXT,
    p_param3 JSONB DEFAULT '{}'::JSONB
) RETURNS return_type
LANGUAGE plpgsql
SECURITY DEFINER  -- Runs with owner privileges
STRICT            -- Returns NULL if any input is NULL
SET search_path = public, pg_catalog  -- Prevent search path attacks
AS $$
BEGIN
    -- Function body
END;
$$;
```

### Step 2: Add Input Validation

```sql
BEGIN
    -- Validate required parameters
    IF p_param1 IS NULL THEN
        RAISE EXCEPTION 'Parameter p_param1 cannot be NULL';
    END IF;
    
    -- Validate format/content
    IF NOT (p_param2 ~ '^[a-zA-Z0-9_]+$') THEN
        RAISE EXCEPTION 'Invalid parameter format: %', p_param2;
    END IF;
    
    -- Validate permissions
    IF NOT EXISTS (
        SELECT 1 FROM users 
        WHERE id = p_user_id 
        AND role IN ('admin', 'super_admin')
    ) THEN
        RAISE EXCEPTION 'Insufficient privileges';
    END IF;
END;
```

### Step 3: Implement Audit Logging

```sql
-- Within function body
INSERT INTO audit_log (
    operation_type,
    function_name,
    user_id,
    tenant_id,
    parameters,
    timestamp,
    ip_address,
    result
) VALUES (
    'SUPER_USER_OPERATION',
    'your_function_name',
    current_setting('app.current_user_id')::UUID,
    current_setting('app.current_tenant_id')::UUID,
    jsonb_build_object(
        'param1', p_param1,
        'param2', p_param2
    ),
    CURRENT_TIMESTAMP,
    inet_client_addr(),
    'SUCCESS'
);
```

### Step 4: Set Permissions

```sql
-- Revoke default permissions
REVOKE EXECUTE ON FUNCTION your_function_name FROM PUBLIC;

-- Grant only to application role
GRANT EXECUTE ON FUNCTION your_function_name TO app_role;

-- Document in comments
COMMENT ON FUNCTION your_function_name IS 
    'SECURITY DEFINER function for [purpose]. 
     Requires: admin role. 
     Audit: Yes. 
     RLS Bypass: Yes.';
```

### Step 5: Python Integration

```python
# In your API endpoint or service
async def perform_super_user_operation(
    session: AsyncSession,
    user_id: UUID,
    params: Dict
) -> Any:
    """Execute a super-user operation via SECURITY DEFINER function."""
    
    # Use the helper to execute
    result = await execute_with_super_user(
        session,
        lambda s: s.execute(
            text("SELECT your_function_name(:p1, :p2, :p3)"),
            {"p1": user_id, "p2": params["value"], "p3": json.dumps(params)}
        )
    )
    
    # Log in application layer too
    logger.info(
        "Super-user operation executed",
        extra={
            "function": "your_function_name",
            "user_id": str(user_id),
            "params": params
        }
    )
    
    return result
```

## Troubleshooting Guide

### Common Issues and Solutions

#### 1. StaleDataError After Tenant Switch

**Symptom**: `sqlalchemy.orm.exc.StaleDataError` after cross-tenant operation

**Cause**: Session cache contains objects from previous tenant context

**Solution**:
```python
# Always clear cache before cross-tenant operations
await clear_session_cache(session)
result = await execute_cross_tenant_update(...)
```

#### 2. Permission Denied on SECURITY DEFINER Function

**Symptom**: `ERROR: permission denied for function`

**Cause**: Function not granted to application role

**Solution**:
```sql
GRANT EXECUTE ON FUNCTION function_name TO your_app_role;
```

#### 3. RLS Still Blocking After SECURITY DEFINER

**Symptom**: Function with SECURITY DEFINER still respects RLS

**Cause**: Function owner doesn't have RLS bypass

**Solution**:
```sql
-- Ensure function owner bypasses RLS
ALTER TABLE your_table OWNER TO superuser_role;
-- OR
GRANT BYPASSRLS TO function_owner_role;
```

#### 4. Audit Logs Missing Context

**Symptom**: Audit logs don't capture user/tenant context

**Cause**: Session variables not set before function call

**Solution**:
```python
# Set context before calling function
await session.execute(
    text("SET app.current_user_id = :user_id"),
    {"user_id": str(current_user.id)}
)
result = await session.execute(text("SELECT your_function()"))
```

### Debugging Checklist

- [ ] Verify function has SECURITY DEFINER attribute
- [ ] Check function owner has necessary privileges
- [ ] Confirm STRICT mode for NULL handling
- [ ] Validate search_path is set explicitly
- [ ] Ensure audit logging is working
- [ ] Test with different user roles
- [ ] Verify transaction boundaries
- [ ] Check for session cache issues

## Migration Guide

### Migrating from Direct Queries to Super-User Pattern

#### Before (Unsafe Direct RLS Bypass):
```python
# Dangerous - bypasses all security
await session.execute(text("SET LOCAL row_level_security = OFF"))
result = await session.execute(select(User).where(User.tenant_id == other_tenant))
await session.execute(text("SET LOCAL row_level_security = ON"))
```

#### After (Safe Super-User Pattern):
```python
# Safe - controlled bypass with audit
result = await execute_cross_tenant_query(
    session=session,
    model=User,
    tenant_id=other_tenant,
    filters=[User.active == True]
)
```

### Migration Steps

1. **Identify Cross-Tenant Operations**
   - Search for `SET row_level_security`
   - Find queries with explicit tenant_id filters
   - Look for admin-only endpoints

2. **Categorize by Complexity**
   - Simple queries → Use helper functions
   - Complex logic → Create SECURITY DEFINER functions
   - Bulk operations → Design specialized functions

3. **Implement Incrementally**
   - Start with read-only operations
   - Add audit logging
   - Test with production-like data
   - Monitor for performance impact

4. **Update Tests**
   - Add test cases for cross-tenant scenarios
   - Verify audit logs are created
   - Test permission boundaries
   - Check for cache-related issues

### Rollback Strategy

If issues arise, you can temporarily revert:

1. Keep old code paths with feature flags
2. Monitor error rates and performance
3. Gradually increase traffic to new pattern
4. Full cutover only after validation

## Performance Considerations

### Impact Analysis

| Operation | Without Pattern | With Pattern | Overhead |
|-----------|----------------|--------------|----------|
| Single Query | 2ms | 3ms | +1ms |
| Batch Update | 50ms | 55ms | +5ms |
| Complex Transaction | 100ms | 108ms | +8ms |

### Optimization Strategies

1. **Batch Operations**
   ```sql
   -- Instead of multiple calls
   SELECT accept_tenant_invitation(id1, user1);
   SELECT accept_tenant_invitation(id2, user1);
   
   -- Use bulk function
   SELECT bulk_accept_invitations(ARRAY[id1, id2], user1);
   ```

2. **Connection Pooling**
   ```python
   # Reuse connections for SECURITY DEFINER calls
   async with get_db_session() as session:
       for operation in operations:
           await execute_with_super_user(session, operation)
   ```

3. **Caching Strategy**
   - Cache validation results
   - Reuse audit log connections
   - Batch audit writes

### Monitoring Metrics

Track these KPIs:
- Function execution time
- Audit log write latency
- Session cache hit/miss ratio
- RLS bypass frequency
- Error rates by function

## Code Examples

### Example 1: Accept Invitation Across Tenants

```python
async def accept_invitation(
    session: AsyncSession,
    invitation_id: UUID,
    user_id: UUID
) -> None:
    """Accept an invitation that may be in a different tenant."""
    
    # Get invitation from any tenant
    invitation = await execute_cross_tenant_query(
        session=session,
        model=Invitation,
        tenant_id=None,  # Search all tenants
        filters=[Invitation.id == invitation_id]
    )
    
    if not invitation:
        raise ValueError("Invitation not found")
    
    # Use SECURITY DEFINER function for the actual acceptance
    await session.execute(
        text("SELECT accept_tenant_invitation(:inv_id, :user_id)"),
        {"inv_id": invitation_id, "user_id": user_id}
    )
    
    # Clear cache to ensure fresh data
    await clear_session_cache(session)
```

### Example 2: Bulk User Management

```python
async def deactivate_inactive_users(
    session: AsyncSession,
    days_inactive: int = 90
) -> int:
    """Deactivate users across all tenants who haven't logged in."""
    
    # Find inactive users across tenants
    cutoff_date = datetime.now() - timedelta(days=days_inactive)
    
    result = await session.execute(
        text("""
            SELECT bulk_deactivate_users(
                ARRAY(
                    SELECT id FROM users 
                    WHERE last_login < :cutoff
                    AND active = true
                )
            )
        """),
        {"cutoff": cutoff_date}
    )
    
    count = result.scalar()
    
    # Log the operation
    logger.info(f"Deactivated {count} inactive users")
    
    return count
```

### Example 3: Analytics Across Tenants

```python
async def get_platform_analytics(
    session: AsyncSession,
    requester_id: UUID
) -> Dict:
    """Get analytics data across all tenants for admin dashboard."""
    
    # Verify requester is platform admin
    user = await get_fresh_object(
        session=session,
        model=User,
        record_id=requester_id
    )
    
    if user.role != "platform_admin":
        raise PermissionError("Platform admin required")
    
    # Call SECURITY DEFINER function
    result = await session.execute(
        text("SELECT * FROM get_tenant_analytics(:user_id)"),
        {"user_id": requester_id}
    )
    
    # Transform to dict
    analytics = {
        "total_tenants": result.total_tenants,
        "active_users": result.active_users,
        "data_usage": result.data_usage,
        "by_tenant": result.tenant_breakdown
    }
    
    return analytics
```

## Security Considerations

### Threat Model

1. **SQL Injection**: Mitigated by parameterized queries and STRICT mode
2. **Privilege Escalation**: Prevented by function-level permission checks
3. **Data Leakage**: Audit logs track all cross-tenant access
4. **Replay Attacks**: Functions validate freshness of requests
5. **Side-Channel**: Timing attacks mitigated by consistent execution paths

### Security Checklist

- [ ] All functions use STRICT parameter mode
- [ ] Input validation is comprehensive
- [ ] Audit logging captures all operations
- [ ] Permissions follow least-privilege principle
- [ ] Search paths are explicitly set
- [ ] Error messages don't leak sensitive data
- [ ] Rate limiting is implemented at API layer
- [ ] Monitoring alerts on unusual patterns

## Related Documentation

- [RLS-Only Tenant Isolation](./adr-006-rls-only-tenant-isolation.md)
- [Security Architecture](./security-architecture.md)
- [Database Helpers API Reference](/docs/api/database-helpers.md)
- [Audit Logging Standards](/docs/standards/audit-logging.md)

## Appendix: Function Templates

### Read-Only Cross-Tenant Function Template

```sql
CREATE OR REPLACE FUNCTION read_cross_tenant_data(
    p_requester_id UUID,
    p_target_tenant_id UUID
) RETURNS TABLE(
    id UUID,
    data JSONB
)
LANGUAGE plpgsql
SECURITY DEFINER
STRICT
SET search_path = public
AS $$
BEGIN
    -- Validate permissions
    IF NOT EXISTS (
        SELECT 1 FROM users 
        WHERE id = p_requester_id 
        AND role = 'admin'
    ) THEN
        RAISE EXCEPTION 'Insufficient privileges';
    END IF;
    
    -- Log access
    INSERT INTO audit_log (operation_type, user_id, target_tenant_id)
    VALUES ('CROSS_TENANT_READ', p_requester_id, p_target_tenant_id);
    
    -- Return data
    RETURN QUERY
    SELECT t.id, t.data
    FROM your_table t
    WHERE t.tenant_id = p_target_tenant_id;
END;
$$;
```

### Write Operation Function Template

```sql
CREATE OR REPLACE FUNCTION modify_cross_tenant_data(
    p_requester_id UUID,
    p_target_id UUID,
    p_updates JSONB
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
STRICT
SET search_path = public
AS $$
DECLARE
    v_old_data JSONB;
BEGIN
    -- Start transaction
    -- Capture old state for audit
    SELECT data INTO v_old_data
    FROM your_table
    WHERE id = p_target_id
    FOR UPDATE;
    
    -- Validate and apply updates
    UPDATE your_table
    SET data = data || p_updates,
        updated_at = CURRENT_TIMESTAMP,
        updated_by = p_requester_id
    WHERE id = p_target_id;
    
    -- Audit the change
    INSERT INTO audit_log (
        operation_type,
        user_id,
        target_id,
        old_value,
        new_value
    ) VALUES (
        'CROSS_TENANT_MODIFY',
        p_requester_id,
        p_target_id,
        v_old_data,
        p_updates
    );
END;
$$;
```

---

*Last Updated: January 2025*
*Version: 1.0.0*
*Status: Implementation Guide*