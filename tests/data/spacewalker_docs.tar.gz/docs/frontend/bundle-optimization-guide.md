# Bundle Optimization Guide

## 🎯 Problem Analysis

Based on our codebase analysis, we identified **6 files with 35+ Material-UI imports**, creating significant bundle size impact:

### Worst Offenders
1. **DebugDashboard.tsx** - 48 imports (32 MUI + 16 icons)
2. **AITestingLab.tsx** - 48 imports (30 MUI + 18 icons)
3. **RoomDetailPage.tsx** - 41 imports (28 MUI + 13 icons)
4. **SettingsPage.tsx** - 40 imports (31 MUI + 9 icons)
5. **AIPromptWorkspace.tsx** - 40 imports (28 MUI + 12 icons)
6. **SurveysPage.tsx** - 37 imports (29 MUI + 8 icons)

## 🔧 Optimization Strategy

### 1. Composite Component Pattern
Instead of importing individual components in each file, use pre-bundled composite components:

**❌ Before (37 imports in surveys/page.tsx):**
```typescript
import {
  Box, Paper, Typography, Button, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Chip, IconButton, TextField,
  InputAdornment, MenuItem, Grid, Alert, CircularProgress, Tooltip,
  Dialog, DialogTitle, DialogContent, DialogActions, FormControl,
  InputLabel, Select, Card, CardHeader, CardContent,
} from '@mui/material';
import {
  Search, Refresh, Visibility, CheckCircle, Cancel,
  HourglassEmpty, FilterList, Compare,
} from '@mui/icons-material';
```

**✅ After (3-5 imports):**
```typescript
import { TablePageLayout } from '@/components/TablePageLayout';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  StatusChip, ActionButtons, LoadingTable
} from '@/components/common/DataTableComponents';
import { SearchField, SelectField } from '@/components/common/FormComponents';
import { ConfirmDialog } from '@/components/common/DialogComponents';
```

### 2. Available Composite Components

#### Data Table Components (`/components/common/DataTableComponents.tsx`)
- **Table components**: Table, TableBody, TableCell, etc.
- **StatusChip**: Pre-styled status indicators
- **ActionButtons**: View/Edit/Delete button groups
- **LoadingTable**: Loading state table
- **EmptyTable**: Empty state table

#### Form Components (`/components/common/FormComponents.tsx`)
- **SearchField**: Search input with icon
- **SelectField**: Dropdown with proper styling
- **PasswordField**: Password input with show/hide
- **FormCard**: Card wrapper for forms
- **FormSection**: Sectioned form layout

#### Dialog Components (`/components/common/DialogComponents.tsx`)
- **ConfirmDialog**: Confirmation dialogs
- **InfoDialog**: Information dialogs
- **LoadingDialog**: Loading state dialogs
- **FormDialog**: Form submission dialogs

### 3. Migration Checklist

For each file with 35+ imports:

1. **Identify patterns**: What UI patterns are repeated?
2. **Group imports**: Which components are used together?
3. **Replace with composites**: Use bundled components
4. **Test functionality**: Ensure no regressions
5. **Measure impact**: Verify bundle size reduction

### 4. Priority Migration Order

**High Priority (Dev Tools - 3 files):**
- `DebugDashboard.tsx` (48 imports)
- `AITestingLab.tsx` (48 imports)
- `AIPromptWorkspace.tsx` (40 imports)

**Medium Priority (User-facing - 3 files):**
- `RoomDetailPage.tsx` (41 imports)
- `SettingsPage.tsx` (40 imports)
- `SurveysPage.tsx` (37 imports)

### 5. Bundle Size Benefits

**Expected reductions per file:**
- **Import statements**: 35+ → 3-5 imports
- **Bundle impact**: ~30-40% reduction in component imports
- **Tree shaking**: Better optimization with bundled exports
- **Code splitting**: Easier lazy loading of composite components

### 6. Maintenance Benefits

**Developer Experience:**
- **Consistency**: Standardized component usage
- **Reusability**: Common patterns become reusable
- **Type Safety**: Better TypeScript support
- **Testing**: Easier to test composite components

**Long-term Maintainability:**
- **Centralized updates**: Change UI patterns in one place
- **Design system**: Foundation for component library
- **Documentation**: Self-documenting component patterns

## 🚀 Implementation Example

### Before: SurveysPage.tsx (37 imports)
```typescript
// 35+ individual Material-UI imports
import { Box, Paper, Typography, ... } from '@mui/material';
import { Search, Refresh, ... } from '@mui/icons-material';

export default function SurveysPage() {
  return (
    <Box>
      <Typography variant="h4">Surveys</Typography>
      <TextField
        InputProps={{
          startAdornment: <Search />
        }}
      />
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {surveys.map(survey => (
            <TableRow key={survey.id}>
              <TableCell>
                <Chip
                  label={survey.status}
                  color={getStatusColor(survey.status)}
                />
              </TableCell>
              <TableCell>
                <IconButton onClick={() => view(survey.id)}>
                  <Visibility />
                </IconButton>
                <IconButton onClick={() => edit(survey.id)}>
                  <Edit />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Box>
  );
}
```

### After: SurveysPage.tsx (5 imports)
```typescript
import { TablePageLayout } from '@/components/TablePageLayout';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  StatusChip, ActionButtons
} from '@/components/common/DataTableComponents';
import { SearchField } from '@/components/common/FormComponents';

export default function SurveysPage() {
  return (
    <TablePageLayout title="Surveys">
      <SearchField
        value={searchTerm}
        onChange={setSearchTerm}
        placeholder="Search surveys..."
      />
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {surveys.map(survey => (
              <TableRow key={survey.id}>
                <TableCell>
                  <StatusChip status={survey.status} />
                </TableCell>
                <TableCell>
                  <ActionButtons
                    onView={() => view(survey.id)}
                    onEdit={() => edit(survey.id)}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </TablePageLayout>
  );
}
```

## 📊 Measuring Success

**Bundle Analysis Tools:**
```bash
# Analyze bundle before/after
npm run build -- --analyze    # Generate bundle analysis

# Check import usage
npx depcheck                   # Find unused dependencies
npx bundle-analyzer            # Visualize bundle composition
```

**Success Metrics:**
- **Import reduction**: 35+ → 3-5 imports per file
- **Bundle size**: Measurable decrease in JavaScript bundle
- **Performance**: Faster initial page loads
- **Maintainability**: Easier component updates

## 🎯 Next Steps

1. **Start with dev-admin components** (biggest impact, lower risk)
2. **Create measurement baseline** with current bundle size
3. **Migrate one file at a time** with testing
4. **Document patterns** for team adoption
5. **Consider lazy loading** for large composite components

This optimization strategy will significantly reduce bundle size while improving code maintainability and developer experience.
