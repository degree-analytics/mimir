# SpaceWalker Admin Interface Layout Standards

## Purpose
Comprehensive layout standards for the SpaceWalker admin interface, establishing consistent responsive design patterns, optimal screen width utilization, and professional appearance across all admin pages.

## When to Use This
- Implementing new admin pages or components
- Refactoring existing layout implementations
- Resolving width utilization issues
- Ensuring cross-browser compatibility
- Following Material-UI best practices

**Keywords:** layout standards, responsive design, Material-UI, container standards, admin interface

---

## 📐 Container and maxWidth Standards

### Standard Container Configuration
**Primary Standard**: All admin pages MUST use Material-UI Container with `maxWidth="xl"`

```typescript
import { Container } from '@mui/material';

// ✅ CORRECT: Standard admin page container
<Container maxWidth="xl">
  {/* Page content */}
</Container>
```

### Container Size Specifications

| Container Size | Pixel Width | Use Case | Status |
|----------------|-------------|----------|---------|
| `xs` | 444px | **AVOID** - Too narrow for admin data | ❌ |
| `sm` | 600px | **AVOID** - Too narrow for admin data | ❌ |
| `md` | 900px | **AVOID** - Too narrow for admin data | ❌ |
| `lg` | 1200px | **AVOID** - Underutilizes available space | ❌ |
| `xl` | 1536px | **STANDARD** - Optimal for admin interfaces | ✅ |
| `false` | 100% | Use only for full-viewport components | ⚠️ |

### Implementation Rationale
- **Screen Utilization**: `maxWidth="xl"` (1536px) maximizes data visibility on large screens
- **Professional Appearance**: Eliminates excessive whitespace that appears unprofessional
- **Data Density**: Allows tables and forms to display more information effectively
- **User Experience**: Reduces horizontal scrolling and improves productivity

---

## 📱 Responsive Padding Patterns

### Standard Responsive Padding
Apply consistent responsive padding using Material-UI theme spacing:

```typescript
import { Container, Box } from '@mui/material';

// ✅ CORRECT: Standard responsive padding pattern
<Container maxWidth="xl" sx={{ px: { xs: 2, sm: 3, md: 4 } }}>
  <Box sx={{ py: { xs: 2, sm: 3, md: 4 } }}>
    {/* Page content */}
  </Box>
</Container>
```

### Padding Specifications

| Breakpoint | Spacing Value | Pixel Equivalent | Usage |
|------------|---------------|------------------|--------|
| `xs` (0-600px) | `px: 2, py: 2` | 16px horizontal, 16px vertical | Mobile devices |
| `sm` (600-900px) | `px: 3, py: 3` | 24px horizontal, 24px vertical | Small tablets |
| `md` (900px+) | `px: 4, py: 4` | 32px horizontal, 32px vertical | Desktop screens |

### Padding Implementation Rules
1. **Horizontal Padding** (`px`): Applied to Container for consistent edge spacing
2. **Vertical Padding** (`py`): Applied to inner Box for content spacing
3. **Consistent Scaling**: Padding increases proportionally with screen size
4. **Touch Targets**: Minimum 44px touch targets maintained on mobile

---

## 📊 Table Layout Patterns

### Standard Table Implementation
All admin tables MUST use the following pattern for consistent width utilization:

```typescript
import {
  TableContainer,
  Table,
  Paper,
  Container,
  Box
} from '@mui/material';

// ✅ CORRECT: Standard table layout pattern
<Container maxWidth="xl" sx={{ px: { xs: 2, sm: 3, md: 4 } }}>
  <Box sx={{ py: { xs: 2, sm: 3, md: 4 } }}>
    <TableContainer
      component={Paper}
      sx={{
        width: '100%',
        overflowX: 'auto',
        borderRadius: 2,
        boxShadow: 1
      }}
    >
      <Table sx={{ minWidth: 650 }}>
        {/* Table content */}
      </Table>
    </TableContainer>
  </Box>
</Container>
```

### Table Width Requirements
- **TableContainer**: `width: '100%'` to utilize full available space
- **Table**: `minWidth: 650` to ensure readability on smaller screens
- **Overflow**: `overflowX: 'auto'` for horizontal scrolling when needed
- **Paper Component**: Provides consistent elevation and styling

### Cross-Browser Table Compatibility
Special considerations for Safari browser compatibility:

```typescript
// ✅ CORRECT: Safari-compatible table styling
<TableContainer
  component={Paper}
  sx={{
    width: '100%',
    overflowX: 'auto',
    // Safari-specific fixes
    WebkitOverflowScrolling: 'touch',
    '& .MuiTable-root': {
      width: '100%',
      tableLayout: 'auto'
    }
  }}
>
```

---

## 🏗️ AdminLayout Component Examples

### Basic AdminLayout Implementation
Create a reusable AdminLayout component that enforces standards:

```typescript
// components/AdminLayout.tsx
import React from 'react';
import { Container, Box } from '@mui/material';
import { DashboardLayout } from './DashboardLayout';

interface AdminLayoutProps {
  children: React.ReactNode;
  title?: string;
  maxWidth?: 'xl' | false;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  children,
  title,
  maxWidth = 'xl'
}) => {
  return (
    <DashboardLayout title={title}>
      <Container
        maxWidth={maxWidth}
        sx={{ px: { xs: 2, sm: 3, md: 4 } }}
      >
        <Box sx={{ py: { xs: 2, sm: 3, md: 4 } }}>
          {children}
        </Box>
      </Container>
    </DashboardLayout>
  );
};
```

### Page Implementation Example
How to implement a standard admin page using AdminLayout:

```typescript
// pages/SurveyManagementPage.tsx
import React from 'react';
import { AdminLayout } from '../components/AdminLayout';
import { SurveyTable } from '../components/SurveyTable';

export const SurveyManagementPage: React.FC = () => {
  return (
    <AdminLayout title="Survey Management">
      <SurveyTable />
    </AdminLayout>
  );
};
```

### Advanced Layout Variants
For special cases requiring different container behavior:

```typescript
// Full-width layout for special cases
<AdminLayout maxWidth={false}>
  {/* Full viewport width content */}
</AdminLayout>

// With custom padding override
<AdminLayout>
  <Box sx={{ px: 0 }}> {/* Override padding for specific content */}
    {/* Custom padded content */}
  </Box>
</AdminLayout>
```

---

## 🌍 Browser Compatibility Requirements

### Supported Browsers
| Browser | Version Support | Testing Priority | Special Considerations |
|---------|----------------|------------------|----------------------|
| **Chrome** | Latest 2 versions | High | Primary development browser |
| **Firefox** | Latest 2 versions | High | Standard compliance testing |
| **Safari** | Latest 2 versions | High | TableContainer width issues |
| **Edge** | Latest 2 versions | Medium | Chromium-based compatibility |

### Safari-Specific Fixes
Safari requires additional CSS properties for proper table width utilization:

```typescript
// Safari compatibility for tables
const safariTableStyles = {
  WebkitOverflowScrolling: 'touch',
  '& .MuiTableContainer-root': {
    width: '100%',
    display: 'block'
  },
  '& .MuiTable-root': {
    width: '100%',
    tableLayout: 'auto'
  }
};
```

### Mobile Browser Support
- **iOS Safari**: Latest 2 versions
- **Android Chrome**: Latest 2 versions
- **Responsive Behavior**: All layouts must work from 375px to 1920px+ viewport widths

---

## 📐 Breakpoint Definitions

### Material-UI Theme Breakpoints
Standard breakpoints used throughout the application:

```typescript
// Theme breakpoint configuration
const breakpoints = {
  xs: 0,      // 0px - 599px (Mobile)
  sm: 600,    // 600px - 899px (Small tablet)
  md: 900,    // 900px - 1199px (Large tablet/Small desktop)
  lg: 1200,   // 1200px - 1535px (Desktop)
  xl: 1536    // 1536px+ (Large desktop)
};
```

### Responsive Design Targets
| Device Category | Viewport Range | Primary Use Case | Layout Considerations |
|----------------|----------------|------------------|----------------------|
| **Mobile** | 375px - 599px | Touch interaction | Single column, stacked elements |
| **Small Tablet** | 600px - 899px | Touch/mouse hybrid | Two column layouts possible |
| **Large Tablet** | 900px - 1199px | Predominantly mouse | Multi-column layouts |
| **Desktop** | 1200px - 1535px | Mouse interaction | Full feature layouts |
| **Large Desktop** | 1536px+ | Mouse interaction | Maximum data density |

### Responsive Implementation Pattern
```typescript
// ✅ CORRECT: Responsive property implementation
sx={{
  px: { xs: 2, sm: 3, md: 4 },        // Padding scales with screen size
  fontSize: { xs: '0.875rem', md: '1rem' }, // Text scales appropriately
  gridTemplateColumns: {
    xs: '1fr',
    sm: 'repeat(2, 1fr)',
    md: 'repeat(3, 1fr)'
  }
}}
```

---

## ✅ Visual Guidelines with Do/Don't Examples

### ✅ DO: Proper Container Usage

```typescript
// ✅ CORRECT: Full-width admin page layout
<AdminLayout>
  <TableContainer component={Paper} sx={{ width: '100%' }}>
    <Table sx={{ minWidth: 650 }}>
      {/* Table utilizes full available width */}
    </Table>
  </TableContainer>
</AdminLayout>
```

**Result**: Table uses full available screen width, maximizing data visibility and professional appearance.

### ❌ DON'T: Constrained Container Width

```typescript
// ❌ INCORRECT: Artificially constrained layout
<Container maxWidth="md"> {/* Only 900px wide */}
  <TableContainer component={Paper}>
    <Table>
      {/* Table is unnecessarily narrow */}
    </Table>
  </TableContainer>
</Container>
```

**Result**: Excessive whitespace, poor space utilization, unprofessional appearance.

### ✅ DO: Responsive Padding Implementation

```typescript
// ✅ CORRECT: Responsive padding that scales appropriately
<Container maxWidth="xl" sx={{ px: { xs: 2, sm: 3, md: 4 } }}>
  <Box sx={{ py: { xs: 2, sm: 3, md: 4 } }}>
    {/* Content has appropriate spacing at all screen sizes */}
  </Box>
</Container>
```

**Result**: Consistent, proportional spacing that adapts to screen size.

### ❌ DON'T: Fixed Padding Values

```typescript
// ❌ INCORRECT: Fixed padding doesn't adapt to screen size
<Container maxWidth="xl" sx={{ p: 4 }}> {/* Same padding on all screens */}
  {/* Content spacing is inappropriate on mobile */}
</Container>
```

**Result**: Too much padding on mobile, inconsistent spacing across devices.

### ✅ DO: Safari-Compatible Table Implementation

```typescript
// ✅ CORRECT: Cross-browser compatible table
<TableContainer
  component={Paper}
  sx={{
    width: '100%',
    overflowX: 'auto',
    WebkitOverflowScrolling: 'touch'
  }}
>
  <Table sx={{ minWidth: 650, width: '100%', tableLayout: 'auto' }}>
    {/* Table works correctly in all browsers */}
  </Table>
</TableContainer>
```

**Result**: Consistent table behavior across Chrome, Firefox, Safari, and Edge.

### ❌ DON'T: Browser-Specific Layout Issues

```typescript
// ❌ INCORRECT: Missing browser compatibility considerations
<TableContainer component={Paper}>
  <Table> {/* No width or compatibility styles */}
    {/* Table may not utilize full width in Safari */}
  </Table>
</TableContainer>
```

**Result**: Layout inconsistencies between browsers, poor user experience.

---

## 🔧 Implementation Checklist

### New Page Development
- [ ] Use `AdminLayout` component wrapper
- [ ] Implement `Container maxWidth="xl"`
- [ ] Apply responsive padding patterns
- [ ] Use standard table layout for data display
- [ ] Test in Chrome, Firefox, Safari, and Edge
- [ ] Verify responsive behavior from 375px to 1920px+
- [ ] Validate accessibility compliance

### Existing Page Refactoring
- [ ] Replace existing layout with `AdminLayout`
- [ ] Update container maxWidth to "xl"
- [ ] Implement responsive padding
- [ ] Add Safari-specific table fixes if needed
- [ ] Test cross-browser compatibility
- [ ] Verify no functionality regression
- [ ] Document any special layout requirements

### Code Review Requirements
- [ ] Container maxWidth is "xl" (unless specifically justified)
- [ ] Responsive padding follows standard pattern
- [ ] Tables use full available width
- [ ] Safari compatibility is considered
- [ ] Implementation follows documented patterns
- [ ] No excessive whitespace or poor space utilization

---

## 📋 Related Documentation

### Architecture References
- [Admin Container Architecture](../admin/architecture/admin-container-architecture.md) - Frontend architecture patterns
- [System Architecture](../architecture/system-architecture.md) - Overall system design

### Implementation Guides
- [Development Patterns](../mobile/development-patterns.md) - React Native patterns applicable to admin
- [API Development](../backend/api-development.md) - Backend integration patterns

### Troubleshooting
- [Safari Browser Issues](../gotchas/safari-browser-issues.md) - Browser-specific fixes
- [Mobile Compatibility](../gotchas/mobile-hermes-compatibility.md) - Cross-platform considerations

---

**Last Updated:** 2025-07-02
**Status:** Current
**Version:** 1.0
**Maintained By:** Frontend Team
**Review Cycle:** Monthly or on major Material-UI updates
