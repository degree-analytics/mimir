# API Trailing Slashes Authentication Failure

## Problem Description
API endpoints with trailing slashes cause 403 Forbidden errors even with valid authentication. This issue affects all authenticated API calls and can completely break frontend applications without obvious error messages.

## Symptoms
- 403 Forbidden errors on API calls that should work
- Authentication headers appear correct in network inspector
- Same API calls work without trailing slash
- Error occurs inconsistently across different endpoints
- Frontend applications fail to load data despite successful login

### Error Messages
```
HTTP 403 Forbidden
```

Network inspector shows:
- Request: `POST /api/surveys/` with Authorization header
- Response: 403 Forbidden
- Working version: `POST /api/surveys` with same Authorization header returns 200

## Root Cause
FastAPI automatically redirects URLs with trailing slashes to non-trailing slash versions using HTTP 308 (Permanent Redirect). During this redirect process, browsers strip the Authorization header for security reasons, causing the redirected request to be unauthenticated.

**Technical Flow:**
1. Frontend sends: `POST /api/surveys/` with `Authorization: Bearer <token>`
2. FastAPI responds: `308 Permanent Redirect` to `/api/surveys`
3. Browser follows redirect: `POST /api/surveys` **without Authorization header**
4. Backend sees unauthenticated request: `403 Forbidden`

## Solution

### Immediate Fix
Remove trailing slashes from all API endpoint calls:

```typescript
// ❌ WRONG - will cause 403 errors
api.get('/buildings/');
api.post('/tenants/', data);
api.put(`/surveys/${id}/`, payload);
api.delete(`/rooms/${id}/`);

// ✅ CORRECT
api.get('/buildings');
api.post('/tenants', data);
api.put(`/surveys/${id}`, payload);
api.delete(`/rooms/${id}`);
```

### Automated Fix
The project includes an ESLint rule and request interceptor as safety nets:

```typescript
// Request interceptor strips trailing slashes automatically
api.interceptors.request.use((config) => {
  if (config.url?.endsWith('/')) {
    config.url = config.url.slice(0, -1);
  }
  return config;
});
```

### Batch Fix Command
```bash
# Use ESLint to automatically fix all trailing slashes
npm run lint:fix
```

## Prevention

### ESLint Rule
The project includes a custom ESLint rule `no-api-trailing-slash` that errors on any API endpoints with trailing slashes:

```javascript
// .eslintrc.js
rules: {
  'no-api-trailing-slash': 'error'
}
```

### Development Practices
1. **Always omit trailing slashes** in API endpoint definitions
2. **Use ESLint auto-fix** during development: `npm run lint:fix`
3. **Review API calls** in pull requests for trailing slash patterns
4. **Test authentication** thoroughly when adding new endpoints

### Code Review Checklist
- [ ] No trailing slashes in API endpoint strings
- [ ] ESLint passes without trailing slash warnings
- [ ] Authentication tested with new endpoints

## Time Impact
**12 hours lost** - This issue caused a full day of debugging because:
- 403 errors don't indicate the real cause (trailing slash redirect)
- Authentication appears correct in network inspector
- Issue only manifests with authenticated endpoints
- FastAPI's redirect behavior is not immediately obvious

## Related Issues
- [Variable Name Mismatches](./variable-name-mismatches.md) - Another environment configuration issue
- [Environment Setup](../workflows/environment-setup.md#authentication-failures) - Authentication troubleshooting

## Keywords
API, authentication, FastAPI, trailing slashes, 403 forbidden, HTTP redirect, authorization header, browser security
