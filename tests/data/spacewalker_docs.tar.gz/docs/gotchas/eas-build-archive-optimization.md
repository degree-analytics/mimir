# EAS Build Archive Optimization for Monorepos

## Problem: 3.0GB Archive Size in CI/CD

**Symptom**: EAS build failures with "Your project archive is 3.0 GB. You can reduce its size and the time it takes to upload by excluding files that are unnecessary for the build process in .easignore file."

**Root Cause**: EAS uploads the entire monorepo, including:
- Large `.git` directory from `fetch-depth: 0` in GitHub Actions
- All `node_modules` directories across the monorepo (1.0GB at root)
- Backend virtual environments (`.venv` - 839MB)
- All other project directories not needed for mobile builds

## Solution: Simplified Pattern with Leading Slashes

### 1. Root Directory `.easignore` Configuration

Create `.easignore` in the repository root with this simplified pattern:

```bash
# .easignore - Monorepo EAS Build Configuration

# CRITICAL: Exclude large directories at root (these are huge!)
/node_modules
/.venv
/.git
/.expo
/dist
/build

# Exclude all node_modules everywhere
**/node_modules

# Exclude other apps completely
/apps/admin
/apps/backend

# Exclude documentation and CI/CD
/docs
/.github
/scripts/test
/scripts/infra

# Exclude test files
**/*.test.js
**/*.test.ts
**/*.spec.js
**/*.spec.ts
**/__tests__

# Exclude build artifacts
**/*.log
**/dist
**/build
**/.next
**/.turbo
**/.DS_Store

# Exclude Python artifacts
**/__pycache__
**/*.pyc
**/.pytest_cache
**/.ruff_cache

# Exclude environment files (not needed for build)
.env*
!.env.example
```

### Key Changes from Previous Approach:
- **Leading slashes** (`/node_modules`) to properly exclude root directories
- **Wildcard patterns** (`**/node_modules`) to exclude nested directories
- **Simpler structure** without complex deny-all/allow-specific pattern
- **Proven to work** - reduced archive from 3.0GB to under 2.0GB limit

### 2. EAS Configuration

Keep `eas.json` in the mobile app directory (`apps/mobile/eas.json`):

```json
{
  "cli": {
    "version": ">= 12.0.0",
    "appVersionSource": "remote",
    "requireCommit": false
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "preview": {
      "distribution": "internal"
    },
    "production": {
      "distribution": "internal"
    }
  }
}
```

### 3. GitHub Actions Configuration

Run EAS from the mobile directory:

```yaml
- name: Trigger EAS Build
  env:
    EXPO_TOKEN: ${{ secrets.EXPO_TOKEN }}
  run: |
    cd apps/mobile
    eas build --profile preview --platform all --non-interactive --no-wait
```

## Key Insights

### Why Local Testing is Misleading

```bash
# ❌ This only shows mobile directory size (misleading)
cd apps/mobile
eas build:inspect --profile preview --platform android
# Shows ~350MB

# ✅ EAS actually uploads entire monorepo
# Archive includes all directories from repository root
```

### Why Previous Approaches Failed

1. **Local `.easignore` in `apps/mobile/`**: Only affects files within mobile directory
2. **EAS_NO_VCS=1**: Doesn't solve the fundamental issue of uploading entire monorepo
3. **Relative paths in `.easignore`**: EAS processes from repository root, not mobile directory

### Why This Solution Works

1. **Root-level `.easignore`**: Controls what gets uploaded from repository root
2. **Deny-all pattern**: Starts with `*` to exclude everything
3. **Selective whitelist**: Only includes essential files and directories
4. **Explicit re-exclusions**: Removes `node_modules` even from whitelisted directories

## Testing the Solution

```bash
# Test archive size locally (from repository root)
tar --exclude-from=.easignore -czf test-archive.tar.gz .
ls -lh test-archive.tar.gz
# Should show <500MB instead of 3.2GB

# Verify EAS build success
cd apps/mobile
eas build --profile preview --platform android
# Should complete without archive size errors
```

## Common Pitfalls

### 1. Wrong `.easignore` Location
```bash
# ❌ Wrong: Only affects mobile directory
apps/mobile/.easignore

# ✅ Correct: Affects entire monorepo upload
.easignore
```

### 2. Missing Wildcard Pattern
```bash
# ❌ Wrong: Only excludes specific files
apps/backend/
apps/admin/

# ✅ Correct: Deny all, then allow specific
*
!/apps/mobile/
!/packages/
```

### 3. Forgetting Node Modules Re-exclusion
```bash
# ✅ Required: Re-exclude node_modules in whitelisted dirs
!/apps/mobile/
/apps/mobile/node_modules  # This line is critical
```

## Related Documentation

- [Mobile Build Pipeline](../mobile/build-pipeline.md) - Complete build troubleshooting
- [CI/CD Build Guide](../workflows/ci-cd-build-guide.md) - Pipeline architecture
- [Mobile Troubleshooting](../mobile/troubleshooting-guide.md) - Development issues

## Status

✅ **RESOLVED**: EAS build archive size optimization implemented successfully
- Archive size reduced from 3.0GB to under 2.0GB limit
- CI/CD pipeline builds completing successfully
- Solution verified across multiple build profiles
- Simplified pattern proven more reliable than deny-all approach

---

*Last Updated: 2025-07-19*  
*Issue: EAS build archive size optimization*  
*Solution: Simplified .easignore with leading slashes and wildcards*