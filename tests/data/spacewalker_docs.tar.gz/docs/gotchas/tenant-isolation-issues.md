# Tenant Isolation Issues & Solutions

## Purpose
Documents critical tenant isolation bugs, their symptoms, root causes, and solutions. Essential for maintaining data security and preventing cross-tenant data exposure in multi-tenant environments.

## When to Use This
- FICM codes displaying as "-" instead of actual values
- Demo data creation showing empty or incorrect data
- Cross-tenant data visibility in queries
- Testing tenant isolation functionality
- **Keywords:** tenant isolation, FICM, cross-tenant, data leakage, Row Level Security

**Version:** 1.0 (Post-FICM tenant filtering fix)
**Date:** 2025-07-16
**Status:** Current - Production tenant isolation patterns

---

## 🚨 Critical Issue: FICM Codes Display as "-" (FIXED)

### Symptoms
- FICM codes appear as "-" in admin UI room attributes instead of expected values like "210", "110", "730"
- Some rooms show correct FICM codes while others show "-"
- Issue appears intermittently or affects specific tenants

### Root Cause
**Missing tenant filtering in demo data creation queries**

The `create_demo.py` script was missing `tenant_id` filtering when querying FICM data:

```python
# ❌ PROBLEMATIC CODE (cross-tenant query)
ficm_design_types = self.session.query(FICMDesignType).all()
ficm_base_codes = self.session.query(FICMBaseCode).all()
```

This caused the system to pull FICM codes from **ALL tenants** instead of the current tenant's data, leading to incorrect mappings and display issues.

### Solution Applied
**Added proper tenant isolation filtering:**

```python
# ✅ FIXED CODE (tenant-isolated query)
ficm_design_types = (
    self.session.query(FICMDesignType)
    .filter(FICMDesignType.tenant_id == self.tenant_id)
    .all()
)
ficm_base_codes = (
    self.session.query(FICMBaseCode)
    .filter(FICMBaseCode.tenant_id == self.tenant_id)
    .all()
)
```

### Verification Steps
1. Run `just db_demo` to create demo data with proper tenant filtering
2. Start services with `just up`
3. Navigate to admin UI room attributes
4. Confirm FICM codes display actual values instead of "-"
5. Use `just ficm_status` to verify FICM data integrity

---

## 🛡️ Tenant Isolation Best Practices

### Always Filter by tenant_id
Every database query MUST include tenant filtering:

```python
# ✅ CORRECT PATTERN
records = session.query(Model).filter(Model.tenant_id == current_tenant_id).all()

# ❌ DANGEROUS PATTERN
records = session.query(Model).all()  # Exposes all tenant data
```

### Test Tenant Isolation
Use the new unit test pattern for verifying tenant isolation:

```python
def test_tenant_isolation():
    # Create data for tenant A
    tenant_a_data = create_test_data(tenant_id=1)

    # Create data for tenant B
    tenant_b_data = create_test_data(tenant_id=2)

    # Query as tenant A - should only see tenant A data
    result = get_data_for_tenant(tenant_id=1)
    assert all(item.tenant_id == 1 for item in result)
    assert len(result) == len(tenant_a_data)
```

### Commands for Tenant Isolation Verification
```bash
# Verify FICM data structure and tenant isolation
just ficm_status

# Run tenant isolation specific tests
just test_tenant_isolation

# Verify FICM codes after demo data creation
just ficm_demo_verify
```

---

## 🔍 Debugging Tenant Issues

### Check Session Context
Verify the current tenant context is properly set:

```python
# In your code, check current tenant
current_tenant = get_current_tenant_id()
logger.info(f"Operating in tenant context: {current_tenant}")
```

### Verify RLS Policies
Check that Row Level Security policies are active:

```sql
-- Check RLS status for tables
SELECT schemaname, tablename, rowsecurity
FROM pg_tables
WHERE rowsecurity = true;
```

### Audit Query Results
Always log tenant context for debugging:

```python
logger.info(f"Found {len(results)} records for tenant {tenant_id}")
```

---

## 🧪 Testing Patterns

### Unit Test Template
```python
@pytest.fixture
def multi_tenant_session():
    """Session with data for multiple tenants"""
    # Setup test data for multiple tenants
    pass

def test_function_respects_tenant_isolation(multi_tenant_session):
    """Verify function only returns current tenant's data"""
    result = your_function(tenant_id=1)
    assert all(item.tenant_id == 1 for item in result)
```

### Integration Test Pattern
```python
def test_api_endpoint_tenant_isolation():
    """Verify API endpoints respect tenant boundaries"""
    # Test with different tenant contexts
    # Verify no cross-tenant data leakage
```

---

## 🚨 Security Implications

### Data Exposure Risk
- **HIGH RISK**: Cross-tenant queries can expose sensitive data
- **IMPACT**: Potential data breach, compliance violations
- **PREVENTION**: Always filter by tenant_id in queries

### Compliance Requirements
- Row Level Security (RLS) enforcement is mandatory
- All queries must be tenant-scoped
- Regular tenant isolation testing required

---

## 📋 Prevention Checklist

- [ ] All database queries include tenant_id filtering
- [ ] Unit tests verify tenant isolation for new functions
- [ ] Demo data creation respects tenant boundaries
- [ ] API endpoints validate tenant context
- [ ] Regular tenant isolation audits performed

---

## Related Documentation
- [Tenant Management System Guide](../backend/tenant-management.md)
- [Security Architecture](../architecture/security-architecture.md)
- [Testing Guide](../workflows/testing-guide.md)
- [Database Design](../backend/database-design.md)
