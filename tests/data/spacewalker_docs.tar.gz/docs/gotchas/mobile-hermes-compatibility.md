# Mobile Hermes Runtime Compatibility Issues

## Purpose
Comprehensive troubleshooting guide for React Native Hermes engine compatibility issues, package version mismatches, and their solutions to prevent common mobile development pitfalls.

## When to Use This
- Troubleshooting mobile app crashes on physical devices
- Resolving Hermes engine compatibility errors
- Fixing package version conflicts in React Native projects
- Keywords: Hermes crash, React Native compatibility, package versions, mobile debugging

**Severity:** High - Can block mobile app deployment
**Platform:** React Native with Hermes engine
**Last Updated:** 2025-06-28

## The Problem

### Symptoms
- Mobile app gets stuck on the purple Spacewalker splash screen when running on physical device (iPhone)
- App downloads from exp://192.168.11.27:8081 but crashes immediately after splash screen
- Works perfectly fine in Metro development mode (Expo Go)
- Only fails when running with Hermes engine on device

### Errors Encountered
```
TypeError: Cannot read property 'S' of undefined, js engine: hermes
TypeError: Cannot read property 'default' of undefined, js engine: hermes
```

These cryptic errors indicated minified/compiled third-party code failing in Hermes runtime.

## What We Tried That Didn't Work

### Circular Dependencies Investigation ❌
- Ran `madge --circular --extensions ts,tsx src` to check for circular dependencies
- Found NO circular dependencies in the codebase
- Fixed navigation type imports (moved `RootStackParamList` from App.tsx to navigation.types.ts)
- **Result**: Hermes errors persisted - this was not the cause

### Theme Import Issues ❌
- Discovered theme imports had changed from named to default exports
- Fixed all theme imports back to named imports throughout the app
- Removed conflicting default export from theme.ts
- **Result**: Hermes errors persisted after these fixes

### Our Application Code Analysis ❌
- Added extensive debug logging to trace execution
- Discovered the error happens AFTER all imports succeed but BEFORE App component renders
- **Result**: Confirmed the issue is NOT in our code - it's a third-party package compatibility issue

### StyleSheet.create at Module Level ❌
- Initially suspected StyleSheet.create calls using theme at module level
- **Result**: Investigation showed this was not the root cause

## The Version Mismatch Warnings

When running the app, Expo displayed these warnings about incompatible package versions:
```
The following packages should be updated for best compatibility with the installed expo version:
  @react-native-async-storage/async-storage@2.2.0 - expected version: 2.1.2
  expo@53.0.11 - expected version: 53.0.12
  react@18.3.1 - expected version: 19.0.0
  react-native@0.79.3 - expected version: 0.79.4
  react-native-gesture-handler@2.26.0 - expected version: ~2.24.0
  react-native-reanimated@3.18.0 - expected version: ~3.17.4
  @types/react@18.3.23 - expected version: ~19.0.10
  jest-expo@51.0.4 - expected version: ~53.0.7
```

Note: We were already on Expo SDK 54, but other packages were mismatched.

## The Solution - Update All Warning Packages

Instead of a methodical approach, we decided to update ALL the packages that Expo warned about:

### Updated Package Versions in `/apps/mobile/package.json`:
```json
// FROM (causing Hermes crash):
"@react-native-async-storage/async-storage": "^2.1.2",  // Actually 2.2.0
"expo": "~53.0.0",                                       // Actually 53.0.11
"react": "18.3.1",
"react-native": "0.79.3",
"react-native-gesture-handler": "^2.26.0",
"react-native-reanimated": "^3.18.0",
"@types/react": "^18.3.0",                              // Actually 18.3.23
"jest-expo": "^51.0.4",
"react-test-renderer": "18.3.1",

// TO (fixed Hermes crash):
"@react-native-async-storage/async-storage": "2.1.2",
"expo": "~53.0.12",
"react": "19.0.0",
"react-native": "0.79.4",
"react-native-gesture-handler": "~2.24.0",
"react-native-reanimated": "~3.17.4",
"@types/react": "~19.0.10",
"jest-expo": "~53.0.7",
"react-test-renderer": "19.0.0",  // Also updated to match React version
```

## Additional Changes Required

### Root Workspace Package.json Changes
The root `/package.json` had overrides forcing React 18.3.1, which conflicted with our React 19 update:

```json
// FROM:
"overrides": {
  "@types/react": "^18.3.0",
  "react": "18.3.1",
  "react-dom": "18.3.1"
},
"resolutions": {
  "@types/react": "^18.3.0",
  "react": "18.3.1",
  "react-dom": "18.3.1",
  // ...
}

// TO:
"overrides": {
  "@types/react": "~19.0.10",
  "react": "19.0.0",
  "react-dom": "19.0.0"
},
"resolutions": {
  "@types/react": "~19.0.10",
  "react": "19.0.0",
  "react-dom": "19.0.0",
  // ...
}
```

### Dockerfile Changes (NOT suitable for production)
The project doesn't generate `package-lock.json`, so we had to modify `/apps/mobile/Dockerfile`:

1. **Changed from `npm ci` to `npm install`**:
```dockerfile
# FROM:
RUN --mount=type=cache,target=/root/.npm \
    npm ci --prefer-offline --fetch-retries=5 --fetch-timeout=60000 --maxsockets=1

# TO:
RUN --mount=type=cache,target=/root/.npm \
    npm install --fetch-retries=5 --fetch-timeout=60000 --maxsockets=1 --legacy-peer-deps
```

2. **Added explicit dependency installation in development stage**:
```dockerfile
# Added these lines:
COPY --from=deps /usr/src/app/apps/mobile/node_modules ./node_modules
RUN npm install --production=false --legacy-peer-deps
```

3. **Why `--legacy-peer-deps` was needed**: React 19 is newer than what many packages expect, causing peer dependency conflicts

### Additional Package Updates Not in Warnings
- `react-test-renderer`: Updated from 18.3.1 to 19.0.0 to match React version

## Result: HERMES CRASH FIXED! ✅

After updating all the packages to match Expo's warnings:
1. App launches successfully on physical device ✅
2. No more "Cannot read property 'S' of undefined" errors ✅
3. Login functionality works ✅
4. Navigation throughout the app works ✅

### Why This Fixed the Issue
The cryptic Hermes errors were caused by package version mismatches creating incompatible JavaScript that:
- Worked in Metro's more forgiving development environment
- Failed in Hermes's stricter production runtime

The key was updating React from 18.3.1 to 19.0.0, along with ensuring all related packages were compatible.

## ⚠️ Production Considerations

**WARNING**: The current fix uses workarounds NOT suitable for production:

1. **No package-lock.json**
   - The project doesn't generate lock files
   - This means builds aren't reproducible
   - Different developers might get different dependency versions

2. **--legacy-peer-deps flag**
   - We're bypassing npm's peer dependency checks
   - This could lead to runtime issues with incompatible packages
   - Only needed because React 19 is newer than what many packages expect

3. **Test Suite is Broken**
   - The package updates broke all tests
   - React 19 compatibility issues with testing libraries
   - Tests must be fixed before deploying to production

4. **Dockerfile Modifications**
   - Changed from `npm ci` to `npm install` (less reliable)
   - Added redundant dependency installation steps
   - These changes reduce build reproducibility

## Recommended Next Steps

1. **Fix the test suite** to work with React 19
2. **Generate proper lock files** (investigate why package-lock.json isn't being created)
3. **Consider package strategy**:
   - Option A: Stay on React 19 and wait for packages to update
   - Option B: Find a compatible set of packages for React 18
4. **Remove workarounds** once proper solutions are in place
5. **Document the minimum package updates** needed (we updated everything, but maybe only React 19 was needed?)

## Prevention Strategies

### For Future Projects
- **Always check Expo compatibility warnings** before deploying to devices
- **Test on physical devices early** in development cycle
- **Use exact package versions** rather than ranges for critical dependencies
- **Generate and commit lock files** for reproducible builds
- **Set up automated testing** on device builds, not just development

### Monitoring
- **Package audit tools**: Regularly run `expo doctor` and `npm audit`
- **Version tracking**: Monitor Expo SDK compatibility warnings
- **Device testing**: Include physical device testing in CI/CD pipeline

## Related Issues
- React Native Hermes engine compatibility
- Expo SDK package version management
- Metro vs Hermes runtime differences
- React 19 compatibility with React Native ecosystem

## Related Documentation
- Mobile Development Guide → ../mobile/development/README.md
- Mobile Architecture Overview → ../mobile/architecture/README.md
- Backend Deployment Issues → ../gotchas/deployment-gotchas.md

---
**Severity:** High
**Impact:** Blocks mobile app deployment
**Resolution Time:** 4-6 hours (investigation + fix)
**Last Updated:** 2025-06-28
