# Production Deployment Gotchas

## SSL Certificate Wildcard Limitations

### Problem
AWS wildcard certificates only work for one subdomain level:
- `*.degreeanalytics.com` matches `app.degreeanalytics.com` ✅
- `*.degreeanalytics.com` does NOT match `admin.spacewalker.degreeanalytics.com` ❌

### Solution
Create a separate certificate for `*.spacewalker.degreeanalytics.com` to support:
- admin.spacewalker.degreeanalytics.com
- backend.spacewalker.degreeanalytics.com
- mobile.spacewalker.degreeanalytics.com

### Implementation
```yaml
# sam/certificates/template.yaml
prod:
  ExistingCertArn: "arn:aws:acm:us-east-1:352676346183:certificate/YOUR-CERT-ID"
```

## DNS Validation for Multi-Level Subdomains

### Problem
CloudFormation's automatic DNS validation can conflict when creating certificates for multi-level subdomains if validation records already exist.

### Error Message
```
The request contains an invalid set of changes for a resource record set
'CNAME _c1d450bb245fd6c20c33cf768e5fd1c6.spacewalker.degreeanalytics.com.'
```

### Solution
1. Remove `DomainValidationOptions` from certificate template
2. Let ACM create validation records automatically
3. Or manually create validation records before deploying

## CloudFormation Stack States

### ROLLBACK_COMPLETE State
Stack is stuck and cannot be updated. Must be deleted before redeploying.

### Error Message
```
Stack is in UPDATE_ROLLBACK_COMPLETE state - this may cause deployment issues
```

### Solution
```bash
# Option 1: Delete via CloudFormation
AWS_PROFILE=production aws cloudformation delete-stack --stack-name STACK_NAME

# Option 2: Delete with justfile
just stack delete prod STACK_NAME --force
```

### Prevention
- Always check stack status before deploying
- Use `just stack status prod` to verify state

## Security Group IP Management

### Dynamic IP Changes
Your public IP can change when:
- Moving locations (home → office → coffee shop)
- ISP assigns new IP
- VPN connection changes

### Symptoms
- SSH connection times out
- Cannot access bastion host
- Database tunnel fails

### Solution
```bash
# Check current IP
curl -s ifconfig.me

# Add current IP to bastion
just bastion_allow_me prod 8

# Verify access
just bastion_list_ips prod
```

### Best Practices
- Use temporary IPs with descriptive timestamps
- Clean up old IPs regularly: `just bastion_cleanup_temp_ips prod`
- Consider VPN for stable access

## Production Account Differences

### Region Mismatch
Production uses `us-east-1` while dev uses `us-east-2`.

### Common Errors
- "Stack does not exist" when in wrong region
- Resources created in wrong region
- Cross-region reference failures

### Prevention
Scripts now auto-detect region based on environment:
```python
# scripts/database/db_helper.py
self.region = "us-east-1" if env == "prod" else "us-east-2"
```

### AWS Profile Issues
Production requires `AWS_PROFILE=production`.

### Solution
The justfile and scripts now handle this automatically, but for manual commands:
```bash
export AWS_PROFILE=production
aws s3 ls  # Will use production account
```

## Certificate Export Conflicts

### Problem
Multiple stacks trying to export the same certificate ARN.

### Error Message
```
Export with name prod-spacewalker-certificate-arn is already exported by stack prod-spacewalker-certificates
```

### Solution
1. Use separate certificates stack (current approach)
2. Or hardcode certificate ARNs in service templates during transition

## Database Migration on Startup

### Automatic Behavior
Backend service runs migrations automatically on startup:
1. Checks for alembic_version table
2. Runs `alembic upgrade head`
3. Seeds FICM data
4. Loads demo data if `LOAD_DEMO_DATA=true`

### Monitoring
```bash
# Check backend logs for migration status
AWS_PROFILE=production aws logs tail /ecs/prod-spacewalker-backend --since 1h | grep -i migration
```

### Manual Intervention
If migrations fail, connect via bastion:
```bash
just db_quick_connect prod
# Then run migrations manually
```

## ECS Service Updates

### Health Check Grace Period
New tasks need time to:
1. Pull container image
2. Run database migrations
3. Start application
4. Pass health checks

### Symptoms
- Tasks constantly restarting
- "Unhealthy" status in ECS console
- ALB target group shows unhealthy

### Solution
Backend has independent health check at `/health/` that doesn't depend on database.

### Monitoring
```bash
# Check service status
AWS_PROFILE=production aws ecs describe-services \
  --cluster prod-spacewalker-ecs-cluster \
  --services prod-spacewalker-backend \
  --query "services[0].deployments"
```

## Common Production Issues

### 1. "No changes to deploy"
CloudFormation thinks nothing changed when you expect updates.

**Solution**: Add a dummy parameter to force update:
```yaml
StackStateFix:
  Type: String
  Default: "1.4"  # Increment to force update
```

### 2. Cross-Stack Dependencies
Services depend on exports from other stacks.

**Order matters**:
```
foundation → certificates → database → cluster → services → dns
```

### 3. Secrets Manager Permissions
ECS tasks need specific permissions to read secrets.

**Check IAM role** has:
```json
{
  "Effect": "Allow",
  "Action": ["secretsmanager:GetSecretValue"],
  "Resource": "arn:aws:secretsmanager:*:*:secret:prod/spacewalker/*"
}
```

## Production Deployment Checklist

Before deploying to production:
- [ ] Enable production mode: `(just prod enable --minutes=120)`
- [ ] Verify AWS profile: `aws sts get-caller-identity`
- [ ] Check existing stacks: `just health prod`
- [ ] Add bastion access: `just bastion_allow_me prod 8`
- [ ] Have rollback plan ready
- [ ] Monitor CloudWatch logs during deployment
- [ ] Test health endpoints after deployment
- [ ] Remove temporary bastion access when done
