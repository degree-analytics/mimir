# BACnet APDU Timeout Debugging

## Purpose
Diagnostic procedures for troubleshooting BACnet APDU timeout issues and WhoIs/unicast communication failures in containerized IoT systems. Essential reference for resolving Docker networking problems, BACpypes3 configuration issues, and container connectivity failures.

## When to Use This
- BACnet APDU timeout errors during device communication
- WhoIs requests succeeding but ReadProperty operations failing
- Container networking issues preventing BACnet unicast communication
- BACpypes3 application initialization problems
- Docker bridge network connectivity troubleshooting
- Keywords: BACnet timeout, APDU failure, container networking, BACpypes3, WhoIs unicast, Docker diagnostics

**Version:** 2.0 (Migrated from Cursor rules)
**Date:** 2025-06-29
**Status:** Current - Production Debugging Procedures

---

## 🔍 Initial APDU Timeout Checks

### Container Network Verification
First step when encountering APDU timeouts is confirming Docker network connectivity:

```bash
# Verify both containers are running and have IP addresses on the same network
docker inspect occupancy-bacnet-connector testing-bacnet-client \
  --format '{{.Name}} - {{.NetworkSettings.Networks.app_bacnet_network.IPAddress}}'
```

Expected output shows both containers with IPs on `app_bacnet_network` (e.g., `192.168.22.10`, `192.168.22.11`).

### Basic Network Connectivity Test
Confirm Layer 3 connectivity between containers:

```bash
# Basic ping test from client to server container
./scripts/diagnostics/ping-app-server-from-client.sh <server_ip>
```

If ping fails, troubleshoot Docker network configuration before proceeding to BACnet-specific debugging.

### Server Application Health Check
Verify the BACnet server application is running correctly:

```bash
# Check occupancy-bacnet-connector logs for startup errors
./scripts/docker-run.sh logs-snapshot occupancy-bacnet-connector
```

Look for:
- ✅ "Application created with args: ..." - Shows `Application.from_args()` succeeded
- ✅ "BACnet application services started. Running indefinitely..." - Confirms `app.run()` reached
- ❌ BACpypes initialization errors or startup failures

### WhoIs Broadcast Test
Test basic BACnet stack functionality:

```bash
# Test if server responds to WhoIs broadcasts
./scripts/diagnostics/whois-app.sh
```

Successful `IAm` response indicates the server's BACnet stack is operational and broadcasting. If this fails, focus on server application and configuration issues.

---

## 🎯 WhoIs Works but Unicast Fails (APDU Timeout)

When broadcast WhoIs succeeds but unicast operations (ReadProperty, WriteProperty) timeout, the issue is typically in server configuration or unicast handling.

### Server Environment Configuration

#### Critical `.env` Settings
Verify these settings in the server's `.env` file:

```bash
# BACNET_IP_ADDRESS must be the EXACT container IP (not CIDR notation)
BACNET_IP_ADDRESS=192.168.22.10    # ✅ Correct: specific IP
# BACNET_IP_ADDRESS=192.168.22.10/24  # ❌ Wrong: CIDR notation

# BACNET_PORT must match expected BACnet port
BACNET_PORT=47808
```

**Critical**: BACpypes3 `Application.from_args()` requires the specific IP address for binding, not CIDR notation. CIDR may be used elsewhere but the application's listening address must be precise.

#### Validation Commands
```bash
# Check current container IP
docker inspect occupancy-bacnet-connector \
  --format '{{.NetworkSettings.Networks.app_bacnet_network.IPAddress}}'

# Verify .env matches container IP
grep BACNET_IP_ADDRESS .env
```

### BACpypes Application Initialization

#### Server Code Verification (`src/main.py`)
Ensure proper BACpypes3 application setup:

```python
# Verify address format in application initialization
# Should be formatted as <IP>:<PORT> (e.g., "192.168.22.10:47808")
app = Application.from_args(ns)  # ns.address must be "IP:PORT" format

# Confirm device object configuration before app.run()
app.this_device_object.segmentationSupported = True
app.this_device_object.vendorIdentifier = YOUR_VENDOR_ID

# Ensure app.run() is reached and runs indefinitely
await app.run()
```

#### Server Log Analysis
Look for these key log entries:

```bash
# Application initialization confirmation
"Application created with args: ..."

# Service startup confirmation
"BACnet application services started. Running indefinitely..."

# Manual IAm request (if implemented)
"Sending manual IAmRequest..."
```

Absence of errors after startup is good, but doesn't guarantee unicast request processing capability.

---

## 🔧 Client-Side Debugging

### Enhanced APDU Debugging
Enable detailed client-side logging when using diagnostic scripts:

```bash
# Enable APDU debugging in client container
# Add this to ./scripts/diagnostics/read-app.sh docker exec call:
-e BACNET_APDU_DEBUG=1

# Example modified command:
docker exec -e BACNET_APDU_DEBUG=1 testing-bacnet-client \
  bacrp <device_id> <object_type>:<object_instance> <property>
```

### Additional Debug Variables
Other useful BACnet debugging environment variables:

```bash
# Log to file within container
-e BACNET_DEBUG_FILE=/tmp/bacnet_debug.log

# Enable specific debug categories
-e BACNET_NET_DEBUG=1      # Network layer debugging
-e BACNET_APP_DEBUG=1      # Application layer debugging
```

### Manual Testing Commands
Direct bacrp testing with debug output:

```bash
# Basic ReadProperty test with timeout
docker exec testing-bacnet-client \
  bacrp 1001 device:1001 object-name

# With enhanced debugging
docker exec -e BACNET_APDU_DEBUG=1 testing-bacnet-client \
  bacrp 1001 device:1001 object-name
```

---

## 🛡️ Network and Firewall Considerations

### Docker Bridge Network Issues
Although uncommon, check for host-level interference:

```bash
# Verify Docker network configuration
docker network inspect app_bacnet_network

# Check for conflicting firewall rules
iptables -L | grep 47808
ufw status | grep 47808
```

### Container Port Binding
Ensure the server container properly binds to the BACnet port:

```bash
# Check if port is bound inside container
docker exec occupancy-bacnet-connector netstat -ln | grep 47808

# Should show: 0.0.0.0:47808 or specific IP:47808
```

---

## 🔄 Rebuild and Restart Procedures

### After Configuration Changes
When modifying `.env` files or critical application code:

```bash
# 1. Rebuild the relevant Docker image
./scripts/docker-build.sh [--no-cache] <service_name_if_specific>

# 2. Stop all relevant containers
./scripts/dev/stop-app-with-client.sh
# Alternative: docker compose -f docker/docker-compose.yml down

# 3. Restart containers with new configuration
./scripts/dev/start-app-with-client.sh
```

**Note**: Always use helper scripts when available for consistent container management.

### Verification After Restart
```bash
# 1. Verify container network assignments
docker inspect occupancy-bacnet-connector testing-bacnet-client \
  --format '{{.Name}} - {{.NetworkSettings.Networks.app_bacnet_network.IPAddress}}'

# 2. Check server application logs
./scripts/docker-run.sh logs-snapshot occupancy-bacnet-connector

# 3. Test WhoIs functionality
./scripts/diagnostics/whois-app.sh

# 4. Test unicast ReadProperty
./scripts/diagnostics/read-app.sh
```

---

## 🔍 Advanced Troubleshooting

### BACwi Tool Issues
If `bacwi -d <file>` fails but plain `bacwi` works:

```bash
# Test basic device discovery
docker exec testing-bacnet-client bacwi

# If the above works but file redirection fails:
docker exec testing-bacnet-client bacwi -d /tmp/devices.txt
```

This may indicate a tool-specific issue with file redirection in the containerized environment. Prioritize debugging server responsiveness if basic WhoIs works.

### Segmentation Support Issues
If ReadProperty fails for large responses:

```python
# Ensure segmentation is properly configured
app.this_device_object.segmentationSupported = True
app.this_device_object.maxSegmentsAccepted = 32  # Or appropriate value
```

### Vendor Identifier Validation
Incorrect vendor identifier can cause communication issues:

```python
# Set valid vendor identifier before app.run()
app.this_device_object.vendorIdentifier = 1234  # Use your assigned vendor ID
```

---

## 📊 Diagnostic Checklist

### Container Network Health
- [ ] Both containers running with IP addresses on same Docker network
- [ ] Basic ping connectivity between containers successful
- [ ] No host firewall rules blocking BACnet port (47808)
- [ ] Docker network inspect shows proper configuration

### Server Configuration
- [ ] `BACNET_IP_ADDRESS` matches exact container IP (no CIDR notation)
- [ ] `BACNET_PORT` correctly set (typically 47808)
- [ ] Server logs show successful BACpypes3 initialization
- [ ] Application reaches and runs `app.run()` indefinitely

### BACnet Stack Health
- [ ] WhoIs broadcast test successful (receives IAm response)
- [ ] Server responds to basic device discovery
- [ ] Segmentation support properly configured
- [ ] Valid vendor identifier set

### Unicast Communication
- [ ] ReadProperty operations complete without APDU timeout
- [ ] Client-side debugging enabled for detailed error analysis
- [ ] Server processes unicast requests correctly
- [ ] No network routing issues between containers

---

## 📋 Related Troubleshooting Documentation

### Container and Networking Issues
- **[Docker Environment Setup](../setup/development-setup.md)** - Container configuration and networking setup
- **[Development Environment Issues](../setup/development-setup.md)** - Common container and networking problems

### Backend Development
> 🚀 **Backend Teams**: See [Backend Development](../backend/development/) for BACnet implementation details and server configuration
> 🚀 **IoT Integration**: See [Backend IoT Integration](../backend/iot-integration/) for BACnet protocol implementation specifics

### Deployment and Operations
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Production container deployment procedures
- **[Development Tools](../development/development-tools.md)** - Diagnostic scripts and automation tools

---

**Status**: ✅ **PRODUCTION DEBUGGING PROCEDURES**
**Last Updated**: 2025-06-29
**Applies To**: BACnet IoT integration, Docker containerized applications
**Integration**: Container networking, BACpypes3 applications, diagnostic workflows

---

*This debugging guide provides systematic procedures for resolving BACnet APDU timeout issues in containerized environments. Following these procedures ensures proper network connectivity, correct server configuration, and successful unicast communication for IoT device integration.*
