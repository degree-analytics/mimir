# AWS SES Sandbox Limitations

## Overview
AWS Simple Email Service (SES) operates in "sandbox mode" by default, which restricts email sending capabilities. This affects all email functionality in development and staging environments.

## Key Limitations

### 1. Recipient Verification Required
- **In sandbox mode**: Can only send emails to verified email addresses
- **Error message**: `MessageRejected - Email address is not verified`
- **Solution**: Recipients must be verified in AWS SES before receiving emails

### 2. Currently Verified Emails (as of 2025-08-01)
```
campusiq.com                    # Domain (all @campusiq.com addresses)
chad.walters@campusiq.com       # Individual verified
chad.walters@gmail.com          # Individual verified  
jeremiah@degreeanalytics.com    # Individual verified
noreply@littleponies.com        # Individual verified
spacewalker@campusiq.com        # System sender address
```

### 3. How to Verify New Email Addresses
```bash
# Add a new email for verification
AWS_PROFILE=development aws ses verify-email-identity \
  --email-address user@example.com \
  --region us-east-2

# List all verified identities
AWS_PROFILE=development aws ses list-identities \
  --region us-east-2
```

## Impact on Features

### Tenant Invitations
- Invitations will be created in the database
- Email will only send if recipient is verified
- UI will show "Email Sent: Yes" even if email fails
- Check backend logs for actual email status

### Password Resets
- Only work for verified email addresses
- Users with unverified emails cannot receive password reset links

### Notifications
- All email notifications affected by sandbox restrictions
- Consider using test accounts with verified emails

## Moving to Production
To remove sandbox restrictions and send to any email address:
1. Request production access through AWS Console
2. Provide use case justification
3. Implement bounce/complaint handling
4. AWS typically approves within 24 hours

## Testing in Development

### Recommended Approach
1. Use verified email addresses for testing:
   - `chad.walters@campusiq.com`
   - `chad.walters@gmail.com`
   - Any `@campusiq.com` address (domain verified)

2. For new testers:
   - Verify their email first using the AWS CLI command above
   - Wait for them to click verification link
   - Then proceed with testing

### Checking Email Service Status
```bash
# Check if email service is healthy
just health dev | grep -i email

# Check backend health endpoint directly
curl -s https://backend.spacewalker.littleponies.com/health | jq '.checks.email'
```

## Common Issues

### "Email not sent" but UI shows success
- Check backend logs: `just logs backend dev | grep -i "email\|ses"`
- Look for "MessageRejected" errors
- Verify recipient email is in verified list

### Invitation created but no email received
- This is expected for unverified recipients
- Invitation exists in database and can be accessed via direct link
- Resend will fail until email is verified

## LocalStack Integration for Development

### LocalStack SES Configuration
For local development with LocalStack, the email service automatically detects LocalStack environment and uses:
- **Endpoint**: `/_aws/ses` (updated from deprecated `/_localstack/ses`)
- **Email verification**: Required via `verify_email_identity()` in test fixtures
- **Dual format parsing**: Supports both LocalStack and AWS SES response formats

### LocalStack API Changes
- ⚠️ **Deprecated**: `/_localstack/ses` endpoint (no longer supported)
- ✅ **Current**: `/_aws/ses` endpoint for LocalStack SES API
- All integration tests updated to use the new endpoint format

## Notes
- Sandbox mode indicated in health check: `"Email service operational (sandbox mode)"`
- Production environment may have full SES access (check before assuming)
- All environments use the same sender: `spacewalker@campusiq.com`
- LocalStack integration provides reliable email testing without external dependencies