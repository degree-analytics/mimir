# CloudFormation Circular Dependencies

## Problem Description
CloudFormation stacks become locked in circular dependencies where Stack A exports a value that Stack B imports, and Stack B exports a value that Stack A imports. This prevents either stack from being deleted or updated, forcing a complete infrastructure teardown.

## Symptoms
- Stack deletion fails with: "Cannot delete export as it is in use by another stack"
- Multiple stacks show "DELETE_FAILED" status with exports still in use
- Cannot update stacks due to import dependencies
- Forced to delete ALL stacks and start over

## Root Cause
In our case, the circular dependency web was:
1. **Mobile stack** needed DNS stack (imported API URL from DNS)
2. **DNS stack** needed Mobile and Backend stacks (created Route53 records pointing to their load balancers)
3. **Backend stack** might have also depended on DNS for its API configuration
4. None could be deleted without the others being deleted first - a complete deadlock

## Solution

### Breaking the Circular Dependency with Minimal Templates

1. **Create minimal "broken" templates** that remove all circular references:

   ```yaml
   # sam/dns/template-minimal.yaml - Strip out all service references
   Resources:
     HostedZone:
       Type: AWS::Route53::HostedZone
       Properties:
         Name: !Sub "${Environment}.${DomainName}"
   # Remove all Record resources that reference other stacks
   ```

   ```yaml
   # sam/ecs/mobile-minimal.yaml - Remove DNS imports
   Resources:
     MobileService:
       Type: AWS::ECS::Service
       Properties:
         # Remove any !ImportValue references to DNS
         # Use placeholder values instead
   ```

   ```yaml
   # sam/ecs/backend-minimal.yaml - Remove DNS imports
   Resources:
     BackendService:
       Type: AWS::ECS::Service
       Properties:
         # Remove any !ImportValue references to DNS
   ```

2. **Deploy the minimal templates** to break dependencies:
   ```bash
   # Deploy minimal versions to get stacks into deletable state
   aws cloudformation update-stack --stack-name dev-spacewalker-dns \
     --template-body file://sam/dns/template-minimal.yaml \
     --parameters ParameterKey=Environment,ParameterValue=dev

   aws cloudformation update-stack --stack-name dev-spacewalker-mobile \
     --template-body file://sam/ecs/mobile-minimal.yaml \
     --parameters ParameterKey=Environment,ParameterValue=dev

   aws cloudformation update-stack --stack-name dev-spacewalker-backend \
     --template-body file://sam/ecs/backend-minimal.yaml \
     --parameters ParameterKey=Environment,ParameterValue=dev
   ```

3. **Now stacks can be deleted** since circular imports are gone:
   ```bash
   just aws_delete_dns dev
   just aws_delete_mobile dev
   just aws_delete_backend dev
   # Continue with other stacks...
   ```

### If Already in DELETE_FAILED State

1. **Use retain-resources to skip problematic resources**:
   ```bash
   aws cloudformation delete-stack \
     --stack-name dev-spacewalker-database \
     --retain-resources DatabaseSecretUpdate
   ```

2. **Manually clean up retained resources**:
   ```bash
   # Find and delete secrets
   aws secretsmanager list-secrets --query "SecretList[?contains(Name, 'dev-spacewalker')]"
   aws secretsmanager delete-secret --secret-id AURORA/dev-spacewalker --force-delete-without-recovery
   ```

## Prevention

### Design Patterns to Avoid Circular Dependencies

1. **Move Route53 records to individual service stacks**:
   ```yaml
   # WRONG: DNS stack creates records for all services
   # sam/dns/template.yaml
   BackendRecord:
     Type: AWS::Route53::RecordSet
     Properties:
       AliasTarget:
         DNSName: !ImportValue dev-spacewalker-backend-dns  # Circular!

   # RIGHT: Each service creates its own DNS record
   # sam/ecs/backend.yaml
   BackendRecord:
     Type: AWS::Route53::RecordSet
     Properties:
       HostedZoneId: !ImportValue dev-spacewalker-hosted-zone-id
       Name: !Sub "api.${Environment}.${DomainName}"
       AliasTarget:
         DNSName: !GetAtt LoadBalancer.DNSName  # No import needed!
   ```

2. **Use Parameter Store for shared configuration**:
   ```yaml
   # DNS stack stores zone ID in Parameter Store
   HostedZoneParameter:
     Type: AWS::SSM::Parameter
     Properties:
       Name: /spacewalker/dev/hosted-zone-id
       Value: !Ref HostedZone

   # Services read from Parameter Store
   HostedZoneId: !Sub '{{resolve:ssm:/spacewalker/${Environment}/hosted-zone-id}}'
   ```

3. **Create a clear dependency hierarchy**:
   ```
   Foundation → ECR → Cluster → Database → DNS (zone only)
                                         ↓
   Backend/Admin/Mobile (create own DNS records)
   ```

4. **Document all exports and imports**:
   ```yaml
   # At top of each template, document:
   # EXPORTS:
   #   - dev-spacewalker-hosted-zone-id (DNS exports only zone)
   # IMPORTS:
   #   - dev-spacewalker-vpc-id (from Foundation)
   #   - dev-spacewalker-hosted-zone-id (from DNS)
   # CREATES OWN:
   #   - Route53 records for this service
   ```

### Emergency Cleanup Script
Save this for future circular dependency issues:
```bash
#!/bin/bash
# break-circular-deps.sh
ENV=$1

echo "Breaking circular dependencies for $ENV environment..."

# Create minimal templates
cat > sam/dns/template-minimal.yaml << EOF
AWSTemplateFormatVersion: '2010-09-09'
Parameters:
  Environment:
    Type: String
Resources:
  HostedZone:
    Type: AWS::Route53::HostedZone
    Properties:
      Name: !Sub "\${Environment}.example.com"
Outputs:
  HostedZoneId:
    Value: !Ref HostedZone
    Export:
      Name: !Sub '\${Environment}-spacewalker-hosted-zone-id'
EOF

# Create minimal service templates
for service in backend mobile admin; do
  cat > sam/ecs/${service}-minimal.yaml << EOF
AWSTemplateFormatVersion: '2010-09-09'
Parameters:
  Environment:
    Type: String
Resources:
  Service:
    Type: AWS::ECS::Service
    Properties:
      ServiceName: !Sub '\${Environment}-spacewalker-${service}'
      Cluster: !Sub '\${Environment}-spacewalker-cluster'
      DesiredCount: 0
EOF
done

# Deploy minimal templates
for stack in dns backend mobile admin; do
  echo "Deploying minimal $stack..."
  aws cloudformation update-stack \
    --stack-name $ENV-spacewalker-$stack \
    --template-body file://sam/${stack}/template-minimal.yaml \
    --parameters ParameterKey=Environment,ParameterValue=$ENV \
    --capabilities CAPABILITY_IAM || true
done

# Wait for updates
echo "Waiting for stacks to update..."
sleep 30

# Now delete in correct order
for stack in dns mobile admin backend database cluster ecr foundation; do
  echo "Deleting $stack..."
  just aws_delete_$stack $ENV || true
done

# Clean up minimal templates
rm -f sam/dns/template-minimal.yaml
rm -f sam/ecs/*-minimal.yaml
```

## The Permanent Fix

After breaking the circular dependencies and deleting all stacks, we implemented a permanent solution:

1. **DNS stack now only creates the hosted zone**:
   - Exports only `HostedZoneId`
   - No imports from other stacks
   - No Route53 records

2. **Each service stack creates its own DNS record**:
   - Backend creates `api.dev.example.com`
   - Admin creates `admin.dev.example.com`
   - Mobile creates `mobile.dev.example.com`
   - Each imports `HostedZoneId` from DNS stack
   - Each uses its own load balancer DNS name directly

This architecture ensures no circular dependencies can form between service stacks and DNS.

## Time Impact
Initial circular dependency resolution: 4-6 hours
With this guide: 15 minutes

## Related Issues
- [CloudFormation Deployment Gotchas](./cloudformation-deployment-gotchas.md) - Overall deployment issues
- [ECS Deployment Circuit Breaker](./ecs-deployment-circuit-breaker.md) - Service startup failures

## Keywords
CloudFormation, circular dependency, exports, imports, DELETE_FAILED, stack deletion, Route53, DNS
