# SSH Bastion Host Setup Gotchas

## Problem Description
Database health checks and connections fail due to SSH key mismatches, missing known_hosts entries, or incorrect bastion configuration. The system uses environment-specific SSH configurations that must be properly set up.

## Symptoms
- `just health dev` fails with "Permission denied (publickey)"
- SSH tunnel creation fails with host key verification errors
- Database connection times out despite bastion being accessible
- Error: "WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!"
- Script looks for `~/.ssh/known_hosts.dev` but file doesn't exist

## Root Cause
The database helper script (`scripts/database/db_helper.py`) uses environment-specific SSH configurations:
1. SSH key must match the key pair used when creating the bastion EC2 instance
2. Known hosts are stored in environment-specific files (`~/.ssh/known_hosts.dev`)
3. Bastion host key changes when instance is recreated
4. Local SSH key fingerprint doesn't match AWS key pair

## Solution

### Complete SSH Setup Process

1. **Verify current bastion IP**:
   ```bash
   just stack status dev | grep BastionHostPublicIP
   # Or directly:
   aws cloudformation describe-stacks --stack-name dev-spacewalker-foundation \
     --query "Stacks[0].Outputs[?OutputKey=='BastionHostPublicIP'].OutputValue" \
     --output text
   ```

2. **Create new SSH key pair** (if mismatch):
   ```bash
   # In AWS EC2 console:
   # 1. Go to EC2 → Key Pairs
   # 2. Create key pair named: dev-spacewalker-key
   # 3. Download the .pem file

   # Set up locally:
   mv ~/Downloads/dev-spacewalker-key.pem ~/.ssh/
   chmod 600 ~/.ssh/dev-spacewalker-key.pem
   ```

3. **Redeploy bastion with new key**:
   ```bash
   # Update foundation stack to use new key
   just aws_deploy_foundation dev
   ```

4. **Set up environment-specific known_hosts**:
   ```bash
   # First connection will prompt to accept host key
   ssh -i ~/.ssh/dev-spacewalker-key.pem ec2-user@<bastion-ip>

   # Copy to environment-specific file
   cp ~/.ssh/known_hosts ~/.ssh/known_hosts.dev

   # For other environments:
   cp ~/.ssh/known_hosts ~/.ssh/known_hosts.staging
   cp ~/.ssh/known_hosts ~/.ssh/known_hosts.prod
   ```

### Handling Host Key Changes

When bastion is recreated:
```bash
# Remove old host key
ssh-keygen -R <old-bastion-ip>

# Connect to new bastion
ssh -i ~/.ssh/dev-spacewalker-key.pem ec2-user@<new-bastion-ip>

# Update environment-specific known_hosts
grep <new-bastion-ip> ~/.ssh/known_hosts >> ~/.ssh/known_hosts.dev
```

### Debug SSH Issues

```bash
# Test SSH connectivity with verbose output
ssh -vvv -i ~/.ssh/dev-spacewalker-key.pem ec2-user@<bastion-ip>

# Check key fingerprint
ssh-keygen -lf ~/.ssh/dev-spacewalker-key.pem

# Verify key matches AWS
aws ec2 describe-key-pairs --key-names dev-spacewalker-key
```

## Prevention

1. **Document SSH key locations** in team wiki:
   ```
   Dev: ~/.ssh/dev-spacewalker-key.pem
   Staging: ~/.ssh/staging-spacewalker-key.pem
   Prod: ~/.ssh/prod-spacewalker-key.pem
   ```

2. **Backup SSH keys** to secure password manager

3. **Use consistent key naming** across environments

4. **Add setup script** for new developers:
   ```bash
   #!/bin/bash
   # setup-ssh.sh
   for env in dev staging prod; do
     if [ -f ~/.ssh/${env}-spacewalker-key.pem ]; then
       chmod 600 ~/.ssh/${env}-spacewalker-key.pem
       echo "✓ ${env} key configured"
     else
       echo "✗ Missing ${env} key - download from AWS console"
     fi
   done
   ```

5. **Test after bastion changes**:
   ```bash
   just health dev
   ```

## Time Impact
Initial debugging: 2-4 hours
With proper setup: 5 minutes

## Related Issues
- [Database Security Gotchas](./database-security-gotchas.md) - Overall database security
- [CloudFormation Deployment Gotchas](./cloudformation-deployment-gotchas.md) - Infrastructure deployment

## Keywords
SSH, bastion host, known_hosts, key pair, EC2, database tunnel, publickey authentication
