# localStorage Security: JSON Injection Prevention

## Purpose
Critical security patterns for safely handling localStorage data to prevent JSON injection attacks and prototype pollution vulnerabilities.

## When to Use This
- Working with localStorage persistence
- Implementing client-side data storage
- Handling user-controlled data in browsers
- Reviewing security vulnerabilities in frontend code

**Keywords:** localStorage, JSON injection, security, Zod validation, prototype pollution

---

## ⚠️ Critical Security Issue

**The Problem**: Direct `JSON.parse()` on localStorage data creates severe security vulnerabilities:

```typescript
// 🚨 DANGEROUS - Never do this
const data = JSON.parse(localStorage.getItem('userPreferences'));
```

**Attack Vector**: Malicious users can inject dangerous JSON that creates prototype pollution or executes unexpected code.

---

## 🔒 Secure Implementation Pattern

### Step 1: Schema Definition with Zod

```typescript
import { z } from 'zod';

// Define strict schema with bounded inputs
const SortColumnSchema = z.object({
  field: z.string().min(1).max(100), // Bounded field names
  direction: z.enum(['asc', 'desc']),
  type: z.enum(['string', 'number', 'date', 'boolean', 'status']),
}).strict(); // Reject any additional properties

const StoredSortingDataSchema = z.object({
  sortColumns: z.array(SortColumnSchema).max(10), // Limit array size
  timestamp: z.number().int().positive(),
  expiration: z.number().int().positive(),
}).strict(); // Critical: prevents prototype pollution
```

### Step 2: Safe Parsing with Validation

```typescript
export function loadSortingState(key: string): SortColumn[] {
  try {
    const stored = localStorage.getItem(key);
    if (!stored) {
      return [];
    }

    // ✅ SECURE: Validate before parsing
    const parsed = JSON.parse(stored);
    const validatedData = StoredSortingDataSchema.parse(parsed);

    // Check expiration
    if (Date.now() > validatedData.expiration) {
      localStorage.removeItem(key);
      return [];
    }

    return validatedData.sortColumns;
  } catch (error) {
    // ✅ SECURE: Clean up invalid data and log
    console.warn('Invalid sorting data found, cleaning up:', error);
    localStorage.removeItem(key);
    return [];
  }
}
```

### Step 3: Safe Storage with Validation

```typescript
export function saveSortingState(key: string, sortColumns: SortColumn[]): void {
  try {
    const data = {
      sortColumns,
      timestamp: Date.now(),
      expiration: Date.now() + (7 * 24 * 60 * 60 * 1000), // 7 days
    };

    // ✅ SECURE: Validate before storing
    const validatedData = StoredSortingDataSchema.parse(data);
    localStorage.setItem(key, JSON.stringify(validatedData));
  } catch (error) {
    console.error('Failed to save sorting state:', error);
    // Fail silently - don't break user experience
  }
}
```

---

## 🛡️ Security Best Practices

### 1. Always Use `.strict()` in Zod Schemas
```typescript
// ✅ SECURE: Prevents prototype pollution
const schema = z.object({
  field: z.string(),
  value: z.string(),
}).strict(); // Rejects __proto__, constructor, etc.

// 🚨 VULNERABLE: Allows arbitrary properties
const schema = z.object({
  field: z.string(),
  value: z.string(),
}); // Missing .strict()
```

### 2. Bound All String Inputs
```typescript
// ✅ SECURE: Bounded inputs prevent memory attacks
field: z.string().min(1).max(100),
sortColumns: z.array(SortColumnSchema).max(10),

// 🚨 VULNERABLE: Unbounded inputs
field: z.string(),
sortColumns: z.array(SortColumnSchema),
```

### 3. Use Enums for Known Values
```typescript
// ✅ SECURE: Only allow known directions
direction: z.enum(['asc', 'desc']),

// 🚨 VULNERABLE: Any string allowed
direction: z.string(),
```

### 4. Include Expiration and Cleanup
```typescript
// ✅ SECURE: Automatic cleanup of old data
const data = {
  payload: userData,
  expiration: Date.now() + EXPIRATION_TIME,
};

// Check expiration on load
if (Date.now() > validatedData.expiration) {
  localStorage.removeItem(key);
  return defaultValue;
}
```

---

## 🧪 Security Testing Patterns

### Test 1: JSON Injection Prevention
```typescript
describe('localStorage Security', () => {
  it('should reject malicious JSON injection', () => {
    // Attempt prototype pollution
    const maliciousData = JSON.stringify({
      sortColumns: [],
      timestamp: Date.now(),
      expiration: Date.now() + 1000,
      __proto__: { isAdmin: true },
    });
    
    localStorage.setItem('test-key', maliciousData);
    
    // Should reject and clean up
    const result = loadSortingState('test-key');
    expect(result).toEqual([]);
    expect(localStorage.getItem('test-key')).toBeNull();
  });
});
```

### Test 2: Boundary Validation
```typescript
it('should reject oversized inputs', () => {
  const oversizedData = {
    sortColumns: new Array(20).fill({ // Exceeds max of 10
      field: 'a'.repeat(200), // Exceeds max of 100
      direction: 'asc',
      type: 'string',
    }),
    timestamp: Date.now(),
    expiration: Date.now() + 1000,
  };
  
  expect(() => {
    saveSortingState('test-key', oversizedData.sortColumns);
  }).not.toThrow(); // Should fail silently
  
  expect(localStorage.getItem('test-key')).toBeNull();
});
```

---

## 🚨 Common Attack Vectors

### 1. Prototype Pollution
```javascript
// Malicious payload that modifies Object.prototype
{
  "sortColumns": [],
  "__proto__": {
    "isAdmin": true,
    "polluted": "value"
  }
}
```

### 2. Constructor Manipulation
```javascript
// Attempts to modify constructor
{
  "sortColumns": [],
  "constructor": {
    "prototype": {
      "isAdmin": true
    }
  }
}
```

### 3. Memory Exhaustion
```javascript
// Extremely large payloads to crash browser
{
  "sortColumns": [/* thousands of entries */],
  "field": "a".repeat(1000000)
}
```

---

## 🔍 Security Review Checklist

When reviewing localStorage usage:

- [ ] **Zod validation**: All localStorage reads use schema validation
- [ ] **Strict schemas**: All schemas use `.strict()` to prevent pollution
- [ ] **Bounded inputs**: String lengths and array sizes are limited
- [ ] **Enum validation**: Known values use enums, not free-form strings
- [ ] **Expiration handling**: Old data is automatically cleaned up
- [ ] **Error handling**: Invalid data is logged and cleaned up
- [ ] **Silent failures**: Validation failures don't break user experience
- [ ] **Security tests**: Tests verify injection prevention

---

## 📚 Real-World Example

See our implementation in `apps/admin/src/utils/sortingPersistence.ts` for a complete, production-ready example of secure localStorage handling with:

- Comprehensive Zod schema validation
- Automatic expiration and cleanup
- Prototype pollution prevention
- Memory exhaustion protection
- Graceful error handling

---

## 🔗 References

- [Zod Documentation](https://zod.dev/) - Schema validation library
- [OWASP JSON Injection](https://owasp.org/www-community/vulnerabilities/JSON_Injection) - Security vulnerability details
- [Prototype Pollution](https://blog.p6.is/AST-Injection/) - Attack vector explanation
- [localStorage Security](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API#security) - MDN security considerations

---

**Last Updated:** 2025-07-02  
**Status:** Current  
**Priority:** Critical Security Issue