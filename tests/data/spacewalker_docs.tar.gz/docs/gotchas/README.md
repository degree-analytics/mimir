# Common Gotchas and Issues

## Purpose
Collection of known issues, problems, and solutions discovered during Spacewalker development. Each gotcha documents a specific problem with symptoms, root cause, solution, and prevention tips.

## When to Use This
- Debugging mysterious issues and unexpected behavior
- Understanding common pitfalls and how to avoid them
- Finding solutions to recurring problems
- Learning from documented troubleshooting experiences
- Keywords: gotchas, issues, problems, solutions, troubleshooting, debugging

**Version:** 2.0 (New documentation structure)
**Date:** 2025-07-03
**Status:** Current - Growing Collection

---

## 🚨 High-Impact Issues

### Deployment and Infrastructure
- **[CloudFormation Circular Dependencies](./cloudformation-circular-dependencies.md)** - Critical: Breaking circular imports (6 hours lost)
- **[CloudFormation Deployment Gotchas](./cloudformation-deployment-gotchas.md)** - Critical: Stack dependencies and drift (24 hours lost)
- **[ECS Deployment Circuit Breaker](./ecs-deployment-circuit-breaker.md)** - Service startup dependency failures

### API and Backend Issues
- **[API Trailing Slashes](./api-trailing-slashes.md)** - Critical authentication failure (12 hours lost)
- **[Variable Name Mismatches](./variable-name-mismatches.md)** - Environment variable inconsistencies (12 hours lost)

### Mobile Development Issues
- **[EAS Build Archive Optimization](./eas-build-archive-optimization.md)** - Critical: 3.2GB archive size solution (24 hours lost)
- **[Mobile Hermes Compatibility](./mobile-hermes-compatibility.md)** - React Native Hermes engine crashes
- **[React 19 Testing Compatibility](./mobile-react19-testing.md)** - Testing framework compatibility issues

---

## 📱 Mobile App Gotchas

### React Native Issues
- **[EAS Build Archive Optimization](./eas-build-archive-optimization.md)** - Monorepo archive size exceeding 2GB limit
- **[Mobile Hermes Compatibility](./mobile-hermes-compatibility.md)** - Engine crashes and version conflicts
- **[React 19 Testing Compatibility](./mobile-react19-testing.md)** - Jest testing framework issues

### Development Environment
- **[Safari Browser Issues](./safari-browser-issues.md)** - Safari-specific rendering and compatibility problems
- Additional mobile development issues will be documented as discovered

---

## 🔧 Backend API Gotchas

### Authentication and API
- **[API Trailing Slashes](./api-trailing-slashes.md)** - FastAPI redirect auth header dropping
- **[Variable Name Mismatches](./variable-name-mismatches.md)** - Environment variable naming inconsistencies

### Database and Infrastructure
- **[Database Security Gotchas](./database-security-gotchas.md)** - SSH security, credential management, and database access security
- **[BACnet Timeout Debugging](./bacnet-timeout-debugging.md)** - Protocol-specific debugging for building automation systems
- Additional backend infrastructure issues will be documented as discovered

---

## 🌐 Admin Dashboard Gotchas

### React and Next.js
- **[Table Filter Dependencies](./table-filter-dependencies.md)** - Common filter dependency anti-patterns and solutions
- **[localStorage Security](./localstorage-security.md)** - JSON injection prevention and secure localStorage patterns
- Additional React and Next.js issues will be documented as discovered

### Build and Deployment
- **[Playwright Testing Gotchas](./playwright-testing-gotchas.md)** - Playwright timing issues, selector strategies, and test reliability patterns
- Additional build and deployment issues will be documented as discovered

---

## ⚙️ Development Environment Gotchas

### Configuration Issues
- **[Variable Name Mismatches](./variable-name-mismatches.md)** - Environment variable naming inconsistencies (cross-reference)
- Additional configuration issues will be documented as discovered

### Tooling Problems
- Additional tooling issues will be documented as discovered

---

## 🚀 Deployment and Infrastructure Gotchas

### AWS and Infrastructure
- **[CloudFormation Circular Dependencies](./cloudformation-circular-dependencies.md)** - Breaking circular import/export chains
- **[CloudFormation Deployment Gotchas](./cloudformation-deployment-gotchas.md)** - Critical: Stack drift, deployment order (24 hours lost)
- **[ECS Deployment Circuit Breaker](./ecs-deployment-circuit-breaker.md)** - Service startup failures and dependency issues
- **[SSH Bastion Setup](./ssh-bastion-setup.md)** - SSH key configuration and environment-specific setup
- **[AWS Security Practices](./aws-security-practices.md)** - Security configuration pitfalls and best practices
- **[Database Security Gotchas](./database-security-gotchas.md)** - SSH security, credential management, and database access security (cross-reference)
- Additional AWS and infrastructure issues will be documented as discovered

### CI/CD Pipeline
- **[CI/CD Deployment Fixes](./ci-cd-deployment-fixes.md)** - CloudWatch IAM permissions, deployment debugging, Docker tags

---

## 💡 How to Use This Collection

### For Developers
1. **Before debugging:** Check relevant category for similar issues
2. **When stuck:** Search for symptoms or error messages
3. **After solving:** Document new gotchas following the template below

### For New Team Members
1. **Start here:** Review high-impact issues first
2. **By role:** Focus on gotchas relevant to your development area
3. **Preventive:** Use prevention tips to avoid common problems

---

## 📝 Contributing New Gotchas

### Gotcha Template
When documenting a new issue, create a new file following this structure:

```markdown
# [Issue Title]

## Problem Description
Clear description of what goes wrong and when it occurs.

## Symptoms
- Observable symptoms and error messages
- What the user experiences
- How to identify this specific issue

## Root Cause
Technical explanation of why this happens:
- Underlying technical reason
- System behavior that causes the problem
- Configuration or code patterns involved

## Solution
Step-by-step solution:
1. Specific actions to take
2. Commands to run
3. Code changes to make
4. Configuration updates needed

## Prevention
How to avoid this issue in the future:
- Best practices to follow
- Code patterns to use/avoid
- Configuration standards
- Validation steps

## Time Impact
How much time this issue cost to resolve (helps prioritize documentation)

## Related Issues
- Links to related gotchas or documentation
- Cross-references to similar problems

## Keywords
Tags for searchability: relevant technology, error types, components affected
```

### File Naming Convention
- Use kebab-case: `api-trailing-slashes.md`
- Be descriptive: `mobile-hermes-compatibility.md`
- Include component: `backend-database-connection.md`

---

## Related Documentation

- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Systematic problem resolution workflows
- **[Testing Guide](../workflows/testing-guide.md)** - Testing-related issue resolution
- **[Deployment Guide](../workflows/deployment-guide.md)** - Infrastructure and deployment troubleshooting
- **[Environment Setup](../setup/environment-setup.md)** - Configuration and environment issues

---

**Status**: ✅ Active collection - Add new gotchas as they're discovered and resolved.
**Last Updated**: 2025-07-03
