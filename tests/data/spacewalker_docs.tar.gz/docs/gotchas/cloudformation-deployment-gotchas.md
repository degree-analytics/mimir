# CloudFormation Deployment Gotchas

## Problem Description
Full CloudFormation stack deployments can fail due to circular dependencies, missing resources, stack drift, and missing secrets. These issues can cascade through the deployment process causing hours of troubleshooting.

## Symptoms
- ECS deployment circuit breaker triggers repeatedly
- Stack creation fails with "Export not found" errors
- Services fail to start with "ResourceInitializationError"
- Database health checks fail with SSH connection errors
- Stack deletion gets stuck in DELETE_IN_PROGRESS state
- Services report missing secrets or environment variables

## Root Cause
Multiple interconnected issues:
1. **Circular Dependencies**: Stacks export values that other stacks depend on, creating deletion/update deadlocks
2. **Stack Drift**: Resources manually deleted outside CloudFormation cause deployment failures
3. **Missing Secrets**: Services require specific AWS Secrets Manager entries that must exist before deployment
4. **SSH Key Mismatches**: Bastion host expects specific SSH keys that must match local configuration
5. **Resource Creation Order**: Some resources must exist before others can reference them

## Solution

### Complete Stack Reset Procedure
When encountering insurmountable issues, follow this order:

1. **Delete all stacks** (handle circular dependencies):
   ```bash
   # First update any stack with circular dependencies to remove imports
   just aws_deploy_foundation dev  # After removing problematic imports

   # Then delete in reverse dependency order
   just aws_delete_dns dev
   just aws_delete_mobile dev
   just aws_delete_admin dev
   just aws_delete_backend dev
   just aws_delete_database dev
   just aws_delete_cluster dev
   just aws_delete_ecr dev
   just aws_delete_foundation dev

   # If stuck in DELETE_IN_PROGRESS, use retain-resources
   aws cloudformation delete-stack --stack-name dev-spacewalker-database --retain-resources DatabaseSecretUpdate
   ```

2. **Clean up orphaned resources**:
   ```bash
   # Delete S3 buckets if they exist
   aws s3 rb s3://dev-spacewalker-mobile-builds --force
   aws s3 rb s3://dev-spacewalker-admin-builds --force
   ```

3. **Deploy in correct order**:
   ```bash
   just aws_deploy_foundation dev
   just aws_deploy_ecr dev
   just aws_deploy_cluster dev
   just aws_deploy_database dev
   just aws_deploy_backend dev
   just aws_deploy_admin dev
   just aws_deploy_mobile dev
   just aws_deploy_dns dev
   ```

### Required Secrets Configuration
Before deploying services, create these secrets:

```bash
# API Keys secret (required by backend)
just secrets create dev --secret-name api-keys --secret-value '{
  "GEMINI_API_KEY": "your-gemini-api-key",
  "JWT_SECRET": "your-jwt-secret"
}'

# Storage secret (required by mobile)
just secrets update dev --secret-name storage --secret-value '{
  "EXPO_TOKEN": "your-expo-token"
}'
```

### SSH Key Setup for Bastion
The database helper expects environment-specific SSH keys and known_hosts:

1. **Create new SSH key pair**:
   ```bash
   # In AWS EC2 console, create key pair named: dev-spacewalker-key
   # Download and save to: ~/.ssh/dev-spacewalker-key.pem
   chmod 600 ~/.ssh/dev-spacewalker-key.pem
   ```

2. **Handle known_hosts**:
   ```bash
   # The db_helper.py script uses environment-specific known_hosts
   # After first connection, copy the host key:
   cp ~/.ssh/known_hosts ~/.ssh/known_hosts.dev
   ```

## Prevention

1. **Always check stack status before deployment**:
   ```bash
   just stack status dev
   ```

2. **Verify required secrets exist**:
   ```bash
   just secrets list dev
   just secrets show dev --secret-name api-keys
   just secrets show dev --secret-name storage
   ```

3. **Use CloudFormation for all infrastructure changes** - avoid manual AWS console modifications

4. **Document all required secrets** in your deployment guide with exact key names

5. **Test SSH connectivity** before database operations:
   ```bash
   just health dev
   ```

6. **Monitor for stack drift**:
   ```bash
   aws cloudformation detect-stack-drift --stack-name dev-spacewalker-foundation
   ```

## Time Impact
Initial deployment issues: 24+ hours
With proper procedure: 30 minutes

## Related Issues
- [CloudFormation Circular Dependencies](./cloudformation-circular-dependencies.md) - Detailed circular dependency resolution
- [ECS Deployment Circuit Breaker](./ecs-deployment-circuit-breaker.md) - Service startup failures
- [SSH Bastion Setup](./ssh-bastion-setup.md) - SSH key configuration
- [Variable Name Mismatches](./variable-name-mismatches.md) - Environment variable inconsistencies
- [Database Security Gotchas](./database-security-gotchas.md) - SSH security and credential management

## Keywords
CloudFormation, deployment, circular dependencies, stack drift, ECS, secrets manager, SSH, bastion host, infrastructure
