# Playwright Testing Gotchas

## Purpose
Critical issues, timing problems, and anti-patterns when implementing tests with Playwright. Essential knowledge for preventing flaky tests and building robust test automation.

## When to Use This
- Tests are failing intermittently (flaky tests)
- Playwright selectors are breaking after UI changes
- Tests work locally but fail in CI/CD
- Performance issues or timeouts in tests
- Implementing new test patterns

**Keywords:** playwright, testing, flaky tests, selectors, timeouts, ci/cd

**Version:** 1.0
**Date:** 2025-07-02
**Status:** Current

---

## 🎭 Playwright-Specific Issues

### 1. Selector Brittleness - The #1 Test Killer

**Problem:** Single selector strategies break when UI changes
```typescript
// ❌ FRAGILE - Will break with UI changes
await page.click('.submit-button');
await page.click('button'); // Too generic
await page.click('text="Submit"'); // Text changes
```

**Solution:** Multi-selector strategy with graceful fallbacks
```typescript
// ✅ ROBUST - Multiple fallback strategies
await page.click([
  '[data-testid="submit-button"]',    // Preferred: data attributes
  'button[type="submit"]',            // Semantic: form semantics
  '.submit-button',                   // Fallback: CSS classes
  'button:has-text("Submit")',        // Alternative: text content
  'button:has-text("Save")'           // Alternative: synonym text
].join(', '));

// ✅ EVEN BETTER - Extract to helper function
async function clickSubmitButton(page: Page) {
  const submitSelectors = [
    '[data-testid="submit-button"]',
    'button[type="submit"]:visible',
    '.btn-primary:has-text("Submit")',
    'button:has-text("Submit")',
    'button:has-text("Save")'
  ];

  for (const selector of submitSelectors) {
    try {
      await page.click(selector, { timeout: 5000 });
      return; // Success
    } catch (error) {
      console.log(`Selector failed: ${selector}`);
    }
  }
  throw new Error('Could not find submit button with any known selector');
}
```

**Real-world example from admin dashboard:**
```typescript
// Robust survey approval pattern
const approveButton = page.locator([
  '[data-testid="approve-survey"]',
  '.approve-button',
  'button:has-text("Approve")',
  '.btn-success',
  'button[title*="approve" i]'
].join(', '));
```

### 2. Timing and Race Conditions

**Problem:** Tests fail because they run faster than the application
```typescript
// ❌ WRONG - Arbitrary waits are unreliable
await page.click('button');
await page.waitForTimeout(2000); // Could be too short or too long
```

**Solution:** Wait for actual conditions
```typescript
// ✅ CORRECT - Wait for actual state changes
await page.click('button');
await page.waitForLoadState('networkidle');
await expect(page.locator('.success-message')).toBeVisible();

// ✅ BETTER - Wait for specific data conditions
await page.click('.load-surveys-button');
await expect(page.locator('.survey-item')).toHaveCount(100, { timeout: 30000 });

// ✅ BEST - Wait for application state
await page.waitForFunction(() => {
  return window.surveysLoaded && window.surveysCount === 100;
});
```

**Demo data loading pattern:**
```typescript
// Wait for demo data to fully load
test.beforeEach(async ({ page }) => {
  await page.goto('/surveys');

  // Wait for multiple indicators that data is ready
  await Promise.all([
    page.waitForLoadState('networkidle'),
    expect(page.locator('.survey-item')).toHaveCount(100),
    expect(page.locator('.loading-indicator')).not.toBeVisible(),
    page.waitForFunction(() => document.querySelectorAll('.survey-item').length >= 100)
  ]);
});
```

### 3. Authentication and Session Management

**Problem:** Authentication flakiness breaks entire test suites
```typescript
// ❌ FRAGILE - No verification of login success
await page.fill('input[name="email"]', 'admin@demo.university.edu');
await page.fill('input[name="password"]', 'demo123');
await page.click('button[type="submit"]');
// Assumes login worked
```

**Solution:** Robust authentication with verification
```typescript
// ✅ ROBUST - Verify authentication success
async function authenticateAsAdmin(page: Page) {
  await page.goto('/login');

  // Handle potential redirects for already-logged-in users
  if (page.url().includes('/dashboard') || page.url().includes('/surveys')) {
    return; // Already authenticated
  }

  // Fill login form with multiple selector strategies
  await page.fill('input[name="email"], input[type="email"], #email', 'admin@demo.university.edu');
  await page.fill('input[name="password"], input[type="password"], #password', 'demo123');

  // Click login and wait for navigation
  await page.click('button[type="submit"], button:has-text("Login"), .login-button');

  // Wait for successful login with multiple indicators
  await Promise.race([
    page.waitForURL('**/dashboard'),
    page.waitForURL('**/surveys'),
    page.waitForSelector('[data-testid="user-menu"]'),
    page.waitForSelector('.admin-header')
  ]);

  // Verify authentication state
  await expect(page.locator('[data-testid="user-menu"], .user-menu, .admin-header')).toBeVisible();
}
```

## 🌐 Environment-Specific Issues

### 4. Local vs CI/CD Environment Differences

**Problem:** Tests pass locally but fail in CI/CD
```typescript
// ❌ PROBLEM - Hardcoded local URLs
await page.goto('http://localhost:3001/surveys');
```

**Solution:** Environment-aware configuration
```typescript
// ✅ SOLUTION - Environment detection
// tests/utils/environment-config.ts
export function getEnvironmentConfig() {
  const env = process.env.TEST_ENVIRONMENT || 'local';

  const configs = {
    local: {
      adminUrl: 'http://localhost:3001',
      backendUrl: 'http://localhost:8000',
      timeout: 30000
    },
    dev: {
      adminUrl: 'https://admin.spacewalker.littleponies.com',
      backendUrl: 'https://backend.spacewalker.littleponies.com',
      timeout: 60000 // Longer timeouts for remote
    },
    staging: {
      adminUrl: 'https://admin.spacewalker.staging.com',
      backendUrl: 'https://backend.spacewalker.staging.com',
      timeout: 45000
    }
  };

  return { environment: env, ...configs[env] };
}

// Usage in tests
const config = getEnvironmentConfig();
await page.goto(`${config.adminUrl}/surveys`);
```

**CI-specific adaptations:**
```typescript
// Handle CI-specific timing issues
const isCI = process.env.CI === 'true';
const baseTimeout = isCI ? 60000 : 30000;

test.setTimeout(baseTimeout * 2); // Longer timeouts in CI

if (isCI) {
  // CI-specific setup
  await page.waitForLoadState('domcontentloaded'); // Don't wait for networkidle in CI
} else {
  // Local development setup
  await page.waitForLoadState('networkidle');
}
```

## 📊 Data-Related Gotchas

### 5. Demo Data Assumptions

**Problem:** Tests assume specific demo data that may not exist
```typescript
// ❌ DANGEROUS - Assumes specific survey exists
await page.click('.survey-item:first-child .approve-button');
```

**Solution:** Validate data before interaction
```typescript
// ✅ SAFE - Verify data exists before acting
test('should approve pending survey', async ({ page }) => {
  await page.goto('/surveys');

  // Wait for surveys to load
  await expect(page.locator('.survey-item')).toHaveCount(100);

  // Find a pending survey specifically
  const pendingSurvey = page.locator('.survey-item:has(.status-pending)').first();
  await expect(pendingSurvey).toBeVisible();

  // Verify it has an approve button before clicking
  const approveButton = pendingSurvey.locator('.approve-button, button:has-text("Approve")');
  await expect(approveButton).toBeVisible();

  await approveButton.click();

  // Verify the action succeeded
  await expect(pendingSurvey.locator('.status-approved')).toBeVisible();
});
```

**Demo data validation helper:**
```typescript
// Comprehensive demo data validation
export async function validateDemoData(page: Page) {
  const checks = [
    { name: 'surveys', selector: '.survey-item', expectedCount: 100 },
    { name: 'buildings', selector: '.building-item', expectedCount: 5 },
    { name: 'rooms', selector: '.room-item', expectedCount: 50 }
  ];

  for (const check of checks) {
    await page.goto(`/${check.name}`);
    await expect(page.locator(check.selector)).toHaveCount(check.expectedCount, {
      timeout: 30000
    });
    console.log(`✅ ${check.name}: ${check.expectedCount} items found`);
  }
}
```

## 🎯 Performance and Resource Issues

### 6. Memory Leaks and Resource Cleanup

**Problem:** Tests consume excessive memory or leave resources hanging
```typescript
// ❌ PROBLEM - No cleanup
test('memory hungry test', async ({ page }) => {
  // Creates many resources without cleanup
  for (let i = 0; i < 100; i++) {
    await page.evaluate(() => window.createLargeObject());
  }
});
```

**Solution:** Proper resource management
```typescript
// ✅ SOLUTION - Explicit cleanup
test('resource-aware test', async ({ page }) => {
  // Track resources for cleanup
  const resources = [];

  try {
    for (let i = 0; i < 100; i++) {
      const resource = await page.evaluate(() => window.createLargeObject());
      resources.push(resource);
    }

    // Test logic here

  } finally {
    // Always clean up
    await page.evaluate((resourceIds) => {
      resourceIds.forEach(id => window.cleanupResource(id));
    }, resources);
  }
});

// ✅ BETTER - Use test hooks for cleanup
test.afterEach(async ({ page }) => {
  // Clean up any test artifacts
  await page.evaluate(() => {
    window.testCleanup && window.testCleanup();
  });
});
```

### 7. Slow Test Performance

**Problem:** Tests take too long and timeout
```typescript
// ❌ SLOW - Loading full dataset every test
test.beforeEach(async ({ page }) => {
  await page.goto('/surveys');
  await page.waitForLoadState('networkidle'); // Waits for everything
});
```

**Solution:** Optimized loading strategies
```typescript
// ✅ FAST - Minimal loading with strategic waits
test.beforeEach(async ({ page }) => {
  await page.goto('/surveys');

  // Wait only for essential content
  await page.waitForLoadState('domcontentloaded');

  // Wait specifically for test requirements
  const testNeedsFullData = expect.getState().currentTestName?.includes('full dataset');
  if (testNeedsFullData) {
    await expect(page.locator('.survey-item')).toHaveCount(100);
  } else {
    // Most tests only need some data to be visible
    await expect(page.locator('.survey-item')).toHaveCountGreaterThan(0);
  }
});
```

## 🔧 Test Organization and Maintenance

### 8. Test Interdependencies

**Problem:** Tests depend on execution order or shared state
```typescript
// ❌ FRAGILE - Tests depend on each other
test('create survey', async ({ page }) => {
  // Creates survey with ID 'test-survey-123'
});

test('approve survey', async ({ page }) => {
  // Assumes survey from previous test exists
  await page.click('[data-survey-id="test-survey-123"] .approve-button');
});
```

**Solution:** Independent, isolated tests
```typescript
// ✅ ROBUST - Each test sets up its own data
test.describe('Survey Management', () => {
  test.beforeEach(async ({ page }) => {
    // Ensure clean state for each test
    await resetToKnownState(page);
  });

  test('should approve survey', async ({ page }) => {
    // Create the specific data this test needs
    const surveyId = await createTestSurvey(page, { status: 'pending' });

    // Test the approval workflow
    await page.click(`[data-survey-id="${surveyId}"] .approve-button`);

    // Verify result
    await expect(page.locator(`[data-survey-id="${surveyId}"] .status-approved`)).toBeVisible();

    // Optional: Clean up test data
    await deleteTestSurvey(page, surveyId);
  });
});
```

## 🚨 Critical Anti-Patterns to Avoid

### 9. Hard-coded Waits and Sleeps

```typescript
// ❌ NEVER DO THIS
await page.waitForTimeout(5000); // Arbitrary wait
await new Promise(resolve => setTimeout(resolve, 3000)); // Manual sleep
```

### 10. Overly Specific Selectors

```typescript
// ❌ TOO BRITTLE
await page.click('body > div.app > div.main > div.content > div.surveys > div:nth-child(3) > button');

// ✅ BETTER
await page.click('[data-testid="survey-approve-button"]');
```

### 11. Testing Implementation Details

```typescript
// ❌ WRONG - Testing internal state
await expect(page.locator('.component-state-loading')).toBeVisible();

// ✅ RIGHT - Testing user-visible behavior
await expect(page.locator('.survey-item')).toBeVisible();
```

---

## 🛠️ Best Practices Summary

### Essential E2E Testing Patterns
1. **Multi-selector strategies** for resilient element selection
2. **Condition-based waits** instead of arbitrary timeouts
3. **Environment-aware configuration** for local/CI consistency
4. **Data validation** before assumptions
5. **Resource cleanup** to prevent memory leaks
6. **Test isolation** to prevent interdependencies

### Performance Optimization
- Use `domcontentloaded` instead of `networkidle` when possible
- Implement progressive loading validation
- Cache authentication state between tests
- Parallelize independent test execution

### Debugging Strategies
```bash
# Debug failing tests
just test e2e admin --debug "survey approval"

# Run with detailed logging
DEBUG=pw:api just test e2e admin --ui

# Generate reports for analysis
just test e2e admin --report
```

---

## Related Documentation

- **[E2E Testing Framework](../../tests/docs/README.md)** - Complete testing documentation
- **[Debugging Guide](../../tests/docs/debugging-guide.md)** - Systematic debugging procedures
- **[Testing Guide](../workflows/testing-guide.md)** - Comprehensive testing strategies
- **[Demo Data Management](../workflows/demo-data-management.md)** - Data setup and validation

---

**Remember:** E2E tests should test user workflows, not implementation details. When tests are flaky, the problem is usually timing, selectors, or environment differences - not the application logic itself.

---
**Status:** ✅ Current as of 2025-07-02
