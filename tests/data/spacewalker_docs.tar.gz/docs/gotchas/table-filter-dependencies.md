# Table Filter Dependencies: Common UI Logic Anti-Patterns

## Purpose
Document common filter dependency bugs where UI restrictions artificially prevent independent filter usage that the backend API actually supports.

## When to Use This
- Implementing table filters and search functionality
- Debugging filter behavior inconsistencies
- Reviewing UI logic for artificial constraints
- Designing filter user experiences

**Keywords:** filter dependencies, UI constraints, backend API, independent filtering, artificial restrictions

---

## 🐛 The Problem: Artificial UI Constraints

**Symptom**: Users cannot use individual filters independently (e.g., floor filter only works when building is selected), despite the backend API supporting independent filtering.

**Root Cause**: UI logic incorrectly enforces dependencies that don't exist in the backend data model.

---

## 📝 Real-World Case Study

### The Bug We Fixed

**Location**: `apps/admin/src/components/rooms/RoomsFilter.tsx` (and related components)

**Original Problem Code**:
```tsx
// 🚨 PROBLEMATIC: Artificial UI constraint
<TextField
  select
  fullWidth
  label="Floor"
  value={floorFilter}
  onChange={(e) => onFloorChange(e.target.value)}
  size="small"
  disabled={buildingFilter === 'all'} // ❌ Artificial constraint
>
```

**Backend Reality**: The API endpoint `/api/rooms` accepts:
```typescript
// Backend supports ALL combinations:
{
  building_id?: number,  // Optional
  floor_id?: number,     // Optional - works independently
  room_type?: string,    // Optional
  // Any combination of filters works
}
```

**The Fix**:
```tsx
// ✅ CORRECT: No artificial constraints
<TextField
  select
  fullWidth
  label="Floor"
  value={floorFilter}
  onChange={(e) => onFloorChange(e.target.value)}
  size="small"
  // disabled prop removed - user can filter by floor alone
>
```

---

## 🔍 How to Identify This Pattern

### 1. Check for Artificial `disabled` Props
```tsx
// 🚨 RED FLAGS: Look for these patterns
disabled={otherFilter === 'all'}
disabled={!someOtherValue}
disabled={dependencies.length === 0}
```

### 2. Verify Against Backend API
```typescript
// Check if backend endpoint documentation shows:
// ✅ All parameters are optional
// ✅ Filters work independently
// ✅ No enforced relationships between filters

// Example of backend flexibility:
app.get('/api/rooms', (req, res) => {
  const { building_id, floor_id, room_type } = req.query;
  
  let query = 'SELECT * FROM rooms WHERE 1=1';
  const params = [];
  
  // Each filter is truly optional and independent
  if (building_id && building_id !== 'all') {
    query += ' AND building_id = ?';
    params.push(building_id);
  }
  
  if (floor_id && floor_id !== 'all') {
    query += ' AND floor_id = ?';
    params.push(floor_id);
  }
  
  // No artificial dependencies between filters
});
```

### 3. Test User Scenarios
```typescript
describe('Filter Independence', () => {
  it('should allow floor filtering without building selection', () => {
    // User should be able to:
    // 1. Leave building as "All Buildings" 
    // 2. Select specific floor
    // 3. See all rooms on that floor across all buildings
  });
  
  it('should allow room type filtering independently', () => {
    // User should be able to filter by room type alone
  });
});
```

---

## 🛡️ Prevention Strategies

### 1. API-First Design
**Always design UI filters to match backend capabilities**:

```typescript
// ✅ GOOD: UI mirrors backend flexibility
interface FilterState {
  building?: string;
  floor?: string;
  roomType?: string;
  // No enforced relationships
}

// Backend endpoint design:
// GET /api/rooms?building_id=123&floor_id=456  ✅ Both filters
// GET /api/rooms?floor_id=456                  ✅ Floor only
// GET /api/rooms?building_id=123              ✅ Building only
// GET /api/rooms                              ✅ No filters
```

### 2. Remove UI Logic Dependencies
```tsx
// ❌ AVOID: Artificial UI constraints
const isFloorDisabled = buildingFilter === 'all';
const isRoomTypeDisabled = !floorFilter;

// ✅ PREFER: Let users choose any combination
const FloorFilter = () => (
  <TextField
    select
    label="Floor"
    value={floorFilter}
    onChange={onFloorChange}
    // No disabled prop - always available
  >
    <MenuItem value="all">All Floors</MenuItem>
    {floors.map(floor => (
      <MenuItem key={floor.id} value={floor.id}>
        {floor.name}
      </MenuItem>
    ))}
  </TextField>
);
```

### 3. Document Expected Behavior
```tsx
/**
 * Room Filters Component
 * 
 * DESIGN PRINCIPLE: All filters work independently
 * - Users can filter by building alone
 * - Users can filter by floor alone (shows rooms across all buildings)
 * - Users can filter by room type alone
 * - Any combination of filters is valid
 * 
 * This matches the backend API design where all parameters are optional.
 */
```

---

## 🧪 Testing Independent Filters

### Test Suite Example
```typescript
describe('Room Filters Independence', () => {
  beforeEach(() => {
    render(<RoomsPage />);
  });

  it('should allow independent building filtering', async () => {
    // Select building without floor
    fireEvent.change(screen.getByLabelText('Building'), {
      target: { value: 'building-1' }
    });
    
    // Should show all rooms in that building
    await waitFor(() => {
      expect(screen.getByText('Building 1 Room A')).toBeInTheDocument();
      expect(screen.getByText('Building 1 Room B')).toBeInTheDocument();
    });
  });

  it('should allow independent floor filtering', async () => {
    // Select floor without building (building = "all")
    fireEvent.change(screen.getByLabelText('Floor'), {
      target: { value: 'floor-2' }
    });
    
    // Should show all Floor 2 rooms across all buildings
    await waitFor(() => {
      expect(screen.getByText('Building A Floor 2 Room')).toBeInTheDocument();
      expect(screen.getByText('Building B Floor 2 Room')).toBeInTheDocument();
    });
  });

  it('should combine filters when both selected', async () => {
    // Select both building and floor
    fireEvent.change(screen.getByLabelText('Building'), {
      target: { value: 'building-1' }
    });
    fireEvent.change(screen.getByLabelText('Floor'), {
      target: { value: 'floor-2' }
    });
    
    // Should show only Building 1, Floor 2 rooms
    await waitFor(() => {
      expect(screen.getByText('Building 1 Floor 2 Room')).toBeInTheDocument();
      expect(screen.queryByText('Building 2 Floor 2 Room')).not.toBeInTheDocument();
    });
  });
});
```

---

## 🔧 Common Locations to Check

### 1. Filter Components
```bash
# Search for artificial disabled conditions
grep -r "disabled.*=.*" apps/admin/src/components/
grep -r "disabled={" apps/admin/src/components/
```

### 2. Page Components with Filters
```bash
# Check page-level filter logic
find apps/admin/src/app -name "page.tsx" -exec grep -l "filter" {} \;
```

### 3. Filter State Management
```typescript
// Look for state management that enforces dependencies
const [buildingFilter, setBuildingFilter] = useState('all');
const [floorFilter, setFloorFilter] = useState('all');

// ❌ PROBLEMATIC: Clearing dependent filters
const handleBuildingChange = (value) => {
  setBuildingFilter(value);
  if (value === 'all') {
    setFloorFilter('all'); // ❌ Why clear the floor filter?
  }
};

// ✅ BETTER: Independent filter management
const handleBuildingChange = (value) => {
  setBuildingFilter(value);
  // Don't touch other filters - let user decide
};
```

---

## 📋 Review Checklist

When implementing or reviewing filters:

- [ ] **Backend verification**: Confirm API supports independent filtering
- [ ] **No artificial constraints**: Remove unnecessary `disabled` props
- [ ] **User flexibility**: Allow any combination of filters that backend supports
- [ ] **Clear defaults**: Use "All [Category]" as sensible defaults
- [ ] **Test independence**: Write tests for each filter working alone
- [ ] **Test combinations**: Verify filters work together as expected
- [ ] **Documentation**: Comment the expected behavior clearly

---

## 🔗 Related Issues

### Files We Fixed
- `apps/admin/src/components/rooms/RoomsFilter.tsx:96` - Removed `disabled={buildingFilter === 'all'}`
- `apps/admin/src/app/(dashboard)/rooms/page.tsx:309` - Removed floor filter constraint
- `apps/admin/src/app/(dashboard)/surveys/page.tsx` - Similar pattern fixed

### Similar Patterns to Watch For
- Date range filters that unnecessarily require start AND end dates
- Category filters that require parent category selection
- Permission-based filters that over-restrict based on UI assumptions
- Search filters that artificially limit combinations

---

**Last Updated:** 2025-07-02  
**Status:** Current  
**Found In:** ENG-622 - Filter Dependency Bug Investigation