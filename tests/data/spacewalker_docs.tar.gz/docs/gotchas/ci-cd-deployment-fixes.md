# CI/CD and Deployment Fixes

## Purpose
Document critical fixes applied to CI/CD pipeline and AWS deployment infrastructure based on production issues encountered. Essential reference for DevOps engineers troubleshooting deployment failures.

## When to Use This
- CI/CD pipeline failing silently without error details
- CloudWatch Logs authentication errors (403/503)
- Docker image build failures with semantic versioning
- GitHub release creation permission errors
- ECS deployment failures without proper error messages
- Keywords: CI/CD, GitHub Actions, CloudWatch Logs, IAM permissions, Docker tags, deployment debugging

**Version:** 1.0
**Date:** 2025-07-01
**Status:** Current - Production Fixes Applied

---

## 🚨 Critical Issues Fixed

### 1. CloudWatch Logs IAM Permission Error

**Problem:**
```
AccessDeniedException: User is not authorized to perform: logs:DescribeLogGroups 
on resource: arn:aws:logs:us-east-2:881490112168:log-group::log-stream:
```

**Root Cause:**
The AWS API requires `logs:DescribeLogGroups` to have `Resource: '*'` when using `logGroupNamePrefix` parameter.

**Solution:**
Split CloudWatch Logs permissions in `sam/foundation/template.yaml`:

```yaml
# ECSTaskRoleS3 policies
- PolicyName: S3PhotoStorageAccess
  PolicyDocument:
    Statement:
      # CloudWatch Logs access - split into two statements
      # DescribeLogGroups requires * resource
      - Effect: Allow
        Action:
          - logs:DescribeLogGroups
        Resource: '*'
      # Other log operations on specific log groups
      - Effect: Allow
        Action:
          - logs:DescribeLogStreams
          - logs:PutLogEvents
          - logs:CreateLogStream
        Resource:
          - !Sub 'arn:aws:logs:${AWS::Region}:${AWS::AccountId}:log-group:/ecs/${Environment}-spacewalker-*'
          - !Sub 'arn:aws:logs:${AWS::Region}:${AWS::AccountId}:log-group:/ecs/${Environment}-spacewalker-*:*'
          - !Sub 'arn:aws:logs:${AWS::Region}:${AWS::AccountId}:log-group:/aws/spacewalker/${Environment}'
          - !Sub 'arn:aws:logs:${AWS::Region}:${AWS::AccountId}:log-group:/aws/spacewalker/${Environment}:*'
```

---

### 2. CI/CD Silent Deployment Failures

**Problem:**
ECS deployments were failing with generic "Backend deployment failed" messages without actual error details.

**Root Cause:**
Missing error capture and debugging output in deployment commands.

**Solution:**
Enhanced error handling in `.github/workflows/ci-cd.yml`:

```yaml
# Add AWS configuration verification
- name: Verify AWS Configuration
  run: |
    echo "🔍 Verifying AWS configuration..."
    echo "AWS_REGION: ${{ secrets.AWS_REGION }}"
    echo "Current AWS identity:"
    aws sts get-caller-identity
    echo "Checking ECS cluster:"
    aws ecs describe-clusters --clusters dev-spacewalker-ecs-cluster \
      --region ${{ secrets.AWS_REGION }} \
      --query 'clusters[0].clusterName' --output text || echo "Failed to describe cluster"

# Enhanced deployment with error capture
- name: Deploy ECS services
  run: |
    # Force backend service to redeploy
    echo "🔄 Updating backend service..."
    if aws ecs update-service \
      --cluster dev-spacewalker-ecs-cluster \
      --service dev-spacewalker-backend \
      --force-new-deployment \
      --region ${{ secrets.AWS_REGION }} 2>&1; then
      echo "✅ Backend deployment initiated successfully"
    else
      BACKEND_ERROR=$?
      echo "❌ Backend deployment failed with exit code: $BACKEND_ERROR"
      echo "🔍 Debug: AWS_REGION=${{ secrets.AWS_REGION }}"
      echo "🔍 Debug: Checking cluster existence..."
      aws ecs describe-clusters --clusters dev-spacewalker-ecs-cluster \
        --region ${{ secrets.AWS_REGION }} || echo "Cluster check failed"
      exit 1
    fi
```

---

### 3. Docker Tag Semantic Version Issues

**Problem:**
Docker tags with `+` characters (e.g., `2.1.3+dev.20250701.abc123`) were causing build failures.

**Root Cause:**
Docker doesn't support `+` in tag names.

**Solution:**
Replace `+` with `-` in `docker-bake.hcl`:

```hcl
function "image_tags" {
  params = [name]
  result = [
    # Semantic version tags (replace + with - for Docker compatibility)
    "${ECR_REGISTRY}/${ENVIRONMENT}-${name}:${replace(SEMANTIC_VERSION, "+", "-")}",
    "${ECR_REGISTRY}/${ENVIRONMENT}-${name}:v${replace(SEMANTIC_VERSION, "+", "-")}",
    # Git-based tags (existing)
    "${ECR_REGISTRY}/${ENVIRONMENT}-${name}:${replace(GIT_BRANCH, "/", "-")}",
    "${ECR_REGISTRY}/${ENVIRONMENT}-${name}:${GIT_SHA}",
    "${ECR_REGISTRY}/${ENVIRONMENT}-${name}:latest"
  ]
}
```

---

### 4. GitHub Release Creation Permission Error

**Problem:**
```
HTTP 403: Resource not accessible by integration
```

**Root Cause:**
Missing `contents: write` permission in the deploy job.

**Solution:**
Add proper permissions to `deploy-to-ecs` job:

```yaml
deploy-to-ecs:
  permissions:
    id-token: write  # Required for OIDC connection to AWS
    contents: write  # Required to create releases
```

---

### 5. Branch-Specific Release Strategy

**Problem:**
Same release creation logic for dev and main branches caused conflicts.

**Solution:**
Implement branch-specific release handling:

```yaml
- name: Create GitHub release for deployments
  if: github.ref == 'refs/heads/dev' || github.ref == 'refs/heads/main'
  run: |
    # Determine release type based on branch
    if [[ "${{ github.ref }}" == "refs/heads/main" ]]; then
      RELEASE_TYPE="Production"
      RELEASE_TAG="v$DEPLOYMENT_VERSION"
      PRERELEASE_FLAG=""
    else
      RELEASE_TYPE="Development"
      RELEASE_TAG="dev-v$DEPLOYMENT_VERSION"
      PRERELEASE_FLAG="--prerelease"
    fi
    
    # Create release with appropriate settings
    gh release create "$RELEASE_TAG" \
      --title "$RELEASE_TYPE Release $DEPLOYMENT_VERSION" \
      $PRERELEASE_FLAG \
      --notes "deployment details..." \
      --latest
```

---

## 📋 Verification Steps

After applying these fixes:

1. **Verify CloudWatch Logs health:**
   ```bash
   curl https://backend.spacewalker.littleponies.com/api/logs/health
   # Should return: {"status": "healthy", "cloudwatch_connected": true}
   ```

2. **Check CI/CD run output:**
   - Look for AWS configuration verification output
   - Confirm detailed error messages appear on failures
   - Verify deployment logs show success/failure clearly

3. **Verify Docker tags:**
   ```bash
   aws ecr describe-images --repository-name dev-spacewalker-backend \
     --query 'sort_by(imageDetails, &imagePushedAt)[-1].imageTags' \
     --output table
   ```

4. **Check GitHub releases:**
   - Dev branch creates `dev-v*` prereleases
   - Main branch creates `v*` production releases

---

## 🔗 Related Documentation

- [AWS Deployment Guide](../workflows/aws-deployment-guide.md) - Main deployment procedures
- [Troubleshooting Guide](../workflows/troubleshooting-guide.md) - General troubleshooting
- [Monitoring Runbook](../monitoring/monitoring-runbook.md) - CloudWatch monitoring setup

---

## 📝 Lessons Learned

1. **AWS API Quirks:** Some AWS APIs have non-obvious resource requirements (e.g., `logs:DescribeLogGroups` needs `Resource: '*'`)

2. **Error Visibility:** Always capture stderr (`2>&1`) and exit codes (`$?`) in CI/CD scripts for better debugging

3. **Docker Constraints:** Docker tag names have character restrictions - always sanitize version strings

4. **GitHub Actions Permissions:** Be explicit about all required permissions in job definitions

5. **Branch-Specific Logic:** Different environments (dev/prod) often need different release strategies