# AWS CLI Security Gotchas

## Purpose
Critical AWS security practices and common pitfalls that can result in catastrophic security breaches, production incidents, or accidental resource deletion. Essential reference for preventing costly AWS mistakes and security vulnerabilities.

## When to Use This
- Before running any AWS CLI commands that modify resources
- Understanding AWS account separation and security boundaries
- Avoiding common IAM policy mistakes and credential exposure
- Preventing accidental production deployments or resource deletion
- Troubleshooting permission and security configuration issues
- Keywords: AWS security mistakes, production incidents, credential exposure, IAM pitfalls, account separation

**Version:** 2.0 (Extracted from AWS CLI safety rules)
**Date:** 2025-06-29
**Status:** Critical - Production Security Guidelines

---

## ⚠️ Critical AWS Security Warnings

### The Catastrophic Risk: Wrong Account Deployment
**Most Dangerous Mistake**: Accidentally deploying to production instead of sandbox environment.

**Real Incident Example**: Developer deploys test data deletion script to production account, wiping customer data.

**Prevention**: Always verify account context before any operation:
```bash
# Always verify current account and region
aws sts get-caller-identity
aws configure get region

# Expected outputs for environments:
# Sandbox: Account 881490112168, Region us-east-2
# Production: Account 352676346183, Region us-east-1
```

### Environment Separation Gotchas

#### Gotcha 1: Mixed Credentials in Local Environment
**Problem**: Developer accidentally uses production credentials for sandbox testing.

**Symptoms**:
- Unexpectedly high AWS bills from sandbox work
- Production resources showing up in development scripts
- Security team alerts about unusual production access

**Solution**: Use named profiles for strict separation:
```bash
# Configure separate profiles
aws configure --profile sandbox
aws configure --profile production

# Always specify profile in commands
aws --profile sandbox s3 ls
aws --profile production cloudformation describe-stacks

# Set default profile in shell
export AWS_PROFILE=development
```

#### Gotcha 2: Branch-Environment Mismatch
**Problem**: CI/CD deploys sandbox code to production environment or vice versa.

**Symptoms**:
- Production showing test features or debug code
- Sandbox missing critical production security configurations
- Database migrations running against wrong environment

**Critical Check**:
```bash
# Verify branch-environment alignment
if [[ "$GITHUB_REF" == "refs/heads/main" ]]; then
  # Should be production account 352676346183
  EXPECTED_ACCOUNT="352676346183"
else
  # Should be sandbox account 881490112168
  EXPECTED_ACCOUNT="881490112168"
fi

CURRENT_ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
if [[ "$CURRENT_ACCOUNT" != "$EXPECTED_ACCOUNT" ]]; then
  echo "❌ CRITICAL: Wrong account! Expected $EXPECTED_ACCOUNT, got $CURRENT_ACCOUNT"
  exit 1
fi
```

---

## 🔐 IAM Security Pitfalls

### Gotcha 3: Overly Permissive IAM Policies
**Problem**: Creating IAM policies with `*` permissions or global resource access.

**Dangerous Examples**:
```json
{
  "Effect": "Allow",
  "Action": "*",              // ❌ NEVER DO THIS
  "Resource": "*"             // ❌ NEVER DO THIS
}

{
  "Effect": "Allow",
  "Action": "s3:*",
  "Resource": "*"             // ❌ Allows access to ALL S3 buckets
}
```

**Secure Alternative**:
```json
{
  "Effect": "Allow",
  "Action": [
    "s3:GetObject",
    "s3:PutObject"
  ],
  "Resource": [
    "arn:aws:s3:::spacewalker-sandbox-deployments/*",
    "arn:aws:s3:::spacewalker-prod-deployments/*"
  ],
  "Condition": {
    "StringEquals": {
      "aws:RequestedRegion": ["us-east-2", "us-east-1"],
      "aws:PrincipalAccount": ["881490112168", "352676346183"]
    }
  }
}
```

### Gotcha 4: Forgetting Permission Boundaries
**Problem**: IAM users or roles can escalate privileges beyond intended scope.

**Symptoms**:
- CI/CD users gaining unintended admin access
- Service roles accessing resources outside their domain
- Cross-account access working when it shouldn't

**Solution**: Always implement permission boundaries:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "*",
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "aws:RequestedRegion": ["us-east-2"]
        },
        "StringLike": {
          "aws:ResourceTag/Environment": ["sandbox", "development"]
        }
      }
    }
  ]
}
```

### Gotcha 5: Hardcoded Credentials in Code
**Critical Security Violation**: Never commit AWS credentials to repositories.

**Common Mistakes**:
```bash
# ❌ NEVER DO THIS
export AWS_ACCESS_KEY_ID="AKIA..."
export AWS_SECRET_ACCESS_KEY="secret..."

# ❌ NEVER DO THIS IN DOCKER
ENV AWS_ACCESS_KEY_ID=AKIA...
ENV AWS_SECRET_ACCESS_KEY=secret...

# ❌ NEVER DO THIS IN CONFIG FILES
aws_access_key_id = AKIA...
aws_secret_access_key = secret...
```

**Detection Commands**:
```bash
# Check for accidentally committed credentials
grep -r "AKIA" . --exclude-dir=.git
grep -r "aws_access_key" . --exclude-dir=.git
grep -r "aws_secret" . --exclude-dir=.git
```

---

## 💥 Resource Modification Dangers

### Gotcha 6: Destructive Operations Without Backups
**Problem**: Running destructive AWS operations without proper backups or confirmation.

**High-Risk Commands**:
```bash
# ❌ Extremely dangerous without confirmation
aws s3 rm s3://bucket-name --recursive
aws rds delete-db-instance --db-instance-identifier prod-db
aws cloudformation delete-stack --stack-name production-stack
aws iam delete-user --user-name important-service-user
```

**Safe Approach**:
```bash
# ✅ Always verify what you're about to delete
aws s3 ls s3://bucket-name --recursive | head -10
echo "About to delete $(aws s3 ls s3://bucket-name --recursive | wc -l) objects"
read -p "Continue? (yes/no): " confirm

if [[ "$confirm" == "yes" ]]; then
  aws s3 rm s3://bucket-name --recursive
else
  echo "Operation cancelled"
fi
```

### Gotcha 7: Resource ARN Confusion
**Problem**: Operating on wrong resources due to similar ARN patterns.

**Common Confusion**:
```bash
# These look similar but are completely different!
arn:aws:s3:::spacewalker-prod-backup     # Production backups
arn:aws:s3:::spacewalker-prod-backup-test # Test bucket that looks like prod

# Different regions/accounts
arn:aws:s3:::bucket-name  # Could exist in multiple accounts
```

**Verification Strategy**:
```bash
# Always verify resource exists and is in expected account
aws s3api head-bucket --bucket spacewalker-prod-backup
aws s3api get-bucket-location --bucket spacewalker-prod-backup

# Check resource tags to verify environment
aws s3api get-bucket-tagging --bucket spacewalker-prod-backup
```

---

## 🚨 Network and Access Control Gotchas

### Gotcha 8: Security Group Rule Confusion
**Problem**: Opening security groups too broadly or to wrong sources.

**Dangerous Patterns**:
```bash
# ❌ Opens to entire internet
aws ec2 authorize-security-group-ingress \
  --group-id sg-12345 \
  --protocol tcp \
  --port 22 \
  --cidr 0.0.0.0/0

# ❌ Wrong source group (production allowing sandbox)
aws ec2 authorize-security-group-ingress \
  --group-id sg-prod-db \
  --protocol tcp \
  --port 5432 \
  --source-group sg-sandbox-app
```

**Verification Commands**:
```bash
# Check what you're about to allow
aws ec2 describe-security-groups --group-ids sg-12345
aws ec2 describe-instances --filters "Name=instance.group-id,Values=sg-12345"
```

### Gotcha 9: Cross-Account Access Misconfiguration
**Problem**: Accidentally granting cross-account access to wrong accounts.

**Common Mistake**:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::123456789012:root"  // ❌ Wrong account ID
      },
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::sensitive-bucket/*"
    }
  ]
}
```

**Account Verification**:
```bash
# Always double-check account IDs
echo "Sandbox Account: 881490112168"
echo "Production Account: 352676346183"
echo "Current Account: $(aws sts get-caller-identity --query Account --output text)"
```

---

## 🛡️ Monitoring and Audit Gotchas

### Gotcha 10: Missing CloudTrail Coverage
**Problem**: Making changes without audit trail or in regions without logging.

**Blind Spots**:
```bash
# Commands that might not be logged
aws configure set region us-west-1  # Different region
aws iam create-access-key --user-name service-user  # Credential creation
aws kms decrypt --ciphertext-blob file://encrypted.txt  # Data access
```

**Verification**:
```bash
# Check CloudTrail status in current region
aws cloudtrail describe-trails
aws cloudtrail get-trail-status --name arn:aws:cloudtrail:region:account:trail/name
```

### Gotcha 11: Ignoring AWS Config Compliance
**Problem**: Making changes that violate compliance rules without checking.

**Common Violations**:
- Creating unencrypted S3 buckets
- Launching instances without required tags
- Creating security groups with overly permissive rules

**Prevention**:
```bash
# Check compliance before making changes
aws configservice get-compliance-details-by-resource \
  --resource-type AWS::S3::Bucket \
  --resource-id bucket-name
```

---

## 🔍 Account Context Verification Checklist

### Pre-Operation Safety Checklist
Run these commands before ANY destructive operation:

```bash
# 1. Verify account identity
echo "Current Account: $(aws sts get-caller-identity --query Account --output text)"
echo "Current Region: $(aws configure get region)"
echo "Current User/Role: $(aws sts get-caller-identity --query Arn --output text)"

# 2. Check if this matches expected environment
if [[ "$(aws sts get-caller-identity --query Account --output text)" == "352676346183" ]]; then
  echo "⚠️  YOU ARE IN PRODUCTION ACCOUNT!"
  echo "🔴 EXTRA CAUTION REQUIRED"
elif [[ "$(aws sts get-caller-identity --query Account --output text)" == "881490112168" ]]; then
  echo "✅ You are in sandbox account"
else
  echo "❌ UNKNOWN ACCOUNT - STOP IMMEDIATELY"
  exit 1
fi

# 3. Verify resource scope
echo "About to operate on: [LIST YOUR RESOURCES]"
read -p "Confirm this is correct (yes/no): " confirm
```

### 🛡️ Production Safety System (2025 Update)

**NEW: Automated Production Protection**

SpaceWalker now includes a comprehensive production safety system that prevents most accidental deployments:

```bash
# Production commands are automatically blocked
just aws_deploy_foundation prod  # ❌ Blocked without prod mode

# Must explicitly enable production mode
(just prod enable --minutes=30)             # Enable for 30 minutes
# Type: ENABLE PRODUCTION ACCESS

# Now production commands work with safety warnings
just aws_deploy_foundation prod  # ✅ Works with account verification
```

**Key Features:**
- **Time-Limited Access**: Auto-expires (15-60 minutes)
- **Visual Indicators**: Terminal title shows `🚨PROD:15m`
- **Account Verification**: Shows target AWS account before deployment
- **Explicit Activation**: Must type exact confirmation phrase

**Setup Guide**: See [docs/workflows/deployment-guide.md#production-safety-system](../workflows/deployment-guide.md#production-safety-system)

### Emergency Contact Information
If you accidentally make changes to production:

1. **Immediate Actions**:
   - Stop all running operations immediately
   - Document what was changed
   - Check AWS CloudTrail for full scope of changes

2. **Escalation**:
   - Notify DevOps team immediately
   - Create incident ticket with full details
   - Prepare rollback plan if needed

3. **Recovery**:
   - Use CloudFormation stack rollback if applicable
   - Restore from automated backups
   - Review and update security procedures

---

## 📋 Related Security Documentation

### Platform-Specific Security Guidelines
> 🔒 **Backend Teams**: See [Backend Security](../backend/security/) for API and database security practices
> 🔒 **Admin Teams**: See [Admin Security](../admin/security/) for dashboard security considerations
> 🔒 **Mobile Teams**: See [Mobile Security](../mobile/security/) for mobile app security patterns

### Implementation Guidance
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Secure deployment procedures and CI/CD practices
- **[Development Setup](../setup/development-setup.md)** - Secure development environment configuration

### Architecture & Requirements
- **[Security Requirements](../architecture/architecture-requirements.md)** - Overall security architecture requirements
- **[Product Overview](../product/product-overview.md)** - System security context and threat model

---

**Status**: 🚨 **CRITICAL SECURITY GUIDELINES**
**Last Updated**: 2025-06-29
**Environment Accounts**: Sandbox (881490112168), Production (352676346183)
**Security Level**: Production-Critical

---

*These security practices are based on real production incidents and industry security breaches. Following these guidelines prevents catastrophic security mistakes that could compromise customer data, incur massive costs, or result in service outages.*
