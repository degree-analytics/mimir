# CloudFormation Circular Dependency Resolution

## The Problem: A Web of Circular Dependencies

We encountered a severe CloudFormation circular dependency issue that put multiple stacks in `UPDATE_ROLLBACK_COMPLETE` state, making them impossible to update or delete through normal means.

### The Dependency Web

```
DNS Stack ─────────────────────────────────┐
│                                          │
├─ Exports:                                │
│  └─ dev-spacewalker-certificate-arn ─────┼──┬─→ Imported by: Backend
│  └─ dev-spacewalker-backend-domain ──────┼──┼─→ Imported by: Mobile
│  └─ dev-spacewalker-mobile-domain        │  │
│                                          │  │
├─ Resources:                              │  │
│  └─ Certificate (ACM)                    │  │
│  └─ Route53 Records ──────────────────┐  │  │
│                                       │  │  │
Backend Stack ←─────────────────────────┼──┘  │
│                                       │     │
├─ Imports:                             │     │
│  └─ Certificate from DNS ←────────────┼─────┘
│  └─ ALB DNS from self (!)             │
│                                       │
├─ Exports:                             │
│  └─ dev-backend-alb-dns ──────────────┼─────→ Imported by: DNS (for Route53)
│                                       │
Mobile Stack ←──────────────────────────┘
│
├─ Imports:
│  └─ Certificate from DNS
│  └─ Backend domain from DNS
│
└─ Exports:
   └─ dev-mobile-alb-dns ───────────────────→ Imported by: DNS (for Route53)
```

### The Circular Loop

1. **DNS** exports certificate → used by **Backend** and **Mobile**
2. **Backend** exports ALB DNS → used by **DNS** for Route53 records
3. **Mobile** exports ALB DNS → used by **DNS** for Route53 records
4. **DNS** can't delete because Backend/Mobile use its exports
5. **Backend/Mobile** can't delete because DNS uses their exports
6. Result: **DEADLOCK**

## Why This Happened

### Root Causes

1. **Bidirectional Dependencies**: DNS needed ALB DNS names from Backend/Mobile, while Backend/Mobile needed the certificate from DNS
2. **Export Protection**: CloudFormation prevents deletion of exports that are in use
3. **Stack State Lock**: Once in `UPDATE_ROLLBACK_COMPLETE`, stacks can't be modified if they have protected exports

### What Made It Worse

- The circular dependency existed at the CloudFormation metadata level, not just the AWS resource level
- Even with all actual AWS resources deleted, the export/import metadata prevented stack operations
- AWS Support confirmed they couldn't force-delete from their end

## The Solution: Hollowing Out Stacks

### Step 1: Create Minimal Templates

We created minimal templates for each stack that:
- Contained only a single `WaitConditionHandle` resource (no actual AWS resources)
- Preserved all exports with hardcoded values
- Removed all imports

```yaml
Resources:
  DummyWaitHandle:
    Type: AWS::CloudFormation::WaitConditionHandle

Outputs:
  # Keep all exports with hardcoded values
  CertificateArn:
    Value: 'arn:aws:acm:us-east-2:xxx:certificate/xxx'  # Hardcoded
    Export:
      Name: !Sub '${Environment}-spacewalker-certificate-arn'
```

### Step 2: Update Stacks to Minimal Versions

- Updated each stack to its minimal template
- This deleted all real AWS resources while preserving exports
- Stacks became "export containers" with no actual resources

### Step 3: Delete in Correct Order

With stacks hollowed out, deletion order becomes manageable:
1. Mobile and Backend first (leaf nodes)
2. DNS next (after its importers are gone)
3. Foundation last

## Prevention: What NOT to Do

### 🚫 NEVER Create Bidirectional Dependencies

**Bad Pattern:**
```yaml
# DNS Stack
Resources:
  DNSRecord:
    Properties:
      AliasTarget:
        DNSName: !ImportValue 'backend-alb-dns'  # ❌ Importing from Backend

Outputs:
  CertificateArn:
    Export:
      Name: 'certificate-arn'  # ❌ Backend will import this
```

**Good Pattern:**
```yaml
# DNS Stack - Only exports, no imports from dependent stacks
Outputs:
  CertificateArn:
    Export:
      Name: 'certificate-arn'

# Backend Stack - Only imports, no exports back to DNS
Resources:
  ALB:
    Properties:
      Certificates:
        - CertificateArn: !ImportValue 'certificate-arn'
```

### 🚫 NEVER Use ImportValue for Circular Resources

**Bad Pattern:**
- DNS creates Route53 records using `!ImportValue` from ALB DNS names
- ALBs need certificates from DNS

**Good Pattern:**
- Use parameters or SSM Parameter Store for values needed by multiple stacks
- Or create Route53 records in the same stack as the ALB

### ✅ DO Follow Dependency Hierarchy

1. **Foundation Stack**: VPC, subnets, basic security groups (no imports)
2. **DNS/Certificate Stack**: Certificates, hosted zones (imports only from Foundation)
3. **Service Stacks**: ECS, ALBs, apps (import from Foundation and DNS, but don't export back)

### ✅ DO Use These Patterns Instead

1. **Parameter Store Pattern**:
```yaml
# Backend Stack - Write ALB DNS to Parameter Store
ALBDNSParameter:
  Type: AWS::SSM::Parameter
  Properties:
    Name: '/app/backend/alb-dns'
    Value: !GetAtt ALB.DNSName

# DNS Stack - Read from Parameter Store (not Import)
DNSRecord:
  Type: AWS::Route53::RecordSet
  Properties:
    AliasTarget:
      DNSName: !Sub '{{resolve:ssm:/app/backend/alb-dns}}'
```

2. **Single Stack Pattern**:
```yaml
# Put Route53 records in the same stack as the ALB
Resources:
  ALB:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer

  DNSRecord:
    Type: AWS::Route53::RecordSet
    Properties:
      AliasTarget:
        DNSName: !GetAtt ALB.DNSName  # Direct reference, no export/import
```

3. **Orchestration Pattern**:
- Use deployment scripts that gather outputs and pass as parameters
- Avoid CloudFormation exports for inter-stack communication

## Key Lessons

1. **Exports create hard dependencies** - Use them sparingly
2. **Circular dependencies can lock stacks permanently** - Always map dependencies before creating exports
3. **"Hollowing out" is a last resort** - Better to prevent than fix
4. **Stack hierarchy should be unidirectional** - Dependencies should flow one way
5. **When in doubt, use parameters** - They're more flexible than exports

## Emergency Recovery Checklist

If you find yourself in a circular dependency situation:

1. **Stop making changes** - More updates usually make it worse
2. **Map the full dependency graph** - Understand all imports/exports
3. **Create minimal templates** - Preserve exports, remove resources
4. **Update stacks to minimal** - This removes AWS resources
5. **Delete in dependency order** - Leaves first, roots last
6. **Rebuild with proper patterns** - Don't recreate the same issue

## Testing for Circular Dependencies

Before deploying interconnected stacks:

```bash
# List all exports
aws cloudformation list-exports --query "Exports[?starts_with(Name, 'dev-')].[Name,ExportingStackId]" --output table

# Check what imports each export
for export in $(aws cloudformation list-exports --query "Exports[?starts_with(Name, 'dev-')].Name" --output text); do
  echo "Export: $export"
  aws cloudformation list-imports --export-name "$export" --query "Imports[]" --output json
done
```

If you see Stack A importing from Stack B, and Stack B importing from Stack A - **STOP** and redesign.
