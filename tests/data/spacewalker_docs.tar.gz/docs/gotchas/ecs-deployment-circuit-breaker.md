# ECS Deployment Circuit Breaker Gotchas

## Problem Description
ECS deployments fail repeatedly with "service failed to launch a task" and the deployment circuit breaker triggers, preventing the service from starting. The ECS console shows tasks starting and immediately stopping in a loop.

## Symptoms
- ECS service stuck in "UPDATE_IN_PROGRESS" state
- Tasks show "STOPPED" status immediately after starting
- CloudFormation stack update fails with "Resource handler returned message: Error occurred during operation"
- ECS events show "service xxx was unable to place a task"
- Tasks exit with "ResourceInitializationError" or "Essential container xxx exited"

## Root Cause
The circuit breaker triggers when ECS cannot successfully start tasks. Common causes:
1. **Missing dependencies**: Database not accessible, required services not running
2. **Missing secrets**: Environment variables referencing non-existent secrets
3. **IAM permissions**: Task execution role lacks permissions to access secrets/resources
4. **Container image issues**: ECR repository doesn't exist or image not pushed
5. **Resource constraints**: Insufficient CPU/memory in cluster

## Solution

### Diagnostic Steps
1. **Check ECS task logs**:
   ```bash
   just aws_logs dev
   # Or directly:
   aws logs tail /aws/ecs/dev-spacewalker-backend --follow
   ```

2. **Inspect stopped tasks**:
   ```bash
   # List stopped tasks
   aws ecs list-tasks --cluster dev-spacewalker-cluster --desired-status STOPPED

   # Describe task for stop reason
   aws ecs describe-tasks --cluster dev-spacewalker-cluster --tasks <task-arn>
   ```

3. **Verify dependencies**:
   ```bash
   # Check if database is accessible
   just health dev

   # Verify ECR repositories exist
   aws ecr describe-repositories --repository-names dev-spacewalker-backend

   # Check secrets exist
   just secrets list dev
   ```

### Common Fixes

#### Missing Database
```bash
# Deploy database first
just aws_deploy_database dev

# Verify it's accessible
just health dev
```

#### Missing Secrets
```bash
# Backend requires api-keys secret
just secrets create dev --secret-name api-keys --secret-value '{
  "GEMINI_API_KEY": "your-key",
  "JWT_SECRET": "your-secret"
}'

# Mobile requires EXPO_TOKEN in storage secret
just secrets update dev --secret-name storage --secret-value '{
  "EXPO_TOKEN": "your-expo-token"
}'
```

#### Missing ECR Images
```bash
# Build and push images
just aws build backend dev
just aws build admin dev
just aws build mobile dev
```

#### IAM Permission Issues
```bash
# Update foundation stack to grant secret access
# Edit sam/foundation/foundation.yaml to add:
- Effect: Allow
  Action:
    - secretsmanager:GetSecretValue
  Resource:
    - !Sub "arn:aws:secretsmanager:${AWS::Region}:${AWS::AccountId}:secret:${Environment}-spacewalker-*"

# Redeploy foundation
just aws_deploy_foundation dev
```

## Prevention

1. **Deploy in correct order**:
   - Foundation → ECR → Cluster → Database → Backend → Admin → Mobile

2. **Pre-deployment checklist**:
   ```bash
   # Verify all dependencies
   just stack status dev        # All prerequisite stacks deployed
   just secrets list dev        # Required secrets exist
   just aws_ecr_check dev         # ECR repositories exist
   ```

3. **Use health checks** after each deployment:
   ```bash
   just health dev
   just aws status all dev
   ```

4. **Monitor ECS events** during deployment:
   ```bash
   aws ecs describe-services --cluster dev-spacewalker-cluster --services dev-spacewalker-backend
   ```

## Time Impact
Each circuit breaker trigger: 15-30 minutes
Proper deployment order: Prevents issue entirely

## Related Issues
- [CloudFormation Deployment Gotchas](./cloudformation-deployment-gotchas.md) - Overall deployment issues
- [Variable Name Mismatches](./variable-name-mismatches.md) - Environment variable issues

## Keywords
ECS, circuit breaker, deployment, ResourceInitializationError, task placement, secrets, ECR, IAM
