# Variable Name Mismatches Environment Issues

## Problem Description
Inconsistent environment variable naming between different configuration sources causes deployment failures and configuration errors. Variables with similar names like `IMAGE_BUCKET` vs `IMAGES_BUCKET` create confusion and runtime failures.

## Symptoms
- Services fail to start with "missing configuration" errors
- Environment variables appear set but aren't recognized
- Configuration works in one environment but fails in another
- Deployment scripts reference variables that don't exist
- Storage or API calls fail with "bucket not found" or similar errors

### Error Messages
```
KeyError: 'IMAGES_BUCKET'
Configuration validation failed: missing required environment variable
```

Development environment shows:
- Variable set as `IMAGE_BUCKET=my-bucket` in `.env`
- Code references `IMAGES_BUCKET` (with 'S')
- Result: Service can't find storage configuration

## Root Cause
Lack of a single source of truth for environment variable naming leads to inconsistencies across:
- Environment configuration files (`.env`, `.env.local`)
- Infrastructure as Code templates (CloudFormation YAML)
- Application code variable references
- Documentation and setup guides

**Technical Flow:**
1. Infrastructure defines: `ImageBucket` in `shared-resources.yaml`
2. Environment file uses: `IMAGE_BUCKET=bucket-name`
3. Application code references: `IMAGES_BUCKET`
4. Result: Configuration mismatch and runtime failure

## Solution

### Immediate Fix
Always use `shared-resources.yaml` as the authoritative source for variable names:

```bash
# Check the canonical variable name
grep -r "Bucket" shared-resources.yaml

# Example output shows correct name:
# ImagesBucket: !Ref ImagesBucket
```

Update environment files to match:
```bash
# ❌ WRONG - inconsistent naming
IMAGE_BUCKET=my-bucket
IMAGES_BUCKETS=my-bucket

# ✅ CORRECT - matches shared-resources.yaml
IMAGES_BUCKET=my-bucket
```

### Systematic Fix
1. **Audit all variable references**:
```bash
# Find all environment variable patterns
grep -r "IMAGE.*BUCKET" --include="*.py" --include="*.ts" --include="*.js" .
grep -r "IMAGE.*BUCKET" --include="*.env*" --include="*.yaml" .
```

2. **Use shared-resources.yaml as source of truth**:
```bash
# Check infrastructure definitions
cat shared-resources.yaml | grep -i bucket
```

3. **Update all references to match**:
```bash
# Update environment files
sed -i 's/IMAGE_BUCKET/IMAGES_BUCKET/g' .env*
```

## Prevention

### Configuration Standards
1. **Always reference shared-resources.yaml** for canonical variable names
2. **Use consistent naming patterns** across all configuration sources
3. **Validate environment variables** during application startup
4. **Document variable mappings** between infrastructure and application code

### Development Practices
```bash
# Before adding new environment variables
1. Check shared-resources.yaml first
2. Use exact names from infrastructure definitions
3. Update all configuration files consistently
4. Test in clean environment to verify
```

### Code Review Checklist
- [ ] New environment variables match shared-resources.yaml naming
- [ ] All configuration files use consistent variable names
- [ ] Environment validation includes new variables
- [ ] Documentation updated with correct variable names

## Time Impact
**12 hours lost** - This issue caused significant debugging time because:
- Variable appears to be set correctly in environment inspection
- Error messages don't clearly indicate naming mismatch
- Multiple similar variable names make identification difficult
- Issue only manifests at runtime, not during development setup

## Related Issues
- [API Trailing Slashes](./api-trailing-slashes.md) - Another configuration-related authentication issue
- [Environment Setup](../workflows/environment-setup.md#environment-variables) - Environment variable troubleshooting

## Keywords
Environment variables, configuration, naming consistency, shared-resources.yaml, deployment configuration, infrastructure as code, CloudFormation
