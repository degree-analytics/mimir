# CI/CD Performance Anti-Patterns

## Purpose
Documents CI/CD performance anti-patterns discovered during ENG-736 optimization, helping teams avoid common pitfalls that can severely impact build times.

## When to Use This
- Designing new CI/CD workflows
- Optimizing existing pipeline performance
- Debugging slow build times
- Planning monorepo CI/CD architecture

**Keywords**: CI/CD performance, GitHub Actions optimization, artifact vs cache patterns, build speed

**Version**: 1.0  
**Date**: 2025-07-18  
**Status**: Current - Based on ENG-736 findings

---

## 🚨 Anti-Pattern #1: Artifact-Based Dependency Distribution

### The Anti-Pattern
```yaml
# ❌ DON'T: Create artifacts for dependencies
- name: Create dependency artifacts
  run: |
    tar -czf node_modules.tar.gz node_modules
    tar -czf python_env.tar.gz .venv
- name: Upload dependency artifacts
  uses: actions/upload-artifact@v4
  with:
    name: dependencies
    path: "*.tar.gz"
```

### Why It's Problematic
- **Massive Time Overhead**: 82% of build time spent on artifact creation/upload
- **CPU Intensive**: Compression takes 6.7x longer in CI than locally
- **Network Overhead**: Large uploads to GitHub artifact storage
- **Sequential Bottleneck**: All jobs wait for artifact creation
- **Double Storage**: Both cache AND artifacts store same data

### Real Performance Impact (ENG-736)
| Operation | Time | Percentage |
|-----------|------|------------|
| Artifact Creation | 342 seconds | 61.9% |
| Artifact Upload | 111 seconds | 20.2% |
| **Total Overhead** | **453 seconds** | **82%** |

### The Correct Pattern
```yaml
# ✅ DO: Use direct cache access in each job
- name: Cache dependencies
  id: cache-deps
  uses: actions/cache@v4
  with:
    path: |
      ~/.npm
      ~/.cache/pip
      .venv
      node_modules
      apps/*/node_modules
    key: ${{ runner.os }}-deps-${{ hashFiles('**/package.json', '**/package-lock.json', '**/requirements.txt') }}

- name: Install dependencies if needed
  run: |
    if [ ! -d "node_modules" ] || [ ! -d ".venv" ]; then
      echo "🔄 Installing dependencies..."
      just install target=dev
    else
      echo "📦 Using cached dependencies"
    fi
```

---

## 🚨 Anti-Pattern #2: Conditional Artifact Creation

### The Anti-Pattern
```yaml
# ❌ DON'T: Make artifact creation conditional
- name: Create artifacts only on cache miss
  if: steps.cache.outputs.cache-hit != 'true'
  run: tar -czf dependencies.tar.gz node_modules .venv
```

### Why It Fails
- **Dependency Coupling**: Downstream jobs expect specific artifacts
- **Fallback Complexity**: Jobs must handle missing artifacts gracefully
- **Cache Miss Cascade**: One job's cache miss affects all dependent jobs
- **Increased Complexity**: More conditional logic = more failure points

### Critical Lesson from ENG-736
> "Phase 1 approach (conditional artifact creation) is fundamentally broken: Dependent jobs expect full artifacts, skipping artifact creation on cache hits forces all jobs to reinstall dependencies. This makes the pipeline SLOWER, not faster."

### The Correct Pattern
```yaml
# ✅ DO: Eliminate artifacts entirely, use cache consistently
# Each job handles its own dependencies independently
jobs:
  test-backend:
    steps:
      - name: Cache dependencies
        uses: actions/cache@v4
        # ... cache configuration
      - name: Install if needed
        # ... installation logic
```

---

## 🚨 Anti-Pattern #3: Incomplete Cache Keys

### The Anti-Pattern
```yaml
# ❌ DON'T: Use incomplete cache keys
key: ${{ runner.os }}-deps-${{ hashFiles('**/package-lock.json') }}
```

### Problems
- **Missing Dependencies**: Doesn't include workspace `package.json` files
- **Cache Pollution**: Stale cache when workspace dependencies change
- **Inconsistent Behavior**: Some dependency changes don't invalidate cache

### The Correct Pattern
```yaml
# ✅ DO: Include ALL dependency-defining files
key: ${{ runner.os }}-deps-${{ hashFiles('**/package.json', '**/package-lock.json', '**/requirements.txt') }}
```

### Cache Key Best Practices
1. **Include ALL lock files**: `package-lock.json`, `requirements.txt`, `Cargo.lock`, etc.
2. **Include workspace files**: Root and app-specific `package.json` files
3. **Version the pattern**: Add version suffix when changing cache structure
4. **Test locally**: Verify hash patterns match expected files

---

## 🚨 Anti-Pattern #4: Inconsistent Dependency Verification

### The Anti-Pattern
```yaml
# ❌ DON'T: Different verification logic across jobs
# Job 1:
if [ ! -d "node_modules" ]; then npm ci; fi

# Job 2:  
if [ ! -d "node_modules" ] || [ ! -d "apps/admin/node_modules" ]; then npm ci; fi

# Job 3:
if [ ! -d ".venv" ]; then just install target=dev; fi
```

### Problems
- **Inconsistent Behavior**: Different jobs handle dependencies differently
- **Hidden Failures**: Some jobs may use partial/stale dependencies
- **Debugging Complexity**: Hard to track which job has which dependencies

### The Correct Pattern
```yaml
# ✅ DO: Standardized verification with logging
- name: Verify cache hit and install dependencies
  run: |
    echo "Cache hit status: ${{ steps.cache-deps.outputs.cache-hit }}"
    if [ ! -d "node_modules" ] || [ ! -d "apps/mobile/node_modules" ]; then
      echo "🔄 Installing mobile dependencies..."
      npm ci
    else
      echo "📦 Using cached Node.js dependencies"
      echo "✅ Verified: node_modules and apps/mobile/node_modules exist"
    fi
```

---

## 🚨 Anti-Pattern #5: Race Conditions in Parallel Installs

### The Anti-Pattern
```yaml
# ❌ DON'T: Install tools without caching in parallel jobs
jobs:
  job1:
    steps:
      - run: pip install uv
  job2:
    steps:
      - run: pip install uv  # Race condition
```

### Problems
- **Network Contention**: Multiple simultaneous downloads
- **Installation Conflicts**: Concurrent installs may interfere
- **Wasted Resources**: Repeated downloads of same binaries

### The Correct Pattern
```yaml
# ✅ DO: Cache tool binaries separately
- name: Cache UV binary
  uses: actions/cache@v4
  with:
    path: ~/.local/bin
    key: ${{ runner.os }}-uv-${{ hashFiles('**/requirements.txt') }}
    
- name: Install UV if needed
  run: |
    if ! command -v uv &> /dev/null; then
      pip install uv
    fi
```

---

## 📊 Performance Impact Summary

### ENG-736 Results: Artifact → Cache Migration

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Total Setup Time** | 9.2 minutes | ~30 seconds | **82% reduction** |
| **Job Start Delay** | 9+ minutes | Immediate | **100% elimination** |
| **Workflow Complexity** | High (artifacts) | Low (cache only) | **Simplified** |
| **Debugging Ease** | Poor | Good | **Per-job visibility** |

### Key Lessons
1. **GitHub Actions cache >> artifacts** for dependency distribution
2. **Direct cache access** eliminates setup bottlenecks
3. **Complete cache keys** prevent stale dependency issues
4. **Consistent patterns** across jobs reduce complexity
5. **Tool caching** prevents race conditions

---

## 🔧 Implementation Checklist

When optimizing CI/CD performance:

### Cache Strategy
- [ ] Use GitHub Actions cache, not artifacts, for dependencies
- [ ] Include ALL dependency files in cache keys
- [ ] Cache tool binaries separately to prevent race conditions
- [ ] Add cache hit logging for debugging

### Job Design
- [ ] Each job handles its own dependencies
- [ ] Consistent dependency verification logic across jobs
- [ ] Proper fallback when cache misses
- [ ] Clear logging for cache hit/miss status

### Performance Monitoring
- [ ] Track cache hit rates across builds
- [ ] Monitor job start times after cache changes
- [ ] Measure total workflow duration improvements
- [ ] Document performance baselines for future optimization

---

## 📚 Related Documentation

- **[CI/CD Build Guide](../workflows/ci-cd-build-guide.md)** - Complete pipeline documentation with performance section
- **[GitHub Actions Best Practices](../workflows/github-actions-best-practices.md)** - General workflow optimization patterns
- **[EAS Build Archive Optimization](./eas-build-archive-optimization.md)** - Mobile-specific build optimizations

---

**Status**: ✅ Current as of 2025-07-18. Based on real performance analysis from ENG-736 optimization.
