# Database Security Gotchas

## Purpose
Critical security considerations and common pitfalls when working with database access infrastructure in the Spacewalker system. Essential reading for developers and DevOps engineers to avoid security vulnerabilities and configuration issues.

## When to Use This
- Setting up database access for the first time
- Troubleshooting SSH connection issues
- Reviewing security configurations
- Implementing database access in CI/CD pipelines
- Debugging authentication and authorization problems

**Keywords:** database security, SSH security, AWS Secrets Manager, bastion host security, credential management

**Version:** 1.0 (Initial security documentation)
**Date:** 2025-07-03
**Status:** Current - Critical Security Guidelines

---

## 🚨 Critical Security Issues

### SSH Host Key Verification Bypass

**❌ NEVER DO THIS:**
```bash
# DANGEROUS: Disables host key verification
ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null
```

**✅ SECURE APPROACH:**
```bash
# SECURE: Accept new keys but verify existing ones
ssh -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=~/.ssh/known_hosts.dev
```

**Why This Matters:**
- `StrictHostKeyChecking=no` disables all host key verification
- Vulnerable to man-in-the-middle attacks
- AWS bastion hosts can change IPs, making this tempting but dangerous
- Our implementation uses environment-specific known_hosts files for proper security

### Credential Exposure in Command History

**❌ DANGEROUS PATTERN:**
```bash
# Credentials visible in shell history and process list
psql postgresql://user:password@host:port/database
export PGPASSWORD="hardcoded-password"
```

**✅ SECURE APPROACH:**
```bash
# Credentials retrieved securely from AWS Secrets Manager
just db_quick_connect dev
# OR
export PGPASSWORD=$(aws secretsmanager get-secret-value --secret-id AURORA/dev-spacewalker --query SecretString --output text | jq -r '.password')
```

**Security Benefits:**
- No hardcoded credentials in scripts or environment
- AWS Secrets Manager provides automatic rotation
- Credentials cached securely in memory for session duration
- No credential exposure in command history

---

## 🔒 SSH Security Best Practices

### Environment-Specific Known Hosts

**Our Implementation:**
```bash
# Environment-specific known_hosts files prevent cross-environment attacks
~/.ssh/known_hosts.dev      # Development environment keys
~/.ssh/known_hosts.staging  # Staging environment keys  
~/.ssh/known_hosts.prod     # Production environment keys
```

**Why This Matters:**
- Prevents accidental connections to wrong environment
- Isolates SSH trust relationships by environment
- Enables proper host key rotation per environment
- Reduces blast radius of compromised keys

### SSH Key Management

**✅ SECURE SSH KEY PRACTICES:**
```bash
# Proper SSH key permissions (critical)
chmod 400 ~/.ssh/dev-spacewalker-key.pem
chmod 400 ~/.ssh/staging-spacewalker-key.pem

# Verify key permissions
ls -la ~/.ssh/*-spacewalker-key.pem
# Should show: -r-------- (400 permissions)
```

**❌ COMMON MISTAKES:**
```bash
# Wrong permissions - SSH will reject overly permissive keys
chmod 644 ~/.ssh/dev-spacewalker-key.pem  # TOO PERMISSIVE
chmod 777 ~/.ssh/dev-spacewalker-key.pem  # EXTREMELY DANGEROUS
```

**Key Security Notes:**
- SSH keys must have restrictive permissions (400 or 600)
- Different keys for each environment prevent privilege escalation
- Keys should be stored securely and never committed to git
- Regular key rotation is essential for production environments

---

## 🌐 Network Security Considerations

### Port Management Security

**Race Condition Prevention:**
Our database helper implements automatic port detection to prevent conflicts:

```bash
# Secure port allocation with validation
just db_tunnel dev 5432  # Validates port range 1024-65535
```

**Security Features:**
- Port range validation (1024-65535) prevents system port conflicts
- Automatic port discovery prevents tunnel collisions
- Race condition prevention in multi-user environments
- Proper cleanup prevents port exhaustion

### Tunnel Security

**✅ SECURE TUNNEL PATTERNS:**
```bash
# Tunnels automatically cleaned up on exit
just db_quick_connect dev

# Background tunnels with proper PID tracking
just db_tunnel_background dev 5433
just db_kill_tunnels dev  # Clean cleanup
```

**❌ INSECURE TUNNEL PATTERNS:**
```bash
# Manual SSH tunnels without proper cleanup
ssh -L 5432:db:5432 -N bastion &  # Process may become orphaned
# No automatic cleanup leads to security and resource issues
```

---

## 🔐 AWS Security Integration

### Secrets Manager Best Practices

**✅ SECURE CREDENTIAL RETRIEVAL:**
```python
# Our implementation: Secure credential caching
credentials = self.get_database_credentials()  # Cached securely
# Credentials cached in memory for session duration only
```

**Security Benefits:**
- Credentials retrieved from AWS Secrets Manager only
- Secure in-memory caching reduces API calls
- Automatic credential rotation support
- No credentials stored in files or environment variables

### IAM Permission Requirements

**Minimum Required Permissions:**
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "secretsmanager:GetSecretValue"
            ],
            "Resource": "arn:aws:secretsmanager:region:account:secret:AURORA/*"
        },
        {
            "Effect": "Allow", 
            "Action": [
                "cloudformation:DescribeStacks"
            ],
            "Resource": "arn:aws:cloudformation:region:account:stack/*-spacewalker-foundation/*"
        }
    ]
}
```

**Security Notes:**
- Principle of least privilege - only necessary permissions
- Resource-specific ARNs prevent overly broad access
- Regular permission audits ensure minimal access rights

---

## ⚠️ Common Security Pitfalls

### 1. Bypassing Input Validation

**❌ DANGEROUS:**
```bash
# Bypassing our validation by calling Python directly
python3 scripts/database/db_helper.py --env "dev; malicious-command"
```

**✅ SECURE:**
```bash
# Use justfile commands that include proper validation
just db_quick_connect dev
```

**Protection:** Our implementation includes comprehensive input validation for environments and ports.

### 2. Reusing SSH Tunnels Across Environments

**❌ SECURITY RISK:**
```bash
# Using dev tunnel for staging operations
just db_tunnel dev 5432
just db_connect staging 5432  # WRONG - connects to dev through staging credentials
```

**✅ SECURE APPROACH:**
```bash
# Environment-specific tunnels
just db_tunnel dev 5432
just db_connect dev 5432      # Correct environment matching
```

### 3. Credential Leakage in Logs

**❌ DANGEROUS LOG PATTERNS:**
```bash
# Credentials might appear in logs
echo "Connecting with password: $PGPASSWORD"  # NEVER DO THIS
```

**✅ SECURE LOGGING:**
```python
# Our implementation: Secure logging without credential exposure
print(f"✅ Database credentials: {creds['username']}@{creds['host']}")
# Password never logged
```

---

## 🛡️ Security Monitoring

### Connection Auditing

**What Gets Logged:**
- SSH connection attempts to bastion hosts
- Database connection establishments
- Credential retrieval from Secrets Manager
- Tunnel creation and termination

**Monitoring Locations:**
- **CloudTrail**: AWS API calls and Secrets Manager access
- **VPC Flow Logs**: Network traffic patterns and connections
- **EC2 Instance Logs**: SSH authentication attempts on bastion hosts
- **Database Logs**: PostgreSQL connection and query logs

### Security Alerts

**Monitor For:**
- Multiple failed SSH attempts to bastion hosts
- Unusual database connection patterns
- Credential access outside business hours
- Tunnel connections from unexpected IP addresses

---

## 🔧 Troubleshooting Security Issues

### SSH Connection Failures

**Common Issue: Host Key Verification Failures**
```bash
# Error: "Host key verification failed"
# Solution: Check environment-specific known_hosts
ls -la ~/.ssh/known_hosts.dev
```

**Common Issue: Permission Denied**
```bash
# Error: "Permission denied (publickey)"
# Check SSH key permissions
chmod 400 ~/.ssh/dev-spacewalker-key.pem
```

### AWS Access Issues

**Common Issue: Secrets Manager Access Denied**
```bash
# Test AWS access
aws sts get-caller-identity
aws secretsmanager describe-secret --secret-id AURORA/dev-spacewalker
```

**Common Issue: CloudFormation Stack Not Found**
```bash
# Verify stack exists
aws cloudformation describe-stacks --stack-name dev-spacewalker-foundation
```

---

## 📋 Security Checklist

### Before Database Access
- [ ] SSH key exists and has correct permissions (400)
- [ ] AWS CLI configured with appropriate IAM permissions
- [ ] Environment-specific known_hosts file exists
- [ ] No hardcoded credentials in scripts or environment

### During Database Operations
- [ ] Use justfile commands instead of manual SSH
- [ ] Verify connecting to correct environment
- [ ] Clean up tunnels after use
- [ ] Monitor for unusual connection patterns

### After Database Access
- [ ] Terminate all SSH tunnels properly
- [ ] Clear any temporary credential caches
- [ ] Review connection logs for anomalies
- [ ] Update known_hosts if bastion IP changed

---

## 🔗 Related Security Documentation

- **[Security Architecture](../architecture/security-architecture.md)** - System-wide security design
- **[Database Access Workflows](../workflows/database-access.md)** - Secure operational procedures
- **[AWS Security Practices](./aws-security-practices.md)** - AWS-specific security guidelines
- **[Environment Configuration](../setup/environment-configuration.md)** - Secure environment setup

---

**Status**: ✅ **CRITICAL SECURITY GUIDELINES**
**Last Updated**: 2025-07-03
**Scope**: Database Security, SSH Security, AWS Integration, Credential Management
**Key Focus**: Security vulnerability prevention and secure operational practices

---

*This security documentation provides essential guidelines for maintaining secure database access while avoiding common security pitfalls and vulnerabilities.*