# TestFlight Duplicate Build Number Prevention

## Problem: TestFlight Submission Failures Due to Duplicate Build Numbers

**Symptom**: TestFlight submission fails with error:
```
You've already submitted this build of the app.
Builds are identified by CFBundleVersion from Info.plist (expo.ios.buildNumber in app.json).
If you're submitting an Expo project built with EAS Build, increment the build number (expo.ios.buildNumber) in app.json and build the project again.
```

**Root Cause**: Static build numbers in `app.json` cause EAS builds to use the same `CFBundleVersion`, leading to duplicate submissions when multiple builds are created from the same branch or after failed deployments.

## Impact
- **Deployment Blocking**: Failed TestFlight submissions prevent release cycles
- **Manual Intervention**: Requires manual `app.json` editing and rebuild
- **CI/CD Disruption**: Automated pipelines fail at submission step
- **Time Loss**: Each failure requires ~15-20 minute rebuild cycle

## Solution: Automated EAS Version Sync

### 1. EAS Version Sync Script

**Location**: `scripts/eas_version_sync.sh`

**Purpose**: Automatically updates both semantic version and unique build numbers for iOS and Android platforms before EAS build triggers.

**Key Features**:
- **Timestamp-based build numbers**: Format `YYMMDDHHMM` ensures uniqueness
- **Cross-platform support**: Updates both iOS `buildNumber` and Android `versionCode`
- **Semantic version extraction**: Strips build metadata for clean app version
- **Error handling**: Validates inputs and file operations

### 2. CI/CD Integration

**Before Fix**:
```yaml
# Only updated version, buildNumber remained static
json -I -f app.json -e "this.expo.version='$SEMANTIC_VERSION'"
```

**After Fix**:
```yaml
# Sync both version and build number automatically
bash ../../scripts/eas_version_sync.sh "$SEMANTIC_VERSION"
```

**Applied To**:
- iOS EAS build job (`eas-build-ios`)
- Android EAS build job (`eas-build-android`)

### 3. Build Number Format

**Pattern**: `YYMMDDHHMM` (10 digits)
- `YY`: Year (25 for 2025)
- `MM`: Month (01-12)  
- `DD`: Day (01-31)
- `HH`: Hour (00-23)
- `MM`: Minutes (00-59)

**Examples**:
- `2507181445` = July 18, 2025 at 14:45
- `2507181446` = July 18, 2025 at 14:46
- `2512311159` = December 31, 2025 at 11:59

**Benefits**:
- **Guaranteed uniqueness**: Two builds cannot have identical timestamps
- **Chronological ordering**: Higher numbers = newer builds
- **Human readable**: Easy to identify build creation time
- **Platform compatible**: Fits within iOS/Android version code limits

## Prevention Workflow

### Automatic Prevention (Recommended)

The CI/CD pipeline now prevents duplicate builds automatically:

1. **Trigger**: Push to `main` or `dev` branch
2. **Version Sync**: `eas_version_sync.sh` generates unique build number
3. **EAS Build**: Uses updated `app.json` with unique identifiers
4. **TestFlight Submit**: Succeeds with unique build number

### Manual Prevention (Emergency)

If manual build is needed:

```bash
# 1. Navigate to mobile directory
cd apps/mobile

# 2. Run version sync with current version
bash ../../scripts/eas_version_sync.sh "1.0.4"

# 3. Verify update
cat app.json | jq '.expo.ios.buildNumber'

# 4. Trigger EAS build
eas build --platform ios --profile production-testing
```

## Validation Commands

### Check Current Build Numbers
```bash
# View current app.json configuration
cd apps/mobile
cat app.json | jq '{version: .expo.version, ios: .expo.ios.buildNumber, android: .expo.android.versionCode}'
```

### Verify TestFlight Submission Status
```bash
# Check recent EAS builds
eas build:list --platform ios --limit 5

# Check submission status
eas submit:list --platform ios --limit 3
```

### Test Version Sync Script
```bash
# Test script with version
bash scripts/eas_version_sync.sh "1.0.4"

# Verify changes (should show new build number)
git diff apps/mobile/app.json
```

## Related Issues

### Android Build Number Limits
**Issue**: Android `versionCode` has maximum value of `2100000000`
**Current Format**: `YYMMDDHHMM` (max ~2512311159 in 2025)
**Future Consideration**: Format change needed by ~2035

### Build Number Collisions
**Risk**: Multiple builds within same minute
**Mitigation**: CI/CD builds are sequential, collision probability minimal
**Fallback**: Manual increment if collision detected

### Git State During CI
**Issue**: Script modifies `app.json` during build
**Impact**: Temporary file changes in CI environment only
**Resolution**: Changes not committed back to repository

## Troubleshooting

### Script Execution Errors
```bash
# Check script permissions
ls -la scripts/eas_version_sync.sh

# Make executable if needed
chmod +x scripts/eas_version_sync.sh

# Validate json utility availability
which json || npm install -g json
```

### Build Number Validation
```bash
# Check if build number is valid integer
BUILD_NUM=$(date -u +"%y%m%d%H%M")
echo $BUILD_NUM | grep -E '^[0-9]{10}$' && echo "Valid" || echo "Invalid"
```

### TestFlight Submission History
```bash
# Review submission history for patterns
eas submit:list --platform ios --limit 10 | grep -E "(completed|error)"
```

## Best Practices

1. **Never manually edit build numbers** in `app.json` - use the sync script
2. **Always test** version sync script changes with dry runs
3. **Monitor build history** for any duplicate number patterns
4. **Validate CI/CD pipeline** after any workflow changes
5. **Document build number format changes** for future maintenance

## Justfile Integration

### Production Version Generation

The `just version_generate_prod` command now automatically syncs EAS build numbers:

```bash
# Generate version files with production metadata (for deployments)
version_generate_prod:
    @echo "🏷️ Generating version files with production metadata..."
    @echo "⚙️ Setting production environment for version generation..."
    DEPLOY_ENV=prod DOCKER_BUILD_GIT_BRANCH=main just version_backend
    DEPLOY_ENV=prod DOCKER_BUILD_GIT_BRANCH=main just version_frontend
    @echo "🔄 Syncing EAS build numbers for mobile app..."
    #!/usr/bin/env bash
    VERSION=$(jq -r '.version' version.json) && ./scripts/eas_version_sync.sh "$VERSION"
    @echo "✅ Production version files generated with environment=prod, branch=main and EAS build numbers synced"
```

**Key Benefits**:
- **Automated**: Build number sync happens automatically during production builds
- **Consistent**: Ensures all production deployments have unique build numbers
- **Integrated**: Part of standard deployment workflow via justfile

### Usage in Dev→Main Workflow

When using the `/smart-dev-to-main` command:
1. Runs `just version_generate_prod` automatically
2. Updates all version files with production metadata
3. Syncs EAS build numbers with timestamp format
4. Commits changes before creating PR

This prevents TestFlight duplicate build errors during main branch deployments.

## References

- **Script Location**: `scripts/eas_version_sync.sh`
- **CI/CD Configuration**: `.github/workflows/ci-cd.yml`
- **Justfile Command**: `just version_generate_prod`
- **EAS Documentation**: [Expo Build Numbers](https://docs.expo.dev/build-reference/app-versions/)
- **Related Documentation**: [Version Management System](../system/version-management.md)