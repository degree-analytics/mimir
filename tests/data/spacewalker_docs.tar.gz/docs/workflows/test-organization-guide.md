# Test Organization Guide

## Overview
Spacewalker's test suite is organized into unit and integration tests to provide structured testing feedback.

## Test Categories

### 1. Unit Tests (Backend)
**Location**: `apps/backend/tests/unit/`
**Dependencies**: Minimal - mocked external dependencies
**Runtime**: Variable based on test content

**What belongs here**:
- Password utilities and validation
- FICM validation logic
- YAML configuration loading
- Middleware logic
- Security helpers
- Pure functions and algorithms
- Tests with mocked dependencies

**Command**: 
```bash
just test unit backend
```

### 2. Integration Tests (Backend)
**Location**: `apps/backend/tests/integration/`
**Dependencies**: PostgreSQL database + LocalStack services (S3, SES, Secrets Manager)
**Runtime**: Variable based on service dependencies

**What belongs here**:
- User management operations
- Tenant operations
- Analytics with DB queries
- AI prompt generation (needs DB context)
- Any test requiring SQLAlchemy Session
- Model CRUD operations
- Email service tests (SES)
- File upload tests (S3)
- Secret management tests
- Any test using boto3 or AWS services

**Command**:
```bash
just test integration backend
```

## Test Commands

### Current Test Structure
```bash
# Unit tests - mocked dependencies
just test unit backend

# Integration tests - full services
just test integration backend

# All backend tests
just test all backend
```

## CI/CD Integration

### GitHub Actions Example
```yaml
jobs:
  test-unit:
    runs-on: ubuntu-latest
    steps:
      - name: Run unit tests
        run: just test unit backend

  test-integration:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16
      localstack:
        image: localstack/localstack:3.8.1
    steps:
      - name: Run integration tests
        run: just test integration backend
```

## Test Markers

Tests can be marked to indicate their dependencies:

```python
import pytest

@pytest.mark.unit
def test_password_validation():
    """Pure unit test - no external dependencies"""
    pass

@pytest.mark.integration
def test_user_creation():
    """Integration test - needs database"""
    pass

@pytest.mark.aws
def test_email_sending():
    """AWS integration test - needs LocalStack"""
    pass
```

## Best Practices

### 1. Keep Unit Tests Pure
- No database connections
- No external API calls
- No file system operations (except temp files)
- Use mocks for external dependencies

### 2. Minimize Integration Test Scope
- Test integration points, not business logic
- Business logic should be in unit tests
- Keep integration tests focused on boundaries

### 3. Use Appropriate Test Level
- Start with unit tests for logic
- Add integration tests for boundaries
- Reserve full integration for critical paths

## Performance Benchmarks

| Test Type | Dependencies | Use Case |
|-----------|--------------|----------|
| Unit | Mocked | Logic validation |
| Integration | DB + LocalStack | External services |
| All Tests | Everything | Complete validation |

## Troubleshooting

### Tests Running Slowly?
- Check if external services are properly mocked in unit tests
- Ensure unit tests don't require database connections
- Consider optimizing test setup and teardown

### Tests Failing Due to Missing Services?
- Ensure tests are in the correct directory
- Unit tests shouldn't need services
- Integration tests should be marked appropriately

### CI Taking Too Long?
- Implement parallel execution strategy
- Run unit tests while services start
- Consider using cached LocalStack image

## Future Improvements

### Planned Enhancements
1. **Custom LocalStack Base Image**: Pre-configured with common resources
2. **Parallel CI Execution**: Run test suites concurrently
3. **Test Sharding**: Split large test suites across workers
4. **Smart Test Selection**: Run only affected tests based on changes

### Monitoring Test Performance
Track test execution times to identify slow tests using pytest options:

```bash
# Generate test timing report
just test unit backend --pattern="." --verbose
```

## Related Documentation
- [Testing Guide](./testing-guide.md)
- [CI/CD Build Guide](./ci-cd-build-guide.md)
- [Unified Test Commands](./unified-test-commands.md)
- [Verification Standards](../claude-components/verification-standards.md)