# CI/CD Mobile Build Triggering Fix

## Problem
The CI/CD pipeline was incorrectly triggering mobile builds based on accumulated differences between branches (dev vs main) rather than checking what actually changed in each specific commit. This caused documentation-only commits to trigger expensive mobile builds if there were any mobile-related changes elsewhere in the branch.

## Root Cause
The `dorny/paths-filter@v3` action was using its default behavior:
- For push events: Compared the entire branch against main
- Result: Any push to dev triggered mobile builds if dev had mobile changes that main didn't have

## Solution Implemented

### 1. Added Smart Base Commit Detection
```yaml
# First, determine the base commit for comparison
- name: Get comparison base
  id: get-base
  run: |
    if [[ "${{ github.event_name }}" == "push" ]]; then
      # For push events, use the parent commit SHA
      BASE_SHA=$(git rev-parse HEAD~1 2>/dev/null || echo "")
      if [[ -z "$BASE_SHA" ]]; then
        # Handle first commit case
        BASE_SHA=$(git hash-object -t tree /dev/null)
      fi
      echo "base=$BASE_SHA" >> $GITHUB_OUTPUT
    else
      # For PR events, use default behavior
      echo "base=" >> $GITHUB_OUTPUT
    fi

# Then use the computed base in paths-filter
- name: Detect changes in mobile-related paths
  uses: dorny/paths-filter@v3
  id: filter
  with:
    base: ${{ steps.get-base.outputs.base }}
    filters: |
      mobile:
        - 'apps/mobile/**'
        # ... rest of filters
```

### 2. Clarified PR Behavior
Added comment to clarify that PRs only trigger tests, not mobile builds:
```yaml
pull_request:
  # Run tests on ALL pull requests, regardless of target branch
  # This ensures Graphite stack PRs (task3 → task2) also get tested
  # NOTE: Pull requests do NOT trigger mobile builds, only tests
```

## Expected Behavior After Fix

### Push Events (main/dev branches)
- ✅ Documentation-only commit → No mobile build
- ✅ Mobile code changes → Triggers mobile build
- ✅ Backend-only changes → No mobile build
- ✅ Each commit evaluated independently based on its own changes

### Pull Request Events
- ✅ Runs tests for code quality validation
- ✅ Does NOT trigger mobile builds (already prevented by `if: github.event_name != 'pull_request'`)
- ✅ Mobile builds only happen after PR is merged and code lands in main/dev

### Manual Workflow Dispatch
- ✅ Respects `force_mobile_builds` parameter
- ✅ Can override automatic detection when needed

## Testing the Fix

1. **Test documentation-only push**:
   ```bash
   # Make a docs-only change
   echo "test" >> README.md
   git add README.md
   git commit -m "docs: update readme"
   git push origin dev
   # Expected: NO mobile build triggered
   ```

2. **Test mobile code push**:
   ```bash
   # Make a mobile change
   echo "// test" >> apps/mobile/src/App.tsx
   git add apps/mobile/src/App.tsx
   git commit -m "fix: mobile app update"
   git push origin dev
   # Expected: Mobile build IS triggered
   ```

3. **Test PR behavior**:
   ```bash
   # Create PR with mobile changes
   gt create --all -m "feat: mobile updates"
   gt submit
   # Expected: Tests run, but NO mobile build
   ```

## Cost Savings
- Eliminates unnecessary mobile builds for non-mobile commits
- Saves ~43 minutes and ~$4 per avoided build
- More predictable CI/CD behavior

## Edge Cases Handled
- First commit on new branch (HEAD~1 might not exist) - handled by fetch-depth: 2
- Force pushes - will compare to the new HEAD~1
- Merge commits - uses first parent for comparison

## Related Documentation
- [Smart Build Triggering](./smart-build-triggering.md)
- [Build Metrics Dashboard](./build-metrics-dashboard.md)