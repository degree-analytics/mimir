# Branch Synchronization Strategy

## 🎯 **Problem Solved**

This document addresses the **branch divergence issue** where `main` and `dev` branches drift apart over time, causing massive merge conflicts (like the 237-commit divergence we just resolved).

## 🔄 **Automated Solution (Primary)**

### GitHub Action: `sync-dev-main.yml`

**Trigger**: Automatically runs after every push to `main` branch (i.e., after PR merges)

**What it does**:
1. ✅ Detects when code is merged to `main`
2. ✅ Installs `just` command runner
3. ✅ Calls `just gh-branch-sync auto` for automated sync
4. ✅ Verifies sync completed with `just gh-branch-sync verify`
5. ✅ All logic centralized in justfile (no duplication)

**Benefits**:
- 🚫 **No human error** - runs automatically
- 🚫 **No forgotten syncs** - triggers on every main push
- ✅ **Clean merge history** - proper merge commits with context
- ✅ **Immediate sync** - happens within minutes of PR merge

**Monitoring**:
```bash
# Check if GitHub Action is working
gh run list --workflow="sync-dev-main.yml" --limit=5

# Verify branches are in sync
git fetch origin main dev
git log --oneline --graph main..dev  # Should show minimal diff
```

## 🛠️ **Manual Backup Process**

**Use when**: GitHub Action fails, or for immediate manual sync

### Step-by-Step Process
```bash
# 1. Switch to main and get latest
git checkout main
git pull origin main

# 2. Switch to dev and merge main
git checkout dev
git pull origin dev  # Get latest dev changes first

# 3. Merge main into dev
git merge main --no-ff -m "chore: manual sync dev with main

Syncing dev branch with latest main changes.
Manual sync performed on $(date).

🤖 Generated with [Claude Code](https://claude.ai/code)"

# 4. Push updated dev
git push origin dev

# 5. Verify sync
git log --oneline --graph main..dev  # Should be minimal
```

### Quick Verification Commands
```bash
# Check if branches are diverged
just git-status-dev-main  # (custom command - see justfile)

# OR manual check
git fetch origin main dev
git rev-list --count origin/main..origin/dev  # Should be low
git rev-list --count origin/dev..origin/main  # Should be 0
```

## 📋 **Integration with Existing Workflows**

### 1. Update PR Template
Add to `.github/pull_request_template.md`:
```markdown
## Post-Merge Checklist
- [ ] GitHub Action will auto-sync dev with main
- [ ] Monitor sync action: `gh run list --workflow="sync-dev-main.yml"`
- [ ] If action fails, perform manual sync: `just gh-branch-sync manual`
```

### 2. Justfile Commands
Add to `justfile`:
```bash
# Check branch sync status
git-status-dev-main:
    @echo "🔍 Checking branch synchronization status..."
    @git fetch origin main dev
    @echo "📊 Commits in dev not in main: $(git rev-list --count origin/main..origin/dev)"
    @echo "📊 Commits in main not in dev: $(git rev-list --count origin/dev..origin/main)"
    @if [ "$(git rev-list --count origin/dev..origin/main)" -gt "0" ]; then \
        echo "⚠️  DIVERGENCE DETECTED - main has commits not in dev"; \
    else \
        echo "✅ Branches are synchronized"; \
    fi

# Manual branch sync (backup)
branch-sync-manual:
    @echo "🔄 Performing manual dev↔main sync..."
    git checkout main && git pull origin main
    git checkout dev && git pull origin dev
    git merge main --no-ff -m "chore: manual sync dev with main"
    git push origin dev
    @echo "✅ Manual sync completed"
```

### 3. Weekly Health Check
```bash
# Add to weekly maintenance routine
just git-status-dev-main
```

## 🚨 **Emergency Procedures**

### If GitHub Action Fails
1. Check action logs: `gh run list --workflow="sync-dev-main.yml"`
2. Run manual sync: `just gh-branch-sync manual`
3. Fix action if needed and re-enable

### If Large Divergence Detected
```bash
# If branches drift apart significantly (>20 commits)
# 1. Assess the situation
git fetch origin main dev
git log --oneline origin/dev..origin/main  # See what main has
git log --oneline origin/main..origin/dev  # See what dev has

# 2. If safe to merge (no conflicts expected)
just gh-branch-sync manual

# 3. If conflicts expected, use conflict resolution process
# (follow the same process we used for PR #363)
```

## 📊 **Success Metrics**

**Goal**: Keep branch divergence under control
- ✅ **Target**: `main..dev` commits < 5 at any time  
- ✅ **Target**: `dev..main` commits = 0 always
- ✅ **Target**: GitHub Action success rate > 95%
- ✅ **Target**: No manual interventions needed

**Monitoring Commands**:
```bash
# Daily check
just git-status-dev-main

# Weekly detailed check  
git log --oneline --graph --decorate origin/main origin/dev | head -20
```

## 🎯 **Prevention Strategy Summary**

1. **Automated sync** prevents 99% of divergence issues
2. **Manual backup** handles edge cases and emergencies
3. **Regular monitoring** catches issues early
4. **Clear documentation** ensures team knows the process

**The key insight**: We need **bidirectional flow** - not just dev→main PRs, but automatic main→dev syncing after every merge.

---

**Result**: No more 237-commit divergences. Clean, manageable branch history. Happy developers. 🎉