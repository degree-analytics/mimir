# Codex Review Workflows

SpaceWalker uses Codex for an additional AI review pass focused on summary + inline comments.

What it does
- Posts a PR summary comment and inline review comments anchored to the diff
- Responds to PR comment triggers; no automatic runs
- Complements Claude by adding a second AI perspective

Usage
- Comment on the PR:
```
@codex review
/codex review
```

Secrets and configuration
- Required secret: OPENAI_API_KEY
- Workflow: .github/workflows/codex-review.yml
- Action: gersmann/codex-review-action@v1 (mode: review)
- Model: defaults to gpt-4.1 (settable in the workflow if needed)

Outputs
- One PR summary comment
- Inline review comments per finding
- Sticky status (added by our wrapper) with model and run link

Notes
- Token/cost metrics are not exposed by this action; we only display model and run link in the sticky status
- For autonomous edits (opt-in), the action supports @codex edit: … in mode: act; we run review-only by default

Best practices
- Use Codex when you want a second, independent analysis alongside Claude
- Prefer Claude for category-specific targeted reviews and cost/token metrics
