# Automated GT Worktree Troubleshooting Guide

## 🚨 Quick Diagnosis

**Having issues with the automated GT worktree workflow?** Use this decision tree to quickly identify the problem:

```
❌ Issue Category?
├─ 🌿 Worktree Creation Fails → [Worktree Creation Issues](#worktree-creation-issues)
├─ ⚡ GT Branch Problems → [GT Integration Issues](#gt-integration-issues)  
├─ 📋 Task Master Issues → [Task Master Problems](#task-master-problems)
├─ 🔗 Symlink/Config Issues → [Configuration Problems](#configuration-problems)
└─ 🧹 Cleanup/Removal Issues → [Cleanup Problems](#cleanup-problems)
```

## 🌿 Worktree Creation Issues

### ❌ Error: "Dev branch does not exist"

**Problem:** The script tries to create worktree from `dev` branch but it doesn't exist.

**Symptoms:**
```bash
just worktree create my-feature
# ❌ ERROR: Dev branch does not exist
# Hint: Create dev branch first or check repository setup
```

**Solutions:**
```bash
# Option 1: Create dev branch from main
git checkout main
git checkout -b dev
git push -u origin dev

# Option 2: Use existing branch instead
# Modify scripts/worktree/create-feature-worktree.sh line 173:
# Change: git worktree add -b "$temp_branch" "$worktree_path" dev
# To:     git worktree add -b "$temp_branch" "$worktree_path" main

# Option 3: Sync dev branch if it exists remotely
git fetch origin
git checkout -b dev origin/dev
```

### ❌ Error: "Worktree already exists"

**Problem:** Attempting to create a worktree that already exists.

**Symptoms:**
```bash
just worktree create payment-system
# ❌ ERROR: Worktree already exists: .worktrees/payment-system
# Hint: Switch to existing worktree with: cd .worktrees/payment-system
```

**Solutions:**
```bash
# Option 1: Use existing worktree
cd .worktrees/payment-system

# Option 2: Clean up old worktree first
just worktree cleanup payment-system
just worktree create payment-system

# Option 3: Use different feature name
just worktree create payment-system-v2
```

### ❌ Error: "Branch already exists"

**Problem:** The `worktree/<name>` branch already exists, preventing worktree creation.

**Symptoms:**
```bash
just worktree create my-feature
# ❌ ERROR: Branch already exists
# Context: Cannot create worktree because branch 'worktree/my-feature' already exists
```

**Common Causes:**
1. Previous incomplete cleanup left orphaned branch
2. Another worktree is using this branch
3. Manual branch creation with conflicting name

**Solutions:**

**If branch is checked out in another worktree:**
```bash
# Error message will show location like:
# ℹ️  This branch is currently checked out at: /path/to/.worktrees/my-feature

# Option 1: Clean up the existing worktree
just worktree cleanup my-feature

# Option 2: Use a different feature name
just worktree create my-feature-v2
```

**If branch exists but not in a worktree:**
```bash
# Option 1: Investigate what's on the branch
git log worktree/my-feature --oneline -5

# Option 2: Delete if it's safe (CAUTION: check for uncommitted work first)
git branch -D worktree/my-feature

# Option 3: Use a different feature name
just worktree create my-new-feature
```

### ❌ Error: "Failed to create Git worktree"

**Problem:** Git worktree creation fails for other reasons.

**Common Causes & Solutions:**

**Repository state issues:**
```bash
# Check repository status
git status

# Ensure dev branch exists
git show-ref --verify refs/heads/dev

# Try worktree creation again
just worktree create my-feature
```

**Permission issues:**
```bash
# Check directory permissions
ls -la .worktrees/

# Fix permissions if needed
chmod 755 .worktrees/
sudo chown -R $USER:$USER .worktrees/
```

**Repository corruption:**
```bash
# Check repository integrity
git fsck

# Clean up repository
git gc --prune=now

# Try again
just worktree create my-feature
```

### ❌ Error: "Feature name contains invalid characters"

**Problem:** Feature name violates naming conventions.

**Invalid Examples:**
```bash
just worktree create "payment system"     # ❌ Contains spaces
just worktree create payment@system       # ❌ Invalid characters
just worktree create ""                   # ❌ Empty name
```

**Valid Examples:**
```bash
just worktree create payment-system       # ✅ kebab-case
just worktree create payment_system       # ✅ snake_case  
just worktree create PaymentSystem        # ✅ PascalCase
```

## ⚡ GT Integration Issues

### ❌ Error: "GT branch creation had issues"

**Problem:** The automated GT branch creation encounters problems.

**Symptoms:**
```bash
just worktree create my-feature
# ✅ Created Git worktree: .worktrees/my-feature
# ⚠️  GT branch creation had issues (likely empty commit warning)
# Note: You may need to run 'gt create' manually
```

**Root Causes & Solutions:**

**GT not installed:**
```bash
# Check GT installation
gt --version

# Install if missing (macOS)
brew install graphite-cli

# Install if missing (npm)
npm install -g @gitstart/graphite-cli

# Initialize GT in repository if needed
gt auth
gt repo init
```

**GT not initialized in repository:**
```bash
# Initialize GT tracking
cd .worktrees/my-feature
gt repo init

# Create GT branch manually
gt create my-feature -m "feat: initial feature setup"
```

**Permission or authentication issues:**
```bash
# Check GT auth status
gt auth status

# Re-authenticate if needed
gt auth

# Try manual GT branch creation
cd .worktrees/my-feature
gt create my-feature -m "feat: manual feature branch"
```

### ❌ Error: "GT create fails with empty commit"

**Problem:** GT can't create branch with no changes.

**Solution:**
```bash
cd .worktrees/my-feature

# Option 1: Create with --allow-empty flag
gt create my-feature --allow-empty -m "feat: initial feature branch"

# Option 2: Make a small change first
echo "# My Feature" > README-feature.md
git add README-feature.md
gt create my-feature -m "feat: add initial feature documentation"

# Option 3: Use the `draft` approach (automated workflow)
# This is already handled by the script, but if manual:
touch .feature-marker
git add .feature-marker
gt create my-feature -m "draft: my-feature"
```

### ❌ Error: "GT submit fails or hangs"

**Problem:** Cannot create PR via GT submit command.

**Diagnostics:**
```bash
# Check GT status
gt status

# Check branch tracking
gt log --stack

# Check GitHub authentication
gh auth status
```

**Solutions:**
```bash
# Fix GitHub authentication
gh auth login

# Re-initialize GT repo connection
gt repo init

# Set proper remote (if needed)
git remote -v
git remote set-url origin https://github.com/your-org/spacewalker.git

# Try manual PR creation
gh pr create --title "feat: my feature" --body "Description"
```

## 📋 Task Master Problems

### ❌ Error: "Task Master commands not found"

**Problem:** Task Master CLI not installed or not in PATH.

**Symptoms:**
```bash
task-master --version
# command not found: task-master
```

**Solutions:**
```bash
# Install Task Master CLI globally
npm install -g task-master-ai

# Verify installation
task-master --version

# If still not found, check PATH
echo $PATH
# Ensure npm global bin directory is in PATH

# Alternative: Use npx
npx task-master-ai --version
```

### ❌ Error: "No tasks.json found"

**Problem:** Task Master can't find the tasks file in worktree.

**Symptoms:**
```bash
cd .worktrees/my-feature
task-master list
# ERROR: No tasks.json found in .taskmaster/tasks/
```

**Solutions:**
```bash
# Check file structure
ls -la .taskmaster/

# Recreate minimal tasks.json if missing
mkdir -p .taskmaster/tasks/
echo '{"master": {"tasks": []}}' > .taskmaster/tasks/tasks.json

# Or reinitialize Task Master
task-master init

# Check symlinks are working
ls -la .taskmaster/config.json
# Should show: config.json -> ../../.taskmaster/config.json
```

### ❌ Error: "Config.json symlink broken"

**Problem:** Symlinked configuration files are broken or missing.

**Symptoms:**
```bash
ls -la .taskmaster/config.json
# config.json -> ../../.taskmaster/config.json (broken)
```

**Solutions:**
```bash
# Recreate symlinks manually
cd .worktrees/my-feature/.taskmaster/

# Remove broken symlinks
rm -f config.json CLAUDE.md templates

# Create new symlinks (relative paths)
ln -sf ../../.taskmaster/config.json config.json
ln -sf ../../.taskmaster/CLAUDE.md CLAUDE.md
ln -sf ../../.taskmaster/templates templates

# Verify symlinks work
ls -la config.json
cat config.json | head -5
```

### ❌ Error: "API key not configured"

**Problem:** Task Master can't authenticate with AI services.

**Solutions:**
```bash
# Check environment variables
env | grep -E "(ANTHROPIC|OPENAI|PERPLEXITY)_API_KEY"

# Set missing API keys
export ANTHROPIC_API_KEY="your-key-here"
export PERPLEXITY_API_KEY="your-key-here"

# Or configure Task Master models
task-master models --setup

# Check configuration
cat .taskmaster/config.json
```

## 🔗 Configuration Problems

### ❌ Error: "Permission denied on symlink creation"

**Problem:** Script can't create symlinks due to permissions.

**Solutions:**
```bash
# Check directory permissions
ls -la .worktrees/

# Fix ownership if needed
sudo chown -R $USER:$USER .worktrees/

# Check parent .taskmaster directory exists and is accessible
ls -la .taskmaster/
chmod 755 .taskmaster/
chmod 644 .taskmaster/config.json
```

### ❌ Error: "Templates directory not found"

**Problem:** Symlink to templates fails because source doesn't exist.

**Expected Behavior:** This is normal - templates are optional.

**If you need templates:**
```bash
# Create templates directory
mkdir -p .taskmaster/templates/

# Add example templates
cp docs/examples/*.txt .taskmaster/templates/

# Recreate symlinks in worktree
cd .worktrees/my-feature/.taskmaster/
ln -sf ../../.taskmaster/templates templates
```

### ❌ Error: "CLAUDE.md not found"

**Problem:** CLAUDE.md file missing from main repository.

**Solutions:**
```bash
# Check if CLAUDE.md exists in main repo
ls -la CLAUDE.md
ls -la .taskmaster/CLAUDE.md

# If missing, create minimal CLAUDE.md
touch CLAUDE.md
# OR copy from .taskmaster/
cp .taskmaster/CLAUDE.md ./

# Recreate symlink in worktree
cd .worktrees/my-feature/.taskmaster/
ln -sf ../../CLAUDE.md CLAUDE.md
```

## 🧹 Cleanup Problems

### ❌ Error: "Cleanup fails - directory not found"

**Problem:** Worktree directory already removed but Git references remain.

**Symptoms:**
```bash
just worktree cleanup my-feature
# ❌ ERROR: Worktree directory not found: .worktrees/my-feature
# But git worktree list still shows the worktree
```

**Solutions:**
```bash
# Clean up Git worktree references
git worktree prune

# Remove any remaining references manually
git worktree list
git worktree remove my-feature --force

# Clean up any remaining directories
rm -rf .worktrees/my-feature
```

### ❌ Error: "GT branch cleanup fails"

**Problem:** Cannot remove GT branch after worktree cleanup.

**Solutions:**
```bash
# Check GT status
gt status
gt log --stack

# Clean up GT branch manually
gt branch delete my-feature

# If branch is remote, clean up remote reference
git push origin --delete my-feature

# Clean up any orphaned GT metadata
gt cleanup
```

### ❌ Error: "Worktree has uncommitted changes"

**Problem:** Cannot clean up worktree with uncommitted work.

**Solutions:**
```bash
cd .worktrees/my-feature

# Option 1: Commit the changes
git add -A
git commit -m "draft: save work before cleanup"
gt submit  # If ready for PR

# Option 2: Stash the changes
git stash push -m "Work saved before cleanup"

# Option 3: Force cleanup (loses changes)
cd ../..
rm -rf .worktrees/my-feature
git worktree prune
```

## 🔧 Advanced Troubleshooting

### Diagnostic Commands

**Check system health:**
```bash
# Verify all tools are installed
gt --version
task-master --version
git --version
just --version

# Check repository state
git status
git branch -a
git worktree list

# Check worktree script permissions
ls -la scripts/worktree/
```

**Debug worktree creation step-by-step:**
```bash
# Enable script debugging
bash -x scripts/worktree/create-feature-worktree.sh my-feature

# Check each step manually
git worktree add -b temp-branch .worktrees/my-feature dev
cd .worktrees/my-feature
gt create my-feature -m "draft: my-feature"
```

**Check Task Master integration:**
```bash
cd .worktrees/my-feature

# Verify Task Master setup
ls -la .taskmaster/
cat .taskmaster/tasks/tasks.json
cat .taskmaster/state.json

# Test Task Master functionality
task-master list
task-master models
```

### Recovery Procedures

**Complete worktree reset:**
```bash
# Remove all worktrees
rm -rf .worktrees/
git worktree prune

# Remove GT references
gt repo deinit
gt repo init

# Start fresh
just worktree create my-feature
```

**Repository health check:**
```bash
# Verify repository integrity
git fsck --full

# Clean up repository
git gc --aggressive --prune=now

# Reset any corrupted references
git remote prune origin
git fetch --all --prune
```

**Task Master reset:**
```bash
# Backup current tasks
cp -r .taskmaster/ .taskmaster-backup/

# Reinitialize Task Master
rm -rf .taskmaster/tasks/
task-master init

# Restore configuration
cp .taskmaster-backup/config.json .taskmaster/
```

## 🚨 Emergency Procedures

### Complete System Recovery

If the entire automated workflow is broken:

```bash
# 1. Save any important work
git stash --all
git stash list

# 2. Clean up all worktrees
rm -rf .worktrees/
git worktree prune

# 3. Reset GT state
gt repo deinit
gt repo init

# 4. Reinitialize Task Master
cp .taskmaster/config.json /tmp/tm-config-backup.json
task-master init
cp /tmp/tm-config-backup.json .taskmaster/config.json

# 5. Test with simple worktree
just worktree create test-recovery

# 6. If successful, restore stashed work
git stash pop
```

### Script Permission Reset

If script permissions are corrupted:

```bash
# Fix all script permissions
find scripts/ -name "*.sh" -exec chmod +x {} \;

# Verify justfile can execute scripts
just worktree help

# Test script execution directly
bash scripts/worktree/create-feature-worktree.sh test-permissions
```

## 📞 Getting Help

### Internal Resources
- **Documentation**: `automated-gt-worktree-workflow.md` (in same directory)
- **Script Source**: `scripts/worktree/` directory
- **Justfile Commands**: `just help | grep worktree`
- **CLAUDE.md**: Project-specific context and patterns

### External Resources
- **Graphite Docs**: https://graphite.dev/docs
- **Task Master**: https://github.com/josh-paul-king/task-master-ai
- **Git Worktrees**: https://git-scm.com/docs/git-worktree

### Debugging Tips

**Enable verbose output:**
```bash
# For script debugging
bash -x scripts/worktree/create-feature-worktree.sh my-feature

# For GT debugging
gt --debug status
gt --debug submit

# For Task Master debugging
task-master --debug list
```

**Collect diagnostic information:**
```bash
# System info
uname -a
git --version
gt --version
task-master --version

# Repository state
git status
git worktree list
git branch -a

# Worktree status
just worktree list
ls -la .worktrees/
```

## 📊 Understanding Worktree Status Output

### Branch Status Indicators

When running `just worktree list`, the branch status is shown with these indicators:

- **🔄** - Temporary branch (`worktree/<name>`)
  - **Meaning:** Worktree is ready for GT branch creation
  - **Action:** Run `gt create <branch-name> -m "message"` when ready to commit

- **⚡** - GT feature branch
  - **Meaning:** Normal development state, GT branch has been created
  - **Action:** Continue normal development with `gt modify` commands

- **❓** - Unknown branch type
  - **Meaning:** Branch doesn't match expected patterns
  - **Action:** Investigate with `git status` and `gt status`

### Example Output Interpretation

```
🌿 my-feature │ 🔄 worktree/my-feature @ abc1234 │ 📋 3/8 tasks
              ↑                         ↑
              Ready for GT branch       Commit hash
```

This shows:
- Worktree "my-feature" exists
- Currently on temporary branch (🔄)
- At commit abc1234
- Has 3 of 8 tasks complete

---

*This troubleshooting guide covers the most common issues with the automated GT worktree workflow. Keep it updated as new issues are discovered and resolved.*