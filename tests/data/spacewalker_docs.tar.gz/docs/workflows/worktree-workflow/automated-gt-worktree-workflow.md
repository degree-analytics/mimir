# Automated GT Worktree Workflow

## 🚀 Overview

The Automated GT Worktree Workflow combines Git worktrees, Graphite (GT), and Task Master AI to create isolated feature development environments with zero context switching overhead. This workflow uses temporary tracking branches (`worktree/<name>`) that integrate seamlessly with GT's stacking workflow, providing immediate GT compatibility while maintaining clean branch organization.

## 🎯 Key Benefits

- **Zero Context Switching**: Each feature gets its own complete workspace
- **Clean GT Integration**: GT branches created when you're ready to commit
- **Task Master Integration**: Each worktree gets isolated task tracking
- **GT-Ready Branches**: Creates tracking branches that work immediately with GT commands
- **Simplified Cleanup**: One command removes worktree and all associated data

## 🏗️ Architecture

```
spacewalker/                    # Main repository
├── .worktrees/                # Feature workspaces
│   ├── payment-system/        # Feature 1 worktree
│   │   ├── .taskmaster/       # Isolated task tracking
│   │   └── ... (full codebase)
│   └── user-auth/             # Feature 2 worktree
│       ├── .taskmaster/       # Independent task tracking  
│       └── ... (full codebase)
├── .taskmaster/               # Main project tasks
└── scripts/worktree/          # Workflow scripts
```

## 🛠️ Commands Reference

### Core Commands

```bash
# Create new feature worktree with automated GT branch
just worktree create <feature-name>

# List all active worktrees with detailed status
just worktree list

# Clean up completed worktree
just worktree cleanup <feature-name>

# Show GT integration status across all worktrees
just worktree gt status
```

### Feature Name Formats

Supported naming conventions:
- `kebab-case`: `payment-integration`
- `snake_case`: `user_authentication` 
- `PascalCase`: `GraphQLMigration`

## 📋 Step-by-Step Workflow

### 1. Create Feature Worktree

```bash
# Create new feature environment
just worktree create payment-integration
```

**What happens automatically:**
- ✅ Git worktree created from `dev` branch with GT-tracked branch `worktree-<feature-name>`
- ✅ Graphite (GT) tracking configured with `gt branch track --parent dev`
- ✅ Clean workspace ready for development with GT integration from the start
- ✅ Task Master environment set up with isolated tracking
- ✅ Symlinks created to shared configuration
- ✅ CI/CD-managed files marked with `--skip-worktree` (version.ts files)
- ✅ GT commands work immediately (`gt modify`, `gt create`, `gt submit`)

### 2. Navigate to Worktree

```bash
# Change to the new feature workspace
cd .worktrees/payment-integration
```

### 3. Define Feature Requirements

```bash
# Create Product Requirements Document
vim .taskmaster/docs/prd.txt
```

**Example PRD structure:**
```markdown
# Payment Integration Feature

## Overview
Implement Stripe payment processing for subscription billing.

## Requirements
1. Payment form with credit card validation
2. Stripe webhook handling for payment events
3. Subscription management dashboard
4. Failed payment retry logic

## Acceptance Criteria
- All payments processed through Stripe
- PCI compliance maintained
- Error handling covers all edge cases
- Unit tests achieve 90%+ coverage
```

### 4. Generate and Organize Tasks

```bash
# Parse PRD into actionable tasks
task-master parse-prd .taskmaster/docs/prd.txt

# Break down complex tasks into subtasks
task-master expand --all --research

# Start working on first task
task-master next
```

### 5. Develop with GT Integration

```bash
# Make your changes
# ... code development ...

# Create GT branch with your first commit (from tracking branch)
gt create -am "feat(payments): implement Stripe payment processing

- Add payment form with validation
- Integrate Stripe Elements for secure card input
- Handle payment confirmation and errors
- Update subscription status on successful payment"

# Continue iterating
# ... more development ...

# Update commit as you progress
gt modify -am "feat(payments): add webhook handling and retry logic"
```

### 6. Set PR Metadata and Submit

```bash
# Set proper PR title and description (separate from commit)
just git-info pr-title "feat: Stripe payment integration with webhook support"
just git-info pr-desc "Implements complete payment processing workflow with Stripe integration, webhook handling, and automated retry logic for failed payments."

# Submit PR to dev branch
gt submit
```

### 7. Clean Up When Complete

```bash
# Return to main workspace
cd ../../

# Clean up completed feature worktree
just worktree cleanup payment-integration
```

## 🔄 Automated GT Workflow Details

### Tracking Branch Workflow

The automated workflow uses temporary tracking branches for immediate GT integration:

```bash
# Initial state after worktree creation (tracking branch)
git status
# On branch worktree/payment-integration

# Create GT branch with your first commit
gt create -am "feat: implement payment form"
git log --oneline  
# def5678 feat: implement payment form

# GT creates a properly named branch from your tracking branch
```

### Benefits of Tracking Branch Approach

1. **Immediate GT Compatibility**: GT commands work right away without special setup
2. **Clean Namespace**: `worktree/` prefix keeps temporary branches organized
3. **Automatic Cleanup**: Cleanup script removes both worktree and tracking branch
4. **Better Error Recovery**: Named branches easier to debug and manage
5. **Performance Optimized**: Uses `just install` for 60%+ faster setup

### Safety Features

The worktree creation script includes several safety mechanisms:

1. **Branch Collision Detection**: Never deletes existing branches
   - Checks if `worktree/<name>` branch already exists
   - Provides clear error messages with resolution steps
   - Shows where conflicting branches are checked out

2. **Non-Destructive Creation**: Create operations are read-only until actual creation
   - No branch deletion attempts
   - No force operations
   - Preserves any existing work

3. **Clear Error Reporting**: Specific messages for each failure scenario
   - Branch conflicts show exact location
   - Suggests appropriate resolution steps
   - No misleading generic errors

### GT Branch Management

**Automatic GT Setup (New in Latest Version):**

When creating a worktree, GT integration is now automatic:
1. Branch is created with pattern `worktree-<feature-name>` (no slash for GT compatibility)
2. GT tracking is immediately configured with `gt branch track --parent dev`
3. Upstream is set to `dev` for better integration
4. You can use GT commands immediately without manual setup

```bash
# View GT stack from within worktree
gt log --stack

# Check branch tracking status
gt branch info

# Start committing immediately (no manual GT setup needed!)
gt modify -am "feat: my changes"

# Create stacked branches as needed
gt create -am "feat: new feature layer"

# Check integration status across all worktrees
just worktree gt status

# Submit PR when ready
gt submit

# Manually clean up orphaned GT branches if needed
just worktree gt cleanup
```

**GT Integration Benefits:**
- ✨ **Zero manual setup**: GT tracking configured automatically
- 🚀 **Immediate productivity**: Start using `gt modify` right away
- 🔗 **Proper parent tracking**: Dev branch set as parent automatically
- 📊 **Stack visualization**: Full GT stack features available
- 🧹 **Clean branch names**: Uses `worktree-<name>` pattern for GT compatibility

### Branch Pollution Mitigation

The tracking branch approach creates temporary `worktree/<name>` branches, but includes several strategies to minimize branch pollution:

1. **Namespace Isolation**: All worktree branches use the `worktree/` prefix, keeping them separate from feature branches
2. **Automatic Cleanup**: The `just worktree cleanup` command removes both the worktree directory and its tracking branch
3. **GT Branch Migration**: Once you create a GT branch with `gt create`, work continues on the properly named GT branch
4. **Regular Pruning**: Run `git branch -d worktree/*` periodically to remove any orphaned tracking branches
5. **CI/CD Filtering**: CI systems can ignore `worktree/*` branches to avoid unnecessary builds

The tracking branch approach improves GT integration reliability and provides better error recovery during development. The benefits of immediate GT compatibility and easier debugging make this the optimal workflow pattern.

## 📊 Monitoring and Status

### Worktree Status Dashboard

```bash
# Detailed view of all worktrees
just worktree list
```

**Example output:**
```
📋 Feature Worktrees Status
═══════════════════════════════════════════════════════════════════════════

🌿 payment-integration        │ ⚡ payment-integration @ def5678 │ 📋 3/8 tasks
💾 127.3 MB                   │ 🕒 2 hours ago                  │ 📄 PRD exists

🌿 user-auth                  │ 🔄 worktree/user-auth @ abc1234 │ 📋 7/12 tasks  
💾 98.7 MB                    │ 🕒 1 day ago                    │ 📄 PRD exists

💾 Total disk usage: 226.0 MB across 2 worktrees
```

**Branch Status Indicators:**
- **🔄** - Temporary branch (`worktree/<name>`) - ready for GT branch creation
- **⚡** - GT feature branch created - normal development state
- **❓** - Unknown branch type - shouldn't occur with current workflow

### Summary View

```bash
# Condensed overview
just worktree list --summary
```

## 🎯 Best Practices

### Feature Development

1. **Start with PRD**: Always define requirements before coding
2. **Task-Driven Development**: Use Task Master to break down work
3. **Regular Updates**: Update commit messages as features evolve
4. **Clean Commits**: Create meaningful commit messages from the start
5. **Isolated Testing**: Run tests within each worktree environment

### Branch Management

1. **One Feature Per Worktree**: Keep features isolated
2. **Meaningful Commit Messages**: Use conventional commit format
3. **PR Metadata**: Set title/description separately from commits
4. **Clean History**: Squash or rewrite commits before final submission

### Task Master Integration

1. **Feature-Scoped Tasks**: Tasks stay within their worktree
2. **Shared Templates**: Use symlinked templates for consistency
3. **Regular Status Updates**: Use `task-master update-subtask` for progress
4. **Completion Tracking**: Mark tasks done as features are completed

## 🔒 CI/CD Managed Files

When working in worktrees, certain files are automatically protected from local changes to prevent conflicts with CI/CD processes:

### Protected Files

The following files are marked with `git update-index --skip-worktree`:
- `apps/admin/src/version.ts` - Admin application version metadata
- `apps/mobile/src/version.ts` - Mobile application version metadata

### Why Skip-Worktree?

These files are:
- **Generated by CI/CD**: Contains build timestamps, git commit hashes, and version info
- **Updated automatically**: Modified during the build and deployment pipeline
- **Test-sensitive**: Local changes can cause integration test failures
- **Branch-agnostic**: Should reflect CI/CD state, not local development

### Managing Skip-Worktree Files

```bash
# View files with skip-worktree flag
git ls-files -v | grep "^S"

# Manually set skip-worktree (already done automatically)
git update-index --skip-worktree apps/admin/src/version.ts

# Remove skip-worktree if needed (not recommended)
git update-index --no-skip-worktree apps/admin/src/version.ts
```

### Impact on Development

- **No impact on normal workflow**: Files appear unchanged even if modified
- **Test stability**: Prevents `GIT_COMMIT = "unknown"` test failures
- **Clean git status**: Won't show as modified in `git status`
- **PR safety**: Won't accidentally commit local version changes

## 🧹 Container Management Across Worktrees

When working with multiple worktrees, Docker containers can run in any of them. Use these commands to manage containers:

```bash
# Stop containers in current directory only
just down

# Stop ALL containers across main repo and all worktrees (idempotent)
just down everywhere

# Stop containers with sequential output (for debugging)
just down everywhere --sequential
```

The `just down everywhere` command:
- **Idempotent**: Safe to run multiple times
- **Complete cleanup**: Removes stopped containers, networks, and volumes
- **Parallel execution**: Stops containers in all locations simultaneously by default
- **Works with crashed containers**: Cleans up even if containers aren't running

## 🔧 Troubleshooting

### Common Issues

#### Worktree Creation Fails

**Branch Already Exists Error:**
If you see "Branch already exists" error, the script detected a collision with an existing `worktree/<name>` branch. This is a safety feature to prevent accidental data loss.

Resolution options:
1. **Check for existing worktree**: The error message will show if the branch is checked out elsewhere
2. **Choose different name**: `just worktree create <different-name>`
3. **Clean up if orphaned**: If from incomplete cleanup, manually delete with `git branch -D worktree/<name>`
4. **Investigate branch**: Check what's on it with `git log worktree/<name> --oneline -5`

**Other Creation Issues:**
```bash
# Check if dev branch exists
git show-ref --verify refs/heads/dev

# Verify no existing worktree with same name
just worktree list

# Check for orphaned worktree branches
git branch | grep "worktree/"
```

#### GT Branch Creation Issues
```bash
# Check GT status
gt status

# Manually create GT branch if needed
cd .worktrees/<feature-name>
gt create <branch-name> -m "feat: manual GT branch creation"
```

#### Task Master Setup Problems
```bash
# Verify Task Master CLI is installed
task-master --version

# Check configuration
cat .taskmaster/config.json

# Reinitialize if needed
task-master init
```

### Recovery Procedures

#### Clean Up Failed Worktree Creation
```bash
# Remove partial worktree directory
rm -rf .worktrees/<feature-name>

# Clean up Git references
git worktree prune

# Try creation again
just worktree create <feature-name>
```

#### Fix Broken Symlinks
```bash
cd .worktrees/<feature-name>

# Check symlink status
ls -la .taskmaster/

# Recreate broken symlinks
ln -sf ../../.taskmaster/config.json .taskmaster/config.json
ln -sf ../../.taskmaster/CLAUDE.md .taskmaster/CLAUDE.md
```

## 🚀 Advanced Usage

### Parallel Feature Development

```bash
# Create multiple features simultaneously
just worktree create payment-system
just worktree create user-notifications
just worktree create api-refactoring

# Work on different features in different terminals
cd .worktrees/payment-system     # Terminal 1
cd .worktrees/user-notifications # Terminal 2
cd .worktrees/api-refactoring    # Terminal 3
```

### Integration with CI/CD

The workflow integrates seamlessly with existing CI/CD:
- Each PR comes from a properly named GT branch
- Commit history is clean (meaningful commits from the start)
- Features are developed in isolation
- Testing can run per-feature in isolated environments

### Custom Automation

Extend the workflow by modifying scripts in `scripts/worktree/`:
- Add custom project templates
- Integrate with additional tools
- Customize Task Master setup
- Add feature-specific validations

## 📚 Related Documentation

- Task Master Integration (see `.taskmaster/CLAUDE.md` after running `task-master init` during onboarding - this file is symlinked in worktrees)
- [Graphite Workflows](../graphite-workflows.md)  
- [Git Commit Standards](../git-commit-standards.md)
- [Testing Guide](../testing-guide.md)

## 🤝 Contributing to the Workflow

To improve or extend the workflow:
1. Modify scripts in `scripts/worktree/`
2. Update documentation in `docs/workflows/`
3. Test changes across different feature types
4. Update CLAUDE.md with new patterns
5. Create issues for feature requests or bugs

---

*This workflow represents the evolution of feature development at Spacewalker, combining the best of Git worktrees, Graphite's stacking workflow, and AI-powered task management.*