# Unified Test Commands Guide

## Overview
As part of the justfile consolidation effort (ENG-733), we've replaced 40+ individual test commands with a single unified `test` command that provides consistent testing across all repositories.

## Command Structure

```bash
just test <test_type> <repo> [options]
```

### Parameters

**test_type** (required):
- `unit` - Run unit tests
- `integration` - Run integration tests
- `system` - Run system tests
- `all` - Run all test types

**repo** (required):
- `backend` - Test backend only
- `admin` - Test admin dashboard only
- `mobile` - Test mobile app only
- `all` - Test all repositories

**options** (optional):
- `--pattern=<pattern>` - Run specific tests matching pattern
- `--local` - Run tests locally (admin/mobile)
- `--watch` - Run tests in watch mode
- `--coverage` - Generate coverage report
- `--ci` - Run in CI mode with stricter settings

## Common Examples

### Quick Testing
```bash
# Run all unit tests (fastest)
just test unit all

# Run backend unit tests only
just test unit backend

# Run specific test file
just test unit backend --pattern=test_auth
```

### Development Workflow
```bash
# Watch mode for continuous testing
just test unit admin --watch

# Test with coverage report
just test unit all --coverage

# Local testing for admin/mobile
just test unit admin --local
```

### Comprehensive Testing
```bash
# All tests for all repos
just test all all

# All backend tests (unit + integration + system)
just test all backend

# Integration tests with CI settings
just test integration all --ci
```

## Migration from Old Commands

| Old Command | New Command |
|------------|-------------|
| `just test_unit` | `just test unit all` |
| `just test_unit_backend` | `just test unit backend` |
| `just test_unit_admin` | `just test unit admin` |
| `just test_unit_mobile` | `just test unit mobile` |
| `just test_integration` | `just test integration all` |
| `just test_integration_backend` | `just test integration backend` |
| `just test_system` | `just test system backend` |
| `just test_all` | `just test all all` |
| `just test_quick` | `just test unit all` |
| `just test_backend_case auth` | `just test unit backend --pattern=auth` |
| `just test_watch` | `just test unit all --watch` |

## Implementation Details

The unified test command is powered by `scripts/helpers/test_manager.py` which:
- Detects test type and repository
- Configures appropriate test runners (pytest for backend, npm/jest for admin/mobile)
- Handles all options consistently across repos
- Provides clear output and error messages
- Validates test directories and scripts before running

## Benefits

1. **Consistency**: Single command pattern for all testing needs
2. **Discoverability**: Easier to understand available test options
3. **Maintainability**: One script to maintain instead of 40+ justfile commands
4. **Flexibility**: All options work consistently across repositories
5. **Extensibility**: Easy to add new test types or options in the future

## Related Documentation

- [Testing Guide](./testing-guide.md) - Comprehensive testing strategies
- [Testing Strategy](./testing-strategy.md) - Framework-specific approaches
- [Development Setup](../setup/development-setup.md) - Environment configuration
