# 🚀 Deployment Verification Integration Guide

## Overview

This guide documents how the comprehensive ECS deployment verification system is integrated throughout SpaceWalker's infrastructure. The system ensures all deployments are verified to prevent silent failures and rollbacks.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Deployment Entry Points                   │
├─────────────────────────────────────────────────────────────┤
│  just aws deploy  │  just aws deploy │  GitHub Actions CI   │
└───────────┬───────┴────────┬─────────┴──────────┬──────────┘
            │                │                     │
            ▼                ▼                     ▼
┌─────────────────────────────────────────────────────────────┐
│              deployment_manager.py (Python)                  │
│  - Unified interface for all deployment operations          │
│  - Handles production safety checks                         │
│  - Routes to appropriate deployment scripts                 │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│           force-ecs-deployment.sh (Bash)                     │
│  - Sources deployment-verification.sh                       │
│  - Captures pre-deployment state                           │
│  - Forces ECS deployment                                   │
│  - Waits for stability                                    │
│  - Verifies success (no rollback)                         │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         deployment-verification.sh (Core Logic)              │
│  - capture_current_task_definition()                        │
│  - verify_deployment_success()                              │
│  - Rollback detection algorithms                           │
│  - Exit code management                                    │
└─────────────────────────────────────────────────────────────┘
```

## Integration Points

### 1. Justfile Commands

#### `just aws deploy` / `just aws images`
- **Location**: `justfile` lines 502-504
- **Flow**: Calls `deployment_manager.py` with appropriate action
- **Verification**: Automatic for `deploy` and `images` actions
- **Example**:
  ```bash
  just aws deploy backend dev      # Deploys with verification
  just aws images backend prod     # Forces new images with verification
  ```

#### `just aws deploy` (CI/CD)
- **Location**: `justfile` lines 739-741
- **Flow**: Uses `deployment_manager.py --action deploy`
- **Purpose**: Same deployment logic for CI/CD and interactive use
- **Example**:
  ```bash
  just aws deploy backend dev      # Used by GitHub Actions
  ```

### 2. Python Layer (deployment_manager.py)

#### Key Methods

**`deploy_ecs_service()`** (lines 65-129)
- Enhanced with comprehensive error handling
- Detects rollback patterns in output
- Provides specific error messages for common failures
- Returns boolean for success/failure

**`images()`** (lines 476-507)
- Uses `deploy_ecs_service()` helper
- Ensures verification for force deployments
- Proper exit codes for CI/CD

### 3. Bash Scripts

#### force-ecs-deployment.sh
- **Sources**: `deployment-verification.sh` for core functions
- **Pre-deployment**: Captures current task definition
- **Post-deployment**: Verifies no rollback occurred
- **Exit codes**:
  - 0: Success with verification
  - 1: Deployment failed
  - 2: Rollback detected

#### deployment-verification.sh
- **Core functions**:
  - `capture_current_task_definition()`: Records pre-deployment state
  - `verify_deployment_success()`: Compares revisions, detects rollbacks
- **Rollback detection**: Compares task definition revisions
- **Emergency bypass**: `--skip-verification` flag (use with caution)

### 4. CI/CD Pipeline (.github/workflows/ci-cd.yml)

#### test-deployment-verification Job
- **Purpose**: Runs deployment verification test suite
- **When**: On all PRs and pushes to dev/main
- **Tests**: 
  - Successful deployment scenarios
  - Rollback detection
  - Edge cases
  - CI/CD integration

#### Deployment Steps
All deployment steps in CI now use `just aws deploy` which includes verification:
```yaml
- name: Deploy to Dev
  run: just aws deploy backend dev
  # Exit code 0 = success, non-zero = failure/rollback
```

### 5. Test Suite (scripts/tests/)

#### Test Modules
- `test-deployment-verification.sh`: Main test framework
- `test-successful-deployment.sh`: Success scenarios
- `test-rollback-detection.sh`: Rollback scenarios
- `test-edge-cases.sh`: Error conditions
- `test-ci-cd-integration.sh`: CI/CD specific tests

## Usage Patterns

### Standard Deployment (Interactive)
```bash
# Deploy with automatic verification
just aws deploy backend dev

# Output includes:
# - Pre-deployment task definition capture
# - Deployment progress
# - Post-deployment verification
# - Clear success/failure indication
```

### CI/CD Deployment
```bash
# In GitHub Actions or CI environment
just aws deploy backend dev

# Same verification path as interactive use
# Exit codes indicate success/failure
```

### Force Image Update
```bash
# Force ECS to pull latest images
just aws images backend dev

# Includes full verification
# Detects if deployment rolled back
```

### Emergency Deployment (Skip Verification)
```bash
# ONLY for emergencies - bypasses verification
./scripts/deployment/force-ecs-deployment.sh dev backend --skip-verification

# ⚠️ WARNING: Use only when verification is broken
# Document why verification was skipped
```

## Error Handling

### Common Errors and Detection

1. **Circuit Breaker Rollback**
   - Pattern: Task revision decreases
   - Message: "CIRCUIT BREAKER ROLLBACK DETECTED"
   - Cause: Containers failing health checks

2. **AWS Authentication Issues**
   - Pattern: UnauthorizedException/AccessDenied
   - Message: "AWS Authentication/Permission Error"
   - Fix: Check credentials and IAM permissions

3. **Service Not Found**
   - Pattern: ServiceNotFoundException
   - Message: "Service Not Found"
   - Fix: Verify service name and cluster

4. **Network/Timeout Issues**
   - Pattern: Read timeout/Connection error
   - Message: "Network Connectivity Error"
   - Fix: Check connectivity, retry

## Best Practices

### 1. Always Use Justfile Commands
```bash
# ✅ Correct
just aws deploy backend dev

# ❌ Avoid
./scripts/deployment/force-ecs-deployment.sh dev backend
```

### 2. Monitor Deployment Output
- Watch for verification messages
- Check task definition revision changes
- Note any warning messages

### 3. Handle Failures Appropriately
- If rollback detected, check CloudWatch logs
- Investigate container health check failures
- Fix issues before redeploying

### 4. Production Deployments
```bash
# Enable production mode first
(just prod enable --minutes=30)

# Then deploy with verification
just aws deploy backend prod
```

## Troubleshooting

### Deployment Verification Failed
1. Check CloudWatch logs for container errors
2. Verify health check configuration
3. Ensure new image is compatible
4. Check for environment variable issues

### False Positive Rollback Detection
- Rare but possible with rapid deployments
- Verify actual service state with `just aws status`
- Check ECS console for deployment events

### CI/CD Pipeline Failures
1. Check GitHub Actions logs
2. Verify AWS credentials in CI
3. Ensure correct environment variables
4. Check for region mismatches

## Maintenance

### Adding New Services
1. Update SERVICE_MAPPING in deployment_manager.py
2. Ensure ECS service follows naming convention
3. Test deployment with verification
4. Update documentation

### Modifying Verification Logic
1. Update deployment-verification.sh
2. Test with test-deployment-verification.sh
3. Ensure backward compatibility
4. Update this documentation

## Related Documentation

- [Deployment Guide](deployment-guide.md)
- [Troubleshooting Guide](troubleshooting-guide.md)
- [System Architecture](../architecture/system-architecture.md)
- [CI/CD Pipeline](ci-cd-pipeline.md)