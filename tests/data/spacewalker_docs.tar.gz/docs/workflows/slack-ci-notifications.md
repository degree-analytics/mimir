# Slack CI Notifications Workflow

Automated Slack notifications for Spacewalker GitHub Actions runs. This guide explains how to configure the reusable notification workflows, manage Slack credentials, and keep changelog entries compatible with release announcements.

## Overview
- Posts every push-triggered CI result from `dev` to a designated Slack channel.
- Posts every push-triggered CI result from `main` with the latest release notes appended.
- Uses reusable workflow `.github/workflows/slack-message.yml` to build messages and call Slack via `slackapi/slack-github-action@v2`.
- Trigger workflow `.github/workflows/notify-slack.yml` listens to the existing “CI/CD Pipeline” workflow and exposes a manual `workflow_dispatch` trigger for dry runs.

## Prerequisites
1. **Slack App** (owned by Chad / platform tooling):
   - Create a Slack app in the Spacewalker workspace.
   - Add scopes: `chat:write`, `channels:read` (for posting to public channels; add `groups:read` if using private channels).
   - Install the app to the workspace and invite the bot user to the target channels.
2. **Secrets** (repository or org level):
   - `SLACK_BOT_TOKEN` — Bot token from the Slack app (starts with `xoxb-`).
   - `SLACK_CHANNEL_DEV` — Channel ID (e.g., `C0123456`) for dev notifications.
   - `SLACK_CHANNEL_MAIN` — Channel ID for release notifications.
   - Store via `gh secret set` or the GitHub UI. Never commit tokens or channel IDs in code.
3. **Changelog hygiene**:
   - Latest release should be the first versioned section (`## [x.y.z] - YYYY-MM-DD`) in the file. If an `[Unreleased]` header exists, it can come before it.
   - Entries organized using Keep a Changelog headings (Added/Changed/Fixed/etc.).

## Setup Steps
1. **Add workflow files** (copy/paste into the repo):
   - `.github/workflows/slack-message.yml`
   - `.github/workflows/notify-slack.yml`
2. **Secrets configuration**:
   ```bash
   gh secret set SLACK_BOT_TOKEN --body "$SLACK_BOT_TOKEN"
   gh secret set SLACK_CHANNEL_DEV --body "C0123456"
   gh secret set SLACK_CHANNEL_MAIN --body "C0654321"
   ```
   Replace IDs with real channel IDs (Slack → channel details → “Copy channel ID”).
3. **Manual smoke test**:
   - Run `just slack test-dev` (or `just slack test-main`) to trigger the manual workflow dispatch from your current branch, or
   - In GitHub → Actions → “Notify Slack on CI status” → “Run workflow” and supply branch/status/inputs manually.
   - Verify message format, changelog block (for `main`), and confirm warnings stay clear in workflow logs.
4. **Production verification**:
   - Merge a change into `dev` and `main` to exercise the workflow run trigger.
   - Confirm Slack messages use the correct channel, include run link, repo, actor, and (for main) changelog text.

## Message Format
- Header: `:large_green_circle:` for success, `:red_circle:` for other outcomes, plus branch label.
- Body bullets: commit short SHA with link to run, commit subject, `@actor`, repo name.
- Context block: “View run details” link.
- `main` branch appends “Latest changelog – {version}```<body>```” using the first versioned changelog section.

## Changelog Requirements
To ensure release notes display correctly:
- Keep the newest release section as the first `## [version] - YYYY-MM-DD` entry in the changelog (an optional `[Unreleased]` header may appear above it). The workflow always selects the first versioned block it encounters.
- Use standard subheadings (`### Added`, `### Changed`, `### Fixed`, etc.).
- Avoid trailing whitespace or unclosed code fences.
- If `CHANGELOG.md` is missing or no release section matches the expected pattern, the workflow logs a warning and still posts the Slack message without the changelog block.

## Troubleshooting
| Symptom | Cause | Resolution |
| ------- | ----- | ---------- |
| Warning `Missing SLACK_BOT_TOKEN` | Secret not set | Add `SLACK_BOT_TOKEN`; rerun workflow |
| Warning `No Slack channel configured for branch` | Channel ID secret missing or bot not invited | Set `SLACK_CHANNEL_DEV` / `MAIN`, ensure bot in channel |
| Changelog block missing | Malformed or reordered changelog | Ensure newest release is first versioned section; check for unmatched headings |
| Slack step failure warning | Slack API rejected payload | Inspect step logs for Slack error message; verify token scopes and channel access |

## Future Enhancements (Backlog)
- Optional `<!here>` mentions on failure once teams are ready for alerts.
- Additional branch routing (e.g., `staging`) by extending `notify-slack.yml`.
- Threaded follow-up messages with deployment artifacts.

## Related Documents
- [CI/CD Build Guide](./ci-cd-build-guide.md)
- [GitHub Actions Best Practices](./github-actions-best-practices.md)
- [Documentation Navigation Patterns](../development/documentation-navigation-patterns.md)
- Changelog authoring tips live alongside `/changelog-add` usage in the repo root.
