# GitHub Actions Analysis Guide

A comprehensive guide for using Spacewalker's GitHub Actions analysis tools to debug CI/CD failures, analyze performance, and extract insights from workflow runs.

## Overview

The `just gh-actions` command suite provides a unified interface for analyzing GitHub Actions workflow runs, replacing the need to "bop around the CLI" with scattered `gh` commands. It offers structured data extraction, error analysis, and AI-powered insights.

## Quick Start

```bash
# List recent workflow runs
just gh-actions list

# Analyze a specific run
just gh-actions show 7123456789

# Get AI analysis of a failed run
just gh-actions ai 7123456789 failure_analysis

# Complete analysis with all details
just gh-actions analyze 7123456789
```

## Command Reference

### Listing Workflow Runs

```bash
# List all recent runs
just gh-actions list

# Filter by workflow name
just gh-actions list --workflow "CI/CD Pipeline"

# Limit results
just gh-actions list --limit 10

# Quick status check
just gh-actions status
```

### Analyzing Specific Runs

```bash
# Show run details
just gh-actions show <run_id>

# List all jobs in a run
just gh-actions jobs <run_id>

# Get complete analysis (details + AI + jobs)
just gh-actions analyze <run_id>
```

### Debugging Failed Jobs

```bash
# Extract errors from job logs
just gh-actions errors <job_id>

# View full job logs
just gh-actions logs <job_id>

# AI failure analysis
just gh-actions ai <run_id> failure_analysis
```

### Working with Artifacts

```bash
# List artifacts from a run
just gh-actions artifacts <run_id>

# Download an artifact
just gh-actions download <artifact_id>
```

### AI Analysis Options

```bash
# Run summary (default)
just gh-actions ai <run_id>

# Failure root cause analysis
just gh-actions ai <run_id> failure_analysis

# Performance analysis
just gh-actions ai <run_id> performance

# Test health analysis
just gh-actions ai <run_id> test_analysis
```

## Finding IDs

The GitHub Actions analysis tools use different types of IDs:

1. **Run IDs**:
   - Find with: `just gh-actions list`
   - Example: 7123456789

2. **Job IDs**:
   - Find with: `just gh-actions jobs <run_id>`
   - Example: 20123456789

3. **Artifact IDs**:
   - Find with: `just gh-actions artifacts <run_id>`
   - Example: 500123456

## Common Workflows

### Debugging a CI Failure

```bash
# 1. Find the failed run
just gh-actions list --limit 5

# 2. Get detailed analysis
just gh-actions analyze 7123456789

# 3. If you need to dig deeper into a specific job
just gh-actions jobs 7123456789
# Find the failed job ID, then:
just gh-actions errors 20123456789
```

### Investigating Flaky Tests

```bash
# 1. Look at recent runs for a workflow
just gh-actions list --workflow "CI/CD Pipeline" --limit 20

# 2. Analyze multiple runs to find patterns
just gh-actions ai 7123456789 test_analysis
just gh-actions ai 7123456790 test_analysis
```

### Performance Optimization

```bash
# 1. Analyze run performance
just gh-actions ai 7123456789 performance

# 2. Identify long-running jobs
just gh-actions show 7123456789
# Look for jobs marked as "long running"
```

### Artifact Investigation

```bash
# 1. List artifacts from a run
just gh-actions artifacts 7123456789

# 2. Download specific artifact
just gh-actions download 500123456

# 3. Extract and examine
unzip artifact-500123456.zip
```

## Error Analysis Features

The error extraction system identifies:

- **Critical Errors**: Syntax errors, import failures
- **High Priority**: Test failures, build errors
- **Medium Priority**: Linting issues, warnings
- **Low Priority**: Deprecation warnings

Each error includes:
- Line number and context
- Error type classification
- Severity assessment
- Pattern that matched

## AI Analysis Capabilities

When `ANTHROPIC_API_KEY` is set in `.env`, AI analysis provides:

1. **Executive Summary**: Quick overview of run status
2. **Root Cause Analysis**: Likely causes of failures
3. **Performance Insights**: Bottlenecks and optimization opportunities
4. **Recommendations**: Specific actionable fixes
5. **Pattern Recognition**: Identification of recurring issues

Without an API key, the tool falls back to basic analysis mode with structured summaries.

## Data Export

Export data for further analysis:

```bash
# Export run list
just gh-actions export list

# Export specific run data
just gh-actions export run 7123456789 my-run-data.json
```

## Integration with Other Tools

The actions tools integrate seamlessly with:

- **PR Analysis**: Use alongside `just gh-pr` commands
- **Local Testing**: Verify fixes with `just test`
- **Deployment**: Check pre-deploy with `just gh-actions status`

## Troubleshooting

### Authentication Issues

If you see "You must authenticate via a GitHub App" errors:
- These are non-critical and can be ignored
- They occur when trying to access check runs data
- Core functionality remains unaffected

### No Logs Available

If logs are empty:
- The job may still be running
- The job was skipped or cancelled
- Check job status with `just gh-actions jobs <run_id>`

### AI Analysis Not Working

If AI analysis fails:
1. Check `ANTHROPIC_API_KEY` is set in `.env`
2. Verify the API key is valid
3. Tool will fall back to basic mode automatically

## Best Practices

1. **Start Broad**: Use `just gh-actions list` to get overview
2. **Drill Down**: Use specific commands as needed
3. **Use AI First**: Let AI analysis guide your investigation
4. **Export Complex Data**: Use JSON export for detailed analysis
5. **Check Multiple Runs**: Look for patterns across failures

## Technical Details

The GitHub Actions analysis tools use:
- Parallel API calls for efficiency
- Structured data extraction
- Pattern-based error detection
- Context-aware AI prompts
- Security validation on all inputs

## Related Documentation

- [Troubleshooting Guide](troubleshooting-guide.md) - General debugging tips
- [CI/CD Workflows](ci-cd-workflows.md) - Pipeline configuration
- [Testing Guide](testing-guide.md) - Local test execution
