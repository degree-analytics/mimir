# Spacewalker Troubleshooting Guide

## Purpose
Central resource for debugging and problem resolution - organized by problem category with diagnostic commands and solutions. Complete guide for developers, DevOps engineers, and operations teams solving system issues.

## When to Use This
- Diagnosing system issues and service failures
- Resolving environment setup and configuration problems
- Troubleshooting build, deployment, and infrastructure issues
- Debugging mobile connectivity and development problems
- Solving testing, quality, and performance issues
- Keywords: troubleshooting, debugging, diagnostics, problem resolution, emergency recovery

**Version:** 2.0 (Updated for new documentation structure)
**Date:** 2025-06-29
**Status:** Current - Complete Troubleshooting Hub

---

## 🚨 Quick Diagnostics
**First steps for any problem** - Get immediate system status and identify the issue category

When something goes wrong, start here for **fast diagnosis** to identify which category your problem falls into:

### 🔍 Diagnostic Decision Tree

```mermaid
graph TD
    A[🚨 Problem Detected] --> B[🏥 Run just health]
    B --> C{Services Running?}

    C -->|❌ No| D[🔧 Service Issues]
    C -->|✅ Yes| E[🔍 Run just env_check]

    D --> D1[📱 Mobile not connecting?]
    D --> D2[🐳 Docker issues?]
    D --> D3[🗃️ Database problems?]

    E --> F{Environment OK?}
    F -->|❌ No| G[⚙️ Environment Issues]
    F -->|✅ Yes| H[🧪 Run Tests]

    G --> G1[🔧 Missing dependencies?]
    G --> G2[📁 Wrong directory?]
    G --> G3[🔑 Config problems?]

    H --> I{Tests Pass?}
    I -->|❌ No| J[🧪 Testing Issues]
    I -->|✅ Yes| K[🚀 Deployment Issues]

    D1 --> D1A[📱 Mobile Connectivity]
    D2 --> D2A[🐳 Service Management]
    D3 --> D3A[🗃️ Database Problems]

    G1 --> G1A[🔧 Environment Setup]
    G2 --> G1A
    G3 --> G1A

    J --> J1A[🧪 Testing & Quality]
    K --> K1A[🚀 Build & Deployment]

    style A fill:#ffebee
    style B fill:#e3f2fd
    style D fill:#fff3e0
    style G fill:#f3e5f5
    style J fill:#e8f5e8
    style K fill:#e0f2f1
```

```bash
just health                    # Overall system health check
just env_check                 # Environment validation
just docker_status             # Container diagnostics
just info                      # Configuration overview
```

### 🎯 Quick Health Assessment
```bash
# Service status overview
just status                    # Complete environment status
just logs backend local      # View backend service logs
just logs admin local        # View admin dashboard logs
just logs mobile local       # View mobile app logs
just logs db local           # View database logs

# Environment validation
just env_status                # Environment configuration status
just env_check                 # Comprehensive environment diagnostics
```

### 📚 Quick Diagnostic Resources
- **[Getting Started Guide](../setup/getting-started.md)** - Complete setup validation and verification
- **[Quick Start Guide](../setup/quick-start.md)** - **Primary troubleshooting commands** and workflows
- **[Environment Configuration](../setup/environment-setup.md)** - Configuration troubleshooting reference

---

## 🔧 Environment & Setup Issues
**Prerequisites, dependencies, and configuration** - New installations and environment problems

Solve **setup and configuration issues** that prevent Spacewalker from running properly:

### 🔍 Environment Diagnostics
```bash
# Environment validation and setup
just env_check                 # Comprehensive environment diagnostics
just env_setup                 # Setup development environment from scratch
just env_status                # Current environment configuration

# Prerequisites check
which python3                  # Python installation check
which node                     # Node.js installation check
which docker                   # Docker installation check
which uv                       # uv package manager check
```

### 🛠️ Common Environment Fixes
```bash
# Complete environment setup
just env_setup                 # Automated environment setup from scratch

# Manual setup steps
just install                   # Install all dependencies
just up                        # Start all services
just health                    # Verify setup success

# Mobile development setup
just expo ip auto              # Configure mobile IP automatically
just expo start --offline      # Start mobile development server
```

### 📚 Environment Resources
- **[Environment Configuration Guide](../setup/environment-setup.md)** - **Comprehensive environment troubleshooting**
- **[Getting Started Guide](../setup/getting-started.md)** - Prerequisites and setup validation
- **[Project Structure Guide](../development/project-structure.md)** - Understanding codebase organization

**Related Gotchas:**
- **[AI Development Setup](../setup/ai-development-setup.md)** - Common environment problems and solutions

---

## 🐳 Service Management & Docker
**Container and service lifecycle** - Services not starting, Docker issues, port conflicts

Handle **service and container problems** that affect the running environment:

### 🔍 Service Diagnostics
```bash
# Service health and status
just health                    # Service health overview
just docker_status             # Detailed Docker diagnostics
just status                    # Complete environment status

# Service logs and debugging
just logs backend local      # Backend API logs
just logs admin local        # Admin dashboard logs
just logs mobile local       # Mobile service logs
just logs db local           # Database logs

# AWS environment logs
just logs backend dev        # Dev backend logs
just logs admin staging      # Staging admin logs
just logs backend prod       # Production backend logs
```

### 🛠️ Service Management
```bash
# Service control
just up                        # Start all services
just down                      # Stop all services
just service restart backend # Restart specific service
just service restart admin   # Restart admin service

# Docker management
just docker_clean              # Clean Docker state
just docker_rebuild            # Rebuild containers
just docker_clean && just up   # Clean restart
```

### 🚑 Service Recovery
```bash
# Progressive recovery steps
just service restart [service] # Restart specific service
just down && just up           # Full service restart
just docker_clean && just up   # Clean Docker restart
just fresh_dev                 # Fresh development environment (nuclear option)
```

### 📚 Service Resources
- **[Quick Start Guide](../setup/quick-start.md)** - **Service management commands** and troubleshooting
- **[Docker Compose](../../docker-compose.yml)** - Main development environment configuration
- **[Docker Dev Config](../../docker-compose.dev.yml)** - Development-specific overrides

**Related Gotchas:**
- **[Environment Setup](../setup/environment-setup.md)** - Container and deployment security

---

## 🗃️ Database Problems
**Database connectivity, migrations, and data integrity** - Connection failures, data issues

Resolve **database-related issues** while preserving data safety:

### 🔍 Database Diagnostics
```bash
# Database connectivity and status
just db shell                # Direct database access
just db verify               # Check migrations and consistency
just health                    # Database health in overall status

# Database inspection
psql -d spacewalker_dev        # Direct PostgreSQL access (if available)
just logs backend local      # Backend logs often show DB issues
just logs db local           # Direct database logs
```

### 🛠️ Database Management
```bash
# Safe database operations
just db_backup                 # Create backup before operations
just db_backup_named "issue"   # Named backup for specific troubleshooting
just db_safe_reset             # Reset database with backup preservation

# Demo data management
just db_seed_safe              # Create demo data (preserves existing)
just db_seed_users             # Create only demo users
just db_clean_demo             # Remove ONLY demo tenant data
```

### 🚑 Database Recovery
```bash
# Progressive database recovery
just db verify               # Check database consistency
just db_safe_reset             # Reset with automatic backup
just db_backup && just db_reset  # Manual backup then reset
just fresh_dev                 # Fresh development environment with clean DB
```

### 📚 Database Resources
- **[Backend Development Guide](../backend/development/README.md)** - Database setup and connection troubleshooting

**Related Gotchas:**
- **[Environment Setup](../setup/environment-setup.md)** - Database API connectivity problems

---

## 📱 Mobile App Connectivity
**Mobile development and device connection** - Mobile app can't connect, IP issues, platform problems

Fix **mobile connectivity issues** and development setup problems:

### 🔍 Mobile Diagnostics
```bash
# Mobile connectivity diagnosis
just info                      # Show current IP configuration
just expo start --offline      # Start or check Expo development server
just logs mobile local       # Mobile service logs
just health                    # Overall mobile service health
```

### 🛠️ Mobile Connection Setup
```bash
# Automatic IP configuration
just expo ip auto              # Detect and configure IP automatically
just expo start --offline      # Start/restart Expo development server

# Manual IP verification
just info                      # Display current configuration
# Check mobile app shows: "Connected to: http://YOUR_IP:8000"
```

### 📱 Platform-Specific Solutions
```bash
# iOS (Safari method)
# Navigate to: exp://YOUR_IP:8081
# Example: exp://192.168.1.100:8081

# Android (Expo Go method)
just expo start --offline      # Shows QR code for Expo Go app
# Scan QR code with Expo Go from Google Play Store
```

### 🚑 Mobile Recovery
```bash
# Progressive mobile troubleshooting
just expo ip auto              # Reconfigure IP detection
just service restart mobile  # Restart mobile service
just expo start --offline      # Restart Expo development server
just fresh_dev                 # Fresh development environment reset
```

### 📚 Mobile Resources
- **[Quick Start Guide](../setup/quick-start.md)** - **Mobile connection setup** and IP configuration
- **[Mobile Development Guide](../mobile/development/README.md)** - Mobile-specific setup and troubleshooting

**Related Gotchas:**
- **[Environment Setup](../setup/environment-setup.md)** - Device connection problems
- **[Getting Started Guide](../setup/getting-started.md)** - React Native Hermes issues

---

## 🚀 Build & Deployment Failures
**Build processes, CI/CD, and infrastructure** - Build failures, deployment issues, AWS problems

Resolve **build and deployment problems** in development and production:

### 🔍 Build Diagnostics
```bash
# Build validation
just test unit all                 # Quick build validation
just test unit all           # Unit test validation
just lint check all                # Code quality validation

# Docker build diagnostics
just docker_rebuild            # Force rebuild containers
just docker_status             # Container build status
```

### 🛠️ Development Build Issues
```bash
# Local build troubleshooting
just clean                     # Clean build state
just install                   # Reinstall dependencies
just docker_rebuild            # Rebuild Docker images
just fresh_dev                 # Fresh development environment
```

### 🏗️ AWS Deployment Diagnostics
```bash
# AWS infrastructure status
just health dev              # Check AWS infrastructure health
just aws_deploy_foundation     # Redeploy base infrastructure
just aws_deploy_services       # Redeploy application services

# Deployment validation
just workflow_prod_check       # Production readiness validation
```

### 📚 Build & Deployment Resources
- **[Deployment Guide](../workflows/deployment-guide.md)** - **Comprehensive deployment workflows and infrastructure setup**
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - OIDC configuration and CI/CD best practices
- **[CI/CD Deployment Fixes](../gotchas/ci-cd-deployment-fixes.md)** - **Critical fixes for CloudWatch IAM, Docker tags, and deployment debugging**

**Related Gotchas:**
- **[Environment Setup](../setup/environment-setup.md)** - Common build and deployment issues
- **[CI/CD Deployment Fixes](../gotchas/ci-cd-deployment-fixes.md)** - Production CI/CD pipeline fixes

---

## 🔄 CI/CD Pipeline Issues
**GitHub Actions failures, workflow debugging** - Failed runs, job errors, artifact issues

Debug **CI/CD pipeline failures** and analyze workflow performance:

### 🔍 GitHub Actions Diagnostics
```bash
# Quick status check
just gh-actions status                # Recent runs overview
just gh-actions list --limit 5        # List recent workflow runs

# Investigate specific run
just gh-actions show 7123456789       # Detailed run information
just gh-actions jobs 7123456789       # List all jobs in run
just gh-actions analyze 7123456789    # Complete analysis with AI
```

### 🛠️ Debugging Failed Jobs
```bash
# Find failed job ID
just gh-actions jobs 7123456789       # Lists jobs with status icons

# Extract errors from logs
just gh-actions errors 20123456789    # Smart error extraction
just gh-actions logs 20123456789      # Full job logs

# AI-powered failure analysis
just gh-actions ai 7123456789 failure_analysis
```

### 📊 Common CI/CD Issues
- **Test Failures**: Use `just gh-actions errors <job_id>` to extract test failures
- **Build Errors**: Check for syntax errors, missing dependencies
- **Deployment Issues**: Verify credentials and permissions
- **Timeout Problems**: Look for long-running jobs with `just gh-actions show`
- **Flaky Tests**: Use AI analysis to identify intermittent failures

### 🔧 Artifact Investigation
```bash
# List artifacts from failed run
just gh-actions artifacts 7123456789

# Download specific artifact
just gh-actions download 500123456

# Extract and examine
unzip artifact-500123456.zip
```

### 📚 CI/CD Resources
- **[GitHub Actions Analysis Guide](github-actions-analysis.md)** - **Comprehensive guide to using actions tools**
- **[CI/CD Deployment Fixes](../gotchas/ci-cd-deployment-fixes.md)** - Critical fixes and debugging tips

---

## 🧪 Testing & Quality Issues
**Test failures, quality tools, validation** - Tests not passing, linting errors, CI failures

Resolve **testing and code quality problems** that block development:

### 🔍 Testing Diagnostics
```bash
# Quick test validation
just test unit all                 # Fast unit tests (should always pass)
just dev_cycle                 # Development cycle with tests + linting
just health                    # Ensure services running for integration tests

# Comprehensive test status
just test all all                  # All test types
just test unit all           # Unit test validation
```

### 🛠️ Test Issue Resolution
```bash
# Test environment setup
just up                        # Ensure services running
just db_seed_safe              # Ensure demo data available
just test unit all                 # Run unit tests first

# Integration test issues
just test integration all --with-setup  # Auto-start infrastructure
just db verify               # Check database consistency
```

### 📊 Known Test Issues
- **Backend**: 21 failing tests, 142 passing (documented in test_summary.md)
- **Mobile**: 6 expected failures due to alert message changes
- **Auth Tests**: 5 failures due to test isolation issues
- **Integration**: ~23 expected failures documented

### 🎯 Quality Validation
```bash
# Code quality
just lint                      # Auto-fix code style issues
just lint check all                # Read-only linting validation
just lint check all --ci                   # CI-style linting (warnings as errors)

# Repository-specific linting
just lint check backend              # Backend code quality
just lint check admin                # Admin code quality
just lint check mobile               # Mobile code quality
```

### 📚 Testing Resources
- **[Testing Guide](./testing-guide.md)** - **Comprehensive testing troubleshooting and workflows**
- **[Logging Guide](./logging-guide.md)** - **Unified log viewing with u_logs command**
- **[Backend Development Guide](../backend/development/README.md)** - Current test status and expected failures

**Related Gotchas:**
- **[Environment Setup](../setup/environment-setup.md)** - Common testing problems and solutions
- **[Getting Started Guide](../setup/getting-started.md)** - Mobile testing compatibility issues

---

## ⚡ Performance & Resource Issues
**Slow performance, resource constraints** - Services slow to start, resource exhaustion

Diagnose and resolve **performance and resource problems**:

### 🔍 Performance Diagnostics
```bash
# Resource monitoring
just docker_status             # Container resource usage
just health                    # Service response time status
just logs backend local      # Check for performance-related errors
just logs admin local --errors-only  # Performance error patterns

# System resource check
docker stats                   # Real-time container resource usage
df -h                          # Disk space availability
free -h                        # Memory availability (Linux)
```

### 🛠️ Performance Optimization
```bash
# Resource management
just down && just up           # Restart services to free resources
just docker_clean              # Clean Docker resources
just docker_rebuild            # Rebuild optimized containers

# Development performance
just test unit all                 # Fast tests for quick feedback
just dev_cycle                 # Optimized development workflow
```

### 🚑 Resource Recovery
```bash
# Progressive resource cleanup
just docker_clean              # Clean Docker state
just down                      # Stop services in current directory
just down everywhere           # Stop containers in main repo + all worktrees (idempotent)
docker system prune -f         # Clean Docker system resources
just fresh_dev                 # Fresh development environment reset
```

### 📚 Performance Resources
- **[Quick Start Guide](../setup/quick-start.md)** - **Performance monitoring commands**
- **[Docker Configuration](../../docker-compose.yml)** - Resource allocation and container limits

**Related Gotchas:**
- **[Environment Setup](../setup/environment-setup.md)** - Common performance problems and optimization

---

## 🔐 Security & Authentication
**Authentication, authorization, security** - Login failures, permission errors, JWT issues

Resolve **security and authentication problems**:

### 🔍 Authentication Diagnostics
```bash
# Authentication validation
just health                    # Check auth service status
just logs backend              # Backend auth logs
just db shell                # Direct database auth inspection

# Demo credentials validation
just db_seed_safe              # Ensure demo users exist
# Use demo credentials from apps/admin/DEMO_CREDENTIALS.md
```

### 🛠️ Authentication Setup
```bash
# Demo authentication
just db_seed_safe              # Create demo users safely
just db_seed_users             # Create only demo users

# Environment authentication
just env_check                 # Validate auth configuration
just env_status                # Check auth environment variables
```

### 🔑 Common Auth Issues
- **JWT Token Errors**: Check environment JWT_SECRET configuration
- **Demo Credentials**: Use credentials from DEMO_CREDENTIALS.md after running `just db_seed_safe`
- **API Authentication**: Verify environment variables in environment configuration

### 📚 Security Resources
- **[Environment Configuration](../setup/environment-setup.md)** - Security configuration and secrets
- **[Admin Architecture Guide](../admin/architecture/README.md)** - Demo authentication credentials

**Related Gotchas:**
- **[Environment Setup](../setup/environment-setup.md)** - Login and JWT token issues

---

## 🌐 External Service Integration
**Third-party APIs and services** - API failures, storage issues, connectivity problems

Troubleshoot **external service connectivity and configuration**:

### 🔍 External Service Diagnostics
```bash
# Service connectivity
just health                    # Overall external service health
just logs backend              # Backend external service logs
just test ai real              # Test real Gemini API integration (if configured)

# Configuration validation
just env_check                 # External service configuration
just env_status                # API key and endpoint status
```

### 🛠️ External Service Configuration
```bash
# API configuration
just env_check                 # Validate API configuration
# Check environment configuration for:
# - Gemini API keys
# - S3/MinIO storage configuration
# - External API endpoints
```

### 🔗 Common External Issues
- **Gemini AI API**: Check API key configuration in environment variables
- **S3/MinIO Storage**: Verify storage configuration and credentials
- **Network Connectivity**: Check firewall and network access to external APIs
- **Rate Limiting**: Check API usage limits and retry logic

### 📚 External Service Resources
- **[Environment Configuration](../setup/environment-setup.md)** - External service configuration and secrets
- **[Backend Development Guide](../backend/development/README.md)** - External API testing and known issues

**Related Gotchas:**
- **[Environment Setup](../setup/environment-setup.md)** - Third-party service connectivity problems

---

## 🎯 Troubleshooting by User Type

### 👨‍💻 Developers
**Daily development issues**
1. Start: [Quick Diagnostics](#-quick-diagnostics) → [Environment & Setup](#-environment--setup-issues)
2. Common: [Service Management](#-service-management--docker) → [Mobile Connectivity](#-mobile-app-connectivity)
3. Quality: [Testing & Quality Issues](#-testing--quality-issues)

### 🔧 DevOps Engineers
**Infrastructure and deployment**
1. Primary: [Build & Deployment Failures](#-build--deployment-failures) → [Performance & Resource](#-performance--resource-issues)
2. Integration: [External Service Integration](#-external-service-integration) → [Security & Authentication](#-security--authentication)
3. Monitoring: [Database Problems](#-database-problems)

### 🔍 Operations Teams
**Production support and monitoring**
1. Monitoring: [Performance & Resource](#-performance--resource-issues) → [Security & Authentication](#-security--authentication)
2. Integration: [External Service Integration](#-external-service-integration) → [Database Problems](#-database-problems)
3. Recovery: [Service Management](#-service-management--docker)

---

## 🚑 Emergency Recovery Procedures

### Level 1: Service Recovery (< 5 minutes)
```bash
just service restart [service] # Restart specific service
just health                    # Verify recovery
```

### Level 2: Environment Recovery (5-15 minutes)
```bash
just down && just up           # Full service restart
just docker_clean && just up   # Clean Docker restart
just health                    # Verify recovery
```

### Level 3: Nuclear Recovery (15-30 minutes)
```bash
just fresh_dev                 # Fresh development environment reset
just health && just test unit all  # Verify complete recovery
```

### Level 4: Data Recovery (30+ minutes)
```bash
just db_backup                 # Create backup first
just db_safe_reset             # Reset database with backup
just fresh_dev                 # Fresh development environment
```

---

## Application-Specific Troubleshooting

### Backend Troubleshooting
- **[Backend Development Guide](../backend/development/README.md)** - FastAPI service troubleshooting
- **[Backend Architecture](../backend/architecture/README.md)** - Service architecture and debugging

### Admin Dashboard Troubleshooting
- **[Admin Architecture Guide](../admin/architecture/README.md)** - Next.js dashboard troubleshooting
- **[Admin Architecture Guide](../admin/architecture/README.md)** - Dashboard architecture and debugging

### Mobile App Troubleshooting
- **[Mobile Development Guide](../mobile/development/README.md)** - React Native app troubleshooting
- **[Mobile Architecture](../mobile/architecture/README.md)** - App architecture and debugging

---

## Common Issues and Solutions

### Known Gotchas
- **[Mobile Development Guide](../mobile/development/README.md)** - React Native engine issues
- **[Getting Started Guide](../setup/getting-started.md)** - Testing framework issues
- **[Environment Setup](../setup/environment-setup.md)** - Common configuration issues

---

## Related Documentation

- **[Getting Started Guide](../setup/getting-started.md)** - Complete setup validation and verification
- **[Quick Start Guide](../setup/quick-start.md)** - Rapid setup with diagnostic commands
- **[Deployment Guide](../workflows/deployment-guide.md)** - Infrastructure setup and deployment troubleshooting
- **[Testing Guide](./testing-guide.md)** - Testing frameworks and quality issue resolution
- **[Environment Configuration](../setup/environment-setup.md)** - Configuration reference and troubleshooting

---

## 📞 Getting Help

### Immediate Assistance
- **Quick Health**: `just health` - Overall system status
- **Environment Issues**: `just env_check` - Environment diagnostics
- **Service Problems**: `just docker_status` - Container diagnostics
- **Complete Reset**: `just fresh_dev` - Nuclear option

### Documentation Resources
- **[Quick Start Guide](../setup/quick-start.md)** - Essential commands and workflows
- **[Testing Guide](./testing-guide.md)** - Test-related troubleshooting
- **[Deployment Guide](../workflows/deployment-guide.md)** - Infrastructure troubleshooting
- **[Environment Configuration](../setup/environment-setup.md)** - Configuration reference

### Known Issues References
- **[Backend Development Guide](../backend/development/README.md)** - Current test status and expected failures
- **[Setup Documentation](../setup/)** - Application-specific issues and solutions

**Remember**: When in doubt, start with `just health` and `just env_check` for immediate diagnostics! 🚀

---
**Status**: ✅ Updated and current as of 2025-06-29. Reorganized for improved navigation and enhanced with application-specific troubleshooting cross-references.
