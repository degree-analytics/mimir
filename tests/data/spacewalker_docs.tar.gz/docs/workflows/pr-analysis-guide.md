# PR Analysis Tools Guide

This guide covers SpaceWalker's unified PR analysis system that provides comprehensive insights into pull requests through a consistent action-based interface.

## Overview

The PR analysis system uses an action-first pattern (`just gh-pr <action> <pr_number>`) that provides:
- **Direct Data Access** - Get specific PR information without AI processing
- **Rich Commit History** - Full commit messages, bodies, and co-author information
- **File Organization** - Changes grouped by directory with statistics
- **Comprehensive Timeline** - Chronological view of all PR events
- **AI Enhancement** - Optional Claude-powered analysis for deeper insights
- **Test Status Checking** - Real-time CI/CD status with freshness validation

## Quick Start

```bash
# Show PR summary (default action)
just gh-pr show 290

# View detailed commit history
just gh-pr commits 290

# See file changes with stats
just gh-pr files 290

# Get detailed statistics
just gh-pr stats 290

# View chronological timeline
just gh-pr timeline 290

# AI-powered risk analysis
just git-info pr-review-issues 290 --analysis=risk
```

## Available Commands

### Data Access Commands

#### `just gh-pr show <pr_number>`
Shows a concise PR summary with key metrics and recommendations.

#### `just gh-pr commits <pr_number>`
Displays detailed commit history including:
- Full commit messages and bodies
- Author and co-author information
- Commit dates and SHAs
- Linked issues in commit messages

#### `just gh-pr files <pr_number>`
Shows file changes organized by directory:
- Files grouped by directory
- Addition/deletion counts per file
- Status indicators (added/modified/removed)
- Directory-level statistics

#### `just gh-pr stats <pr_number>`
Provides comprehensive statistics:
- Total files, commits, and line changes
- File type breakdown with change counts
- Largest changes ranked by impact
- Net code change calculations

#### `just gh-pr timeline <pr_number>`
Shows chronological PR events:
- All commits with timestamps
- Comments and reviews
- Status changes and CI events
- Review requests and assignments

### Data Export Commands

#### `just gh-pr fetch <pr_number>`
Returns raw JSON data containing all PR information.

```bash
just gh-pr fetch 290                    # Output to console
just gh-pr export 290                   # Save to pr-290.json
just gh-pr export 290 custom.json       # Save to custom file
```

### Specialized Commands

#### `just gh-pr test-status <pr_number>`
Quick CI/CD status check without full analysis.

```bash
just gh-pr test-status 290              # Detailed test status
```

#### `just gh-pr comment <pr_number> --file=<path> | --text="<comment>"`
Post comments to PRs safely.

```bash
just gh-pr comment 290 --file=review.md
just gh-pr comment 290 --text="LGTM! Ready to merge."
```

### AI Analysis Commands

All AI commands require `ANTHROPIC_API_KEY` in your `.env` file.

#### `just git-info pr-review-issues <pr_number> --analysis=<type>`
Runs AI analysis on PR data.

Analysis types:
- `summary` - Comprehensive PR analysis
- `comments` - Comment thread analysis
- `risk` - Risk assessment and concerns
- `test-freshness` - Are tests run after latest changes?

```bash
just git-info pr-review-issues 290 --analysis=summary          # Full AI analysis
just git-info pr-review-issues 290 --analysis=risk              # Risk assessment only
```

### Composed Commands

#### `just git-info pr-review-issues <pr_number>`
Comprehensive review combining multiple analyses:
1. Algorithmic Analysis Summary
2. AI-Powered Insights (if API key configured)
3. Test Status with freshness check

```bash
just git-info pr-review-issues 290 --analysis=summary   # Complete multi-section review

### Actionable, Time-Aware Reviews (New)

Surface only new, validated issues since your last push, with priorities and confidence:

```bash
just git-info pr-review-issues 290 --analysis=actionable --since-last-push

# Or specify a timestamp explicitly
just git-info pr-review-issues 290 --analysis=actionable --since=2025-09-10T12:00:00Z
```
```

## Customization

### Output Formats

The formatter supports multiple output styles via `--format`:
- `title` - Generates conventional commit style PR title
- `full` - Complete PR description with all sections
- `summary` - Key metrics and changes overview
- `compact` - Single line summary for scripts

### AI Analysis Types

When using `just git-info pr-review-issues <pr> --analysis=<type>`:
- `summary` - Comprehensive PR analysis with recommendations
- `comments` - Analyzes discussion threads and sentiment
- `risk` - Security and stability risk assessment
- `test-freshness` - Validates tests were run after latest changes

### Composing Custom Workflows

The action-based commands enable powerful automation:

```bash
# Quick review workflow - see summary, commits, and files
for action in show commits files; do
  echo "=== PR 290: $action ==="
  just gh-pr $action 290
done

# Batch export PR data
for pr in 290 291 292; do
  just gh-pr export $pr pr-$pr-data.json
done

# Risk assessment for all open PRs
gh pr list --json number -q '.[].number' | while read pr; do
  echo "PR $pr risk:"
  just git-info pr-review-issues $pr --analysis=risk
done

# Daily standup helper - review your latest PR
MY_PR=$(gh pr list --author @me --json number -q '.[0].number')
just git-info pr-review-issues $MY_PR --analysis=summary

# Quick PR stats comparison
for pr in $(gh pr list --limit 5 --json number -q '.[].number'); do
  echo -n "PR #$pr: "
  just gh-pr stats $pr | grep "Net change"
done
```

## Integration with Development Workflow

### During PR Creation
```bash
# Get overview of your changes
just gh-pr show $PR_NUMBER              # Quick summary
just gh-pr stats $PR_NUMBER             # See impact metrics

# Before submitting PR
just git-info pr-review-issues $PR_NUMBER --analysis=risk           # Check for risks
just gh-pr test-status $PR_NUMBER       # Verify tests pass
```

### During Code Review
```bash
# As reviewer - understand the changes
just gh-pr show $PR_NUMBER              # Get overview
just gh-pr commits $PR_NUMBER           # Review commit history
just gh-pr files $PR_NUMBER             # Examine file changes
just gh-pr timeline $PR_NUMBER          # See development flow

# Deep dive with AI assistance
just git-info pr-review-issues $PR_NUMBER --analysis=summary       # Full AI-powered review
just git-info pr-review-issues $PR_NUMBER --analysis=comments      # Analyze discussions
```

### Before Merging
```bash
# Final checks
just gh-pr test-status $PR_NUMBER       # All green?
just git-info pr-review-issues $PR_NUMBER --analysis=test-freshness # Tests current?
just gh-pr stats $PR_NUMBER             # Final impact check
```

## Troubleshooting

### ANTHROPIC_API_KEY not found
```bash
# Add to .env file
echo "ANTHROPIC_API_KEY=your-key-here" >> .env
```

### Command not found
```bash
# Check available commands
just gh-pr help

# Ensure you're in project root
pwd  # Should show spacewalker directory
```

### Empty or error responses
```bash
# Test individual components
just gh-pr fetch $PR_NUMBER           # Can we get raw data?
just gh-pr test-status $PR_NUMBER     # Is GitHub API working?

# Check PR exists
gh pr view $PR_NUMBER

# Debug specific action
just gh-pr show $PR_NUMBER            # Try simplest action first
```

## Security & Validation

All PR tools include comprehensive input validation to prevent security vulnerabilities:
- API key format validation
- PR number validation (numeric only)
- Repository format validation (owner/repo)
- Output path validation (prevents directory traversal)

See `scripts/pr_validation.py` for implementation details.

## Architecture

The new mega analyzer architecture:

```
┌─────────────────────┐
│   just gh-pr command   │
└──────────┬──────────┘
           │
    ┌──────▼──────────┐
    │ analyzer.py     │ ← Main orchestrator
    └──────┬──────────┘
           │
    ┌──────▼──────────┐      ┌─────────────────┐
    │ fetcher.py      │──────► Parallel GitHub │
    │                 │      │ API calls       │
    └──────┬──────────┘      └─────────────────┘
           │
    ┌──────▼──────────┐      ┌─────────────────┐
    │ enhancer.py     │──────► Algorithmic     │
    │                 │      │ Analysis Engine │
    └──────┬──────────┘      └─────────────────┘
           │
    ┌──────▼──────────┐      ┌─────────────────┐
    │ formatter.py    │──────► Multiple Output │
    │  OR             │      │ Formats         │
    │ ai_analyzer.py  │      └─────────────────┘
    └─────────────────┘
```

**Key Improvements:**
- **80% more data** extracted via parallel API calls
- **Pure algorithmic analysis** - no ML/AI dependency for core features
- **Unified command interface** - single entry point for all functionality
- **Modular components** - each script is self-contained and testable

## Best Practices

1. **Start with default analysis** - `just gh-pr <number>` provides comprehensive data
2. **Use format options wisely** - `--format=title` for automation, `--format=full` for reviews
3. **Save analysis for large PRs** - `--output=file.json` preserves data for iterative work
4. **Leverage AI for complex PRs** - `just git-info pr-review-issues <number> --analysis=risk` catches subtle issues
5. **Always verify test freshness** - Critical before merging any PR

## Related Documentation

- [Graphite Workflows](./graphite-workflows.md) - Branch and commit strategies
- [Testing Guide](./testing-guide.md) - Running and writing tests
- [Claude Review Workflows](./claude-review-workflows.md) - GitHub-triggered AI reviews
