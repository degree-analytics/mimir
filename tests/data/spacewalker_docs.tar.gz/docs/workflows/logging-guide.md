# Spacewalker Logging Guide

## Purpose
Comprehensive guide to viewing and analyzing logs across all Spacewalker services and environments using the unified `logs` command. Essential reference for debugging, monitoring, and troubleshooting system behavior in development and production.

## When to Use This
- Debugging service issues in any environment (local, dev, staging, prod)
- Monitoring application behavior and performance
- Troubleshooting integration problems between services
- Analyzing error patterns and system health
- Following request flows across services
- Keywords: logs, logging, debugging, monitoring, cloudwatch, docker logs, troubleshooting

**Version:** 1.0 (Initial unified logging documentation)
**Date:** 2025-07-20
**Status:** Current - Unified Logging System

---

## 🎯 Quick Start: Unified Log Viewing

### The Single Command You Need
```bash
just logs <service> <env> [options]
```

**This single command replaces 13+ individual log commands** and provides consistent access to logs across all services and environments.

### Basic Examples
```bash
# View backend logs in local development
just logs backend local

# Follow admin logs in dev environment
just logs admin dev --follow

# View last 100 lines of mobile logs in production
just logs mobile prod --tail 100

# Show only errors from database in staging
just logs db staging --errors-only

# View logs from the last 30 minutes
just logs backend dev --since 30m
```

---

## 📋 Available Services and Environments

### Services
- `backend` - FastAPI backend service
- `admin` - Next.js admin dashboard
- `mobile` - React Native mobile app
- `db` - PostgreSQL database

### Environments
- `local` - Local Docker development
- `dev` - AWS development environment
- `staging` - AWS staging environment
- `prod` - AWS production environment

---

## 🔧 Command Options

### Following Logs
```bash
# Follow logs in real-time (like tail -f)
just logs backend local --follow
just logs admin dev -f
```

### Limiting Output
```bash
# Show last N lines
just logs backend dev --tail 50
just logs admin prod -n 100
```

### Time-Based Filtering
```bash
# Show logs from last N minutes/hours/days
just logs backend dev --since 30m    # Last 30 minutes
just logs admin prod --since 2h       # Last 2 hours
just logs mobile staging --since 1d   # Last 24 hours
```

### Error Filtering
```bash
# Show only errors and critical messages
just logs backend dev --errors-only
just logs admin prod -e
```

### Custom Filtering
```bash
# Filter logs by custom pattern
just logs backend dev --filter "user_id=123"
just logs admin staging --filter "BuildingController"
```

---

## 🐳 Local Development Logs

When viewing logs in the `local` environment, the command reads from Docker containers:

```bash
# View all backend logs
just logs backend local

# Follow logs in real-time
just logs backend local --follow

# Filter for errors
just logs backend local --errors-only
```

### Local Container Mapping
- `backend` → `spacewalker-backend-1`
- `admin` → `spacewalker-admin-1`
- `mobile` → `spacewalker-mobile-1`
- `db` → `spacewalker-db-1`

---

## ☁️ AWS CloudWatch Logs

For AWS environments (dev, staging, prod), logs are retrieved from CloudWatch:

```bash
# View recent backend logs from dev
just logs backend dev

# Follow production admin logs
just logs admin prod --follow

# View staging database logs from last hour
just logs db staging --since 1h
```

### CloudWatch Log Groups
- Backend: `/ecs/{env}-spacewalker-backend`
- Admin: `/ecs/{env}-spacewalker-admin`
- Mobile: `/ecs/{env}-spacewalker-mobile`
- Database: `/aws/rds/instance/spacewalker-{env}`

---

## 🔍 Common Debugging Scenarios

### 1. Debugging API Errors
```bash
# Check backend logs for errors
just logs backend dev --errors-only

# Follow logs while reproducing issue
just logs backend dev --follow

# Search for specific endpoint
just logs backend dev --filter "/api/buildings"
```

### 2. Frontend Issues
```bash
# Check admin dashboard logs
just logs admin dev --tail 200

# Look for specific component errors
just logs admin dev --filter "BuildingList"
```

### 3. Database Problems
```bash
# View recent database logs
just logs db dev --tail 100

# Check for connection issues
just logs db dev --filter "connection"
```

### 4. Mobile App Connectivity
```bash
# Check mobile service logs
just logs mobile local --follow

# Look for API connection errors
just logs mobile local --filter "fetch.*failed"
```

### 5. Cross-Service Request Tracing
```bash
# Open multiple terminals and follow logs from different services
# Terminal 1: Backend
just logs backend dev --follow

# Terminal 2: Admin
just logs admin dev --follow

# Terminal 3: Database
just logs db dev --follow
```

---

## 🎯 Error Patterns and Filtering

### Default Error Pattern
When using `--errors-only`, the following patterns are matched:
- `ERROR`
- `CRITICAL`
- `Exception`
- `Traceback`
- `FATAL`

### Custom Filtering Examples
```bash
# Find authentication failures
just logs backend dev --filter "401|Unauthorized"

# Track specific user activity
just logs backend dev --filter "user_id=12345"

# Monitor database queries
just logs backend dev --filter "SELECT|INSERT|UPDATE|DELETE"

# Find timeout issues
just logs backend dev --filter "timeout|timed out"
```

---

## 📊 Time-Based Analysis

### Relative Time Formats
```bash
# Minutes
just logs backend dev --since 15m    # Last 15 minutes
just logs backend dev --since 45m    # Last 45 minutes

# Hours
just logs backend dev --since 1h     # Last hour
just logs backend dev --since 3h     # Last 3 hours

# Days
just logs backend dev --since 1d     # Last 24 hours
just logs backend dev --since 7d     # Last week
```

### Analyzing Patterns Over Time
```bash
# Check for errors in the last hour
just logs backend prod --since 1h --errors-only

# Review overnight activity
just logs backend prod --since 12h

# Analyze weekly patterns
just logs backend prod --since 7d --filter "cron"
```

---

## 🚨 Troubleshooting Log Access

### Local Docker Issues
```bash
# Verify containers are running
docker ps

# Check container names match expected pattern
docker ps --format "table {{.Names}}"

# Access logs directly if needed
docker logs spacewalker-backend-1
```

### AWS CloudWatch Issues
```bash
# Verify AWS credentials
aws sts get-caller-identity

# Check log group exists
aws logs describe-log-groups --log-group-name-prefix "/ecs/dev-spacewalker"

# Verify permissions
aws logs filter-log-events --log-group-name "/ecs/dev-spacewalker-backend" --max-items 1
```

---

## 🔧 Advanced Usage

### Log Analysis Pipeline
```bash
# Export logs for analysis
just logs backend prod --since 1d > backend-logs.txt

# Count error occurrences
just logs backend prod --since 1h --errors-only | grep -c "ERROR"

# Find unique error types
just logs backend prod --since 1h --errors-only | grep "ERROR" | sort | uniq -c
```

### Monitoring Specific Features
```bash
# Monitor authentication flow
just logs backend dev --filter "auth|login|jwt" --follow

# Track API performance
just logs backend dev --filter "response_time|duration" --follow

# Watch for specific errors
just logs backend dev --filter "ValidationError|TypeError" --follow
```

---

## 📚 Related Documentation

- **[Troubleshooting Guide](./troubleshooting-guide.md)** - General troubleshooting procedures
- **[Deployment Guide](./deployment-guide.md)** - Deployment and infrastructure logs
- **[Quick Start Guide](../setup/quick-start.md)** - Getting started with development
- **[Backend Development](../backend/development/README.md)** - Backend-specific logging
- **[Mobile Development](../mobile/development/README.md)** - Mobile app logging

---

## 🎓 Best Practices

### 1. Start Broad, Then Narrow
```bash
# Start with recent logs
just logs backend dev --tail 100

# If you find an issue, follow in real-time
just logs backend dev --follow

# Then filter for specific patterns
just logs backend dev --filter "specific-error"
```

### 2. Use Multiple Terminals
Open separate terminals to monitor different services simultaneously when debugging cross-service issues.

### 3. Save Important Logs
```bash
# Save logs for later analysis
just logs backend prod --since 1h > incident-logs.txt

# Save filtered logs
just logs backend prod --since 1h --errors-only > error-logs.txt
```

### 4. Time-Based Investigation
When investigating issues:
1. Start with the time range when the issue occurred
2. Look for patterns before and after
3. Compare with normal operation periods

---

## 🚀 Migration from Old Commands

The `logs` command replaces these legacy commands:

### Local Docker Logs (replaced)
- `just logs` → `just logs backend local`
- `just logs_backend` → `just logs backend local`
- `just logs_admin` → `just logs admin local`
- `just logs_mobile` → `just logs mobile local`
- `just logs_db` → `just logs db local`

### AWS CloudWatch Logs (replaced)
- `just aws_logs dev backend` → `just logs backend dev`
- `just aws_logs staging admin` → `just logs admin staging`
- `just aws_logs prod mobile` → `just logs mobile prod`

---

**Remember**: One command to rule them all - `just logs <service> <env> [options]` 🎯
