# GitHub Actions Best Practices

## Purpose
Guidelines and patterns for optimizing GitHub Actions workflows, based on real-world performance analysis and Spacewalker-specific optimizations.

## When to Use This
- Designing new GitHub Actions workflows
- Optimizing existing workflow performance
- Troubleshooting slow CI/CD pipelines
- Planning cache and dependency strategies

**Keywords**: GitHub Actions optimization, workflow performance, cache strategies, CI/CD best practices

**Version**: 1.0  
**Date**: 2025-07-18  
**Status**: Current - Based on ENG-736 optimization findings

---

## 🚀 Performance Optimization Patterns

### Cache-First Architecture

**Pattern**: Use GitHub Actions cache strategically with proper separation and versioning.

> **⚠️ IMPORTANT**: See [GitHub Cache Optimization Guide](./github-cache-optimization-guide.md) for comprehensive cache optimization strategies that reduced our cache from 205GB to <10GB.

```yaml
# ✅ RECOMMENDED: Versioned, separated caches
- name: Cache Python dependencies
  id: cache-python
  uses: actions/cache@v4
  with:
    path: |
      ~/.cache/pip
      .venv
    key: ${{ runner.os }}-python-v2-${{ hashFiles('**/requirements.txt') }}

- name: Cache Node dependencies
  id: cache-node
  uses: actions/cache@v4
  with:
    path: |
      ~/.npm
      node_modules
    key: ${{ runner.os }}-node-v2-${{ hashFiles('**/package-lock.json') }}

# For read-only jobs (tests), use restore action
- name: Restore Python cache (read-only)
  uses: actions/cache/restore@v4
  with:
    path: |
      ~/.cache/pip
      .venv
    key: ${{ runner.os }}-python-v2-${{ hashFiles('**/requirements.txt') }}
    fail-on-cache-miss: true
```

**Benefits**:
- Prevents cache bloat through separation
- Enables targeted cache invalidation via versioning
- Reduces duplication with read-only restore
- Improves cache hit rates

### Complete Cache Keys

**Pattern**: Include ALL files that affect dependencies in cache keys.

```yaml
# ✅ COMPLETE: All dependency-defining files
key: ${{ runner.os }}-deps-${{ hashFiles('**/package.json', '**/package-lock.json', '**/requirements.txt', '**/Cargo.lock') }}

# ❌ INCOMPLETE: Missing workspace package.json files
key: ${{ runner.os }}-deps-${{ hashFiles('**/package-lock.json') }}
```

**Guidelines**:
- Include lock files: `package-lock.json`, `requirements.txt`, `Cargo.lock`
- Include workspace files: root and app-specific `package.json`
- Test hash patterns locally before deploying
- Version cache keys when changing structure

### Tool Binary Caching

**Pattern**: Cache tool binaries separately to prevent race conditions.

```yaml
# ✅ RECOMMENDED: Cache tools separately
- name: Cache UV binary
  uses: actions/cache@v4
  with:
    path: ~/.local/bin
    key: ${{ runner.os }}-uv-${{ hashFiles('**/requirements.txt') }}

- name: Install UV if needed
  run: |
    if ! command -v uv &> /dev/null; then
      pip install uv
    fi
```

**Benefits**:
- Prevents network contention in parallel jobs
- Avoids installation conflicts
- Reduces redundant downloads

---

## 🏗️ Workflow Architecture Patterns

### Job Independence Pattern

**Principle**: Each job should handle its own dependencies independently.

```yaml
jobs:
  test-backend:
    steps:
      - uses: actions/checkout@v4
      - name: Cache dependencies
        # ... independent cache setup
      - name: Install dependencies
        # ... job-specific logic
  
  test-frontend:
    steps:
      - uses: actions/checkout@v4
      - name: Cache dependencies
        # ... independent cache setup  
      - name: Install dependencies
        # ... job-specific logic
```

**Benefits**:
- Jobs can start immediately after checkout
- Failures in one job don't affect others
- Easier debugging and monitoring
- Better parallelization

### Consistent Verification Pattern

**Pattern**: Standardize dependency verification across all jobs.

```yaml
# ✅ STANDARDIZED: Consistent verification pattern
- name: Verify cache hit and install dependencies
  run: |
    echo "Cache hit status: ${{ steps.cache-deps.outputs.cache-hit }}"
    if [ ! -d "node_modules" ] || [ ! -d "apps/admin/node_modules" ]; then
      echo "🔄 Installing admin dependencies..."
      npm ci
    else
      echo "📦 Using cached Node.js dependencies"
      echo "✅ Verified: node_modules and apps/admin/node_modules exist"
    fi
```

**Benefits**:
- Consistent behavior across jobs
- Better debugging through logging
- Clear verification of dependency state
- Standardized error handling

---

## 🔧 Cache Optimization Strategies

### Cache Key Versioning

**Pattern**: Version cache keys for controlled invalidation.

```yaml
# Add version suffix when changing cache structure
key: ${{ runner.os }}-deps-v2-${{ hashFiles('**/package.json', '**/package-lock.json') }}
```

### Cache Path Optimization

**Pattern**: Include all relevant cache locations.

```yaml
path: |
  ~/.npm                    # npm global cache
  ~/.cache/pip             # pip cache
  ~/.local/bin             # tool binaries
  .venv                    # Python virtual environment
  node_modules             # root dependencies
  apps/*/node_modules      # app-specific dependencies
  packages/*/node_modules  # package dependencies
```

### Cache Warming Strategy

**Pattern**: Keep cache fresh with scheduled workflows.

```yaml
# Scheduled cache warming
on:
  schedule:
    - cron: '0 2 * * 1-5'  # Weekdays at 2 AM

jobs:
  warm-cache:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Warm dependency cache
        # ... standard cache setup
      - name: Install dependencies
        run: npm ci && pip install -r requirements.txt
```

---

## 📊 Performance Monitoring

### Cache Hit Rate Tracking

```bash
# Monitor cache performance
gh run list --workflow=ci-cd.yml --limit=10
gh run view [run-id] --log | grep "Cache hit status"

# Analyze cache patterns
gh api repos/:owner/:repo/actions/cache/usage
```

### Workflow Duration Analysis

```bash
# Track workflow duration trends
gh run list --workflow=ci-cd.yml --json conclusion,createdAt,timing --limit=50 \
  | jq '.[] | select(.conclusion=="success") | .timing'
```

### Job Start Time Monitoring

```yaml
# Add timing logs to jobs
- name: Job start timestamp
  run: echo "Job started at $(date -Iseconds)"
  
- name: Dependencies ready timestamp  
  run: echo "Dependencies ready at $(date -Iseconds)"
```

---

## 🚨 Anti-Patterns to Avoid

### ❌ Artifact-Based Dependency Distribution

**Don't**: Use artifacts for sharing dependencies between jobs.

```yaml
# ❌ ANTI-PATTERN: Slow artifact-based distribution
- name: Create dependency artifacts
  run: tar -czf deps.tar.gz node_modules .venv
- name: Upload artifacts
  uses: actions/upload-artifact@v4
```

**Why**: Creates sequential bottlenecks, high compression overhead, network delays.

### ❌ Conditional Artifact Creation

**Don't**: Make artifact creation conditional on cache hits.

```yaml
# ❌ ANTI-PATTERN: Conditional artifacts break downstream jobs
- name: Create artifacts if cache miss
  if: steps.cache.outputs.cache-hit != 'true'
  run: tar -czf deps.tar.gz node_modules
```

**Why**: Downstream jobs expect artifacts; missing artifacts force reinstallation.

### ❌ Incomplete Cache Keys

**Don't**: Use partial file patterns in cache keys.

```yaml
# ❌ INCOMPLETE: Missing workspace package.json files
key: ${{ runner.os }}-deps-${{ hashFiles('package-lock.json') }}
```

**Why**: Cache won't invalidate when workspace dependencies change.

---

## 🔍 Debugging Workflows

### Cache Debugging

```yaml
# Add cache debugging information
- name: Debug cache key
  run: |
    echo "Cache key files:"
    find . -name "package.json" -o -name "package-lock.json" -o -name "requirements.txt" | sort
    echo "Cache key hash: ${{ hashFiles('**/package.json', '**/package-lock.json', '**/requirements.txt') }}"
```

### Dependency State Verification

```yaml
# Verify dependency installation state
- name: Verify dependencies
  run: |
    echo "Node modules status:"
    ls -la node_modules/ | head -5
    echo "Python environment status:"
    ls -la .venv/ | head -5
    echo "Tool availability:"
    which node npm python pip uv || true
```

### Performance Profiling

```yaml
# Add timing to identify bottlenecks
- name: Start timer
  run: echo "START_TIME=$(date +%s)" >> $GITHUB_ENV

- name: End timer
  run: |
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    echo "Operation took ${DURATION} seconds"
```

---

## 📚 Implementation Checklist

### New Workflow Setup
- [ ] Use cache-first architecture (not artifacts)
- [ ] Include complete file patterns in cache keys
- [ ] Add cache hit logging for debugging
- [ ] Implement consistent dependency verification
- [ ] Cache tool binaries separately

### Existing Workflow Optimization
- [ ] Identify artifact-based patterns to eliminate
- [ ] Update cache keys to include all dependency files
- [ ] Add cache hit status logging
- [ ] Standardize dependency verification across jobs
- [ ] Monitor cache hit rates and performance improvements

### Performance Validation
- [ ] Measure workflow duration before/after changes
- [ ] Track cache hit rates across different scenarios
- [ ] Monitor job start times and parallelization
- [ ] Document performance improvements achieved

---

## 📈 Real-World Results

### Spacewalker ENG-736 Optimization
- **Before**: 9.2 minutes setup time (artifact-based)
- **After**: ~30 seconds setup time (cache-only)
- **Improvement**: 82% reduction in setup time
- **Approach**: Eliminated artifacts, implemented cache-first architecture

---

## 📚 Related Documentation

- **[CI/CD Build Guide](./ci-cd-build-guide.md)** - Complete pipeline documentation with performance optimization
- **[CI/CD Performance Anti-Patterns](../gotchas/ci-cd-performance-anti-patterns.md)** - Common mistakes to avoid
- **[ADR-005: CI/CD Cache Optimization](../architecture/adr-005-ci-cd-cache-optimization.md)** - Architectural decision record

---

**Status**: ✅ Current as of 2025-07-18. Based on ENG-736 performance optimization analysis.