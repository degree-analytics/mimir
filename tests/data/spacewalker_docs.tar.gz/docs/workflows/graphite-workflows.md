# Graphite (GT) Workflows

## Purpose
Comprehensive Graphite workflows for stack-based development using the `gt` CLI. Essential reference for managing stacked PRs, branch relationships, and professional development workflows that enhance code review quality and reduce merge complexity.

## When to Use This
- Managing multiple related features through stacked PRs
- Creating dependent branch workflows for large features
- Resolving complex merge conflicts across stacked branches
- Understanding Graphite's stack-based development model
- Training teams on modern PR workflows and stack management

**Keywords:** graphite, gt cli, stacked PRs, branch management, stack workflows, dependent branches

**Version:** 1.0 (Extracted from CLAUDE.md)
**Date:** 2025-06-29
**Status:** Current - Production Development Workflow

---

## 🎯 Graphite Fundamentals

### What Are Stacks?
**Stacks are chains of dependent branches** where each branch builds on the previous one:
```
main ← feature-1 ← feature-2 ← feature-3
```

- **Each branch = One focused change/PR**
- **Stack = Related changes that depend on each other**
- **Benefits:** Smaller PRs, parallel development, easier reviews

### Why Stacks vs Traditional Branching?
- **Traditional:** One massive PR with multiple unrelated changes
- **Stacked:** Multiple small, focused PRs that can be reviewed/merged independently
- **Result:** Faster reviews, easier debugging, better code quality

### Core GT Concepts
- **Trunk:** Main development branch (usually `dev` or `main`)
- **Stack:** Ordered chain of branches with parent/child relationships
- **Parent/Child:** Each branch (except trunk) has a parent; can have children
- **Sync:** Update branches with latest changes from trunk/parents

---

## 🚨 Critical Safety Rules

### RULE 1: USE GT, NOT GIT - ALWAYS
**You MUST use Graphite's `gt` CLI instead of raw `git` commands. Git bypasses Graphite's stack management.**

- **Default:** Use `gt` for ALL source control operations
- **Git is FORBIDDEN** except for read-only status checks (`git status`, `git diff`)
- **Why:** Git commands break Graphite's stack tracking and parent/child branch relationships
- **When in doubt:** Ask "Should I use gt for this?" (Answer is YES)

### RULE 2: NO SOURCE CONTROL COMMANDS WITHOUT PERMISSION
**You MUST NEVER run ANY gt or git commands without explicit user confirmation.**

- **Source Control:** NO `gt` or `git` commands without permission
- **ALWAYS ASK FIRST:** "Should I run [specific command]?" and wait for explicit "yes"

---

## 🔍 MANDATORY CONTEXT CHECKS (ALWAYS RUN FIRST)

**Before ANY gt operation, you MUST run these commands and report results:**

```bash
# 1. Check working directory status
git status

# 2. See current stack position and structure
gt log --stack

# 3. Confirm current branch
gt branch

# 4. Check if trunk is up to date
gt trunk && gt status
```

**You MUST report these results to user before proceeding with ANY gt operation.**

---

## 🎯 DECISION TREE: STACKED vs STANDALONE

### Use STACKED PRs when:
- **Building on previous work:** This change depends on uncommitted work
- **Related features:** Multiple PRs that are logically connected
- **Large feature breakdown:** Breaking big feature into smaller pieces
- **Already in a stack:** Currently on a non-trunk branch

### Use STANDALONE PRs when:
- **Independent bug fix:** Completely unrelated to current work
- **Hot fix:** Urgent fix that needs to go directly to main
- **New feature start:** Beginning completely new work
- **User explicitly requests:** "Make this a standalone PR"

### How to Decide:
1. **Ask user:** "Is this change related to existing work or completely independent?"
2. **Check current position:** If not on trunk, likely want to stack
3. **Consider urgency:** Hot fixes should be standalone
4. **When in doubt:** Ask user to choose

---

## 🚀 GT WORKFLOW PATTERNS

### Pattern A: Stacked Development (Building on Existing Work)
```bash
# 1. MANDATORY: Check context first
git status && gt log --stack && gt branch

# 2. Report current position to user, then ASK:
#    "Ready to create stacked branch with message: [proposed message]?"

# 3. Only after user confirms:
gt create --all --message "user provided commit message"

# 4. ASK USER: "Should I sync and submit the PR?"
# 5. Only if user confirms:
gt sync && gt submit
```

### Pattern B: Standalone Development (Independent Work)
```bash
# 1. MANDATORY: Check context first
git status && gt log --stack && gt branch

# 2. ASK USER: "Should I return to trunk for standalone PR?"
# 3. Only after user confirms:
gt trunk && gt sync

# 4. Make code changes as requested

# 5. ASK USER: "Ready to create standalone branch with message: [proposed message]?"
# 6. Only after user confirms:
gt create --all --message "user provided commit message"

# 7. ASK USER: "Should I sync and submit the PR?"
# 8. Only if user confirms:
gt sync && gt submit
```

### Pattern C: Emergency Hotfix
```bash
# 1. Check context
git status && gt log --stack

# 2. ASK USER: "This looks like a hotfix. Should I switch to main branch?"
# 3. Only after user confirms:
gt checkout main && gt sync

# 4. Make urgent fix

# 5. ASK USER: "Ready to create hotfix with message: [proposed message]?"
# 6. Create and submit immediately:
gt create --all --message "hotfix: user provided message"
gt sync && gt submit
```

---

## 🛠️ ESSENTIAL GT COMMANDS

### Navigation & Status
```bash
gt branch                    # Show current branch
gt log --stack              # Show stack structure and position
gt status                   # Show branch status vs parent
gt trunk                    # Switch to trunk branch (dev/main)
gt up [steps]              # Move up stack toward trunk
gt down [steps]            # Move down stack toward leaves
```

### Branch Operations
```bash
gt create --all --message "msg"    # Stage all changes, create branch, commit
gt modify --all                    # Amend current branch's commit
gt delete [branch]                 # Delete branch and restack children
gt sync                           # Update current branch with latest changes
gt restack                        # Fix stack relationships after conflicts
```

### PR Management
```bash
gt submit                   # Create/update PR for current branch
gt submit --stack          # Submit all PRs in current stack
gt draft                   # Mark PR as draft
gt ready                   # Mark PR as ready for review
```

### Multi-branch Operations
```bash
gt sync --stack            # Sync entire stack with trunk
gt modify --all --stack    # Amend all branches in stack
gt submit --stack          # Submit all PRs in stack
```

---

## ⚠️ RECOVERY & TROUBLESHOOTING

### When Stacks Get Messed Up
```bash
# Check what's wrong
gt log --stack

# Fix stack relationships
gt restack

# If still broken, ask user before proceeding
```

### 🚨 CRITICAL: NEVER USE REBASE DURING GT RESTACK
**When `gt restack` encounters merge conflicts:**
- ❌ **NEVER run `git rebase`** - This breaks GT's internal tracking
- ✅ **Use merge resolution** - Let GT handle the merge strategy
- ✅ **Use `gt continue`** after resolving conflicts manually
- ✅ **Use `gt abort`** if unsure and ask user for guidance

**Why rebase breaks GT:**
- GT maintains parent/child relationships between branches
- Rebase rewrites commit history, confusing GT's tracking
- Results in cascading conflicts across the entire stack
- Can make stack unrecoverable without manual intervention

### When Branches Conflict
```bash
# Sync to get latest changes
gt sync

# If conflicts occur, resolve manually then:
gt continue

# Or abort and ask user
gt abort
```

### When Lost in Stack
```bash
# See where you are
gt log --stack
gt branch

# Get back to trunk safely
gt trunk
```

---

## 🚨 CRITICAL ANTI-PATTERNS (NEVER DO THESE)

❌ **NEVER use git commands for branch operations** (breaks stack tracking)
❌ **NEVER run gt commands without asking user first**
❌ **NEVER assume stacked vs standalone - always ask**
❌ **NEVER skip context checks before gt operations**
❌ **NEVER proceed without explicit user approval**
❌ **NEVER work on main branch without double confirmation**
❌ **NEVER push to main/trunk without explicit user instruction**
❌ **NEVER use `git rebase` during gt restack operations** (breaks GT tracking)

---

## 🎯 WORKFLOW DECISION TEMPLATE

**Use this exact template before ANY gt operation:**

```
Current Status:
- Branch: [current branch name]
- Stack Position: [output of gt log --stack]
- Working Directory: [clean/modified files]

Question: [What user wants to accomplish]

My Assessment: [Stacked/Standalone reasoning]

Proposed Action: [Exact gt commands I want to run]

User, please confirm: [Yes/No]
```

**You MUST use this template and get explicit user approval before ANY gt operation.**

---

## 📋 Advanced Stack Management

### Managing Complex Stacks
```bash
# View detailed stack information
gt log --stack --oneline

# Reorder branches in a stack
gt move --onto <new-parent-branch>

# Split a branch into multiple commits
gt split

# Fold commits together
gt fold <commit-range>
```

### Stack Synchronization
```bash
# Sync entire stack with trunk changes
gt sync --stack

# Update just the current branch
gt sync

# Force sync when conflicts exist
gt sync --force
```

### Branch Cleanup
```bash
# Clean up merged branches
gt cleanup

# Delete specific branch and restack children
gt delete <branch-name>

# Archive completed stacks
gt archive --stack
```

---

## 🧪 Integration with Standard Git Workflows

### Compatibility with Existing Git Documentation
- **Commit Standards:** Follow [Git Commit Standards](./git-commit-standards.md) for all GT commits
- **Merge Strategy:** GT handles merging, but conflicts follow [Git Merge Strategy](./git-merge-strategy.md) principles
- **Branch Protection:** Works with GitHub branch protection and [Git Merge Strategy](./git-merge-strategy.md) safety rules

### When to Use Git vs GT
```bash
# ✅ Safe Git Commands (Read-only)
git status                  # Check working directory
git diff                   # Review changes
git log                    # View history

# ✅ GT Commands (All branch operations)
gt create                  # Create branches
gt submit                  # Submit PRs
gt sync                    # Update branches
gt delete                  # Remove branches
```

---

## 📊 Stack Quality Checklist

### Before Creating Stack
- [ ] Feature can be broken into logical, reviewable chunks
- [ ] Each branch in stack has clear, focused purpose
- [ ] Dependencies between branches are necessary and minimal
- [ ] Stack depth is reasonable (typically < 5 branches)

### During Stack Development
- [ ] Regular sync with trunk to minimize conflicts
- [ ] Each branch builds and tests independently
- [ ] Commit messages follow [Git Commit Standards](./git-commit-standards.md)
- [ ] PR descriptions clearly explain branch relationships

### Before Stack Submission
- [ ] All branches in stack have passing tests
- [ ] Stack order is logical and reviewable
- [ ] No circular dependencies between branches
- [ ] Ready for independent review and potential cherry-picking

---

## 📊 Analytics & Monitoring Considerations

When working with stacked PRs, keep in mind:
- **Feature flags**: Consider using feature flags (e.g., PostHog) to control rollout of stacked features
- **Metrics tracking**: Each PR in a stack can have its own metrics for A/B testing
- **Gradual rollout**: Stacks enable deploying foundation work before user-facing features
- **Monitoring**: Track the impact of each layer in your stack independently

---

## 📋 Related Development Documentation

### Git Workflow Integration
- **[Git Commit Standards](./git-commit-standards.md)** - Commit message formatting for GT operations
- **[Git Merge Strategy](./git-merge-strategy.md)** - Conflict resolution principles for GT stacks
- **[Development Setup](../setup/development-setup.md)** - Environment configuration including GT setup

### Development Workflows
- **[Testing Guide](./testing-guide.md)** - Quality assurance for stacked development
- **[Deployment Guide](./deployment-guide.md)** - Deploying stacked features to production

### Platform-Specific Integration
> 🚀 **Backend Teams**: GT stacks work seamlessly with [Backend Development](../backend/development/) workflows
> 🚀 **Admin Teams**: Perfect for [Admin Development](../admin/development/) feature iterations
> 🚀 **Mobile Teams**: Ideal for [Mobile Development](../mobile/development/) component development

---

**Status**: ✅ **PRODUCTION DEVELOPMENT WORKFLOW**
**Last Updated**: 2025-06-29
**Applies To**: All Spacewalker development teams using stack-based development
**Integration**: Git workflows, Pull Request processes, CI/CD pipelines

---

*This Graphite workflow guide enables professional stack-based development that improves code review quality, reduces merge complexity, and accelerates feature delivery across all Spacewalker teams.*
