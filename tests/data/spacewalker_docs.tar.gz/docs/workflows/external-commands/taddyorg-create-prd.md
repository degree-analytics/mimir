# TaddyOrg's Create PRD Command

## Original Command
Create a Product Requirements Document (PRD) as an experienced Product Manager.

## Key Principles
- "Focus on the feature and the user needs, not the technical implementation"
- "Do not include any time estimates"
- Capture "the what, why, and how of the product"

## Process
1. **Preparation Steps**:
   - Read product documentation in `product-development/resources/product.md`
   - Read feature documentation in `product-development/current-feature/feature.md`
   - Read Jobs to be Done (JTBD) documentation in `product-development/current-feature/JTBD.md`

2. **PRD Creation**:
   - Use PRD template from `product-development/resources/PRD-template.md`
   - Output final PRD in `product-development/current-feature/PRD.md`

## Focus Areas
- User needs and value proposition
- Product requirements and acceptance criteria
- User experience considerations
- Success metrics and definitions

## Implementation Notes
- Template-driven approach ensures consistency
- Structured documentation hierarchy
- Clear separation between product and technical concerns