# TEVM's Commit Command

## Original Command
```
/commit
/commit --no-verify
```

## Purpose
Create well-structured git commits with conventional commit messages, emojis, and automated pre-commit checks.

## Features
- Conventional commit messages with emojis
- Automatic pre-commit checks (lint, build, documentation)
- Analyzes changes to suggest potential commit splitting
- Supports various commit types: feat, fix, docs, etc.

## Commit Message Best Practices
- Use present tense, imperative mood
- Keep first line under 72 characters
- Match emoji to commit type (✨ for features, 🐛 for bug fixes)
- Focus on atomic, logical commits

## Examples
- "✨ feat: add user authentication system"
- "🐛 fix: resolve memory leak in rendering process"
- "📝 docs: update API documentation"

## Implementation
- Analyzes current git changes
- Suggests commit splitting if needed
- Runs pre-commit validation
- Creates structured commit messages