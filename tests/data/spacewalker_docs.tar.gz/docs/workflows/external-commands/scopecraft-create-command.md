# Scopecraft's Create Command

## Original Command
Comprehensive guide for creating Claude commands within the Scopecraft project.

## Five Key Phases

### 1. Understanding Purpose
- Identify the command's problem and target users
- Determine expected output and interaction style

### 2. Category Classification
- Classify command type (e.g., planning, implementation, analysis)
- Determine if mode variations are needed

### 3. Pattern Selection
- Study similar existing commands
- Analyze their structure, MCP tool usage, and documentation

### 4. Command Location
- Choose between project-specific or user-level command
- Consider scope and reusability

### 5. Resource Planning
- Create supporting files and documentation
- Update relevant guides and references

## Key Principles
- Always use MCP tools instead of direct CLI commands
- Reference organizational structure documents
- Include human review sections
- Follow established patterns from similar commands

## Implementation
- Provides detailed checklist and example workflow
- Ensures consistent and high-quality command creation
- Systematic approach to command development