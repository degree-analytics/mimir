# Berry's Add to Changelog Command

## Original Command
```
/add-to-changelog <version> <change_type> <message>
```

## Purpose
Update the project's CHANGELOG.md file with version-specific changes following "Keep a Changelog" and "Semantic Versioning" conventions.

## Usage
- `/add-to-changelog 1.1.0 added "New markdown to BlockDoc conversion feature"`
- Change types: "added", "changed", "deprecated", "removed", "fixed", "security"

## Implementation Notes
- Automatically creates/updates changelog sections
- Parses arguments to determine version and change type
- Suggests version commits after changelog updates
- Follows standardized changelog format

## Key Features
- Standardizes changelog maintenance
- Minimal manual intervention required
- Follows semantic versioning conventions
- Supports all standard change types