# ast-grep Troubleshooting Guide

## Purpose
Comprehensive troubleshooting guide for diagnosing and resolving ast-grep integration issues in SpaceWalker, providing systematic problem-solving approaches, common error patterns, performance debugging, and escalation procedures for development and operations teams.

## When to Use This
- ast-grep execution failures or errors
- Performance degradation or timeout issues
- Security rule violations that need resolution
- CI/CD pipeline failures related to ast-grep
- Configuration problems or integration issues
- Memory usage or resource exhaustion problems

**Keywords:** ast-grep troubleshooting, debugging, error resolution, performance issues, security violations, CI/CD problems

**Version:** 1.0
**Date:** 2025-09-09
**Status:** Active - Production Support

---

## Quick Navigation

### Immediate Problem Resolution
- [Quick Diagnostic Commands](#quick-diagnostic-commands) - First-line debugging
- [Common Error Patterns](#common-error-patterns) - Frequent issues and fixes
- [Emergency Procedures](#emergency-procedures) - Critical failure recovery

### Systematic Troubleshooting
- [Performance Issues](#performance-troubleshooting) - Speed and resource problems
- [Configuration Problems](#configuration-troubleshooting) - Setup and settings
- [Rule Development Issues](#rule-development-troubleshooting) - Custom rule problems

### Advanced Diagnostics
- [CI/CD Pipeline Issues](#cicd-pipeline-troubleshooting) - Automated workflow problems
- [Integration Problems](#integration-troubleshooting) - SpaceWalker compatibility
- [Escalation Procedures](#escalation-and-support) - When to seek help

---

## Quick Diagnostic Commands

### First-Line Health Checks
```bash
# 1. Verify ast-grep installation and version
ast-grep --version
which ast-grep

# 2. Check SpaceWalker configuration
ls -la .ast-grep/sgconfig.yml
cat .ast-grep/sgconfig.yml

# 3. Test basic functionality
just lint check astgrep

# 4. Validate rule syntax
sg check --config .ast-grep/sgconfig.yml
```

### Performance Quick Check
```bash
# Run performance benchmark
python3 scripts/helpers/benchmark_astgrep.py --report

# Check for file filtering issues
python3 scripts/helpers/benchmark_astgrep.py --file-analysis

# Monitor memory usage during execution
/usr/bin/time -v just lint check astgrep
```

### Error Information Gathering
```bash
# Collect comprehensive diagnostic information
cat > collect_diagnostics.sh << 'EOF'
#!/bin/bash
echo "=== ast-grep Diagnostic Information ==="
echo "Date: $(date)"
echo "System: $(uname -a)"
echo

echo "=== ast-grep Version ==="
ast-grep --version 2>&1

echo "=== Configuration ==="
cat .ast-grep/sgconfig.yml 2>&1

echo "=== Rule Files ==="
find .ast-grep/rules -name "*.yml" -type f | head -20

echo "=== Recent Execution ==="
just lint check astgrep 2>&1 | head -50

echo "=== Performance Benchmark ==="
python3 scripts/helpers/benchmark_astgrep.py --quick 2>&1
EOF

chmod +x collect_diagnostics.sh
./collect_diagnostics.sh > ast-grep-diagnostics.txt
```

---

## Common Error Patterns

### 1. Installation and Setup Issues

#### Error: `command not found: ast-grep`
**Symptom**:
```bash
$ just lint check astgrep
bash: ast-grep: command not found
Error: ast-grep binary not available
```

**Root Cause Analysis**:
- ast-grep binary not installed on system
- PATH environment variable doesn't include installation directory
- Installation incomplete or corrupted

**Solutions** (in order of preference):
```bash
# Solution 1: Install via Rust Cargo (recommended)
cargo install ast-grep
# Verify: ~/.cargo/bin should be in PATH

# Solution 2: Install via Homebrew (macOS)
brew install ast-grep
# Verify: /usr/local/bin/ast-grep or /opt/homebrew/bin/ast-grep

# Solution 3: Manual binary installation
curl -L https://github.com/ast-grep/ast-grep/releases/latest/download/ast-grep-x86_64-unknown-linux-gnu.zip -o ast-grep.zip
unzip ast-grep.zip
sudo mv sg /usr/local/bin/ast-grep
chmod +x /usr/local/bin/ast-grep

# Solution 4: Verify PATH configuration
echo $PATH
which ast-grep
# Add to ~/.bashrc or ~/.zshrc if needed:
# export PATH="$HOME/.cargo/bin:$PATH"
```

**Verification**:
```bash
# Test installation
ast-grep --version
# Expected: ast-grep 0.x.x

# Test basic functionality
echo 'console.log("test")' | ast-grep -p 'console.log($A)'
# Expected: Match found
```

#### Error: `Configuration file not found`
**Symptom**:
```bash
$ just lint check astgrep
Error: Configuration file .ast-grep/sgconfig.yml not found
```

**Root Cause Analysis**:
- Working directory doesn't contain ast-grep configuration
- Configuration file corrupted or moved
- Git repository state issues

**Solutions**:
```bash
# Solution 1: Verify current directory
pwd
ls -la .ast-grep/
# Should be in SpaceWalker root directory

# Solution 2: Check git status
git status .ast-grep/
git ls-files .ast-grep/sgconfig.yml

# Solution 3: Restore from git if missing
git checkout HEAD -- .ast-grep/sgconfig.yml

# Solution 4: Verify configuration syntax
yaml-lint .ast-grep/sgconfig.yml  # If available
# or
python3 -c "import yaml; yaml.safe_load(open('.ast-grep/sgconfig.yml'))"
```

### 2. Performance Issues

#### Error: `Execution timeout (>30s)`
**Symptom**:
```bash
$ just lint check astgrep
Scanning files... (this may take a while)
[30 seconds pass]
Error: ast-grep execution timed out
Performance Summary: NOT GENERATED (timeout)
```

**Root Cause Analysis**:
```bash
# Diagnose root cause
python3 scripts/helpers/benchmark_astgrep.py --diagnose

# Check file count being processed
python3 scripts/helpers/benchmark_astgrep.py --file-analysis

# Expected healthy output:
# Files scanned: 969 (should be <2000)
# Execution time: <5s
```

**Common Causes and Solutions**:

**Cause 1: File filtering ineffective**
```bash
# Diagnosis: Check if too many files being processed
python3 scripts/helpers/benchmark_astgrep.py --file-analysis
# Look for: Files scanned: >5000

# Solution: Update ignore patterns in sgconfig.yml
ignore:
  - "node_modules/**"      # Add missing patterns
  - ".venv/**"
  - "build/**"
  - "dist/**"
  - "coverage/**"
  - "vendor/**"            # Add new directories
  - "*.min.js"             # Add file patterns
```

**Cause 2: Complex rule patterns**
```bash
# Diagnosis: Identify slow rules
python3 scripts/helpers/benchmark_astgrep.py --per-rule
# Look for: Rules taking >5s individually

# Solution: Optimize complex patterns
# Before (slow):
rule:
  kind: string
  regex: '.*password.*|.*secret.*|.*key.*|.*token.*|.*credential.*'

# After (fast):
rule:
  kind: string
  pattern: |
    any:
      - "password"
      - "secret"
      - "key"
      - "token"
```

**Cause 3: System resource constraints**
```bash
# Diagnosis: Check system resources
free -h                    # Available memory
nproc                     # Available CPU cores
df -h .                   # Available disk space

# Solution: Adjust worker configuration
# In lint_manager.py, reduce workers if needed:
max_workers = min(len(rule_directories), 4)  # Reduce from 8 to 4
```

#### Error: `Memory usage exceeded limit`
**Symptom**:
```bash
$ just lint check astgrep
Performance Summary:
  • Process memory: 523.4MB (target: <500MB) ❌
  • Memory regression detected
```

**Root Cause Analysis**:
```bash
# Memory analysis
python3 scripts/helpers/benchmark_astgrep.py --memory-profile

# Check for memory leaks
valgrind python3 scripts/helpers/lint_manager.py check astgrep  # If available
```

**Solutions**:
```bash
# Solution 1: Reduce batch processing size
# In lint_manager.py, modify batch_size parameter
batch_size = 50  # Reduce from 100

# Solution 2: Enable garbage collection
import gc
gc.collect()  # Add after each rule processing

# Solution 3: Use streaming processing
# Process files in smaller chunks
for file_batch in chunk_files(files, chunk_size=25):
    process_batch(file_batch)
    gc.collect()
```

### 3. Rule Syntax and Processing Issues

#### Error: `Invalid rule syntax`
**Symptom**:
```bash
$ sg test --rule .ast-grep/rules/security/new-rule.yml
Error: Invalid rule syntax at line 15:
  pattern: $INVALID_PATTERN
```

**Root Cause Analysis**:
```yaml
# Common syntax errors in rules:

# Error 1: Invalid YAML indentation
rule:
kind: call          # ❌ Missing indentation
  pattern: $FUNC()  # ❌ Inconsistent indentation

# Error 2: Incorrect ast-grep pattern syntax
rule:
  pattern: $FUNC($ARGS)  # ❌ Should use specific pattern
  # ✅ Correct:
  kind: call
  pattern: $FUNC($ARGS)

# Error 3: Unsupported language features
language: python
rule:
  kind: jsx_element    # ❌ JSX in Python rule
```

**Solutions**:
```bash
# Step 1: Validate YAML syntax
python3 -c "
import yaml
try:
    with open('.ast-grep/rules/security/new-rule.yml') as f:
        yaml.safe_load(f)
    print('✅ YAML syntax valid')
except yaml.YAMLError as e:
    print(f'❌ YAML error: {e}')
"

# Step 2: Test rule pattern
sg test --rule .ast-grep/rules/security/new-rule.yml

# Step 3: Validate against test cases
# Create test file with known matches
echo 'problematic_pattern()' > test_input.py
sg scan --rule .ast-grep/rules/security/new-rule.yml test_input.py
```

#### Error: `Rule produces no matches`
**Symptom**:
```bash
$ sg scan --rule .ast-grep/rules/security/my-rule.yml apps/backend/
No matches found (expected matches based on manual review)
```

**Debugging Approach**:
```bash
# Step 1: Test with minimal example
echo 'def problematic_function():
    password = "hardcoded"
    return password' > minimal_test.py

sg scan --rule .ast-grep/rules/security/my-rule.yml minimal_test.py

# Step 2: Debug pattern matching
# Add debug information to rule
rule:
  kind: assignment
  pattern: $VAR = $VALUE
  debug: true  # Enable debug output

# Step 3: Test pattern variations
# Try simpler patterns first
rule:
  kind: string
  pattern: '"hardcoded"'  # Simple string match first
```

### 4. CI/CD Pipeline Issues

#### Error: `GitHub Actions workflow fails`
**Symptom**:
```yaml
# In GitHub Actions log:
Run python3 scripts/helpers/lint_manager.py check astgrep
Error: ast-grep binary not found in CI environment
Process completed with exit code 127
```

**Root Cause Analysis**:
- ast-grep not installed in CI environment
- Wrong architecture (x86_64 vs ARM64)
- Binary installation step failed silently

**Solutions**:
```yaml
# Solution 1: Robust installation in workflow
- name: Install ast-grep (robust)
  run: |
    # Detect architecture
    ARCH=$(uname -m)
    case $ARCH in
      x86_64) ARCH_SUFFIX="x86_64-unknown-linux-gnu" ;;
      aarch64) ARCH_SUFFIX="aarch64-unknown-linux-gnu" ;;
      *) echo "Unsupported architecture: $ARCH"; exit 1 ;;
    esac

    # Download and install
    curl -L "https://github.com/ast-grep/ast-grep/releases/latest/download/ast-grep-${ARCH_SUFFIX}.zip" -o ast-grep.zip
    unzip ast-grep.zip
    chmod +x sg
    sudo mv sg /usr/local/bin/ast-grep

    # Verify installation
    ast-grep --version

# Solution 2: Use pre-built action (if available)
- name: Setup ast-grep
  uses: ast-grep/setup-ast-grep@v1
  with:
    version: 'latest'

# Solution 3: Cache installation for speed
- name: Cache ast-grep
  uses: actions/cache@v3
  with:
    path: ~/.local/bin/ast-grep
    key: ast-grep-${{ runner.os }}-${{ hashFiles('**/package.json') }}
```

#### Error: `Performance regression in CI`
**Symptom**:
```yaml
# GitHub Actions output:
⚠️ Performance regression detected: 4.2s > 3.0s threshold
⚠️ Memory regression detected: 1.8MB > 1.0MB threshold
```

**Diagnosis Steps**:
```bash
# Step 1: Compare with baseline
python3 scripts/helpers/benchmark_astgrep.py --ci --compare-baseline

# Step 2: Identify cause
python3 scripts/helpers/benchmark_astgrep.py --regression-analysis

# Step 3: Check recent changes
git log --oneline -10 .ast-grep/
git diff HEAD~5 .ast-grep/
```

**Common Causes and Fixes**:
```bash
# Cause 1: New files not filtered
# Check .ast-grep/sgconfig.yml for missing patterns
git diff HEAD~1 .ast-grep/sgconfig.yml

# Cause 2: New complex rules added
# Check for new rules with expensive patterns
find .ast-grep/rules -name "*.yml" -newer /tmp/baseline -type f

# Cause 3: CI environment changes
# Verify CI runner resources
echo "Runner specs: ${{ runner.os }}, cores: $(nproc)"
```

---

## Performance Troubleshooting

### Systematic Performance Analysis

#### Performance Diagnostic Workflow
```bash
# Step 1: Establish baseline
python3 scripts/helpers/benchmark_astgrep.py --full-scan > baseline_performance.txt

# Step 2: Analyze current performance
python3 scripts/helpers/benchmark_astgrep.py --report --compare baseline_performance.txt

# Step 3: Identify bottlenecks
python3 scripts/helpers/benchmark_astgrep.py --profile --per-rule --file-analysis

# Step 4: Test optimizations
# Apply fixes and retest
python3 scripts/helpers/benchmark_astgrep.py --validate-optimizations
```

#### Performance Issue Categories

**Category 1: File Filtering Inefficiencies**
```bash
# Symptoms
Files scanned: >2000 (target: ~1000)
Execution time: >5s (target: ~2s)

# Diagnosis
python3 scripts/helpers/benchmark_astgrep.py --file-analysis
# Output analysis:
# - Total files in repository: 116,925
# - Filtered files: 2,340 (97.9% filtered) ❌ Should be >99%
# - File types breakdown: Check for unexpected inclusions

# Common causes:
1. New file extensions not filtered
2. New build directories not excluded
3. Temporary files not ignored
4. Test fixtures included in scan

# Solutions:
# Update .ast-grep/sgconfig.yml
ignore:
  - "**/*.log"           # Log files
  - "**/*.tmp"           # Temporary files
  - "test-fixtures/**"   # Test data
  - "vendor/**"          # Third-party code
  - "*.generated.py"     # Generated files
```

**Category 2: Rule Performance Issues**
```bash
# Symptoms
Per-rule time: >2s for individual rules
Total time dominated by 1-2 rules

# Diagnosis
python3 scripts/helpers/benchmark_astgrep.py --per-rule
# Look for rules taking >30% of total time

# Example problematic output:
security/complex-pattern: 3.2s (94% of total time) ❌
security/simple-pattern: 0.1s
security/another-pattern: 0.2s

# Solutions:
# Optimize complex patterns
# Before:
rule:
  pattern: $FUNC($ARGS)
  has:
    field: any
    regex: '.*secret.*|.*password.*|.*key.*|.*token.*'

# After:
rule:
  kind: call
  pattern: dangerous_function($SECRET)
  where:
    SECRET:
      kind: string
      matches: '^(secret|password|key|token)'
```

**Category 3: System Resource Constraints**
```bash
# Symptoms
Memory usage approaching system limits
High CPU usage during execution
I/O wait times elevated

# Diagnosis
# System monitoring during execution
htop &                          # Monitor CPU/Memory
iotop &                         # Monitor I/O (if available)
just lint check astgrep         # Run the scan
pkill htop iotop

# Memory-specific analysis
python3 scripts/helpers/benchmark_astgrep.py --memory-profile
# Look for:
# - Memory growth during execution
# - Peak memory usage >100MB
# - Memory not released after completion

# Solutions:
# Reduce parallel workers
max_workers = min(len(rule_directories), 4)  # Reduce from 8

# Implement memory limits
import resource
resource.setrlimit(resource.RLIMIT_AS, (200*1024*1024, -1))  # 200MB limit

# Add garbage collection
import gc
gc.collect()  # After each rule processing batch
```

### Advanced Performance Optimization

#### Custom Performance Profiling
```python
# Create custom_profiler.py for advanced analysis
import cProfile
import pstats
import io
from contextlib import contextmanager

@contextmanager
def performance_profile(filename=None):
    """Context manager for detailed performance profiling."""
    profiler = cProfile.Profile()
    profiler.enable()

    try:
        yield profiler
    finally:
        profiler.disable()

        # Generate detailed stats
        stats_buffer = io.StringIO()
        stats = pstats.Stats(profiler, stream=stats_buffer)
        stats.sort_stats('cumulative')
        stats.print_stats(20)  # Top 20 functions

        profile_output = stats_buffer.getvalue()

        if filename:
            with open(filename, 'w') as f:
                f.write(profile_output)
        else:
            print(profile_output)

# Usage:
from custom_profiler import performance_profile

with performance_profile('ast_grep_profile.txt'):
    # Run ast-grep operations
    subprocess.run(['just', 'lint', 'check', 'astgrep'])
```

#### Memory Leak Detection
```python
# Create memory_tracker.py for leak detection
import tracemalloc
import psutil
import gc
from typing import Dict, List
from dataclasses import dataclass

@dataclass
class MemorySnapshot:
    timestamp: float
    traced_memory: int
    process_memory: int
    top_allocations: List[str]

class MemoryLeakDetector:
    def __init__(self):
        self.snapshots = []
        self.process = psutil.Process()
        tracemalloc.start()

    def take_snapshot(self, label: str = "") -> MemorySnapshot:
        # Get current memory info
        traced_current, traced_peak = tracemalloc.get_traced_memory()
        process_memory = self.process.memory_info().rss

        # Get top memory allocations
        snapshot = tracemalloc.take_snapshot()
        top_stats = snapshot.statistics('lineno')[:10]
        top_allocations = [
            f"{stat.traceback.format()[-1]}: {stat.size / 1024 / 1024:.1f}MB"
            for stat in top_stats
        ]

        memory_snapshot = MemorySnapshot(
            timestamp=time.time(),
            traced_memory=traced_current,
            process_memory=process_memory,
            top_allocations=top_allocations
        )

        self.snapshots.append((label, memory_snapshot))
        return memory_snapshot

    def detect_leaks(self) -> Dict:
        if len(self.snapshots) < 2:
            return {"error": "Need at least 2 snapshots"}

        # Compare first and last snapshots
        start_snapshot = self.snapshots[0][1]
        end_snapshot = self.snapshots[-1][1]

        memory_growth = end_snapshot.process_memory - start_snapshot.process_memory
        growth_rate = memory_growth / (end_snapshot.timestamp - start_snapshot.timestamp)

        return {
            "memory_growth_mb": memory_growth / 1024 / 1024,
            "growth_rate_mb_per_sec": growth_rate / 1024 / 1024,
            "leak_suspected": memory_growth > 50 * 1024 * 1024,  # 50MB growth
            "snapshots": len(self.snapshots)
        }

# Usage example:
detector = MemoryLeakDetector()

detector.take_snapshot("start")
# Run ast-grep operations
subprocess.run(['just', 'lint', 'check', 'astgrep'])
detector.take_snapshot("after_first_run")

# Run again to check for accumulation
subprocess.run(['just', 'lint', 'check', 'astgrep'])
detector.take_snapshot("after_second_run")

leak_report = detector.detect_leaks()
print(f"Leak detection report: {leak_report}")
```

---

## Configuration Troubleshooting

### Configuration File Issues

#### Invalid YAML Syntax
**Common YAML Problems**:
```yaml
# Problem 1: Inconsistent indentation
ruleDirs:
  - rules/security
- rules/api-design    # ❌ Wrong indentation

# Fix:
ruleDirs:
  - rules/security
  - rules/api-design  # ✅ Consistent indentation

# Problem 2: Missing quotes for special characters
ignore:
  - node_modules/**   # ❌ Unquoted special characters

# Fix:
ignore:
  - "node_modules/**" # ✅ Quoted pattern

# Problem 3: Invalid language configuration
languageGlobs:
  python: *.py        # ❌ Should be array

# Fix:
languageGlobs:
  python: ["*.py"]    # ✅ Correct array syntax
```

**YAML Validation Script**:
```bash
# Create yaml_validator.py
import yaml
import sys

def validate_yaml_file(filename):
    try:
        with open(filename, 'r') as file:
            config = yaml.safe_load(file)

        # Validate required sections
        required_sections = ['ruleDirs', 'languageGlobs']
        for section in required_sections:
            if section not in config:
                print(f"❌ Missing required section: {section}")
                return False

        # Validate rule directories exist
        for rule_dir in config['ruleDirs']:
            rule_path = f".ast-grep/{rule_dir}"
            if not os.path.exists(rule_path):
                print(f"❌ Rule directory not found: {rule_path}")
                return False

        print("✅ YAML configuration is valid")
        return True

    except yaml.YAMLError as e:
        print(f"❌ YAML syntax error: {e}")
        return False
    except FileNotFoundError:
        print(f"❌ Configuration file not found: {filename}")
        return False

# Usage:
python3 yaml_validator.py .ast-grep/sgconfig.yml
```

### Rule Directory Structure Issues

#### Missing Rule Files
**Problem**: Rules referenced but files missing
```bash
# Symptoms
$ sg check --config .ast-grep/sgconfig.yml
Error: Rule file not found: rules/security/missing-rule.yml

# Diagnosis
find .ast-grep/rules -name "*.yml" -type f | sort
# Compare with sgconfig.yml ruleDirs configuration

# Find missing rules
for rule_dir in $(grep -A 10 "ruleDirs:" .ast-grep/sgconfig.yml | grep "^  -" | sed 's/^  - //'); do
    if [ ! -d ".ast-grep/$rule_dir" ]; then
        echo "❌ Missing directory: .ast-grep/$rule_dir"
    fi
done
```

**Solutions**:
```bash
# Solution 1: Create missing directories
mkdir -p .ast-grep/rules/api-design
mkdir -p .ast-grep/rules/mobile
mkdir -p .ast-grep/rules/admin
mkdir -p .ast-grep/rules/common

# Solution 2: Update configuration to match existing structure
# Edit .ast-grep/sgconfig.yml to only include existing directories

# Solution 3: Restore from git if accidentally deleted
git status .ast-grep/rules/
git checkout HEAD -- .ast-grep/rules/missing-directory/
```

#### Rule File Permissions
**Problem**: Rules files not readable
```bash
# Symptoms
$ just lint check astgrep
Error: Permission denied reading rule file

# Diagnosis
ls -la .ast-grep/rules/security/
# Look for files with incorrect permissions (not readable)

# Solution
chmod 644 .ast-grep/rules/security/*.yml
chmod 755 .ast-grep/rules/security/
```

### Language Configuration Issues

#### Unsupported File Extensions
**Problem**: Files not being scanned due to missing language configuration
```bash
# Symptoms
Expected violations not found in .vue files or .tsx files

# Diagnosis
python3 scripts/helpers/benchmark_astgrep.py --file-analysis
# Check "Files by extension" section

# Solution: Add missing extensions
languageGlobs:
  typescript: ["*.ts", "*.tsx", "*.vue"]  # Add .vue for Vue.js
  javascript: ["*.js", "*.jsx", "*.mjs"]  # Add .mjs for modules
  python: ["*.py", "*.pyi"]               # Add .pyi for type stubs
```

---

## Rule Development Troubleshooting

### Rule Creation and Testing Issues

#### Rule Pattern Not Matching Expected Code
**Problem**: Rule written but doesn't match known violations

**Debugging Approach**:
```bash
# Step 1: Create minimal test case
cat > test_case.py << 'EOF'
# This should match your rule
def problematic_function():
    password = "hardcoded_secret"
    return password
EOF

# Step 2: Test rule against minimal case
sg scan --rule .ast-grep/rules/security/your-rule.yml test_case.py

# Step 3: Debug pattern step by step
# Start with broad pattern, narrow down
rule:
  # Start broad
  kind: assignment

  # Add specificity gradually
  pattern: $VAR = $VALUE

  # Add constraints
  where:
    VALUE:
      kind: string
      matches: "secret"
```

**Pattern Development Workflow**:
```yaml
# Phase 1: Broad matching
rule:
  kind: any  # Match anything initially

# Phase 2: Narrow by node type
rule:
  kind: assignment  # Only assignments

# Phase 3: Add pattern matching
rule:
  kind: assignment
  pattern: $VAR = $VALUE

# Phase 4: Add constraints
rule:
  kind: assignment
  pattern: $VAR = $VALUE
  where:
    VAR:
      matches: "(password|secret|key)"
    VALUE:
      kind: string
```

#### Rule Performance Issues
**Problem**: New rule causes significant slowdown

**Performance Testing**:
```bash
# Benchmark before adding rule
python3 scripts/helpers/benchmark_astgrep.py --per-rule > before_rule.txt

# Add new rule and benchmark again
python3 scripts/helpers/benchmark_astgrep.py --per-rule > after_rule.txt

# Compare results
diff before_rule.txt after_rule.txt

# Look for:
# - New rule taking >1s individually
# - Total time increasing >50%
# - Memory usage increasing significantly
```

**Rule Optimization Strategies**:
```yaml
# Slow pattern (avoid complex regex)
rule:
  kind: string
  regex: '.*(password|secret|key|token|credential|auth|login|pass).*'

# Faster pattern (specific matching)
rule:
  kind: string
  pattern: |
    any:
      - "password"
      - "secret"
      - "key"
      - "token"

# Even faster (target specific contexts)
rule:
  kind: assignment
  pattern: $VAR = $SECRET
  where:
    VAR:
      matches: "password"
    SECRET:
      kind: string
```

### Rule Testing and Validation

#### Comprehensive Rule Testing Framework
```bash
# Create rule_tester.py for thorough testing
cat > scripts/helpers/rule_tester.py << 'EOF'
#!/usr/bin/env python3
"""Comprehensive rule testing framework."""

import subprocess
import tempfile
import yaml
from pathlib import Path
from typing import List, Dict, Any

class RuleTester:
    def __init__(self, rule_file: str):
        self.rule_file = rule_file
        self.rule_config = self.load_rule_config()

    def load_rule_config(self) -> Dict[str, Any]:
        with open(self.rule_file, 'r') as f:
            return yaml.safe_load(f)

    def test_positive_cases(self, test_cases: List[str]) -> Dict[str, bool]:
        """Test cases that SHOULD match the rule."""
        results = {}

        for i, test_case in enumerate(test_cases):
            case_name = f"positive_case_{i+1}"
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(test_case)
                f.flush()

                # Test if rule matches
                result = subprocess.run([
                    'sg', 'scan', '--rule', self.rule_file, f.name
                ], capture_output=True, text=True)

                # Should have matches (exit code 0 with output)
                has_matches = result.returncode == 0 and result.stdout.strip()
                results[case_name] = has_matches

                if not has_matches:
                    print(f"❌ {case_name}: Expected match but got none")
                    print(f"   Test case: {test_case[:50]}...")

        return results

    def test_negative_cases(self, test_cases: List[str]) -> Dict[str, bool]:
        """Test cases that should NOT match the rule."""
        results = {}

        for i, test_case in enumerate(test_cases):
            case_name = f"negative_case_{i+1}"
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(test_case)
                f.flush()

                result = subprocess.run([
                    'sg', 'scan', '--rule', self.rule_file, f.name
                ], capture_output=True, text=True)

                # Should have NO matches
                has_no_matches = not result.stdout.strip()
                results[case_name] = has_no_matches

                if not has_no_matches:
                    print(f"❌ {case_name}: Expected no match but got match")
                    print(f"   Test case: {test_case[:50]}...")
                    print(f"   Match: {result.stdout.strip()}")

        return results

    def performance_test(self) -> Dict[str, float]:
        """Test rule performance."""
        import time

        # Create larger test file
        test_content = """
        def function1():
            password = "secret123"
            return password

        def function2():
            user = get_user()
            return user.data
        """ * 100  # Repeat 100 times

        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(test_content)
            f.flush()

            # Time the execution
            start_time = time.perf_counter()
            result = subprocess.run([
                'sg', 'scan', '--rule', self.rule_file, f.name
            ], capture_output=True, text=True)
            end_time = time.perf_counter()

            execution_time = end_time - start_time

        return {
            'execution_time': execution_time,
            'matches_found': len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0,
            'performance_grade': 'PASS' if execution_time < 1.0 else 'SLOW'
        }

# Usage example
if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        print("Usage: python3 rule_tester.py <rule_file>")
        sys.exit(1)

    rule_file = sys.argv[1]
    tester = RuleTester(rule_file)

    # Define test cases
    positive_cases = [
        'password = "hardcoded"',
        'SECRET_KEY = "sk-1234567890"',
        'api_key = "secret123"'
    ]

    negative_cases = [
        'password = os.getenv("PASSWORD")',
        'SECRET_KEY = get_secret()',
        'api_key = config.get_api_key()'
    ]

    # Run tests
    print(f"Testing rule: {rule_file}")
    print("=" * 50)

    positive_results = tester.test_positive_cases(positive_cases)
    negative_results = tester.test_negative_cases(negative_cases)
    performance_results = tester.performance_test()

    # Summary
    positive_pass = sum(positive_results.values())
    negative_pass = sum(negative_results.values())

    print(f"\nTest Results:")
    print(f"Positive cases: {positive_pass}/{len(positive_cases)} passed")
    print(f"Negative cases: {negative_pass}/{len(negative_cases)} passed")
    print(f"Performance: {performance_results['performance_grade']} ({performance_results['execution_time']:.3f}s)")

    if positive_pass == len(positive_cases) and negative_pass == len(negative_cases):
        print("✅ All tests passed!")
    else:
        print("❌ Some tests failed!")
        sys.exit(1)
EOF

chmod +x scripts/helpers/rule_tester.py

# Test a specific rule
python3 scripts/helpers/rule_tester.py .ast-grep/rules/security/env-var-security.yml
```

---

## CI/CD Pipeline Troubleshooting

### GitHub Actions Workflow Issues

#### Workflow Permission Problems
**Problem**: GitHub Actions can't access repository or write comments

**Symptoms**:
```yaml
# In GitHub Actions log:
Error: Resource not accessible by integration
Error: 403 Forbidden - insufficient permissions
```

**Solutions**:
```yaml
# Add required permissions to workflow
name: ast-grep Security Analysis
on: [push, pull_request]

permissions:
  contents: read          # Read repository content
  pull-requests: write    # Comment on PRs
  checks: write           # Create check runs
  actions: read           # Access other workflow runs

jobs:
  ast-grep-security:
    runs-on: ubuntu-latest
    # ... rest of workflow
```

#### Environment-Specific Issues
**Problem**: Different behavior between local and CI environments

**Common Differences**:
```bash
# Local Environment:
- macOS/Windows vs Linux
- Different Python versions
- Different file permissions
- Local configuration files

# CI Environment:
- Clean environment each run
- Limited resources
- No cached dependencies
- Strict timeout limits
```

**Debugging CI Issues**:
```yaml
# Add debugging steps to workflow
- name: Debug Environment
  run: |
    echo "Environment Information:"
    echo "OS: ${{ runner.os }}"
    echo "Python: $(python3 --version)"
    echo "Working Directory: $(pwd)"
    echo "Available Memory: $(free -h)"
    echo "Available Disk: $(df -h .)"
    echo "File Permissions:"
    ls -la .ast-grep/
    echo "Configuration Content:"
    cat .ast-grep/sgconfig.yml

- name: Debug ast-grep Installation
  run: |
    which ast-grep || echo "ast-grep not found"
    ast-grep --version || echo "Version check failed"
    sg check --config .ast-grep/sgconfig.yml || echo "Config check failed"
```

#### Performance Regression Detection Issues
**Problem**: False positive performance regressions in CI

**Common Causes**:
```bash
# Cause 1: CI runner variability
# Solution: Use wider regression thresholds in CI
benchmark_time=5.0    # Instead of 3.0 for local testing

# Cause 2: Cold start effects
# Solution: Warm up before benchmarking
sg scan --rule .ast-grep/rules/security/simple-rule.yml test-file.py >/dev/null 2>&1

# Cause 3: Resource contention
# Solution: Run benchmarks multiple times and take median
for i in {1..3}; do
    python3 scripts/helpers/benchmark_astgrep.py --quick >> benchmark_runs.txt
done
```

### Artifact Collection and Analysis

#### Comprehensive CI Diagnostics
```yaml
- name: Collect Comprehensive Diagnostics
  if: failure()
  run: |
    mkdir -p diagnostics

    # System information
    uname -a > diagnostics/system_info.txt
    free -h > diagnostics/memory_info.txt
    df -h > diagnostics/disk_info.txt

    # ast-grep specific
    ast-grep --version > diagnostics/astgrep_version.txt 2>&1 || echo "Version failed"
    sg check --config .ast-grep/sgconfig.yml > diagnostics/config_check.txt 2>&1 || echo "Config check failed"

    # Rule information
    find .ast-grep/rules -name "*.yml" > diagnostics/rule_files.txt

    # Performance data
    python3 scripts/helpers/benchmark_astgrep.py --quick > diagnostics/performance.txt 2>&1 || echo "Benchmark failed"

    # Recent commits (might affect performance)
    git log --oneline -10 > diagnostics/recent_commits.txt

    # File count analysis
    echo "Total repository files:" >> diagnostics/file_analysis.txt
    find . -type f | wc -l >> diagnostics/file_analysis.txt
    echo "Git tracked files:" >> diagnostics/file_analysis.txt
    git ls-files | wc -l >> diagnostics/file_analysis.txt

- name: Archive Diagnostics
  if: failure()
  uses: actions/upload-artifact@v3
  with:
    name: ast-grep-diagnostics-${{ github.run_id }}
    path: diagnostics/
    retention-days: 7
```

---

## Integration Troubleshooting

### SpaceWalker Integration Issues

#### Justfile Command Problems
**Problem**: `just lint check astgrep` fails with integration errors

**Common Issues**:
```bash
# Issue 1: Python environment problems
$ just lint check astgrep
Error: ModuleNotFoundError: No module named 'yaml'

# Solution:
python3 -m pip install PyYAML psutil

# Issue 2: Path configuration issues
$ just lint check astgrep
Error: lint_manager.py not found

# Solution:
# Verify working directory
pwd  # Should be SpaceWalker root
ls scripts/helpers/lint_manager.py  # Should exist

# Issue 3: Permission problems
$ just lint check astgrep
Error: Permission denied: /usr/local/bin/ast-grep

# Solution:
chmod +x /usr/local/bin/ast-grep
# or install in user directory
cargo install ast-grep  # Installs to ~/.cargo/bin/
```

#### lint_manager.py Integration Issues
**Problem**: Integration script fails or produces incorrect results

**Debugging Steps**:
```bash
# Step 1: Test direct execution
python3 scripts/helpers/lint_manager.py check astgrep --debug

# Step 2: Verify imports
python3 -c "
import sys
sys.path.append('scripts/helpers')
try:
    from lint_manager import run_astgrep_lint
    print('✅ Import successful')
except ImportError as e:
    print(f'❌ Import failed: {e}')
"

# Step 3: Test with minimal configuration
python3 scripts/helpers/lint_manager.py check astgrep --files apps/backend/main.py
```

### IDE Integration Problems

#### VS Code Integration Issues
**Problem**: ast-grep not working properly in VS Code

**Setup Verification**:
```bash
# Create .vscode/tasks.json if it doesn't exist
mkdir -p .vscode
cat > .vscode/tasks.json << 'EOF'
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "ast-grep Security Check",
            "type": "shell",
            "command": "just",
            "args": ["lint", "check", "astgrep"],
            "group": "build",
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            },
            "problemMatcher": {
                "pattern": [
                    {
                        "regexp": "^(.+):(\\d+):(\\d+):(.*)$",
                        "file": 1,
                        "line": 2,
                        "column": 3,
                        "message": 4
                    }
                ]
            }
        }
    ]
}
EOF

# Test the task
code .  # Open in VS Code
# Press Ctrl+Shift+P, type "Tasks: Run Task", select "ast-grep Security Check"
```

#### Pre-commit Hook Integration
**Problem**: Pre-commit hook fails or takes too long

**Hook Configuration**:
```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: ast-grep-security
        name: ast-grep Security Check
        entry: bash -c 'just lint check astgrep'
        language: system
        pass_filenames: false
        types: [python, typescript, javascript]
        # Add timeout to prevent hanging
        timeout: 30
```

**Performance Optimization for Hooks**:
```bash
# Create fast-astgrep command in justfile for pre-commit
# justfile addition:
fast-astgrep:
    #!/usr/bin/env bash
    # Only scan changed files for speed
    changed_files=$(git diff --cached --name-only --diff-filter=ACM | grep -E '\.(py|ts|tsx|js|jsx)$' | head -20)
    if [ -n "$changed_files" ]; then
        echo "🔍 ast-grep checking changed files..."
        python3 scripts/helpers/lint_manager.py check astgrep --files $changed_files
    else
        echo "✅ No relevant files changed"
    fi

# Update pre-commit hook to use fast version
entry: bash -c 'just fast-astgrep'
```

---

## Emergency Procedures

### Critical Failure Recovery

#### Complete ast-grep Failure
**When**: ast-grep completely broken, blocking development

**Immediate Actions**:
```bash
# Step 1: Bypass ast-grep temporarily
# Edit justfile to comment out ast-grep
sed -i.backup 's/python3 scripts\/helpers\/lint_manager.py check astgrep/#&/' justfile

# Step 2: Verify other linting still works
just lint check all --skip-astgrep  # If available

# Step 3: Document the bypass
echo "$(date): ast-grep bypassed due to critical failure" >> .emergency-log

# Step 4: Create minimal test case for debugging
echo 'print("test")' > minimal-test.py
ast-grep --version > debug-info.txt 2>&1
sg scan minimal-test.py >> debug-info.txt 2>&1
```

#### CI/CD Pipeline Failure
**When**: GitHub Actions failing, blocking merges

**Immediate Actions**:
```yaml
# Step 1: Create hotfix workflow (emergency-ci.yml)
name: Emergency CI (No ast-grep)
on:
  push:
    branches: [main, emergency-*]

jobs:
  emergency-checks:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Run Basic Checks
      run: |
        echo "Running emergency checks without ast-grep"
        # Run other linting that works
        python3 -m flake8 apps/backend/ || true

# Step 2: Create emergency branch
git checkout -b emergency-bypass-astgrep
# Make necessary changes
git commit -m "emergency: bypass ast-grep temporarily"
git push origin emergency-bypass-astgrep

# Step 3: Document emergency
echo "Emergency bypass active - $(date)" > EMERGENCY-STATUS.md
git add EMERGENCY-STATUS.md
git commit -m "docs: document ast-grep emergency bypass"
```

### Data Collection for Support

#### Comprehensive Debug Information Package
```bash
# Create emergency_debug_package.sh
cat > emergency_debug_package.sh << 'EOF'
#!/bin/bash
set -e

echo "🚨 Creating ast-grep Emergency Debug Package"
DEBUG_DIR="ast-grep-debug-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DEBUG_DIR"

echo "📋 Collecting system information..."
{
    echo "=== SYSTEM INFO ==="
    uname -a
    echo "Date: $(date)"
    echo "User: $(whoami)"
    echo "Working Directory: $(pwd)"
    echo

    echo "=== ENVIRONMENT ==="
    env | grep -E "(PATH|PYTHON|CARGO|HOME)" | sort
    echo

    echo "=== PYTHON INFO ==="
    python3 --version
    python3 -c "import sys; print(f'Python executable: {sys.executable}')"
    python3 -c "import sys; print(f'Python path: {sys.path}')"
    echo

    echo "=== AST-GREP INFO ==="
    which ast-grep || echo "ast-grep not found in PATH"
    ast-grep --version 2>&1 || echo "ast-grep version failed"
    echo
} > "$DEBUG_DIR/system_info.txt"

echo "📁 Collecting configuration files..."
cp -r .ast-grep/ "$DEBUG_DIR/" 2>/dev/null || echo "No .ast-grep directory"
cp justfile "$DEBUG_DIR/" 2>/dev/null || echo "No justfile"

echo "🔍 Collecting recent activity..."
{
    echo "=== GIT STATUS ==="
    git status
    echo

    echo "=== RECENT COMMITS ==="
    git log --oneline -10
    echo

    echo "=== RECENT CHANGES TO AST-GREP FILES ==="
    git log --oneline -5 --name-only -- .ast-grep/ scripts/helpers/lint_manager.py
    echo
} > "$DEBUG_DIR/git_info.txt"

echo "🧪 Running diagnostic tests..."
{
    echo "=== BASIC FUNCTIONALITY TEST ==="
    echo 'print("test")' > test_file.py

    echo "Testing ast-grep directly:"
    sg scan test_file.py 2>&1 || echo "Direct sg scan failed"

    echo "Testing configuration:"
    sg check --config .ast-grep/sgconfig.yml 2>&1 || echo "Config check failed"

    echo "Testing lint manager:"
    python3 scripts/helpers/lint_manager.py check astgrep --files test_file.py 2>&1 || echo "Lint manager failed"

    rm -f test_file.py
    echo
} > "$DEBUG_DIR/functionality_tests.txt"

echo "📊 Collecting performance data..."
{
    python3 scripts/helpers/benchmark_astgrep.py --quick 2>&1 || echo "Benchmark failed"
} > "$DEBUG_DIR/performance_data.txt"

echo "📦 Creating archive..."
tar -czf "${DEBUG_DIR}.tar.gz" "$DEBUG_DIR/"
rm -rf "$DEBUG_DIR/"

echo "✅ Debug package created: ${DEBUG_DIR}.tar.gz"
echo
echo "📧 Please send this file to the development team with:"
echo "1. Description of the issue"
echo "2. Steps to reproduce"
echo "3. Expected vs actual behavior"
echo "4. When the issue started"
EOF

chmod +x emergency_debug_package.sh
./emergency_debug_package.sh
```

---

## Escalation and Support

### When to Escalate

#### Automatic Escalation Triggers
1. **Performance Regression >100%**: Execution time doubles
2. **Memory Usage >1GB**: Exceeds reasonable limits
3. **Complete Failure >24h**: No successful runs for a day
4. **CI/CD Blocking**: Prevents merges for >2 hours
5. **Security Rule Failures**: Critical security patterns not working

#### Manual Escalation Guidelines
1. **Complex Rule Issues**: Pattern matching problems beyond basic troubleshooting
2. **Integration Architecture**: Deep SpaceWalker integration problems
3. **Performance Optimization**: Need for architectural changes
4. **Multiple Failed Attempts**: Tried troubleshooting for >2 hours

### Support Information Package

#### Essential Information for Support Requests
```markdown
# ast-grep Support Request Template

## Issue Summary
- **Problem**: Brief description
- **Impact**: Severity (Critical/High/Medium/Low)
- **Environment**: Local/CI/Both
- **Started**: When the issue began

## System Information
- **OS**: [Output of `uname -a`]
- **ast-grep version**: [Output of `ast-grep --version`]
- **Python version**: [Output of `python3 --version`]
- **SpaceWalker branch**: [Current git branch]

## Reproduction Steps
1. Step 1
2. Step 2
3. Step 3

## Expected vs Actual Behavior
- **Expected**: What should happen
- **Actual**: What actually happens
- **Error messages**: Full error output

## Troubleshooting Attempted
- [ ] Verified installation
- [ ] Checked configuration
- [ ] Ran diagnostic commands
- [ ] Tested with minimal example
- [ ] Reviewed recent changes

## Debug Information
- **Debug package attached**: [yes/no]
- **Logs available**: [specify location]
- **Configuration changes**: [recent modifications]

## Business Impact
- **Blocking development**: [yes/no]
- **Security implications**: [describe any security concerns]
- **Workaround available**: [describe if any]
```

### Internal Support Contacts

#### Support Escalation Path
1. **Level 1**: Development Team Lead
   - Quick fixes and configuration issues
   - Standard troubleshooting guidance
   - Rule development assistance

2. **Level 2**: Security Engineering
   - Security rule validation issues
   - Pattern matching for security violations
   - Compliance and audit requirements

3. **Level 3**: Platform Engineering
   - Performance architecture issues
   - CI/CD pipeline integration problems
   - Scalability and infrastructure concerns

4. **Level 4**: External Support
   - ast-grep tool issues (upstream)
   - System-level performance problems
   - Complex debugging requiring specialized tools

### Community Resources

#### External Support Resources
- **ast-grep GitHub Issues**: https://github.com/ast-grep/ast-grep/issues
- **ast-grep Documentation**: https://ast-grep.github.io/
- **Rust Community Forums**: For installation and compilation issues
- **Static Analysis Community**: For pattern matching best practices

#### Knowledge Base Articles
- **[Performance Optimization Guide](../development/ast-grep-optimization-guide.md)**
- **[Rule Development Best Practices](../development/ast-grep-integration.md#rule-development)**
- **[CI/CD Integration Guide](../workflows/ci-cd-build-guide.md)**
- **[Security Architecture](../architecture/security-architecture.md)**

---

## Prevention and Maintenance

### Proactive Monitoring

#### Health Check Automation
```bash
# Create ast-grep-health-check.sh for regular monitoring
cat > scripts/monitoring/ast-grep-health-check.sh << 'EOF'
#!/bin/bash
# ast-grep Health Check Script
# Run this regularly to catch issues early

set -e

echo "🏥 ast-grep Health Check - $(date)"
echo "=================================="

# Check 1: Basic functionality
echo "✅ Testing basic functionality..."
if just lint check astgrep >/dev/null 2>&1; then
    echo "   ✅ Basic execution: PASS"
else
    echo "   ❌ Basic execution: FAIL"
    exit 1
fi

# Check 2: Performance baseline
echo "✅ Testing performance..."
PERF_OUTPUT=$(python3 scripts/helpers/benchmark_astgrep.py --quick 2>&1)
EXEC_TIME=$(echo "$PERF_OUTPUT" | grep "execution_time_s" | cut -d':' -f2 | tr -d ' ')

if (( $(echo "$EXEC_TIME < 5.0" | bc -l) )); then
    echo "   ✅ Performance: PASS (${EXEC_TIME}s)"
else
    echo "   ⚠️  Performance: SLOW (${EXEC_TIME}s - investigate)"
fi

# Check 3: Configuration validity
echo "✅ Testing configuration..."
if sg check --config .ast-grep/sgconfig.yml >/dev/null 2>&1; then
    echo "   ✅ Configuration: VALID"
else
    echo "   ❌ Configuration: INVALID"
    exit 1
fi

# Check 4: Rule file integrity
echo "✅ Testing rule integrity..."
RULE_COUNT=$(find .ast-grep/rules -name "*.yml" -type f | wc -l)
if [ "$RULE_COUNT" -ge 7 ]; then
    echo "   ✅ Rules: ${RULE_COUNT} files found"
else
    echo "   ❌ Rules: Only ${RULE_COUNT} files (expected ≥7)"
    exit 1
fi

echo
echo "🎉 All health checks passed!"
EOF

chmod +x scripts/monitoring/ast-grep-health-check.sh

# Add to cron for regular monitoring
# crontab -e
# 0 9 * * * /path/to/spacewalker/scripts/monitoring/ast-grep-health-check.sh >> /tmp/astgrep-health.log 2>&1
```

#### Performance Monitoring Dashboard
```python
# Create performance_dashboard.py for trend analysis
import json
import time
from pathlib import Path
from typing import Dict, List
import matplotlib.pyplot as plt  # If available

class PerformanceDashboard:
    def __init__(self):
        self.history_file = Path('.build/astgrep-performance-history.json')
        self.history = self.load_history()

    def load_history(self) -> List[Dict]:
        if self.history_file.exists():
            with open(self.history_file) as f:
                return json.load(f)
        return []

    def save_history(self):
        self.history_file.parent.mkdir(exist_ok=True)
        with open(self.history_file, 'w') as f:
            json.dump(self.history, f, indent=2)

    def record_performance(self, metrics: Dict):
        """Record current performance metrics."""
        entry = {
            'timestamp': time.time(),
            'date': time.strftime('%Y-%m-%d %H:%M:%S'),
            **metrics
        }
        self.history.append(entry)

        # Keep last 100 entries
        self.history = self.history[-100:]
        self.save_history()

    def get_trends(self) -> Dict:
        """Analyze performance trends."""
        if len(self.history) < 2:
            return {'status': 'insufficient_data'}

        recent = self.history[-10:]  # Last 10 runs
        older = self.history[-20:-10]  # Previous 10 runs

        recent_avg_time = sum(r.get('execution_time', 0) for r in recent) / len(recent)
        older_avg_time = sum(r.get('execution_time', 0) for r in older) / len(older) if older else recent_avg_time

        time_trend = 'improving' if recent_avg_time < older_avg_time else 'degrading'

        return {
            'status': 'analyzed',
            'time_trend': time_trend,
            'recent_avg_time': recent_avg_time,
            'older_avg_time': older_avg_time,
            'entries_analyzed': len(self.history)
        }

# Usage in benchmarking
dashboard = PerformanceDashboard()

# Record after each benchmark
metrics = run_benchmark()  # Your benchmark function
dashboard.record_performance(metrics)

# Check trends
trends = dashboard.get_trends()
if trends['time_trend'] == 'degrading':
    print("⚠️ Performance degradation trend detected")
```

### Maintenance Procedures

#### Regular Maintenance Checklist
```markdown
# ast-grep Monthly Maintenance Checklist

## Performance Review (Monthly)
- [ ] Run comprehensive performance benchmark
- [ ] Review performance trends over last month
- [ ] Identify any degradation patterns
- [ ] Update performance baselines if needed

## Configuration Review (Monthly)
- [ ] Review ignore patterns for new file types
- [ ] Check for new directories that should be excluded
- [ ] Validate rule organization and structure
- [ ] Test configuration with sg check command

## Rule Maintenance (Quarterly)
- [ ] Review effectiveness of existing rules
- [ ] Analyze false positive rates
- [ ] Update rule patterns for new code patterns
- [ ] Test rules against recent codebase changes

## Integration Health (Monthly)
- [ ] Test justfile commands
- [ ] Verify CI/CD pipeline functionality
- [ ] Check IDE integration status
- [ ] Validate pre-commit hooks

## Tool Updates (As Needed)
- [ ] Check for ast-grep tool updates
- [ ] Review changelog for new features
- [ ] Test compatibility with new versions
- [ ] Update installation procedures if needed

## Documentation (Quarterly)
- [ ] Review troubleshooting guide accuracy
- [ ] Update performance metrics in documentation
- [ ] Validate setup and installation procedures
- [ ] Update examples with current code patterns
```

---

## Related Documentation

### Core Troubleshooting Resources
- **[ast-grep Integration Developer Guide](../development/ast-grep-integration.md)** - Implementation and usage reference
- **[ast-grep Architecture Documentation](../architecture/structural-analysis.md)** - System design and technical details
- **[Performance Optimization Guide](../development/ast-grep-optimization-guide.md)** - Detailed performance tuning

### SpaceWalker Integration Guides
- **[Lint System Documentation](../development/adding-custom-lints.md)** - Broader linting troubleshooting
- **[General Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Build and deployment issues
- **[Development Environment Setup](../setup/development-setup.md)** - Environment configuration

### External Resources
- **[ast-grep Official Troubleshooting](https://ast-grep.github.io/troubleshooting/)** - Tool-specific issues
- **[Static Analysis Best Practices](https://github.com/analysis-tools-dev/static-analysis)** - Community troubleshooting
- **[Performance Debugging Techniques](https://www.brendangregg.com/perf.html)** - System-level debugging

---

**Emergency Contact**: For critical issues blocking development, contact the development team immediately with debug package and impact assessment.

**Feedback**: This troubleshooting guide should be updated based on real-world issues encountered. Please contribute common problems and solutions to keep it current and comprehensive.
