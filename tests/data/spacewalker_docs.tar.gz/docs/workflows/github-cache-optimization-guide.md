# GitHub Actions Cache Optimization Guide

## Purpose
Comprehensive guide for optimizing GitHub Actions cache to prevent bloat, improve performance, and reduce costs. Based on real-world optimization that reduced cache from 205GB to <10GB.

## When to Use This
- GitHub cache exceeding storage limits
- Duplicate cache entries with identical content
- Slow CI/CD due to cache misses
- Implementing new caching strategies

**Keywords**: GitHub Actions cache, cache optimization, CI/CD performance, cache deduplication, storage reduction

**Version**: 1.0
**Date**: 2025-09-16
**Status**: Current - ENG-1156 cache optimization implementation

---

## 🚨 Common Cache Problems & Solutions

### Problem 1: Duplicate Cache Entries
**Symptom**: Multiple 1.5GB cache entries with slightly different keys but identical content.

**Root Cause**: Each job creates its own cache instead of sharing.

**Solution**: Implement centralized dependency installation with cache sharing.

### Problem 2: Combined Language Caches
**Symptom**: Python and Node dependencies cached together unnecessarily.

**Root Cause**: Single cache block containing all dependencies.

**Solution**: Separate caches by language/purpose.

### Problem 3: Test Jobs Creating Cache Duplicates
**Symptom**: Read-only jobs creating new cache entries.

**Root Cause**: Using `actions/cache@v4` which both reads and writes.

**Solution**: Use `actions/cache/restore@v4` for read-only access.

---

## ✅ Optimized Caching Strategy

### 1. Version Your Cache Keys

Add version suffixes to force cache invalidation when needed:

```yaml
# ✅ GOOD: Versioned cache key
key: ${{ runner.os }}-deps-v2-${{ hashFiles('**/package-lock.json') }}

# ❌ BAD: No version control
key: ${{ runner.os }}-deps-${{ hashFiles('**/package-lock.json') }}
```

### 2. Separate Caches by Purpose

Don't combine unrelated dependencies:

```yaml
# ✅ GOOD: Separate Python cache
- name: Cache Python dependencies
  uses: actions/cache@v4
  with:
    path: |
      ~/.cache/pip
      .venv
    key: ${{ runner.os }}-python-v2-${{ hashFiles('**/requirements.txt') }}

# ✅ GOOD: Separate Node cache
- name: Cache Node dependencies
  uses: actions/cache@v4
  with:
    path: |
      ~/.npm
      node_modules
    key: ${{ runner.os }}-node-v2-${{ hashFiles('**/package-lock.json') }}

# ❌ BAD: Combined cache
- name: Cache all dependencies
  uses: actions/cache@v4
  with:
    path: |
      ~/.npm
      ~/.cache/pip
      .venv
      node_modules
    key: ${{ runner.os }}-all-deps-${{ hashFiles('**/*') }}
```

### 3. Use Read-Only Cache for Test Jobs

Prevent duplicate cache saves:

```yaml
# ✅ GOOD: Read-only cache for tests
test-job:
  steps:
    - uses: actions/cache/restore@v4  # Note: restore, not cache
      with:
        path: .venv
        key: ${{ runner.os }}-python-v2-${{ hashFiles('**/requirements.txt') }}
        fail-on-cache-miss: true

# ❌ BAD: Test job creating cache
test-job:
  steps:
    - uses: actions/cache@v4  # This will save cache again!
      with:
        path: .venv
        key: ${{ runner.os }}-python-v2-${{ hashFiles('**/requirements.txt') }}
```

### 4. Implement Shared Dependency Installation

Create a single job that installs dependencies once:

```yaml
jobs:
  install-dependencies:
    runs-on: ubuntu-latest
    outputs:
      python-cache-key: ${{ steps.cache-keys.outputs.python }}
      node-cache-key: ${{ steps.cache-keys.outputs.node }}
    steps:
      # Generate cache keys
      - id: cache-keys
        run: |
          echo "python=${{ runner.os }}-python-v2-${{ hashFiles('**/requirements.txt') }}" >> $GITHUB_OUTPUT
          echo "node=${{ runner.os }}-node-v2-${{ hashFiles('**/package-lock.json') }}" >> $GITHUB_OUTPUT

      # Cache and install Python deps
      - uses: actions/cache@v4
        id: cache-python
        with:
          path: |
            ~/.cache/pip
            .venv
          key: ${{ steps.cache-keys.outputs.python }}

      - if: steps.cache-python.outputs.cache-hit != 'true'
        run: |
          pip install uv
          uv venv .venv
          source .venv/bin/activate
          uv pip install -r requirements.txt

  # Test jobs just restore the cache
  test-backend:
    needs: install-dependencies
    steps:
      - uses: actions/cache/restore@v4
        with:
          path: |
            ~/.cache/pip
            .venv
          key: ${{ needs.install-dependencies.outputs.python-cache-key }}
          fail-on-cache-miss: true
```

### 5. Add Docker Layer Caching

For Docker builds, use BuildKit cache:

```yaml
- name: Build and push Docker image
  uses: docker/build-push-action@v5
  with:
    context: .
    push: true
    tags: ${{ env.IMAGE_TAG }}
    # GitHub Actions cache
    cache-from: type=gha,scope=${{ matrix.app }}-${{ github.ref }}
    cache-to: type=gha,scope=${{ matrix.app }}-${{ github.ref }},mode=max
    # OR Registry cache
    cache-from: type=registry,ref=${{ env.REGISTRY }}/${{ matrix.app }}:buildcache
    cache-to: type=registry,ref=${{ env.REGISTRY }}/${{ matrix.app }}:buildcache,mode=max
```

---

## 🧹 Cache Cleanup

### Manual Cleanup Script

Use the provided script to clean duplicate caches:

```bash
#!/bin/bash
# Location: scripts/cicd/cleanup-github-cache.sh

# Run the cleanup
./scripts/cicd/cleanup-github-cache.sh

# Check cache status
gh api "/repos/$OWNER/$REPO/actions/cache/usage" | jq
```

### Automated Weekly Cleanup

Add a scheduled workflow:

```yaml
# .github/workflows/cache-cleanup.yml
name: Weekly Cache Cleanup
on:
  schedule:
    - cron: '0 0 * * 0'  # Sunday midnight
  workflow_dispatch:

jobs:
  cleanup:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Cleanup old caches
        env:
          GH_TOKEN: ${{ github.token }}
        run: |
          # Delete caches older than 7 days
          gh extension install actions/gh-actions-cache

          gh actions-cache list -R ${{ github.repository }} | \
            grep -E "days ago|weeks ago" | \
            cut -f1 | \
            xargs -I {} gh actions-cache delete {} -R ${{ github.repository }} --confirm
```

---

## 📊 Monitoring Cache Usage

### Check Current Usage

```bash
# Via GitHub CLI
gh api "/repos/$(gh repo view --json nameWithOwner -q .nameWithOwner)/actions/cache/usage" | \
  jq '{
    count: .active_caches_count,
    size_mb: (.active_caches_size_in_bytes / 1048576),
    size_gb: (.active_caches_size_in_bytes / 1073741824)
  }'
```

### Monitor After Changes

1. Check GitHub Actions tab → Caches
2. Look for duplicate entries with same content
3. Verify cache hit rates in workflow logs
4. Monitor total size stays under 10GB

---

## 🎯 Migration Checklist

When optimizing existing workflows:

- [ ] Add `-v2` suffix to all cache keys
- [ ] Separate Python and Node caches
- [ ] Convert test jobs to use `cache/restore@v4`
- [ ] Implement shared dependency installation job
- [ ] Add Docker layer caching if applicable
- [ ] Run cleanup script to remove old caches
- [ ] Set up automated cleanup workflow
- [ ] Monitor cache metrics after deployment

---

## 📈 Expected Results

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Cache Size | 205 GB | <10 GB | 95% reduction |
| Cache Entries | 75+ | 10-15 | 80% reduction |
| Cache Hit Rate | Variable | >90% | Consistent hits |
| CI Duration | Baseline | -20% | Faster builds |

---

## 🚫 Anti-Patterns to Avoid

### Don't Cache Everything Together
```yaml
# ❌ BAD
path: |
  ~/.npm
  ~/.cache/pip
  .venv
  node_modules
  apps/*/node_modules
  ~/.cargo
  ~/.rustup
```

### Don't Use Same Cache Key Everywhere
```yaml
# ❌ BAD: All jobs use same key
key: ${{ runner.os }}-cache
```

### Don't Forget Version Suffixes
```yaml
# ❌ BAD: Can't invalidate cache
key: ${{ runner.os }}-deps-${{ hashFiles('**/*') }}
```

### Don't Let Test Jobs Write Cache
```yaml
# ❌ BAD: Test job creates duplicate cache
test-job:
  - uses: actions/cache@v4  # Should be cache/restore@v4
```

---

## 🔗 Related Documentation

- [GitHub Actions Best Practices](./github-actions-best-practices.md)
- [CI/CD Build Guide](./ci-cd-build-guide.md)
- [Docker Optimization](./docker-base-image-optimization.md)

---

## 📝 Implementation Files

- **Optimization Example**: `.github/workflows/ci-cd-optimized-caching.yml`
- **Cleanup Script**: `scripts/cleanup-github-cache.sh`
- **Current Implementation**: `.github/workflows/ci-cd.yml` (with v2 cache keys)