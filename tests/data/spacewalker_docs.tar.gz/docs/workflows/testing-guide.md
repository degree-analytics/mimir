# Spacewalker Testing Guide

## Purpose
Comprehensive testing documentation for all test types and environments - from unit tests to CI/CD pipelines. Complete guide for developers, QA engineers, and DevOps teams implementing testing strategies.

## When to Use This
- Setting up testing workflows for daily development
- Implementing CI/CD testing pipelines
- Understanding test coverage and quality standards
- Troubleshooting test failures and infrastructure issues
- Planning comprehensive testing strategies across applications
- Keywords: testing, unit tests, integration tests, CI/CD, test automation, quality assurance

**Version:** 2.0 (Updated for new documentation structure)
**Date:** 2025-07-03
**Status:** Current - Complete Testing Hub

---

## ⚡ Quick Start Testing
**Get tests running immediately** - Essential for daily development workflow

Jump straight into testing with our **fast feedback loop** that validates your changes in minutes:

```bash
just test unit all         # Fast unit tests across all repos (2-3 min)
just dev_cycle         # Complete development testing cycle
just health            # Verify all services are running
```

This gives you **instant confidence** in your changes with comprehensive validation across backend, admin, and mobile components.

### 🎯 Quick Validation Commands
```bash
just test unit all                          # All unit tests across repos
just test unit backend                      # Backend tests only (fastest)
just test unit admin                        # Admin dashboard tests only
just test unit mobile                       # Mobile app tests only
just docs validate all                      # Documentation link validation (when editing docs)
```

### 📚 Quick Start Resources
- **[Getting Started Guide](../setup/getting-started.md)** - Contains testing verification steps in development workflow
- **[Quick Start Guide](../setup/quick-start.md)** - Testing verification in rapid setup workflow

---

## 🔬 Unit Testing
**Fast, isolated component testing** - No infrastructure dependencies, immediate feedback

Our unit test suite provides **lightning-fast validation** with 560+ tests across all components, designed for continuous development feedback.

### 🔄 Testing Workflow Overview

```mermaid
graph LR
    A[🔬 Unit Tests<br/>~2-3 min] --> B{All Pass?}
    B -->|✅ Yes| C[🔗 Integration Tests<br/>~5-10 min]
    B -->|❌ No| A1[🔧 Fix Issues]
    A1 --> A

    C --> D{Services OK?}
    D -->|✅ Yes| E[🎯 System Tests<br/>~10-15 min]
    D -->|❌ No| C1[🐳 Fix Infrastructure]
    C1 --> C

    E --> F{E2E Pass?}
    F -->|✅ Yes| G[🚀 Ready for Deploy]
    F -->|❌ No| E1[🔍 Debug Workflows]
    E1 --> E

    style A fill:#e3f2fd
    style C fill:#f1f8e9
    style E fill:#fff3e0
    style G fill:#e8f5e8
```

### 📊 Test Coverage Overview
- **Backend**: 151+ pytest tests (always should pass)
- **Admin**: 20+ Jest/React tests with Next.js integration
- **Mobile**: 389+ React Native tests (6 expected failures due to alert changes)

### ⚙️ Configuration & Setup

#### Backend (Python/pytest)
- **[pytest.ini](../../apps/backend/pytest.ini)** - **Main pytest configuration** with markers and coverage
- **[Backend Development](../backend/development/README.md)** - Recent test results and current status
- Test markers: `integration`, `system`, `external`, `smoke`, `use_real_gemini`

**Related Documentation:** [Backend Development Guide](../backend/development/README.md)

#### Admin Dashboard (JavaScript/Jest)
- **[jest.config.ts](../../apps/admin/jest.config.ts)** - **Jest + Next.js configuration**
- **[jest.setup.ts](../../apps/admin/jest.setup.ts)** - Test environment setup
- **[test-utils.tsx](../../apps/admin/src/test-utils.tsx)** - React testing utilities
- Coverage thresholds: 20% branches, 25% functions, 30% lines

**Related Documentation:** [Admin Architecture Guide](../admin/architecture/README.md)

#### Mobile App (React Native/Jest)
- **[package.json](../../apps/mobile/package.json)** - **Mobile Jest configuration** (in package.json)
- **[jest.setup.js](../../apps/mobile/jest.setup.js)** - Mobile test environment setup
- **[React 19 Preset](../../apps/mobile/jest-preset-react19.js)** - React 19 compatibility

**Related Documentation:** [Mobile Architecture Guide](../mobile/architecture/README.md)

### 🚀 Unit Testing Commands
```bash
# Run all unit tests
just test unit all              # All repos unit tests (2-3 min)

# Repository-specific unit tests
just test unit backend          # Backend unit tests only (~1 min)
just test unit admin            # Admin unit tests only (~30 sec)
just test unit mobile           # Mobile unit tests only (~1 min)

# Development workflow
just dev_cycle              # Unit tests + linting + formatting
```

---

## 🔗 Integration Testing
**Service interaction testing** - Database and infrastructure required for realistic validation

Integration tests validate **cross-component workflows** and service interactions, ensuring your changes work correctly with real database and infrastructure dependencies.

### 🎯 Integration Test Overview
- **Backend**: ~28 integration tests (database + services)
- **Admin**: 6 integration tests (frontend + API integration)
- **Expected Results**: ~385 passed, ~23 expected failures

### 🛠️ Database Testing Strategies

#### Strategy 1: Local Development (Fast)
```bash
just test integration all       # Uses shared development database
```
- **Speed**: Fast (shared PostgreSQL database)
- **Isolation**: Partial (shared state)
- **Best for**: Daily development workflow

#### Strategy 2: CI Environment (Isolated)
```bash
just test integration all --with-setup  # Auto-starts infrastructure
```
- **Speed**: Medium (starts fresh services)
- **Isolation**: Full (clean environment)
- **Best for**: Pre-commit validation

### 📚 Integration Resources
- **[SSR Testing Utils](../../apps/admin/src/test-utils/ssr-testing.tsx)** - Server-side rendering test support
- **[Backend Integration Tests](../../apps/backend/tests/integration/)** - Database + services integration
- **[Admin Integration Tests](../../apps/admin/src/__tests__/integration/)** - Frontend integration testing

### 🔄 Integration Testing Commands
```bash
# All integration tests
just test integration all                   # All repos integration tests
just test integration all --with-setup      # Auto-start infrastructure first

# Repository-specific integration tests
just test integration backend               # Backend integration only
just test integration admin                 # Admin integration only
just test integration mobile                # Mobile integration only

# Infrastructure management
just up                                 # Start all services for testing
just db shell                        # Access test database
```

---

## 🏗️ System Testing
**End-to-end workflow validation** - Complete user journeys and production-like scenarios

System tests validate **entire user workflows** from start to finish, ensuring the complete application works correctly in realistic scenarios.

### 🎯 System Test Overview
- **System Tests**: ~13 tests (end-to-end workflows)
- **External Tests**: Variable (real API integration)
- **Expected Results**: ~13 passed, ~3 expected failures

### 🔍 System Test Categories
- **End-to-End Workflows**: Complete user journeys
- **Analytics Validation**: Reporting and data analysis workflows
- **Real API Integration**: External service integration testing

### 📚 System Testing Resources
- **[System Tests](../../apps/backend/tests/system/)** - End-to-end workflow tests
- **[External Tests](../../apps/backend/tests/external/)** - Real API integration tests
- **[Image Test Helpers](../../apps/backend/tests/utils/image_helpers.py)** - Image testing utilities

### 🎮 System Testing Commands
```bash
# System and external tests
just test system backend                    # System tests only
just test external all                      # External API tests
just test all all                           # Complete test suites (all types)

# AI-specific system testing
just test ai real                           # Real Gemini API integration
just test ai all                            # Mocked + real API tests (if key available)

# Complete validation
just test all all --with-setup              # Full tests with infrastructure
just test all backend                       # All backend tests (unit+integration+system)
```

---

## 🔒 Security Testing
**Vulnerability testing and security validation** - Proactive security testing to prevent injection attacks and data breaches

Security testing ensures your application is protected against **common attack vectors** including JSON injection, prototype pollution, input validation bypasses, and localStorage vulnerabilities.

### 🎯 Security Test Overview
- **JSON Injection Tests**: Prevent prototype pollution and injection attacks
- **Input Validation Tests**: Boundary testing and malicious input handling
- **localStorage Security**: Zod schema validation and safe data parsing
- **Authentication Tests**: Token validation and authorization bypasses
- **Filter Security**: Independent filter validation and SQL injection prevention

### 🛡️ Security Test Categories

#### 1. JSON Injection & Prototype Pollution
```typescript
// Test localStorage injection prevention
describe('localStorage Security', () => {
  it('should reject malicious JSON injection', () => {
    const maliciousData = JSON.stringify({
      sortColumns: [],
      __proto__: { isAdmin: true }, // Prototype pollution attempt
    });

    localStorage.setItem('test-key', maliciousData);
    const result = loadSortingState('test-key');

    expect(result).toEqual([]); // Should reject and return default
    expect(localStorage.getItem('test-key')).toBeNull(); // Should clean up
  });
});
```

#### 2. Input Boundary Testing
```typescript
// Test bounded input validation
describe('Input Validation Security', () => {
  it('should reject oversized inputs', () => {
    const oversizedData = {
      field: 'a'.repeat(200), // Exceeds 100 char limit
      sortColumns: new Array(20).fill({}), // Exceeds 10 item limit
    };

    expect(() => {
      validateSortingData(oversizedData);
    }).toThrow(); // Should reject oversized inputs
  });
});
```

#### 3. Filter Independence Security
```typescript
// Test filter injection prevention
describe('Filter Security', () => {
  it('should prevent SQL injection in filters', () => {
    const maliciousFilter = "'; DROP TABLE users; --";

    // Should safely escape or reject malicious input
    const result = applyBuildingFilter(maliciousFilter);
    expect(result).not.toContain('DROP TABLE');
  });
});
```

### 🧪 Security Testing Implementation

#### Zod Schema Validation Testing
```bash
# Test file: apps/admin/src/utils/__tests__/sortingPersistence.security.test.ts
just test security admin          # Admin security tests
```

**Key Test Areas:**
- `.strict()` validation prevents prototype pollution
- Bounded string lengths prevent memory exhaustion
- Array size limits prevent DoS attacks
- Enum validation prevents injection via enums

#### Performance Security Testing
```bash
# Test file: apps/admin/src/hooks/__tests__/useTableSort.performance.test.ts
just test performance admin       # Performance + security validation
```

**Key Test Areas:**
- Large dataset handling without memory leaks
- Memoization prevents excessive computation attacks
- Graceful degradation under load

### 📚 Security Testing Resources
- **[localStorage Security Guide](../gotchas/localstorage-security.md)** - **Complete security implementation patterns**
- **[Filter Security Guide](../gotchas/table-filter-dependencies.md)** - Filter injection prevention
- **[Security Test Suite](../../apps/admin/src/utils/__tests__/sortingPersistence.security.test.ts)** - Comprehensive security tests

### 🔍 Security Testing Commands
```bash
# Security-focused testing
just test security all                      # All security tests across repos
just test security admin                    # Admin security tests (localStorage, validation)
just test security backend                  # Backend security tests (API, auth)

# Performance security testing
just test performance all                   # Performance tests with security validation
just test performance admin                 # Admin performance + security tests

# Combined security validation
just security_audit                         # Complete security test suite + static analysis
```

### ⚠️ Security Test Requirements

#### For All localStorage Usage
- [ ] **Zod validation**: All localStorage reads must use schema validation
- [ ] **Strict schemas**: Use `.strict()` to prevent prototype pollution
- [ ] **Bounded inputs**: String lengths and array sizes must be limited
- [ ] **Injection tests**: Test malicious JSON payloads
- [ ] **Cleanup tests**: Verify invalid data is removed

#### For All Filter Implementations
- [ ] **Independence tests**: Filters work without artificial dependencies
- [ ] **Injection prevention**: Malicious filter values are safely handled
- [ ] **Boundary testing**: Oversized or malformed filter values are rejected
- [ ] **Combination testing**: Filter combinations don't create vulnerabilities

#### For All User Input
- [ ] **Schema validation**: All user input validated against strict schemas
- [ ] **Sanitization**: Input is properly escaped for display
- [ ] **Error handling**: Invalid input fails gracefully without exposing internals

### 🚨 Critical Security Issues Prevented

Our security testing has prevented these **real vulnerabilities**:

1. **JSON Injection in localStorage** (ENG-624)
   - **Risk**: Prototype pollution via malicious localStorage data
   - **Prevention**: Zod `.strict()` validation with cleanup
   - **Test Coverage**: `sortingPersistence.security.test.ts`

2. **Filter Dependency Bypass** (ENG-622)
   - **Risk**: Artificial UI constraints hiding backend capabilities
   - **Prevention**: Independent filter validation
   - **Test Coverage**: Filter independence tests

3. **Memory Exhaustion Attacks**
   - **Risk**: Unbounded input causing browser crashes
   - **Prevention**: Bounded validation (100 char strings, 10 item arrays)
   - **Test Coverage**: Performance security tests

---

## 🗃️ Test Data Management
**Safe test data strategies** - Database isolation and demo data management

Comprehensive **test data safety** ensures your tests run reliably without interfering with production data or other developers' work.

### 🔒 Database Safety Strategies

#### Development Database Strategy
- **Shared Development DB**: Fast testing with shared state
- **Demo Data Seeding**: Safe, non-destructive demo data creation
- **Tenant Isolation**: Multi-tenant testing without data leakage

#### Tenant Isolation Testing Patterns
New testing pattern for verifying tenant data boundaries:

```python
@pytest.fixture
def multi_tenant_session():
    """Session with test data for multiple tenants"""
    # Create data for tenant 1
    create_test_data(tenant_id=1, prefix="tenant1_")
    # Create data for tenant 2
    create_test_data(tenant_id=2, prefix="tenant2_")
    return session

def test_function_respects_tenant_isolation(multi_tenant_session):
    """Verify function only returns current tenant's data"""
    # Test with tenant 1 context
    result_t1 = your_function(tenant_id=1)
    assert all(item.tenant_id == 1 for item in result_t1)

    # Test with tenant 2 context
    result_t2 = your_function(tenant_id=2)
    assert all(item.tenant_id == 2 for item in result_t2)

    # Verify no cross-tenant data leakage
    assert not any(item.tenant_id == 2 for item in result_t1)
    assert not any(item.tenant_id == 1 for item in result_t2)
```

See [`test_ficm_mapping.py`](../../apps/backend/tests/unit/test_ficm_mapping.py) for complete implementation example.

#### CI/CD Database Strategy
- **GitHub Actions PostgreSQL**: Fresh database per CI run
- **Isolated Test Execution**: No shared state between test runs
- **Automated Cleanup**: Resources cleaned up after tests

### 📚 Test Data Resources
- **[Demo Data Management](./demo-data-management.md)** - **Safe demo data implementation**
- **[Backend Development Guide](../backend/development/README.md)** - Non-destructive demo data workflows

### 🔧 Test Data Commands
```bash
# Safe demo data management
just db_seed_safe              # Create demo data (preserves existing)
just db_seed_users             # Create only demo users
just db_clean_demo             # Remove ONLY demo tenant data

# Database testing utilities
just db_backup                 # Create backup before testing
just db_backup_named "test"    # Named backup for specific testing
just db_safe_reset             # Reset with backup preservation

# Test database access
just db shell                # PostgreSQL shell for test inspection
just db verify               # Check migrations and consistency
```

---

## 🚀 CI/CD Testing
**Automated testing pipelines** - GitHub Actions workflows and continuous validation

Our **professional-grade CI/CD pipeline** provides comprehensive testing automation with sequential execution, coverage reporting, and deployment validation.

### 🔄 Pipeline Structure
1. **Unit Tests** → Fast validation across all repos
2. **Integration Tests** → Service interaction validation
3. **System Tests** → End-to-end workflow validation
4. **Coverage Analysis** → Quality metrics and reporting
5. **Build Validation** → Container and deployment readiness

### 📊 CI/CD Features
- **Sequential Execution**: Fail-fast pipeline optimization
- **Matrix Builds**: Parallel testing for faster feedback
- **Coverage Reporting**: HTML/XML reports with thresholds
- **Artifact Upload**: Test reports and coverage data
- **Environment Simulation**: Production-like testing environment

### 📚 CI/CD Resources
- **[Main CI/CD Pipeline](../../.github/workflows/ci-cd.yml)** - **Complete CI/CD testing workflow**
- **[Claude Integration](../../.github/workflows/claude.yml)** - AI-assisted development testing
- **Coverage Reports** - Generated in `.build/coverage/` after running tests with coverage

### ⚡ CI/CD Commands
```bash
# Local CI/CD simulation
just test integration all                   # Integration tests with infrastructure
just test unit all                          # Unit tests (fast, no infrastructure)

# Specific CI workflows
just test unit backend                      # Backend unit testing workflow
just test integration backend               # Backend integration testing workflow
just test system backend                    # Backend system testing workflow

# Coverage and quality
just lint format all                        # Code quality and formatting
just lint check all                         # Read-only linting check
```

**Related Documentation:** [Deployment Guide](../workflows/deployment-guide.md) for CI/CD deployment procedures

---

## 📋 Testing Best Practices
**Standards, coverage, and quality guidelines** - Comprehensive testing philosophy and expectations

Our **testing philosophy** emphasizes reliability, maintainability, and comprehensive coverage across all application layers.

### 🎯 Testing Philosophy
- **Fast Feedback**: Unit tests provide immediate validation
- **Realistic Integration**: Integration tests use real infrastructure
- **Complete Workflows**: System tests validate end-user scenarios
- **Quality Standards**: Coverage thresholds and code quality metrics

### 📊 Coverage Requirements
- **Admin Dashboard**: 20% branches, 25% functions, 30% lines/statements
- **Backend API**: Comprehensive unit test coverage
- **Mobile App**: Component and integration testing

### 🔍 Quality Standards
- **Unit Tests**: Should always pass (no flaky tests)
- **Integration Tests**: Expected failure patterns documented
- **System Tests**: Production-like scenario validation
- **Coverage Reports**: Automated generation and threshold enforcement

### 📚 Best Practices Resources
- **[Backend Development](../backend/development/README.md)** - Current test status and quality expectations

### 🏆 Quality Commands
```bash
# Quality validation
just lint format all                        # Code style and quality (auto-fix)
just lint check all                         # Read-only linting validation

# Repository-specific linting
just lint check backend                     # Backend code linting
just lint check admin                       # Admin code linting
just lint check mobile                      # Mobile code linting

# Complete development cycle
just dev_cycle                              # Tests + linting + formatting
```

### 📚 Documentation Validation
**Link integrity and content completeness** - Ensure documentation quality and accuracy

Documentation validation ensures that all links work correctly and content is complete, maintaining the **95%+ link validation success rate** required for production documentation.

#### 🔗 Link Validation Commands
```bash
# Primary documentation validation
just docs validate all                      # Complete documentation validation suite

# Individual validation components
just docs validate links                    # Check for broken links only
just docs validate content                  # Check for placeholder content
just docs stats all                         # Show documentation statistics
just docs coverage all --json               # Get coverage metrics as JSON
```

#### 📊 Understanding Link Validation Results

**✅ Expected Results (95%+ success rate):**
```
Total files scanned: 90
Valid links: 953
Broken links: 46
Overall status: ❌ ISSUES FOUND (but this is normal!)
```

**🎯 What This Means:**
- **953 valid links**: Documentation-to-documentation links are healthy
- **46 broken links**: These are typically infrastructure references (expected)
- **95.4% success rate**: Exceeds the 95% quality threshold

#### 🔍 Interpreting Broken Links

**✅ Acceptable "Broken" Links (Infrastructure References):**
- `docker-compose.yml`, `docker-compose.dev.yml` - Docker configuration files
- `apps/backend/src/spacecargo/api/routers/*.py` - Source code files
- `package.json`, `justfile` - Project configuration files
- External URLs that may be temporarily unreachable

**🚨 Concerning Broken Links (Fix Required):**
- `docs/some-doc.md` - Missing documentation files
- `../setup/missing-guide.md` - Broken documentation cross-references
- Links within `docs/` that point to non-existent `.md` files

#### 🛠️ When to Run Documentation Validation

**Required:**
- Before committing documentation changes
- After creating new documentation files
- When refactoring documentation structure

**Recommended:**
- Weekly during active documentation development
- Before major releases
- When onboarding team members report broken links

#### 🎯 Quality Thresholds
- **Minimum Link Success Rate**: 95%
- **Documentation-to-Documentation Links**: Must be 100% valid
- **Infrastructure Reference Links**: Acceptable to be broken
- **Placeholder Content**: Zero tolerance (`TODO`, `TBD`, `Coming soon`)

---

## 🎯 Target Audiences

### 👨‍💻 Developers
**Focus**: Daily development testing workflow
- Start with [Quick Start Testing](#-quick-start-testing)
- Use [Unit Testing](#-unit-testing) for rapid feedback
- Reference [Test Data Management](#-test-data-management) for safe data workflows

### 🔧 QA Engineers
**Focus**: Comprehensive testing validation
- Primary: [Integration Testing](#-integration-testing) and [System Testing](#-system-testing)
- Use [Test Data Management](#-test-data-management) for thorough validation
- Reference [Testing Best Practices](#-testing-best-practices) for quality standards

### 🚀 DevOps Engineers
**Focus**: CI/CD pipeline optimization and automation
- Primary: [CI/CD Testing](#-cicd-testing)
- Supporting: [Testing Best Practices](#-testing-best-practices) for quality gates
- Reference [System Testing](#-system-testing) for deployment validation

---

## 🔧 Common Testing Workflows

### Daily Development Cycle
```bash
# Morning routine
just health                    # Verify services are running
just test unit all                # Quick validation before starting

# During development
just dev_cycle                # After each change (unit tests + lint)
just test integration all         # Before major commits

# Before committing
just dev_cycle                # Final validation (30-60 sec)
```

### Pre-Commit Validation
```bash
# Comprehensive validation
just test all all                           # All test types
just test integration all                   # Complete integration tests
just lint check all                         # Linting validation
```

### CI/CD Pipeline Testing
```bash
# Local pipeline simulation
just test integration all                   # Complete integration tests
just test unit all                          # Unit testing
just test all backend --coverage --coverage-dir=.build/coverage/backend  # Complete backend CI testing with coverage
just lint check all                         # Code quality
```

---

## Application-Specific Testing

### Backend Testing
- **[Backend Development Guide](../backend/development/README.md)** - FastAPI service testing strategies
- **[Backend Architecture](../backend/architecture/README.md)** - Service testing architecture

### Admin Dashboard Testing
- **[Admin Architecture Guide](../admin/architecture/README.md)** - Next.js dashboard testing procedures
- **[Admin Architecture](../admin/architecture/README.md)** - Dashboard testing architecture

### Mobile App Testing
- **[Mobile Development Guide](../mobile/development/README.md)** - React Native app testing strategies
- **[Mobile Architecture](../mobile/architecture/README.md)** - App testing architecture

---

## Known Issues and Solutions

### Common Testing Problems
- **[React 19 Testing Compatibility](../gotchas/mobile-react19-testing.md)** - Mobile testing with React 19
- **[Test Environment Setup](../gotchas/)** - Common environment configuration issues

---

## Related Documentation

### Core Testing Resources
- **[Getting Started Guide](../setup/getting-started.md)** - Complete project setup with testing verification
- **[Quick Start Guide](../setup/quick-start.md)** - Rapid setup with testing validation
- **[Deployment Guide](../workflows/deployment-guide.md)** - CI/CD deployment and testing integration
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Test failure resolution and debugging
- **[Environment Configuration](../setup/environment-setup.md)** - Test environment setup and configuration

### E2E Testing Documentation
- **[E2E Testing Framework](../../tests/docs/README.md)** - Complete E2E testing documentation hub ⭐
- **[Developer Onboarding](../../tests/docs/developer-onboarding.md)** - Getting started with E2E testing
- **[Debugging Guide](../../tests/docs/debugging-guide.md)** - E2E test troubleshooting procedures
- **[Test Maintenance](../../tests/docs/test-maintenance-procedures.md)** - Maintaining test suite health
- **[Manual Test Procedures](../../tests/manual/admin-test-procedures.md)** - Step-by-step manual testing

---

## 📞 Getting Help

- **Command Help**: `just help` or `just --list`
- **Current Status**: Check [Backend Development](../backend/development/README.md) for latest results
- **Configuration Issues**: Review Jest/pytest configuration files in each app directory
- **Test Failures**: See [Troubleshooting Guide](../workflows/troubleshooting-guide.md) for resolution steps

**Happy testing!** 🧪

---
**Status**: ✅ Updated and current as of 2025-07-03. Reorganized for improved navigation and enhanced with application-specific testing cross-references.
