# Production Monitoring Deployment Guide

## Purpose
Step-by-step guide for deploying and validating monitoring infrastructure in production environment, including Slack integration and health verification.

## When to Use This
- Setting up monitoring for new production deployment
- Disaster recovery scenarios requiring monitoring rebuild
- Migrating monitoring between AWS accounts
- Troubleshooting production monitoring issues

**Keywords:** production, monitoring, deployment, slack, alerts, cloudwatch

---

## 🚨 Prerequisites

### Required Access
- Production AWS account access (`AWS_PROFILE=production`)
- Slack workspace admin permissions for webhook creation
- Production mode enabled: `just prod enable [minutes]`

### Infrastructure Dependencies
- Foundation stack deployed (`prod-spacewalker-foundation`)
- Backend service deployed (required for alarm targets)
- DNS and domain configuration completed

### Certificate Architecture
- **Development**: Certificates managed by DNS stack (`dev-spacewalker-dns`)
- **Production**: Uses external hardcoded certificate for `*.spacewalker.degreeanalytics.com`
- Both environments deploy the same 8 core stacks (no separate certificates stack)

### Verification Commands
```bash
# Check prerequisites
just stack_status prod
(just prod enable --minutes=10)  # Enable production access

# Verify foundation exists
aws cloudformation describe-stacks --stack-name prod-spacewalker-foundation --region us-east-1
```

---

## 🚀 Production Deployment Process

### Step 1: Enable Production Access
```bash
# Enable production mode (adjust minutes as needed)
(just prod enable --minutes=15)

# Verify correct AWS account
aws sts get-caller-identity
# Should show account: 352676346183 (actual production account)
```

### Step 2: Deploy Monitoring Infrastructure
```bash
# Deploy complete monitoring stack
just aws_deploy_monitoring prod

# Verify deployment
just stack_status prod
```

**Expected Results:**
- Stack Status: `CREATE_COMPLETE` or `UPDATE_COMPLETE`
- Components: SNS topic, Lambda function, IAM roles, log groups

### Step 3: Configure Slack Integration

#### 3.1 Create Production Slack Webhook
1. Go to Slack workspace settings
2. Navigate to **Apps** → **Incoming Webhooks**
3. Click **Add to Slack**
4. Select channel: `#spacewalker-prod-alerts`
5. Copy webhook URL (starts with `https://hooks.slack.com/services/`)

#### 3.2 Create AWS Secret
```bash
# Create Slack webhook secret (use actual webhook URL)
just secrets_create_slack prod "https://hooks.slack.com/services/T2NT6RK6X/B094U5KPV2N/..."

# Verify secret creation
just aws_secrets_health prod
```

### Step 4: Comprehensive Validation
```bash
# Full monitoring validation (includes Slack test)
just monitor validate prod

# Production-specific health check
just monitor status prod
```

---

## 🧪 Validation Checklist

### Infrastructure Validation
- [ ] **Monitoring Stack**: `✅ CREATE_COMPLETE`
- [ ] **SNS Topic**: `✅ EXISTS`
- [ ] **Lambda Function**: `✅ EXISTS`
- [ ] **Slack Secret**: `✅ EXISTS`

### Functional Validation
- [ ] **Slack Test Message**: Successfully sent to #spacewalker-prod-alerts
- [ ] **Lambda Execution**: Returns 200 status code
- [ ] **Secret Access**: Lambda can read webhook URL from secret
- [ ] **CloudWatch Integration**: SNS topic ready for alarm notifications

### Expected Test Output
```
🔍 Validating monitoring infrastructure for prod...
Region: us-east-1
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Monitoring Stack: ✅ CREATE_COMPLETE
🤖 Slack Lambda: ✅ EXISTS
📡 SNS Topic: ✅ EXISTS
🔐 Slack Secret: ✅ EXISTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧪 Running Slack integration test...
📢 Testing Slack notifications for prod...
✅ Lambda invocation successful
🎉 Slack notification sent successfully!
💬 Check your #spacewalker-prod-alerts channel for the test message
```

---

## 🔧 Troubleshooting Production Issues

### Common Production Deployment Issues

#### 1. S3 Bucket Not Found
**Error**: `S3 Bucket not specified`
**Solution**: Use correct production deployment bucket
```bash
# Find production S3 bucket
aws s3 ls | grep spacewalker | grep prod

# Deploy with specific bucket
sam deploy --template-file sam/monitoring/simple-monitoring.yaml \
  --stack-name prod-spacewalker-monitoring \
  --parameter-overrides Environment=prod \
  --s3-bucket prod-spacewalker-sam-deployment-bucket-352676346183 \
  --capabilities CAPABILITY_IAM CAPABILITY_NAMED_IAM \
  --region us-east-1
```

#### 2. Cross-Account IAM Issues
**Error**: Access denied or insufficient permissions
**Solutions**:
- Verify `AWS_PROFILE=production` is set
- Check IAM role has CloudFormation and Lambda permissions
- Ensure cross-account trust relationships are configured

#### 3. Lambda Environment Variables Not Updated
**Error**: Lambda still using old configuration
**Solution**: Force Lambda function restart
```bash
# Update Lambda configuration to force restart
aws lambda update-function-configuration \
  --function-name spacewalker-slack-notifications-prod \
  --environment Variables='{
    "ENVIRONMENT":"prod",
    "SNS_TOPIC_ARN":"arn:aws:sns:us-east-1:352676346183:prod-spacewalker-alerts",
    "SLACK_WEBHOOK_SECRET_NAME":"prod/spacewalker/slack-webhook"
  }' \
  --region us-east-1
```

#### 4. Secret Wrong Format
**Error**: Lambda cannot parse webhook URL
**Solution**: Ensure secret uses correct JSON format
```bash
# Check current secret format
just aws_secret_show prod "prod/spacewalker/slack-webhook"

# Fix secret format (use webhook_url, not WEBHOOK_URL)
aws secretsmanager update-secret \
  --secret-id "prod/spacewalker/slack-webhook" \
  --secret-string '{"webhook_url":"https://hooks.slack.com/services/..."}' \
  --region us-east-1
```

### Diagnostic Commands
```bash
# Check Lambda logs for errors
aws logs tail /aws/lambda/spacewalker-slack-notifications-prod --follow --region us-east-1

# Test Lambda function directly
aws lambda invoke \
  --function-name spacewalker-slack-notifications-prod \
  --payload '{"Records":[{"Sns":{"Message":"{\"AlarmName\":\"TEST\",\"NewStateValue\":\"ALARM\",\"StateChangeTime\":\"2024-01-01T12:00:00.000Z\"}"}}]}' \
  /tmp/test-response.json \
  --region us-east-1

# Check SNS topic configuration
aws sns get-topic-attributes \
  --topic-arn "arn:aws:sns:us-east-1:352676346183:prod-spacewalker-alerts" \
  --region us-east-1
```

---

## 🔄 Post-Deployment Configuration

### Enable CloudWatch Alarms
After monitoring deployment, configure alarms to use the SNS topic:

```bash
# Check if backend alarms can reference the monitoring stack
aws cloudformation describe-stacks \
  --stack-name prod-spacewalker-backend \
  --query 'Stacks[0].Parameters[?ParameterKey==`MonitoringStackName`]' \
  --region us-east-1

# If not configured, update backend stack to reference monitoring
# (This may require backend redeployment)
```

### Configure Alert Channels
1. **Critical Alerts**: Route to #spacewalker-prod-alerts + PagerDuty
2. **Warning Alerts**: Route to #spacewalker-prod-alerts only
3. **Info Alerts**: Log only, no notifications

### Set Up Dashboard Access
Production team members should bookmark:
- **System Overview**: CloudWatch console → Dashboards → prod-spacewalker-system-overview
- **Real-time Monitor**: CloudWatch console → Dashboards → prod-spacewalker-realtime
- **Alarms View**: CloudWatch console → Alarms (filtered by prod-spacewalker-)

---

## 🚨 Emergency Procedures

### Monitor Monitoring System
Even monitoring needs monitoring. Set up these safeguards:

#### 1. Lambda Function Health
```bash
# Check Lambda function is not erroring
aws logs filter-log-events \
  --log-group-name /aws/lambda/spacewalker-slack-notifications-prod \
  --start-time $(date -d '1 hour ago' +%s)000 \
  --filter-pattern "ERROR" \
  --region us-east-1
```

#### 2. Slack Webhook Validation
```bash
# Test webhook is still active (run weekly)
just monitor slack-test prod
```

#### 3. SNS Topic Subscription Health
```bash
# Verify Lambda is subscribed to SNS topic
aws sns list-subscriptions-by-topic \
  --topic-arn "arn:aws:sns:us-east-1:352676346183:prod-spacewalker-alerts" \
  --region us-east-1
```

### Disaster Recovery
If monitoring completely fails:

1. **Immediate**: Deploy monitoring from scratch
   ```bash
   (just prod enable --minutes=20)
   just aws deploy monitoring prod
   just secrets_create_slack prod "backup-webhook-url"
   just monitor validate prod
   ```

2. **Temporary**: Use manual monitoring
   - Monitor CloudWatch console directly
   - Set up temporary alerts via AWS Console
   - Use mobile app push notifications if available

3. **Communication**: Notify team via alternative channels
   - Email alerts to team distribution list
   - Manual status updates in primary team channel

---

## 📊 Production Metrics and SLAs

### Monitoring System SLAs
- **Alert Delivery**: < 2 minutes from alarm trigger to Slack notification
- **Uptime**: 99.9% availability (monitored via CloudWatch Lambda metrics)
- **Error Rate**: < 0.1% failed notifications

### Key Metrics to Monitor
- Lambda function error rate
- Lambda function duration
- SNS message delivery rate
- Slack webhook response time

### Alerting on Alerting
Consider setting up alerts for:
- Lambda function errors > 5% over 5 minutes
- SNS message failures > 1 over 10 minutes
- Lambda function duration > 30 seconds

---

## 🔗 Related Documentation
- [Slack Integration Setup](../monitoring/slack-integration-setup.md) - Detailed Slack configuration
- [Monitoring Runbook](../monitoring/monitoring-runbook.md) - Day-to-day operations
- [Alert Thresholds](../monitoring/alert-thresholds-and-escalation.md) - Alert configuration
- [Environment Configuration](../setup/environment-configuration.md) - AWS configuration

---

## 📝 Production Checklist

### Pre-Deployment
- [ ] Production access enabled
- [ ] Foundation infrastructure deployed
- [ ] Backend services deployed
- [ ] Slack webhook created for #spacewalker-prod-alerts

### Deployment
- [ ] Monitoring stack deployed successfully
- [ ] Slack secret created with correct format
- [ ] Lambda function exists and configured
- [ ] SNS topic created

### Validation
- [ ] `just monitor validate prod` passes
- [ ] Test message appears in #spacewalker-prod-alerts
- [ ] CloudWatch dashboards accessible
- [ ] All secrets health checks pass

### Post-Deployment
- [ ] Team notified of new monitoring
- [ ] Dashboard bookmarks shared
- [ ] Escalation procedures updated
- [ ] Monitoring system itself monitored
