# Spacewalker Testing Strategy

## Purpose
Comprehensive testing strategy and implementation guide for all Spacewalker platforms including backend, admin dashboard, and mobile applications. Essential reference for understanding testing approaches, database strategies, and cross-platform testing coordination.

## When to Use This
- Understanding testing strategies and when to use each approach
- Setting up testing environments for different development scenarios
- Troubleshooting testing issues across platforms
- Coordinating testing between backend, admin, and mobile teams
- Implementing CI/CD testing workflows
- Keywords: testing strategy, unit tests, integration tests, cross-platform testing, database testing

**Version:** 2.0 (Reorganized from testing-specific documentation)
**Date:** 2025-06-29
**Status:** Current - Cross-Platform Testing Strategy

---

## <¯ Testing Strategy Overview

### The Cross-Platform Challenge
Spacewalker testing involves coordination across three distinct platforms with different database and infrastructure requirements:

1. **=3 Docker Compose Strategy** - Shared development database for fast iteration
2. **=, Testcontainers Strategy** - Isolated containers for clean testing (CI-like)
3. ** CI Environment Strategy** - GitHub Actions with PostgreSQL service

This diversity enables flexible development but requires clear guidelines to avoid conflicts and confusion.

### Platform Testing Scope
- **Backend (FastAPI)** - API endpoints, business logic, database integration, AI services
- **Admin Dashboard (Next.js)** - UI components, workflows, integration with backend APIs
- **Mobile App (React Native)** - Mobile-specific functionality, offline capabilities, sync logic

---

## =Ê Test Types & Strategy Matrix

| Test Type | Speed | Isolation | Backend | Admin | Mobile | When to Use |
|-----------|-------|-----------|---------|--------|--------|-------------|
| **Unit** ¡ | Fast | Full |  |  |  | Always - no infrastructure needed |
| **Integration** = | Medium | Partial |  |  |  | Testing with real services/APIs |
| **System** <× | Slow | Full |  |  |  | End-to-end workflows |

### Platform-Specific Test Characteristics
- **Backend Tests** - Focus on API contracts, database operations, AI service integration
- **Admin Tests** - UI component testing, workflow validation, data display accuracy
- **Mobile Tests** - Platform-specific behavior, offline functionality, sync reliability

---

## ¡ Unit Testing Strategy (All Platforms)

### Universal Unit Test Commands
```bash
# Run all platform unit tests
just test unit all              # All platforms: backend, admin, mobile
just test unit all_cov           # With coverage reports across platforms

# Platform-specific unit tests
just test unit all_backend       # Backend API and business logic only
just test unit all_admin         # Admin dashboard components only
just test unit all_mobile        # Mobile app functionality only
```

### Unit Test Principles
** Use unit tests when:**
- Developing new features across any platform
- Need quick feedback loops during development
- Testing pure business logic without external dependencies
- Validating component behavior in isolation

**L Unit tests never fail due to:**
- Database connectivity issues
- Network problems or service unavailability
- Infrastructure configuration problems
- Cross-platform integration issues

### Expected Unit Test Results
- **Backend**: ~151 tests  (100% success expected)
- **Admin**: ~20+ tests  (100% success expected)
- **Mobile**: ~389 tests  (6 known failures due to alert message format changes)

---

## =3 Docker Compose Testing Strategy (Fast Development)

### Docker Compose Commands
```bash
# Fast integration testing with shared database
just test integration all_local  # Integration tests across platforms
just test_complete_local     # Complete test suite with shared DB
```

### Docker Compose Characteristics
** Use Docker Compose strategy when:**
- Fast development cycles across platforms
- Working with existing test data and schemas
- Quick feedback on database integration
- Local development with established environment

**L Common issues with Docker Compose:**
- Shared database state between test runs
- RLS (Row Level Security) conflicts between platforms
- Data pollution affecting cross-platform test results
- Platform-specific database configurations conflicting

**=' Fix Docker Compose issues:**
```bash
just db_reset               # Clean shared database state
just health                 # Verify all services are running
```

### Expected Docker Compose Results
- **Integration Tests**: ~378 passed (94% success rate)
- **Common Failures**: ~19 tests (RLS disabled scenarios, storage configuration)
- **Execution Time**: ~30 seconds for complete integration suite

---

## =, Testcontainers Strategy (CI-Like, Most Reliable)

### Testcontainers Commands
```bash
# Isolated testing with clean containers
just test integration all_iso   # Isolated integration tests
just test system backend            # System tests (always isolated)
just test_complete_iso      # Complete test suite (CI-like behavior)
```

### Testcontainers Characteristics
** Use Testcontainers strategy when:**
- Need clean database state for reliable testing
- Before submitting PRs for review
- Debugging test isolation issues across platforms
- Want CI-like behavior in local development
- Testing cross-platform integration scenarios

**L Testcontainers considerations:**
- Slower startup time (downloads Docker images)
- Higher system resource usage
- First run can be very slow due to image downloads
- May require Docker configuration adjustments

### Expected Testcontainers Results
- **Integration Tests**: ~385 passed (93% success rate)
- **Expected Failures**: ~23 tests (RLS configuration, storage setup issues)
- **Execution Time**: ~1-2 minutes for complete suite

---

##  CI Strategy (GitHub Actions)

### CI Environment Characteristics
```bash
# CI commands run automatically - not called directly
test unit backend         # Backend unit tests
test integration backend  # Backend integration tests
test all admin --coverage --coverage-dir=.build/coverage/admin    # Admin dashboard tests in CI with coverage
test all mobile --coverage --coverage-dir=.build/coverage/mobile  # Mobile app tests in CI with coverage
```

### CI Testing Behavior
**=' CI Configuration:**
- Uses PostgreSQL service container
- Clean database for every test run
- Environment: `DATABASE_URL=postgresql://postgres:postgres@localhost:5432/spacewalker_test`
- Parallel execution across platform test suites

** CI Strategy ensures:**
- Complete isolation between test runs
- Fresh environment for every platform
- Cross-platform integration validation
- Production-like testing conditions

---

## =¨ Cross-Platform Testing Issues & Solutions

### Issue 1: "Connection to db:5432 failed" (Cross-Platform)
**Problem:** Tests trying to connect to Docker container from host environment
**Platforms Affected:** Backend, Admin (when testing API integration)
**Solution:** Use isolated testing: `just test integration all_iso`

### Issue 2: RLS (Row Level Security) Test Failures
**Problem:** Multi-tenant RLS tests expect clean database state
**Platforms Affected:** Backend (primarily), Admin (multi-tenant workflows)
**Solution:**
```bash
# Option 1: Use isolated tests
just test integration all_iso

# Option 2: Reset shared database
just db_reset && just test integration all_local
```

### Issue 3: Tests Pass in CI But Fail Locally
**Problem:** Different database strategies causing inconsistent results
**Platforms Affected:** All platforms
**Solution:** Use CI-like behavior locally: `just test_complete_iso`

### Issue 4: Mobile Alert Message Test Mismatches
**Problem:** Error message format changed but tests expect old format
**Platforms Affected:** Mobile (React Native)
**Solution:** Update test expectations in mobile test files to match current message formats

### Issue 5: Cross-Platform API Contract Failures
**Problem:** Backend API changes break Admin/Mobile integration tests
**Platforms Affected:** Admin, Mobile (when testing backend integration)
**Solution:**
```bash
# Test backend first
just test unit all_backend
just test integration all_backend

# Then test platform integration
just test integration all_iso  # For complete cross-platform validation
```

---

## =Ë Recommended Cross-Platform Testing Workflows

### Daily Development Workflow
```bash
# Quick feedback across platforms
just test unit all              # Fast unit tests for all platforms

# Platform-specific development
just test unit all_backend       # When working on backend features
just test unit all_admin         # When working on admin interface
just test unit all_mobile        # When working on mobile features

# Fast integration testing
just test integration all_local  # Quick cross-platform integration check
```

### Pre-Commit Workflow (Recommended)
```bash
# Complete validation before committing
just test_complete_iso      # Full CI-like validation across platforms
```

### Cross-Platform Integration Testing
```bash
# When working on features that span platforms
just test integration all_iso   # Isolated cross-platform integration
just test system backend            # End-to-end workflow validation
```

### Debugging Cross-Platform Issues
```bash
# Step-by-step debugging approach
just test unit all              # Verify platform-specific logic
just test integration all_iso   # Isolate database and service issues
just db_reset               # Clean shared database state
just test integration all_local # Test against clean shared environment
just health                 # Verify all services are operational
```

### CI/Production Validation
- GitHub Actions automatically runs complete test suite
- Uses PostgreSQL service for clean database state
- Should always pass if `test_complete_iso` passes locally
- Validates cross-platform integration in production-like environment

---

## =Ê Expected Test Results by Platform

### ¡ Unit Tests (Should Always Pass - 100%)
- **Backend Unit Tests**: ~151 tests  (API logic, business rules, utilities)
- **Admin Unit Tests**: ~20+ tests  (React components, utility functions)
- **Mobile Unit Tests**: ~389 tests  (6 known alert message failures)

### =, Integration Tests (Platform Coordination)
**Isolated Integration (`test_integration_iso`):**
- **Expected Success**: ~385 passed (93% success rate)
- **Expected Failures**: ~23 tests (RLS configuration, storage setup)
- **Execution Time**: ~1-2 minutes
- **Covers**: Cross-platform API integration, database operations, service coordination

**Local Integration (`test_integration_local`):**
- **Expected Success**: ~378 passed (94% success rate)
- **Expected Failures**: ~19 tests (RLS disabled scenarios, storage issues)
- **Execution Time**: ~30 seconds
- **Covers**: Fast feedback on platform integration

### <× System Tests (End-to-End Workflows)
- **Expected Success**: ~13 passed (81% success rate)
- **Expected Failures**: ~3 tests (API configuration, cross-platform workflow issues)
- **Covers**: Complete user workflows spanning multiple platforms

---

## =' Platform Testing Quick Reference

| Command | Database | Coverage | Speed | Backend | Admin | Mobile | Use Case |
|---------|----------|----------|-------|---------|--------|--------|----------|
| `test_unit` | None | No | ¡¡¡ |  |  |  | Development |
| `test_unit_cov` | None | Yes | ¡¡ |  |  |  | Coverage check |
| `test_integration_local` | Docker Compose | No | ¡ |  |  |  | Fast integration |
| `test_integration_iso` | Testcontainers | No | = |  |  |  | Clean integration |
| `test_complete_local` | Docker Compose | Yes | ¡ |  |  |  | Fast complete |
| `test_complete_iso` | Testcontainers | Yes | == |  |  |  | CI-like complete |

---

## < Troubleshooting Escalation Guide

### When Tests Fail More Than Expected

**Step 1: Start with Unit Tests**
```bash
just test unit all              # Should always pass for all platforms
```
If unit tests fail, focus on platform-specific logic issues before proceeding.

**Step 2: Try Isolated Integration Tests**
```bash
just test integration all_iso   # Should get ~385 passed across platforms
```
If isolated tests fail significantly, investigate database or service configuration issues.

**Step 3: Reset Shared Environment**
```bash
just db_reset               # Clean shared database state
just test integration all_local # Test against clean environment
```

**Step 4: Verify Platform Services**
```bash
just health                 # Ensure all Docker services are running
just env_status             # Check environment configuration
```

**Step 5: Platform-Specific Debugging**
```bash
# Debug specific platform issues
just test unit all_backend      # Isolate backend issues
just test unit all_admin        # Isolate admin issues
just test unit all_mobile       # Isolate mobile issues
```

**Step 6: Seek Team Assistance**
- Provide specific error messages and which testing strategy was used
- Include platform-specific details (backend/admin/mobile)
- Share environment information (`just env_status` output)

---

## =e Onboarding Guide for New Team Members

### Getting Started with Platform Testing
```bash
# Start with unit tests - should always work
just test unit all

# Try isolated integration - might be slow first time
just test integration all_iso
```

### Common New Developer Issues
**Database Connection Errors:**
- You're likely mixing testing strategies
- Use `_iso` commands for clean isolation
- Use `_local` commands for speed (but reset DB when issues occur)

**Platform-Specific Setup:**
- **Backend Developers**: Focus on `just test unit all_backend` and `just test integration all_iso`
- **Admin Developers**: Ensure backend is running for admin integration tests
- **Mobile Developers**: Use `just test unit all_mobile` for quick feedback

### Development Environment Verification
```bash
# Verify complete setup works
just health                 # Check service health
just test unit all              # Verify basic functionality
just test integration all_iso   # Verify clean testing works
```

---

## =Ú Related Testing Documentation

### Platform-Specific Testing Details
> =Ö **Backend Teams**: See [Backend Testing](../backend/testing/) for API testing specifics
> =Ö **Admin Teams**: See [Admin Testing](../admin/testing/) for UI testing approaches
> =Ö **Mobile Teams**: See [Mobile Testing](../mobile/testing/) for platform-specific testing

### Development & Operations
- **[Development Setup](../setup/development-setup.md)** - Development environment configuration required for testing
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Testing in deployed environments

### Architecture & Requirements
- **[Backend Architecture](../backend/architecture/README.md)** - Backend testing architecture and patterns
- **[Mobile Architecture](../mobile/architecture/README.md)** - Mobile testing considerations
- **[Admin Architecture](../admin/architecture/README.md)** - Admin testing workflows

---

**Status**:  **PRODUCTION READY & VALIDATED**
**Last Updated**: 2025-06-29
**Testing Approach**: Multi-Strategy (Docker Compose, Testcontainers, CI)
**Platform Coverage**: Backend, Admin Dashboard, Mobile Application

---

*This testing strategy enables reliable and coordinated testing across all Spacewalker platforms while providing flexibility for different development scenarios and team workflows.*
