# Git Merge Strategy

## Purpose
Professional git merge strategy and conflict resolution procedures to maintain clean target branches and ensure reviewable merge conflicts through proper Pull Request workflows. Essential reference for handling merge conflicts, maintaining project history integrity, and following best practices for branch management.

## When to Use This
- Before creating Pull Requests that may have merge conflicts
- When encountering merge conflicts during feature development
- Setting up branching strategies and PR workflows for development teams
- Understanding proper conflict resolution procedures that maintain code review integrity
- Training developers on professional git workflow practices
- Keywords: git merge conflicts, pull request workflow, branch management, conflict resolution, clean target branches

**Version:** 2.0 (Migrated from Cursor rules)
**Date:** 2025-06-29
**Status:** Current - Production Development Workflow

---

## 🛡️ Main Branch Protection Rules

### Critical Safety Requirements
**You MUST explicitly obtain confirmation before making any changes to the main branch.** These rules prevent accidental damage to the production codebase and ensure all changes follow proper review processes.

#### Actions Requiring Explicit Confirmation
- **Git Push Operations**: Any `git push` to main branch (especially with `--force` or `--force-with-lease`)
- **Pull Request Creation**: Running `gh pr create` with `--base main`
- **Ambiguous Instructions**: If a command could target main but isn't explicit (e.g., "push the changes", "create the PR")

#### Required Confirmation Questions
When main branch operations are detected, use these confirmation patterns:

```bash
# Push operation confirmation
"This action will push changes directly to the `main` branch. Please confirm you want to proceed."

# Pull request confirmation
"The target branch for this Pull Request is currently set to `main`. Is this correct, or should it target `dev` or another branch?"

# Ambiguous operation clarification
"Should this target the `main` branch or another branch? Please specify the target branch."
```

### Prohibited Actions (Without Confirmation)
Never execute these commands without explicit user approval:

```bash
# ❌ Direct main branch pushes
git push origin main
git push --force origin main
git push --force-with-lease origin main

# ❌ Pull requests targeting main
gh pr create --base main
```

### Recommended Safe Defaults
When the target branch is unclear, follow these safe practices:

```bash
# ✅ Default PR target to dev branch
gh pr create --base dev

# ✅ Always ask for target branch confirmation
echo "Which branch should this target? (dev/main/other):"
read target_branch

# ✅ Assume feature branch operations unless specified
git push origin feature-branch-name
```

### Automation Guidelines
- **Default Assumption**: Target is `dev` or current feature branch, NOT `main`
- **Explicit Requirements**: Main branch operations require explicit user intent
- **Safety First**: When in doubt, ask for clarification rather than assume main branch access

---

## 🎯 Core Strategy: Update Feature Branch Before PR

### The Golden Rule
**Always merge the target branch INTO your feature branch to resolve conflicts, then create a clean Pull Request.**

This approach ensures:
- Merge conflicts are resolved and reviewed on the feature branch **before** hitting the target branch
- Target branches (main, develop) remain clean with minimal conflict resolution
- All conflict resolution decisions are reviewable through the PR process
- Final merges into target branches are straightforward and low-risk

---

## 📋 Step-by-Step Workflow

### 1. Prepare Feature Branch
Ensure your feature branch is current and pushed to remote:

```bash
# On your feature branch (e.g., feature/user-auth)
git checkout feature/user-auth
git add .
git commit -m "feat(auth): complete user authentication feature"
git push origin feature/user-auth
```

### 2. Fetch Latest Target Branch
Get the most recent changes from the target branch:

```bash
# Fetch latest changes from target branch
git fetch origin main
```

### 3. Merge Target INTO Feature Branch
This is the key step - merge the target branch into your feature branch:

```bash
# Ensure you're on your feature branch
git checkout feature/user-auth

# Merge the target branch into your feature branch
git merge origin/main
```

### 4. Resolve Conflicts on Feature Branch
If conflicts occur, resolve them systematically:

```bash
# Check which files have conflicts
git status

# See conflicted files marked with "both modified"
```

#### Manual Conflict Resolution
For each conflicted file:

1. **Open the file** and look for conflict markers:
   ```
   <<<<<<< HEAD
   // Your feature branch changes
   =======
   // Changes from main branch
   >>>>>>> origin/main
   ```

2. **Edit the file** to desired final state:
   - Remove conflict markers (`<<<<<<<`, `=======`, `>>>>>>>`)
   - Keep the code you want from both sides
   - Ensure the result is functional and makes sense

3. **Handle deleted vs modified conflicts**:
   - Use `git rm <file>` to keep the deletion
   - Use `git add <file>` to keep the modified file

#### Visual Merge Tool (Recommended)
```bash
# Use configured merge tool for visual conflict resolution
git mergetool

# Popular options: VS Code, Sublime Merge, Beyond Compare, KDiff3
```

### 5. Complete the Merge
After resolving all conflicts:

```bash
# Stage all resolved files
git add .

# Commit the merge (Git provides default message)
git commit
# Default message: "Merge branch 'main' into feature/user-auth"
```

### 6. Push Updated Feature Branch
```bash
# Push feature branch with resolved conflicts
git push origin feature/user-auth
```

### 7. Create Clean Pull Request
Now create your PR with confidence:

```bash
# Using GitHub CLI
gh pr create --title "feat(auth): implement user authentication" --body "..."

# Or through GitHub web interface
```

The PR will show:
- ✅ Your feature changes relative to the updated main baseline
- ✅ How conflicts were resolved (reviewable in commit history)
- ✅ Clean, fast-forward merge potential

---

## ✅ Why This Strategy Works

### Benefits for Code Review
- **Reviewable Conflict Resolution**: PR reviewers can see exactly how conflicts were handled
- **Complete Context**: All merge decisions are documented in feature branch history
- **Clean Diffs**: PR shows only relevant feature changes, not merge artifacts

### Benefits for Project History
- **Clean Target Branch**: Main branch only receives approved, conflict-free merges
- **Traceable Decisions**: Each merge conflict resolution is associated with the feature that caused it
- **Rollback Safety**: Easy to identify and revert problematic merges

### Benefits for Team Workflow
- **Reduced Merge Complexity**: Final PR merge is typically conflict-free
- **Standard Practice**: Aligns with GitHub Flow and Gitflow methodologies
- **CI/CD Friendly**: Automated builds and tests run on the resolved code

---

## ⚠️ Anti-Patterns to Avoid

### Don't Merge Feature INTO Target Locally
```bash
# ❌ WRONG: Direct merge bypasses PR review
git checkout main
git merge feature/user-auth  # Conflicts resolved outside PR process
git push origin main         # Pushes unreviewed conflict resolution
```

**Problems with this approach:**
- Conflict resolution bypasses code review process
- No opportunity for team input on merge decisions
- Target branch history becomes messy
- Difficult to track which feature caused conflicts

### Don't Use Aggressive Merge Strategies Blindly
```bash
# ❌ DANGEROUS: Blindly favoring one side
git merge origin/main --strategy-option=theirs  # Loses your changes
git merge origin/main --strategy-option=ours    # Ignores important updates
```

**Use these only when:**
- You fully understand what changes will be lost
- The conflict is purely mechanical (e.g., package-lock.json)
- You've verified the result manually

---

## 🔧 Advanced Conflict Resolution

### Complex Merge Scenarios

#### Large Binary Files
```bash
# For binary files that can't be merged
git checkout --theirs path/to/binary-file
# Or
git checkout --ours path/to/binary-file
```

#### Package Lock Files
```bash
# For package-lock.json, yarn.lock, Pipfile.lock
git checkout --theirs package-lock.json
npm install  # Regenerate based on package.json
git add package-lock.json
```

#### Database Migrations
```bash
# Handle conflicting migration timestamps
# 1. Rename your migration to be after theirs
# 2. Update migration dependencies
# 3. Test migration sequence locally
```

### Merge Conflict Prevention

#### Regular Sync Strategy
```bash
# Daily sync to minimize conflicts
git fetch origin main
git merge origin/main

# Weekly cleanup
git branch --merged main | grep -v main | xargs git branch -d
```

#### Feature Branch Size Management
- Keep feature branches small and focused
- Merge to target branch within 3-5 days
- Break large features into smaller, sequential PRs

---

## 🛠️ Emergency Procedures

### Abort Merge if Things Go Wrong
```bash
# Cancel merge and return to pre-merge state
git merge --abort

# Check current status
git status
```

### Fix Incomplete Merge
```bash
# If you accidentally committed with unresolved conflicts
git reset HEAD~1          # Undo the merge commit
git status                # See what needs fixing
# Resolve conflicts properly, then re-commit
```

### Reset Feature Branch to Remote
```bash
# If local branch gets too messy
git fetch origin
git reset --hard origin/feature/user-auth
```

---

## 📊 Validation Checklist

### Before Creating PR
- [ ] Feature branch includes latest changes from target branch
- [ ] All merge conflicts resolved and tested
- [ ] Code compiles and runs without errors
- [ ] Unit tests pass with new merged code
- [ ] No conflict markers left in source files
- [ ] Merge commit message is clear and descriptive

### PR Quality Check
- [ ] PR diff shows only intended feature changes
- [ ] Conflict resolution decisions are documented in commit history
- [ ] CI/CD builds pass on the feature branch
- [ ] Branch is ready for fast-forward merge to target

---

## 📋 Related Development Documentation

### Git Workflow Documentation
- **[Git Commit Standards](./git-commit-standards.md)** - Formatting and conventions for commit messages
- **[Development Setup](../setup/development-setup.md)** - Complete development environment configuration

### Development Tools & Automation
- **[Development Tools](../development/development-tools.md)** - Professional automation and helper scripts
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Deployment procedures and CI/CD workflows

### Platform-Specific Workflows
> 🚀 **Backend Teams**: See [Backend Development](../backend/development/) for backend-specific git workflow integration
> 🚀 **Admin Teams**: See [Admin Development](../admin/development/) for dashboard development git practices
> 🚀 **Mobile Teams**: See [Mobile Development](../mobile/development/) for React Native development workflows

### Troubleshooting
- **[Development Tools](../development/development-tools.md)** - Common code review and merge mistakes to avoid
- **[Environment Setup](../setup/environment-setup.md)** - Common setup and configuration problems

---

**Status**: ✅ **PRODUCTION DEVELOPMENT WORKFLOW**
**Last Updated**: 2025-06-29
**Applies To**: All Spacewalker development teams (Backend, Admin, Mobile)
**Integration**: Git workflows, Pull Request processes, CI/CD pipelines

---

*This merge strategy ensures clean project history, reviewable conflict resolution, and professional development workflows across all Spacewalker teams. Following these procedures reduces merge complexity, improves code review quality, and maintains target branch integrity.*
