# Mobile Development Workflows

**SpaceWalker Mobile App** - Complete development workflows using justfile commands and best practices

---

## 📋 Overview

This guide covers the complete mobile development workflow for the SpaceWalker React Native application, including:
- **Development setup** and environment configuration
- **Build and deployment** workflows using justfile commands
- **Testing strategies** and quality assurance
- **CI/CD integration** with GitHub Actions
- **Troubleshooting** common development issues

---

## 🚀 Quick Start Workflow

### Initial Project Setup

```bash
# 1. Clone and setup project environment
git clone <repository-url>
cd spacewalker
just env_setup

# 2. Start all services
just up

# 3. Start mobile development
just expo start --offline
```

### Daily Development Workflow

```bash
# Morning routine
just up                    # Start all services
just health               # Verify all services are healthy
just expo start --offline # Start mobile development server

# Development cycle
just test unit all_mobile     # Run unit tests
just lint check mobile          # Check code quality
just dev_cycle           # Quick development validation

# End of day
just service clean mobile        # Clean up if needed
```

---

## 🛠️ Development Commands

### Core Development

#### Starting Development Server
```bash
# Start mobile development server
just expo start --offline
# Opens Expo development server at http://localhost:8081
# QR code available for device testing

# Start mobile with all services
just up                   # Starts backend, admin, mobile, and MinIO
# Access points:
# - Backend API: http://localhost:8000/docs
# - Admin: http://localhost:3000
# - Mobile: http://localhost:8081
# - MinIO Console: http://localhost:9001
```

#### Environment Configuration
```bash
# Update mobile IP configuration (for LAN testing)
just expo ip auto
# Updates mobile environment with current LAN IP address
# Needed when IP changes or for device testing

# Mobile-specific environment setup
just mobile_fresh
# Complete mobile reset: clean → install → start
# Use when dependencies or configuration changes
```

#### Health Checks
```bash
# Check mobile service health
just health
# Shows status of all services including mobile

# Mobile-specific health check (Docker)
docker compose ps mobile | grep -i healthy
```

### Testing Commands

#### Unit Testing
```bash
# Run all mobile unit tests with coverage
just test unit all_mobile
# Runs Jest tests in maxWorkers=1 mode for stability
# Generates coverage report in .build/coverage/mobile

# Run specific test file
just test all mobile_case "src/screens/LoginScreen.test.tsx"

# Run tests locally (outside Docker)
just test all mobile_local "src/screens/LoginScreen.test.tsx"

# Run tests with pattern matching
just test all mobile_case "src/screens --testNamePattern='should render'"
```

#### Integration Testing
```bash
# Run mobile integration tests
just test integration all_mobile
# Currently includes 1 integration test
# Focuses on API interactions and workflows

# Complete mobile test suite
just test all all_mobile
# Runs: unit tests → integration tests
# Full test coverage for mobile app
```

#### Test Watching and Development
```bash
# Watch mode for continuous testing
just test unit all --watch mobile "src/screens/LoginScreen.test.tsx"
# Automatically reruns tests when files change
# Useful during active development

# Test specific functionality
npm test -- --testNamePattern="geminiClient"
npm test -- --testNamePattern="attributeService"
```

### Code Quality and Formatting

#### Linting
```bash
# Lint mobile code with ESLint
just lint check mobile
# Auto-fixes minor issues, reports others
# Uses project ESLint configuration

# Check linting without auto-fix
just lint check all
# Read-only linting for CI-style validation
```

#### Code Formatting
```bash
# Format mobile code with Prettier
just lint format mobile
# Formats: src/**/*.{ts,tsx,js,jsx} and root files

# Format all code (backend, admin, mobile)
just format
```

### Dependency Management

#### Installation and Updates
```bash
# Install mobile dependencies only
just service install mobile
# Runs npm install in apps/mobile

# Install all project dependencies
just service install all
# Installs backend, admin, and mobile dependencies

# Check mobile dependency health
just env_check
# Verifies critical mobile dependencies are available
```

#### Cleaning and Reset
```bash
# Clean mobile artifacts only
just service clean mobile
# Stops processes, removes containers, cleans build artifacts
# Removes: .expo, node_modules, build caches

# Clean all project artifacts
just clean
# Complete project cleanup including Docker resources
```

---

## 📱 Build and Deployment Workflows

### Local Development Builds

#### Platform-Specific Development
```bash
# Run on iOS simulator
just mobile_ios
# Equivalent to: cd apps/mobile && npm run ios

# Run on Android emulator
just mobile_android
# Equivalent to: cd apps/mobile && npm run android

# Web development
cd apps/mobile && npm run web
# Runs mobile app in web browser for quick testing
```

#### Development Server Management
```bash
# Start mobile service only
just service up mobile
# Stops existing mobile container and starts fresh
# Useful when only mobile development is needed

# Health check with logs
just service up mobile && sleep 10 && just health
# Start and verify mobile service health
```

### EAS Builds (Production)

#### Build Commands
```bash
# Build iOS for local development (simulator)
just mobile_build_ios_local
# Uses EAS development profile
# Points to localhost:8000 backend

# Build iOS for dev server testing
just mobile_build_ios_dev
# Uses EAS preview profile
# Points to backend.spacewalker.littleponies.com

# Build Android for local development
just mobile_build_android_local
# Generates APK for local testing

# Build Android for dev server testing
just mobile_build_android_dev
# Generates AAB for internal distribution

# Build both platforms for local development
just mobile_build_local

# Build both platforms for dev server
just mobile_build_dev
```

#### Production Builds
```bash
# Build production iOS
eas build --platform ios --profile production

# Build production Android
eas build --platform android --profile production

# Build both platforms for production
eas build --platform all --profile production
```

#### Build Management
```bash
# Check build status
just mobile_build_status
# Shows recent EAS builds and their status

# Download latest iOS build
just mobile_download_ios
# Downloads latest iOS build to local machine

# List recent builds
eas build:list --platform all --limit 10
```

### TestFlight and Distribution

#### TestFlight Deployment
```bash
# Submit production build to TestFlight
just mobile_submit_testflight
# Submits latest production iOS build

# Full TestFlight deployment pipeline
just mobile_deploy_testflight
# Builds production iOS → submits to TestFlight

# Check submission status
eas submit:list --platform ios
```

#### CI/CD Integration
```bash
# For mobile builds, use EAS directly:
# cd apps/mobile && eas build --profile development
# Dry run with --non-interactive --no-wait flags

# Test mobile locally
just test unit mobile
# Runs unit tests with coverage

# Check CI build status
just mobile_ci_status
# Shows in-progress and recent CI builds
```

---

## 🔄 Development Workflows

### Feature Development Workflow

```bash
# 1. Setup development environment
just env_setup
just up

# 2. Create feature branch
git checkout -b feature/new-mobile-feature

# 3. Start mobile development
just expo start --offline

# 4. Development cycle
# ... write code ...
just test unit all_mobile          # Run tests frequently
just lint check mobile              # Check code quality
just mobile_ios               # Test on iOS simulator

# 5. Pre-commit validation
just test all all_mobile          # Full test suite
just lint format mobile            # Format code
just lint check mobile              # Final lint check

# 6. Commit and push
git add .
git commit -m "feat(mobile): add new feature"
git push origin feature/new-mobile-feature

# 7. Create PR and merge
# GitHub UI or CLI: gh pr create
```

### Testing Workflow

```bash
# 1. Unit testing during development
just test unit all_mobile
# Run frequently during development

# 2. Integration testing for API changes
just test integration all_mobile
# Test when backend APIs change

# 3. Device testing setup
just expo ip auto             # Update IP for device testing
just expo start --offline     # Start development server
# Scan QR code with Expo Go app

# 4. Platform-specific testing
just mobile_ios               # Test iOS-specific features
just mobile_android           # Test Android-specific features

# 5. Build testing
just mobile_build_ios_local   # Test build process
# Install on device/simulator for full testing

# 6. Performance and quality checks
just lint check mobile              # Code quality
just env_check  # Dependency health
```

### Release Workflow

```bash
# 1. Pre-release validation
just test all all_mobile          # Complete test suite
just mobile_build_local       # Test build process
just lint check mobile              # Code quality check

# 2. Version management
# Update version in apps/mobile/package.json
# Update version in apps/mobile/app.json

# 3. Build release candidates
just mobile_build_dev         # Preview build for testing
# Test with dev backend infrastructure

# 4. Production build
eas build --platform all --profile production
# Monitor build status: just mobile_build_status

# 5. TestFlight distribution
just mobile_submit_testflight
# Submit to Apple for beta testing

# 6. App Store submission (if approved)
# Manual process through App Store Connect
```

### Hotfix Workflow

```bash
# 1. Emergency setup
git checkout main
git pull origin main
git checkout -b hotfix/critical-issue

# 2. Quick fix implementation
# ... implement fix ...
just test all mobile_case "critical-path-tests"  # Test fix only

# 3. Emergency merge
git checkout main
git merge hotfix/critical-issue
git push origin main

# 4. Emergency build
just mobile_deploy_testflight    # Build and submit immediately

# 5. Expedited testing
# Notify key testers immediately
# Monitor TestFlight for rapid feedback

# 6. Fast-track to production
# Submit to App Store as emergency update
```

---

## 🔧 Environment Management

### Development Environment Switching

#### Local Development (Default)
```bash
# Standard local development setup
export EXPO_PUBLIC_API_BASE_URL=http://localhost:8000
export EXPO_PUBLIC_APP_VARIANT=development
just expo start --offline
```

#### Preview Environment Testing
```bash
# Test against dev backend
export API_BASE_URL=https://backend.spacewalker.littleponies.com
export APP_VARIANT=preview
just expo start --offline
```

#### Production Environment Testing
```bash
# Test against production backend (rare)
export API_BASE_URL=https://api.spacewalker.com
export APP_VARIANT=production
just expo start --offline
```

### Configuration Validation

```bash
# Validate current environment configuration
just mobile_env_validate
# Checks: API URL format, environment variables, connectivity

# Debug configuration issues
just mobile_config_debug
# Shows: current environment, API endpoints, variable sources

# Show current API configuration
just mobile_api_info
# Displays: API URL, environment, health status
```

### IP and Network Configuration

```bash
# Update IP configuration for device testing (recommended)
just expo ip auto
# Updates mobile configuration with current LAN IP
# Required when WiFi changes or IP address changes

# Manual IP configuration
just expo ip set 192.168.1.100

# Network troubleshooting
curl -X GET "$(just mobile_get_api_url)/health/"
# Test API connectivity from mobile perspective
```

---

## 🧪 Testing Strategies

### Test Categories

#### 1. Unit Tests
```bash
# Core business logic tests
just test unit all_mobile

# Specific test categories:
npm test -- --testNamePattern="aiProcessor"      # AI processing logic
npm test -- --testNamePattern="attributeService" # Attribute management
npm test -- --testNamePattern="geminiClient"     # AI client integration
npm test -- --testNamePattern="ficmService"      # FICM service logic
```

#### 2. Integration Tests
```bash
# API integration tests
just test integration all_mobile

# Component integration tests
npm test -- --testPathPattern="integration"
```

#### 3. Component Tests
```bash
# UI component tests (currently limited due to React 19 compatibility)
npm test -- --testNamePattern="component"

# Mock-based component testing
npm test -- --testPathPattern="components"
```

### Testing Best Practices

#### Test Execution Strategy
```bash
# 1. Fast feedback loop during development
just test unit all_mobile                    # 30-60 seconds

# 2. Comprehensive testing before commit
just test all all_mobile                     # 2-5 minutes

# 3. Device testing for critical paths
just mobile_ios                          # Manual testing
just mobile_android                      # Cross-platform validation

# 4. Build validation before release
just mobile_build_local                  # Build testing
```

#### Coverage Requirements
```bash
# Generate coverage reports
just test unit all_mobile
# Coverage report: .build/coverage/mobile/

# Coverage thresholds:
# - Statements: >80%
# - Branches: >75%
# - Functions: >80%
# - Lines: >80%
```

### Mock and Test Data

#### Mock Configuration
```bash
# Mock services for testing
# Located in: apps/mobile/__mocks__/

# File mocks: fileMock.js
# Component mocks: Various component mocks
# Service mocks: API and service mocks
```

#### Test Utilities
```bash
# Test utilities location: apps/mobile/src/utils/__tests__/
# Shared test utilities: apps/mobile/__tests__/utils/

# Common test patterns:
# - Render testing with React Native Testing Library
# - Mock API responses for integration tests
# - Snapshot testing for UI components
```

---

## 🔍 Debugging and Troubleshooting

### Common Development Issues

#### 1. Metro/Expo Server Issues
```bash
# Clear Expo cache
cd apps/mobile && npx expo start --clear

# Restart development server
just service clean mobile && just expo start --offline

# Check port conflicts
lsof -i :8081
# Kill process if needed: kill -9 <PID>
```

#### 2. Dependency Issues
```bash
# Clean and reinstall dependencies
just service clean mobile
just service install mobile

# Check for dependency conflicts
npm ls --depth=0

# Validate critical dependencies
just env_check
```

#### 3. Build Issues
```bash
# Local build debugging
just mobile_build_ios_local --clear-cache

# EAS build debugging
eas build:list --status=errored
eas logs --build-id <failed-build-id>

# Configuration validation
eas build:configure
```

#### 4. Device Connection Issues
```bash
# Update IP configuration
just expo ip auto

# Check QR code availability
just expo start --offline
# Ensure QR code is displayed in terminal

# Manual connection
# iOS: Open Camera app, scan QR code
# Android: Open Expo Go, scan QR code
```

### Performance Debugging

#### Metro Bundle Analysis
```bash
# Analyze bundle size
cd apps/mobile
npx react-native bundle --platform ios --dev false --entry-file index.js --bundle-output bundle.js --assets-dest ./

# Bundle analyzer (if configured)
npx @rnx-kit/bundle-diff --compare-bundle bundle.js
```

#### Memory and Performance
```bash
# Enable performance monitoring
# Add to App.tsx:
# import { enableScreens } from 'react-native-screens';
# enableScreens();

# Monitor performance in development
# Use React Native Debugger or Flipper
```

### Log Analysis

#### Development Logs
```bash
# Mobile service logs (Docker)
docker compose logs mobile -f

# Expo development logs
# Check terminal output when running `just expo start --offline`

# Device logs
# iOS: Xcode → Window → Devices and Simulators → View Device Logs
# Android: adb logcat | grep -i expo
```

#### Build Logs
```bash
# EAS build logs
eas logs --build-id <build-id>

# Local build logs
# Check terminal output during build process

# CI/CD logs
# GitHub Actions → Workflow runs → View logs
```

---

## 🚀 CI/CD Integration

### GitHub Actions Workflows

#### Mobile Build Workflow
The mobile app integrates with GitHub Actions for automated builds and deployments:

```yaml
# Triggered by:
# - Push to main branch with changes in apps/mobile/**
# - Manual workflow dispatch

# Build stages:
# 1. Setup environment (Node.js, Expo CLI)
# 2. Install dependencies
# 3. Run tests
# 4. Build with EAS
# 5. Submit to TestFlight (if production)
```

#### Workflow Commands
```bash
# For mobile builds, use EAS directly:
# cd apps/mobile && eas build --profile development
# Add --non-interactive --no-wait for CI environments

# Test mobile locally
just test unit mobile

# Monitor CI builds
just mobile_ci_status
```

### Automated Testing in CI

#### Test Execution
```bash
# Mobile test command
just test unit mobile
# Runs unit tests with coverage

# Coverage reporting
# Coverage reports are uploaded to CI artifacts

# Test result analysis
# Failed tests block deployment pipeline
```

#### Quality Gates
```bash
# Required for CI success:
# ✅ All tests pass (just test unit mobile)
# ✅ Linting passes (just lint check all)
# ✅ Build succeeds (eas build)
# ✅ No security vulnerabilities (npm audit)
```

### Deployment Automation

#### Automatic TestFlight Submission
```bash
# Triggered automatically on main branch:
# 1. Changes in apps/mobile/** detected
# 2. EAS build succeeds
# 3. Automatic submission to TestFlight
# 4. Notification to team

# Manual override if needed:
just mobile_submit_testflight
```

#### Release Notes Generation
```bash
# Automatic release notes from commits:
git log --oneline --since="last release" --grep="feat\|fix\|mobile"

# Enhanced with justfile command:
just mobile_generate_release_notes
# Extracts relevant commits and formats for TestFlight
```

---

## 📊 Performance Optimization

### Development Performance

#### Metro Configuration Optimization
```javascript
// metro.config.js optimizations:
module.exports = {
  transformer: {
    minifierConfig: {
      keep_fargs: true,
      mangle: false,
    },
  },
  resolver: {
    alias: {
      // Path aliases for faster imports
    },
  },
};
```

#### Development Server Optimization
```bash
# Use dedicated mobile development server
just service up mobile                    # Mobile only (faster startup)

# vs full development stack
just up                          # All services (more resources)
```

### Build Performance

#### EAS Build Optimization
```bash
# Use appropriate resource class
# In eas.json:
"ios": {
  "resourceClass": "default"      # For standard builds
  // "resourceClass": "large"     # For complex builds (premium)
}
```

#### Caching Strategy
```bash
# Clear build cache when needed
eas build --clear-cache

# Local cache management
just service clean mobile               # Clear local caches
npx expo start --clear         # Clear Expo cache
```

### Runtime Performance

#### Bundle Size Optimization
```bash
# Analyze bundle composition
npx expo export --dump-sourcemap
npx @expo/metro-config analyze <sourcemap-file>

# Optimize imports
# Use import { specific } from 'library'
# Avoid import * from 'large-library'
```

#### Memory Management
```bash
# Monitor memory usage
# Use React Native Performance Monitor
# Profile with Flipper or React Native Debugger

# Optimize images and assets
# Use appropriate image sizes
# Implement lazy loading for lists
```

---

## 📚 Best Practices Summary

### Development Practices

#### 1. Code Organization
```bash
# Follow project structure:
apps/mobile/src/
├── components/         # Reusable UI components
├── screens/           # Screen components
├── services/          # API and business logic
├── utils/             # Utility functions
├── config/            # Configuration modules
└── types/             # TypeScript definitions
```

#### 2. Testing Strategy
```bash
# Test pyramid approach:
# 🔺 Unit tests (majority) - just test unit all_mobile
# 🔸 Integration tests (some) - just test integration all_mobile
# 🔹 E2E tests (few) - manual device testing

# Focus areas:
# ✅ Business logic (services, utils)
# ✅ API integrations
# ✅ Critical user flows
# ⚠️ UI components (limited by React 19 compatibility)
```

#### 3. Quality Assurance
```bash
# Pre-commit checklist:
just test all all_mobile              # All tests pass
just lint check mobile                  # Code quality check
just lint format mobile                # Code formatting
just mobile_build_local           # Build validation

# Regular maintenance:
just env_check  # Weekly dependency check
npm audit                         # Security vulnerability scan
just service clean mobile                 # Periodic cache cleanup
```

### Deployment Practices

#### 1. Environment Management
```bash
# Clear environment separation:
# Development: localhost:8000, .dev bundle ID
# Preview: dev backend, .preview bundle ID
# Production: production backend, base bundle ID

# Configuration validation:
just mobile_env_validate          # Before each deployment
```

#### 2. Release Management
```bash
# Staged release approach:
# 1. Development → Internal testing
# 2. Preview → Stakeholder review
# 3. Production → Beta testing
# 4. App Store → Public release

# Version control:
# Semantic versioning (1.0.0 → 1.0.1 → 1.1.0 → 2.0.0)
# Git tags for releases
# Consistent version bumping
```

#### 3. Monitoring and Feedback
```bash
# Active monitoring:
# ✅ Build status (just mobile_build_status)
# ✅ TestFlight analytics
# ✅ User feedback collection
# ✅ Crash reporting (when configured)

# Continuous improvement:
# Weekly review of mobile metrics
# Monthly dependency updates
# Quarterly architecture review
```

---

## 📚 Related Documentation

- **[Mobile Architecture](../mobile/architecture.md)** - Dual-mode configuration system
- **[Environment Configuration](../mobile/environment-config.md)** - Environment setup guide
- **[TestFlight Guide](../mobile/testflight-guide.md)** - Distribution and beta testing
- **[Build Pipeline](../mobile/build-pipeline.md)** - Build troubleshooting
- **[Troubleshooting Guide](./troubleshooting-guide.md)** - General troubleshooting

### External Resources
- **[Expo Documentation](https://docs.expo.dev/)**
- **[React Native Documentation](https://reactnative.dev/docs/getting-started)**
- **[EAS Build Documentation](https://docs.expo.dev/build/introduction/)**
- **[TestFlight Documentation](https://developer.apple.com/testflight/)**

---

**Last Updated**: {{ current_date }}
**Workflow Version**: 2.0 (Justfile Integration)
**Mobile Development Status**: ✅ Fully Documented and Operational
