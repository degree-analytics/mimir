# PR Comment Automation Guide

## Purpose
Automate GitHub PR commenting without shell escaping issues, supporting full markdown formatting, code blocks, and special characters.

## When to Use This
- Posting review requests to PRs
- Adding complex comments with code examples
- Automating PR feedback workflows
- Claude Code integration for automated comments

**Keywords:** PR comments, GitHub automation, shell escaping, Claude Code, review requests

---

## Overview

The PR comment automation system provides a safe, reliable way to post comments to GitHub PRs without worrying about shell escaping issues. It handles all special characters, markdown formatting, and code blocks automatically.

### Key Benefits
- **No Shell Escaping**: Use quotes, backticks, parentheses freely
- **Full Markdown Support**: Code blocks, formatting, links all work
- **Claude Code Ready**: Can be permitted for automation
- **Error Handling**: Clear feedback when issues occur
- **Validation**: Checks PR exists before posting

---

## Installation & Setup

### 1. Verify Script Exists
```bash
ls -la scripts/helpers/pr_comment_manager.py
```

### 2. Make Executable (if needed)
```bash
chmod +x scripts/helpers/pr_comment_manager.py
```

### 3. Test Installation
```bash
python scripts/helpers/pr_comment_manager.py --help
```

---

## Usage Methods

### Method 1: Via Justfile (Recommended)
```bash
# Basic usage
just gh-pr_comment 123 /tmp/review.md

# With options
just gh-pr_comment 123 comment.md --quiet
just gh-pr_comment 123 review.md --validate-only
```

### Method 2: Direct Python Script
```bash
# Post comment
python scripts/helpers/pr_comment_manager.py \
  --pr-number 123 \
  --comment-file /path/to/comment.md

# Validate PR exists
python scripts/helpers/pr_comment_manager.py \
  --pr-number 123 \
  --validate-only

# Quiet mode
python scripts/helpers/pr_comment_manager.py \
  --pr-number 123 \
  --comment-file comment.md \
  --quiet
```

### Method 3: From Python Code
```python
from scripts.helpers.pr_comment_manager import PRCommentManager

manager = PRCommentManager()
success, message = manager.post_comment_from_text(
    pr_number=123,
    comment_text="@claude, please review\n\nThis fixes the `auth()` bug."
)
```

---

## Claude Code Integration

### Enable in Claude Code Settings

Add to `.claude/settings.json`:
```json
{
  "permittedCommands": [
    "python scripts/helpers/pr_comment_manager.py"
  ]
}
```

Or in VS Code settings:
```json
{
  "claude.permittedCommands": [
    "python scripts/helpers/pr_comment_manager.py"
  ]
}
```

### Using in Claude Commands

The `/project:request-review` command already uses this automatically:

```bash
# In command implementation
cat > /tmp/pr-review.md << 'EOF'
@claude, please review
bugbot run

## Summary
Fixed authentication bug in `UserManager.authenticate()`...
EOF

python scripts/helpers/pr_comment_manager.py \
  --pr-number ${PR_NUMBER} \
  --comment-file /tmp/pr-review.md
```

---

## Examples

### Simple Review Request
```bash
cat > /tmp/review.md << 'EOF'
@claude, please review
bugbot run

Fixed the critical bug where users without tenant associations
would not see proper UI feedback.
EOF

just gh-pr_comment 292 /tmp/review.md
```

### Complex Comment with Code
```bash
cat > /tmp/complex.md << 'EOF'
@claude, please review this implementation

## Rate Limiter Implementation

### Key Code:
```python
class RateLimiter:
    def __init__(self, redis_client: Redis):
        """Initialize with Redis backing"""
        self.redis = redis_client

    async def check_rate_limit(self, key: str) -> bool:
        """Check if request should be allowed"""
        current = await self.redis.incr(f"rl:{key}")
        return current <= self.limit
```

### Testing Approach:
1. Unit tests with mocked Redis
2. Integration tests with real container
3. Load tests to verify limits

Special chars work: ${VAR}, quotes "work", method_name() all fine!
EOF

just gh-pr_comment 123 /tmp/complex.md
```

### Validation Before Posting
```bash
# Check if PR exists first
just gh-pr_comment 999 dummy.md --validate-only

# If successful, then post
just gh-pr_comment 999 real-comment.md
```

---

## Common Issues & Solutions

### Issue: "PR not found"
- **Cause**: PR doesn't exist or wrong repository
- **Solution**: Verify PR number and that you're in correct repo
- **Check**: `gh pr view 123` to verify access

### Issue: "gh: command not found"
- **Cause**: GitHub CLI not installed
- **Solution**:
  ```bash
  # macOS
  brew install gh

  # Then authenticate
  gh auth login
  ```

### Issue: Permission Denied
- **Cause**: Script not executable or gh not authenticated
- **Solutions**:
  ```bash
  # Make executable
  chmod +x scripts/helpers/pr_comment_manager.py

  # Check gh auth
  gh auth status
  ```

---

## Integration with Other Workflows

### Review Request Workflow
```bash
# 1. Make changes and commit
just commit -m "fix: authentication bug"

# 2. Create PR
gt submit

# 3. Request review with context
/project:request-review 123
```

### CI Failure Response
```bash
# 1. Analyze CI failure
/project:analyze-ci-failure 123

# 2. Fix issues
# ... implement fixes ...

# 3. Post update comment
cat > /tmp/ci-fix.md << 'EOF'
Fixed CI failures:
- Resolved type errors in user.service.ts
- Fixed failing tests
- All checks now passing ✅
EOF

just gh-pr_comment 123 /tmp/ci-fix.md
```

---

## Best Practices

### 1. Use Heredocs for Complex Comments
```bash
cat > /tmp/comment.md << 'EOF'
Your complex markdown here...
EOF
```

### 2. Validate Before Posting
Always check PR exists if unsure:
```bash
just gh-pr_comment 123 dummy --validate-only
```

### 3. Keep Comments Focused
- Start with `@claude, please review` for review requests
- Include `bugbot run` on separate line if needed
- Summarize changes clearly
- Highlight areas needing attention

### 4. Use Templates
Create reusable templates:
```bash
# Save template
cat > ~/.pr-templates/review-request.md << 'EOF'
@claude, please review
bugbot run

## Summary
[CHANGE SUMMARY]

## Changes Made
- [CHANGE 1]
- [CHANGE 2]

## Review Focus
- [FOCUS AREA 1]
- [FOCUS AREA 2]
EOF

# Use template
cp ~/.pr-templates/review-request.md /tmp/review.md
# Edit /tmp/review.md
just gh-pr_comment 123 /tmp/review.md
```

---

## Security Considerations

- Never include secrets or credentials in comments
- The script uses subprocess safely (no shell injection)
- Comments are public on public repos
- All GitHub permissions apply (can only comment on accessible PRs)

---

## Related Documentation
- [Graphite Workflows](./graphite-workflows.md)
- [Testing Guide](./testing-guide.md)
- [Git Commit Standards](./git-commit-standards.md)
