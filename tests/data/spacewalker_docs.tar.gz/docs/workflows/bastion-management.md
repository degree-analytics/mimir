# Bastion Host Management Workflow

## Overview
This guide covers dynamic IP management for bastion host access in both dev and production environments. The bastion host provides secure SSH access to RDS databases and other private resources.

## Prerequisites
- AWS CLI configured with appropriate profiles
- SSH keys created for each environment:
  - Dev: `~/.ssh/dev-spacewalker-key.pem`
  - Prod: `~/.ssh/prod-spacewalker-key.pem`
- Production mode enabled (for prod commands): `(just prod enable --minutes=30)`

## Quick Start

### Grant Access to Your Current IP
```bash
# Add your current IP for 8 hours (default)
just bastion allow dev --hours=8
just bastion allow prod --hours=8  # Requires production mode

# Add for custom duration
just bastion allow prod --hours=24  # 24 hours
```

### Check Who Has Access
```bash
just bastion list dev
just bastion list prod
```

### Remove Access
```bash
# Remove your current IP
just bastion remove dev
just bastion remove prod

# Remove specific IP
just bastion remove prod --ip=70.123.52.100
```

### Clean Up Temporary IPs
```bash
# Remove all IPs with "Temp" in description
just bastion cleanup dev
just bastion cleanup prod
```

## IP Management Architecture

### Security Group Rules
- Each bastion has its own security group
- SSH access (port 22) is controlled via CIDR rules
- Each rule includes a description with metadata:
  - Timestamp when added (ISO 8601 format)
  - Expiration timestamp (ISO 8601 format for Lambda parsing)
  - Source IP address

### Temporary vs Permanent Access
- **Temporary Access**: Added via `bastion allow` with "Temp" in description
- **Permanent Access**: Added via CloudFormation or manually without "Temp"
- Cleanup commands only affect temporary entries

## Common Workflows

### Working from a New Location
1. Check your current IP: `curl -s ifconfig.me`
2. Add access: `just bastion allow prod --hours=8`
3. Test connection: `just bastion ssh prod`
4. When done: `just bastion remove prod`

### Team Member Access
```bash
# List current access
just bastion list prod

# Manually add team member IP (permanent)
AWS_PROFILE=production aws ec2 authorize-security-group-ingress \
  --group-id $(just bastion list prod | grep "Security Group:" | awk '{print $3}') \
  --ip-permissions "IpProtocol=tcp,FromPort=22,ToPort=22,IpRanges=[{CidrIp=THEIR_IP/32,Description='Team Member Name'}]"
```

### Debugging Access Issues
1. Verify your IP is allowed: `just bastion list prod`
2. Check your current IP matches: `curl -s ifconfig.me`
3. Test SSH directly: `ssh -i ~/.ssh/prod-spacewalker-key.pem ec2-user@BASTION_IP`
4. Check security group in AWS Console

## Environment Differences

| Aspect | Development | Production |
|--------|-------------|------------|
| AWS Profile | default | production |
| Region | us-east-2 | us-east-1 |
| SSH Key | ~/.ssh/dev-spacewalker-key.pem | ~/.ssh/prod-spacewalker-key.pem |
| Protection | None | Requires `prod_enable` |
| Typical Duration | 2-8 hours | 8-24 hours |

## Security Best Practices

### IP Whitelisting
- Only add IPs you control
- Use minimum duration needed
- Remove access when work is complete
- Regularly run cleanup commands

### Access Patterns
- Prefer temporary access over permanent
- Use descriptive entries for team members
- Audit access regularly with `bastion list`
- Consider VPN for frequent access needs

### Key Management
- Keep SSH keys secure (chmod 400)
- Never commit keys to git
- Rotate keys periodically
- Use different keys per environment

## Automated Cleanup

SpaceWalker includes an automated Lambda function to clean up expired temporary IPs:

### Deployment
```bash
# Deploy the cleanup Lambda
just aws_deploy_bastion_cleanup prod

# The Lambda runs hourly to remove expired entries
```

### Manual Trigger
```bash
# Invoke the Lambda manually (if you need immediate cleanup)
AWS_PROFILE=production aws lambda invoke \
  --function-name prod-spacewalker-bastion-cleanup \
  --region us-east-1 \
  /tmp/cleanup-output.json

# Check the results
cat /tmp/cleanup-output.json
```

## Troubleshooting

### "Connection refused" or "Operation timed out"
- Your IP might not be whitelisted
- Check with: `just bastion list prod`
- Add access: `just bastion allow prod --hours=8`

### "Permission denied (publickey)"
- Wrong SSH key or key permissions
- Fix: `chmod 400 ~/.ssh/prod-spacewalker-key.pem`
- Verify key exists: `ls -la ~/.ssh/*-spacewalker-key.pem`

### IP Already Exists
- The command will show "IP might already be allowed"
- This is normal - your IP is already whitelisted
- Check current rules: `just bastion list prod`

### Can't Find Security Group
- Bastion might not be deployed
- Check: `just stack_status prod`
- Deploy if needed: `just aws_deploy_foundation prod`

## Advanced Usage

### Bastion SSH Access
```bash
# Direct SSH access
just bastion ssh prod
```

### Bastion Networking Tools
The bastion host includes essential networking diagnostic tools:
- `nc` (netcat) - Port connectivity testing
- `telnet` - Protocol testing
- `nslookup`/`dig` - DNS resolution testing
- `curl`/`wget` - HTTP/HTTPS testing
- `traceroute` - Network path analysis

**Examples:**
```bash
# Test RDS connectivity
nc -z -v prod-spacewalker-db.cuot6uwyhikz.us-east-1.rds.amazonaws.com 5432

# Test HTTP endpoint
curl -I https://example.com

# DNS resolution
nslookup prod-spacewalker-db.cuot6uwyhikz.us-east-1.rds.amazonaws.com
```

### Database Access via Bastion
```bash
# Create SSH tunnel for database
just db_tunnel prod 5433

# Quick database connection
just db_quick_connect prod

# Check database status
just aws_db_status prod
```

### Automation Scripts
When automating, you can use the underlying AWS CLI commands:
```bash
# Get security group ID
SG_ID=$(AWS_PROFILE=production aws cloudformation describe-stacks \
  --stack-name prod-spacewalker-foundation \
  --region us-east-1 \
  --query "Stacks[0].Outputs[?OutputKey=='BastionSecurityGroupId'].OutputValue" \
  --output text)

# Add IP programmatically
AWS_PROFILE=production aws ec2 authorize-security-group-ingress \
  --group-id $SG_ID \
  --region us-east-1 \
  --ip-permissions "IpProtocol=tcp,FromPort=22,ToPort=22,IpRanges=[{CidrIp=YOUR_IP/32,Description='Automation'}]"
```

## Related Documentation
- [Database Access Patterns](./database-access.md)
- [Production Infrastructure](../setup/production-infrastructure.md)
- [AWS Environment Configuration](../setup/environment-configuration.md)
