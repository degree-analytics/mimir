# Spacewalker Enhanced Workflows

## Purpose
Professional-grade intelligent workflow automation that provides sophisticated development experiences with error handling, progress tracking, and smart recovery. Essential reference for understanding Spacewalker's workflow orchestration system across all platforms.

## When to Use This
- Setting up development environments with automated validation
- Understanding intelligent CI/CD workflows and automation capabilities
- Implementing robust development processes with timeout protection
- Managing cross-platform workflows and integrated automation
- Troubleshooting workflow issues and understanding recovery procedures
- Keywords: workflow automation, intelligent development, CI/CD orchestration, smart recovery, cross-platform workflows

**Version:** 2.0 (Reorganized from workflow-specific documentation)
**Date:** 2025-06-29
**Status:** Current - Production Workflow Orchestration

---

## =� Workflow Automation Overview

### The Cross-Platform Challenge
Traditional development workflows often break down when:
- Services fail to start properly across different platforms
- Tests hang indefinitely without timeout protection
- Dependencies get out of sync between backend, admin, and mobile
- Environment configuration drifts between team members

### Professional-Grade Solutions
**Spacewalker's enhanced workflows solve these problems** with:
- ⏱️ **Timeout Protection** - No more hanging builds or infinite waits
- 📊 **Progress Tracking** - Real-time status with timestamps and step-by-step feedback
- 🔄 **Smart Recovery** - Graceful handling of transient failures with retry logic
- 🏗️ **Infrastructure Management** - Automatic start/stop of dependent services across platforms

This transforms development from a collection of fragile scripts into a robust, professional development platform with **orchestrated intelligent automation**.

---

## =� Core Workflow Architecture

### WorkflowStep Framework
All enhanced workflows use a sophisticated step-based architecture that provides enterprise-grade automation capabilities:

```python
@dataclass
class WorkflowStep:
    name: str          # Unique identifier for tracking and logging
    command: str       # Command to execute with full argument specification
    description: str   # Human-readable description for progress reporting
    timeout: int       # Maximum execution time in seconds
    required: bool     # Whether failure should stop entire workflow
    retry_count: int   # Number of automatic retries on failure
```

### Universal Workflow Features
Every enhanced workflow provides professional development capabilities:
- **Visual Progress Tracking** - Real-time step execution with timestamps and completion status
- **Intelligent Timeout Protection** - Context-aware timeouts that prevent hanging on broken commands
- **Rich Error Context** - Detailed failure information with diagnostic suggestions
- **Graceful Degradation** - Optional steps can fail without breaking entire workflow
- **Safety Validation** - Pre-execution checks and validation before destructive operations
- **Cross-Platform Coordination** - Unified orchestration across backend, admin, and mobile platforms

---

## =� Available Enhanced Workflows

### 1. Intelligent Development Setup (`workflow_setup`)

**Purpose**: Complete environment setup from scratch with comprehensive validation at every step.

```bash
just workflow_setup                # Complete automated setup
just workflow_setup --verbose      # Detailed progress and diagnostic information
```

#### Workflow Steps & Automation
**1. Environment Prerequisites Check** (60s timeout)
- Validates Python 3.12+, Node.js 18+, Docker, uv availability across platforms
- Checks version compatibility and reports specific upgrade requirements
- Reports missing dependencies with platform-specific installation instructions
- Validates cross-platform development tool consistency

**2. Dependency Installation** (300s timeout)
- Installs Python dependencies via uv with integrity verification
- Installs Node.js packages for admin dashboard and mobile app
- Handles version conflicts automatically with dependency resolution
- Validates package integrity and reports installation status

**3. Cross-Platform Mobile IP Configuration** (30s timeout)
- Intelligent IP detection across macOS, Linux, Windows platforms
- Updates mobile environment files for backend connectivity
- Validates network connectivity and reachability testing
- Handles complex network configurations (VPN, multi-interface)

**4. Docker Environment Preparation** (120s timeout, optional)
- Cleans any stale Docker resources and dangling containers
- Prepares fresh development environment with health validation
- Continues gracefully even if cleanup fails (non-blocking)
- Validates Docker daemon availability and configuration

**5. Service Startup & Orchestration** (180s timeout)
- Starts all required services: database, backend API, admin dashboard
- Waits for comprehensive health checks to pass with retry logic
- Validates inter-service connectivity and API availability
- Ensures complete service mesh is operational

**6. Health Verification & Validation** (60s timeout)
- Comprehensive system-wide health checks across all platforms
- Database connectivity validation with schema verification
- API endpoint availability checks with response validation
- Cross-platform integration testing and service coordination

**7. Unit Test Validation** (300s timeout)
- Runs complete unit test suite to verify setup integrity
- Ensures all platforms (backend, admin, mobile) are working correctly
- Provides confidence in environment state and development readiness
- Reports any platform-specific issues requiring attention

#### Usage Scenarios
- **New developer onboarding** - Complete automated environment setup
- **After major system changes** - Validate environment integrity
- **Environment recovery** - Restore broken development setup
- **Team consistency** - Ensure uniform development environments

#### Example Execution Output
```
[14:32:15] 🔵 Starting intelligent workflow with 7 steps
[14:32:15] 🔵 Step 1/7: Environment prerequisite validation across platforms
[14:32:17] ✅ env_check completed successfully (2.1s)
[14:32:17] 🔵 Step 2/7: Installing dependencies with integrity verification
[14:32:45] ✅ install completed successfully (28.3s)
[14:32:45] 🔵 Step 3/7: Cross-platform mobile IP configuration
[14:32:48] ✅ expo ip auto completed successfully (3.2s)
[14:35:22] ✅ 🎉 Complete workflow automation successful!
```

### 2. Fast Development Cycle (`dev_cycle`)

**Purpose**: Rapid feedback loop optimization for active development with unit tests and quality validation.

```bash
just dev_cycle              # Fast development feedback (30-60 sec)
just dev_cycle_full         # Full validation with integration tests
```

#### Optimized Workflow Steps
**1. Dependency Installation** (300s timeout)
- Fast dependency resolution with caching optimization
- Parallel installation across backend, admin, mobile platforms
- Incremental updates for changed dependencies only

**2. Code Quality Validation** (180s timeout)
- Linting checks across all platforms with consistent standards
- Code formatting validation and style guide enforcement
- Type checking and static analysis for quality assurance

**3. Cross-Platform Unit Tests** (300s timeout)
- Parallel unit test execution across backend, admin, mobile
- Fast feedback with isolated testing (no infrastructure dependencies)
- Comprehensive coverage reporting and test result analysis

#### Performance Optimizations
- **Infrastructure Skipping** - Bypasses service startup for maximum speed
- **Dependency Caching** - Reuses installed packages when possible for faster iterations
- **Parallel Execution** - Runs independent validations simultaneously where safe
- **Typical Runtime** - 2-4 minutes for complete quality validation

#### Development Integration
- **Active Development** - Perfect for continuous feedback during coding
- **Pre-Commit Validation** - Quick quality checks before committing changes
- **Fast Iteration Cycles** - Enables rapid development with immediate feedback

### 3. Complete CI Pipeline (`workflow_ci`)

**Purpose**: Comprehensive CI validation including integration tests with full infrastructure orchestration.

```bash
just workflow_ci                   # Complete CI validation
just workflow_ci --verbose         # Detailed integration testing logs
```

#### Comprehensive Workflow Steps
**1. Dependency Installation** (300s timeout)
- Complete dependency resolution with integrity verification
- Cross-platform consistency validation and version alignment

**2. Code Quality Validation** (180s timeout)
- Strict linting with zero tolerance for warnings
- Comprehensive code formatting and style validation

**3. Unit Test Execution** (300s timeout)
- Complete unit test suite across all platforms
- Coverage analysis and quality gate enforcement

**4. Infrastructure Startup & Orchestration** (120s timeout)
- Automated database and backend service startup
- Health check validation with comprehensive readiness testing
- Service mesh coordination and dependency validation

**5. Integration Test Execution** (600s timeout)
- Complete API testing across all platform integrations
- Database integration validation with transaction testing
- Cross-platform workflow testing and data consistency validation

**6. Infrastructure Cleanup & Resource Management** (60s timeout)
- Graceful service shutdown and resource cleanup
- Container and volume cleanup with verification
- Environment reset for next execution cycle

#### Quality Assurance Features
- **Production-Grade Validation** - Tests mirror production environment behavior
- **Complete Integration Coverage** - Validates all platform interactions
- **Resource Management** - Ensures clean environment state for reliable testing

### 4. Production Readiness Validation (`workflow_prod_check`)

**Purpose**: Comprehensive validation that code meets production deployment standards and compliance requirements.

```bash
just workflow_prod_check           # Production deployment readiness
just workflow_prod_check --strict  # Enhanced compliance validation
```

#### Production-Grade Validation Steps
**1. Strict Code Quality Validation** (180s timeout)
- Zero-warning linting with production quality standards
- Code formatting validation with style guide compliance
- Security linting and vulnerability scanning

**2. Complete Test Suite Execution** (900s timeout)
- Unit tests with comprehensive coverage requirements (>80%)
- Integration tests with production data patterns
- End-to-end workflow validation with realistic scenarios

**3. Production Build Verification** (600s timeout)
- Production build process validation with optimization
- Asset optimization and compression validation
- Bundle size analysis and performance optimization validation

**4. Environment & Security Validation** (60s timeout)
- Configuration validation for production deployment
- Security compliance checking and vulnerability assessment
- Dependency audit for known security vulnerabilities

#### Compliance & Quality Standards
- **Production Readiness** - Ensures code meets deployment standards
- **Security Compliance** - Validates security requirements and best practices
- **Performance Standards** - Ensures production performance requirements are met

---

## 🔧 Environment Setup & Dependency Management

### Bootstrap for Fresh Machines (`bootstrap`)

**Purpose**: Initialize a fresh development machine with all prerequisites needed for Spacewalker development.

```bash
# Run bootstrap script directly
./scripts/bootstrap.sh

# Or use the just command (once just is installed)
just bootstrap
```

#### Bootstrap Process
**1. Tool Verification**
- Checks for Python 3.11+ installation
- Verifies Node.js 18+ availability
- Confirms Docker and Docker Compose installation
- Validates just command runner

**2. Python Prerequisites Installation**
- Installs uv (fast Python package manager)
- Installs PyYAML (required by helper scripts)
- Installs python-dotenv (environment management)

**3. Guidance for Missing Tools**
- Provides platform-specific installation instructions
- Suggests package managers (brew, apt, etc.)
- Links to official installation guides

#### When to Use Bootstrap
- **New Developer Machines** - First-time Spacewalker setup
- **CI/CD Environments** - Ensure prerequisites are installed
- **After System Updates** - Verify tools are still available
- **Team Onboarding** - Standardize development environments

### Dependency Installation (`install`)

**Purpose**: Install all project dependencies across backend, admin, and mobile platforms.

```bash
just install                   # Full local environment (base + dev + tooling + services)
just install target=dev        # CI/dev-only dependencies
just install target=runtime    # Minimal runtime dependencies
just install target=tooling    # Doc search tooling (Mímir CLI)
```

#### Installation Details
- **Backend**: Creates virtual environment, installs requirements.txt
- **Admin**: Installs npm packages for Next.js dashboard
- **Mobile**: Installs React Native and Expo dependencies
- **Root**: Workspace-level dependencies

### Comprehensive Cleanup (`clean`)

**Purpose**: Clean build artifacts, dependencies, and Docker resources with multiple cleanup levels.

```bash
just clean                    # Basic cleanup (containers, images, volumes)
just clean --deep            # Remove dependencies and build artifacts
just clean --cache           # Clear all caches
just clean --nuclear         # Complete fresh start
just clean --force           # Skip confirmation prompts
```

#### Cleanup Levels Explained

**Basic Clean** (`just clean`)
- Stops and removes Docker containers
- Removes Docker images for services
- Cleans Docker volumes
- Service-specific artifact cleanup

**Deep Clean** (`just clean --deep`)
- Everything from basic clean, plus:
- Removes all node_modules directories
- Removes Python virtual environment
- Clears build directories (.next, .expo)
- Removes Docker volumes

**Cache Clean** (`just clean --cache`)
- Clears npm cache
- Removes Python __pycache__ directories
- Removes .pyc files
- Clears Docker build cache
- Removes .DS_Store and .log files

**Nuclear Clean** (`just clean --nuclear`)
- Everything from deep + cache clean, plus:
- Docker system prune (ALL unused Docker data)
- Complete Docker metadata cleanup
- Total environment reset

#### Common Cleanup Scenarios

```bash
# Before major updates
just clean --cache

# Dependency conflicts
just clean --deep && just install

# Docker space issues
just clean docker --force

# Complete reset
just clean --nuclear && just bootstrap && just install
```

---

## =� Database Management Workflows

### Smart Database Operations
Enhanced database management with enterprise-grade automation, safety checks, and backup management:

```bash
just db_safe_reset              # Reset with automatic backup creation
just db_backup                  # Intelligent backup with timestamp naming
just db_backup_named "release"  # Custom named backup for specific purposes
just db_restore <backup_name>   # Restore from specific backup with validation
just db verify                # Migration and schema consistency validation

# Direct database access with safety features
just db shell                 # Interactive PostgreSQL shell
just sql "SELECT * FROM users"  # Execute SQL queries (read-only by default)
just sql "UPDATE..." --write  # Write operations require explicit flag
```

### Database Workflow Features
- **Automatic Backup Creation** - Generated before any destructive operation with metadata
- **Intelligent Timestamp Naming** - `backup_20241221_143022.sql` format for chronological organization
- **Health Validation** - Waits for database readiness with connection testing
- **Migration Consistency Checks** - Validates schema state and migration integrity
- **Cleanup Management** - Automatic old backup cleanup with configurable retention

### Database Safety & Recovery
**Pre-Operation Safety Checks:**
- Database connectivity verification with timeout handling
- Available disk space checking (minimum 2GB required for operations)
- Backup directory permissions and write access validation
- User confirmation for destructive operations with impact summary

**Example Safe Reset Workflow:**
```
[14:30:15] 🔵 Performing pre-reset safety validation...
[14:30:15] ✅ Database connectivity verified
[14:30:15] ✅ Sufficient disk space available (15.2 GB)
[14:30:15] 🔵 Creating backup before reset...
[14:30:16] ✅ Backup created: backup_20241221_143015.sql (45.2 MB)
[14:30:16] 🔵 Performing safe database reset with validation...
[14:30:25] ✅ Database reset completed successfully
[14:30:25] 📋 Backup available for rollback if needed
```

---

## =� Docker Workflow Enhancements

### Intelligent Docker Operations
Sophisticated Docker management with health monitoring, progressive restart capabilities, and resource optimization:

```bash
just docker_rebuild             # Complete rebuild with health validation
just docker_clean               # Intelligent cleanup (containers, images, volumes)
just docker_restart <service>   # Service restart with readiness waiting
just docker_logs <service>      # Enhanced logging with service coordination
```

### Docker Workflow Features
- **Health Check Integration** - Waits for services to be truly ready, not just started
- **Intelligent Resource Cleanup** - Only removes safe-to-remove resources with verification
- **Progressive Service Restart** - Graceful restart with dependency handling and coordination
- **Real-Time Status Monitoring** - Container status tracking with service health reporting

### Docker Safety & Coordination
**Service Dependency Management:**
- Understands service dependencies (database → backend → admin)
- Coordinated startup and shutdown sequences for reliability
- Health validation at each step before proceeding to dependent services

**Resource Management:**
- Intelligent volume and network cleanup with safety checks
- Preservation of important data volumes and configurations
- Comprehensive cleanup verification and status reporting

---

## =� Error Handling & Recovery

### Automatic Error Recovery Systems
- **Transient Failure Recovery** - Automatic retry logic for network-related issues with exponential backoff
- **Resource Cleanup** - Automatic cleanup of partial state on workflow failure
- **Partial Success Handling** - Continue with optional steps even if some non-critical steps fail
- **Rich Error Context** - Detailed logging with diagnostic information and recovery suggestions

### Manual Recovery Procedures
```bash
# Complete environment reset (nuclear option)
just clean && just workflow_setup

# Targeted recovery for specific issues
just docker_clean && just up              # Docker environment issues
just db clean && just db init && just db seed && alembic upgrade head     # Database state problems
just install && just dev_cycle            # Dependency and build issues
```

### Recovery Decision Matrix
- **Service Startup Failures** → `just docker_clean && just up`
- **Database Issues** → `just db clean && just db init && just db seed && just health`
- **Dependency Problems** → `just install && just test unit all`
- **Complete Environment Corruption** → `just clean && just workflow_setup`

---

## =� Workflow Selection Guide

| Development Scenario | Recommended Workflow | Typical Runtime | Coverage Scope |
|----------------------|---------------------|----------------|----------------|
| New developer onboarding | `workflow_setup` | 5-8 minutes | Complete environment setup |
| Active feature development | `dev_cycle` | 30-60 seconds | Unit tests + lint validation |
| Pre-commit validation | `dev_cycle_full` | 2-4 minutes | Full test suite + quality assurance |
| Pre-merge validation | `workflow_ci` | 8-12 minutes | Full integration testing |
| Release preparation | `workflow_prod_check` | 15-20 minutes | Production-grade validation |
| Environment recovery | `clean && workflow_setup` | 6-10 minutes | Fresh environment restoration |

### Decision Criteria
- **Speed Priority** → `dev_cycle` for rapid feedback
- **Comprehensive Validation** → `workflow_ci` for thorough testing
- **Production Readiness** → `workflow_prod_check` for deployment preparation
- **Environment Issues** → `workflow_setup` for complete restoration

---

## =� Advanced Workflow Features

### Parallel Execution Optimization
Sophisticated parallelization where safe and beneficial:
- **Multi-Platform Dependency Installation** - Simultaneous backend, admin, mobile setup
- **Independent Validation Checks** - Parallel linting, type checking, formatting validation
- **Non-Conflicting Cleanup Operations** - Concurrent resource cleanup with safety verification

### Intelligent Caching Systems
- **Dependency Cache** - Reuses installed packages when versions and checksums match
- **Docker Layer Cache** - Leverages Docker build cache for faster image building
- **Test Result Cache** - Skips unchanged test suites where safely possible (with hash verification)

### Real-Time Progress Visualization
```
[14:32:15] 🔵 Starting intelligent workflow with 7 steps
[14:32:15] 🔵 Step 1/7: Environment prerequisite validation
[14:32:17] ✅ env_check completed successfully (2.1s)
[14:32:17] 🔵 Step 2/7: Installing dependencies with verification
[14:32:45] ✅ install completed successfully (28.3s)
[14:32:45] 🔵 Step 3/7: Cross-platform mobile IP configuration
[14:32:48] ✅ expo ip auto completed successfully (3.2s)
```

### Context-Aware Timeout Protection
Intelligent timeout configuration based on operation characteristics:
- **Quick Operations** - 30-60 seconds (health checks, validation, IP configuration)
- **Medium Operations** - 120-300 seconds (installation, unit tests, service startup)
- **Long Operations** - 600-900 seconds (integration tests, production builds, comprehensive validation)

---

## =� Benefits & Value Proposition

### For Developers
- **Predictable, Reliable Workflows** - Consistent behavior across different environments and platforms
- **Fast Feedback Loops** - Rapid development cycles with immediate quality validation
- **Automatic Error Recovery** - Reduced manual intervention and troubleshooting time
- **Rich Progress Information** - Clear visibility into workflow execution and completion status

### For Development Teams
- **Consistent Development Environment** - Uniform setup and validation across all team members
- **Reduced Support Overhead** - Self-healing workflows reduce infrastructure support requests
- **Standardized CI/CD Processes** - Unified approach to quality validation and integration testing
- **Enhanced Debugging Information** - Detailed logging and error context for faster issue resolution

### For Operations & DevOps
- **Production-Ready Validation** - Comprehensive checks ensure deployment readiness
- **Automated Safety Procedures** - Built-in backup and recovery mechanisms
- **Comprehensive Audit Logging** - Complete workflow execution history and audit trails
- **Graceful Failure Handling** - Predictable behavior and recovery procedures for operational stability

---

## =� Related Workflow Documentation

### Platform-Specific Development Workflows
> =� **Backend Teams**: See [Backend Development](../backend/development/) for backend-specific workflow integration
> =� **Admin Teams**: See [Admin Development](../admin/development/) for dashboard development workflows
> =� **Mobile Teams**: See [Mobile Development](../mobile/development/) for React Native workflow automation

### Supporting Documentation
- **[Development Setup](../setup/development-setup.md)** - Complete development environment configuration supporting these workflows
- **[Testing Strategy](../workflows/testing-strategy.md)** - Testing automation and quality assurance integration
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Production deployment automation and workflow orchestration

### Architecture & Implementation
- **[Development Tools](../development/development-tools.md)** - Professional-grade scripts and automation tools underlying these workflows
- **[Product Overview](../product/product-overview.md)** - System overview and workflow integration context

---

**Status**: ✅ **PRODUCTION-READY INTELLIGENT AUTOMATION**
**Last Updated**: 2025-06-29
**Workflow Categories**: Development Setup, CI/CD Orchestration, Database Management, Docker Operations
**Platform Coverage**: Cross-Platform (Backend, Admin Dashboard, Mobile Application)

---

*These enhanced workflows transform Spacewalker from a collection of fragile development scripts into a robust, professional development platform with intelligent automation, sophisticated error handling, and exceptional developer experience across all platforms.*
