# 🚀 CI/CD Build Pipeline & Mobile Distribution Guide

## Overview

This guide explains the complete CI/CD build pipeline, including when builds are triggered, what environments they target, and how mobile apps are distributed through EAS, TestFlight, and Google Play Internal Testing. Web/backend jobs remain in `.github/workflows/ci-cd.yml`, while mobile builds now execute via the dedicated `.github/workflows/mobile-smart-build.yml` workflow.

## 📋 Table of Contents

1. [Pipeline Architecture](#pipeline-architecture)
2. [Backend Test Matrix Strategy](#-backend-test-matrix-strategy)
3. [Build Triggers](#build-triggers)
4. [Environment Mapping](#environment-mapping)
5. [Mobile Distribution Strategy](#mobile-distribution-strategy)
6. [Branch-to-Environment Flow](#branch-to-environment-flow)
7. [Production Notes](#production-notes)
8. [Troubleshooting](#troubleshooting)

---

## 🏗️ Pipeline Architecture

```mermaid
graph TB
    subgraph "CI/CD Pipeline (Cache-Optimized Architecture)"
        A[Code Push] --> B[Setup Job<br/>⚡ 30s with cache]
        B --> C[Parallel Phase<br/>🚀 Jobs start immediately]

        subgraph "Parallel Phase"
            C --> D[Lint Tests<br/>📦 Direct cache usage]
            C --> E[Backend Tests<br/>📦 Direct cache usage]
            C --> F[Admin Tests<br/>📦 Direct cache usage]
            C --> G[Mobile Tests<br/>📦 Direct cache usage]
            C --> H[EAS Build<br/>📦 Direct cache usage]
        end

        subgraph "Cache Architecture"
            I[GitHub Actions Cache<br/>🔑 Smart cache keys<br/>📊 82% faster setup]
            I -.-> D
            I -.-> E
            I -.-> F
            I -.-> G
            I -.-> H
        end

        subgraph "Sequential Phase"
            D --> J{All Tests Pass?}
            E --> J
            F --> J
            G --> J
            J -->|Yes| K[Docker Build & Push]
            J -->|No| L[❌ Pipeline Fails]
            K --> M[ECS Deployment]
            M --> N[GitHub Release]
        end

        subgraph "Mobile Distribution"
            H --> O{Build Profile?}
            O -->|production-testing| P[App Store Submission]
            O -->|preview/development| Q[EAS URLs Only]
            P --> R[TestFlight]
            P --> S[Google Play Internal]
        end
    end
```

### 🚀 Backend Test Matrix Strategy

The backend tests utilize GitHub Actions matrix strategy to run unit, integration, and system tests in parallel:

```yaml
strategy:
  matrix:
    test-type: [unit, integration, system]
  fail-fast: false  # Continue running other test types even if one fails
```

**Benefits:**
- **3x Faster Feedback**: Tests that previously ran sequentially now execute in parallel
- **Independent Status**: Each test type reports pass/fail independently
- **Granular Coverage**: Coverage is tracked per test type and aggregated in PR comments
- **Selective Reruns**: Failed test types can be rerun without affecting others

**Coverage Aggregation:**
- Each test type generates its own coverage report
- PR comments show breakdown: `unit: 79%, integration: 65%, system: 82%`
- Coverage artifacts are stored separately: `backend-coverage-{test-type}/`

---

## 🔄 Build Triggers

### Automatic Triggers

| Event | Branches | Jobs Triggered |
|-------|----------|---------------|
| **Push** | `main`, `dev` | Full pipeline + EAS builds |
| **Pull Request** | `main`, `dev` | Tests + Lint only (no builds/deploys) |
| **Manual Dispatch** | Any branch | Full pipeline + EAS builds |

### Manual Triggers

```bash
# Trigger workflow manually
gh workflow run ci-cd.yml --ref your-branch
```

---

## 🌍 Environment Mapping

```mermaid
graph LR
    subgraph "Git Branches"
        A[dev branch]
        B[main branch]
        C[feature branches]
    end

    subgraph "Backend Environments"
        D[Dev Environment<br/>backend.spacewalker.littleponies.com]
        E[Prod Environment<br/>api.spacewalker.com]
    end

    subgraph "Mobile Build Profiles"
        F[preview<br/>EAS URLs + Dev Backend]
        G[production-testing<br/>TestFlight + Prod Backend]
        H[development<br/>Local/EAS URLs]
    end

    A --> D
    A --> F
    B --> E
    B --> G
    C --> H
```

### Environment Details

| Branch | Backend URL | Mobile Profile | Docker Environment | EAS Distribution |
|--------|-------------|----------------|-------------------|------------------|
| `dev` | `backend.spacewalker.littleponies.com` | `preview` | `dev` | EAS URLs only |
| `main` | `api.spacewalker.com` | `production-testing` | `prod` | TestFlight + Google Play |
| `feature-*` | `localhost:8000` | `development` | None | EAS URLs only |

---

## 📱 Mobile Distribution Strategy

### Current Implementation (Phase 1)

```mermaid
graph TD
    subgraph "Branch-Based Distribution"
        A[Code Push] --> B{Which Branch?}

        B -->|dev| C[EAS Build: preview]
        B -->|main| D[EAS Build: production-testing]
        B -->|feature| E[EAS Build: development]

        C --> F[✅ EAS URLs for Dev Testing<br/>📱 Expo Go compatible<br/>🔗 Share links with team]

        D --> G[✅ EAS URLs for Prod Testing<br/>📱 Expo Go compatible]
        D --> H{After Deployment Success}

        H --> I[🍎 TestFlight Submission<br/>📨 Internal testers notified]
        H --> J[🤖 Google Play Internal Testing<br/>📨 Internal testers notified]

        E --> K[✅ EAS URLs for Feature Testing<br/>📱 Local development]
    end

    subgraph "Distribution Channels"
        L[EAS URLs<br/>📱 Scan QR code<br/>🔗 Direct download]
        M[TestFlight<br/>🍎 iOS App Store Connect<br/>👥 Internal testers]
        N[Google Play Internal<br/>🤖 Play Console<br/>👥 Internal testers]
    end

    F --> L
    G --> L
    K --> L
    I --> M
    J --> N
```

### Distribution Matrix

| Branch | EAS Build | EAS URLs | TestFlight | Google Play Internal | Production Store |
|--------|-----------|----------|------------|---------------------|------------------|
| `dev` | ✅ preview | ✅ Yes | ❌ No | ❌ No | ❌ No |
| `main` | ✅ production-testing | ✅ Yes | ✅ **Auto** | ✅ **Auto** | ❌ Not Yet |
| `feature-*` | ✅ development | ✅ Yes | ❌ No | ❌ No | ❌ No |

---

## 🔀 Branch-to-Environment Flow

### Development Branch (`dev`)

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant GH as GitHub
    participant CI as CI/CD Pipeline
    participant EAS as EAS Build
    participant BE as Backend (Dev)
    participant ECS as ECS (Dev)

    Dev->>GH: Push to dev branch
    GH->>CI: Trigger workflow
    CI->>CI: Run tests (parallel)
    CI->>EAS: Build preview profile
    EAS->>EAS: Build mobile app
    EAS->>Dev: 📱 EAS URLs available
    CI->>CI: Build Docker images
    CI->>ECS: Deploy to dev environment
    ECS->>BE: Update dev backend

    Note over Dev,BE: Mobile app (EAS URLs) → Dev Backend
    Note over Dev: Ready for development testing
```

### Main Branch (`main`)

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant GH as GitHub
    participant CI as CI/CD Pipeline
    participant EAS as EAS Build
    participant TF as TestFlight
    participant GP as Google Play
    participant BE as Backend (Prod)
    participant ECS as ECS (Prod)

    Dev->>GH: Push to main branch
    GH->>CI: Trigger workflow
    CI->>CI: Run tests (parallel)
    CI->>EAS: Build production-testing profile
    EAS->>EAS: Build mobile app
    EAS->>Dev: 📱 EAS URLs available
    CI->>CI: Build Docker images
    CI->>ECS: Deploy to production environment
    ECS->>BE: Update production backend

    par App Store Submissions
        CI->>TF: Submit to TestFlight
        TF->>Dev: 🍎 iOS build available
    and
        CI->>GP: Submit to Google Play Internal
        GP->>Dev: 🤖 Android build available
    end

    Note over Dev,BE: Mobile app (stores) → Production Backend
    Note over Dev: Ready for production testing
```

---

## 🏭 Production Notes

### ⚠️ Current Status: **Pre-Production**

The current pipeline automatically pushes to **internal testing channels only**:

- ✅ **TestFlight**: Internal testers (up to 100 users)
- ✅ **Google Play Internal Testing**: Internal testers (up to 100 users)
- ❌ **App Store**: **NOT YET CONFIGURED** - requires manual approval process
- ❌ **Google Play Store**: **NOT YET CONFIGURED** - requires manual approval process

### 🎯 Next Steps for Full Production

1. **Manual App Store Release Process**
   ```bash
   # After testing is complete, manually promote:
   # 1. TestFlight → App Store Connect → App Store Review
   # 2. Google Play Internal → Alpha/Beta → Production
   ```

2. **Production Release Workflow** (Future)
   - Manual approval gates for store releases
   - Phased rollout capabilities
   - Release notes automation
   - Version promotion workflows

### 🔧 Configuration Status

| Service | Status | Configuration |
|---------|---------|---------------|
| **EAS Builds** | ✅ Active | All profiles configured |
| **TestFlight** | ✅ Active | Auto-submit to internal testing |
| **Google Play Internal** | ✅ Active | Auto-submit to internal testing |
| **App Store** | ⏳ Pending | Manual promotion required |
| **Google Play Store** | ⏳ Pending | Manual promotion required |

---

## ⚡ Performance Optimization Architecture

### Cache-Only Implementation (ENG-736)

**Problem Solved**: Setup stage previously took 9.2 minutes, with 82% spent on artifact creation/upload.

**Solution**: Eliminated artifacts entirely, using GitHub Actions cache directly in each job.

#### Before vs After Performance

| Metric | Before (Artifact-Based) | After (Cache-Only) | Improvement |
|--------|------------------------|-------------------|-------------|
| **Setup Time** | 9.2 minutes | ~30 seconds | **82% faster** |
| **Artifact Creation** | 342 seconds | Eliminated | **100% reduction** |
| **Artifact Upload** | 111 seconds | Eliminated | **100% reduction** |
| **Job Start Delay** | ~9 minutes | Immediate | **Job parallelization** |

#### Cache Key Strategy

```yaml
# Optimized cache key pattern includes ALL dependency sources
key: ${{ runner.os }}-deps-${{ hashFiles('**/package.json', '**/package-lock.json', '**/requirements.txt') }}

# Cache paths cover all dependency locations
path: |
  ~/.npm
  ~/.cache/pip
  .venv
  node_modules
  apps/*/node_modules
```

#### Architecture Benefits

1. **Immediate Job Start**: No waiting for setup job artifacts
2. **Direct Cache Access**: Each job uses cache independently
3. **Simplified Workflow**: No artifact creation/upload/download steps
4. **Better Debugging**: Cache hit/miss status visible per job
5. **GitHub Best Practice**: Aligns with GitHub Actions recommendations

#### Implementation Details

- **UV Binary Caching**: Prevents race conditions during parallel installs
- **Dependency Verification**: Consistent logic across all jobs with verification logging
- **Cache Hit Logging**: Explicit cache status reporting for debugging
- **Fallback Installation**: Automatic dependency installation when cache misses

### Monitoring Cache Performance

```bash
# Check cache hit rates in workflow logs
gh run list --workflow=ci-cd.yml --limit=10
gh run view [run-id] --log | grep "Cache hit status"

# Local cache key testing
echo "node_modules pattern: $(find . -name package.json -o -name package-lock.json | sort)"
echo "python pattern: $(find . -name requirements.txt | sort)"
```

---

## 🛠️ Troubleshooting

### Common Issues

#### EAS Build Archive Size Issues
```bash
# Symptom: "Your project archive is 3.2 GB"
# Root cause: EAS uploads entire monorepo including all dependencies
# Solution: Use "deny all, then allow specific" .easignore pattern

# Create .easignore in repository root:
*                          # Deny everything
!/apps/mobile/            # Allow mobile app
!/packages/               # Allow shared packages
/apps/mobile/node_modules  # Re-exclude node_modules

# See: docs/gotchas/eas-build-archive-optimization.md
```

#### EAS Build Failures
```bash
# Check build status
cd apps/mobile
eas build:list --limit=5

# View build logs
eas build:view [build-id]
```

#### TestFlight Submission Issues
```bash
# Check submission status
eas submit:list --platform ios

# Common issues:
# - Missing iOS certificates
# - Invalid bundle ID
# - Apple Developer account issues
```

#### Google Play Submission Issues
```bash
# Check submission status
eas submit:list --platform android

# Common issues:
# - Missing service account key
# - Invalid package name
# - Play Console permissions
```

#### EAS Build Wait Logic Issues
```bash
# Symptom: CI/CD fails with "build status fetch failed" but builds are running
# Root cause: EAS API may not return build status immediately after trigger

# Solution implemented in CI/CD:
# 1. 30-second initial delay before first status check
# 2. Treat fetch failures as "pending" not "errored"
# 3. Only fail on actual build errors

# Manual verification if CI shows false failure:
cd apps/mobile
eas build:list --platform all --limit 5
# Check Expo dashboard: https://expo.dev/accounts/degree-analytics/projects/spacewalker/builds
```

### Debug Commands

```bash
# Check current build profiles
cd apps/mobile
eas build:configure

# Test build locally
eas build --profile development --local

# Check credentials
eas credentials

# View project configuration
eas project:info
```

---

## 📊 Build Performance Metrics

### Typical Build Times

| Phase | Duration | Optimization |
|-------|----------|--------------|
| **Setup** | ~2 minutes | ✅ Cached dependencies |
| **Backend Tests (Matrix)** | ~2-3 minutes | ✅ 3x faster with matrix strategy |
| **Frontend Tests (Parallel)** | ~3-5 minutes | ✅ Parallel execution |
| **EAS Build** | ~10-15 minutes | ⚠️ EAS service dependent |
| **Docker Build** | ~5-8 minutes | ✅ Matrix parallelization |
| **Deployment** | ~3-5 minutes | ✅ Parallel service deployment |
| **App Store Submission** | ~2-3 minutes | ✅ Automated |

**Total Pipeline Time**: ~25-35 minutes (including mobile builds)

### Resource Usage

- **GitHub Actions**: ~40-50 minutes of compute time
- **EAS Build Credits**: 1 build per supported platform per push
- **Artifact Storage**: ~1GB per build (1-day retention)

---

## 🔗 Related Documentation

- [Mobile Development Workflows](./mobile-development.md)
- [AWS Deployment Guide](./aws-deployment-guide.md)
- [Environment Setup](../setup/environment-setup.md)
- [Mobile Architecture](../mobile/architecture/mobile-container-architecture.md)

---

*Last Updated: $(date)*
*Pipeline Version: Combined CI/CD v1.0*
