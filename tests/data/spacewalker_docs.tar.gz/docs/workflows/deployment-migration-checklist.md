# 🚀 Deployment Migration Checklist

## 📋 PRE-DEPLOYMENT VALIDATION

### Before ANY Production Deployment:

1. **Check Migration State**
   ```bash
   # Get current prod DB migration
   just sql "SELECT version_num FROM alembic_version;" prod

   # Get expected migration from code
   cd apps/backend && alembic show head
   ```

2. **If Migrations Don't Match:**
   ```bash
   # Option 1: Apply missing migrations (RECOMMENDED)
   just shell backend prod
   alembic upgrade head
   exit

   # Option 2: If customers exist and migrations are complex
   # Create staging environment with prod data copy first
   # Test migration path before applying to prod
   ```

3. **Verify Migration Success**
   ```bash
   just sql "SELECT version_num FROM alembic_version;" prod
   # Should match: alembic show head
   ```

## 🔄 STANDARD DEPLOYMENT WORKFLOW

### 1. Code Changes with Database Schema Changes
```bash
# In backend directory
alembic revision --autogenerate -m "description"
# Review generated migration file
alembic upgrade head  # Test locally
```

### 2. Before Pushing to Dev/Main
```bash
# Ensure dev database is up to date
just shell backend dev
alembic upgrade head
exit

# Verify dev works with new schema
just health dev
```

### 3. Production Deployment
```bash
# Check prod migration state (see above)
# Apply migrations if needed (see above)
# Deploy code via normal CI/CD or manual deploy
```

## 🚨 EMERGENCY PROCEDURES

### If Deployment Fails Due to Migration Mismatch:

1. **Immediate Fix**
   ```bash
   just shell backend prod
   alembic upgrade head
   exit
   ```

2. **Re-deploy**
   ```bash
   # CI/CD will automatically retry, or
   just aws deploy backend prod
   ```

3. **Verify Success**
   ```bash
   just health prod
   just aws status backend prod
   ```

## 📏 PREVENTION RULES

### ✅ DO:
- Always run `alembic upgrade head` in target environment before deploying containers
- Test migration path in staging environment for complex changes
- Keep environments in sync with same migration versions
- Use `alembic upgrade head` command, never manual database edits

### ❌ DON'T:
- Deploy containers without ensuring database schema matches
- Manually edit `alembic_version` table (dangerous anti-pattern)
- Assume environments have same migration state
- Skip testing migration path for merge commits

## 🔧 TOOLING IMPROVEMENTS

### CI/CD Pipeline Enhanced
- Added pre-deployment migration validation
- Deployment blocks if database/code migration mismatch
- Clear error messages with fix instructions

### Justfile Commands Added
```bash
just migration-check env    # Check if DB matches code migration
just migration-fix env      # Apply missing migrations
just deployment-verify env  # Full pre-deployment verification
```

## 📊 MONITORING

### Post-Deployment Verification
```bash
# Verify services are healthy
just health prod
just aws status all prod

# Check application logs for migration-related errors
just logs backend prod --errors-only

# Verify database schema matches expectations
just sql "SELECT version_num FROM alembic_version;" prod
```

---
*This checklist prevents deployment failures caused by database migration mismatches.*
