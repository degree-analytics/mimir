# Dependency Management Workflow

## Purpose
Comprehensive guide for managing project dependencies and cleaning build artifacts across all Spacewalker components. Covers installation, updates, and cleanup procedures.

## When to Use This
- Setting up a new development environment
- Updating project dependencies
- Cleaning build artifacts and caches
- Recovering from dependency conflicts
- Preparing for a fresh build
- Keywords: dependencies, install, clean, npm, pip, docker, cache

**Version:** 1.0
**Date:** 2025-07-26
**Status:** Current

---

## Overview

Spacewalker uses a unified dependency management system through justfile commands that handle:
- Python dependencies (backend, scripts)
- Node.js dependencies (admin, mobile)
- Docker images and containers
- Build artifacts and caches

## Installation Workflows

### Quick Install (All Dependencies)

```bash
# Default: full local environment (base + dev + tooling + backend/admin/mobile)
just install

# CI / developer workflows (base + dev extras, backend requirements)
just install target=dev

# Runtime-only (minimal dependencies, no tooling)
just install target=runtime

# Optional doc-search tooling (Mímir CLI, vector search extras)
just install target=tooling

# Legacy service installs remain available if needed
just install backend
just install admin
just install mobile
```

### What Gets Installed

**Default (`just install`)**:
- Creates Python virtual environment (.venv)
- Installs scripts package with dev + tooling extras
- Installs evaluation package (for shared test utilities)
- Installs backend requirements (`apps/backend/requirements.txt`)
- Installs npm dependencies for admin and mobile apps
- Installs root workspace npm packages

**Dev (`just install target=dev`)**:
- Base + dev extras
- Backend requirements
- Skips tooling extras and frontend installs (faster CI path)

**Tooling (`just install target=tooling`)**:
- Base package
- Mímir CLI + vector/LLM extras
- No service installs

**Runtime (`just install target=runtime`)**:
- Base package only (useful for production images)

## Cleanup Workflows

### Basic Clean

```bash
# Clean all services (containers, images, artifacts)
just clean

# Clean specific service
just clean backend
just clean admin
just clean mobile
```

### Deep Clean Options

```bash
# Remove dependencies and volumes (requires confirmation)
just clean --deep

# Clear all caches
just clean --cache

# Nuclear option - remove EVERYTHING
just clean --nuclear

# Skip confirmation prompts
just clean --deep --force
```

### Cleanup Levels Explained

**Basic Clean (`just clean`)**:
- Stops and removes Docker containers
- Removes Docker images
- Removes volumes
- Cleans service-specific artifacts

**Deep Clean (`just clean --deep`)**:
- Everything from basic clean, plus:
- Removes all node_modules directories
- Removes Python virtual environment (.venv)
- Removes build directories (.next, .expo, .build)
- Removes Docker volumes

**Cache Clean (`just clean --cache`)**:
- Clears npm cache
- Removes Python __pycache__ directories
- Removes .pyc files
- Clears Docker build cache
- Removes .DS_Store and .log files

**Nuclear Clean (`just clean --nuclear`)**:
- Everything from deep + cache clean, plus:
- Docker system prune (removes ALL unused Docker data)
- Clears Docker metadata
- Complete fresh start

## Common Scenarios

### Fresh Setup on New Machine

```bash
# 1. Run bootstrap to install prerequisites
./scripts/bootstrap.sh

# 2. Install all dependencies
just install

# 3. Start services
just service up
```

### Dependency Conflicts

```bash
# 1. Clean everything
just clean --deep

# 2. Reinstall
just install

# 3. Restart services
just service restart
```

### Before Major Updates

```bash
# 1. Clean caches to avoid conflicts
just clean --cache

# 2. Update dependencies
just install

# 3. Run tests
just test unit all
```

### CI/CD Pipeline Issues

```bash
# Ensure prerequisites are installed
pip install pyyaml python-dotenv

# Then run normal install
just install
```

### Docker Space Issues

```bash
# Quick cleanup
just clean docker

# More aggressive cleanup
just clean --cache

# Nuclear option (removes ALL Docker data)
just clean --nuclear --force
```

## Best Practices

### Regular Maintenance

1. **Weekly**: Run `just clean --cache` to clear build caches
2. **Before PRs**: Run `just install` to ensure dependencies are current
3. **After merges**: Run `just install` to pick up new dependencies

### Troubleshooting

**"Module not found" errors**:
```bash
# Python modules
just clean backend --deep
just install backend

# Node modules
just clean admin --deep
just install admin
```

**Docker issues**:
```bash
# Reset Docker state
just clean docker --force
just service rebuild
```

**Out of disk space**:
```bash
# Progressive cleanup
just clean              # Try basic first
just clean --cache      # Then caches
just clean --deep       # Then deep
just clean --nuclear    # Last resort
```

## Technical Details

### Dependency Locations

- **Python**: `.venv/` (virtual environment)
- **Backend**: `apps/backend/requirements.txt`
- **Admin**: `apps/admin/package.json`
- **Mobile**: `apps/mobile/package.json`
- **Root**: `package.json` (workspace dependencies)

### Cache Locations

- **NPM**: `~/.npm` and `node_modules/.cache`
- **Python**: `__pycache__` directories
- **Docker**: Docker build cache
- **Build**: `.next`, `.expo`, `.build`

### Environment Variables

The service manager respects these environment variables:
- `AWS_PROFILE`: For AWS operations
- `DOCKER_BUILDKIT`: For build performance
- Standard Docker environment variables

## Related Documentation

- [Developer Prerequisites](../setup/developer-prerequisites.md) - Required tools
- [Quick Start Guide](../setup/quick-start.md) - Getting started
- [Enhanced Workflows](./enhanced-workflows.md) - Docker operations
- [Testing Guide](./testing-guide.md) - Running tests

## Command Reference

```bash
# Installation
just install [all|backend|admin|mobile]

# Cleanup
just clean [all|backend|admin|mobile|docker] [--deep] [--cache] [--nuclear] [--force]

# Verification
just health          # Check if services are healthy
just env_check       # Verify environment setup
```
