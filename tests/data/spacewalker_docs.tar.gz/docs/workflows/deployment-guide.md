# Spacewalker Deployment Guide

## Purpose
Complete deployment documentation for all environments - from local development to AWS production infrastructure. Comprehensive guide for developers, DevOps engineers, and operations teams.

## When to Use This
- Setting up local development environment quickly
- Deploying to AWS production infrastructure
- Configuring environment variables and secrets
- Implementing CI/CD pipelines and automation
- Troubleshooting deployment issues and operational problems
- Keywords: deployment, AWS, production, infrastructure, CI/CD, automation

**Version:** 2.0 (Updated for new documentation structure)
**Date:** 2025-06-29
**Status:** Current - Complete Deployment Hub

---

## 🚀 Quick Start Deployment
**Get something running quickly** - Perfect for developers and immediate testing

Experience our **revolutionary automated setup** that gets you from zero to fully running in minutes:

```bash
just workflow_setup    # One-command magic setup with professional automation
```

This intelligent automation:
- 🔍 **Validates** your environment (Python, Node.js, Docker, uv)
- 📦 **Installs** all dependencies intelligently
- 🔧 **Configures** mobile IP automatically
- 🐳 **Starts** all services with health checks
- 🧪 **Tests** everything to ensure it works

### 📚 Quick Start Resources
- **[Getting Started Guide](../setup/getting-started.md)** - Complete automated setup and verification
- **[Environment Configuration](../setup/environment-setup.md)** - Variable setup and troubleshooting
- **[Project Structure](../development/project-structure.md)** - Understanding the codebase organization

### 🎯 Common Commands
```bash
just up                     # Start all services
just health                 # Verify everything works
just test unit all             # Run tests
just expo start --offline   # Connect mobile app
```

---

## 🛡️ Production Safety System
**MANDATORY SETUP** - Essential safety protection for all team members deploying to production

### 🚨 **Why This Matters**
Production deployments carry significant risk. Our safety system prevents:
- Accidental production deployments during development work
- Forgotten production mode leading to security exposure
- Wrong AWS account deployment (sandbox vs production confusion)
- Unauthorized production access

### ⚡ **Quick Setup for New Team Members**

**1. Configure AWS Profiles** (if not already done):
```bash
# Configure production AWS profile
aws configure --profile production
# Enter production account credentials (352676346183)

# Configure sandbox profile
aws configure --profile sandbox
# Enter sandbox account credentials (881490112168)
```

**2. Add Production Safety to Shell** (required for Warp/Oh My Zsh users):

> ⚠️ **UPDATE REQUIRED**: If you added this before July 2025, you need to update your `~/.zshrc` to support the new ISO date format. The old Unix timestamp format is deprecated.

```bash
# Backup current shell config
cp ~/.zshrc ~/.zshrc.backup

# Add production mode integration
cat >> ~/.zshrc << 'EOF'

#--------------------
# Production Mode Terminal Integration
#--------------------
# Function to check production mode status
check_prod_mode() {
    if [ -f .prod_mode_expires ]; then
        expires=$(cat .prod_mode_expires)
        # Check if file contains Unix timestamp (old format) or ISO format (new format)
        if [[ "$expires" =~ ^[0-9]+$ ]]; then
            # Old Unix timestamp format
            current=$(date +%s)
            if [ $current -lt $expires ]; then
                remaining=$((expires - current))
                minutes=$((remaining / 60))
                echo "🚨PROD:${minutes}m"
            else
                rm -f .prod_mode_expires 2>/dev/null
                echo ""
            fi
        else
            # New ISO format - use Python for date comparison
            if python3 -c "from datetime import datetime, timezone; expires = datetime.fromisoformat('$expires'); now = datetime.now(timezone.utc) if expires.tzinfo else datetime.now(); exit(0 if now < expires else 1)" 2>/dev/null; then
                # Calculate remaining time
                remaining=$(python3 -c "from datetime import datetime, timezone; expires = datetime.fromisoformat('$expires'); now = datetime.now(timezone.utc) if expires.tzinfo else datetime.now(); print(int((expires - now).total_seconds()))")
                minutes=$((remaining / 60))
                echo "🚨PROD:${minutes}m"
            else
                rm -f .prod_mode_expires 2>/dev/null
                echo ""
            fi
        fi
    else
        echo ""
    fi
}

# Production mode Powerlevel10k segment (for Oh My Zsh users)
function prompt_prod_mode() {
    local prod_status=$(check_prod_mode)
    if [[ -n "$prod_status" ]]; then
        p10k segment -f white -b red -t "$prod_status"
    fi
}

# Terminal title integration (works in all terminals)
function set_terminal_title_with_prod() {
    local prod_status=$(check_prod_mode)
    local title="Terminal"
    if [[ -n "$prod_status" ]]; then
        title="$prod_status - PRODUCTION MODE ACTIVE"
    fi
    echo -ne "\033]0;$title\007"
}

autoload -U add-zsh-hook
add-zsh-hook precmd set_terminal_title_with_prod

# Aliases for quick access
alias prodstatus='just prod status'
alias prodenable='just prod enable'
alias proddisable='just prod disable'
EOF

# Reload shell configuration
source ~/.zshrc
```

**3. For Powerlevel10k Users** (optional visual prompt indicator):
```bash
# Edit ~/.p10k.zsh and add 'prod_mode' to your prompt elements:
# Find POWERLEVEL9K_LEFT_PROMPT_ELEMENTS and add:
#   prod_mode               # production mode indicator
```

### 🎯 **How the Safety System Works**

**Production Mode Activation:**
```bash
# Enable production mode (time-limited)
just prod enable --minutes=30    # Enable for 30 minutes
# Type: ENABLE PRODUCTION ACCESS

# Check status
just prod status       # Show remaining time

# Disable manually
just prod disable      # Immediate disable
```

**Visual Indicators:**
- **Terminal Tab Title**: Shows `🚨PROD:15m - PRODUCTION MODE ACTIVE`
- **Prompt Segment** (if configured): Red `🚨PROD:15m` in your prompt
- **Command Warnings**: Production deployment commands show account info

**Security Features:**
- **Explicit Activation**: Must type exact phrase to enable
- **Time-Limited**: Auto-expires (15-60 minutes recommended)
- **Visual Feedback**: Impossible to miss when active
- **Account Verification**: Shows target AWS account in warnings
- **Command Blocking**: All production commands blocked unless enabled

### 🚀 **Protected Commands**
All AWS deployment commands are protected and require production mode:
- `just aws deploy all prod`
- `just aws deploy foundation prod`
- `just aws deploy backend prod`
- `just aws deploy admin prod`
- `just aws deploy mobile prod`
- `just aws deploy database prod`
- `just aws deploy dns prod`

---

## 🏗️ AWS Production Deployment
**Complete production deployment** - For DevOps engineers deploying to AWS infrastructure

Deploy Spacewalker to AWS with our Infrastructure as Code approach using SAM templates and ECS containerization.

### ⚠️ **PREREQUISITE: Production Safety Setup Required**
**Before production deployment, you MUST complete the [Production Safety System](#-production-safety-system) setup above.**

### 📖 **Unified Command Help System**
All unified commands support contextual help. Get detailed information about any command:
```bash
just aws help              # Show all AWS deployment commands
just db help               # Show all database commands
just test help             # Show all testing commands
just help                  # Show all available commands
```

### 🔄 Deployment Pipeline Overview

```mermaid
graph TD
    A[🏗️ Foundation<br/>Infrastructure] --> B[🗃️ Database<br/>Setup]
    B --> C[🐳 Container<br/>Services]
    C --> D[🌐 DNS & SSL<br/>Configuration]
    D --> E[📊 Monitoring<br/>& Logging]

    A1[VPC, Networking<br/>Security Groups] --> A
    B1[RDS PostgreSQL<br/>Multi-tenant Config] --> B
    C1[ECS Cluster<br/>Backend, Admin, Mobile] --> C
    D1[Domain Config<br/>Automatic HTTPS] --> D
    E1[CloudWatch Integration<br/>Health Checks] --> E

    F[🚀 Production Ready] --> E

    style A fill:#e1f5fe
    style B fill:#f3e5f5
    style C fill:#e8f5e8
    style D fill:#fff3e0
    style E fill:#fce4ec
    style F fill:#e0f2f1
```

### 📋 Production Deployment Process

1. **Foundation Infrastructure** - VPC, networking, security groups
2. **Database Setup** - RDS PostgreSQL with multi-tenant configuration
3. **Container Services** - ECS cluster with backend, admin, and mobile services
4. **DNS & SSL** - Domain configuration with automatic HTTPS
5. **Monitoring & Logging** - CloudWatch integration and health checks

### 📚 Production Resources

- **[Main Deployment Guide](deployment/aws-deployment-order.md)** - **Step-by-step AWS production deployment**
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - CloudFormation DNS and certificate configuration
- **[SAM Templates](../../sam/)** - Infrastructure as Code definitions
  - `foundation/template.yaml` - VPC and networking
  - `database/template.yaml` - RDS PostgreSQL setup
  - `ecs/cluster.yaml` - Container orchestration
  - `ecs/backend.yaml` - Backend API deployment
  - `ecs/admin.yaml` - Admin dashboard deployment
  - `ecs/mobile.yaml` - Mobile service deployment

### 🚀 Deployment Commands

**Safe Production Deployment Workflow:**
```bash
# 1. Enable production mode (required for prod environment)
just prod enable --minutes=30          # Enable for 30 minutes
# Type: ENABLE PRODUCTION ACCESS

# 2. Verify production mode active (check terminal tab title)
just prod status             # Show remaining time

# 3. Deploy with automatic safety features
just aws deploy foundation prod    # Deploy base infrastructure (PROTECTED)
just aws deploy database prod      # Deploy database (PROTECTED)
just aws deploy cluster prod       # Deploy ECS cluster (PROTECTED)
just aws deploy backend prod       # Deploy backend service (PROTECTED)
just aws deploy admin prod         # Deploy admin dashboard (PROTECTED)
just aws deploy mobile prod        # Deploy mobile service (PROTECTED)

# 4. Validate deployment
just health prod               # Check deployment health

# Alternative: Deploy everything at once
just aws deploy all prod           # Deploy all components (PROTECTED)
```

**Sandbox Development (No Protection Needed):**
```bash
just aws deploy foundation dev     # Works without production mode
just aws deploy backend dev        # Safe for development testing
just health dev                # Check dev environment
```

**Key Safety Features:**
- 🛡️ **Production commands automatically blocked** without `prod_enable`
- 🔄 **Automatic AWS profile switching**: `production` for prod, `sandbox` for dev
- 📊 **Account verification**: Shows target AWS account before deployment
- ⏰ **Time-limited access**: Production mode auto-expires
- 👀 **Visual indicators**: Terminal title shows production mode status

**Related Documentation:**
- **[Backend Development](../backend/development/README.md)** - Backend-specific deployment procedures
- **[Admin Architecture](../admin/architecture/README.md)** - Admin dashboard deployment
- **[Mobile Development](../mobile/development/README.md)** - Mobile app distribution

---

## ⚙️ Environment Configuration
**Configure different environments** - Environment variables, secrets, and multi-tenant setup

Comprehensive configuration management for development, staging, and production environments with AWS Secrets Manager integration.

### 🔑 Configuration Areas

- **Environment Variables** - Service configuration and feature flags
- **AWS Secrets Manager** - Secure credential and API key management
- **Multi-Tenant Setup** - Database isolation and tenant-specific configuration
- **Service Discovery** - Internal service communication configuration

### 📚 Configuration Resources

- **[Environment Configuration Reference](../setup/environment-setup.md)** - **Comprehensive configuration guide**
- **[Backend Environment Template](../../apps/backend/env.example)** - Backend-specific configuration

### 🔧 Configuration Commands

```bash
just env_check              # Validate environment configuration
just env_status             # Show current environment status
just expo ip auto           # Configure mobile networking
```

---

## 🔄 CI/CD & Automation
**Automated deployment workflows** - GitHub Actions, testing pipelines, and deployment automation

Professional-grade CI/CD pipeline with comprehensive testing, security scanning, and automated deployment to AWS.

### 🔨 Pipeline Features

- **Multi-Stage Testing** - Unit, integration, and end-to-end tests
- **Security Scanning** - Vulnerability detection and dependency checking
- **Docker Image Building** - Multi-platform containerization
- **Automated Deployment** - ECS service updates with rollback capability
- **Environment Promotion** - Staged deployment through dev → staging → production

### 📚 CI/CD Resources

- **[Main CI/CD Pipeline](../../.github/workflows/ci-cd.yml)** - **Complete workflow definition**
- **[Claude Integration](../../.github/workflows/claude.yml)** - AI-assisted development workflow
- **[Deployment Scripts](../../scripts/deployment/)** - Python and shell automation tools
- **AWS Commands** - Use `just aws` commands for AWS operations

### 📝 Important Note: Deployment Scripts vs Local Commands

**Why deployment scripts use direct AWS CLI instead of justfile commands:**

The deployment scripts in `scripts/deployment/` (like `force-ecs-deployment.sh` and `deployment-verification.sh`) intentionally use direct AWS CLI commands rather than justfile wrappers. This is by design:

1. **CI/CD Context** - These scripts run in GitHub Actions where justfile commands aren't available
2. **Precise Control** - Deployment verification requires specific AWS API calls that justfile commands don't expose
3. **Error Handling** - Scripts need granular error codes and outputs for deployment validation
4. **Profile Management** - Scripts already handle AWS profiles correctly for CI/CD environments

**When to use what:**
- **Local Development**: Always use `just` commands (e.g., `just aws deploy backend dev`)
- **CI/CD Scripts**: Direct AWS CLI is appropriate and expected
- **Manual Operations**: Use `just` commands for consistency and safety

This distinction ensures that local development follows standardized patterns while CI/CD pipelines have the flexibility they need for complex deployment operations.

### ⚡ Automation Commands

```bash
just workflow_ci            # Run full CI pipeline locally
just dev_cycle              # Quick validation (30-60 sec)
just docker_build           # Build all container images
```

**Related Documentation:**
- **[Testing Guide](./testing-guide.md)** - Comprehensive testing workflows for deployment validation

---

## 🔧 Infrastructure Management
**Manage and maintain infrastructure** - Monitoring, scaling, backup, and operational procedures

Tools and procedures for maintaining AWS infrastructure, monitoring system health, and handling operational tasks.

### 🏥 Management Areas

- **Infrastructure Monitoring** - CloudWatch metrics and alerting
- **Health Checking** - Automated status validation across services
- **Scaling Considerations** - Auto-scaling configuration and manual scaling
- **Backup & Recovery** - Database backups and disaster recovery procedures
- **Security Maintenance** - Certificate renewal and security updates

### 📚 Management Resources

- **Infrastructure Checker** - AWS infrastructure status validation (deprecated script removed)
- **[Development Tools](../development/development-tools.md)** - Complete inventory of operational scripts
- **[Justfile Operations](../../justfile)** - Infrastructure commands (`just aws_*`, `just docker_*`)

### 🔍 Management Commands

```bash
just health dev         # Check AWS infrastructure status
just docker_status          # Docker system diagnostics
just db_backup              # Create database backup
just env_status             # Environment health overview
```

### 🏛️ Tenant Management Commands

**System Default Tenant Attribute Initialization**

The System Default tenant (ID: 1) requires attribute initialization for developers to test attribute functionality in the admin interface. These commands ensure the System Default tenant has all 41 standard attribute definitions across 7 categories.

```bash
# Local Development (requires running backend)
just db_init_system_attributes

# Cloud Environments (dev/prod with safety checks)
just aws init system-attributes dev   # Initialize in development environment
just aws init system-attributes prod  # Initialize in production environment (requires prod_enable)
```

**Demo Tenant Management**

```bash
# Local Development
just db_demo_clean           # Remove demo tenant data (preserves other tenants)
just db_demo_minimal         # Create minimal demo tenant and users
just db_demo_debug           # Complete demo tenant debugging workflow

# Cloud Environments
just aws init demo-db dev    # Initialize comprehensive demo tenant in cloud
just aws init demo-db prod   # Initialize demo tenant in production
```

**Tenant Inspection and Debugging**

```bash
# Inspect tenant attribute setup
just db_inspect_attributes                 # Check demo tenant attributes
just db_inspect_attributes tenant_id=1     # Check System Default tenant attributes
just db_inspect_attributes tenant_id=123   # Check specific tenant attributes

# General tenant status
just db status               # View all tenants and database status
just db shell             # Access database shell for manual queries
```

**Usage Examples**

```bash
# Complete System Default tenant setup for new environment
just aws init system-attributes dev

# Expected output:
# ✅ System Default attribute initialization completed successfully!
# ✅ System Default tenant now has all 41 standard attributes
# ✅ Developers can now test attribute functionality in admin interface

# Verify initialization worked
just db_inspect_attributes tenant_id=1

# Debug tenant setup if issues occur
just db_demo_debug
```

---

## 🚨 Troubleshooting & Operations
**Solve deployment problems** - Debugging tools, common issues, and resolution procedures

Comprehensive troubleshooting resources for deployment failures, performance issues, and operational problems.

### 🔍 Troubleshooting Categories

- **Deployment Failures** - Build errors, infrastructure issues, service startup problems
- **Performance Problems** - Slow response times, resource constraints, optimization
- **Connectivity Issues** - Network problems, service discovery, external API access
- **Environment Problems** - Configuration errors, missing dependencies, permission issues

### 📚 Troubleshooting Resources

- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - **Comprehensive problem resolution workflows**
- **[Common Gotchas](../gotchas/)** - Known issues and workarounds
- **[Deployment Fixer](../../scripts/deployment/fix-deployment.sh)** - Automated deployment issue resolution
- **Infrastructure Status** - Health checking and validation (deprecated script removed)

### 🔧 Debugging Commands

```bash
just health                 # Quick service health check
just logs [service]         # View service logs
just docker_status          # Docker diagnostics
just env_check             # Environment validation
just workflow_setup        # Complete re-setup for major issues
```

### 🆘 Emergency Recovery

```bash
# Nuclear option: complete reset
just clean && just workflow_setup

# Database recovery
just db_safe_reset          # Reset with backup preservation

# Infrastructure recovery
just aws deploy foundation  # Redeploy base infrastructure
```

---

## 🎯 Target Audiences

### 👨‍💻 Developers
**Focus**: Local setup and development deployment
- Start with [Quick Start Deployment](#-quick-start-deployment)
- Use [Environment Configuration](#-environment-configuration) for setup
- Reference [Troubleshooting](#-troubleshooting--operations) for issues

### 🔧 DevOps Engineers
**Focus**: Production infrastructure and CI/CD
- Primary: [AWS Production Deployment](#-aws-production-deployment)
- Supporting: [CI/CD & Automation](#-cicd--automation)
- Reference: [Infrastructure Management](#-infrastructure-management)

### 🔍 Operations Teams
**Focus**: Monitoring, troubleshooting, maintenance
- Primary: [Infrastructure Management](#-infrastructure-management)
- Daily: [Troubleshooting & Operations](#-troubleshooting--operations)
- Reference: [Environment Configuration](#-environment-configuration)

---

## Application-Specific Deployment

### Backend Deployment
- **[Backend Development Guide](../backend/development/README.md)** - FastAPI service deployment procedures
- **[Backend Architecture](../backend/architecture/README.md)** - Service design and infrastructure requirements

### Admin Dashboard Deployment
- **[Admin Architecture Guide](../admin/architecture/README.md)** - Next.js dashboard deployment procedures
- **[Admin Architecture](../admin/architecture/README.md)** - Dashboard architecture and hosting requirements

### Mobile App Deployment
- **[Mobile Development Guide](../mobile/development/README.md)** - React Native app distribution and deployment
- **[Mobile Architecture](../mobile/architecture/README.md)** - App architecture and platform considerations

---

## Related Documentation

- **[Getting Started Guide](../setup/getting-started.md)** - Complete project setup and first deployment
- **[Environment Configuration](../setup/environment-setup.md)** - Variable setup and troubleshooting
- **[Testing Guide](./testing-guide.md)** - Testing workflows and CI/CD validation
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Problem resolution and debugging
- **[Project Structure](../development/project-structure.md)** - Understanding the codebase organization

---

## 📞 Getting Help

- **Command Help**: `just help` or `just --list`
- **Environment Diagnostics**: `just env_check`
- **Infrastructure Status**: `just health dev`
- **Docker Issues**: `just docker_status`

**Happy deploying!** 🚀

---
**Status**: ✅ Updated and current as of 2025-06-29. Reorganized for improved navigation and enhanced with application-specific deployment cross-references.
