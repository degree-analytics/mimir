# GitHub Pages Build Metrics Dashboard

## Overview

The GitHub Pages Build Metrics Dashboard provides real-time visibility into the effectiveness of the EAS build optimization system. It displays cost savings, skip rates, build patterns, and performance metrics through interactive charts and summary statistics.

### Dashboard Access

- **Live URL**: [https://degree-analytics.github.io/spacewalker/dashboard.html](https://degree-analytics.github.io/spacewalker/dashboard.html)
- **Auto-redirect**: [https://degree-analytics.github.io/spacewalker/](https://degree-analytics.github.io/spacewalker/)
- **Repository**: Deployed from `gh-pages` branch in the spacewalker repository

## Architecture Overview

The dashboard uses a **dual-update mechanism** where metrics collection and dashboard deployment are separate processes:

```mermaid
graph TD
    A[Main Branch Build] --> B[CI/CD Workflow]
    B --> C[Collect Build Metrics Job]
    C --> D[Update .build/metrics/*.json]
    D --> E[Commit to gh-pages Branch]
    E --> F[Deploy Dashboard Workflow]
    F --> G[Generate Static Dashboard]
    G --> H[Deploy to GitHub Pages]
    H --> I[Dashboard Updates Live]
```

### Key Components

1. **Metrics Collection** - Automated during CI/CD builds
2. **Data Storage** - JSON files on `gh-pages` branch  
3. **Dashboard Generation** - React-based static HTML
4. **Deployment Pipeline** - GitHub Actions workflow
5. **Auto-Updates** - Multiple trigger mechanisms

## Dashboard Features

### Summary Cards

The dashboard displays four key performance indicators:

| Metric | Description | Color Indicator |
|--------|-------------|-----------------|
| **Total Cost Savings** | Cumulative dollar savings from skipped builds | 🟢 Green (Success) |
| **Skip Rate** | Percentage of builds successfully skipped | 🟢 Green (Success) |
| **Total Builds** | Number of builds processed by the system | 🔵 Blue (Neutral) |
| **Avg Build Time** | Average duration when builds are required | 🟡 Yellow (Warning) |

Each card includes:
- Current value for selected time period
- Trend indicator (📈 increase, 📉 decrease, ➡️ stable)
- Comparison to previous period

### Interactive Charts

#### 1. Cost Savings Trend (Full-Width)
- **Type**: Combined Line + Bar Chart
- **Data**: Cumulative savings (line) + daily savings (bars)
- **Features**: Dual Y-axes, responsive tooltips, time period filtering
- **Purpose**: Track financial impact over time

#### 2. Skip Rate Analysis
- **Type**: Bar Chart with Pie Chart toggle
- **Data**: iOS vs Android skip rates by day
- **Features**: Platform comparison, percentage display, toggle views
- **Purpose**: Understand platform-specific optimization effectiveness

#### 3. Build Frequency  
- **Type**: Area Chart with gradient fill
- **Data**: Number of builds triggered per day
- **Features**: Smooth curves, pattern recognition
- **Purpose**: Identify build volume trends and peaks

#### 4. Build Time Distribution
- **Type**: Line Chart with multiple series
- **Data**: Average, iOS, and Android build durations
- **Features**: Multi-platform tracking, time-based trends
- **Purpose**: Monitor build performance when optimization is bypassed

#### 5. Build Patterns
- **Type**: Stacked Bar Chart
- **Data**: Build outcomes (Skipped, Succeeded, Failed)
- **Features**: Outcome categorization, success rate tracking
- **Purpose**: Analyze build reliability and optimization effectiveness

### Time Range Filtering

All charts support dynamic time range selection:

- **7 Days** - Default view, shows recent trends
- **30 Days** - Monthly patterns and cycles  
- **90 Days** - Quarterly analysis and longer trends
- **All Time** - Complete historical data

Filter changes update all charts simultaneously with smooth transitions.

## Data Sources & Structure

### Metrics Storage Location

All metrics are stored on the `gh-pages` branch in:
```
.build/metrics/
├── build-metrics.json      # Primary optimization data
└── build-times.json        # Build duration tracking
```

### Data Structure

#### build-metrics.json
```json
{
  "builds": [
    {
      "date": "2024-08-28T10:00:00Z",
      "branch": "main",
      "ios_skipped": true,
      "android_skipped": false,
      "minutes_saved": 12,
      "reason": "No iOS-specific changes detected",
      "ios_actual_duration": null,
      "android_actual_duration": 15.2
    }
  ],
  "total_minutes_saved": 340,
  "total_builds_skipped": 45,
  "total_cost_saved": 561.00,
  "last_updated": "2024-08-28T16:45:00Z"
}
```

#### build-times.json
```json
{
  "ios": [
    {
      "date": "2024-08-28T10:00:00Z",
      "duration": 15.3,
      "status": "success"
    }
  ],
  "android": [
    {
      "date": "2024-08-28T14:30:00Z",
      "duration": 12.8,
      "status": "success"
    }
  ]
}
```

### Data Collection Process

Metrics are collected through the `collect-build-metrics` job in the main CI/CD workflow:

```yaml
collect-build-metrics:
  needs: [detect-changes, build-ios, build-android]
  if: always() && github.ref == 'refs/heads/main'
  runs-on: ubuntu-latest
  steps:
    - name: Collect build optimization metrics
      run: |
        # Extract build decisions and outcomes
        # Calculate time and cost savings
        # Update metrics JSON files
        # Commit to gh-pages branch
```

## Deployment Pipeline

### Update Triggers

The dashboard automatically updates when:

1. **Metrics Changes** (Most Common)
   - Trigger: Push to main branch with metrics updates
   - Path: `.build/metrics/*.json` changes
   - Frequency: Every main branch build

2. **Daily Scheduled Update**
   - Trigger: Cron job at 6:00 AM UTC
   - Purpose: Refresh stale data, regenerate dashboard
   - Schedule: `0 6 * * *` (daily)

3. **Manual Workflow Dispatch**
   - Trigger: Manual GitHub Actions trigger
   - Purpose: Emergency updates, testing, troubleshooting
   - Parameters: `force_deploy` option available

4. **Dashboard Template Changes**
   - Trigger: Changes to `scripts/helpers/metrics/dashboard.html`
   - Purpose: UI improvements, feature additions
   - Frequency: As needed during development

### Deployment Workflow (`deploy-dashboard.yml`)

The deployment process follows these steps:

```yaml
name: Deploy EAS Build Metrics Dashboard

on:
  push:
    branches: [main]
    paths: ['.build/metrics/*.json', 'scripts/helpers/metrics/dashboard.html']
  workflow_dispatch:
    inputs:
      force_deploy:
        description: 'Force deploy even if no metrics changes'
        type: boolean
        default: false
  schedule:
    - cron: '0 6 * * *'

jobs:
  deploy-dashboard:
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}dashboard.html
```

### Deployment Steps

1. **Repository Checkout**
   - Full history fetch for metrics analysis
   - Node.js 18 and Python 3.12 setup

2. **Data Validation**
   - Check for existing metrics data
   - Generate sample data if none exists
   - Validate JSON structure integrity

3. **Dashboard Generation**
   - Copy template from `scripts/helpers/metrics/dashboard.html`
   - Update GitHub Pages paths for data fetching
   - Configure CDN URLs for React/Recharts libraries

4. **GitHub Pages Preparation**
   - Create pages directory structure
   - Copy dashboard and metrics files
   - Generate index.html with auto-redirect
   - Create README.md with deployment info

5. **GitHub Pages Deployment**
   - Configure Pages action
   - Upload artifacts
   - Deploy to live site
   - Output final dashboard URL

## Chart Interpretation Guide

### Understanding the Metrics

#### Cost Savings Calculation
- **Formula**: `minutes_saved × $1.65/minute` (based on EAS pricing)
- **Cumulative View**: Shows total savings over time
- **Daily View**: Shows daily contribution to savings
- **Trend Analysis**: Compare current vs previous period performance

#### Skip Rate Analysis
- **Calculation**: `(builds_skipped / total_possible_builds) × 100`
- **Platform Comparison**: iOS vs Android optimization effectiveness
- **Success Indicator**: Higher percentages indicate better optimization
- **Target Range**: 60-80% skip rate indicates healthy optimization

#### Build Frequency Patterns
- **Daily Volume**: Number of builds triggered per day
- **Peak Detection**: Identify high-activity periods
- **Pattern Recognition**: Weekday vs weekend patterns
- **Capacity Planning**: Understand resource usage trends

#### Build Time Distribution  
- **Performance Tracking**: Monitor build duration when optimization is bypassed
- **Platform Comparison**: iOS vs Android build performance
- **Regression Detection**: Identify performance degradation
- **Optimization Opportunities**: Find platforms needing attention

#### Build Patterns Analysis
- **Outcome Categories**:
  - 🟢 **Skipped**: Builds avoided due to smart triggering
  - 🔵 **Succeeded**: Completed builds that were necessary  
  - 🔴 **Failed**: Builds that failed and need attention
- **Success Rate**: Percentage of non-skipped builds that succeed
- **Reliability Indicator**: Low failure rate indicates stable system

### Chart Interaction Features

#### Responsive Design
- **Desktop**: Two-column layout with full-width cost savings chart
- **Tablet**: Single-column layout with optimized spacing
- **Mobile**: Vertical stack with touch-friendly controls

#### Interactive Elements
- **Tooltips**: Hover for detailed data points and context
- **Time Filters**: Click to change date range across all charts
- **Chart Toggles**: Switch between bar/pie views on skip rate chart
- **Loading States**: Visual feedback during data fetching
- **Error Recovery**: Retry buttons for failed data loads

#### Accessibility Features
- **ARIA Labels**: Screen reader support for interactive elements
- **Color Contrast**: High contrast colors for visibility
- **Keyboard Navigation**: Tab-accessible chart controls
- **Alternative Text**: Descriptive labels for chart elements

## Troubleshooting Guide

### Common Issues

#### 1. Dashboard Not Loading

**Symptoms:**
- Blank white page
- "Loading..." state persists
- JavaScript console errors

**Debugging Steps:**
```bash
# Check if metrics files exist
curl -I https://degree-analytics.github.io/spacewalker/metrics/build-metrics.json

# Verify GitHub Pages is enabled
# Go to repository Settings > Pages > Verify source is gh-pages branch

# Check workflow status
gh run list --workflow=deploy-dashboard.yml
```

**Common Causes:**
- GitHub Pages not configured correctly
- Metrics files missing or corrupted
- CDN resources blocked by network/firewall
- JavaScript errors in browser console

**Solutions:**
- Enable GitHub Pages in repository settings
- Trigger manual workflow dispatch to regenerate
- Check browser console for specific error messages
- Verify CDN integrity hashes match current versions

#### 2. Outdated Data

**Symptoms:**
- Dashboard shows old metrics
- "Last updated" timestamp is stale
- Recent builds not reflected

**Debugging Steps:**
```bash
# Check latest mobile workflow runs
gh run list --workflow=mobile-smart-build.yml --limit=5

# Verify metrics collection job ran
gh run view [RUN_ID] --log

# Check gh-pages branch updates
git log origin/gh-pages --oneline -n 10 --grep="metrics"
```

**Solutions:**
- Trigger manual deployment: `gh workflow run deploy-dashboard.yml -f force_deploy=true`
- Check if main branch builds are running the metrics collection job
- Verify gh-pages branch permissions allow automated commits
- Review CI/CD workflow for failed metrics collection steps

#### 3. Charts Not Rendering

**Symptoms:**
- Summary cards load but charts show loading spinners
- "Unable to load data" error messages
- Charts display but without data points

**Debugging Steps:**
```bash
# Test data file accessibility
curl https://degree-analytics.github.io/spacewalker/metrics/build-metrics.json | jq '.'

# Check browser network tab for failed requests
# Look for CORS errors or 404s on metrics files

# Verify JSON structure
python3 -c "
import json, requests
r = requests.get('https://degree-analytics.github.io/spacewalker/metrics/build-metrics.json')
data = r.json()
print(f'Builds: {len(data.get(\"builds\", []))}')
print(f'Valid structure: {\"total_minutes_saved\" in data}')
"
```

**Solutions:**
- Check browser console for specific JavaScript errors
- Verify metrics JSON files have correct structure
- Test dashboard locally with sample data
- Ensure Recharts CDN resources are accessible

#### 4. Performance Issues

**Symptoms:**
- Slow chart loading times
- Unresponsive UI during time range changes
- High memory usage in browser

**Debugging Steps:**
- Check data file sizes: large datasets may cause performance issues
- Profile JavaScript execution in browser DevTools
- Monitor network requests for slow CDN responses

**Solutions:**
- Implement data pagination for very large datasets
- Add data aggregation for longer time periods
- Consider chart virtualization for large data sets
- Optimize chart rendering performance

### Data Recovery

#### Missing Metrics Files

If metrics files are missing or corrupted:

```bash
# Regenerate from git history
git log --oneline --grep="metrics" --since="1 month ago"

# Extract metrics from recent mobile runs
gh run list --workflow=mobile-smart-build.yml --json url,status,conclusion

# Manually create sample data (for testing)
mkdir -p .build/metrics
cat > .build/metrics/build-metrics.json << 'EOF'
{
  "builds": [],
  "total_minutes_saved": 0,
  "total_builds_skipped": 0,
  "total_cost_saved": 0.0,
  "last_updated": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
}
EOF
```

#### Backup and Restore

The system automatically maintains metrics history in git:

```bash
# View metrics history
git log --follow --patch -- .build/metrics/build-metrics.json

# Restore previous version
git checkout HEAD~5 -- .build/metrics/build-metrics.json
git commit -m "restore: revert metrics to working state"
```

## Maintenance and Monitoring

### Regular Health Checks

**Daily:**
- Verify dashboard loads correctly
- Check "Last updated" timestamp is recent (< 24 hours)
- Review summary cards for expected values

**Weekly:**
- Compare skip rates to expected baselines (60-80%)
- Review cost savings trends for consistency
- Check for any failed builds requiring attention

**Monthly:**
- Audit metrics data accuracy against CI/CD logs
- Review dashboard performance and loading times
- Update documentation if workflow changes
- Plan capacity increases if data volume grows significantly

### Performance Optimization

**Data Management:**
- Archive old metrics data if files become too large (>1MB)
- Implement data aggregation for historical periods
- Consider data compression for very large datasets

**Chart Performance:**
- Monitor rendering times for large datasets
- Optimize React component re-rendering
- Consider chart virtualization for better performance

**CDN Management:**
- Monitor CDN uptime for React/Recharts libraries
- Update integrity hashes when libraries are updated
- Consider hosting libraries locally if CDN becomes unreliable

### Security Considerations

**GitHub Pages Security:**
- Dashboard is publicly accessible (no sensitive data)
- Uses CDN resources with SRI (Subresource Integrity) hashes
- All data comes from public GitHub repository

**Data Privacy:**
- No user-specific information is collected
- Only aggregate build metrics and timing data
- No authentication or personal data stored

**Content Security:**
- Dashboard uses Content Security Policy headers
- All external resources loaded via HTTPS with integrity checks
- No user-generated content or dynamic server-side processing

## Integration with CI/CD

### Metrics Collection Integration

The dashboard integrates seamlessly with the main CI/CD workflow through the `collect-build-metrics` job:

```yaml
collect-build-metrics:
  needs: [detect-changes, build-ios, build-android]  
  if: always() && github.ref == 'refs/heads/main'
  steps:
    - name: Calculate build metrics
      run: |
        # Extract build decisions from detect-changes job
        MOBILE_CHANGES="${{ needs.detect-changes.outputs.mobile-changes }}"
        IOS_SKIPPED="${{ needs.detect-changes.outputs.should-build-ios != 'true' }}"
        ANDROID_SKIPPED="${{ needs.detect-changes.outputs.should-build-android != 'true' }}"
        
        # Calculate time and cost savings
        # Update metrics JSON files  
        # Commit to gh-pages branch
```

### Smart Triggering Integration

The dashboard provides feedback on smart triggering effectiveness:

- **Decision Validation**: Shows accuracy of skip/build decisions
- **Cost Impact**: Quantifies financial benefits of optimization  
- **Performance Tracking**: Monitors build times when optimization is bypassed
- **Pattern Recognition**: Identifies trends in build requirements

### Future Enhancements

**Planned Improvements:**
- Real-time notifications for significant cost savings milestones
- Build prediction using historical patterns and machine learning
- Integration with GitHub commit analysis for better change detection
- Enhanced mobile responsiveness and progressive web app features
- A/B testing framework for different optimization strategies

**API Integration:**
- REST API for programmatic access to metrics data
- Webhook notifications for build optimization events
- Integration with external monitoring and alerting systems
- Custom dashboard embedding for other tools and services

The GitHub Pages Build Metrics Dashboard provides comprehensive visibility into the EAS build optimization system, enabling data-driven decisions and continuous improvement of build efficiency and cost management.
