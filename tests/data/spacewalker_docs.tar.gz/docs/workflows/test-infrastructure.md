# Test Infrastructure Guide

## Overview
Spacewalker's hardened test infrastructure provides reliable, repeatable test runs with comprehensive isolation, mocking, and coverage enforcement. This guide documents the test infrastructure improvements implemented as part of Task #1.

## When to Use This Guide
- Understanding test isolation mechanisms
- Configuring test environments
- Troubleshooting test state persistence issues
- Implementing new tests with proper isolation
- Understanding coverage requirements and enforcement

**Version:** 1.0 (Initial comprehensive infrastructure documentation)
**Date:** 2025-08-23
**Status:** Current - Complete Test Infrastructure Documentation

---

## 🏗️ Test Infrastructure Architecture

### Test Isolation System
Our test infrastructure ensures complete isolation between tests to prevent state leakage and ensure reliable, repeatable test runs.

#### Database Transaction Isolation
**Implementation**: `apps/backend/tests/conftest.py` (lines 984-1146)

```python
@pytest.fixture(scope="function")
def db(setup_database):
    """Database session with transaction isolation for test isolation"""
    connection = setup_database.connection()

    # Start outer transaction for isolation
    transaction = connection.begin()

    # Create session bound to this connection
    session = sessionmaker(bind=connection, expire_on_commit=False)()

    # Create nested savepoint for test rollback
    nested = connection.begin_nested()

    # Set up savepoint restoration on rollback
    @event.listens_for(session, "after_transaction_end")
    def end_savepoint(session, transaction):
        nonlocal nested
        if not nested.is_active:
            nested = connection.begin_nested()

    try:
        yield session
    finally:
        session.close()
        nested.rollback()  # Rollback test changes
        transaction.rollback()  # Rollback outer transaction
        connection.close()
```

**Key Features:**
- **Outer Transaction**: Provides test-level isolation
- **Nested Savepoints**: Enable rollback of individual test changes
- **Automatic Restoration**: Savepoints are automatically restored after rollbacks
- **Session Management**: Proper cleanup of database sessions

#### Global State Reset
**Implementation**: `apps/backend/tests/conftest.py` (lines 66-111)

```python
@pytest.fixture(autouse=True, scope="function")
def reset_singletons_and_globals():
    """Reset all singleton and global state between tests"""

    # Clear FastAPI dependency cache
    app.dependency_overrides.clear()

    # Clear service factory singletons
    service_factory.clear_cache()

    # Clear ContextVar tenant context
    tenant_context.clear()

    # Clear CSRF cache
    csrf_cache.clear()

    # Reset any other global state...

    yield  # Run the test

    # Post-test cleanup (if needed)
    # Additional cleanup operations can be added here
```

**State Reset Includes:**
- FastAPI dependency injection cache
- Service factory singleton instances
- Tenant context variables (ContextVar)
- CSRF token cache
- Any other application-level global state

#### External Service Mocking
**Implementation**: `apps/backend/tests/conftest.py` (lines 114-159)

```python
@pytest.fixture(autouse=True, scope="function")
def mock_external_services():
    """Mock all external service calls for test isolation"""

    # Mock email service (SES)
    with patch('boto3.client') as mock_boto_client:
        mock_ses = MockSESClient()
        mock_boto_client.return_value = mock_ses

        # Mock Redis connections
        with patch('redis.Redis') as mock_redis:
            mock_redis_instance = MockRedisClient()
            mock_redis.return_value = mock_redis_instance

            # Mock HTTP requests
            with patch('requests.get') as mock_requests_get, \
                 patch('requests.post') as mock_requests_post:

                # Configure mock responses
                mock_requests_get.return_value.json.return_value = {"status": "success"}
                mock_requests_post.return_value.status_code = 200

                yield {
                    'ses_client': mock_ses,
                    'redis_client': mock_redis_instance,
                    'requests_get': mock_requests_get,
                    'requests_post': mock_requests_post,
                }
```

**Mocked Services Include:**
- **AWS SES**: Email sending service (boto3)
- **Redis**: Caching and session storage
- **HTTP Requests**: External API calls (requests library)
- **File Storage**: S3 operations (when configured)

---

## 🚀 Test Orchestration

### Justfile Integration
All tests are orchestrated through justfile commands to ensure consistent execution environment and parameters.

#### Primary Test Commands
```bash
# Unit tests (fast, isolated)
just test unit backend          # Backend unit tests (~1 min)
just test unit admin           # Admin unit tests (~30 sec)
just test unit mobile          # Mobile unit tests (~1 min)
just test unit all             # All unit tests (~2-3 min)

# Integration tests (with infrastructure)
just test integration backend   # Backend integration tests (~5 min)
just test integration admin     # Admin integration tests (~2 min)
just test integration all      # All integration tests (~10 min)

# System tests (end-to-end)
just test system backend       # Backend system tests (~10 min)
just test all backend          # All backend test types (~15 min)
just test all all              # All tests, all repositories (~20 min)
```

#### Advanced Test Commands
```bash
# With coverage reporting
just test unit backend --coverage                    # Coverage reports
just test unit all --coverage --coverage-dir=custom  # Custom coverage directory

# With database management
just test unit backend --db-reset                    # Reset database before tests
just test integration backend --db-clean             # Clean test data before tests

# CI mode with strict settings
just test all all --ci --coverage                    # CI-optimized execution

# Pattern matching
just test unit backend --pattern=test_auth           # Run specific test patterns

# Verbose output
just test integration backend --verbose              # Detailed test output
```

### Test Manager Implementation
**Location**: `scripts/helpers/test_manager.py`

The unified test manager consolidates 40+ individual test commands into a single interface:

```python
# Database reset integration
def reset_database():
    """Reset the database completely (drops all data)."""
    result = subprocess.run(['just', 'db', 'reset'], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ Database reset failed: {result.stderr}")
        return False

    result = subprocess.run(['just', 'db', 'init'], capture_output=True, text=True)
    return result.returncode == 0

def clean_database():
    """Clean test/demo data from database (preserves foundation data)."""
    result = subprocess.run(['just', 'db', 'clean'], capture_output=True, text=True)
    return result.returncode == 0

# Usage in main()
if args.db_reset:
    if not reset_database():
        return EXIT_FAILURE
elif args.db_clean:
    if not clean_database():
        return EXIT_FAILURE
```

**Features:**
- **Database Management**: Integrated database reset and cleaning
- **Coverage Integration**: Unified coverage reporting across all repositories
- **Pattern Matching**: Flexible test selection with patterns
- **Environment Detection**: Automatic virtual environment detection
- **Error Handling**: Comprehensive error reporting and exit codes

---

## 📊 Coverage Enforcement

### 80% Coverage Requirement
**Configuration**: `apps/backend/pytest.ini`

```ini
[pytest]
pythonpath = src
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = -ra -q --cov=src --cov-fail-under=80 --cov-report=term-missing --cov-report=html --cov-report=xml
asyncio_mode = auto
```

**Key Coverage Settings:**
- **`--cov=src`**: Coverage scoped to source code only
- **`--cov-fail-under=80`**: Tests fail if coverage < 80%
- **`--cov-report=term-missing`**: Terminal report shows missing lines
- **`--cov-report=html`**: Generates HTML coverage report
- **`--cov-report=xml`**: Generates XML coverage report for CI

### Coverage Integration
**Implementation**: `scripts/helpers/test_manager.py` (lines 187-233)

```python
def add_coverage_options(cmd, coverage, validated_coverage_path, repo_name, repo_path, ci=False):
    """Add coverage options to the test command."""
    if not coverage:
        return True

    if repo_name == 'backend':
        # System tests get coverage disabled (override pytest.ini)
        if any('system' in arg for arg in cmd):
            cmd.extend(['--cov-fail-under=0'])
        # For backend, pytest.ini handles the rest (--cov=src, --cov-fail-under=80, etc.)
    else:
        # Non-backend repos (admin/mobile use different coverage systems)
        cmd.extend(['--cov'])

    # Add custom coverage directory if provided
    if validated_coverage_path:
        cmd.extend([
            f'--cov-report=xml:{validated_coverage_path}/coverage.xml',
            f'--cov-report=html:{validated_coverage_path}/htmlcov',
            '--cov-report=term-missing'
        ])

    print_coverage_thresholds(repo_name, repo_path)
    return True
```

**Coverage Features:**
- **Automatic Enforcement**: Tests fail when coverage < 80%
- **System Test Exemption**: End-to-end tests are exempt from coverage requirements
- **Custom Directories**: Support for custom coverage output locations
- **Multi-Repository Support**: Different coverage systems for different repositories
- **Threshold Display**: Coverage requirements are displayed during test runs

### Coverage Validation
```bash
# Example coverage validation output
📊 Coverage threshold: 80% (configured in pytest.ini)
🧪 Running backend unit tests...
   Command: python -m pytest tests/unit

TOTAL                    10863   7038    35%
Coverage HTML written to dir htmlcov
Coverage XML written to file coverage.xml

FAIL Required test coverage of 80% not reached. Total coverage: 35.21%
❌ Tests failed with exit code: 1
```

**Coverage Enforcement:**
- **Exit Code 1**: Test runs fail with non-zero exit code when coverage is insufficient
- **Clear Reporting**: Coverage percentage and threshold are clearly displayed
- **Multiple Formats**: HTML, XML, and terminal coverage reports generated
- **CI Integration**: Coverage failures block CI/CD pipelines

---

## 🛠️ Database Management

### Database Reset Strategies
The test infrastructure provides two database management strategies:

#### Full Reset (`--db-reset`)
```bash
just test unit backend --db-reset
```

**Process:**
1. **Drop Database**: `just db reset` - Completely removes all data and schema
2. **Reinitialize**: `just db init` - Recreates schema and adds foundation data
3. **Run Tests**: Execute tests with clean database state

**Use Cases:**
- Testing database migrations
- Ensuring clean schema state
- Testing with only foundation data

#### Surgical Clean (`--db-clean`)
```bash
just test integration backend --db-clean
```

**Process:**
1. **Clean Test Data**: `just db clean` - Removes demo/test data only
2. **Preserve Foundation**: Keeps essential system data (users, roles, etc.)
3. **Run Tests**: Execute tests with clean but functional database

**Use Cases:**
- Regular integration testing
- Cleaning up after previous test runs
- Maintaining functional database state

### Database Commands
```bash
# Database inspection
just db shell                    # Open PostgreSQL shell
just db verify                   # Check database consistency

# Database management
just db init                     # Initialize with foundation data
just db clean                    # Remove demo/test data only
just db reset                    # Complete reset and reinitialize

# Database backup/restore
just db backup dev               # Create RDS snapshot (dev environment)
just db restore dev snapshot-id  # Restore from snapshot
```

---

## 🔧 Mock Configuration

### Service Mocking Architecture
**Location**: `apps/backend/src/spacecargo/api/services/service_factory.py`

```python
class MockServiceFactory:
    """Factory for creating mock services during testing"""

    def get_email_service(self) -> MockEmailService:
        """Return mock email service for testing"""
        return MockEmailService()

    def get_storage_service(self) -> MockStorageService:
        """Return mock storage service for testing"""
        return MockStorageService()

    def clear_cache(self):
        """Clear all cached service instances"""
        self._instances.clear()
```

### Mock Service Implementations

#### Mock Email Service
**Location**: `apps/backend/src/spacecargo/api/services/email_service.py` (lines 28-57)

```python
class MockSESClient:
    """Mock SES client for testing"""

    def send_email(self, **kwargs):
        """Mock send_email method"""
        return {"MessageId": "mock-message-id-12345"}

    def get_send_quota(self):
        """Mock get_send_quota method"""
        return {"Max24HourSend": 1000, "MaxSendRate": 10, "SentLast24Hours": 0}

    def verify_email_identity(self, **kwargs):
        """Mock verify_email_identity method"""
        return {"ResponseMetadata": {"HTTPStatusCode": 200}}
```

#### Mock Redis Client
```python
class MockRedisClient:
    """Mock Redis client for testing"""

    def __init__(self):
        self._data = {}

    def get(self, key):
        return self._data.get(key)

    def set(self, key, value, ex=None):
        self._data[key] = value
        return True

    def delete(self, key):
        return self._data.pop(key, None) is not None
```

### CSRF Cache Management
**Location**: `apps/backend/src/spacecargo/api/security/csrf_cache.py`

```python
# Global CSRF token cache
_csrf_cache = {}

def clear():
    """Clear CSRF cache for testing"""
    global _csrf_cache
    _csrf_cache.clear()

def generate_token():
    """Generate CSRF token"""
    token = secrets.token_urlsafe(32)
    _csrf_cache[token] = True
    return token
```

---

## 🧪 Test Fixture Architecture

### Core Test Fixtures
**Location**: `apps/backend/tests/conftest.py`

#### Session-Level Fixtures
```python
@pytest.fixture(scope="session")
def setup_database():
    """Session-scoped database setup"""
    # One-time database setup for entire test session
    engine = create_test_engine()
    metadata.create_all(engine)
    yield sessionmaker(bind=engine)
    metadata.drop_all(engine)

@pytest.fixture(scope="session")
def setup_test_environment():
    """Session-scoped environment setup"""
    # Configure test environment variables
    # Set up test configuration
    # Initialize test services
    yield
```

#### Function-Level Fixtures
```python
@pytest.fixture(scope="function")
def db(setup_database):
    """Function-scoped database session with transaction isolation"""
    # Documented above in Database Transaction Isolation section

@pytest.fixture(scope="function", autouse=True)
def reset_singletons_and_globals():
    """Auto-use fixture for global state reset"""
    # Documented above in Global State Reset section

@pytest.fixture(scope="function", autouse=True)
def mock_external_services():
    """Auto-use fixture for external service mocking"""
    # Documented above in External Service Mocking section
```

### Fixture Dependencies
```mermaid
graph TD
    A[setup_test_environment] --> B[setup_database]
    B --> C[db]
    D[reset_singletons_and_globals] --> C
    E[mock_external_services] --> C
    C --> F[Test Execution]

    style A fill:#e3f2fd
    style B fill:#f1f8e9
    style C fill:#fff3e0
    style F fill:#e8f5e8
```

---

## 🎯 Testing Best Practices

### Test Isolation Principles
1. **No Shared State**: Each test runs in complete isolation
2. **Clean Database**: Database state is reset between tests
3. **Mocked Externals**: All external services are mocked
4. **Consistent Environment**: Same environment setup for all tests

### Coverage Standards
1. **80% Minimum**: All backend code must maintain 80% test coverage
2. **System Test Exemption**: End-to-end tests are exempt from coverage requirements
3. **Quality over Quantity**: Focus on meaningful test coverage, not just percentage
4. **Regular Monitoring**: Coverage is monitored in every test run

### Database Testing Patterns
1. **Transaction Isolation**: Use database transactions for test isolation
2. **Foundation Data**: Maintain essential system data for realistic testing
3. **Test Data Cleanup**: Clean up test-specific data between runs
4. **Schema Validation**: Ensure database schema consistency

### Mock Testing Guidelines
1. **Comprehensive Mocking**: Mock all external service dependencies
2. **Realistic Behavior**: Mocks should behave like real services
3. **Error Simulation**: Include error scenarios in mock implementations
4. **State Management**: Mock services maintain appropriate state during tests

---

## 🚀 Running Tests

### Quick Start
```bash
# Fastest feedback (unit tests only)
just test unit all              # ~2-3 minutes

# With database reset
just test unit backend --db-reset   # Clean database state

# With coverage
just test unit all --coverage       # Generate coverage reports

# Complete validation
just test all all --coverage        # All tests with coverage (~20 min)
```

### Development Workflow
```bash
# Morning routine
just health                     # Verify services are running
just test unit all              # Quick validation (~2-3 min)

# During development
just test unit backend          # After backend changes (~1 min)
just test unit admin           # After admin changes (~30 sec)

# Before commit
just test integration all       # Full integration testing (~10 min)
just test all backend --coverage   # Backend validation with coverage
```

### CI/CD Pipeline
```bash
# Simulating CI environment locally
just test unit all --ci            # Unit tests in CI mode
just test integration all --ci     # Integration tests in CI mode
just test all all --ci --coverage  # Complete CI pipeline simulation
```

---

## 🔍 Troubleshooting

### Recent Fixes (August 2024)

#### Token Mismatch Issues (RESOLVED)
**Problem**: Integration tests failing due to hardcoded expected token mismatches with dynamically generated tokens

**Files Fixed**:
- `apps/backend/tests/integration/test_email_localstack.py`
- `apps/backend/tests/integration/test_invitations_router.py`
- `apps/backend/tests/integration/test_localstack_email_content.py`

**Solution**: Fixed by using dynamically generated tokens instead of hardcoded values
```python
# BEFORE (failing):
token=f"invite-abc-{generate_unique_test_data('email2', include_uuid=False)}",
assert "invite/accept?token=invite-abc-123" in invitation_link

# AFTER (working):
test_token = f"invite-abc-{generate_unique_test_data('email2', include_uuid=False)}"
token=test_token,
assert f"invite/accept?token={test_token}" in invitation_link
```

**Status**: ✅ Fixed - Email LocalStack tests now pass (13/13 tests passing)

#### Email Generation Improvements (RESOLVED)
**Problem**: Email utility functions using inconsistent patterns for unique data generation

**Files Fixed**:
- `apps/backend/tests/integration/test_invitations_router.py`

**Solution**: Standardized email generation using `generate_unique_email()` helper
```python
# BEFORE:
admin_email = f"ex_{generate_unique_test_data('exp_test_admin')[:12]}@test.com"

# AFTER:
admin_email = generate_unique_email('exp_admin', 'test.com')
```

**Status**: ✅ Fixed - Consistent email generation across test suite

### Known Issues (Current Status)

#### Integration Test Performance
**Issue**: Some integration tests timeout during CI/CD runs (2-minute timeout exceeded)
**Impact**: Medium - Tests may need to be run individually or with extended timeouts
**Files Affected**: Various integration test files
**Workaround**:
```bash
# Run specific test files individually
just test integration backend --pattern="test_specific_file.py"

# Use longer timeout for full integration suite
# (Configured in pytest settings)
```

#### Deprecated Pydantic Validators
**Issue**: 44+ warnings about deprecated Pydantic V1 validators throughout codebase
**Impact**: Low - Tests run successfully but with warnings
**Files Affected**: Router files in `src/spacecargo/api/routers/`
**Future Action**: Migrate to Pydantic V2 `@field_validator` syntax

#### LocalStack Email Processing Delays
**Issue**: Integration tests occasionally need extra time for LocalStack email processing
**Impact**: Low - Tests include appropriate delays but may need tuning
**Current Mitigation**: Tests include `await asyncio.sleep(1)` for email processing time

### Common Issues

#### Test State Persistence
**Problem**: Tests fail intermittently due to state leakage between tests

**Solution**: The test infrastructure automatically resets all state between tests
- Database transactions are rolled back
- Global state is cleared
- External services are re-mocked

**Verification**:
```bash
# Run tests multiple times to verify isolation
just test unit backend
just test unit backend
just test unit backend
```

#### Coverage Failures
**Problem**: Tests pass but fail due to insufficient coverage

**Solution**:
```bash
# Check current coverage
just test unit backend --coverage

# View detailed coverage report
open apps/backend/htmlcov/index.html

# Focus on uncovered code
grep "Missing" apps/backend/coverage.xml
```

#### Database Connection Issues
**Problem**: Database connection errors during tests

**Solution**:
```bash
# Verify database is running
just health local

# Reset database state
just test unit backend --db-reset

# Check database connection
just db shell
```

#### Mock Service Issues
**Problem**: External service calls not properly mocked

**Solution**: The `mock_external_services` fixture automatically mocks all external services
- AWS services (SES, S3, Secrets Manager)
- Redis connections
- HTTP requests
- File system operations

**Verification**: Look for mock setup in test output and verify no real network calls are made

### Performance Issues

#### Slow Test Execution
**Optimization Strategies**:
```bash
# Run only unit tests for fast feedback
just test unit backend          # ~1 minute

# Use pattern matching for specific tests
just test unit backend --pattern=test_auth

# Parallel execution (when available)
just test unit all             # Runs repositories in parallel
```

#### Database Performance
**Database Optimization**:
- Transaction isolation is faster than database recreation
- Use `--db-clean` instead of `--db-reset` when possible
- Consider using in-memory databases for unit tests

### Debugging Test Failures

#### Verbose Output
```bash
# Enable verbose test output
just test unit backend --verbose

# View test command being executed
python scripts/helpers/test_manager.py unit backend --verbose
```

#### Database Debugging
```bash
# Inspect database state
just db shell

# Check database consistency
just db verify

# View database logs
just logs backend dev
```

#### Coverage Debugging
```bash
# Generate coverage report
just test unit backend --coverage

# View HTML coverage report
open apps/backend/htmlcov/index.html

# Check coverage configuration
cat apps/backend/pytest.ini
```

---

## 📚 Configuration Files

### Backend Configuration
- **`apps/backend/pytest.ini`**: Main pytest configuration with coverage settings
- **`apps/backend/tests/conftest.py`**: Test fixtures and environment setup
- **`apps/backend/pyproject.toml`**: Python dependencies including test frameworks

### Test Manager Configuration
- **`scripts/helpers/test_manager.py`**: Unified test orchestration system
- **`justfile`**: Test command definitions and orchestration

### Coverage Configuration
- **HTML Reports**: Generated in `apps/backend/htmlcov/`
- **XML Reports**: Generated as `apps/backend/coverage.xml`
- **Custom Directories**: Configurable via `--coverage-dir` option

---

## 📞 Getting Help

### Command Help
```bash
# Test manager help
python scripts/helpers/test_manager.py help

# Justfile help
just help

# Specific command help
just test help
```

### Documentation References
- **[Testing Guide](./testing-guide.md)**: Comprehensive testing workflows
- **[Test Organization Guide](./test-organization-guide.md)**: Test structure and categorization
- **[Troubleshooting Guide](./troubleshooting-guide.md)**: General troubleshooting procedures

### Configuration References
- **Backend pytest.ini**: Coverage and test configuration
- **Backend conftest.py**: Test fixtures and isolation setup
- **Test Manager**: Unified test orchestration system

---

**Status**: ✅ Complete - Comprehensive test infrastructure documentation covering all Task #1 improvements (Database Transaction Isolation, Global State Reset, External Service Mocking, Justfile Integration, Database Reset Capabilities, and 80% Coverage Enforcement).

**Last Updated**: 2025-08-23
