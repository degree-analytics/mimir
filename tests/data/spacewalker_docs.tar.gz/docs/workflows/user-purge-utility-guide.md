# User Management Utility Usage Guide

## Purpose
Comprehensive guide for using the User Management Utility to safely manage users and invitations with auto-detection, comprehensive safety checks, transaction integrity, and audit logging.

## When to Use This
- Managing user accounts and invitation system
- Removing users or canceling invitations from the system
- Cleaning up test data after development/testing
- Handling user account removal requests (GDPR compliance)
- Database maintenance and cleanup operations
- Troubleshooting user-related data issues

**Keywords:** user management, invitation management, database cleanup, GDPR, user deletion, data purging, auto-detection

---

## Overview

The User Management Utility is a unified command-line tool designed to safely manage both registered users and pending invitations in the Spacewalker database. It automatically detects whether an email belongs to a registered user or a pending invitation and handles each appropriately. The utility provides comprehensive safety mechanisms, production environment protection, and detailed audit logging.

**🏗️ Current Status**: Production-ready utility with auto-detection and comprehensive safety checks
**📅 Last Updated**: 2025-08-04
**🔧 Location**: `apps/backend/src/spacecargo/scripts/user_cli.py`

---

## Safety Features

### Auto-Detection System
- **Smart Entity Recognition**: Automatically detects whether an email belongs to a registered user or pending invitation
- **Appropriate Handling**: Uses different deletion strategies for users vs invitations
- **Unified Interface**: Single command handles both entity types seamlessly
- **Type Identification**: Clear indication of what type of entity was found and processed

### Production Environment Protection
- **Environment Detection**: Automatically detects production environments
- **Double Confirmation**: Requires explicit confirmation for production operations
- **Forced Acknowledgment**: Production purges require typing confirmation text
- **Environment Indicators**: Checks DATABASE_URL, ENVIRONMENT, and DEPLOYMENT_CONTEXT

### Transaction Safety
- **Atomic Operations**: All deletions occur within database transactions
- **Rollback on Failure**: Automatic rollback if any deletion step fails
- **Foreign Key Discovery**: Automatically discovers database relationships (for users)
- **Cascade Planning**: Shows deletion impact before execution (for users)
- **Simple Removal**: Direct deletion for invitations (no cascade needed)

### Audit and Logging
- **Comprehensive Logging**: Every operation is logged with timestamps
- **Performance Metrics**: Duration and affected record counts tracked
- **Audit Trail**: Complete history of all management operations
- **Error Logging**: Detailed error information with stack traces
- **Entity Type Tracking**: Logs distinguish between user and invitation operations

---

## Installation and Setup

### Prerequisites
- Backend development environment setup
- Database connection configured
- Python dependencies installed

### Environment Setup
```bash
# Ensure backend environment is activated
cd apps/backend

# Verify database connection
export DATABASE_URL="postgresql://user:pass@localhost:5432/spacewalker"

# Optional: Set log level for detailed output
export VERBOSE=1
```

---

## Command Reference

### Basic Usage Pattern
```bash
# Via justfile (recommended) - Auto-detects users vs invitations
just user <command> [options]

# Direct Python execution
cd apps/backend
python src/spacecargo/scripts/user_cli.py <command> [options]
```

### Global Options
- `--database-url, -d`: Override database connection URL
- `--dry-run`: Preview operations without making changes
- `--verbose, -v`: Enable detailed output and logging
- `--help`: Show command help

---

## Core Commands

### 1. Check Environment (`check-env`)

Verify current environment configuration and safety status.

```bash
# Check environment configuration
just user check-env

# Verbose environment check
just user --verbose check-env
```

**Output:**
- Environment variables (ENVIRONMENT, DEPLOYMENT_CONTEXT)
- Database connection details (masked credentials)
- Production detection status
- Safety recommendations

### 2. Show User or Invitation Information (`show`)

**🔄 Auto-Detection**: Automatically detects whether the email belongs to a registered user or pending invitation and displays appropriate information.

Display comprehensive information for users or invitations with auto-detection.

```bash
# Show user or invitation (auto-detects which type)
just user show --email user@example.com

# Show user by ID (only works for registered users)
just user show --id 123

# Different output formats for users
just user show --email user@demo.com --format table
just user show --email user@demo.com --format tree
just user show --email user@demo.com --format both

# Verbose output with relationship analysis (for users)
just user --verbose show --email user@example.com

# Example: Show invitation information
just user show --email invitation@pending.com
```

**Output Format Options:**
- `table`: Structured table view of user data
- `tree`: Hierarchical tree view of relationships
- `both`: Combined table and tree views (default)

**Information Displayed:**

**For Users:**
- User details (ID, email, name, tenant, permissions)
- Related record counts across all tables
- Foreign key relationship mapping
- Impact assessment for potential deletion

**For Invitations:**
- Invitation details (ID, email, status, role, tenant)
- Invitation metadata (created, expires, invited by)
- Token usage status and acceptance information

### 3. Purge User or Invitation (`purge`)

**🔄 Auto-Detection**: Automatically detects whether the email belongs to a registered user or pending invitation and applies appropriate deletion strategy.

```bash
# ALWAYS use dry-run first to preview changes (auto-detects user vs invitation)
just user --dry-run purge --email user@example.com

# Actual deletion (auto-detects user vs invitation)
just user purge --email user@example.com

# Purge by user ID (only works for registered users)
just user purge --id 123

# Skip confirmation prompts (use with caution)
just user purge --email user@demo.com --force

# Verbose output with detailed progress (for users)
just user --verbose purge --email user@example.com

# Example: Purge invitation
just user purge --email invitation@pending.com --force
```

**Important Notes:**
- **ALWAYS run with `--dry-run` first** to preview changes
- **Auto-Detection**: Handles users and invitations differently (cascade vs direct deletion)
- **Users**: Full cascade deletion with transaction safety and rollback
- **Invitations**: Simple direct deletion (no related records to cascade)
- Requires explicit confirmation in production environments
- All deletions are atomic (transaction-based)
- Automatically discovers and deletes related records

### 5. Audit Log (`audit-log`)

View and analyze audit log entries from purge operations.

```bash
# Show audit log summary
just user audit-log --summary

# Show last 50 log entries
just user audit-log --tail 50

# Filter by action type
just user audit-log --action purge_completed

# Filter by user email
just user audit-log --user-email john@company.com

# Show entries since specific date
just user audit-log --since 2024-01-01

# Combine filters
just user audit-log --action show_user_completed --tail 20
```

**Log Entry Types:**
- `show_user_*`: User information queries
- `find_duplicates_*`: Duplicate analysis operations
- `purge_*`: User deletion operations
- Error entries with full stack traces

---

## Workflow Examples

### Standard User Cleanup Workflow

```bash
# 1. Check environment safety
just user check-env

# 2. Find the user and analyze impact
just user --verbose show-user --email user@example.com

# 3. Preview the deletion (DRY RUN)
just user --dry-run purge-user --email user@example.com

# 4. Execute the deletion (if safe)
just user purge-user --email user@example.com

# 5. Verify completion in audit log
just user audit-log --user-email user@example.com
```

### Duplicate User Cleanup Workflow

```bash
# 1. Find all duplicates in the system
just user find-duplicates --criteria all --output detailed

# 2. Analyze specific duplicate users
just user --verbose show-user --email duplicate@example.com

# 3. Preview deletion of extra duplicates
just user --dry-run purge-user --id 456  # Keep user with ID 123

# 4. Execute cleanup
just user purge-user --id 456

# 5. Verify no duplicates remain
just user find-duplicates --criteria email
```

### Production Environment Workflow

```bash
# 1. Verify production environment
just user check-env

# 2. Extensive analysis before deletion
just user --verbose show-user --email prod-user@company.com

# 3. MANDATORY dry-run in production
just user --dry-run purge-user --email prod-user@company.com

# 4. Production deletion (requires confirmation)
just user purge-user --email prod-user@company.com
# System will prompt for explicit confirmation

# 5. Review audit log
just user audit-log --summary
```

---

## Integration with CI/CD

### Test Environment Cleanup

```bash
# In CI/CD scripts - clean test users
just user find-duplicates --criteria email --output csv > duplicates.csv

# Automated cleanup of test users (with specific email patterns)
just user --dry-run purge-user --email test+cleanup@example.com
just user purge-user --email test+cleanup@example.com --force
```

### Automated Duplicate Detection

```bash
# Weekly duplicate detection report
just user find-duplicates --criteria all --output csv > weekly-duplicates.csv

# Alert if duplicates found
DUPLICATE_COUNT=$(just user find-duplicates --criteria email | grep "duplicate groups found" | cut -d: -f2)
if [ "$DUPLICATE_COUNT" -gt 0 ]; then
    echo "WARNING: $DUPLICATE_COUNT duplicate groups found"
fi
```

---

## Database Relationships

### Automatically Discovered Relationships

The utility uses SQLAlchemy reflection to discover foreign key relationships:

**Typical Relationships:**
- `tenant_members` → `users.id` (user_id, invited_by)
- `tenant_invitations` → `users.id` (invited_by, accepted_by)
- `tenant_audit_logs` → `users.id` (user_id)
- `surveys` → `users.email` (user_id, approved_by - string references)

### Deletion Order

The utility automatically handles deletion in the correct order:

1. **Child Records**: Delete records in tables that reference the user
2. **String References**: Handle special cases like surveys table
3. **User Record**: Finally delete the user record itself
4. **Transaction Commit**: Commit all changes atomically

---

## Error Handling and Troubleshooting

### Common Error Scenarios

**1. Foreign Key Constraint Violations**
```bash
Error: foreign key constraint fails
```
**Solution:**
- Run with `--verbose` to see detailed relationship discovery
- Check for custom database constraints not discovered by reflection
- Verify database schema for cascade rules

**2. User Not Found**
```bash
❌ User not found with email 'user@example.com'
```
**Solution:**
- Verify email spelling and case sensitivity
- Try searching by user ID instead: `--id 123`
- Use `find-duplicates` to locate similar users

**3. Production Environment Protection**
```bash
🚨 PRODUCTION ENVIRONMENT DETECTED!
```
**Solution:**
- This is a safety feature, not an error
- Follow production confirmation prompts
- Always use `--dry-run` first in production

**4. Database Connection Errors**
```bash
❌ Failed to initialize database connection
```
**Solution:**
- Verify DATABASE_URL environment variable
- Check database server availability
- Ensure correct credentials and permissions

### Debug Mode

Enable detailed logging for troubleshooting:

```bash
# Set environment variable for debug output
export VERBOSE=1

# Run command with verbose flag
just user --verbose show-user --email problematic@example.com

# Check audit log for detailed error information
just user audit-log --action error --tail 10
```

### Log File Locations

**Audit Log**: `.build/tmp/user_purge.log`
```bash
# View recent log entries
tail -f .build/tmp/user_purge.log

# Search for specific errors
grep "ERROR" .build/tmp/user_purge.log

# View structured log data
cat .build/tmp/user_purge.log | jq .
```

---

## Performance Considerations

### Large Dataset Handling

**Pagination**: For users with many related records:
- The utility handles large datasets efficiently
- Uses parameterized queries to prevent SQL injection
- Streams deletion operations to minimize memory usage

**Timeout Settings**: For very large deletions:
- Database connection timeout: 30 seconds (configurable)
- Transaction timeout: Based on data volume
- Consider breaking large operations into smaller batches

### Performance Monitoring

```bash
# Monitor operation duration in audit log
just user audit-log --action purge_completed | grep duration_ms

# Get performance summary
just user audit-log --summary
```

**Typical Performance:**
- User lookup: < 100ms
- Related record discovery: 100-500ms
- Small user deletion (< 100 records): 500ms-2s
- Large user deletion (> 1000 records): 2-10s

---

## Security and Compliance

### GDPR Compliance

The utility supports GDPR "right to be forgotten" requirements:

**Complete Data Removal:**
- Discovers all database relationships automatically
- Ensures no orphaned personal data remains
- Provides audit trail for compliance reporting

**Verification:**
```bash
# Verify complete removal
just user show-user --email deleted-user@example.com
# Should return "User not found"

# Check audit trail
just user audit-log --user-email deleted-user@example.com
```

### Access Control

**Who Should Use This Tool:**
- Database administrators
- Senior developers with database access
- DevOps engineers for environment cleanup
- Compliance officers for data removal requests

**Access Requirements:**
- Database write permissions
- Backend development environment access
- Understanding of data relationships
- Authority to delete user data

### Production Safety

**Required Approvals:**
- Production deletions should require management approval
- Document business justification for user removal
- Follow company data retention policies
- Consider legal requirements before deletion

---

## Integration Testing

### Test Environment Setup

```bash
# Setup test database with sample data
just db clean
just db seed

# Create test users for purge testing
just user show-user --email admin@demo.university.edu
```

### Test Scripts

**Example Test Script:**
```bash
#!/bin/bash
# test-user-purge.sh

set -e

echo "Testing User Purge Utility..."

# Test environment check
echo "1. Environment check..."
just user check-env

# Test finding duplicates
echo "2. Finding duplicates..."
just user find-duplicates --criteria all

# Test showing user (with test user)
echo "3. Showing test user..."
just user show-user --email admin@demo.university.edu

# Test dry-run purge
echo "4. Dry-run purge test..."
just user --dry-run purge-user --email test-cleanup@example.com

echo "✅ All tests passed!"
```

### Automated Testing

The utility includes comprehensive unit tests:

**Run Tests:**
```bash
# Run user purge utility tests
just test unit backend -- tests/unit/scripts/user_purge/

# Run all backend tests
just test unit backend
```

**Test Coverage:**
- Environment detection and safety checks
- Database relationship discovery
- Transaction rollback on failure
- Production environment protection
- Audit logging functionality

---

## Related Documentation

- **[Backend Testing Guide](../backend/testing/)** - Testing patterns and utilities
- **[Database Access Guide](./database-access.md)** - Database operation procedures
- **[Environment Setup](../setup/environment-setup.md)** - Development environment configuration
- **[Security Implementation](../backend/architecture/security-implementation.md)** - Security patterns and practices

---

## Support and Troubleshooting

### Quick Reference Commands

```bash
# Check environment safety
just user check-env

# Find user information
just user show-user --email user@example.com

# Preview deletion (ALWAYS do this first)
just user --dry-run purge-user --email user@example.com

# Execute deletion
just user purge-user --email user@example.com

# Check audit log
just user audit-log --summary
```

### Common Command Patterns

```bash
# Safe deletion workflow
just user check-env && \
just user --verbose show-user --email user@example.com && \
just user --dry-run purge-user --email user@example.com && \
just user purge-user --email user@example.com

# Duplicate cleanup workflow
just user find-duplicates --criteria all --output detailed
# Review output, then purge specific duplicate IDs
just user --dry-run purge-user --id 456
just user purge-user --id 456
```

### Emergency Procedures

**If Deletion Fails Mid-Operation:**
1. Check audit log: `just user audit-log --tail 10`
2. Verify database consistency (transactions ensure safety)
3. Investigate error details in verbose log output
4. Contact database administrator if foreign key issues persist

**If Wrong User Deleted:**
1. **Stop immediately** - no further deletions
2. Check audit log for complete operation details
3. Database backups are the only recovery option
4. Implement additional confirmation procedures

---

## Best Practices

### Before Any Deletion
1. **Environment Check**: Always verify you're in the correct environment
2. **User Verification**: Confirm user identity and necessity of deletion
3. **Impact Analysis**: Review related record counts and relationships
4. **Dry Run**: ALWAYS use `--dry-run` to preview changes
5. **Backup Verification**: Ensure recent database backups exist

### During Deletion
1. **Monitor Progress**: Use `--verbose` for important operations
2. **Review Output**: Check all deletion steps complete successfully
3. **Verify Completion**: Confirm user no longer exists in database
4. **Audit Log**: Review audit log for operation summary

### After Deletion
1. **Verification**: Attempt to show deleted user (should fail)
2. **Relationship Check**: Verify no orphaned records remain
3. **Audit Review**: Review audit log for complete operation record
4. **Documentation**: Document deletion in compliance records if required

---

**Last Updated:** 2025-08-04
**Status:** Current
**Version:** 1.0.0
