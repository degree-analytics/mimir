# Layout Migration Guide

Step-by-step guide for migrating pages to AdminLayout.

## Overview

This guide helps you migrate existing admin pages to use the new AdminLayout component for consistent UI and improved user experience.

## Migration Steps

### 1. Identify Legacy Pages
- Pages not using AdminLayout
- Inconsistent navigation or styling
- Custom layout implementations

### 2. Update Component Structure
Replace legacy layout with AdminLayout wrapper:

```tsx
// Before
const MyPage = () => {
  return (
    <div className="custom-layout">
      {/* custom navigation */}
      <main>{/* content */}</main>
    </div>
  );
};

// After
import { AdminLayout } from '../components/AdminLayout';

const MyPage = () => {
  return (
    <AdminLayout>
      {/* content */}
    </AdminLayout>
  );
};
```

### 3. Update Navigation
Ensure navigation items are properly configured in AdminLayout.

### 4. Test Migration
- Verify responsive design
- Check cross-browser compatibility
- Test navigation functionality

## Testing Procedures
See [Testing Guide](./testing-guide.md) for comprehensive testing steps.

## Architecture Reference
See [Admin Container Architecture](../admin/architecture/admin-container-architecture.md) for detailed architectural information.
