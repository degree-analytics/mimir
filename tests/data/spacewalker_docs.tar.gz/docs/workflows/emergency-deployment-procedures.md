# Emergency Deployment Procedures

## Purpose
This document outlines emergency deployment procedures for SpaceWalker, including when and how to use deployment escape hatches like `SKIP_MIGRATION_CHECK`. These procedures should only be used in critical situations where standard deployment processes would cause extended downtime or prevent critical fixes from being deployed.

**Version:** 1.0
**Date:** 2025-08-12
**Status:** Active

---

## 🚨 Emergency Deployment Escape Hatches

### SKIP_MIGRATION_CHECK

#### What It Is
An emergency override that bypasses database migration validation during ECS deployments. When set to `true`, the deployment will proceed without verifying that database migrations match the code being deployed.

#### When to Use

##### 1. **Circuit Breaker Rollback Recovery**
**Scenario:** ECS automatically rolled back to a previous task definition, but the database already has the new migration applied.

**Symptoms:**
- Deployment fails with "migration mismatch" error
- Database has migration X, but rolled-back code expects migration X-1
- Need to redeploy the correct (newer) code version

**Example:**
```bash
# Deployment timeline:
1. Deploy v2.0 with migration ABC → Success
2. Container crashes due to memory issue
3. ECS circuit breaker triggers rollback to v1.9
4. Attempt to redeploy v2.0 fails (DB already has ABC)
5. Use SKIP_MIGRATION_CHECK to force correct deployment
```

##### 2. **Critical Production Hotfix**
**Scenario:** Production is experiencing an outage and the fix is unrelated to database schema.

**When appropriate:**
- Fix involves only code changes (no DB schema changes)
- Every second of downtime matters
- Migration validation adds 30-60 seconds to deployment
- Risk of skipping validation is lower than cost of extended outage

**Example:**
```bash
# Rate limiter misconfiguration causing 500 errors
# Fix: Update environment variable only
# Database: Completely unaffected
```

##### 3. **Manual Migration Execution**
**Scenario:** Large or complex migrations that must be run manually during a maintenance window.

**Common cases:**
- Migrations that take hours (e.g., adding large indexes)
- Migrations requiring special privileges
- Multi-step migrations with manual verification between steps
- Migrations that require application downtime

**Example:**
```bash
# 2-hour migration adding 10GB index
1. Put app in maintenance mode
2. Run migration manually via bastion host
3. Verify migration completed successfully
4. Deploy new code with SKIP_MIGRATION_CHECK
5. Exit maintenance mode
```

##### 4. **Broken Migration File Recovery**
**Scenario:** Migration file is corrupted, deleted, or has syntax errors, but database is already in correct state.

**Temporary use while:**
- Recreating missing migration file
- Fixing syntax errors in migration script
- Resolving git merge conflicts in migration files
- Database state is known to be correct

##### 5. **Cross-Region Deployments**
**Scenario:** Deploying to regions with read-only database replicas.

**Applies when:**
- Primary region has master database
- Secondary regions have read replicas
- Migrations can only run against master
- Code needs to deploy to all regions

#### When NOT to Use

**Never use SKIP_MIGRATION_CHECK for:**
- Regular deployments
- "Just to save time"
- When you're unsure if migrations are needed
- To bypass failed migrations (fix the migration instead)
- As a permanent solution to any problem

#### How to Use

##### Via Justfile (Preferred - Logged and Audited)
```bash
# Emergency deployment with migration check bypass
just aws deploy backend dev --skip-migration-check

# Deploy all services with bypass
just aws deploy all prod --skip-migration-check
```

##### Via Environment Variable (CI/CD)
```yaml
# In GitHub Actions or other CI systems
env:
  SKIP_MIGRATION_CHECK: "true"  # Document reason in commit/PR
```

##### Direct Script Call (Last Resort)
```bash
# Only when justfile is unavailable
SKIP_MIGRATION_CHECK=true bash scripts/deployment/force-ecs-deployment.sh dev backend
```

#### Required Documentation

When using SKIP_MIGRATION_CHECK, you MUST:

1. **Document in deployment notes:**
   ```markdown
   Emergency Deployment - [Date/Time]
   Reason: [Circuit breaker recovery / Hotfix / Manual migration / etc.]
   Environment: [dev/staging/prod]
   Services: [backend/admin/all]
   Migration Status: [Already applied / Not needed / Will apply separately]
   Deployed By: [Your name]
   Ticket: [Link to incident/issue]
   ```

2. **Create or update incident ticket:**
   - Link to deployment
   - Explain why override was necessary
   - Plan for resolution (if temporary)

3. **Notify team:**
   - Post in #deployments Slack channel
   - Mention in next standup
   - Add to sprint retrospective if pattern emerges

4. **Monitor post-deployment:**
   - Watch error rates
   - Check database consistency
   - Verify application functionality

#### Audit Trail

All uses of SKIP_MIGRATION_CHECK are automatically logged:

1. **Script output** shows:
   ```
   ⚠️  Migration validation skipped (emergency override)
   🚨 EMERGENCY OVERRIDE ACTIVE - This should be documented!
   📝 Please ensure this emergency deployment is logged
   ⏰ Timestamp: 2025-08-12 15:30:00 UTC
   👤 User: chad.walters
   🌍 Environment: prod
   ```

2. **Exit code 2** (vs 0 for normal success) enables monitoring

3. **CloudWatch logs** capture full context

4. **Deployment tracking** in ECS shows environment variables

---

## 📋 Emergency Deployment Checklist

### Before Emergency Deployment
- [ ] Confirm this is truly an emergency
- [ ] Verify which escape hatches are needed
- [ ] Document reason for emergency procedure
- [ ] Notify team of emergency deployment starting

### During Emergency Deployment
- [ ] Use appropriate escape hatch flags
- [ ] Monitor deployment progress closely
- [ ] Be ready to rollback if issues arise
- [ ] Keep team updated on progress

### After Emergency Deployment
- [ ] Verify application functionality
- [ ] Check error rates and metrics
- [ ] Document in incident report
- [ ] Create follow-up tickets if needed
- [ ] Schedule retrospective if appropriate

---

## 🔄 Recovery Procedures

### After Using SKIP_MIGRATION_CHECK

1. **Verify database state:**
   ```bash
   # Check current migration in database
   just db shell
   SELECT version_num FROM alembic_version;
   ```

2. **Compare with code expectations:**
   ```bash
   # Check latest migration in codebase
   ls -la apps/backend/migrations/versions/ | tail -1
   ```

3. **Run validation manually:**
   ```bash
   # Validate migrations are now in sync
   just migrations validate dev
   ```

4. **Document resolution:**
   - Update incident ticket
   - Note when normal deployment process resumed
   - Add lessons learned

---

## 📊 Monitoring and Alerting

### Escape Hatch Usage Alerts

Configure alerts for:
- Exit code 2 from deployment scripts (indicates override used)
- Log pattern: "EMERGENCY OVERRIDE ACTIVE"
- Environment variable: SKIP_MIGRATION_CHECK=true

### Post-Emergency Monitoring

Enhanced monitoring for 24 hours after emergency deployment:
- Error rate thresholds lowered by 50%
- Database query performance
- Migration state consistency
- Application health checks

---

## 🚫 Anti-Patterns to Avoid

1. **Using escape hatches as standard practice**
   - If you need them frequently, fix the underlying issue

2. **Not documenting emergency deployments**
   - Creates confusion and trust issues

3. **Skipping post-deployment verification**
   - Emergency deployments need MORE monitoring, not less

4. **Not following up after emergency**
   - Always conduct retrospective
   - Fix root cause to prevent recurrence

---

## 📚 Related Documentation

- [Database Migration Guide](../backend/database-migrations.md)
- [Deployment Verification Integration](./deployment-verification-integration.md)
- [AWS Deployment Guide](./aws-deployment-guide.md)
- [Troubleshooting Guide](./troubleshooting-guide.md)
- [Database Migration Debugging](./database-migration-debugging.md)

---

## 📝 Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2025-08-12 | System | Initial documentation of emergency procedures |