# 📚 Documentation Search Guide

## Quick Start

**Find information fast with AI-powered search:**

> 📦 **Setup**: Run `just install target=tooling` (or `just install`) once to install the Mímir CLI extras.

```bash
# Fast semantic search (free, <1 second)
just docs search "deployment guide"

# AI-enhanced search (comprehensive, ~$0.004, 4-7 seconds)
just docs search "deployment best practices" --mode llm

# AI question answering (~$0.002, 2-4 seconds)
just docs ask "How do I deploy Spacewalker to AWS?"
```

## Search Commands Overview

| Command | Speed | Cost | Best For |
|---------|--------|------|----------|
| `just docs search "keyword"` | <1s | Free | Quick lookups, known topics |
| `just docs search "topic" --mode llm` | 4-7s | ~$0.004 | Research, complex topics |
| `just docs ask "How do I...?"` | 2-4s | ~$0.002 | Specific questions, troubleshooting |

## Search Modes Explained

### 🚀 **Smart Mode (Default - Recommended)**
```bash
just docs search "authentication"
# Uses: TF-IDF + semantic search
# Speed: ~1ms
# Cost: Free
# Best for: Most searches, balanced speed + accuracy
```

### ⚡ **Fast Mode**
```bash
just docs search "JWT" --mode fast
# Uses: TF-IDF keyword matching only
# Speed: <1ms
# Cost: Free
# Best for: Exact keyword matches, maximum speed
```

### 🧠 **LLM Mode (AI-Enhanced)**
```bash
just docs search "deployment best practices" --mode llm
# Uses: Query expansion + document analysis + metadata tagging
# Speed: 4-7 seconds
# Cost: ~$0.004 per search
# Best for: Complex research, comprehensive results
```

**LLM Mode Features:**
- **Query Expansion**: `"deployment"` → `"deployment, CI/CD, DevOps, release management..."`
- **Document Analysis**: Adds `"Difficulty: intermediate"`, `"Type: guide"`
- **Enhanced Descriptions**: AI-generated summaries and insights
- **Better Relevance**: Understands context and intent

## AI Question Answering

### 🤖 **Ask Command**
```bash
just docs ask "What are the steps to deploy to production?"
```

**What it does:**
1. Searches documentation for relevant context
2. Uses up to 5 most relevant documents
3. Generates conversational answer based on YOUR docs
4. Honest responses: "documentation doesn't contain..." when info missing

**Perfect for:**
- "How do I...?" questions
- Troubleshooting: "Why is my deployment failing?"
- Configuration: "What environment variables do I need?"
- Workflows: "What's the order of operations for...?"

## Advanced Usage

### **Output Formats**
```bash
# Human-readable (default)
just docs search "deployment"

# JSON for scripts
just docs search "deployment" --format json

# File paths only
just docs search "deployment" --format paths

# LLM-optimized JSON
just docs search "deployment" --format llm
```

### **Limiting Results**
```bash
# Get more results
just docs search "authentication" --limit 20

# Quick top results
just docs search "deployment" --limit 3
```

### **Verbose Output**
```bash
# See search details and performance
just docs search "deployment" --verbose
just docs ask "How do I deploy?" --verbose
```

## When to Use Each Approach

### 📋 **Decision Tree**

**Quick Reference Lookup**
- Known terminology, specific files
- → `just docs search "keyword"`

**Comprehensive Research**
- Complex topics, need full picture
- → `just docs search "topic" --mode llm`

**Specific Questions**
- How-to questions, troubleshooting
- → `just docs ask "How do I...?"`

**Multiple Related Searches**
- Use smart mode first, then LLM mode for promising results
- → `just docs search "deployment"` → `just docs search "deployment best practices" --mode llm`

## Cost Management

### **Daily Usage Estimates**
- **Smart searches**: Unlimited free use
- **LLM searches**: ~$0.004 each (~250 searches = $1.00)
- **AI questions**: ~$0.002 each (~500 questions = $1.00)

### **Cost-Effective Workflow**
1. Start with **smart search** (free) for initial exploration
2. Use **LLM search** for 1-2 most promising topics
3. Use **ask** for specific implementation questions

## Examples by Use Case

### **New Developer Onboarding**
```bash
just docs search "getting started"
just docs ask "How do I set up my development environment?"
just docs search "authentication setup" --mode llm
```

### **Deployment Research**
```bash
just docs search "deployment"  # Quick overview
just docs search "AWS deployment guide" --mode llm  # Comprehensive
just docs ask "What are the deployment prerequisites?"
```

### **Troubleshooting**
```bash
just docs search "error 500"
just docs ask "Why is my authentication failing?"
just docs search "troubleshooting guide" --mode llm
```

### **Architecture Understanding**
```bash
just docs search "architecture"
just docs ask "How does the authentication system work?"
just docs search "security architecture" --mode llm
```

## Integration with Other Tools

### **Ground Truth Verification**
```bash
/ground-truth "JWT authentication"
# Uses: just docs search "JWT authentication" --mode llm --format llm
```

### **Linear Ticket Creation**
```bash
# Research before creating tickets
just docs search "known issues" --mode llm
just docs ask "Are there any known issues with deployment?"
```

### **PR Development**
```bash
# Understanding existing patterns
just docs search "API security patterns" --mode llm
just docs ask "What's the standard authentication flow?"
```

## Performance & Monitoring

### **Search Performance**
All searches are monitored in our Grafana dashboards:
- **Response times**: Track search performance
- **Cost tracking**: Monitor AI usage costs
- **Success rates**: Ensure high availability
- **Usage patterns**: Understand most common searches

### **Index Management**
```bash
# Build/rebuild search index
just docs index

# Check search system status
just docs status
```

The search index is automatically updated when documentation changes.

## Tips for Better Results

### **Smart Search Tips**
- Use specific terms: `"JWT token"` vs `"authentication"`
- Include context: `"React authentication"` vs `"authentication"`
- Try synonyms: `"deploy"` vs `"deployment"` vs `"release"`

### **LLM Search Tips**
- Use natural language: `"deployment best practices"`
- Be specific: `"AWS ECS deployment"` vs `"deployment"`
- Include intent: `"troubleshooting deployment failures"`

### **AI Question Tips**
- Ask specific questions: `"How do I configure JWT?"`
- Include context: `"How do I deploy to production environment?"`
- Be conversational: `"What environment variables do I need for development?"`

## Getting Help

### **Command Help**
```bash
just docs help                    # General docs help
just docs search --help           # Search options
just docs ask --help              # Question answering options
```

### **Status & Diagnostics**
```bash
just docs status                  # Search system health
just docs status --stats          # Detailed statistics
```

---

**💡 Pro Tip**: Start with smart search for exploration, then use LLM search for deep research, and ask specific questions for implementation guidance!
