# Operational Workflows

## Purpose
Operational workflows and process documentation for Spacewalker development, deployment, and maintenance. Essential reference for development workflows, deployment procedures, testing strategies, and operational processes.

## When to Use This
- Understanding development workflows and operational procedures
- Learning deployment and testing strategies
- Troubleshooting development and production issues
- Following git workflows and commit standards
- Keywords: operational workflows, deployment procedures, testing strategies, development processes

**Version:** 2.0
**Date:** 2025-06-29
**Status:** Current - Focused Operational Workflows

---

Spacewalker is a comprehensive room survey management system designed for universities and large organizations to efficiently catalog and manage their physical spaces. This directory contains operational workflows that support the development, deployment, and maintenance of the system.

## Who Uses These Workflows?

Choose your workflow based on what you want to accomplish:

### 🔧 **Development Workflows**
Daily development process documentation:
- **[Git Commit Standards](./git-commit-standards.md)** - Professional commit standards and formatting guidelines ⭐
- **[Git Merge Strategy](./git-merge-strategy.md)** - Branching and merging workflows
- **[Graphite Workflows](./graphite-workflows.md)** - Stack-based development with GT CLI for professional PR workflows ⭐

### 🚀 **Deployment & Operations**
Infrastructure and deployment procedures:
- **[Deployment Guide](../workflows/deployment-guide.md)** - Multi-environment deployment strategies ⭐
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Production deployment procedures ⭐
- **[Smart Build Triggering](./smart-build-triggering.md)** - Intelligent build optimization saving 43min/build ⭐ NEW
- **[Build Metrics Dashboard](./build-metrics-dashboard.md)** - GitHub Pages dashboard for build metrics ⭐ NEW
- **[Database Access](./database-access.md)** - Secure database operations
- **[Demo Data Management](./demo-data-management.md)** - Safe demo data procedures

### 🧪 **Testing & Quality**
Testing strategies and quality assurance:
- **[Testing Guide](./testing-guide.md)** - Comprehensive testing strategies ⭐
- **[Testing Strategy](../workflows/testing-strategy.md)** - Framework-specific testing approaches

### 🛠️ **Workflow Automation**
Intelligent development automation:
- **[Enhanced Workflows](./enhanced-workflows.md)** - Professional-grade workflow automation
- **[Slack CI Notifications](./slack-ci-notifications.md)** - Configure reusable Slack alerts for CI outcomes ⭐ NEW

### 🔧 **Troubleshooting & Support**
Problem resolution procedures:
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Systematic problem resolution ⭐

## Workflow Overview

These operational workflows support the complete Spacewalker development and deployment lifecycle:

### 🔄 Development Lifecycle
1. **Development** → Git workflows for consistent commits and branching
2. **Testing** → Comprehensive testing strategies across all platforms
3. **Deployment** → Automated deployment to multiple environments
4. **Operations** → Database management and demo data procedures
5. **Troubleshooting** → Systematic problem resolution

### 🛠️ Key Workflow Categories

| Workflow Type | Purpose | Key Documents |
|---------------|---------|---------------|
| **Development** | Daily coding workflows | Git standards, merge strategies, Graphite workflows |
| **Testing** | Quality assurance | Testing guide, testing strategy |
| **Deployment** | Infrastructure deployment | AWS deployment, multi-environment |
| **Operations** | Ongoing maintenance | Database access, data management |
| **Support** | Issue resolution | Troubleshooting guide, diagnostics |

### 🔄 Workflow Integration

```mermaid
graph LR
    Dev[Development<br/>Git Workflows] --> Test[Testing<br/>Quality Assurance]
    Test --> Deploy[Deployment<br/>Infrastructure]
    Deploy --> Ops[Operations<br/>Maintenance]
    Ops --> Support[Support<br/>Troubleshooting]
    Support --> Dev

    classDef workflow fill:#E3F2FD,stroke:#1976D2,color:#000000
    class Dev,Test,Deploy,Ops,Support workflow
```

## Quick Navigation

### Application Documentation
For system architecture and component-specific development:
- **[Product Documentation](../product/)** - Business context and requirements
- **[System Architecture](../architecture/)** - Technical architecture and design
- **[Environment Setup](../setup/)** - Initial setup and configuration
- **[Development Reference](../development/)** - Development tools and project structure

### Component Development
- **[Backend Development](../backend/)** - API development and deployment
- **[Mobile Development](../mobile/)** - React Native development
- **[Admin Development](../admin/)** - Web application setup

### Issue Resolution
- **[Common Gotchas](../gotchas/)** - Development-specific issues and solutions

## Prerequisites

To execute these workflows:
- Node.js `v20.19.4` (see `.nvmrc`)
- Python `3.11+`
- PostgreSQL `14+`
- Redis
- `just` command runner
- Docker and Docker Compose

## Getting Started with Workflows

### For Development Teams
1. **[Git Commit Standards](./git-commit-standards.md)** - Learn commit conventions
2. **[Graphite Workflows](./graphite-workflows.md)** - Stack-based development workflows
3. **[Testing Guide](./testing-guide.md)** - Understand testing approaches
4. **[Troubleshooting Guide](./troubleshooting-guide.md)** - Problem resolution

### For DevOps Teams
1. **[Deployment Guide](../workflows/deployment-guide.md)** - Deployment strategies
2. **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Production deployment
3. **[Database Access](./database-access.md)** - Database operations

### For QA Teams
1. **[Testing Guide](./testing-guide.md)** - Testing workflows
2. **[Testing Strategy](../workflows/testing-strategy.md)** - Testing approaches
3. **[Enhanced Workflows](./enhanced-workflows.md)** - Automation

## Support and Contribution

### Getting Help
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Common workflow issues and solutions
- **[Development Issues](../gotchas/)** - Known pitfalls and workarounds

### Contributing to Workflows
- **[Git Commit Standards](./git-commit-standards.md)** - How to contribute workflow improvements
- **[Git Merge Strategy](../workflows/git-merge-strategy.md)** - Workflow contribution process

---

**Documentation Status**: ✅ Updated and current as of 2025-06-29. Reorganized to focus on operational workflows and processes.
