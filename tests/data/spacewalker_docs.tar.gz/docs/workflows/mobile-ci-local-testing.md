# Mobile CI/CD Local Testing Guide

## Purpose

This guide explains how to test the mobile CI/CD workflow locally before pushing changes to GitHub. This helps catch issues early and reduces failed CI builds.

## When to Use This

- Before pushing mobile-related changes that trigger CI builds
- When testing new EAS build configurations
- When debugging CI/CD workflow issues
- When verifying justfile CI commands work correctly

## Prerequisites

1. EAS CLI installed: `npm install -g eas-cli`
2. EXPO_TOKEN configured: `export EXPO_TOKEN=your-token-here`
3. Valid EAS project configuration in `apps/mobile/eas.json`

## Local Testing Commands

### 1. Test CI Build Workflow (Dry Run)

Simulate what would happen in CI without actually triggering a build:

```bash
# Test mobile unit tests locally
just test unit mobile

# For build simulation, use EAS directly:
# cd apps/mobile && eas build --profile development --non-interactive --no-wait
```

This command:
- Simulates CI environment variables
- Shows exactly what commands would run
- Validates configuration without consuming build minutes

### 2. Run Actual CI Build Locally

Trigger a real EAS build from your local machine:

```bash
# Trigger development build
cd apps/mobile && eas build --profile development --non-interactive --no-wait

# Trigger preview build
cd apps/mobile && eas build --profile preview --non-interactive --no-wait

# Trigger production build (requires proper credentials)
cd apps/mobile && eas build --profile production --non-interactive --no-wait
```

### 3. Check Build Status

Monitor the status of running builds:

```bash
# Check current builds
just mobile_ci_status
```

### 4. Test Mobile Unit Tests in CI Mode

Run tests exactly as they would run in CI:

```bash
just test unit mobile
```

This runs tests with:
- Coverage enabled
- No watch mode
- CI-optimized output

## Testing the Full Workflow

To test the complete CI workflow locally:

1. **Verify Configuration**
   ```bash
   cd apps/mobile
   eas whoami  # Verify authentication
   eas project:info  # Verify project setup
   ```

2. **Test Build Trigger (Dry Run)**
   ```bash
   # For build simulation:
   cd apps/mobile && eas build --profile development --non-interactive --no-wait --json
   ```

3. **Run Tests in CI Mode**
   ```bash
   just test unit mobile
   ```

4. **Trigger Actual Build** (if dry run passes)
   ```bash
   cd apps/mobile && eas build --profile development --non-interactive --no-wait
   ```

5. **Monitor Build Progress**
   ```bash
   just mobile_ci_status
   ```

## Environment Variables

The CI commands automatically simulate these environment variables when running locally:
- `CI=true` - Indicates CI environment
- `GITHUB_ACTIONS=true` - Simulates GitHub Actions environment

Your `EXPO_TOKEN` must be set for authentication to work.

## Debugging Common Issues

### Authentication Errors
```bash
# Verify token is set
echo $EXPO_TOKEN

# Re-authenticate
eas login
```

### Build Configuration Issues
```bash
# Validate eas.json
cd apps/mobile
cat eas.json | jq .

# Check specific profile
cat eas.json | jq '.build.development'
```

### Network or Proxy Issues
```bash
# Test EAS connectivity
eas diagnostics
```

## CI Environment Differences

When running locally vs CI:
1. **Local**: Uses your personal Expo account credentials
2. **CI**: Uses service account via EXPO_TOKEN
3. **Local**: May have different network access
4. **CI**: Runs on GitHub-hosted runners with specific permissions

## Best Practices

1. **Always Test Dry Run First**
   ```bash
   # Test with: cd apps/mobile && eas build --profile <profile> --non-interactive --no-wait --json
   ```

2. **Verify Credentials**
   - Ensure EXPO_TOKEN is valid
   - Check EAS project access

3. **Use Development Profile for Testing**
   - Faster builds
   - Doesn't require production credentials

4. **Monitor Resource Usage**
   - EAS builds count against your quota
   - Cancel unnecessary builds promptly

## Troubleshooting Workflow Failures

If the GitHub Actions workflow fails:

1. **Check Workflow Logs**
   ```bash
   gh run list --workflow=eas-build.yml
   gh run view <run-id>
   ```

2. **Test Locally with Same Profile**
   ```bash
   cd apps/mobile && eas build --profile <profile-that-failed> --non-interactive --no-wait
   ```

3. **Verify Secrets**
   - Ensure EXPO_TOKEN is set in GitHub secrets
   - Check token hasn't expired

## Related Documentation

- [EAS Build Workflow](.github/workflows/eas-build.yml)
- [GitHub Actions Configuration](../mobile/deployment/github-actions-config.md)
- [EAS Build Documentation](https://docs.expo.dev/build/introduction/)