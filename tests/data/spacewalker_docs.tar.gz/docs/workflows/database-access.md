# Database Access Workflows

## Purpose
Comprehensive operational workflow documentation for secure database access in the Spacewalker system using bastion hosts, SSH tunneling, and AWS infrastructure. Essential reference for developers, DevOps engineers, and support staff requiring secure database access for development, debugging, and troubleshooting operations.

## When to Use This
- Accessing production or staging databases for debugging and troubleshooting
- Performing database migration debugging and status checks
- Setting up secure development database connections
- Troubleshooting database connectivity and performance issues
- Managing database access through AWS infrastructure and security controls
- Keywords: database access, bastion host, SSH tunnel, AWS Secrets Manager, secure database connection

**Version:** 3.0 (Major security and functionality overhaul)
**Date:** 2025-07-03
**Status:** Current - Enhanced Production Database Access Workflows

---

## 🚀 Quick Start Workflows

### Direct Database Access (New Unified Commands)
```bash
# Interactive shell access
just db shell              # Local environment
just db shell dev          # Development
just db shell prod         # Production (interactive shell, requires caution)

# Execute SQL queries
just sql "SELECT * FROM users LIMIT 5"
just sql "SELECT COUNT(*) FROM buildings" dev
just sql "SELECT * FROM tenants" --format=json
just sql "UPDATE users SET active=true WHERE id='123'" dev --write
```
**Benefits:**
- Simple, direct database access
- Read-only by default (requires --write flag for modifications)
- Multiple output formats (text, json, csv)
- Environment-aware with automatic credential handling

**⚠️ SECURITY WARNINGS:**
- Direct SQL access bypasses Row Level Security (RLS) and tenant isolation
- Production writes require explicit --write flag but lack additional confirmation
- Be extremely cautious with production database access
- Always verify tenant context when querying multi-tenant data

### Option 1: One-Shot Connection (Legacy)
```bash
# Development
just db_quick_connect dev

# Production (requires prod_enable)
just prod enable --minutes=30
just db_quick_connect prod
```
**Benefits:**
- Automatically creates tunnel and connects to database
- Single command for immediate access
- Handles all credential management automatically
- Perfect for quick debugging sessions

### Option 2: Manual Tunnel (For Persistent Access)
```bash
# Terminal 1: Create persistent tunnel (keep this terminal open)
just db_tunnel dev      # Development
just db_tunnel prod     # Production

# Terminal 2: Connect to database through existing tunnel
just db_connect dev     # Development
just db_connect prod    # Production
```
**Benefits:**
- Persistent tunnel for multiple connections
- Better for extended debugging sessions
- Allows multiple database clients to connect
- More control over connection lifecycle

---

## 🧪 Comprehensive Database Command Reference

### Pre-Access Validation & Testing

| Command | Purpose | Use Case |
|---------|---------|----------|
| `just db_test [env]` | Full connectivity test with tunnel validation | Complete system validation before work |
| `just db_test_quick [env]` | Prerequisites-only test (no connectivity) | Quick validation of AWS access and keys |

**Example:**
```bash
# Full validation including live database connection test
just db_test dev

# Quick validation of AWS credentials and SSH keys only
just db_test_quick staging
```

### Core Database Access Commands

| Command | Purpose | Use Case |
|---------|---------|----------|
| `just db_quick_connect [env]` | Auto tunnel + connect (easiest) | Quick debugging sessions |
| `just db_quick_connect_interactive [env]` | Auto tunnel + interactive psql | Extended database work |
| `just db_tunnel [env] [port]` | Smart tunnel (bg in CLI, fg in terminal) | Persistent access sessions |
| `just db_tunnel_background [env] [port]` | Force background tunnel | Scripted operations |
| `just db_connect [env] [port]` | Connect via existing tunnel | Multiple client connections |
| `just db_connect_interactive [env] [port]` | Interactive psql via tunnel | SQL session work |

**Example Workflows:**
```bash
# Quick one-shot database access (most common)
just db_quick_connect dev

# Persistent tunnel for multiple operations
just db_tunnel dev 5432
just db_connect dev 5432

# Interactive SQL session
just db_quick_connect_interactive dev
```

### SSH & Bastion Host Access

| Command | Purpose | Use Case |
|---------|---------|----------|
| `just bastion_ssh [env]` | SSH to bastion host | Advanced debugging and diagnostics |
| `just bastion_ssh_interactive [env]` | Optimized interactive SSH session | Terminal-based operations |

### Database Migration & Status Commands

| Command | Purpose | Use Case |
|---------|---------|----------|
| `just db_migration_status [env] [port]` | Check migration status via tunnel | Schema troubleshooting |
| `just db_migration_status_quick [env]` | Auto-tunnel migration check | Quick migration validation |
| `just db_migration_history [env]` | Detailed migration and schema info | Comprehensive database analysis |

**Migration Troubleshooting:**
```bash
# Quick migration status check
just db_migration_status_quick dev

# Detailed migration history and database info
just db_migration_history dev

# Manual migration debugging
just db_quick_connect_interactive dev
# SQL: SELECT * FROM alembic_version;
```

### Tunnel Management & Cleanup

| Command | Purpose | Use Case |
|---------|---------|----------|
| `just db_kill_tunnels [env]` | Kill all SSH tunnels to database | Clean up connection issues |

### Environment Support

All commands support environment parameters:
- `dev` (default) - Development environment (us-east-2, default profile)
- `staging` - Staging environment
- `prod` - Production environment (us-east-1, production profile, requires `prod_enable`)

**Production Access Requirements:**
```bash
# Enable production mode first
just prod enable --minutes=30

# Grant bastion access
just bastion allow prod --hours=8

# Now database commands work
just db_quick_connect prod
```

**Security Features:**
- 🔒 **Enhanced SSH Security**: `StrictHostKeyChecking=accept-new` with environment-specific known_hosts
- 🛡️ **Input Validation**: Port ranges (1024-65535) and environment name validation
- 🔄 **Race Condition Prevention**: Automatic port detection and retry logic
- 💾 **Credential Caching**: Reduced AWS API calls with secure session caching

---

## 🔧 Infrastructure Architecture

### Database Access Flow
```
Developer → AWS CLI → SSH Tunnel → Bastion Host → RDS Database
    ↓           ↓          ↓             ↓            ↓
Local Client → Secrets → SSH Key → Security Group → PostgreSQL
    ↓           ↓          ↓             ↓            ↓
PostgreSQL → Credentials → Tunnel → Private Subnet → Database Access
```

### Security Components

#### Credential Management
- **AWS Secrets Manager**: `AURORA/dev-spacewalker` secret contains database credentials
- **Automatic Rotation**: Supports credential rotation without service interruption
- **Zero Hardcoded Secrets**: All credentials fetched securely from AWS at runtime

#### Network Security
- **Bastion Host**: t4g.nano EC2 instance in public subnet with restricted access
- **IP-Restricted SSH**: Bastion only accepts connections from authorized IP addresses
- **Security Group Isolation**: Database accepts connections only from bastion host
- **Private Subnet**: Database deployed in private subnet with no direct internet access

#### Authentication Requirements
- **SSH Key**: `~/.ssh/dev-spacewalker-key.pem` must exist and have proper permissions
- **AWS CLI**: Configured with appropriate IAM permissions for Secrets Manager and CloudFormation
- **PostgreSQL Client**: Local `psql` command must be available

---

## 🛠️ Database Migration Troubleshooting

### Migration Status Diagnostics

#### Check Migration Status
```bash
# Comprehensive migration status check
just db_migration_status

# Output includes:
# - Current Alembic version
# - Pending migrations
# - Advisory locks status
# - Migration history
```

#### Manual Migration Debugging
```bash
# Connect to database for manual inspection
just db_connect

# Check current migration version
SELECT * FROM alembic_version;

# Check for blocking advisory locks
SELECT * FROM pg_locks WHERE locktype = 'advisory';

# View migration history
SELECT * FROM information_schema.tables WHERE table_name LIKE 'alembic%';
```

### Common Migration Issues and Solutions

#### Issue: Migration Stuck or Locked
```bash
# 1. Check for advisory locks
just db_connect
# SQL: SELECT * FROM pg_locks WHERE locktype = 'advisory';

# 2. If locks exist, identify blocking processes
# SQL: SELECT pid, state, query FROM pg_stat_activity WHERE state = 'active';

# 3. Clear locks if safe (be very careful in production)
# SQL: SELECT pg_advisory_unlock_all();
```

#### Issue: Migration Version Mismatch
```bash
# 1. Check current version vs expected version
just db_migration_status

# 2. View available migrations on filesystem
just backend_shell
# Inside container: ls -la /app/alembic/versions/

# 3. Manually run specific migration if needed
# Inside container: alembic upgrade <revision_id>
```

### Advanced Debugging via Bastion Host

#### Direct Bastion Access
```bash
# SSH directly to bastion host for advanced debugging
just bastion_ssh

# Bastion host includes:
# - PostgreSQL client pre-installed
# - Direct network access to RDS instance
# - AWS CLI configured with appropriate permissions
# - Debugging tools and utilities
```

#### Bastion Host Capabilities
- **PostgreSQL Client**: Full `psql` client with all extensions
- **Network Diagnostics**: `netcat`, `telnet`, `ping` for connectivity testing
- **AWS Tools**: AWS CLI for Secrets Manager and CloudFormation access
- **Log Analysis**: Access to system logs and connection diagnostics

---

## 📋 Environment Connection Details

### Development Environment Configuration
- **Environment**: `dev`
- **Database Host**: `dev-spacewalker-db.c32g4gicaiw9.us-east-2.rds.amazonaws.com`
- **Database Name**: `spacewalker`
- **Username**: `spacewalker_user` (retrieved from Secrets Manager)
- **Port**: `5432` (PostgreSQL default)

### Infrastructure Components
- **Bastion Host**: Auto-discovered from CloudFormation stack outputs
- **Security Group**: Database access restricted to bastion host only
- **Secrets Manager**: `AURORA/dev-spacewalker` contains all database credentials
- **CloudFormation**: Infrastructure auto-deployed via foundation stack

### Connection Workflow Details
1. **Credential Retrieval**: AWS Secrets Manager provides database credentials
2. **Bastion Discovery**: CloudFormation stack outputs provide bastion host IP
3. **SSH Tunnel**: Secure tunnel created from local machine to bastion host
4. **Database Connection**: PostgreSQL connection established through tunnel

---

## 🔒 Security Best Practices

### Access Control Security
- **No Hardcoded Credentials**: All sensitive values retrieved from AWS Secrets Manager
- **IP-Restricted Access**: Bastion host only accepts connections from authorized IP ranges
- **Least Privilege IAM**: Database access requires specific IAM permissions for Secrets Manager
- **Audit Logging**: All database access logged through CloudTrail and VPC Flow Logs

### Connection Security
- **SSH Key Management**: Private SSH keys stored securely and never transmitted
- **Encrypted Tunnels**: All database traffic encrypted through SSH tunnel
- **Session Management**: Connections automatically terminated on tunnel closure
- **Credential Rotation**: Support for automatic credential rotation via Secrets Manager

### Operational Security
- **Tunnel Cleanup**: Automatic cleanup of SSH tunnels on connection termination
- **Session Timeouts**: Database connections subject to idle timeout policies
- **Access Monitoring**: Database access monitored and logged for security auditing
- **Network Isolation**: Database isolated in private subnet with no direct internet access

---

## 💡 Prerequisites and Setup

### Required Tools and Access

#### Local Development Tools
```bash
# Verify required tools are installed
which aws        # AWS CLI v2
which psql       # PostgreSQL client
which ssh        # SSH client
which python3    # Python 3.8+
```

#### AWS Configuration
```bash
# Verify AWS CLI configuration
aws sts get-caller-identity

# Test Secrets Manager access
aws secretsmanager describe-secret --secret-id AURORA/dev-spacewalker

# Test CloudFormation access
aws cloudformation describe-stacks --stack-name dev-spacewalker-foundation
```

#### SSH Key Setup
```bash
# Verify SSH key exists and has correct permissions
ls -la ~/.ssh/dev-spacewalker-key.pem
chmod 400 ~/.ssh/dev-spacewalker-key.pem
```

### Environment Setup Verification
```bash
# Complete environment setup verification
just db_test

# This command verifies:
# 1. AWS CLI configuration and permissions
# 2. SSH key availability and permissions
# 3. Secrets Manager access
# 4. CloudFormation stack accessibility
# 5. Network connectivity to bastion host
```

---

## 🏗️ Implementation Architecture

### Python Helper Script: `scripts/database/db_helper.py`

The database access system is built around a comprehensive Python helper script that orchestrates all aspects of secure database connectivity:

#### Core Functions
- **AWS Secrets Manager Integration**: Secure retrieval of database credentials
- **CloudFormation Stack Parsing**: Dynamic discovery of bastion host IP addresses
- **SSH Tunnel Management**: Automated creation and management of secure tunnels
- **Connection Orchestration**: Coordinated database connection establishment
- **Error Handling**: Comprehensive error handling and user feedback

#### Security Features
- **Credential Caching**: Secure in-memory credential caching for session duration
- **Connection Validation**: Pre-connection validation of all required components
- **Automatic Cleanup**: Proper cleanup of tunnels and connections on exit
- **Audit Logging**: Detailed logging of all access attempts and operations

### Justfile Command Interface

Clean, user-friendly CLI interface that wraps the Python helper functionality:

| Justfile Command | Python Function | Purpose |
|------------------|-----------------|---------|
| `just db_test` | `test_connectivity()` | Validate AWS access and credentials |
| `just db_tunnel` | `create_tunnel()` | Establish SSH tunnel to database |
| `just db_connect` | `connect_database()` | Connect to database via tunnel |
| `just db_quick_connect` | `quick_connect()` | One-shot tunnel and connection |
| `just bastion_ssh` | `ssh_bastion()` | Direct SSH access to bastion host |
| `just db_migration_status` | `check_migrations()` | Alembic migration status check |

### Infrastructure Component Integration

#### AWS Services Integration
- **EC2 Bastion Host**: Secure jump host for database access
- **RDS PostgreSQL**: Primary database instance with security group restrictions
- **Secrets Manager**: Secure credential storage and automatic rotation support
- **CloudFormation**: Infrastructure as Code for consistent deployment
- **IAM Roles**: Least privilege access control for all components

#### Network Architecture
- **Public Subnet**: Bastion host with controlled internet access
- **Private Subnet**: Database with no direct internet connectivity
- **Security Groups**: Restrictive network access control between components
- **VPC Flow Logs**: Complete network traffic monitoring and auditing

---

## 📋 Related Database Documentation

### Database Architecture and Design
> 🗄️ **Database Design**: See [Database Design](../backend/database-design.md) for comprehensive database schema and architecture documentation
> 🗄️ **Database Development**: See [Backend Development Guide](../backend/development/README.md) for development patterns and best practices

### Infrastructure and Security
- **[Environment Configuration](../setup/environment-configuration.md)** - Complete environment setup including database configuration
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Comprehensive AWS infrastructure setup and management
- **[Security Architecture](../architecture/security-architecture.md)** - Security best practices and implementation details

### Development Workflows
- **[Development Environment Setup](../setup/development-setup.md)** - Complete development environment configuration
- **[Demo Data Management](./demo-data-management.md)** - Safe demo data creation and management workflows
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - Comprehensive troubleshooting procedures for database and infrastructure issues

---

**Status**: ✅ **ENHANCED PRODUCTION DATABASE ACCESS WORKFLOWS**
**Last Updated**: 2025-07-03
**Scope**: Secure Database Access, Enhanced SSH Security, AWS Infrastructure, Comprehensive Command Suite
**Key Commands**: `just db_quick_connect`, `just db_tunnel`, `just db_migration_status_quick`, `just db_test`

---

*This database access documentation provides essential workflows for secure database connectivity, ensuring proper security practices while enabling efficient development and troubleshooting operations across all environments.*
