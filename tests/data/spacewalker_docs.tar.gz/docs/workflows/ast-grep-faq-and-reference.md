# 🔍 ast-grep FAQ and Reference Guide

## Purpose
Comprehensive FAQ, quick reference, and glossary for ast-grep security scanning in SpaceWalker, providing immediate answers to common questions, essential command patterns, and terminology definitions for development teams.

## When to Use This
- Quick answers to ast-grep questions and problems
- Reference for command syntax and configuration options
- Understanding ast-grep terminology and concepts
- Debugging common issues and error messages
- Finding code patterns and rule examples

**Keywords:** ast-grep FAQ, quick reference, commands, troubleshooting, patterns, glossary

**Version:** 1.0
**Date:** 2025-09-10
**Status:** Active - Reference Guide

---

## 🚀 Quick Start Commands

### Essential ast-grep Commands in SpaceWalker

```bash
# Development workflow commands (RECOMMENDED)
just lint astgrep                   # Run ast-grep through SpaceWalker workflow
just dev_cycle                     # Include ast-grep in fast development cycle
just lint check all                # Full linting including ast-grep

# Manual ast-grep commands (for debugging)
ast-grep --version                 # Check installation
ast-grep --config .ast-grep/sgconfig.yml scan .  # Full codebase scan
ast-grep --help                    # Show all options
```

### Most Common Use Cases

```bash
# Scan specific directories
ast-grep --config .ast-grep/sgconfig.yml scan apps/backend/
ast-grep --config .ast-grep/sgconfig.yml scan apps/admin/

# Scan specific file types
ast-grep --config .ast-grep/sgconfig.yml scan . --lang python
ast-grep --config .ast-grep/sgconfig.yml scan . --lang typescript

# Pattern-based searching
ast-grep --pattern 'eval($ARG)' .
ast-grep --pattern 'f"SELECT * FROM $TABLE WHERE $CONDITION"' apps/backend/
```

---

## 🤔 Frequently Asked Questions

### General Usage

**Q: What is ast-grep and why do we use it in SpaceWalker?**

A: ast-grep is a code search and analysis tool that uses Abstract Syntax Trees (AST) to find patterns in code. We use it for:
- Security vulnerability scanning
- Code quality enforcement
- Pattern-based refactoring
- Compliance checking

**Q: How is ast-grep integrated into SpaceWalker's development workflow?**

A: ast-grep runs automatically in:
- `just lint astgrep` - Manual security scanning
- `just dev_cycle` - Fast development iteration
- `just lint check all` - Comprehensive code quality checks
- GitHub Actions CI/CD pipeline - Automated security validation

**Q: Should I run ast-grep directly or through justfile commands?**

A: **Always use justfile commands** (`just lint astgrep`) for consistency. Direct ast-grep commands are only for debugging or development of new rules.

### Configuration and Setup

**Q: Where is ast-grep configured in SpaceWalker?**

A: Configuration files are located in:
- `.ast-grep/sgconfig.yml` - Main configuration
- `.ast-grep/rules/security/` - Security rules directory
- `.github/workflows/ast-grep-security.yml` - CI/CD integration

**Q: How do I check if ast-grep is properly installed?**

A: Run these verification commands:
```bash
ast-grep --version                 # Should show v0.28.0+
which ast-grep                     # Should show installation path
ls -la .ast-grep/                  # Should show config directory
just lint astgrep                 # Should run without errors
```

**Q: What languages does ast-grep scan in SpaceWalker?**

A: Currently configured for:
- Python (`.py` files) - Backend code
- TypeScript (`.ts`, `.tsx` files) - Admin and mobile code
- JavaScript (`.js`, `.jsx` files) - Legacy and build scripts

### Security Rules and Findings

**Q: What types of security issues does ast-grep detect?**

A: Common security patterns detected:
- Hardcoded secrets and API keys
- SQL injection vulnerabilities
- Path traversal attacks
- Unsafe eval() usage
- Missing authentication checks
- Tenant isolation bypasses
- Insecure cryptographic practices

**Q: How do I understand ast-grep security findings?**

A: Each finding includes:
- **Location**: File path and line number
- **Severity**: error (must fix) or warning (should review)
- **Message**: Description of the security issue
- **Rule ID**: Identifier for the security rule
- **Note**: Remediation guidance and best practices

**Q: Are all ast-grep findings real security issues?**

A: Not always. Some may be false positives:
- Test files with intentional security anti-patterns
- Demo code or examples
- Code that has compensating security controls
- Patterns that are safe in specific contexts

Always review findings carefully and consult the security team for complex cases.

### Performance and Optimization

**Q: Why is ast-grep sometimes slow?**

A: Performance can be affected by:
- Large number of files in the codebase
- Complex security rules with broad patterns
- Insufficient file filtering
- Memory constraints on the system

Current SpaceWalker performance: ~1.7s for full scan (highly optimized).

**Q: How can I speed up ast-grep scans?**

A: Optimization strategies:
- Use file filtering: `--lang python` or `--glob '**/*.py'`
- Scan specific directories: `scan apps/backend/` instead of `.`
- Use parallel execution (already optimized in SpaceWalker)
- Exclude unnecessary directories (configured in `.ast-grep/sgconfig.yml`)

**Q: What files are excluded from ast-grep scanning?**

A: Excluded patterns (configured in `sgconfig.yml`):
- `node_modules/` - Package dependencies
- `.git/` - Version control files
- `*.min.js` - Minified JavaScript
- `dist/`, `build/` - Build artifacts
- `__pycache__/` - Python cache files
- Test fixtures and mock data

### Rule Development

**Q: How do I create custom security rules?**

A: Basic rule structure:
```yaml
id: custom-rule-name
message: "Description of the security issue"
severity: error  # or warning
language: python  # or typescript, javascript
rule:
  pattern: |
    # AST pattern to match
note: "Remediation guidance"
```

See the [Onboarding Checklist](../setup/ast-grep-onboarding-checklist.md) for hands-on rule development exercises.

**Q: How do I test custom rules before deploying them?**

A: Testing workflow:
```bash
# 1. Create rule file
cat > custom-rule.yml << 'EOF'
[rule content]
EOF

# 2. Test against specific files
ast-grep --config custom-rule.yml scan apps/backend/

# 3. Validate rule syntax
ast-grep check custom-rule.yml

# 4. Add to official rules after testing
cp custom-rule.yml .ast-grep/rules/security/
```

### Troubleshooting

**Q: ast-grep command not found**

A: Installation solutions:
```bash
# macOS with Homebrew
brew install ast-grep

# Rust cargo
cargo install ast-grep

# Download binary manually
curl -L https://github.com/ast-grep/ast-grep/releases/latest/download/ast-grep-x86_64-unknown-linux-gnu.tar.gz | tar xz
```

**Q: "Configuration file not found" error**

A: Check configuration:
```bash
ls -la .ast-grep/sgconfig.yml      # File should exist
cat .ast-grep/sgconfig.yml         # Check syntax
ast-grep --config .ast-grep/sgconfig.yml scan --help  # Test config loading
```

**Q: Rules not working as expected**

A: Debugging steps:
```bash
# Test rule syntax
ast-grep check .ast-grep/rules/security/your-rule.yml

# Run with debug output
ast-grep --config .ast-grep/sgconfig.yml scan . --debug

# Test specific patterns
ast-grep --pattern 'your_pattern' test-file.py
```

### CI/CD Integration

**Q: ast-grep is failing in GitHub Actions**

A: Common solutions:
- Check that ast-grep binary is installed in CI environment
- Verify configuration files are committed to repository
- Ensure file permissions are correct
- Check for environment-specific path issues

**Q: How do I make ast-grep failures non-blocking in CI?**

A: In GitHub Actions, ast-grep failures are configured to:
- **Block PRs** for `severity: error` findings
- **Allow with warnings** for `severity: warning` findings
- **Report in PR comments** for all findings

**Q: Can I run ast-grep locally exactly like CI does?**

A: Simulate CI environment:
```bash
# Run the same command as GitHub Actions
ast-grep --config .ast-grep/sgconfig.yml scan .

# Check exit codes
echo "Exit code: $?"  # 0 = success, 1 = findings, 2 = error
```

---

## 📖 Quick Reference

### Command Syntax Patterns

```bash
# Basic scanning
ast-grep scan [PATH]
ast-grep --config CONFIG scan PATH
ast-grep scan PATH --lang LANGUAGE

# Pattern matching
ast-grep --pattern 'PATTERN' PATH
ast-grep --pattern 'function $NAME($$$PARAMS) { $$$BODY }' .

# Rule management
ast-grep check RULE_FILE
ast-grep --rule RULE_PATH scan PATH

# Output control
ast-grep scan PATH --json          # JSON output
ast-grep scan PATH --no-color      # Plain text
ast-grep scan PATH --debug         # Verbose debugging
```

### Configuration File Structure

```yaml
# .ast-grep/sgconfig.yml structure
ruleDirs:
  - rules/security                 # Rules directory
languageGlobs:
  python: ["**/*.py"]             # File patterns by language
  typescript: ["**/*.ts", "**/*.tsx"]
ignore:
  - "node_modules/**"             # Excluded patterns
  - "**/*.min.js"
```

### Rule File Template

```yaml
id: rule-identifier
message: "Clear description of the issue"
severity: error  # or warning
language: python  # Target language
rule:
  pattern: |
    # AST pattern to match
    function_call($ARG)
  constraints:
    ARG:
      regex: "dangerous_pattern"   # Additional constraints
note: "How to fix this issue"
```

### Common Pattern Examples

```yaml
# Hardcoded secrets
pattern: |
  $VAR = "$SECRET"
constraints:
  SECRET:
    regex: "(sk-|pk_|api_key_|secret_)"

# SQL injection
pattern: |
  f"SELECT * FROM $TABLE WHERE $CONDITION"

# Missing authentication
pattern: |
  @app.post("$PATH")
  def $FUNC($$$PARAMS):
      $$$BODY
constraints:
  BODY:
    not:
      contains:
        pattern: "get_current_user"

# Unsafe eval
pattern: eval($ARG)

# Path traversal
pattern: |
  open($PATH, $MODE)
constraints:
  PATH:
    regex: ".*\\.\\./.*"
```

---

## 📚 Glossary

### Core Concepts

**Abstract Syntax Tree (AST)**
: A tree representation of the structure of source code, where each node represents a construct in the programming language.

**Pattern Matching**
: The process of checking a given sequence of tokens for the presence of constituents of some pattern.

**Rule**
: A configuration file that defines a code pattern to search for and what action to take when found.

**Severity**
: The importance level of a finding - `error` (must fix) or `warning` (should review).

### ast-grep Specific Terms

**sgconfig.yml**
: The main configuration file for ast-grep that defines languages, file patterns, and rule directories.

**Rule Directory**
: A folder containing ast-grep rule files, organized by category (e.g., `rules/security/`).

**Constraint**
: Additional conditions that must be met for a pattern to match, such as regex patterns or nested conditions.

**Metavariable**
: Placeholders in patterns (like `$VAR`, `$FUNC`) that can match various code elements.

**Capture Group**
: A way to extract specific parts of matched code using metavariables.

### SpaceWalker Integration Terms

**Security Scanning**
: Automated analysis of code for security vulnerabilities using ast-grep rules.

**Lint Integration**
: Running ast-grep as part of code quality checks through `just lint astgrep`.

**Dev Cycle**
: Fast development iteration that includes ast-grep security checks via `just dev_cycle`.

**CI/CD Pipeline**
: Automated workflow that runs ast-grep on every code change to ensure security standards.

### Security Terms

**Hardcoded Secret**
: Sensitive information like API keys or passwords embedded directly in source code.

**SQL Injection**
: A security vulnerability where malicious SQL code is inserted into application queries.

**Path Traversal**
: An attack that aims to access files and directories outside of the web application's root directory.

**Tenant Isolation**
: Security practice ensuring that data from different customers (tenants) is properly separated.

**Authentication Bypass**
: A vulnerability that allows attackers to gain access without proper credentials.

### Performance Terms

**File Filtering**
: Excluding irrelevant files from scanning to improve performance (via glob patterns).

**Parallel Execution**
: Running multiple ast-grep rules simultaneously to speed up scanning.

**Memory Profiling**
: Monitoring memory usage during ast-grep execution to optimize resource consumption.

**Benchmark Testing**
: Measuring ast-grep performance to track improvements and identify bottlenecks.

---

## 🔧 Advanced Usage Patterns

### Complex Pattern Matching

```bash
# Multiple condition patterns
ast-grep --pattern 'if ($COND1 && $COND2) { $$$BODY }' .

# Function definition patterns
ast-grep --pattern 'def $NAME($$$PARAMS): $$$BODY' --lang python apps/backend/

# Class method patterns
ast-grep --pattern 'class $CLASS: def $METHOD(self, $$$PARAMS): $$$BODY' apps/backend/

# Import statement patterns
ast-grep --pattern 'from $MODULE import $ITEMS' --lang python .
```

### Rule Composition

```yaml
# Multiple patterns with OR logic
rule:
  any:
    - pattern: 'eval($ARG)'
    - pattern: 'exec($ARG)'
    - pattern: 'compile($CODE, $FILE, "exec")'

# Patterns with exclusions
rule:
  pattern: 'open($FILE, $MODE)'
  constraints:
    FILE:
      not:
        regex: '^"/(?:tmp|var/tmp)/"'
```

### Output Processing

```bash
# JSON output for scripting
ast-grep scan . --json | jq '.[] | select(.severity == "error")'

# Count findings by severity
ast-grep scan . --json | jq '[.[] | .severity] | group_by(.) | map({severity: .[0], count: length})'

# Extract unique rule IDs
ast-grep scan . --json | jq -r '.[].ruleId' | sort | uniq
```

### Performance Optimization

```bash
# Benchmark different approaches
time ast-grep scan .                    # Full scan
time ast-grep scan . --lang python      # Language-filtered
time ast-grep scan apps/backend/        # Directory-filtered

# Memory usage monitoring
/usr/bin/time -l ast-grep scan . 2>&1 | grep "maximum resident set size"

# Parallel rule execution
python scripts/helpers/benchmark_astgrep.py --workers 8
```

---

## 🚨 Emergency Procedures

### ast-grep Blocking Development

If ast-grep is preventing development progress:

```bash
# 1. Bypass ast-grep temporarily (EMERGENCY ONLY)
just lint check backend           # Skip ast-grep, run other lints
just test unit all               # Run tests without linting

# 2. Quick fix for false positives
# Add comment to suppress specific findings:
# ast-grep:ignore-next-line rule-id
problematic_code_here()

# 3. Get help immediately
just docs search "ast-grep troubleshooting"
```

### CI/CD Pipeline Failures

```bash
# 1. Check recent rule changes
git log --oneline .ast-grep/rules/ | head -5

# 2. Test rules locally
ast-grep check .ast-grep/rules/security/*.yml

# 3. Rollback problematic rules if needed
git revert [commit-hash]
```

### Performance Issues

```bash
# 1. Check for resource exhaustion
top -p $(pgrep ast-grep)

# 2. Use targeted scanning
ast-grep scan apps/backend/ --lang python    # Reduce scope

# 3. Contact DevOps if persistent
# Performance issues may require infrastructure scaling
```

---

## 🔗 Related Documentation

### Essential Guides
- **[ast-grep Onboarding Checklist](../setup/ast-grep-onboarding-checklist.md)** - Hands-on training and exercises
- **[ast-grep Troubleshooting Guide](../workflows/ast-grep-troubleshooting.md)** - Detailed problem resolution
- **[ast-grep Optimization Guide](../development/ast-grep-optimization-guide.md)** - Performance tuning

### SpaceWalker Workflows
- **[Quick Start Guide](../setup/quick-start.md)** - Development environment setup
- **[Development Workflows](../workflows/README.md)** - Team development processes
- **[Testing Guide](../workflows/testing-guide.md)** - Quality assurance workflows

### External Resources
- **[Official ast-grep Documentation](https://ast-grep.github.io/)** - Complete reference
- **[ast-grep GitHub Repository](https://github.com/ast-grep/ast-grep)** - Source code and issues
- **[AST Pattern Matching Guide](https://ast-grep.github.io/guide/)** - Pattern development

---

## 📞 Getting Additional Help

### Internal Support
- **Documentation Search**: `just docs search "ast-grep [topic]"`
- **Team Channels**: #security, #dev-tools, #backend-dev
- **Security Team**: For complex vulnerability assessment
- **DevOps Team**: For performance and CI/CD issues

### Self-Service Resources
- Run `ast-grep --help` for command options
- Check `.ast-grep/sgconfig.yml` for current configuration
- Review recent changes: `git log .ast-grep/`
- Test patterns online: [ast-grep Playground](https://ast-grep.github.io/playground)

### Escalation Path
1. **Level 1**: Check this FAQ and troubleshooting guide
2. **Level 2**: Search SpaceWalker documentation with `just docs search`
3. **Level 3**: Ask in team channels or security team
4. **Level 4**: Create GitHub issue for potential bugs
5. **Level 5**: Contact ast-grep community for tool-specific issues

---

**📋 Quick Access**: Bookmark this page for instant access to ast-grep answers and references. Keep it open during development for efficient problem-solving.

---

**Status**: ✅ Active reference guide - Updated 2025-09-10. Comprehensive FAQ and quick reference for effective ast-grep usage in SpaceWalker development environment.
