# Unified Deployment Commands

## Overview

The `aws` command provides a single, consistent interface for all AWS deployment operations in SpaceWalker. It replaces 20+ individual deployment commands with one unified command that follows the same pattern as our other unified commands (`test`, `lint`, `service`, etc.).

## 🚨 CRITICAL: Infrastructure vs Service Management vs New Code

**FUNDAMENTAL DISTINCTION** - Three separate operations:

### 🏗️ `aws deploy` (for infrastructure components) = Infrastructure ONLY
- Deploys **CloudFormation templates and AWS resources**
- Components: foundation, database, cluster, subnets, certificates, dns, monitoring
- Creates/updates: VPC, ECS clusters, RDS, load balancers, security groups
- Uses SAM templates from `/sam/` directory

### 🔄 `aws deploy` / `aws images` (for application services) = Service Restart
- **Service restart/redeployment** with existing container images in ECR
- Services: backend, admin, mobile
- **DOES NOT build new code** or create new images from local changes
- **DOES NOT deploy newly written code** - only restarts with current ECR images

### 📦 New Code Deployment = Git Push → CI/CD Pipeline
- **Developer writes code locally** → `git push origin dev/main`
- **CI/CD builds new container images** from your code changes
- **CI/CD pushes images to ECR** and deploys them
- **This is how you deploy NEW CODE you've written**

**🔥 Remember**: `aws deploy` ≠ new code deployment. To deploy code changes, push to git.

## Command Structure

```bash
just aws <action> <service> [env]
```

### Actions

- **deploy** - Deploy CloudFormation infrastructure ONLY (AWS resources, templates)
- **status** - Check deployment status and health
- **dry-run** - Preview what would be deployed without executing
- **validate** - Validate CloudFormation/SAM templates
- **restart** - Restart ECS services (useful after updating secrets)
- **recover** - Smart recovery of failed stacks
- **images** - Deploy application code ONLY (force ECS container image updates)

### Services

**Application Services:**
- `all` - Deploy all components in dependency order
- `backend` - Backend API service
- `admin` - Admin web interface
- `mobile` - Mobile API service

**Infrastructure Components:**
- `foundation` - S3, IAM roles, security groups, bastion host
- `database` - RDS PostgreSQL instance
- `cluster` - ECS cluster and related resources

**Supporting Services:**
- `certificates` - SSL certificates (dev only, prod uses hardcoded)
- `dns` - Route53 DNS configuration
- `monitoring` - CloudWatch, SNS, Slack alerts
- `ecr` - Elastic Container Registry repositories

### Environments

- `dev` (default) - Development environment
- `staging` - Staging environment
- `prod` - Production environment (requires `just prod enable`)

## Examples

### Basic Deployment
```bash
# Deploy backend to dev (default environment)
just aws deploy backend

# Deploy admin to staging
just aws deploy admin staging

# Deploy all services to dev
just aws deploy all dev
```

### Status Checks
```bash
# Check status of all services in dev
just aws status all

# Check backend status in prod
just aws status backend prod
```

### Dry Run and Validation
```bash
# Preview what would be deployed
just aws dry-run backend dev

# Validate templates without deploying
just aws validate admin dev
```

### Service Management
```bash
# Restart backend service in dev
just aws restart backend dev

# Force new image deployment
just aws images backend dev

# Recover failed stacks
just aws recover all dev
```

## Production Deployments

Production deployments require explicit enablement for safety:

```bash
# Enable production mode for 30 minutes
(just prod enable --minutes=30)

# Then deploy to production
just aws deploy backend prod
```

## Migration from Old Commands

### Recently Removed Commands (January 2025)

The following redundant AWS commands have been **removed** from the justfile to reduce duplication and improve maintainability. All functionality is preserved through unified commands:

| Removed Command | Replacement | Description |
|----------------|-------------|-------------|
| `just aws_cli` | Direct AWS CLI usage | Use `aws` command directly with appropriate profile/region |
| `just aws_network` | `just stack inspect` + `just aws debug` | Network inspection via CloudFormation |
| `just aws_check` | `just health` | Service health checks |
| `just aws_stacks` | `just stack status` | CloudFormation stack status |
| `just aws_stacks_raw` | `just stack status --raw` | Raw stack status output |
| `just aws_stack_events` | `just stack events` | CloudFormation stack events |
| `just aws_stack_status` | `just stack status` | Individual stack status |
| `just aws_deployments` | `just aws list` | ECS deployment status |
| `just aws_images` | `just aws images` | Container image versions |
| `just aws_deploy_status` | `just aws status` | Deployment status checks |
| `just aws_logs_commands` | See [Logging Guide](./logging-guide.md) | Log access documentation |
| `just test_slack_notifications` | `just monitor slack-test` | Test Slack notification integration |
| `just validate_monitoring` | `just monitor validate` | Validate monitoring infrastructure |
| Production monitoring status alias | `just monitor status` | Legacy monitoring helper removed in Jan 2025 |
| `just aws_issues` | `just aws diagnose` | Diagnose AWS deployment issues |
| `just aws_debug` | `just aws debug` | Run deep debugging analysis |
| `just aws_task_env` | `just ecs env` | View ECS task environment variables |
| `just deployment_history` | `just aws history` | Show deployment history |

### AI Testing Commands

| Removed Command | Replacement | Description |
|----------------|-------------|-------------|
| `just test_ai_real` | `just test unit backend --ai-real` | Run AI tests with real Gemini API |
| `just test_ai_all` | `just test unit backend --ai-all` | Run all AI tests (mocked + real) |

### Deprecated Deployment Commands

All existing `aws_deploy_*` commands are now marked as `[DEPRECATED]` and will be removed in a future version. Here's the migration guide:

| Old Command | New Command |
|------------|-------------|
| `just aws_deploy_backend dev` | `just aws deploy backend dev` |
| `just aws_deploy_admin dev` | `just aws deploy admin dev` |
| `just aws_deploy_all dev` | `just aws deploy all dev` |
| `just aws_deploy_status dev` | `just aws status all dev` |
| `just aws_restart_backend dev` | `just aws restart backend dev` |
| `just aws_deploy_dry_run dev backend` | `just aws dry-run backend dev` |
| `just aws_deploy_images dev backend` | `just aws images backend dev` |
| `just aws_deploy_recover dev` | `just aws recover all dev` |

## Implementation Details

The unified deployment command is implemented by:

1. **`scripts/helpers/deployment_manager.py`** - Main orchestrator that:
   - Maps service names to deployment components
   - Handles AWS profile configuration based on environment
   - Routes actions to appropriate handlers
   - Provides consistent error handling and output

2. **Existing deployment infrastructure** - The unified command wraps:
   - `scripts/helpers/deployment_manager.py` - Core deployment logic
   - `scripts/deployment/` - SAM templates and configurations
   - Various shell scripts for specific operations

## Benefits

- **Consistency**: Same command pattern as other unified commands
- **Discoverability**: Single entry point with built-in help
- **Safety**: Production safety checks built-in
- **Simplicity**: Reduced cognitive load with fewer commands
- **Maintainability**: Single place to update deployment logic
