# Spacewalker AWS Deployment Guide

## Purpose
Comprehensive guide for secure AWS deployment procedures using GitHub Actions, IAM policies, and environment-specific configurations. Essential reference for implementing production-grade CI/CD workflows with proper security controls.

## When to Use This
- Setting up CI/CD pipelines for AWS deployment
- Configuring GitHub Actions for secure AWS access
- Implementing environment-specific deployment workflows
- Understanding IAM policy configuration for deployment users
- Troubleshooting deployment authentication and permission issues
- Keywords: AWS deployment, GitHub Actions, CI/CD security, IAM policies, environment separation

**Version:** 2.0 (Extracted from AWS CLI safety rules)
**Date:** 2025-06-29
**Status:** Current - Production Deployment Procedures

---

## 🏗️ Deployment Architecture Overview

### Environment Separation Strategy
Spacewalker uses strict environment separation with dedicated AWS accounts:

| Environment | Account ID | Region | Branch | Purpose |
|-------------|------------|--------|--------|---------|
| **Sandbox** | 881490112168 | us-east-2 | `test`, feature branches | Development and testing |
| **Production** | 352676346183 | us-east-1 | `main` | Live customer environment |

### Security Principles
1. **Least Privilege Access** - Deploy users have minimal required permissions
2. **Environment Isolation** - No cross-account access between sandbox and production
3. **Credential Security** - All credentials stored in GitHub Secrets
4. **Branch Protection** - Main branch requires reviews and status checks
5. **Audit Trail** - All deployment actions logged via CloudTrail

---

## 🔐 GitHub Actions Configuration

### Secure Credential Management
Spacewalker uses **OIDC (OpenID Connect)** for secure, keyless authentication between GitHub Actions and AWS. This eliminates the need for long-lived access keys.

#### OIDC Configuration (Recommended)
Configure these secrets in your repository settings:

```
AWS_OIDC_ROLE_ARN=arn:aws:iam::881490112168:role/github-actions-deployment-role
AWS_REGION=us-east-2
```

#### Legacy Access Key Method (Deprecated)
If OIDC is not available, use these secrets:

**Sandbox Environment:**
```
AWS_SANDBOX_ACCESS_KEY_ID=AKIA...
AWS_SANDBOX_SECRET_ACCESS_KEY=secret...
AWS_SANDBOX_REGION=us-east-2
```

**Production Environment:**
```
AWS_PROD_ACCESS_KEY_ID=AKIA...
AWS_PROD_SECRET_ACCESS_KEY=secret...
AWS_PROD_REGION=us-east-1
```

#### Environment-Aware Workflow Template (OIDC)
```yaml
name: Secure AWS Deployment

on:
  push:
    branches: [main, dev]
  pull_request:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    # Use GitHub environments for additional protection
    environment: ${{ github.ref == 'refs/heads/main' && 'prod' || 'dev' }}

    permissions:
      id-token: write  # Required for OIDC connection to AWS
      contents: read   # Required to checkout the repository

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Configure AWS credentials (OIDC)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_OIDC_ROLE_ARN }}
          aws-region: ${{ secrets.AWS_REGION }}

      - name: Verify deployment context
        run: |
          echo "Deploying to environment: ${{ github.ref == 'refs/heads/main' && 'PRODUCTION' || 'SANDBOX' }}"
          echo "Account ID: $(aws sts get-caller-identity --query Account --output text)"
          echo "Region: $(aws configure get region)"

          # Verify correct account
          CURRENT_ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
          if [[ "${{ github.ref }}" == "refs/heads/main" ]]; then
            EXPECTED_ACCOUNT="352676346183"
          else
            EXPECTED_ACCOUNT="881490112168"
          fi

          if [[ "$CURRENT_ACCOUNT" != "$EXPECTED_ACCOUNT" ]]; then
            echo "❌ CRITICAL: Wrong account! Expected $EXPECTED_ACCOUNT, got $CURRENT_ACCOUNT"
            exit 1
          fi

          echo "✅ Account verification passed"

      - name: Deploy application
        run: |
          # Your deployment commands here
          echo "Deploying to verified environment..."
          # Example: aws cloudformation deploy --template-file template.yaml --stack-name my-stack
```

### Advanced GitHub Actions Patterns

#### Conditional Deployment with Approvals
```yaml
jobs:
  deploy:
    runs-on: ubuntu-latest
    environment:
      name: ${{ github.ref == 'refs/heads/main' && 'production' || 'sandbox' }}
      url: ${{ steps.deploy.outputs.environment-url }}

    steps:
      - name: Deploy with environment protection
        id: deploy
        run: |
          if [[ "${{ github.ref }}" == "refs/heads/main" ]]; then
            echo "🔴 PRODUCTION DEPLOYMENT - Requires manual approval"
            # Production deployment logic
            echo "environment-url=https://app.spacewalker.com" >> $GITHUB_OUTPUT
          else
            echo "🟡 SANDBOX DEPLOYMENT - Automatic"
            # Sandbox deployment logic
            echo "environment-url=https://sandbox.spacewalker.com" >> $GITHUB_OUTPUT
          fi
```

#### Multi-Service Deployment
```yaml
strategy:
  matrix:
    service: [backend, admin, mobile-api]

steps:
  - name: Deploy ${{ matrix.service }}
    run: |
      SERVICE="${{ matrix.service }}"
      ENVIRONMENT=${{ github.ref == 'refs/heads/main' && 'prod' || 'sandbox' }}

      echo "Deploying $SERVICE to $ENVIRONMENT"

      # Service-specific deployment logic
      case $SERVICE in
        backend)
          aws cloudformation deploy --template-file backend/template.yaml \
            --stack-name spacewalker-backend-$ENVIRONMENT \
            --parameter-overrides Environment=$ENVIRONMENT
          ;;
        admin)
          aws s3 sync admin/dist/ s3://spacewalker-admin-$ENVIRONMENT/
          aws cloudfront create-invalidation --distribution-id $(aws ssm get-parameter --name /spacewalker/$ENVIRONMENT/cloudfront-id --query Parameter.Value --output text) --paths "/*"
          ;;
        mobile-api)
          aws lambda update-function-code --function-name spacewalker-mobile-api-$ENVIRONMENT \
            --zip-file fileb://mobile-api/deployment.zip
          ;;
      esac
```

---

## 🎯 IAM Policy Configuration

### CI/CD User IAM Policy Template
Create dedicated IAM users for GitHub Actions with minimal required permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "CloudFormationManagement",
      "Effect": "Allow",
      "Action": [
        "cloudformation:CreateStack",
        "cloudformation:UpdateStack",
        "cloudformation:DeleteStack",
        "cloudformation:DescribeStacks",
        "cloudformation:DescribeStackEvents",
        "cloudformation:DescribeStackResources",
        "cloudformation:ValidateTemplate"
      ],
      "Resource": [
        "arn:aws:cloudformation:us-east-2:881490112168:stack/spacewalker-*/*",
        "arn:aws:cloudformation:us-east-1:352676346183:stack/spacewalker-*/*"
      ]
    },
    {
      "Sid": "S3DeploymentAccess",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::spacewalker-*",
        "arn:aws:s3:::spacewalker-*/*"
      ],
      "Condition": {
        "StringEquals": {
          "aws:RequestedRegion": ["us-east-2", "us-east-1"]
        }
      }
    },
    {
      "Sid": "LambdaDeployment",
      "Effect": "Allow",
      "Action": [
        "lambda:UpdateFunctionCode",
        "lambda:UpdateFunctionConfiguration",
        "lambda:GetFunction",
        "lambda:ListFunctions"
      ],
      "Resource": [
        "arn:aws:lambda:us-east-2:881490112168:function:spacewalker-*",
        "arn:aws:lambda:us-east-1:352676346183:function:spacewalker-*"
      ]
    },
    {
      "Sid": "CloudFrontInvalidation",
      "Effect": "Allow",
      "Action": [
        "cloudfront:CreateInvalidation",
        "cloudfront:GetInvalidation"
      ],
      "Resource": [
        "arn:aws:cloudfront::881490112168:distribution/*",
        "arn:aws:cloudfront::352676346183:distribution/*"
      ]
    },
    {
      "Sid": "ParameterStoreAccess",
      "Effect": "Allow",
      "Action": [
        "ssm:GetParameter",
        "ssm:GetParameters",
        "ssm:PutParameter"
      ],
      "Resource": [
        "arn:aws:ssm:us-east-2:881490112168:parameter/spacewalker/*",
        "arn:aws:ssm:us-east-1:352676346183:parameter/spacewalker/*"
      ]
    },
    {
      "Sid": "IdentityVerification",
      "Effect": "Allow",
      "Action": [
        "sts:GetCallerIdentity"
      ],
      "Resource": "*"
    }
  ]
}
```

### Permission Boundary for Additional Safety
Apply this permission boundary to deployment users:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "*",
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "aws:RequestedRegion": ["us-east-2", "us-east-1"]
        },
        "StringLike": {
          "aws:userid": ["AIDACKCEVSQ6C2EXAMPLE:*"]
        }
      }
    },
    {
      "Effect": "Deny",
      "Action": [
        "iam:CreateUser",
        "iam:DeleteUser",
        "iam:CreateRole",
        "iam:DeleteRole",
        "iam:AttachUserPolicy",
        "iam:DetachUserPolicy",
        "organizations:*",
        "account:*"
      ],
      "Resource": "*"
    }
  ]
}
```

---

## 🔄 Deployment Workflows

### ECS Deployment Verification

**Problem**: ECS circuit breaker can silently roll back deployments while CI/CD reports success, leading to false positive deployment results.

**Solution**: Spacewalker implements comprehensive deployment verification that detects rollbacks and ensures deployments actually succeed.

#### Verification Workflow

```bash
# Using the enhanced deployment script
scripts/deployment/force-ecs-deployment.sh dev backend

# The script automatically:
# 1. Captures current task definition revision (e.g., revision 44)
# 2. Forces ECS to deploy new containers
# 3. Waits for service stability
# 4. Verifies new revision is running (e.g., revision 45)
# 5. Reports failure if revision unchanged or rolled back
```

#### GitHub Actions Integration

```yaml
- name: Deploy ECS Service with Verification
  run: |
    # The deployment scripts handle verification automatically
    ./scripts/deployment/force-ecs-deployment.sh $ENVIRONMENT $SERVICE
    
    # Exit code 0 = successful deployment with new version
    # Exit code 1 = deployment failed or rolled back
```

#### Emergency Deployments

For situations where verification needs to be bypassed:

```bash
# Skip verification (use with caution)
./scripts/deployment/force-ecs-deployment.sh --skip-verification prod backend
```

#### Debugging Failed Deployments

When deployment verification fails, the script automatically displays recent ECS events:

```
📋 Recent ECS events for debugging:
┌────────────────────────┬──────────────────────────────────────────────┐
│ CreatedAt              │ Message                                      │
├────────────────────────┼──────────────────────────────────────────────┤
│ 2024-01-15T10:23:45Z   │ service backend-service was unable to place │
│                        │ a task because no container instance met    │
│                        │ all of its requirements                      │
└────────────────────────┴──────────────────────────────────────────────┘
```

### Standard Application Deployment

#### Backend API Deployment
```yaml
- name: Deploy Backend API
  run: |
    ENVIRONMENT=${{ github.ref == 'refs/heads/main' && 'prod' || 'sandbox' }}

    # Build and package application
    cd backend
    zip -r deployment.zip . -x "*.git*" "tests/*" "*.md"

    # Deploy via CloudFormation
    aws cloudformation deploy \
      --template-file cloudformation/backend.yaml \
      --stack-name spacewalker-backend-$ENVIRONMENT \
      --capabilities CAPABILITY_IAM \
      --parameter-overrides \
        Environment=$ENVIRONMENT \
        Version=${{ github.sha }} \
        DatabaseUrl=${{ secrets[format('DB_URL_{0}', github.ref == 'refs/heads/main' && 'PROD' || 'SANDBOX')] }}

    # Verify deployment
    STACK_STATUS=$(aws cloudformation describe-stacks \
      --stack-name spacewalker-backend-$ENVIRONMENT \
      --query 'Stacks[0].StackStatus' --output text)

    if [[ "$STACK_STATUS" != "CREATE_COMPLETE" && "$STACK_STATUS" != "UPDATE_COMPLETE" ]]; then
      echo "❌ Deployment failed with status: $STACK_STATUS"
      exit 1
    fi

    echo "✅ Backend deployment successful"
```

#### Static Site Deployment (Admin Dashboard)
```yaml
- name: Deploy Admin Dashboard
  run: |
    ENVIRONMENT=${{ github.ref == 'refs/heads/main' && 'prod' || 'sandbox' }}

    # Build admin dashboard
    cd admin
    npm run build:$ENVIRONMENT

    # Deploy to S3
    aws s3 sync dist/ s3://spacewalker-admin-$ENVIRONMENT/ --delete

    # Invalidate CloudFront cache
    DISTRIBUTION_ID=$(aws ssm get-parameter \
      --name /spacewalker/$ENVIRONMENT/admin-cloudfront-id \
      --query Parameter.Value --output text)

    aws cloudfront create-invalidation \
      --distribution-id $DISTRIBUTION_ID \
      --paths "/*"

    echo "✅ Admin dashboard deployment successful"
```

### Database Migration Deployment
```yaml
- name: Run Database Migrations
  run: |
    ENVIRONMENT=${{ github.ref == 'refs/heads/main' && 'prod' || 'sandbox' }}

    # Get database connection details from Parameter Store
    DB_HOST=$(aws ssm get-parameter --name /spacewalker/$ENVIRONMENT/db-host --query Parameter.Value --output text)
    DB_NAME=$(aws ssm get-parameter --name /spacewalker/$ENVIRONMENT/db-name --query Parameter.Value --output text)

    # Run migrations
    cd backend
    python -m alembic upgrade head

    echo "✅ Database migrations completed"
```

### ECS Task Execution Pattern

**Running Database Operations via ECS Tasks**

For database operations that need to run within the application context (tenant initialization, data seeding, etc.), use ECS tasks to execute scripts using the deployed backend container:

```yaml
- name: Run Database Operations via ECS Task
  run: |
    ENVIRONMENT=${{ github.ref == 'refs/heads/main' && 'prod' || 'sandbox' }}
    REGION=${{ github.ref == 'refs/heads/main' && 'us-east-1' || 'us-east-2' }}
    CLUSTER="${ENVIRONMENT}-spacewalker-ecs-cluster"
    
    # Get the latest backend task definition
    TASK_DEF=$(aws ecs describe-services \
      --cluster $CLUSTER \
      --services ${ENVIRONMENT}-spacewalker-backend \
      --region $REGION \
      --query 'services[0].taskDefinition' \
      --output text)
    
    # Get network configuration from existing service
    NETWORK_CONFIG=$(aws ecs describe-services \
      --cluster $CLUSTER \
      --services ${ENVIRONMENT}-spacewalker-backend \
      --region $REGION \
      --query 'services[0].networkConfiguration.awsvpcConfiguration' \
      --output json)
    
    SUBNETS=$(echo $NETWORK_CONFIG | jq -r '.subnets | join(",")')
    SECURITY_GROUPS=$(echo $NETWORK_CONFIG | jq -r '.securityGroups | join(",")')
    
    # Run database operation task
    TASK_ARN=$(aws ecs run-task \
      --cluster $CLUSTER \
      --task-definition $TASK_DEF \
      --network-configuration "awsvpcConfiguration={subnets=[$SUBNETS],securityGroups=[$SECURITY_GROUPS],assignPublicIp=DISABLED}" \
      --launch-type FARGATE \
      --overrides '{
        "containerOverrides": [{
          "name": "backend",
          "command": ["python", "-m", "spacewalker.scripts.database.your_script"],
          "environment": [{
            "name": "PYTHONUNBUFFERED",
            "value": "1"
          }]
        }]
      }' \
      --region $REGION \
      --query 'tasks[0].taskArn' \
      --output text)
    
    echo "Task started: $TASK_ARN"
    
    # Wait for task completion
    aws ecs wait tasks-stopped \
      --cluster $CLUSTER \
      --tasks $TASK_ARN \
      --region $REGION
    
    # Check task exit code
    EXIT_CODE=$(aws ecs describe-tasks \
      --cluster $CLUSTER \
      --tasks $TASK_ARN \
      --region $REGION \
      --query 'tasks[0].containers[0].exitCode' \
      --output text)
    
    if [ "$EXIT_CODE" == "0" ]; then
      echo "✅ Database operation completed successfully"
    else
      echo "❌ Database operation failed with exit code: $EXIT_CODE"
      exit 1
    fi
```

**Common ECS Task Operations**

```bash
# Examples of database operations using ECS tasks
# (these would be implemented in GitHub Actions using the pattern above)

# Initialize System Default tenant attributes
command: ["python", "-m", "spacecargo.scripts.database.fix_demo_attributes", "--system"]

# Initialize demo tenant data
command: ["python", "-m", "spacecargo.scripts.database.seed_demo_comprehensive", "--mode", "full"]

# Run custom database script
command: ["python", "-c", "your_inline_python_script"]

# Run database maintenance
command: ["python", "-m", "spacecargo.scripts.database.maintenance_script"]
```

**Benefits of ECS Task Pattern**

1. **Consistent Environment**: Scripts run in the same container environment as the application
2. **Database Access**: Automatic access to application database configuration
3. **Dependency Management**: All application dependencies are available
4. **Security**: Uses existing security groups and network configuration
5. **Logging**: Output automatically captured in CloudWatch logs
6. **Scalability**: Can run multiple tasks concurrently if needed

---

## 🛡️ Security Best Practices

### Credential Rotation Strategy
```yaml
- name: Verify Credential Freshness
  run: |
    # Check when credentials were last rotated
    LAST_ROTATED=$(aws iam get-access-key-last-used \
      --access-key-id ${{ secrets.AWS_ACCESS_KEY_ID }} \
      --query 'AccessKeyLastUsed.LastUsedDate' --output text)

    echo "Credentials last used: $LAST_ROTATED"

    # Warn if credentials are old (example: older than 90 days)
    if [[ $(date -d "$LAST_ROTATED" +%s) -lt $(date -d "90 days ago" +%s) ]]; then
      echo "⚠️ WARNING: Credentials may need rotation"
    fi
```

### Environment Protection Configuration
Set up GitHub environment protection rules:

1. **Production Environment**:
   - Required reviewers: DevOps team members
   - Wait timer: 5 minutes (allows for last-minute cancellation)
   - Deployment branches: Only `main` branch

2. **Sandbox Environment**:
   - No required reviewers
   - Deployment branches: All branches except `main`

### Monitoring and Alerting
```yaml
- name: Post-Deployment Monitoring
  run: |
    ENVIRONMENT=${{ github.ref == 'refs/heads/main' && 'prod' || 'sandbox' }}

    # Wait for services to be healthy
    sleep 30

    # Check application health
    HEALTH_URL="https://api.$ENVIRONMENT.spacewalker.com/health"
    HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" $HEALTH_URL)

    if [[ "$HTTP_STATUS" != "200" ]]; then
      echo "❌ Health check failed: $HTTP_STATUS"

      # Send alert to monitoring system
      curl -X POST "${{ secrets.SLACK_WEBHOOK_URL }}" \
        -H 'Content-type: application/json' \
        --data '{"text":"🚨 Deployment health check failed for '$ENVIRONMENT' environment"}'

      exit 1
    fi

    echo "✅ Post-deployment health check passed"
```

---

## 🔍 Troubleshooting Deployment Issues

### Common Permission Errors
```bash
# Error: AccessDenied for CloudFormation
# Solution: Verify IAM policy includes cloudformation:* permissions

# Error: InvalidUserID.NotFound
# Solution: Check if IAM user exists and has programmatic access enabled

# Error: Credential should be scoped to a valid region
# Solution: Verify AWS_REGION secret is set correctly

# Error: The request signature we calculated does not match
# Solution: Regenerate AWS credentials, may be corrupted
```

### Deployment Status Verification
```bash
# Check CloudFormation stack status
aws cloudformation describe-stacks --stack-name spacewalker-backend-prod

# View recent deployment events
aws cloudformation describe-stack-events --stack-name spacewalker-backend-prod --max-items 20

# Check Lambda function deployment
aws lambda get-function --function-name spacewalker-api-prod

# Verify S3 deployment
aws s3 ls s3://spacewalker-admin-prod/ --recursive --human-readable
```

### Rollback Procedures
```yaml
- name: Emergency Rollback
  if: failure()
  run: |
    ENVIRONMENT=${{ github.ref == 'refs/heads/main' && 'prod' || 'sandbox' }}

    echo "🔄 Initiating emergency rollback"

    # Rollback CloudFormation stack to previous version
    aws cloudformation cancel-update-stack --stack-name spacewalker-backend-$ENVIRONMENT

    # If that fails, rollback to last stable version
    PREVIOUS_VERSION=$(aws cloudformation describe-stack-events \
      --stack-name spacewalker-backend-$ENVIRONMENT \
      --query 'StackEvents[?ResourceStatus==`UPDATE_COMPLETE`][0].PhysicalResourceId' \
      --output text)

    if [[ -n "$PREVIOUS_VERSION" ]]; then
      # Implement version-specific rollback logic
      echo "Rolling back to version: $PREVIOUS_VERSION"
    fi

    echo "✅ Rollback completed"
```

---

## 📋 Related Deployment Documentation

### Security & Best Practices
- **[AWS Security Gotchas](../gotchas/aws-security-practices.md)** - Critical security mistakes to avoid during deployment
- **[Development Setup](../setup/development-setup.md)** - Local development environment configuration

### Platform-Specific Deployment
> 🚀 **Backend Teams**: See [Backend Deployment](../backend/deployment/) for API and database deployment specifics
> 🚀 **Admin Teams**: See [Admin Deployment](../admin/deployment/) for dashboard deployment procedures
> 🚀 **Mobile Teams**: See [Mobile Deployment](../mobile/deployment/) for mobile app deployment workflows

### Architecture & Requirements
- **[Product Overview](../product/product-overview.md)** - System architecture and deployment context
- **[Architecture Requirements](../architecture/architecture-requirements.md)** - Infrastructure requirements and constraints

---

**Status**: ✅ **PRODUCTION-READY DEPLOYMENT PROCEDURES**
**Last Updated**: 2025-06-29
**Environment Accounts**: Sandbox (881490112168), Production (352676346183)
**CI/CD Platform**: GitHub Actions with AWS Integration

---

*These deployment procedures are based on production-tested workflows and industry security best practices. Following these guidelines ensures secure, reliable, and auditable deployments across all Spacewalker environments.*
