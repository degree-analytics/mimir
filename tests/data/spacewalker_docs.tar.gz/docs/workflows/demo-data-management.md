# Demo Data Management Workflows

## Purpose
Comprehensive development workflow documentation for safely managing demo data in the Spacewalker system, ensuring multi-tenant data protection while providing robust development and testing environments. Essential reference for development team members setting up local environments and managing demo data across system components.

## When to Use This
- Setting up local development environments with demo data
- Managing safe demo data creation and cleanup workflows
- Understanding multi-tenant safe development practices
- Implementing non-destructive database seeding procedures
- Troubleshooting demo data setup and user credential issues
- Keywords: demo data, development workflows, multi-tenant safety, database seeding, development environment

**Version:** 2.3 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production Development Workflows

---

## 🛡️ Safe Demo Data Overview

The Spacewalker system implements a comprehensive safe demo data management system that protects multi-tenant data while providing excellent local development experience. This workflow ensures that demo data operations never interfere with production or other tenant data.

### Core Safety Principles
- **Multi-Tenant Isolation** - Demo operations affect only the demo tenant, never touching other tenant data
- **Non-Destructive Operations** - Scripts can be run multiple times safely without data loss
- **Explicit Commands** - Clear naming that indicates destructive vs. safe operations
- **Comprehensive Workflows** - Complete workflows for common development scenarios

---

## 🔧 Safe Demo Data Scripts

### Core Python Scripts

| Script | Purpose | Safety Level |
|--------|---------|--------------|
| **create_demo_tenant.py** | Creates demo tenant and users without destroying existing data | ✅ Safe |
| **seed_demo_safe.py** | Safely seeds full demo data (buildings, rooms, surveys) only for demo tenant | ✅ Safe |
| **truncate_demo_tenant.py** | Removes ONLY demo tenant data, preserves all other tenants | ⚠️ Demo-only destructive |

### Script Implementation Details

#### Demo Tenant Creation
```python
# create_demo_tenant.py - Safe tenant and user creation
# Creates demo tenant if it doesn't exist
# Creates demo users with proper role assignments
# Never touches existing tenants or users
```

#### Safe Demo Data Seeding
```python
# seed_demo_safe.py - Non-destructive demo data population
# Creates buildings, floors, rooms for demo tenant only
# Populates sample surveys with realistic data
# Includes demo images and survey responses
# Respects existing data, only adds missing demo content
```

#### Demo Data Cleanup
```python
# truncate_demo_tenant.py - Demo-specific cleanup
# Removes only demo tenant and associated data
# Preserves all other tenant data completely
# Used for clean demo environment reset
```

---

## ⚡ Development Workflow Commands

### Safe Development Commands

| Command | Description | Use Case |
|---------|-------------|----------|
| `just db seed` | Non-destructive demo data seeding | Add demo data to existing environment |
| `just db_seed_users` | Create only demo users (minimal setup) | Quick user setup for testing |
| `just db clean-all-non-system-tenants` | 🚨 **NUCLEAR**: Remove ALL customer data | Clean all customer tenant data (nuclear protection in production) |
| `just fresh_dev` | Complete fresh start workflow | New developer setup or complete reset |
| `just quick_start` | Fast start for returning developers | Resume development with existing setup |

### Destructive Commands (Use with Caution)

| Command | Description | Warning |
|---------|-------------|---------|
| `just db wipe-all` | Complete database reset + sequence reset | 🚨 **NUCLEAR** - Requires "act of god" protection |
| `just db reset-physical` | Complete Docker volume/schema destruction | 🚨 **LOCAL ONLY** - Physical database destruction |

### Development Workflow Examples

#### New Developer Setup
```bash
# Complete fresh development environment
just fresh_dev

# This command sequence:
# 1. Resets database completely (development only)
# 2. Runs all migrations
# 3. Seeds safe demo data
# 4. Creates all demo users
# 5. Provides ready-to-use development environment
```

#### Returning Developer Workflow
```bash
# Quick start for existing development environment
just quick_start

# This command sequence:
# 1. Ensures database is up to date
# 2. Adds any missing demo data
# 3. Verifies demo users exist
# 4. Ready for development without losing existing work
```

#### Demo Data Refresh
```bash
# Clean and refresh demo data only
just db clean-all-non-system-tenants
just db seed

# Workflow (🚨 NUCLEAR IN PRODUCTION):
# 1. Removes ALL customer tenant data (keeps System Tenant only)
# 2. Preserves foundation data and System Tenant
# 3. Re-seeds fresh demo environment
```

---

## 👥 Demo User Credentials

### Available Demo Users

| Email | Password | Role | Access Level |
|-------|----------|------|--------------|
| admin@demo.university.edu | demo123 | Admin | Full administrative access |
| surveyor1@demo.university.edu | demo123 | Surveyor | Survey creation and management |
| surveyor2@demo.university.edu | demo123 | Surveyor | Survey creation and management |
| manager@demo.university.edu | demo123 | Manager | Survey oversight and reporting |
| viewer@demo.university.edu | demo123 | Viewer | Read-only access to surveys |
| dev@spacewalker.ai | dev123 | Platform Super User | System-wide administrative access |

### User Role Capabilities

#### Admin Role
- Complete tenant administration
- User management and role assignment
- Survey approval and management
- System configuration access

#### Surveyor Role
- Survey creation and editing
- Photo upload and management
- Survey submission workflows
- Personal survey history

#### Manager Role
- Survey review and oversight
- Team survey management
- Reporting and analytics access
- Survey approval workflows

#### Viewer Role
- Read-only survey access
- Survey data viewing
- Report viewing capabilities
- No editing permissions

#### Platform Super User
- System-wide administrative access
- Multi-tenant management capabilities
- Platform configuration and monitoring
- Development and debugging tools

---

## 🚀 Implementation Benefits

### Multi-Tenant Safety
- **Isolated Operations** - Demo data operations affect only the demo tenant
- **Data Protection** - Production and other development tenant data remains untouched
- **Safe Defaults** - Default commands prioritize safety over convenience
- **Clear Boundaries** - Explicit separation between safe and destructive operations

### Development Experience
- **Non-Destructive Workflows** - Scripts can be run multiple times safely
- **Clear Command Names** - Explicit about what each command accomplishes
- **Comprehensive Scenarios** - `fresh_dev` and `quick_start` cover common developer needs
- **Incremental Updates** - Add demo data without losing existing development work

### Operational Excellence
- **Predictable Outcomes** - Scripts produce consistent results across environments
- **Documentation Updates** - All related documentation updated to use safe commands
- **Workflow Automation** - Justfile commands automate complex multi-step procedures
- **Error Prevention** - Reduced risk of accidental data loss during development

---

## 🎭 Testing and Demo Data Integration

### Demo Data Validation for Testing
The testing framework requires specific demo data configurations to ensure reliable test execution. Comprehensive validation ensures the testing environment meets all requirements.

#### Required Demo Data Structure
```bash
# E2E testing requires specific demo data counts
just demo_verify_e2e              # Validate all E2E testing requirements

# Expected demo data structure:
# - 100 surveys (mixed status: pending, approved, rejected)
# - 5 buildings (Demo University buildings)
# - 50 rooms (10 rooms per building average)
# - 4 user roles (admin, manager, super user, viewer)
# - 15+ demo images (room photos in MinIO)
```

#### Automated E2E Demo Data Validation
```typescript
// tests/e2e/shared/demo-data.ts - Automated validation
export async function validateDemoDataForE2E(page: Page) {
  const validations = [
    { name: 'surveys', expectedCount: 100, selector: '.survey-item' },
    { name: 'buildings', expectedCount: 5, selector: '.building-item' },
    { name: 'rooms', expectedCount: 50, selector: '.room-item' },
    { name: 'users', expectedCount: 4, selector: '.user-item' }
  ];

  for (const validation of validations) {
    await page.goto(`/${validation.name}`);
    await expect(page.locator(validation.selector)).toHaveCount(
      validation.expectedCount,
      { timeout: 30000 }
    );
  }
}
```

### E2E Testing Workflow Integration

#### Pre-Test Demo Data Setup
```bash
# Ensure demo data is ready for E2E testing
just fresh_dev                   # Complete environment reset
just demo_verify_e2e            # Validate E2E requirements
just test e2e admin             # Run E2E tests with validation

# Alternative: Quick setup for existing environment
just db seed               # Ensure full demo dataset
just demo_verify_e2e            # Confirm E2E requirements
```

#### Demo Data Reset for Test Isolation
```bash
# Between test suites that modify data
just db clean-all-non-system-tenants    # Remove ALL non-system tenant data
just db seed                    # Recreate full demo dataset
just demo_verify_e2e            # Validate before next test run

# Quick reset for specific data types
just db_demo_reset_surveys      # Reset survey data only
just db_demo_reset_buildings    # Reset building data only
```

### E2E Testing Environment Considerations

#### Data Consistency Across Environments
```bash
# Local development testing
TEST_ENVIRONMENT=local just test unit all

# Dev environment testing (requires consistent demo data)
TEST_ENVIRONMENT=dev just test unit all

# Staging environment testing
TEST_ENVIRONMENT=staging just test unit all
```

#### Demo Data Validation Commands
```bash
# Comprehensive demo data health check for E2E
just demo_verify_e2e             # Full validation with E2E requirements
just health                      # Overall system health including demo data
just demo_verify                 # Basic demo data validation

# Manual validation for specific E2E test requirements
curl http://localhost:8000/api/surveys?limit=1  # Check survey API
curl http://localhost:8000/api/buildings         # Check buildings API
```

### Troubleshooting E2E Demo Data Issues

#### Common E2E Demo Data Problems
```bash
# Problem: E2E tests fail due to insufficient demo data
# Solution: Ensure full demo dataset with verification
just db seed
just demo_verify_e2e

# Problem: Demo data counts don't match E2E expectations
# Solution: Reset to known good state
just fresh_dev
just demo_verify_e2e

# Problem: Images missing for room surveys
# Solution: Recreate demo data with image upload
just db seed  # Includes MinIO image upload in local dev
```

#### E2E Testing Best Practices with Demo Data
1. **Always validate demo data before running E2E tests**
2. **Use `demo_verify_e2e` command to ensure E2E requirements**
3. **Reset demo data between test suites that modify state**
4. **Use demo dataset (`db seed`) for comprehensive testing**
5. **Monitor demo data consistency across environments**

---

## 🔄 Workflow Integration

### Documentation Updates
As part of the safe demo data implementation, the following documentation has been updated to use safe commands:

- **[Getting Started Guide](../setup/getting-started.md)** - Updated to use `just fresh_dev` and safe seeding commands
- **[Quick Start Guide](../setup/quick-start.md)** - Updated workflows using `just quick_start` and safe commands
- **[Development Setup](../setup/development-setup.md)** - Comprehensive development environment configuration

### Command Integration
```bash
# Integrated with broader development workflows
just env_setup          # Environment setup
just fresh_dev          # Fresh development start (includes demo data)
just quick_start        # Resume development workflow
just test_with_demo     # Run tests against demo data
```

### Cross-System Impact
- **Backend Development** - Safe database operations for API testing
- **Admin Dashboard** - Consistent demo data for UI development and testing
- **Mobile Development** - Reliable demo data for offline sync testing
- **Integration Testing** - Predictable demo environment for automated tests

---

## 📋 Related Development Documentation

### Setup and Configuration
> 🛠️ **Environment Setup**: See [Development Environment Setup](../setup/development-setup.md) for complete development environment configuration
> 🛠️ **Database Setup**: See [Backend Development Guide](../backend/development/README.md) for database-specific development procedures

### Testing and Quality
- **[Testing Guide](./testing-guide.md)** - Strategies for testing against demo data environments
- **[Testing Strategy](../workflows/testing-strategy.md)** - Testing patterns for multi-tenant applications
- **[Testing Guide](./testing-guide.md)** - Comprehensive testing strategies for development environments

### E2E Testing Integration
- **[E2E Testing Framework](../../tests/docs/README.md)** - Complete E2E testing with demo data validation ⭐
- **[Demo Data Validation](../../tests/e2e/shared/demo-data.ts)** - Automated demo data validation for E2E tests
- **[Playwright Testing Gotchas](../gotchas/playwright-testing-gotchas.md)** - Demo data-related testing issues and solutions

### System Architecture Context
- **[Database Design](../backend/database-design.md)** - Understanding the multi-tenant database architecture
- **[System Architecture](../architecture/system-architecture.md)** - Cross-system data flow including demo data handling

---

**Status**: ✅ **PRODUCTION DEVELOPMENT WORKFLOWS**
**Last Updated**: 2025-06-29
**Scope**: Demo Data Management, Development Workflows, Multi-Tenant Safety
**Key Commands**: `just fresh_dev`, `just quick_start`, `just db seed`, `just db clean-all-non-system-tenants`

---

*This demo data management documentation provides essential workflows for safe development environment setup, ensuring robust multi-tenant data protection while maintaining excellent developer experience across all system components.*
