# CI Parallel Execution Plan

## Current State vs Proposed State

### Current CI Workflow (Sequential)
```
Start → Start Services → Wait for All Services → Run All Tests → Done
        (2 min)         (2 min)                  (5-10 min)
Total: ~10-15 minutes
```

### Proposed CI Workflow (Parallel)
```
Start ─┬→ Run Unit Tests (no services) ──────────────┐
       │  (2-5 seconds)                               │
       │                                              │
       ├→ Start PostgreSQL → Run DB Tests ───────────┤→ Aggregate Results
       │  (30 seconds)       (15-30 seconds)         │
       │                                              │
       └→ Start LocalStack → Run AWS Tests ──────────┘
          (60 seconds)       (45-60 seconds)

Total: ~2-3 minutes (vs 10-15 minutes)
```

## Implementation Strategy

### Phase 1: Update GitHub Actions Workflow

```yaml
name: CI/CD Pipeline (Optimized)

on:
  pull_request:
    branches: [dev, main]
  push:
    branches: [dev, main]

jobs:
  # Job 1: True unit tests (no dependencies)
  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: just install target=dev
      - name: Run unit tests
        run: just test unit backend --ci
      - name: Upload unit test results
        uses: actions/upload-artifact@v4
        with:
          name: unit-test-results
          path: .build/test-results/unit/

  # Job 2: Database integration tests
  db-integration-tests:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: spacewalker_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: just install target=dev
      - name: Run database migrations
        run: |
          cd apps/backend
          alembic upgrade head
      - name: Run DB integration tests
        run: just test integration backend --ci
      - name: Upload DB test results
        uses: actions/upload-artifact@v4
        with:
          name: db-test-results
          path: .build/test-results/db/

  # Job 3: Full integration tests (with LocalStack)
  aws-integration-tests:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: spacewalker_test
      localstack:
        # Use our optimized image once built
        image: ghcr.io/${{ github.repository_owner }}/spacewalker-localstack:latest
        ports:
          - 4566:4566
        env:
          SERVICES: s3,ses,secretsmanager
          SES_HEALTH_MODE: fast
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: just install target=dev
      - name: Wait for LocalStack (fast mode)
        run: |
          SES_HEALTH_MODE=fast timeout 60 bash scripts/localstack/check-localstack-health.sh
      - name: Initialize LocalStack services
        run: just localstack init
      - name: Run AWS integration tests
        run: just test integration backend --ci
        env:
          LOCALSTACK_HOSTNAME: localhost
      - name: Upload AWS test results
        uses: actions/upload-artifact@v4
        with:
          name: aws-test-results
          path: .build/test-results/aws/

  # Job 4: Aggregate results and report
  test-results:
    needs: [unit-tests, db-integration-tests, aws-integration-tests]
    runs-on: ubuntu-latest
    if: always()
    steps:
      - uses: actions/checkout@v4
      - name: Download all test results
        uses: actions/download-artifact@v4
        with:
          path: .build/test-results/
      - name: Aggregate test results
        run: |
          echo "## Test Results Summary" >> $GITHUB_STEP_SUMMARY
          echo "" >> $GITHUB_STEP_SUMMARY
          
          # Check each test type
          if [ -f .build/test-results/unit-test-results/junit.xml ]; then
            echo "✅ Unit Tests: Passed" >> $GITHUB_STEP_SUMMARY
          else
            echo "❌ Unit Tests: Failed" >> $GITHUB_STEP_SUMMARY
          fi
          
          if [ -f .build/test-results/db-test-results/junit.xml ]; then
            echo "✅ DB Integration Tests: Passed" >> $GITHUB_STEP_SUMMARY
          else
            echo "❌ DB Integration Tests: Failed" >> $GITHUB_STEP_SUMMARY
          fi
          
          if [ -f .build/test-results/aws-test-results/junit.xml ]; then
            echo "✅ AWS Integration Tests: Passed" >> $GITHUB_STEP_SUMMARY
          else
            echo "❌ AWS Integration Tests: Failed" >> $GITHUB_STEP_SUMMARY
          fi

  # Continue with existing admin, mobile tests...
  admin-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - name: Install dependencies
        run: just install target=dev
      - name: Run admin tests
        run: just test all admin --ci

  mobile-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - name: Install dependencies
        run: just install target=dev
      - name: Run mobile tests
        run: just test all mobile --ci
```

## Benefits of Parallel Execution

### Time Savings
- **Before**: 10-15 minutes sequential
- **After**: 2-3 minutes parallel
- **Improvement**: 70-80% faster

### Resource Utilization
- Better use of GitHub Actions runners
- Services only started when needed
- Reduced overall resource consumption

### Faster Feedback
- Unit test results in < 30 seconds
- DB test results in < 2 minutes
- Full results in < 3 minutes

## Migration Steps

### Step 1: Deploy Test Reorganization
✅ Move misclassified tests to proper directories
✅ Update test_manager.py with new flags
✅ Update documentation

### Step 2: Test New Commands Locally
```bash
# Verify each test suite works independently
just test unit backend
just test integration backend
```

### Step 3: Build LocalStack Base Image (Optional)
```bash
# Build and push optimized LocalStack image
docker build -f docker/localstack/Dockerfile -t spacewalker-localstack .
docker tag spacewalker-localstack ghcr.io/your-org/spacewalker-localstack:latest
docker push ghcr.io/your-org/spacewalker-localstack:latest
```

### Step 4: Update CI Configuration
1. Create new workflow file: `.github/workflows/ci-cd-parallel.yml`
2. Test in a feature branch
3. Monitor execution times and success rates
4. Once stable, replace existing workflow

### Step 5: Monitor and Optimize
- Track test execution times
- Identify bottlenecks
- Consider test sharding for large suites

## Rollback Plan

If issues arise, revert to sequential execution:
1. Keep existing workflow as backup
2. Can switch back by changing workflow trigger
3. Tests remain organized even if run sequentially

## Cost Considerations

### GitHub Actions Minutes
- Parallel jobs use more concurrent runners
- But total minutes are reduced due to faster completion
- Net result: Similar or lower cost

### Optimization Tips
- Use `paths` filters to skip irrelevant tests
- Cache dependencies aggressively
- Use matrix strategies for similar jobs

## Future Enhancements

### Phase 2: Test Sharding
Split large test suites across multiple workers:
```yaml
strategy:
  matrix:
    shard: [1, 2, 3, 4]
steps:
  - run: just test integration backend --shard ${{ matrix.shard }}/4
```

### Phase 3: Smart Test Selection
Only run tests affected by changes:
```bash
# Detect changed files
git diff --name-only origin/main...HEAD

# Map to affected tests
python scripts/test_impact_analysis.py

# Run only affected tests
just test unit backend --pattern="$AFFECTED_TESTS"
```

### Phase 4: Predictive Test Ordering
Run tests most likely to fail first for faster feedback.

## Metrics to Track

### Key Performance Indicators
- Average CI runtime
- P95 CI runtime
- Test success rate by type
- Time to first failure

### Success Criteria
- [ ] CI runtime < 5 minutes for 90% of runs
- [ ] Unit test results available in < 1 minute
- [ ] No increase in flaky test rate
- [ ] Developer satisfaction improved

## Related Documentation
- [Test Organization Guide](./test-organization-guide.md)
- [CI/CD Build Guide](./ci-cd-build-guide.md)
- [LocalStack Setup](../setup/localstack-setup.md)
- [GitHub Actions Best Practices](./github-actions-best-practices.md)
