# 🚀 GitHub Actions Cache Optimization Implementation Guide

## 📊 Current State Analysis

Your CI/CD workflow currently has a **significant cache inefficiency problem**:
- **Cache Size**: 205GB (extremely high)
- **Duplicate Entries**: 75+ cache entries with identical content
- **Mixed Dependencies**: Python and Node dependencies cached together
- **No Read-Only Access**: Test jobs create duplicate caches

## 🎯 Optimization Strategy

### 1. **Cache Separation** (Critical - 80% size reduction)
Separate Python and Node dependencies into distinct caches to avoid unnecessary storage and improve hit rates.

### 2. **Read-Only Cache Restoration** (Important - 15% reduction)
Use `actions/cache/restore@v4` for test jobs to prevent duplicate cache writes.

### 3. **Docker Layer Caching** (Nice to have - 5% reduction)
Implement GitHub Actions cache for Docker build layers.

### 4. **Version Suffix Update** (Immediate - Forces rebuild)
Change cache keys from `v2` to `v3` to invalidate old, bloated caches.

## 📝 Implementation Steps

### Step 1: Apply Automatic Optimizations

```bash
# Run the optimization script
chmod +x scripts/apply-cache-optimizations.py
python scripts/apply-cache-optimizations.py

# This will:
# - Update cache version suffixes to v3
# - Add optimization comments
# - Create a backup of your workflow
```

### Step 2: Manual Cache Separation

Update each job in `.github/workflows/ci-cd.yml` to use separate caches:

#### Setup Job (Primary Cache Writer)

```yaml
  setup:
    runs-on: ubuntu-latest
    outputs:
      python-cache-hit: ${{ steps.cache-python.outputs.cache-hit }}
      node-cache-hit: ${{ steps.cache-node.outputs.cache-hit }}
    steps:
      # ... checkout and setup steps ...

      # Python dependencies cache
      - name: Cache Python dependencies
        id: cache-python
        uses: actions/cache@v4
        with:
          path: |
            ~/.cache/pip
            ~/.local/bin
            .venv
          key: ${{ runner.os }}-python-v3-${{ hashFiles('**/requirements*.txt', '**/pyproject.toml') }}
          restore-keys: |
            ${{ runner.os }}-python-v3-

      # Node dependencies cache
      - name: Cache Node dependencies
        id: cache-node
        uses: actions/cache@v4
        with:
          path: |
            ~/.npm
            node_modules
            apps/*/node_modules
            packages/*/node_modules
          key: ${{ runner.os }}-node-v3-${{ hashFiles('**/package-lock.json', '**/yarn.lock') }}
          restore-keys: |
            ${{ runner.os }}-node-v3-

      # Install only if cache miss
      - name: Install Python dependencies
        if: steps.cache-python.outputs.cache-hit != 'true'
        run: |
          pip install uv
          just install  # Or your Python install command

      - name: Install Node dependencies
        if: steps.cache-node.outputs.cache-hit != 'true'
        run: |
          npm ci --prefer-offline --no-audit
```

#### Backend Test Jobs (Python Only)

```yaml
  test-backend:
    needs: [setup]
    runs-on: ubuntu-latest
    steps:
      # ... checkout and setup steps ...

      # IMPORTANT: Use restore-only for test jobs
      - name: Restore Python cache (read-only)
        uses: actions/cache/restore@v4
        with:
          path: |
            ~/.cache/pip
            ~/.local/bin
            .venv
          key: ${{ runner.os }}-python-v3-${{ hashFiles('**/requirements*.txt', '**/pyproject.toml') }}
          fail-on-cache-miss: true  # Ensure setup job ran first

      # No Node cache needed for backend tests!
```

#### Frontend Test Jobs (Node Only)

```yaml
  test-admin:
    needs: [setup]
    runs-on: ubuntu-latest
    steps:
      # ... checkout and setup steps ...

      # IMPORTANT: Use restore-only for test jobs
      - name: Restore Node cache (read-only)
        uses: actions/cache/restore@v4
        with:
          path: |
            ~/.npm
            node_modules
            apps/*/node_modules
            packages/*/node_modules
          key: ${{ runner.os }}-node-v3-${{ hashFiles('**/package-lock.json', '**/yarn.lock') }}
          fail-on-cache-miss: true  # Ensure setup job ran first

      # No Python cache needed for frontend tests!
```

#### Lint Job (Both Caches, Read-Only)

```yaml
  lint:
    needs: [setup]
    runs-on: ubuntu-latest
    steps:
      # ... checkout and setup steps ...

      # Restore both caches for linting
      - name: Restore Python cache (read-only)
        uses: actions/cache/restore@v4
        with:
          path: |
            ~/.cache/pip
            ~/.local/bin
            .venv
          key: ${{ runner.os }}-python-v3-${{ hashFiles('**/requirements*.txt', '**/pyproject.toml') }}
          fail-on-cache-miss: true

      - name: Restore Node cache (read-only)
        uses: actions/cache/restore@v4
        with:
          path: |
            ~/.npm
            node_modules
            apps/*/node_modules
            packages/*/node_modules
          key: ${{ runner.os }}-node-v3-${{ hashFiles('**/package-lock.json', '**/yarn.lock') }}
          fail-on-cache-miss: true

      # Additional cache for linting tools
      - name: Cache linting tools
        uses: actions/cache@v4
        with:
          path: |
            ~/.cache/ruff
            ~/.cache/mypy
            ~/.cache/eslint
          key: ${{ runner.os }}-lint-tools-v3-${{ hashFiles('.ruff.toml', '.eslintrc*', 'pyproject.toml') }}
```

### Step 3: Add Docker Layer Caching

For any Docker build jobs, add caching configuration:

```yaml
  build-docker:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        service: [backend, admin]
    steps:
      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Build and push Docker image
        uses: docker/build-push-action@v5
        with:
          context: .
          file: apps/${{ matrix.service }}/Dockerfile
          push: true
          tags: ${{ steps.ecr.outputs.registry }}/${{ matrix.service }}:latest
          # ADD THESE LINES FOR DOCKER CACHING
          cache-from: type=gha,scope=${{ matrix.service }}-${{ github.ref }}
          cache-to: type=gha,scope=${{ matrix.service }}-${{ github.ref }},mode=max
          build-args: |
            BUILDKIT_INLINE_CACHE=1
```

### Step 4: Mobile Build Caching (if applicable)

```yaml
  build-mobile:
    needs: [test-mobile]
    runs-on: ubuntu-latest
    steps:
      # Restore Node cache for mobile build
      - name: Restore Node cache (read-only)
        uses: actions/cache/restore@v4
        with:
          path: |
            ~/.npm
            node_modules
            apps/*/node_modules
          key: ${{ runner.os }}-node-v3-${{ hashFiles('**/package-lock.json', '**/yarn.lock') }}
          fail-on-cache-miss: true

      # Cache Expo/EAS artifacts
      - name: Cache Expo build artifacts
        uses: actions/cache@v4
        with:
          path: |
            ~/.expo
            apps/mobile/.expo
            apps/mobile/dist
            ~/.eas
          key: ${{ runner.os }}-expo-v3-${{ hashFiles('apps/mobile/app.json', 'apps/mobile/eas.json') }}

      # Cache Android Gradle
      - name: Cache Gradle
        uses: actions/cache@v4
        with:
          path: |
            ~/.gradle/caches
            ~/.gradle/wrapper
          key: ${{ runner.os }}-gradle-v3-${{ hashFiles('**/*.gradle*', '**/gradle.properties') }}
```

## 🔍 Verification Steps

### 1. Test in a Pull Request

```bash
# Create a test branch
git checkout -b test/cache-optimizations

# Apply changes
git add .github/workflows/ci-cd.yml
git commit -m "feat(ci): optimize GitHub Actions cache strategy"
git push origin test/cache-optimizations

# Create PR and monitor the CI run
```

### 2. Monitor Cache Usage

```bash
# Check cache usage via GitHub API
gh api "/repos/$GITHUB_REPOSITORY/actions/cache/usage" | jq

# List current caches
gh cache list

# Expected output after optimization:
# - Total size: < 10GB (down from 205GB)
# - Number of entries: 10-20 (down from 75+)
```

### 3. Verify Cache Hit Rates

Look for these messages in CI logs:
- ✅ "Cache restored from key: ubuntu-latest-python-v3-..."
- ✅ "Cache restored from key: ubuntu-latest-node-v3-..."
- ❌ "Cache not found for key..." (only on first run after v3 update)

## 📊 Expected Results

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Total Cache Size** | 205 GB | 5-10 GB | 95% reduction |
| **Cache Entries** | 75+ duplicates | 10-20 unique | 80% reduction |
| **Python Cache** | Mixed with Node | ~1-2 GB isolated | Cleaner |
| **Node Cache** | Mixed with Python | ~2-3 GB isolated | Cleaner |
| **Docker Layers** | Not cached | ~1-2 GB cached | Faster builds |
| **CI Speed** | Baseline | 20-30% faster | Better hit rate |
| **Monthly Cost** | High storage fees | Minimal | Significant savings |

## 🚨 Important Notes

### First Run After Implementation
- **Will be slower**: All caches need to rebuild due to v3 suffix
- **Expected behavior**: "Cache not found" messages are normal
- **Duration**: ~10-15 minutes longer than usual
- **Result**: Clean, optimized caches for future runs

### Cache Key Strategy
- **Version suffix** (`v3`): Increment when you need to force rebuild
- **Hash files**: Include all relevant dependency files
- **Restore keys**: Allow partial matches for better hit rates

### Maintenance
- **Weekly cleanup**: Consider adding a scheduled workflow to prune old caches
- **Monitor size**: Check cache usage weekly
- **Update keys**: Increment version suffix if cache gets corrupted

## 🎯 Quick Checklist

- [ ] Run `apply-cache-optimizations.py` script
- [ ] Separate Python and Node caches in setup job
- [ ] Convert test jobs to use `cache/restore@v4`
- [ ] Add `fail-on-cache-miss: true` to restore steps
- [ ] Add Docker layer caching configuration
- [ ] Update mobile build caching (if applicable)
- [ ] Test changes in a pull request
- [ ] Monitor cache metrics after merge
- [ ] Document any custom cache patterns

## 📚 Additional Resources

- [GitHub Actions Cache Documentation](https://docs.github.com/en/actions/using-workflows/caching-dependencies-to-speed-up-workflows)
- [Cache Restore Action](https://github.com/actions/cache/blob/main/restore/README.md)
- [Docker Build Cache](https://docs.docker.com/build/ci/github-actions/cache/)
- [Optimizing CI/CD Performance](https://github.blog/2022-12-14-optimizing-ci-cd-performance/)

## 💡 Pro Tips

1. **Cache Hierarchy**: Setup job writes → Test jobs read → No duplicates
2. **Granular Keys**: Separate caches = better hit rates
3. **Restore Keys**: Use prefixes for fallback matching
4. **Version Bumping**: Change suffix to force cache rebuild
5. **Monitoring**: Check cache metrics weekly

## 🆘 Troubleshooting

### Cache Not Found Errors
```yaml
# Add restore-keys for partial matches
restore-keys: |
  ${{ runner.os }}-python-v3-
  ${{ runner.os }}-python-
```

### Dependencies Not Installing
```yaml
# Ensure setup job completes first
needs: [setup]
```

### Cache Too Large
- Split into smaller, more specific caches
- Exclude unnecessary directories
- Use `.cacheignore` patterns

### Duplicate Caches Still Created
- Verify all test jobs use `cache/restore@v4`
- Check that only setup job uses `cache@v4`

## ✅ Success Criteria

You'll know the optimization is successful when:
1. GitHub cache usage drops below 10GB
2. No duplicate cache entries with identical content
3. CI jobs show consistent cache hits
4. Test jobs don't create new cache entries
5. Docker builds are 30-50% faster
6. Overall CI time reduced by 20-30%

## 🎉 Conclusion

These optimizations will transform your CI/CD cache from a 205GB bloated mess into a lean, efficient 5-10GB system. The key improvements are:

1. **Separation**: Python and Node caches are independent
2. **Read-only**: Test jobs can't create duplicates
3. **Docker caching**: Build layers are preserved
4. **Version control**: Easy cache invalidation with suffixes

Implement these changes incrementally, test thoroughly, and monitor the results. Your CI/CD pipeline will be faster, cheaper, and more maintainable!