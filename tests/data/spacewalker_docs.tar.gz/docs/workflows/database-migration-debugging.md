# Database Migration Debugging Workflows

**SpaceWalker Backend** - Comprehensive guide to debugging database migration issues in development and production environments

---

## 📋 Overview

This guide provides systematic approaches to debugging database migration issues, including:
- **Migration state diagnosis** and validation
- **Failed migration recovery** procedures
- **Environment-specific debugging** techniques
- **Emergency migration fixes** for production systems
- **Automated debugging tools** and scripts

**Common Migration Issues:**
- Orphaned migration references
- Failed container deployments due to migration errors
- Inconsistent migration states between environments
- Missing migration files
- Database connection issues during migration

---

## 🎯 Quick Diagnosis Commands

### Essential Status Check
```bash
# 1. Check overall database connectivity and migration status
python3 scripts/database/db_helper.py --env dev migration-status

# 2. Check ECS service health (if deployment related)
just health dev

# 3. Check container logs for migration errors
just aws_logs dev 10 | grep -E "(migration|alembic|database)"
```

### Migration State Validation
```bash
# Check current migration in database
psql "postgresql://user:pass@host:5432/spacewalker" -c "SELECT version_num FROM alembic_version;"

# List all migration files
ls -la apps/backend/alembic/versions/ | head -10

# Check if specific migration exists in codebase
find apps/backend -name "*4af652f4b4db*" -type f
```

---

## 🔧 Debugging Procedures

### 1. Migration State Analysis

#### Check Database Migration Table
```bash
# Connect via bastion (production/staging)
python3 scripts/database/db_helper.py --env prod migration-status

# Direct database connection (local)
psql "postgresql://localhost:5432/spacewalker_dev" -c "
SELECT
    version_num as current_migration,
    NOW() - '2025-07-18 12:30:00'::timestamp as time_since_last_fix
FROM alembic_version
ORDER BY version_num;
"
```

#### Compare with Codebase
```bash
# List migrations in order
ls -la apps/backend/alembic/versions/*.py | sort

# Find latest migration file
LATEST_MIGRATION=$(ls apps/backend/alembic/versions/*.py | sort | tail -1)
echo "Latest migration file: $LATEST_MIGRATION"

# Extract migration ID from filename
basename "$LATEST_MIGRATION" | cut -d'_' -f1
```

### 2. Container Deployment Debugging

#### ECS Task Analysis
```bash
# Check failed tasks in ECS cluster
aws ecs list-tasks --cluster dev-spacewalker-ecs-cluster --desired-status STOPPED \
  --region us-east-2 | jq -r '.taskArns[]' | head -5

# Get task details and exit codes
aws ecs describe-tasks --cluster dev-spacewalker-ecs-cluster \
  --tasks $(aws ecs list-tasks --cluster dev-spacewalker-ecs-cluster --desired-status STOPPED --region us-east-2 | jq -r '.taskArns[0]') \
  --region us-east-2 | jq -r '.tasks[0] | {lastStatus, stopCode, exitCode: .containers[0].exitCode}'
```

#### Container Startup Logs
```bash
# Get startup logs from failed containers
aws logs get-log-events --log-group-name /ecs/dev-spacewalker-backend \
  --log-stream-name backend/backend/TASK_ID \
  --start-time $(date -u -d '1 hour ago' +%s)000 \
  --region us-east-2 | jq -r '.events[] | .message' | grep -E "(Migration|alembic|Failed|Error)"
```

### 3. Migration File Validation

#### Check Migration File Integrity
```bash
# Validate Python syntax in migration files
python3 -m py_compile apps/backend/alembic/versions/*.py

# Check for missing imports or syntax errors
cd apps/backend
python3 -c "
import sys
sys.path.append('.')
from alembic.config import Config
from alembic import command
config = Config('alembic.ini')
command.check(config)
"
```

#### Migration Dependency Analysis
```bash
# Check migration chain for breaks
cd apps/backend
alembic history --verbose | head -20

# Check for duplicate migration IDs
find alembic/versions -name "*.py" -exec grep -l "revision = " {} \; | \
  xargs grep "revision = " | sort | uniq -d
```

---

## 🚨 Emergency Recovery Procedures

### Scenario 1: Orphaned Migration Reference

**Symptoms**:
- Container exits with code 255
- Migration error: "Can't locate revision identified by 'MIGRATION_ID'"
- ECS deployment fails repeatedly

**Diagnosis**:
```bash
# 1. Check which migration is causing issues
python3 scripts/database/db_helper.py --env dev migration-status

# 2. Verify migration doesn't exist in codebase
find apps/backend -name "*PROBLEMATIC_MIGRATION_ID*" -type f

# 3. Check if migration is referenced in alembic_version table
psql "connection_string" -c "SELECT * FROM alembic_version WHERE version_num = 'PROBLEMATIC_MIGRATION_ID';"
```

**Resolution**:
```bash
# 1. Create emergency fix script
cat > fix-orphaned-migration.sql << 'EOF'
-- Remove orphaned migration reference
DELETE FROM alembic_version WHERE version_num = 'PROBLEMATIC_MIGRATION_ID';

-- Set to latest known good migration
INSERT INTO alembic_version (version_num)
SELECT 'LATEST_GOOD_MIGRATION_ID'
WHERE NOT EXISTS (SELECT 1 FROM alembic_version);

-- Verify final state
SELECT version_num, NOW() as fixed_at FROM alembic_version;
EOF

# 2. Execute via bastion
python3 scripts/database/db_helper.py --env dev tunnel &
TUNNEL_PID=$!
sleep 5

psql "postgresql://spacewalker_user:password@localhost:5433/spacewalker" -f fix-orphaned-migration.sql

kill $TUNNEL_PID

# 3. Trigger new deployment
just aws_deploy_backend dev
```

### Scenario 2: Failed Migration During Deployment

**Symptoms**:
- Deployment starts but never reaches stable state
- Migration timeout errors
- Database lock issues

**Diagnosis**:
```bash
# 1. Check for active migration locks
python3 scripts/database/db_helper.py --env dev migration-status

# 2. Look for long-running migration processes
psql "connection_string" -c "
SELECT pid, state, query_start, query
FROM pg_stat_activity
WHERE query LIKE '%alembic%' OR query LIKE '%migration%';
"

# 3. Check migration timeout settings
grep -r "MIGRATION_TIMEOUT" apps/backend/
```

**Resolution**:
```bash
# 1. Kill stuck migration processes (if safe)
psql "connection_string" -c "
SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE query LIKE '%alembic%' AND state = 'active' AND query_start < NOW() - INTERVAL '10 minutes';
"

# 2. Reset migration state if needed
psql "connection_string" -c "
DELETE FROM alembic_version WHERE version_num NOT IN (
  SELECT version_num FROM (
    SELECT version_num, ROW_NUMBER() OVER (ORDER BY version_num DESC) as rn
    FROM alembic_version
  ) t WHERE rn = 1
);
"

# 3. Restart deployment
just aws_deploy_backend dev
```

### Scenario 3: Environment Migration Drift

**Symptoms**:
- Different migration states between dev/staging/prod
- Deployment works in one environment but not others
- Inconsistent database schemas

**Diagnosis**:
```bash
# 1. Compare migration states across environments
for env in dev staging prod; do
  echo "=== $env ==="
  python3 scripts/database/db_helper.py --env $env migration-status
done

# 2. Generate schema comparison
pg_dump --schema-only "dev_connection" > /tmp/dev_schema.sql
pg_dump --schema-only "prod_connection" > /tmp/prod_schema.sql
diff /tmp/dev_schema.sql /tmp/prod_schema.sql
```

**Resolution**:
```bash
# 1. Determine target migration state (usually production)
TARGET_MIGRATION=$(python3 scripts/database/db_helper.py --env prod migration-status | grep "current_migration" | awk '{print $1}')

# 2. Update other environments to match
for env in dev staging; do
  echo "Updating $env to migration: $TARGET_MIGRATION"
  python3 scripts/database/db_helper.py --env $env tunnel &
  TUNNEL_PID=$!
  sleep 5

  psql "postgresql://spacewalker_user:password@localhost:5433/spacewalker" -c "
  DELETE FROM alembic_version;
  INSERT INTO alembic_version (version_num) VALUES ('$TARGET_MIGRATION');
  "

  kill $TUNNEL_PID
done

# 3. Verify consistency
for env in dev staging prod; do
  python3 scripts/database/db_helper.py --env $env migration-status
done
```

---

## 🛠️ Debugging Tools and Scripts

### Custom Database Helper Usage

#### Migration Status Check
```bash
# Comprehensive migration status
python3 scripts/database/db_helper.py --env dev migration-status

# Output includes:
# - Current migration version
# - Advisory lock status
# - Database connection info
# - Migration table existence
```

#### Database Tunnel Management
```bash
# Create secure tunnel to database
python3 scripts/database/db_helper.py --env dev tunnel

# Test tunnel connection
python3 scripts/database/db_helper.py --env dev test

# Kill existing tunnels
python3 scripts/database/db_helper.py --env dev kill-tunnels
```

### Manual Migration Commands

#### Safe Migration Operations
```bash
# 1. Navigate to backend directory
cd apps/backend

# 2. Check current migration
alembic current

# 3. Show migration history
alembic history --verbose

# 4. Upgrade to specific migration (if needed)
alembic upgrade head

# 5. Downgrade (DANGEROUS - use only in development)
alembic downgrade -1
```

#### Migration File Generation
```bash
# Create new migration
cd apps/backend
alembic revision --autogenerate -m "Description of changes"

# Create empty migration
alembic revision -m "Manual migration description"

# Edit migration file before running
# vim alembic/versions/GENERATED_MIGRATION_FILE.py
```

### AWS-Specific Debugging

#### ECS Service Investigation
```bash
# Check service status and events
aws ecs describe-services --cluster dev-spacewalker-ecs-cluster \
  --services dev-spacewalker-backend --region us-east-2 | \
  jq -r '.services[0].events[0:5] | .[] | "\(.createdAt): \(.message)"'

# Check task definition details
aws ecs describe-task-definition --task-definition dev-spacewalker-backend \
  --region us-east-2 | jq -r '.taskDefinition.containerDefinitions[0].environment[]'
```

#### RDS Connection Validation
```bash
# Test RDS connectivity from ECS
aws rds describe-db-instances --region us-east-2 | \
  jq -r '.DBInstances[] | select(.DBName=="spacewalker") | .Endpoint.Address'

# Check security group rules
aws ec2 describe-security-groups --group-names "*rds*" --region us-east-2 | \
  jq -r '.SecurityGroups[].IpPermissions[]'
```

---

## 📊 Monitoring and Prevention

### Proactive Migration Monitoring

#### CI/CD Pipeline Checks
```bash
# Add to deployment scripts
#!/bin/bash
set -euo pipefail

echo "Pre-deployment migration validation..."

# 1. Check migration files syntax
python3 -m py_compile apps/backend/alembic/versions/*.py

# 2. Validate migration chain
cd apps/backend && alembic check

# 3. Test migration in isolated environment
echo "Migration validation complete ✅"
```

#### Database Health Monitoring
```bash
# Regular health check script
#!/bin/bash
for env in dev staging prod; do
  echo "=== Migration Health Check: $env ==="

  # Check migration status
  CURRENT=$(python3 scripts/database/db_helper.py --env $env migration-status | grep current_migration | awk '{print $1}')

  # Check for advisory locks
  LOCKS=$(python3 scripts/database/db_helper.py --env $env migration-status | grep "No migration locks" || echo "LOCKS DETECTED")

  echo "Current migration: $CURRENT"
  echo "Lock status: $LOCKS"
  echo ""
done
```

### Best Practices for Migration Safety

#### Development Workflow
```bash
# 1. Always test migrations locally first
cd apps/backend
alembic upgrade head

# 2. Backup before migration (production)
pg_dump "production_connection" > backup_$(date +%Y%m%d_%H%M%S).sql

# 3. Use transaction-safe migrations
# Add to migration file:
# revision = 'new_migration_id'
# down_revision = 'previous_migration_id'
#
# def upgrade():
#     with op.batch_alter_table('table_name') as batch_op:
#         batch_op.add_column(sa.Column('new_column', sa.String(100)))

# 4. Test rollback capability (development only)
alembic downgrade -1
alembic upgrade head
```

#### Production Deployment Checklist
```bash
# Pre-deployment checklist
[ ] Migration tested in development
[ ] Migration tested in staging
[ ] Database backup created
[ ] Migration rollback plan documented
[ ] Downtime window communicated (if needed)
[ ] Monitoring alerts configured
[ ] Emergency contact list ready

# Post-deployment verification
[ ] Migration completed successfully
[ ] Application health checks passing
[ ] Database performance acceptable
[ ] No error logs in application
[ ] User-facing functionality working
```

---

## 📚 Related Documentation

- **[Database Design](../backend/database-design.md)** - Database design and schema documentation
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Comprehensive deployment procedures
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General troubleshooting procedures
- **[Production Monitoring](../workflows/production-monitoring-deployment.md)** - Production monitoring setup
- **[Environment Setup](../setup/environment-configuration.md)** - Database connection configuration

---

## 🏷️ Metadata

**Version**: 1.0.0
**Last Updated**: 2025-07-18
**Maintainer**: Backend Development Team
**Status**: Production Ready

**Keywords**: database, migration, alembic, debugging, ECS, RDS, troubleshooting, recovery
