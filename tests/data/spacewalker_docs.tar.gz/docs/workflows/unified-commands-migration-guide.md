# Unified Commands Migration Guide

## Overview
This guide helps you migrate from old individual commands to the new unified `u_` commands that provide consistent interfaces across the codebase.

## Core Unified Commands

### 1. Testing Commands (`test`)
Replaces 40+ individual test commands with a single unified interface.

| Old Command | New Command |
|------------|-------------|
| `just test_unit` | `just test unit all` |
| `just test_unit_backend` | `just test unit backend` |
| `just test_unit_admin` | `just test unit admin` |
| `just test_unit_mobile` | `just test unit mobile` |
| `just test_integration` | `just test integration all` |
| `just test_integration_backend` | `just test integration backend` |
| `just test_system` | `just test system backend` |
| `just test_all` | `just test all all` |
| `just test_backend_case <pattern>` | `just test unit backend --pattern=<pattern>` |

### 2. Linting Commands (`lint`)
Unified interface for all code quality operations.

| Old Command | New Command |
|------------|-------------|
| `just lint` | `just lint check all` |
| `just lint_backend` | `just lint check backend` |
| `just lint_admin` | `just lint check admin` |
| `just lint_mobile` | `just lint check mobile` |
| `just lint_ci` | `just lint check all --ci` |
| `just format` | `just lint format all` |
| `just format_backend` | `just lint format backend` |
| `just format_admin` | `just lint format admin` |
| `just format_mobile` | `just lint format mobile` |

### 3. Database Commands (`db`)
Simplified database management interface.

| Old Command | New Command | Notes |
|------------|-------------|-------|
| `just db_status` | `just db verify` | Check database state |
| `just db_validate` | `just db verify` | Validate consistency |
| `just db_migrate` | `alembic upgrade head` | Run in backend directory |
| `just db_demo` | `just db seed` | Load demo data |
| `just db_init` | `just db init` | Initialize database |
| `just db_shell` | `just db shell` | Interactive PostgreSQL shell |
| `just shell db` | `just db shell` | Access database shell |

### 3.1 Database Shell & SQL Commands
Direct database access with safety features.

| Old Command | New Command | Notes |
|------------|-------------|-------|
| `just db_shell` | `just db shell` | Interactive PostgreSQL shell |
| N/A | `just sql "SELECT..."` | Execute SQL queries safely |
| N/A | `just sql "UPDATE..." --write` | Write operations require flag |

**Examples:**
```bash
# Interactive shell access
just db shell              # Local environment
just db shell dev          # Development
just db shell prod         # Production (read-only)

# Execute SQL queries
just sql "SELECT * FROM users LIMIT 5"
just sql "SELECT COUNT(*) FROM buildings" dev
just sql "UPDATE users SET active=true" --write
just sql "SELECT * FROM tenants" --format=json
```

### 4. Health & Status Commands
Unified health checking and URL management.

| Old Command | New Command |
|------------|-------------|
| `just aws_health <env>` | `just health <env>` |
| `just aws_urls <env>` | `just urls <env>` |
| `just health` | `just health local` |

### 5. Service Management (`service`)
Unified Docker service management.

| Old Command | New Command | Notes |
|------------|-------------|-------|
| `just up` | `just service up all` | Start all services |
| `just down` | `just service down all` | Stop services in current directory |
| Multiple manual steps | `just down everywhere` | Stop containers in main repo + all worktrees (idempotent) |
| `just restart <service>` | `just service restart <service>` | Restart specific service |
| `just build` | `just service build all` | Build all services |

### 6. Log Management (`logs`)
Consolidated log viewing across all services.

| Old Command | New Command |
|------------|-------------|
| `just logs` | `just logs all local` |
| `just logs_backend` | `just logs backend local` |
| `just logs_admin` | `just logs admin local` |
| `just logs_mobile` | `just logs mobile local` |
| `just aws_logs <env>` | `just logs all <env>` |

### 7. Deployment Management (`u_deploy`)
Unified deployment interface for all AWS services.

| Old Command | New Command | Notes |
|------------|-------------|-------|
| `just aws_deploy_backend dev` | `just aws deploy backend dev` | Deploy backend |
| `just aws_deploy_admin dev` | `just aws deploy admin dev` | Deploy admin |
| `just aws_deploy_mobile dev` | `just aws deploy mobile dev` | Deploy mobile |
| `just aws_status dev` | `just aws status all dev` | Check deployment status |
| Multiple commands | `just aws recover dev` | Smart recovery |

### 8. Secrets Management (`secrets`)
Unified AWS Secrets Manager interface.

| Old Command | New Command | Notes |
|------------|-------------|-------|
| `aws secretsmanager list-secrets` | `just secrets list dev` | List all secrets |
| `aws secretsmanager get-secret-value` | `just secrets show dev --secret-name api-keys` | Show secret (masked) |
| Multiple commands | `just secrets health dev` | Check all secrets exist |
| Manual process | `just secrets create dev --dry-run` | Show creation commands |

### 9. CloudFormation Stack Management (`u_stack_*`)
Unified CloudFormation operations with automatic AWS profile/region handling.

| Old Command | New Command | Notes |
|------------|-------------|-------|
| `aws cloudformation describe-stacks` | `just stack status dev` | All stacks status |
| `aws cloudformation describe-stack-events` | `just stack events dev backend` | Stack events |
| `aws cloudformation list-exports` | `just stack exports dev` | Stack exports |
| `aws cloudformation describe-stack-resources` | `just stack resources dev backend` | Stack resources |
| `aws cloudformation delete-stack` | `just stack delete dev backend` | Delete stack |
| Multiple AWS commands | `just stack inspect dev backend` | Comprehensive view |

**Examples:**
```bash
# Check all stacks
just stack status dev

# Inspect specific stack
just stack inspect dev backend

# View recent events
just stack events dev backend 20

# Delete all stacks in order
just stack delete dev all
```

## Migration Tips

### 1. Use Help to Discover Commands
```bash
just help | grep u_        # Find all unified commands
just test help          # Get help for specific command
```

### 2. Common Patterns
- All unified commands start with `u_` prefix
- Environment defaults to `local` if not specified
- Use `all` to target all services/repos
- Options use `--` prefix (e.g., `--pattern=test_auth`)

### 3. Backward Compatibility
Most old commands still exist but are marked as deprecated. They will be removed in a future release.

### 4. CI/CD Updates
Update your CI/CD pipelines to use the new commands:
```yaml
# Old
- run: just lint_ci
- run: just test_unit

# New
- run: just lint check all --ci
- run: just test unit all
```

## Benefits of Unified Commands

1. **Consistency**: Same patterns across all operations
2. **Discoverability**: Easier to find and understand commands
3. **Flexibility**: More options and better parameter handling
4. **Maintainability**: Fewer commands to maintain
5. **Extensibility**: Easy to add new features

## Need Help?

- Run `just help` to see all available commands
- Check individual command help: `just test help`
- Review the [Unified Test Commands Guide](./unified-test-commands.md)
- See the [Justfile Workflow Guide](../claude-components/justfile-workflow.md)
