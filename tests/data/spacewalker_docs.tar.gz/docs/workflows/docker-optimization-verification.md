# Docker Base Image Optimization - Verification Guide

## Overview

This guide provides comprehensive verification procedures for the Docker base image optimization. Use these procedures to validate the optimization's effectiveness, safety, and proper implementation.

## Quick Verification Workflow

For immediate validation of the optimization:

```bash
# 1. Environment startup
just up                               # Start all services with optimized images
just health dev                       # Verify all services are healthy

# 2. Functional validation
just test unit all                    # Run all unit tests
just test integration all             # Validate integration functionality

# 3. Performance validation
just dev_cycle                        # Quick lint + unit test cycle (30-60 sec)
```

## Comprehensive Verification Procedures

### 1. Build Performance Verification

#### Measure Build Times
```bash
# Baseline measurement (if available)
# git checkout previous-version-without-optimization
# time docker build -f apps/backend/Dockerfile .

# Current optimized measurement
time docker build apps/backend/ --progress=plain 2>&1 | tee .build/tmp/backend-build-log.txt
time docker build apps/admin/ --progress=plain 2>&1 | tee .build/tmp/admin-build-log.txt

# Analyze build stages
grep "DONE" .build/tmp/backend-build-log.txt | tail -10
grep "DONE" .build/tmp/admin-build-log.txt | tail -10
```

#### Expected Performance Improvements
- **Backend**: Build time should be ~8-12 minutes (vs 43+ minutes previously)
- **Admin**: Build time should be ~6-10 minutes (vs 35+ minutes previously)
- **Overall pipeline**: 65-80% reduction in total build time

#### Build Stage Analysis
```bash
# Verify build caching is working
docker buildx build --progress=plain apps/backend/ 2>&1 | grep "CACHED"

# Check base image usage
docker images | grep spacewalker-python-base
docker images | grep spacewalker-node-base
```

### 2. Functional Equivalence Verification

#### Application Functionality
```bash
# Backend API verification
curl -H "Content-Type: application/json" \
  backend.spacewalker.littleponies.com/health

# Admin dashboard verification
curl admin.spacewalker.littleponies.com/health

# Database connectivity
just db verify
```

#### Authentication Flow
```bash
# Test user login (with test credentials)
curl -X POST backend.spacewalker.littleponies.com/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"dev@spacecargo.ai","password":"dev123"}'

# Verify token validation
# (Use token from login response)
curl -H "Authorization: Bearer <token>" \
  backend.spacewalker.littleponies.com/users/me
```

#### Core Workflows
Test key application workflows:
1. **User registration and login**
2. **Building creation and management**
3. **Room and floor management**
4. **Survey data processing**
5. **Admin dashboard functionality**

### 3. Image Security Verification

#### Vulnerability Scanning
```bash
# Scan optimized images for vulnerabilities
docker scout cves spacewalker-backend:latest
docker scout cves spacewalker-admin:latest

# Compare with base images
docker scout cves python:3.12.1-slim
docker scout cves node:20.19.4-alpine
```

#### Image Analysis
```bash
# Analyze image layers
docker history spacewalker-backend:latest
docker history spacewalker-admin:latest

# Check image sizes
docker images | grep spacewalker

# Verify no sensitive data in images
docker run --rm spacewalker-backend:latest env | grep -E "(SECRET|PASSWORD|KEY)"
```

### 4. Runtime Performance Verification

#### Container Startup Times
```bash
# Measure container startup
time docker run --rm spacewalker-backend:latest echo "ready"
time docker run --rm spacewalker-admin:latest echo "ready"

# Service readiness check
just up
time just wait dev  # Measure time to all services ready
```

#### Memory and Resource Usage
```bash
# Monitor resource usage during startup
docker stats --no-stream

# Check memory footprint after startup
docker stats --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}" --no-stream
```

#### Network Performance
```bash
# API response times
time curl backend.spacewalker.littleponies.com/health
time curl admin.spacewalker.littleponies.com/health

# Database connection performance
time just sql "SELECT 1"
```

### 5. Development Workflow Verification

#### Local Development
```bash
# Verify hot reloading works
just up
# Make code change and verify reload

# Development cycle performance
time just dev_cycle  # Should complete in 30-60 seconds

# Build consistency
just clean && just up  # Verify clean build works
```

#### CI/CD Pipeline
```bash
# Verify GitHub Actions work with optimization
# Check latest workflow runs at:
# https://github.com/your-org/spacewalker/actions

# Local pipeline simulation
just test all all                     # Full test suite
just lint check all                   # Code quality checks
```

### 6. Base Image Versioning Verification

#### Version Consistency
```bash
# Check current base image versions
docker images | grep -E "(python-base|node-base)"

# Verify version in running containers
docker exec spacewalker-backend env | grep DOCKER_BUILD
docker exec spacewalker-admin env | grep DOCKER_BUILD
```

#### Version Coordination Test
```bash
# Test with specific base image version
export BASE_IMAGE_VERSION=2025.07.30-abc1234
docker build --build-arg BASE_IMAGE_VERSION=$BASE_IMAGE_VERSION apps/backend/

# Verify version is used
docker run --rm spacewalker-backend:latest env | grep BASE_IMAGE_VERSION
```

## Verification Checklists

### Pre-Deployment Checklist
- [ ] Build times improved by expected percentage (65-80%)
- [ ] All unit tests pass: `just test unit all`
- [ ] All integration tests pass: `just test integration all`
- [ ] Services start successfully: `just up && just health dev`
- [ ] No new security vulnerabilities: `docker scout cves`
- [ ] Memory usage within expected range
- [ ] API endpoints respond correctly
- [ ] Authentication flows work properly

### Post-Deployment Checklist
- [ ] Production deployment successful
- [ ] All health checks passing: `just health prod`
- [ ] Performance metrics within range
- [ ] No error rate increase
- [ ] User workflows functioning normally
- [ ] Monitoring dashboards show normal behavior

### Performance Regression Checklist
- [ ] Build times haven't regressed
- [ ] Container startup times stable
- [ ] API response times unchanged
- [ ] Memory usage stable
- [ ] No performance alerts triggered

## Troubleshooting Verification Issues

### Build Failures
```bash
# Check base image availability
docker pull $ECR_REGISTRY/$ENVIRONMENT-spacewalker-python-base:latest
docker pull $ECR_REGISTRY/$ENVIRONMENT-spacewalker-node-base:latest

# Verify build arguments are passed correctly
docker build --build-arg ECR_REGISTRY=test apps/backend/ --dry-run

# Check for base image workflow completion
# GitHub Actions → "Build Base Images" workflow
```

### Functional Issues
```bash
# Compare with previous version
git log --oneline -10  # Find previous working commit
git checkout <previous-commit>
just up && just test unit all  # Verify baseline works
git checkout -  # Return to current

# Isolate the issue
docker logs spacewalker-backend
docker logs spacewalker-admin
just logs backend dev
```

### Performance Issues
```bash
# Profile build performance
docker build --progress=plain apps/backend/ > .build/tmp/build-profile.log 2>&1
grep -E "(FROM|RUN|COPY)" .build/tmp/build-profile.log

# Compare resource usage
docker stats --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}"

# Network performance analysis
curl -w "@curl-format.txt" backend.spacewalker.littleponies.com/health
```

## Automated Verification Scripts

### Quick Health Check
```bash
#!/bin/bash
# save as scripts/verify-optimization.sh

set -e

echo "🚀 Starting Docker Optimization Verification..."

# Build verification
echo "📦 Building optimized images..."
docker build apps/backend/ -t test-backend
docker build apps/admin/ -t test-admin

# Functional verification
echo "🔧 Starting services..."
just up
sleep 30

echo "🏥 Health checks..."
just health dev

echo "🧪 Running tests..."
just test unit all

echo "✅ Verification completed successfully!"
```

### Performance Benchmark
```bash
#!/bin/bash
# save as scripts/benchmark-builds.sh

set -e

echo "⏱️  Benchmarking build performance..."

# Backend build
echo "Building backend..."
start_time=$(date +%s)
docker build apps/backend/ > /dev/null 2>&1
end_time=$(date +%s)
backend_time=$((end_time - start_time))

# Admin build
echo "Building admin..."
start_time=$(date +%s)
docker build apps/admin/ > /dev/null 2>&1
end_time=$(date +%s)
admin_time=$((end_time - start_time))

echo "📊 Build Performance Results:"
echo "Backend: ${backend_time}s"
echo "Admin: ${admin_time}s"
echo "Total: $((backend_time + admin_time))s"

# Performance thresholds
if [ $backend_time -lt 720 ]; then  # 12 minutes
  echo "✅ Backend build time acceptable"
else
  echo "⚠️  Backend build time concerning"
fi

if [ $admin_time -lt 600 ]; then  # 10 minutes
  echo "✅ Admin build time acceptable"
else
  echo "⚠️  Admin build time concerning"
fi
```

## Verification Evidence Documentation

When documenting verification results, include:

### Build Performance Evidence
```
✅ Build Performance Verified:
- Backend: 43 minutes → 8 minutes (81% improvement)
- Admin: 35 minutes → 6 minutes (83% improvement)
- Total pipeline: 78 minutes → 14 minutes (82% improvement)
```

### Functional Verification Evidence
```
✅ Functional Verification Completed:
- All unit tests pass: 145/145 ✅
- All integration tests pass: 23/23 ✅
- Health checks pass: backend ✅, admin ✅, mobile ✅
- Authentication flows verified ✅
- Core workflows tested ✅
```

### Security Verification Evidence
```
✅ Security Verification Completed:
- No new vulnerabilities introduced
- Image scan results: 0 critical, 0 high, 2 medium (same as baseline)
- No sensitive data in optimized images
- Base image security posture maintained ✅
```

## Continuous Verification

### Automated Monitoring
- **CI/CD Integration**: Every build verifies optimization effectiveness
- **Performance Monitoring**: Track build times and resource usage trends
- **Security Scanning**: Automated vulnerability scans on image updates
- **Health Monitoring**: Continuous service health validation

### Manual Verification Schedule
- **Weekly**: Performance benchmarking and trend analysis
- **Monthly**: Comprehensive security and functionality review
- **Quarterly**: Full optimization effectiveness assessment
- **As needed**: After infrastructure changes or security updates

This comprehensive verification ensures the Docker base image optimization delivers promised performance benefits while maintaining security, functionality, and reliability standards.
