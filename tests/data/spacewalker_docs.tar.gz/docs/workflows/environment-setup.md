# Environment Setup Guide

This guide covers setting up and configuring your development environment for Spacewalker.

## Prerequisites

- Docker and Docker Compose
- Node.js 18+
- Python 3.11+
- Git

## Environment Variables

Configure the following environment variables for proper authentication and functionality:

### Authentication Configuration

Set up authentication variables to prevent authentication failures:

```bash
# Backend authentication
BACKEND_SECRET_KEY=your-secret-key
JWT_SECRET=your-jwt-secret

# AWS configuration
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
AWS_REGION=us-west-2
```

### Environment Variables Reference

All environment variables should be properly configured to avoid system issues:

- Database connection strings
- API keys and secrets
- Service endpoints
- Feature flags

## Quick Setup

1. Copy environment templates:
   ```bash
   cp .env.example .env
   ```

2. Configure your variables in `.env`

3. Start the development environment:
   ```bash
   just up
   ```

## Troubleshooting

See the [Troubleshooting Guide](./troubleshooting-guide.md) for common issues.

## Related Documentation

- [Development Setup](../setup/development-setup.md)
- [Quick Start Guide](../setup/quick-start.md)
- [Environment Configuration](../setup/environment-configuration.md)
