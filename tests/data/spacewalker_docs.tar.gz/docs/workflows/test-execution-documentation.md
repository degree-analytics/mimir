# Test Execution Documentation

## Purpose
Complete guide for executing the Spacewalker test suite, including environment setup, test commands, and interpreting results. Covers local development testing, CI/CD execution, and comprehensive test coverage reporting.

## When to Use This
- Setting up test execution environments
- Running tests during development workflow
- Executing comprehensive test suites before deployment
- Understanding test results and coverage metrics
- Troubleshooting test failures and performance issues
- Planning test execution strategies for CI/CD pipelines

**Keywords:** testing, test execution, pytest, jest, test automation, coverage reporting

---

## Test Execution Overview

Spacewalker uses a multi-layered testing strategy with standardized justfile commands for consistent execution across all environments:

**🏗️ Current Status**: Production-ready test execution framework
**📅 Last Updated**: 2025-08-04
**🧪 Test Framework**: pytest (Backend), Jest (Admin/Mobile)

### Test Architecture
- **Backend**: Python/pytest with comprehensive unit and integration tests
- **Admin**: TypeScript/Jest with React Testing Library
- **Mobile**: React Native/Jest with React Native Testing Library
- **E2E**: Playwright for end-to-end testing (see [E2E Testing Framework](../../tests/docs/README.md))

---

## Environment Setup

### Prerequisites
Before running tests, ensure your development environment is properly configured:

```bash
# 1. Verify all services are running
just health

# 2. Ensure database is properly configured
just db verify

# 3. Check environment variables
just check-env
```

### Database Configuration
Tests require a properly configured test database:

```bash
# Setup test database (if needed)
just db init

# Verify database migrations
alembic current  # Run from apps/backend directory

# Seed test data (optional)
just db seed
```

### Service Dependencies
Some tests require running services:

```bash
# Start all services for integration tests
just up local

# Start specific services
just service up backend
just service up admin
```

### Local Dev Quickstart (Backend Integration Tests)

```bash
# 1) Copy env file (leave DATABASE_URL unset)
cp .env.example .env

# 2) Optional: if port 5432 is busy on your machine, set a custom host port
#    e.g., edit .env and set: POSTGRES_PORT=55432

# 3) Start local infra (DB + LocalStack + services)
just up local

# 4) Wait for services to be healthy (uses POSTGRES_PORT automatically)
just wait local

# 5) Run backend integration tests
just test integration backend

# Targeted run example
just test integration backend --filter=test_auth
```

Notes
- Postgres and LocalStack ports are bound to loopback (127.0.0.1) for safety.
- The backend test runner and fixtures honor `POSTGRES_PORT` and build a localhost URL automatically; you do not need to set `DATABASE_URL` for local tests.
- If DB isn't reachable, try a different `POSTGRES_PORT` and re-run: `just down && just up local && just wait local`.

### 🔧 Troubleshooting Common Issues

#### Port Conflicts (Most Common Issue)

**Problem**: `❌ Postgres not reachable at localhost:5432`

**Solutions** (try in order):

1. **Check if port is in use:**
   ```bash
   lsof -i :5432  # See what's using port 5432
   ```

2. **Use a different port:**
   ```bash
   # Edit .env file
   echo "POSTGRES_PORT=55432" >> .env
   
   # Restart services with new port
   just down && just up local && just wait local
   ```

3. **Kill conflicting process:**
   ```bash
   # If PostgreSQL is running outside Docker
   brew services stop postgresql  # macOS with Homebrew
   # or
   sudo service postgresql stop  # Linux
   ```

#### Environment Variable Issues

**Problem**: `❌ Invalid POSTGRES_PORT value 'abc', using default 5432`

**Solution**: Ensure `POSTGRES_PORT` is numeric:
```bash
# Check current value
echo $POSTGRES_PORT

# Fix in .env file  
echo "POSTGRES_PORT=5432" >> .env
```

#### LocalStack Connection Issues

**Problem**: `⚠️ LocalStack not reachable at localhost:4566`

**Solutions**:
```bash
# 1. Start LocalStack specifically
just service up localstack

# 2. Check LocalStack health
curl http://localhost:4566/_localstack/health

# 3. Full restart if stuck
just down && just up local
```

#### Integration Test Failures

**Problem**: Tests fail with database connection errors

**Debug Steps**:
```bash
# 1. Verify services are healthy
just health local

# 2. Check database directly
just db shell  # Should connect without errors

# 3. Run with debug logging
RUST_LOG=debug just test integration backend

# 4. Test specific database connection
just test integration backend --filter=test_database_connection
```

#### Permission Issues (macOS/Linux)

**Problem**: Permission denied or port binding failures

**Solutions**:
```bash
# 1. Check Docker permissions
docker ps  # Should list containers without sudo

# 2. Reset Docker
docker system prune -f
just down && just up local

# 3. Check firewall (macOS)
sudo pfctl -d  # Temporarily disable PF firewall
```

#### Clear All State and Restart

**Nuclear option** when everything else fails:
```bash
# Stop everything
just down

# Clean all Docker state
docker system prune -a -f
docker volume prune -f

# Clean local build files
rm -rf .build/

# Fresh start
cp .env.example .env  # Edit POSTGRES_PORT if needed
just up local && just wait local
```

---

## Core Test Commands

### Quick Development Testing
Fast feedback loop for daily development:

```bash
# Fast unit tests across all repositories (2-3 minutes)
just test unit all

# Development cycle: unit tests + linting + formatting
just dev_cycle

# Individual repository testing
just test unit backend          # Backend unit tests only (~1 min)
just test unit admin            # Admin unit tests only (~30 sec)
just test unit mobile           # Mobile unit tests only (~1 min)
```

### Comprehensive Testing
Full test suite execution for pre-commit validation:

```bash
# All test types across all repositories
just test all all

# All tests for specific repository
just test all backend           # All backend tests (unit+integration+system)
just test all admin             # All admin tests
just test all mobile            # All mobile tests
```

### Test Type-Specific Commands
Execute specific test categories:

```bash
# Integration tests (with infrastructure dependencies)
just test integration all       # All integration tests
just test integration backend   # Backend integration only
just test integration admin     # Admin integration only

# System tests (end-to-end workflows)
just test system backend        # Backend system tests
just test external all          # External API integration tests

# Specialized test categories
just test unit tenant-management       # Tenant-related unit tests
just test integration tenant-management # Tenant integration tests
just test all tenant-management         # All tenant-related tests

# AI-specific testing
just test ai real               # Real Gemini API integration
just test ai all                # Mocked + real API tests (if key available)
```

---

## Test Execution Environments

### Local Development Environment
Standard development testing workflow:

```bash
# Environment verification
just health local               # Check local services
just urls local                 # Get local service URLs

# Quick validation
just test unit all              # Fast unit tests
just dev_cycle                  # Complete development cycle

# Comprehensive local testing
just test integration all       # Integration tests with shared DB
just test all backend           # Complete backend validation
```

**Characteristics:**
- **Speed**: Fast (shared development database)
- **Isolation**: Partial (shared state)
- **Best for**: Daily development workflow

### CI/CD Environment
Automated testing with isolated infrastructure:

```bash
# CI-style integration testing
just test integration all --with-setup    # Auto-starts infrastructure

# Complete CI simulation
just test unit all                         # Unit testing phase
just test integration all                  # Integration testing phase
just test system backend                   # System testing phase
just lint check all                        # Code quality validation
```

**Characteristics:**
- **Speed**: Medium (fresh services per run)
- **Isolation**: Full (clean environment)
- **Best for**: Pre-commit validation, deployment testing

### Production-Like Testing
Testing against production-like environments:

```bash
# Production environment health checks
just health dev                 # Development environment
just health staging            # Staging environment (if available)

# Performance and load testing
just test performance all       # Performance tests with metrics
just test security all          # Security validation tests
```

---

## Test Configuration

### Backend Configuration (Python/pytest)

**Configuration Files:**
- **[pytest.ini](../../apps/backend/pytest.ini)** - Main pytest configuration
- **Test markers**: `integration`, `system`, `external`, `smoke`, `use_real_gemini`

**Key Settings:**
```ini
[tool:pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
markers =
    integration: Integration tests requiring database
    system: System-level tests with full infrastructure
    external: Tests requiring external services
    smoke: Quick smoke tests for critical functionality
```

**Environment Variables:**
```bash
# Test database configuration
DATABASE_URL="postgresql://user:pass@localhost:5432/spacewalker_test"

# AI testing configuration
GEMINI_API_KEY="your-key-here"  # For real AI tests

# Verbose test output
VERBOSE=1
```

### Admin Configuration (TypeScript/Jest)

**Configuration Files:**
- **[jest.config.ts](../../apps/admin/jest.config.ts)** - Jest + Next.js configuration
- **[jest.setup.ts](../../apps/admin/jest.setup.ts)** - Test environment setup
- **[test-utils.tsx](../../apps/admin/src/test-utils.tsx)** - React testing utilities

**Key Settings:**
```typescript
// Coverage thresholds
coverageThreshold: {
  global: {
    branches: 20,
    functions: 25,
    lines: 30,
    statements: 30
  }
}
```

### Mobile Configuration (React Native/Jest)

**Configuration Files:**
- **[package.json](../../apps/mobile/package.json)** - Mobile Jest configuration
- **[jest.setup.js](../../apps/mobile/jest.setup.js)** - Mobile test environment setup
- **[React 19 Preset](../../apps/mobile/jest-preset-react19.js)** - React 19 compatibility

**Special Considerations:**
- React 19 compatibility requirements
- Mobile-specific mocking for device APIs
- Hermes JavaScript engine compatibility

---

## Coverage Reporting

### Generating Coverage Reports
Execute tests with coverage collection:

```bash
# Backend coverage
just test unit backend --coverage
just test integration backend --coverage

# Admin coverage
just test unit admin --coverage

# Combined coverage reporting
just test all all --coverage --coverage-dir=.build/coverage
```

### Coverage Thresholds
Minimum coverage requirements:

**Backend:**
- **Unit Tests**: 80%+ line coverage target
- **Integration Tests**: Focus on critical paths
- **System Tests**: End-to-end workflow coverage

**Admin Dashboard:**
- **Branches**: 20% minimum
- **Functions**: 25% minimum
- **Lines**: 30% minimum
- **Statements**: 30% minimum

**Mobile App:**
- **Component Tests**: React Native component coverage
- **Integration Tests**: Navigation and state management

### Coverage Report Locations
Generated reports are stored in:

```bash
# Coverage output directory
.build/coverage/
├── backend/          # Backend coverage reports
├── admin/           # Admin coverage reports
├── mobile/          # Mobile coverage reports
└── combined/        # Combined coverage metrics
```

### Viewing Coverage Reports
Access coverage reports:

```bash
# Open HTML coverage report
open .build/coverage/backend/index.html
open .build/coverage/admin/index.html

# View coverage summary
cat .build/coverage/backend/coverage.txt
cat .build/coverage/combined/summary.json
```

---

## Test Result Interpretation

### Backend Test Results (pytest)
Understanding pytest output:

```bash
# Successful test run
======================== test session starts ========================
collecting ... collected 151 items

tests/unit/test_api.py ............................  [ 18%]
tests/integration/test_database.py ................ [ 45%]
tests/system/test_workflows.py ................... [ 72%]
tests/external/test_ai_integration.py ............ [100%]

======================== 151 passed in 45.67s ========================
```

**Key Metrics:**
- **Collection Time**: Time to discover tests
- **Pass/Fail Counts**: Individual test results
- **Execution Time**: Total test runtime
- **Coverage**: Code coverage percentage (if enabled)

### Admin Test Results (Jest)
Understanding Jest output for React components:

```bash
# Successful test run
PASS src/components/AdminLayout.test.tsx
PASS src/pages/dashboard.test.tsx
PASS src/utils/api.test.ts

Test Suites: 20 passed, 20 total
Tests:       89 passed, 89 total
Snapshots:   5 passed, 5 total
Time:        15.234s
```

**Key Metrics:**
- **Test Suites**: Component/module test groups
- **Individual Tests**: Specific test cases
- **Snapshots**: UI component snapshots
- **Time**: Execution duration

### Mobile Test Results (React Native/Jest)
Understanding mobile-specific test output:

```bash
# Expected mobile test results
PASS src/components/SurveyForm.test.tsx
PASS src/navigation/AppNavigator.test.tsx
FAIL src/components/Alert.test.tsx  # Expected failure (React 19 compatibility)

Test Suites: 389 passed, 6 failed, 395 total
Tests:       1248 passed, 12 failed, 1260 total
Time:        42.123s
```

**Expected Failures:**
- **Alert Components**: 6 expected failures due to React 19 alert changes
- **Navigation**: Minor timing issues in navigation tests
- **Device APIs**: Mock-related failures in device integration tests

---

## Test Parallelization

### Local Parallelization
Optimize local test execution:

```bash
# Backend parallel execution
just test unit backend --parallel 4        # Run with 4 workers
just test integration backend --parallel 2  # Limited parallelization for DB tests

# Jest parallel execution (automatic)
just test unit admin                        # Jest auto-detects CPU cores
just test unit mobile --maxWorkers=4       # Explicit worker count
```

### CI/CD Parallelization
GitHub Actions matrix strategy:

```yaml
# Example CI configuration
strategy:
  matrix:
    test-type: [unit, integration, system]
    component: [backend, admin, mobile]
```

**Benefits:**
- **3x Faster**: Matrix strategy reduces CI runtime from 15 to 5 minutes
- **Early Failure**: Fail-fast on critical unit test failures
- **Resource Optimization**: Parallel job execution

### Database Parallelization Considerations
Managing database access in parallel tests:

```bash
# Safe parallel testing strategies
just test unit all                  # No DB dependencies, fully parallel
just test integration backend --sequential  # DB tests run sequentially
just test system backend --isolated # Each test gets fresh DB state
```

---

## Performance Monitoring

### Test Performance Metrics
Monitor test execution performance:

```bash
# Enable performance tracking
just test unit all --profile           # Profile test execution
just test integration all --timing     # Track timing information

# Performance analysis
just test all backend --benchmark      # Benchmark test suite performance
```

**Key Performance Indicators:**
- **Unit Test Speed**: < 2 minutes for full unit suite
- **Integration Test Speed**: < 5 minutes for full integration suite
- **System Test Speed**: < 10 minutes for complete system validation
- **CI Pipeline Total**: < 15 minutes for complete pipeline

### Test Flakiness Detection
Identify and resolve flaky tests:

```bash
# Run tests multiple times to detect flakiness
just test unit backend --repeat 5      # Run 5 times to check consistency
just test integration admin --flaky    # Flaky test detection mode

# Analyze test stability
just test all all --stability-report   # Generate stability metrics
```

### Performance Troubleshooting
Common performance issues and solutions:

**Slow Database Tests:**
```bash
# Optimize database test performance
just db verify                         # Check database health
just test integration backend --fast   # Use faster test database
```

**Memory Issues:**
```bash
# Monitor memory usage during tests
just test all backend --memory-profile # Memory profiling
just test unit all --maxWorkers=2      # Reduce parallel workers
```

---

## Troubleshooting Test Failures

### Common Test Failure Patterns

**1. Database Connection Issues**
```bash
Error: Could not connect to database
Solution:
- just health                           # Check service status
- just db verify                        # Verify database state
- just service restart backend          # Restart database service
```

**2. Environment Configuration Issues**
```bash
Error: Environment variable not set
Solution:
- just check-env                        # Verify environment setup
- source .env                          # Load environment variables
- just test unit all --env-check        # Test with environment validation
```

**3. Service Dependency Issues**
```bash
Error: Connection refused to service
Solution:
- just up                              # Start all services
- just health                          # Verify service readiness
- just test integration all --with-setup # Auto-start dependencies
```

### Test-Specific Troubleshooting

**Backend (pytest) Issues:**
```bash
# Enable verbose debugging - use justfile commands only
just test unit backend --ci  # Verbose CI mode for debugging
just test integration backend --log-cli-level=DEBUG  # Detailed logging

# Database-specific debugging
just db shell                           # Access database directly
just test unit backend --capture=no     # Show print statements
```

**Admin (Jest) Issues:**
```bash
# React Testing Library debugging
just test unit admin --verbose         # Verbose Jest output
just test unit admin --watch           # Watch mode for iterative debugging

# Component-specific debugging
DEBUG_PRINT_LIMIT=0 just test unit admin  # Show full component renders
```

**Mobile (React Native) Issues:**
```bash
# React Native specific debugging
just test unit mobile --verbose        # Detailed mobile test output
just test unit mobile --clearCache     # Clear Jest cache

# Handle expected failures
just test unit mobile --passWithNoTests # Continue despite expected failures
```

### Test Data Issues
Managing test data problems:

```bash
# Reset test data
just db clean                          # Clean test database
just db seed                           # Restore test data

# Verify test data integrity
just test integration backend --verify-data  # Validate test data state
```

---

## CI/CD Integration

### GitHub Actions Integration
Spacewalker uses GitHub Actions for automated testing:

**Workflow Files:**
- **[Main CI/CD Pipeline](../../.github/workflows/ci-cd.yml)** - Complete testing workflow
- **[Claude Integration](../../.github/workflows/claude.yml)** - AI-assisted development testing

**Pipeline Stages:**
1. **Unit Tests** (parallel execution)
2. **Integration Tests** (sequential execution)
3. **System Tests** (end-to-end validation)
4. **Coverage Reporting** (combined metrics)
5. **Artifact Upload** (test results and coverage)

### Local CI Simulation
Test your changes against CI environment locally:

```bash
# Simulate CI testing workflow
just test unit all                      # Unit test phase
just test integration all               # Integration test phase
just test system backend                # System test phase
just lint check all                     # Code quality phase

# Complete CI simulation with coverage
just test all all --ci-mode --coverage  # Full CI pipeline simulation
```

### Test Artifacts
CI generates test artifacts for analysis:

```bash
# Generated artifacts
.build/test-results/
├── junit.xml                          # JUnit test results
├── coverage.xml                       # Coverage reports
├── test-output.log                    # Complete test logs
└── performance-metrics.json           # Performance data
```

---

## Best Practices

### Test Execution Workflow
Recommended testing workflow for development:

```bash
# Daily development cycle
just health                            # Verify environment
just test unit all                     # Quick validation (2-3 min)
# ... make code changes ...
just dev_cycle                         # Test + lint after changes
just test integration all              # Before major commits

# Pre-commit validation
just test all all                      # Comprehensive testing
just lint check all                    # Final code quality check
```

### Test Selection Strategy
Choose appropriate test scope based on changes:

**For Small Changes:**
```bash
just test unit backend                 # Component-specific testing
just dev_cycle                         # Quick feedback loop
```

**For Feature Development:**
```bash
just test all backend                  # Component comprehensive testing
just test integration admin            # Cross-component validation
```

**For Major Changes:**
```bash
just test all all                      # Complete test suite
just test security all                 # Security validation
just test performance all              # Performance regression testing
```

### Test Environment Management
Maintain clean test environments:

```bash
# Environment reset procedures
just service restart all               # Fresh service state
just db clean && just db seed          # Clean database state
just test unit all --clean-cache       # Clear test caches

# Environment validation
just health                            # Service health check
just check-env                         # Environment configuration
just db verify                         # Database integrity
```

---

## Integration with Development Tools

### IDE Integration
Configure your IDE for optimal test execution:

**VS Code:**
```json
// .vscode/settings.json - Configure IDE to use justfile commands
{
  "python.testing.pytestEnabled": false,  // Use justfile commands instead
  "python.testing.unittestEnabled": false,
  "jest.jestCommandLine": "just test unit admin",  // Use justfile for tests
  "jest.autoRun": "off"  // Manual execution via justfile preferred
}
```

**PyCharm:**
- Disable direct pytest integration (use justfile commands instead)
- Configure external tools to run `just test` commands
- Use justfile for coverage reporting: `just test unit backend --coverage`

### Git Hooks Integration
Automated testing with git hooks:

```bash
# Pre-commit hook (example)
#!/bin/bash
just test unit all || exit 1           # Block commit on test failure
just lint check all || exit 1          # Block commit on lint failure

# Pre-push hook (example)
#!/bin/bash
just test integration all || exit 1    # Block push on integration failure
```

### Test Automation
Automated test execution triggers:

```bash
# File watching for continuous testing
just test unit backend --watch         # Re-run tests on file changes
just test unit admin --watchAll        # Jest watch mode

# Scheduled testing
crontab -e
0 2 * * * cd /path/to/project && just test all all  # Nightly comprehensive tests
```

---

## Related Documentation

### Core Testing Resources
- **[Testing Guide](./testing-guide.md)** - Complete testing strategies and frameworks ⭐
- **[E2E Testing Framework](../../tests/docs/README.md)** - End-to-end testing with Playwright ⭐
- **[Backend Development Guide](../backend/development/README.md)** - Backend-specific testing patterns
- **[Admin Architecture Guide](../admin/architecture/README.md)** - Frontend testing strategies

### CI/CD and Deployment
- **[CI/CD Build Guide](./ci-cd-build-guide.md)** - Complete pipeline documentation ⭐
- **[GitHub Actions Best Practices](./github-actions-best-practices.md)** - Workflow optimization ⭐
- **[Deployment Guide](./deployment-guide.md)** - Deployment validation testing

### Environment and Setup
- **[Development Setup](../setup/development-setup.md)** - Development environment configuration ⭐
- **[LocalStack Setup](../setup/localstack-setup.md)** - Local AWS services for testing ⭐
- **[Environment Configuration](../setup/environment-configuration.md)** - Multi-environment setup

---

## Support and Quick Reference

### Essential Commands Quick Reference
```bash
# Quick development testing
just test unit all                     # Fast unit tests (2-3 min)
just dev_cycle                         # Development cycle with linting

# Comprehensive testing
just test all all                      # Complete test suite
just test integration all              # Integration tests with infrastructure

# Environment management
just health                            # Check service status
just db verify                         # Verify database state
just check-env                         # Environment validation

# Coverage and quality
just test all backend --coverage       # Backend tests with coverage
just lint check all                    # Code quality validation
```

### Performance Expectations
- **Unit Tests**: 2-3 minutes for complete suite
- **Integration Tests**: 5-10 minutes with infrastructure
- **System Tests**: 10-15 minutes for end-to-end workflows
- **Complete Pipeline**: 15-20 minutes for full validation

### Getting Help
- **Test Configuration Issues**: Review framework-specific configuration files
- **Performance Problems**: Use `--profile` and `--timing` flags for analysis
- **CI/CD Issues**: Check GitHub Actions logs and artifact outputs
- **Environment Problems**: Run `just health` and `just check-env` for diagnosis

---

**Last Updated:** 2025-08-04
**Status:** Current
**Version:** 1.0.0
