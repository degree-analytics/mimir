# Git Commit Standards

## Purpose
Professional git commit standards and formatting guidelines to ensure consistent, readable, and error-free commits across all Spacewalker development teams. Essential reference for maintaining code quality, enabling automated tooling, and creating clear project history.

## When to Use This
- Before making any git commit in the Spacewalker codebase
- Setting up development environment automation and git workflows
- Creating commit message templates and automation scripts
- Training new developers on project commit standards
- Troubleshooting commit formatting and command-line git operations
- Keywords: git commit, conventional commits, commit formatting, development workflow, code quality

**Version:** 2.0 (Migrated from Cursor rules)
**Date:** 2025-06-29
**Status:** Current - Production Development Standards

---

## 🎯 Quick Reference

### Single-Line Commits (Recommended)
```bash
# Safe single-line commit and push
git add . && git commit -m "type(scope): description" && git push

# Example:
git add . && git commit -m "feat(auth): add OAuth2 integration" && git push
```

### Multi-Line Commits (For Complex Changes)
```bash
# Safe multi-line commit using temporary file
echo "type(scope): brief description

- Detail 1
- Detail 2" > .git/COMMIT_EDITMSG && git commit -F .git/COMMIT_EDITMSG && git push
```

---

## 📋 Commit Message Format

### Structure
```
type(scope): brief description
```

### Commit Types
- **`feat`**: New feature or functionality
- **`fix`**: Bug fix or issue resolution
- **`docs`**: Documentation changes only
- **`style`**: Code formatting changes (no functional changes)
- **`refactor`**: Code restructuring without changing functionality
- **`test`**: Adding or modifying tests
- **`chore`**: Maintenance tasks, dependency updates

### Scope Definitions
- **`api`**: Backend API changes and endpoints
- **`ui`**: User interface changes (admin dashboard, mobile UI)
- **`db`**: Database schema, migrations, or data changes
- **`auth`**: Authentication and authorization systems
- **`rules`**: Cursor rules, development tooling, or linting changes
- **`docs`**: Documentation structure or content
- **`test`**: Testing infrastructure or test cases
- **`core`**: Core functionality affecting multiple systems

---

## ✅ Correct Commit Patterns

### Recommended Approaches
```bash
# Single quotes (prevents shell interpretation)
git commit -m 'feat(auth): add login flow'

# Double quotes (escaped if needed)
git commit -m "fix(api): resolve timeout issue"

# File-based for multi-line (safest for complex messages)
echo "feat(ui): add responsive layout

- Add mobile breakpoints
- Implement flex containers
- Update media queries" > .git/COMMIT_EDITMSG && git commit -F .git/COMMIT_EDITMSG
```

### Example Commit Messages
```bash
# Feature work
git commit -m "feat(user): add email verification"
git commit -m "feat(auth): implement 2FA support"

# Bug fixes
git commit -m "fix(api): resolve rate limiting issue"
git commit -m "fix(ui): correct button alignment"

# Documentation
git commit -m "docs(api): update endpoint documentation"
git commit -m "docs(setup): add deployment guide"

# Refactoring
git commit -m "refactor(core): optimize data processing"
git commit -m "refactor(auth): simplify login flow"
```

---

## ❌ Common Commit Mistakes

### Avoid These Patterns
```bash
# DON'T use newlines in -m flag (causes command parsing errors)
git commit -m "feat(ui): add layout
- Add breakpoints
- Update styles"

# DON'T use multiple -m flags (creates confusing message format)
git commit -m "feat(ui): add layout" -m "- Add breakpoints"

# DON'T use vague or non-descriptive messages
git commit -m "fix stuff"
git commit -m "update"
git commit -m "wip"
```

---

## 📐 Best Practices

### Message Guidelines
1. **Use imperative mood** - "add" not "adds" or "added"
2. **Keep first line under 50 characters** - for better readability in git tools
3. **No period at end of subject line** - saves characters and follows convention
4. **Be specific and clear** - explain what was changed and why
5. **Reference issue numbers when relevant** - helps with tracking and automation

### Commit Organization
1. **Make atomic commits** - one logical change per commit
2. **Verify changes before committing** - review diff to avoid accidental inclusions
3. **Run tests before pushing** - ensure code quality and CI/CD success
4. **Review the diff carefully** - prevent unintended changes and debugging code
5. **Keep commits focused and small** - easier to review, revert, and understand

---

## 🔧 Development Automation

### Git Aliases
Add these to your `~/.gitconfig` for consistent commit workflow:

```bash
[alias]
    # Quick commit with message
    cm = "!f() { git commit -m \"$1\"; }; f"

    # Add, commit, and push in one command
    acp = "!f() { git add . && git commit -m \"$1\" && git push; }; f"

    # Safe multi-line commit
    mcm = "!f() { echo \"$1\" > .git/COMMIT_EDITMSG && git commit -F .git/COMMIT_EDITMSG; }; f"
```

### Shell Functions
Add these to your `~/.zshrc` or `~/.bashrc`:

```bash
# Safe single-line commit
commit() {
    git add . && git commit -m "$1" && git push
}

# Safe multi-line commit
mcommit() {
    echo "$1" > .git/COMMIT_EDITMSG && git commit -F .git/COMMIT_EDITMSG && git push
}
```

---

## 🛠️ Recovery Procedures

### Fix Last Commit
```bash
# Amend commit message
git commit --amend -m "type(scope): corrected message"

# Amend commit content (add forgotten files)
git add forgotten-file
git commit --amend --no-edit
```

### Split Failed Commit
```bash
# Reset last commit but keep changes
git reset HEAD~1

# Commit changes separately
git add feature-files
git commit -m "feat(scope): first part"
git add test-files
git commit -m "test(scope): add tests"
```

---

## 🔍 Pre-Commit Safety Checklist

### Code Quality
- [ ] Run linters and fix formatting issues
- [ ] Check code formatting and style consistency
- [ ] Remove debug code, console.log statements, and temporary files
- [ ] Run unit tests and ensure they pass

### Security Review
- [ ] No sensitive data (API keys, passwords, tokens) in commit
- [ ] No credentials or configuration secrets
- [ ] Check file permissions for security-sensitive files
- [ ] Verify no temporary files with sensitive content

### Commit Message
- [ ] Correct type and scope according to standards
- [ ] Clear, descriptive message explaining the change
- [ ] No newlines in -m flag (use file-based for multi-line)
- [ ] Reference related issues or tickets if applicable

### Change Verification
- [ ] Review diff to understand all changes being committed
- [ ] Verify only intended files are included
- [ ] Check for unintended changes or modifications
- [ ] Confirm adequate test coverage for changes

---

## 📊 Mandatory Diff Review

### Pre-Commit Diff Check
**Always run these commands before any commit:**

```bash
# Check status first
git status | cat

# Review all changes in detail
git diff | cat

# For staged changes
git diff --staged | cat
```

### Diff Review Guidelines

#### File Changes Review
- ✅ Confirm all intended files are modified
- ❌ Check for unintended file deletions
- 🔒 Ensure no sensitive files are exposed

#### Code Changes Review
- 📝 Review each chunk of changes line by line
- 🗑️ Verify line deletions are intentional
- 🐛 Check for remaining debugging code
- 🎨 Confirm formatting changes are appropriate

#### Large Changes Warning
- **>500 lines changed**: Break into smaller, focused commits
- **Large deletions**: Double-check necessity and impact
- **Significant file removals**: Request additional confirmation

### Post-Review Actions
- 🔧 Address any unintended changes before committing
- 🧹 Remove debug statements and temporary code
- 🎯 Fix formatting issues discovered during review
- 📦 Split into multiple commits if changes are too broad

---

## 📋 Related Development Documentation

### Git Workflow Documentation
- **[Git Merge Strategy](../workflows/git-merge-strategy.md)** - Branching, merging, and conflict resolution workflows
- **[Development Setup](../setup/development-setup.md)** - Complete development environment configuration
- **[Development Tools](../development/development-tools.md)** - Professional automation and helper scripts
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Deployment procedures and CI/CD workflows

### Platform-Specific Standards
> 🚀 **Backend Teams**: See [Backend Development](../backend/development/) for backend-specific git workflow integration
> 🚀 **Admin Teams**: See [Admin Development](../admin/development/) for dashboard development git practices
> 🚀 **Mobile Teams**: See [Mobile Development](../mobile/development/) for React Native development workflows

### Quality & Testing
- **[Testing Strategy](../workflows/testing-strategy.md)** - Testing automation and quality assurance workflows
- **[Code Review Gotchas](../development/development-tools.md)** - Common code review and commit mistakes to avoid

---

**Status**: ✅ **PRODUCTION DEVELOPMENT STANDARDS**
**Last Updated**: 2025-06-29
**Applies To**: All Spacewalker development teams (Backend, Admin, Mobile)
**Integration**: Git workflows, CI/CD pipelines, code review processes

---

*These git commit standards ensure consistent project history, enable automated tooling, and maintain code quality across all Spacewalker development teams. Following these guidelines improves collaboration, debugging efficiency, and release management.*
