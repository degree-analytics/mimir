# Attribute Initialization Issues - ENG-951

## Problems Found

### 1. New Tenants Not Getting Attributes
**Problem**: When creating a new tenant, no attributes were being initialized (0 categories, 0 definitions)

**Root Cause**: Superuser context was lost during tenant creation transaction. The code switched to the new tenant's context, then tried to copy from system tenant but was blocked by RLS.

**Fix Applied**: `/apps/backend/src/spacecargo/api/routers/tenants.py` (lines 601-602, 615-616)
```python
# Re-establish superuser context before initialization
db.execute(text("SET app.current_tenant_id = -1"))
AttributeService.initialize_tenant_attributes(db, tenant_id, auto_commit=False)
```

### 2. Attributes Showing as "Unknown" Category
**Problem**: All 74 attributes displayed with "Unknown" category instead of proper categories

**Root Cause**: API mismatch - `/api/attributes/definitions` returned system + tenant data via RLS, but `/api/attributes/categories` only returned tenant-specific categories

**Fix Applied**: `/apps/backend/src/spacecargo/api/services/attribute_service.py` (lines 118-134)
```python
# Now returns both tenant AND system categories
return db.query(AttributeCategory).filter(
    or_(
        AttributeCategory.tenant_id == tenant_id,
        AttributeCategory.tenant_id == 1  # System Default tenant
    )
).all()
```

### 3. Production Configuration Issue
**Problem**: System Tenant ID is 3 in production but code assumes 1

**Fix Needed**:
- Add `SYSTEM_DEFAULT_TENANT_ID=3` to production environment
- Change hardcoded `1` to use config variable

### 4. Degree Analytics Has No Attributes
**Current State**: Tenant ID 6 has 0 categories and 0 definitions

**Fix**: Need to run initialization script or wipe/reseed database

## Files Changed
- `/apps/backend/src/spacecargo/api/routers/tenants.py`
- `/apps/backend/src/spacecargo/api/services/attribute_service.py`

## Verification
Test tenant created after fixes shows:
- ✅ 7 categories from system tenant
- ✅ 2386 definitions visible
- ✅ No "Unknown" category issues
