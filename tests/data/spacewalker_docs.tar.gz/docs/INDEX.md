# Spacewalker Documentation Hub

## Purpose
Central navigation hub for all project documentation, providing organized access to architecture decisions, development guides, operations procedures, and known issues.

## When to Use This
- Finding specific documentation quickly
- Understanding documentation organization
- Onboarding new team members
- Discovering related documentation

**Keywords:** navigation, index, documentation map, getting started

Welcome to the comprehensive documentation hub for **Spacewalker** - a multi-tenant room survey management platform built with React Native, Next.js, and FastAPI. This index provides role-based navigation to help you find exactly what you need quickly and efficiently.

**🏗️ Current Status**: Production-ready documentation for all system components
**📅 Last Updated**: 2025-09-15
**📋 Total Documents**: 175+ comprehensive guides across 6 specialized directories

---

## 🚀 Quick Start Paths

Choose your path based on your role and immediate needs:

| Role | Primary Goal | Start Here | Time to Productive |
|------|-------------|------------|-------------------|
| **Backend Developer** | Build FastAPI services and APIs | [Backend Development](#backend-development) → [API Development Guide](./backend/api-development.md) | 15 minutes |
| **Mobile Developer** | Develop React Native features | [Mobile Development](#mobile-development) → [Development Patterns](./mobile/development-patterns.md) and [Emulators](./mobile/emulators.md) | 15 minutes |
| **Frontend Developer** | Build admin dashboard features | [Admin Development](#admin-development) → [Admin Architecture](./admin/architecture/) | 15 minutes |
| **DevOps Engineer** | Deploy and manage infrastructure | [Operational Workflows](#operational-workflows) → [AWS Deployment Guide](./workflows/aws-deployment-guide.md) | 20 minutes |
| **Product Manager** | Understand system capabilities | [Product Documentation](#product-documentation) → [Product Overview](./product/product-overview.md) | 10 minutes |
| **New Team Member** | Onboard to the platform | [Environment Setup](#environment-setup) → [Development Setup](./setup/development-setup.md) | 30 minutes |

---

## 📱 Mobile Quick Start

- `just up local` — Starts backend + admin, configures IP, launches Expo Go offline
- `just expo start --offline` — Starts Expo dev server (Expo Go)
- `just expo ip auto` — Detects LAN IP and updates `apps/mobile/.env.local`

See also:
- Emulators: `docs/mobile/emulators.md`
- Mobile development guide: `docs/mobile/development/README.md`

## 🤖 AI Tool Documentation (CLAUDE.md)

**NEW: Modular Documentation Structure with Precedence Rules**

The SpaceWalker documentation now uses a modular CLAUDE.md architecture optimized for AI development tools:

### Documentation Hierarchy
| Document | Purpose | Precedence |
|----------|---------|------------|
| **[CLAUDE.md](../CLAUDE.md)** | Root instructions for Claude Code | Base rules |
| **[apps/backend/CLAUDE.md](../apps/backend/CLAUDE.md)** | Backend module-specific rules | Overrides root |
| **[apps/admin/CLAUDE.md](../apps/admin/CLAUDE.md)** | Admin module-specific rules | Overrides root |
| **[apps/mobile/CLAUDE.md](../apps/mobile/CLAUDE.md)** | Mobile module-specific rules | Overrides root |
| **[sam/CLAUDE.md](../sam/CLAUDE.md)** | Infrastructure module rules | Overrides root |

### Cross-Tool Compatibility
- **Claude Code**: Uses CLAUDE.md natively with @docs imports
- **Cursor**: See [.cursor/rules/main.mdc](../.cursor/rules/main.mdc) or [.cursorrules](../.cursorrules) for legacy versions
- **Windsurf/Codeium**: See [AGENTS.md](../AGENTS.md) for adapter instructions

### Component Documentation
Key reusable documentation components:
- **[Deployment Model](./claude-components/deployment-model.md)** - Critical distinction between infrastructure, service management, and new code deployment
- **[Interaction Patterns](./claude-components/interaction-patterns.md)** - Numbered selection patterns for user interaction
- **[Context Discovery](./claude-components/context-discovery.md)** - Search tool hierarchy and proper usage patterns

### Precedence Rules
```
most-specific > local > imports
~/.claude → module → root → @docs
```

---

## 🚨 CRITICAL: Database Migration Workflow

**⚠️ ALWAYS READ BEFORE CREATING MIGRATIONS: [Database Migrations Guide](./backend/database-migrations.md)**

**Essential commands for all database changes:**
```bash
just migrations create "your_migration_name"  # Create migration
just migrations apply local                   # Apply locally
just migrations apply dev                     # Apply to dev (after push)
```

---

## 🎭 MANDATORY: Post-Deploy E2E Testing

**🚨 CRITICAL WORKFLOW: Every deployment MUST be validated with E2E testing**

After every deployment to dev or staging, run these commands to validate your changes:

```bash
# 1. Push code → CI builds containers automatically
git push origin your-branch

# 2. Deploy infrastructure (pulls latest containers from CI)
just aws_deploy_backend dev    # For backend changes
just aws_deploy_admin dev      # For admin changes

# 3. Reset demo data (if needed for clean test state)
just e2e_reset_demo

# 4. 🚀 REQUIRED: Validate deployment with E2E tests
just e2e_post_deploy dev
```

**📋 What this validates:**
- ✅ Admin dashboard loads and functions correctly
- ✅ Authentication and user management works
- ✅ Core business workflows operate as expected
- ✅ Data persistence and retrieval functions properly
- ✅ Integration between frontend and backend is intact

**📖 Full E2E Documentation:** [E2E Testing Framework](../tests/docs/README.md)

---

## 📚 Documentation Structure

Our documentation is organized into 11 specialized directories designed for efficient discovery and minimal cognitive load:

```
docs/
├── 📋 product/          # Product strategy, requirements, roadmap
├── 📊 product-analytics/# User behavior tracking, feature adoption metrics
├── 🏗️ architecture/     # System design, C4 model, technical architecture
├── 🔧 setup/            # Environment setup, getting started, onboarding
├── 🛠️ development/      # Development tools, project structure, standards
├── 🔄 workflows/        # Operational procedures, deployment, testing
├── 🖥️ system/           # System administration, monitoring, versioning
├── 🔧 backend/          # FastAPI, PostgreSQL, AI services
├── 🌐 admin/            # Next.js dashboard, authentication
├── 📱 mobile/           # React Native, offline-first patterns
├── 🧪 tests/            # E2E testing framework, procedures, maintenance
└── ⚠️ gotchas/          # Common issues, troubleshooting
```

---

## 📋 Product Documentation

**Focus**: Business strategy, product requirements, roadmap planning, and stakeholder communication

### Strategy & Vision
- **[Product Overview](./product/product-overview.md)** - High-level product vision, business goals, and system architecture overview ⭐
- **[Product Vision](./product/product-vision.md)** - Strategic direction and long-term goals

### Requirements & Planning
- **[Product Requirements](./product/product-requirements.md)** - Detailed feature specifications and functional requirements
- **[Product Roadmap](./product/product-roadmap.md)** - Development timeline, milestones, and priorities

**💡 Quick Access**: [Product Documentation README](./product/README.md)

---

## 🏗️ System Architecture

**Focus**: Technical architecture, design patterns, security architecture, and system-wide specifications

### System Architecture (C4 Model)
- **[System Architecture](./architecture/system-architecture.md)** - Overall system design and technology architecture overview ⭐
- **[System Context](./architecture/system-context.md)** - C4 Level-1 system overview and external dependencies ⭐
- **[System Container Overview](./architecture/system-container-overview.md)** - C4 Level-2 container architecture and relationships
- **[Component Diagrams](./architecture/component-diagrams.md)** - Detailed component relationships and interactions

### Architecture Patterns & Design
- **[Runtime Sequences](./architecture/runtime-sequences.md)** - Cross-system interaction patterns and data flow ⭐
- **[Data Flow Patterns](./architecture/data-flow-patterns.md)** - Data movement and transformation patterns
- **[Security Architecture](./architecture/security-architecture.md)** - Security patterns, authentication, and authorization design

### Architecture Standards
- **[Architecture Requirements](./architecture/architecture-requirements.md)** - Technical architecture standards and constraints

### Architecture Decisions
- **[ADR-005: CI/CD Cache Optimization](./architecture/adr-005-ci-cd-cache-optimization.md)** - Cache-only architecture decision for 82% performance improvement ⭐

**💡 Quick Access**: [System Architecture README](./architecture/README.md)

---

## 🔧 Environment Setup

**Focus**: Initial setup, environment configuration, onboarding, and getting started guides

### Prerequisites & Quick Start
- **[Developer Prerequisites](./setup/developer-prerequisites.md)** - Complete list of ALL required tools and configurations with bootstrap script ⭐ UPDATED
- **[Quick Start](./setup/quick-start.md)** - 5-minute automated setup for immediate productivity ⭐
- **[Getting Started](./setup/getting-started.md)** - Comprehensive step-by-step onboarding guide with fresh machine setup ⭐ UPDATED
- **[Development Setup](./setup/development-setup.md)** - Complete development environment configuration and daily workflow ⭐

### Environment Configuration
- **[Environment Setup](./setup/environment-setup.md)** - Basic environment configuration and prerequisites
- **[Environment Configuration](./setup/environment-configuration.md)** - Advanced environment settings and customization
- **[Shared Environment Variables](./setup/shared-environment-variables.md)** - Variable naming standards and conventions
- **[Production Infrastructure](./setup/production-infrastructure.md)** - Production-specific setup and deployment guide ⭐

### Specialized Setup
- **[AI Development Setup](./setup/ai-development-setup.md)** - Claude Code, MCP servers, AI development tools, and telemetry integration ⭐ UPDATED
- **[LocalStack Setup](./setup/localstack-setup.md)** - Local AWS services emulation (S3, SES, Secrets Manager) for development and testing with email testing utilities ⭐

**💡 Quick Access**: [Environment Setup README](./setup/README.md)

---

## 🛠️ Development Reference

**Focus**: Development tooling, project structure, documentation standards, and developer resources

### Project Organization
- **[Project Structure](./development/project-structure.md)** - Monorepo organization, component relationships, and conventions ⭐
- **[Helpers Directory Structure](./development/helpers-directory-structure.md)** - Organization of justfile-integrated automation scripts ⭐ NEW

### Development Tooling
- **[Development Tools](./development/development-tools.md)** - IDE setup, debugging, profiling, and development optimization ⭐
- **[AI Telemetry System](./development/ai-telemetry-system.md)** - Unified telemetry for AI tools with monitoring, session correlation, and cost tracking ⭐ NEW
- **[Developer Nuances & Conventions](./development/developer-nuances.md)** - Justfile philosophy, current test hygiene workarounds, and .claude command governance ⭐ NEW
- **[TaskMaster Commands](/tm/help)** - AI-powered project management and task breakdown with Claude Code ⭐
- **[CLAUDE.md Context Management](./development/claude-context-management.md)** - Modular AI context management with @ file references and nested inheritance. See also: [Mobile Troubleshooting](./mobile/troubleshooting-guide.md) ⭐
- **[PR Analysis Tools](./workflows/pr-analysis-guide.md)** - Comprehensive PR analysis with action-based commands for commits, files, stats, and AI insights ⭐ NEW
- **[ast-grep Integration Guide](./development/ast-grep-integration.md)** - Security pattern detection with ast-grep: setup, rule development, and performance optimization ⭐ NEW
- **[ast-grep Optimization Guide](./development/ast-grep-optimization-guide.md)** - Performance tuning, parallel execution strategies, and memory optimization for large codebases ⭐ NEW

### Documentation & Standards
- **[Documentation Navigation Patterns](./development/documentation-navigation-patterns.md)** - Documentation organization principles and best practices
- **[Adding Custom Lints](./development/adding-custom-lints.md)** - How to add project-specific validation to lint system
- **[Claude Commands Guide](./development/claude-commands.md)** - Available Claude slash commands and custom command creation ⭐ NEW
- **[Justfile Special Characters Guide](./development/justfile-special-characters-guide.md)** - Handling special characters in justfile arguments using positional-arguments ⭐ NEW

**💡 Quick Access**: [Development Reference README](./development/README.md)

---

## 🖥️ System Administration

**Focus**: System management, monitoring, version tracking, and operational visibility

### System Management
- **[Version Management](./system/version-management.md)** - Comprehensive semantic versioning system across all services ⭐

**💡 Quick Access**: [System Administration README](./system/README.md)

---

## 🔧 Backend Development

**Focus**: FastAPI services, PostgreSQL database, AI integrations, and API architecture

### 🏗️ Architecture & Design
- **[API Development Guide](./backend/api-development.md)** - FastAPI patterns, authentication, validation, testing ⭐
- **[Database Design](./backend/database-design.md)** - Schema, relationships, multi-tenancy patterns
- **[Database Migrations](./backend/database-migrations.md)** - Alembic workflows, production deployment
- **[API Components](./backend/api-components.md)** - Service layer, component architecture
- **[Backend Container Architecture](./backend/architecture/backend-container-architecture.md)** - System design patterns

### 📋 Requirements & Specifications
- **[Backend Requirements](./backend/requirements.md)** - Functional and technical requirements
- **[API Contracts](./backend/architecture/api-contracts.md)** - Endpoint specifications and schemas
- **[Security Implementation](./backend/architecture/security-implementation.md)** - Authentication and authorization

### 🛠️ Development Resources
- **[BACnet Terminology](./backend/bacnet-terminology.md)** - Building automation protocols and terms
- **[FICM Specifications](./backend/ficm-specifications.md)** - Facility classification standards and domain knowledge
- **[FICM API](./backend/ficm-api.md)** - FICM hierarchy API documentation and flat array structure ⭐
- **[Tenant Management](./backend/tenant-management.md)** - Multi-tenant architecture and superuser features ⭐
- **[BACnet Environment Rebuild](./backend/bacnet-environment-rebuild.md)** - Environment recovery procedures
- **[BACnet Testing Guide](./backend/bacnet-testing-guide.md)** - Protocol-specific testing procedures

### 📊 LLM Evaluation Framework
- **[Evaluation Package Overview](../packages/eval/README.md)** - Comprehensive LLM performance evaluation for FICM room classification with multi-model comparison, A/B testing, ground truth validation, and interactive dashboards ⭐
- **[Evaluation Examples](../packages/eval/examples/)** - Ready-to-use examples for multi-model comparison, A/B testing, and comprehensive evaluations ⭐
- **[Testing Standards Integration](../packages/eval/README.md#testing)** - Evaluation package testing standards updated to use justfile commands instead of direct pytest ⭐ UPDATED

**💡 Quick Access**: [Backend Development README](./backend/development/README.md)

---

## 🌐 Admin Development

**Focus**: Next.js dashboard, administrative interfaces, and web application patterns

### 🏗️ Architecture & Design
- **[Admin Container Architecture](./admin/architecture/admin-container-architecture.md)** - Frontend architecture patterns with AdminLayout integration ⭐
- **[API Proxy Pattern](./admin/architecture/api-proxy-pattern.md)** - Runtime proxy configuration for containers

### 🎨 Component Implementation
- **[AdminLayout Component Guide](./admin/components/admin-layout-guide.md)** - Comprehensive AdminLayout usage guide for standardized layouts ⭐

### 📋 Requirements & Specifications
- **[Admin Requirements](./admin/requirements.md)** - Dashboard functionality and user experience requirements

### 🎯 Performance & Optimization
- **[Performance Optimization Patterns](./admin/performance-optimization-patterns.md)** - React performance patterns for large datasets and complex UIs ⭐
- **[Table Sorting Guide](./admin/table-sorting-guide.md)** - Comprehensive table sorting implementation with security and performance

**💡 Quick Access**: [Admin Architecture README](./admin/architecture/README.md)

---

## 📱 Mobile Development

**Focus**: React Native application, offline-first architecture, and mobile-specific patterns

### 🏗️ Architecture & Design
- **[Development Patterns](./mobile/development-patterns.md)** - React Native patterns, UI layouts, conditional rendering, state management, performance ⭐
- **[Mobile Container Architecture](./mobile/architecture/mobile-container-architecture.md)** - Application architecture
- **[App Components](./mobile/app-components.md)** - Component organization and patterns
- **[Navigation](./mobile/architecture/navigation.md)** - React Navigation implementation
- **[Offline-First Architecture](./mobile/architecture/offline-first.md)** - MMKV storage and sync patterns
- **[State Management](./mobile/architecture/state-management.md)** - Context, Zustand, and data flow

### 📋 Requirements & Specifications
- **[Mobile Requirements](./mobile/requirements.md)** - Feature requirements and technical specifications

### 🛠️ Development Support
- **[Mobile Troubleshooting Guide](./mobile/troubleshooting-guide.md)** - Comprehensive debugging guide for development issues, build failures, and performance problems. Related: [CLAUDE.md Context Management](./development/claude-context-management.md) ⭐
- **[Multi-Tenant Superuser](./admin/multi-tenant-superuser.md)** - Superuser tenant switching and X-Selected-Tenant-Id header mechanism ⭐
- **[AI Testing Tools](./admin/ai-testing-tools.md)** - Dev-admin tools for AI prompt testing and FICM code verification ⭐

**💡 Quick Access**: [Mobile Development README](./mobile/development/README.md)

---

## 🔄 Operational Workflows

**Focus**: Development workflows, deployment procedures, testing strategies, and operational processes

### 🔧 Development Workflows
- **[Documentation Search Guide](./workflows/documentation-search-guide.md)** - AI-powered search with cost-effective workflows and mode selection guide ⭐ NEW
- **[Dependency Management](./workflows/dependency-management.md)** - Comprehensive guide for managing dependencies and cleaning build artifacts ⭐ NEW
- **[Git Commit Standards](./workflows/git-commit-standards.md)** - Professional git commit standards and formatting guidelines with explicit staging step ⭐ UPDATED
- **[Git Merge Strategy](./workflows/git-merge-strategy.md)** - Branching and merging workflows
- **[Graphite Workflows](./workflows/graphite-workflows.md)** - Stack-based development with GT CLI for professional PR workflows ⭐
- **[PR Analysis Guide](./workflows/pr-analysis-guide.md)** - Unified mega analyzer with comprehensive PR analysis and AI insights ⭐ UPDATED
- **[Claude Review Workflows](./workflows/claude-review-workflows.md)** - GitHub AI code reviews with targeted categories and cost metrics ⭐ UPDATED
- **[Codex Review Workflows](./workflows/codex-review-workflows.md)** - Secondary AI reviewer with summary + inline comments ⭐ NEW
- **[Layout Migration Completed](./workflows/)** - Layout migration has been completed for all admin pages ✅

### 🚀 Deployment & Operations
- **[CI/CD Build Guide](./workflows/ci-cd-build-guide.md)** - Complete pipeline documentation with matrix test strategy for 3x faster backend tests ⭐
- **[GitHub Actions Best Practices](./workflows/github-actions-best-practices.md)** - Workflow optimization patterns and cache strategies ⭐
- **[Smart Build Triggering](./workflows/smart-build-triggering.md)** - Intelligent path-based build optimization saving 43 min/build and $4/skip ⭐ NEW
- **[Build Metrics Dashboard Documentation](./workflows/build-metrics-dashboard.md)** - GitHub Pages dashboard for monitoring build optimization metrics and cost savings ⭐ NEW
- **[Deployment Guide](./workflows/deployment-guide.md)** - Multi-environment deployment strategies ⭐
- **[AWS Deployment Guide](./workflows/aws-deployment-guide.md)** - Production deployment procedures ⭐
- **[Deployment Verification Integration](./workflows/deployment-verification-integration.md)** - Comprehensive ECS deployment verification system integration 🆕
- **[EAS Build Metrics Dashboard](https://degree-analytics.github.io/spacewalker/dashboard.html)** - Live dashboard for monitoring EAS build optimization metrics 🆕
- **[Database Access](./workflows/database-access.md)** - Comprehensive secure database operations with 37+ commands ⭐
- **[User Management Utility Guide](./workflows/user-purge-utility-guide.md)** - Unified user and invitation management with auto-detection, transaction integrity, audit logging, and GDPR compliance ⭐
- **[Bastion Management](./workflows/bastion-management.md)** - IP access control and SSH bastion host management ⭐
- **[Demo Data Management](./workflows/demo-data-management.md)** - Safe demo data procedures
- **[Production Monitoring Deployment](./workflows/production-monitoring-deployment.md)** - Complete production monitoring setup and validation ⭐

### 📊 Monitoring & Alerting
- **[Monitoring Runbook](./monitoring/monitoring-runbook.md)** - Operational procedures for monitoring system management ⭐
- **[Slack Integration Setup](./monitoring/slack-integration-setup.md)** - Complete Slack webhook configuration and testing ⭐
- **[Alert Thresholds and Escalation](./monitoring/alert-thresholds-and-escalation.md)** - Alert configuration and response procedures

### 📈 Product Analytics
- **[Product Analytics Implementation](./product-analytics/product-analytics.md)** - Comprehensive PostHog integration guide with event tracking, configuration, and architecture ⭐

### 🧪 Testing & Quality
- **[Testing Guide](./workflows/testing-guide.md)** - Comprehensive testing strategies including E2E testing with Playwright ⭐
- **[Test Execution Documentation](./workflows/test-execution-documentation.md)** - Complete guide for executing test suites with environment setup, commands, and coverage reporting ⭐
- **[Testing Strategy](./workflows/testing-strategy.md)** - Framework-specific testing approaches
- **[Admin E2E Testing Framework](../tests/docs/README.md)** - Complete E2E testing documentation for admin dashboard ⭐

### 🛠️ Workflow Automation
- **[Enhanced Workflows](./workflows/enhanced-workflows.md)** - Professional-grade intelligent workflow automation
- **[Documentation & Justfile Cleanup](./workflows/cleanup-docs-justfile-deprecated.md)** - Review and update documentation and automation after development work ⭐ **(DEPRECATED: Use `/cleanup-docs-justfile` command)**

### 🔍 Debugging & Troubleshooting
- **[Logging Guide](./workflows/logging-guide.md)** - Unified log viewing with `logs` command across all services and environments ⭐
- **[Troubleshooting Guide](./workflows/troubleshooting-guide.md)** - Systematic problem solving and recovery procedures ⭐
- **[GitHub Actions Analysis Guide](./workflows/github-actions-analysis.md)** - CI/CD failure debugging with `just gh-actions` commands ⭐
- **[ast-grep Troubleshooting Guide](./workflows/ast-grep-troubleshooting.md)** - Comprehensive debugging guide for ast-grep integration issues, performance problems, and security rule violations ⭐ NEW

**💡 Quick Access**: [Operational Workflows README](./workflows/README.md)

---

## ⚠️ Common Issues & Solutions

**Focus**: Troubleshooting, gotchas, and solutions to frequently encountered problems

### 🐛 Development Issues
- **[API Trailing Slashes](./gotchas/api-trailing-slashes.md)** - Critical authentication issue with FastAPI endpoints ⭐
- **[Variable Name Mismatches](./gotchas/variable-name-mismatches.md)** - Common naming convention conflicts
- **[Mobile Hermes Compatibility](./gotchas/mobile-hermes-compatibility.md)** - React Native JavaScript engine issues
- **[Mobile React 19 Testing](./gotchas/mobile-react19-testing.md)** - React Native testing library compatibility

### 🔒 Security & Infrastructure
- **[Database Security Gotchas](./gotchas/database-security-gotchas.md)** - SSH security, credential management, and database access security ⭐
- **[localStorage Security](./gotchas/localstorage-security.md)** - JSON injection prevention and secure localStorage patterns ⭐
- **[AWS Security Practices](./gotchas/aws-security-practices.md)** - Security configuration pitfalls
- **[Production Deployment](./gotchas/production-deployment.md)** - Production-specific deployment challenges and solutions ⭐
- **[BACnet Timeout Debugging](./gotchas/bacnet-timeout-debugging.md)** - Protocol-specific debugging

### 🐛 UI/UX Issues
- **[Table Filter Dependencies](./gotchas/table-filter-dependencies.md)** - Common filter dependency anti-patterns and solutions ⭐

### 🧪 Testing & E2E Issues
- **[Playwright Testing Gotchas](./gotchas/playwright-testing-gotchas.md)** - Playwright timing issues, selector strategies, and test reliability patterns ⭐

### 🏢 Data Loading & Multi-Tenancy
- **[FICM Loading Issues](./troubleshooting/ficm-loading.md)** - Troubleshooting FICM code loading and data structure mismatches ⭐

### ⚡ CI/CD & Performance
- **[CI/CD Performance Anti-Patterns](./gotchas/ci-cd-performance-anti-patterns.md)** - Artifact vs cache patterns and performance optimization ⭐

**💡 Quick Access**: [Gotchas README](./gotchas/README.md)

---

## 🎯 Documentation by Use Case

### 🆕 New Developer Onboarding
1. **[Quick Start Guide](./setup/quick-start.md)** - Get running in 5 minutes
2. **[Development Setup](./setup/development-setup.md)** - Complete environment setup
3. **[System Context](./architecture/system-context.md)** - Understand the big picture
4. **Role-specific documentation** (Backend/Mobile/Admin sections above)

### 🏗️ Architecture Understanding
1. **[System Context](./architecture/system-context.md)** - External dependencies and actors
2. **[System Container Overview](./architecture/system-container-overview.md)** - Internal system structure
3. **[Runtime Sequences](./architecture/runtime-sequences.md)** - How systems interact
4. **[Inventory vs Rooms API Pattern](./architecture/inventory-vs-rooms-api-pattern.md)** - Dual API architecture for room management
5. **Component-specific architecture** (in each role section)

### 🚀 Feature Development
1. **[API Development Guide](./backend/api-development.md)** - Backend feature patterns
2. **[Rooms API Quick Reference](./development/rooms-api-quick-reference.md)** - Frontend API usage guide
3. **[Development Patterns](./mobile/development-patterns.md)** - Mobile feature patterns
4. **[Admin Architecture](./admin/architecture/)** - Dashboard feature patterns
5. **[Graphite Workflows](./workflows/graphite-workflows.md)** - Stack-based development with GT CLI
6. **[TaskMaster Commands](/tm/help)** - AI-assisted project management
7. **[Testing Guide](./workflows/testing-guide.md)** - Quality assurance
8. **[Admin E2E Testing](../tests/docs/README.md)** - End-to-end testing for dashboard features

### 🐛 Issue Resolution
1. **[Troubleshooting Guide](./workflows/troubleshooting-guide.md)** - Systematic problem solving
2. **[Gotchas Section](#common-issues--solutions)** - Known issues and solutions
3. **[Database Access](./workflows/database-access.md)** - Database debugging
4. **Component-specific debugging** (in each role section)

### 🚢 Deployment & Operations
1. **[AWS Deployment Guide](./workflows/aws-deployment-guide.md)** - Production deployment
2. **[Environment Configuration](./setup/environment-configuration.md)** - Multi-environment setup
3. **[Database Migrations](./backend/database-migrations.md)** - Schema evolution
4. **[Demo Data Management](./workflows/demo-data-management.md)** - Data operations

---

## 📖 Documentation Standards

### ⭐ Priority Levels
- **⭐ Essential** - Must-read documentation for your role
- **Standard** - Important reference material
- **Specialized** - Deep-dive topics for specific scenarios

### 🏷️ Document Categories
- **🏗️ Architecture** - System design and component structure
- **📋 Requirements** - Functional and technical specifications
- **🛠️ Development** - Implementation patterns and procedures
- **🚀 Operations** - Deployment and operational procedures
- **🧪 Testing** - Quality assurance and validation
- **⚠️ Troubleshooting** - Problem resolution and debugging

### 📅 Freshness Indicators
- **Current** - Actively maintained, reflects production state
- **Draft** - Under development, may have incomplete sections
- **Legacy** - Older documentation, may need updates

---

## 🔍 Search and Discovery

### Finding Documentation
- **By Role** - Use the role-based sections above for targeted navigation
- **By Use Case** - Use the use case sections for workflow-oriented discovery
- **By Problem** - Start with [Troubleshooting Guide](./workflows/troubleshooting-guide.md) or [Gotchas](#common-issues--solutions)
- **By Component** - Navigate directly to backend/, mobile/, admin/ directories

### Cross-References
Most documents include smart cross-references to related documentation. Look for:
- **See Also** sections with related topics
- **Implementation Details** links to code and procedures
- **Architecture References** links to design documentation

### Documentation Maintenance
- All documents include metadata headers with version, date, and status
- Documents are organized by logical grouping with minimal hierarchy depth
- Cross-references are validated and maintained for accuracy

---

## 🆘 Need Help?

### Quick Reference
- **Can't find what you need?** Check the [Troubleshooting Guide](./workflows/troubleshooting-guide.md)
- **Development issues?** Browse the [Gotchas section](#common-issues--solutions)
- **New to the project?** Start with [Quick Start Guide](./setup/quick-start.md)
- **Architecture questions?** Begin with [System Context](./architecture/system-context.md)

### Support Resources
- **Development Setup Issues** → [Development Setup](./setup/development-setup.md)
- **Database Problems** → [Database Access](./workflows/database-access.md)
- **Deployment Issues** → [AWS Deployment Guide](./workflows/aws-deployment-guide.md)
- **Testing Problems** → [Testing Guide](./workflows/testing-guide.md)

---

**🎯 Navigation Tip**: Use your browser's search function (Ctrl/Cmd+F) to quickly find specific topics within this index. Most documents are designed for quick scanning with clear headings and consistent structure.

**📊 Documentation Stats**: This hub organizes 175+ comprehensive guides across 6 specialized directories, providing role-based navigation and use-case driven discovery for maximum developer productivity.

---

**Last Updated:** 2025-07-27
**Status:** Current
