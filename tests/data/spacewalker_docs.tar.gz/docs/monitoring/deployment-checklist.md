# SpaceWalker Monitoring System - Deployment Checklist

## 📋 Pre-Deployment Checklist

### Prerequisites Verification
- [ ] AWS CLI configured with appropriate permissions
- [ ] SAM CLI installed and updated
- [ ] Project environment properly set up (`just env_setup`)
- [ ] Slack webhook URL available for notification setup
- [ ] Target environment accessible (dev/prod)

### Infrastructure Dependencies
- [ ] Foundation stack deployed (`dev-spacewalker-foundation`)
- [ ] Database stack deployed (`dev-spacewalker-database`) 
- [ ] ECS cluster deployed (`dev-spacewalker-ecs-cluster`)
- [ ] Backend service deployed (`dev-spacewalker-backend`)
- [ ] All prerequisite CloudFormation exports available

---

## 🚀 Deployment Steps

### Step 1: Deploy Monitoring Infrastructure
```bash
# Deploy basic monitoring (SNS topic, log groups, Lambda)
just aws_deploy_monitoring dev

# Verify deployment
aws cloudformation describe-stacks \
  --stack-name dev-spacewalker-monitoring \
  --query 'Stacks[0].StackStatus'
```
**Expected Result:** `CREATE_COMPLETE` or `UPDATE_COMPLETE`

### Step 2: Configure Slack Integration
```bash
# Create Slack webhook secret
aws secretsmanager create-secret \
  --name "dev/spacewalker/slack-webhook" \
  --description "Slack webhook for SpaceWalker monitoring alerts" \
  --secret-string '{"webhook_url": "YOUR_SLACK_WEBHOOK_URL_HERE"}'

# Verify secret creation
aws secretsmanager describe-secret \
  --secret-id "dev/spacewalker/slack-webhook"
```
**Expected Result:** Secret created successfully

### Step 3: Deploy CloudWatch Alarms
```bash
# Deploy alarm stack
python -m scripts.deployment.deploy --env dev --component cloudwatch-alarms

# Verify alarms created
aws cloudwatch describe-alarms \
  --alarm-name-prefix "dev-spacewalker-" \
  --query 'MetricAlarms[].{Name:AlarmName,State:StateValue}'
```
**Expected Result:** 13 alarms in `OK` or `INSUFFICIENT_DATA` state

### Step 4: Deploy CloudWatch Dashboards
```bash
# Deploy dashboard stack
python -m scripts.deployment.deploy --env dev --component cloudwatch-dashboards

# Verify dashboards created
aws cloudwatch list-dashboards \
  --dashboard-name-prefix "dev-spacewalker"
```
**Expected Result:** 4 dashboards created successfully

---

## ✅ Post-Deployment Validation

### Test 1: MANDATORY E2E Testing 🎭
```bash
# REQUIRED: After deploying with just aws_deploy_backend/admin dev
just e2e_post_deploy dev
```
**Expected Result:** All E2E tests pass, confirming deployed application works correctly

**🚨 CRITICAL:** Do not proceed if E2E tests fail - investigate and fix issues immediately

### Test 2: Monitoring Infrastructure
```bash
cd sam/monitoring
python test-monitoring.py dev
```
**Expected Result:** All tests pass with 100% success rate

### Test 3: Alarm Functionality
```bash
python test-alarms.py dev
```
**Expected Result:** All 15 alarms (13 individual + 2 composite) validate successfully

### Test 4: Dashboard Accessibility
```bash
python test-dashboards.py dev
```
**Expected Result:** All 4 dashboards accessible with proper widget configuration

### Test 4: End-to-End Alert Testing
```bash
# Trigger a test alarm (safe in dev)
aws cloudwatch put-metric-data \
  --namespace "SpaceWalker/dev/Testing" \
  --metric-data MetricName=TestMetric,Value=100,Unit=Count

# Check Slack notification delivery
# Monitor #alerts channel for test notification
```
**Expected Result:** Slack notification received with dashboard links

---

## 🔍 Validation Checklist

### Infrastructure Components
- [ ] SNS Topic: `dev-spacewalker-alerts` exists and accessible
- [ ] Lambda Function: `spacewalker-slack-notifications-dev` deployed and configured
- [ ] CloudWatch Log Groups: Created with 90-day retention
- [ ] IAM Roles: Proper permissions for Lambda execution and CloudWatch access

### Alarms Configuration
- [ ] **ALB Alarms:** 5 alarms for error rates, response times, and health
- [ ] **ECS Alarms:** 5 alarms for CPU, memory, and task count
- [ ] **Lambda Alarms:** 3 alarms for error rate, duration, and throttles
- [ ] **Composite Alarms:** 2 alarms for system health and performance
- [ ] All alarms correctly reference SNS topic for notifications

### Dashboard Setup
- [ ] **System Overview:** Comprehensive system health dashboard
- [ ] **Error Analysis:** Detailed error tracking and trends
- [ ] **Performance:** Response times and resource utilization
- [ ] **Real-time:** Live monitoring with auto-refresh
- [ ] All dashboards include relevant metrics and proper time ranges

### Slack Integration
- [ ] Webhook URL stored securely in Secrets Manager
- [ ] Lambda function can retrieve webhook URL
- [ ] Test notifications include severity indicators
- [ ] Dashboard links in notifications are functional
- [ ] Message formatting includes relevant context and actions

---

## 🛠️ Troubleshooting Common Issues

### Issue: CloudWatch Alarms Stack Deployment Fails
**Symptom:** `No export named dev-spacewalker-alert-topic-arn found`
**Solution:**
1. Ensure monitoring stack is deployed first
2. Verify SNS topic export is available:
   ```bash
   aws cloudformation list-exports | rg "alert-topic-arn"
   ```

### Issue: Slack Notifications Not Working
**Symptom:** Alarms trigger but no Slack messages received
**Troubleshooting:**
1. Check Lambda function logs:
   ```bash
   aws logs tail /aws/lambda/spacewalker-slack-notifications-dev
   ```
2. Verify webhook URL in Secrets Manager
3. Test webhook manually:
   ```bash
   curl -X POST -H 'Content-type: application/json' \
     --data '{"text":"Test message"}' \
     $SLACK_WEBHOOK_URL
   ```

### Issue: Dashboard "No Data Available"
**Symptom:** Dashboards show no data for metrics
**Solution:**
1. Verify services are running and generating metrics
2. Check metric namespaces and dimensions:
   ```bash
   aws cloudwatch list-metrics \
     --namespace AWS/ApplicationELB \
     --dimensions Name=LoadBalancer,Value=dev-spacewalker-backend-alb
   ```

### Issue: False Positive Alarms
**Symptom:** Alarms triggering for normal operations
**Solution:**
1. Review metric baselines over past week
2. Adjust thresholds in `cloudwatch-alarms.yaml`
3. Redeploy alarm stack with updated thresholds

---

## 📊 Expected Metrics and Baselines

### Normal Operation Baselines (Dev Environment)
| Metric | Expected Range | Alert Threshold |
|--------|----------------|-----------------|
| **ALB 4XX Errors** | 0-5 per 5min | > 10 per 5min |
| **ALB 5XX Errors** | 0-2 per 5min | > 5 per 5min |
| **Response Time** | 200-800ms | > 2000ms |
| **ECS CPU** | 20-60% | > 80% |
| **ECS Memory** | 30-70% | > 85% |
| **Running Tasks** | 2-4 tasks | < 1 task |

### Production Environment Adjustments
- Lower error rate thresholds (more sensitive)
- Shorter evaluation periods for faster detection
- Additional escalation procedures
- More conservative resource utilization thresholds

---

## 🔄 Regular Maintenance Tasks

### Daily (Automated)
- [ ] Monitoring system health check
- [ ] Alert volume and false positive rate calculation
- [ ] Dashboard accessibility verification

### Weekly (Manual Review)
- [ ] Review alert effectiveness metrics
- [ ] Check for new services requiring monitoring
- [ ] Validate threshold accuracy against actual usage patterns
- [ ] Update documentation for any changes

### Monthly (Team Review)
- [ ] Comprehensive monitoring strategy review
- [ ] Cost optimization assessment
- [ ] Threshold tuning based on operational data
- [ ] Training updates for team members

---

## 📞 Support and Contact Information

### Deployment Issues
- **DevOps Team:** #devops-team (Slack)
- **Infrastructure Team:** #infrastructure (Slack)
- **Documentation:** This repository, `/docs/monitoring/`

### Operational Issues
- **Immediate Support:** #alerts (Slack)
- **On-Call Engineer:** PagerDuty escalation
- **AWS Support:** Enterprise Support Plan

### Resource Links
- **Monitoring Runbook:** [monitoring-runbook.md](./monitoring-runbook.md)
- **Alert Procedures:** [alert-thresholds-and-escalation.md](./alert-thresholds-and-escalation.md)
- **CloudWatch Documentation:** [AWS CloudWatch User Guide](https://docs.aws.amazon.com/cloudwatch/)

---

## ✅ Completion Verification

### Final Checklist
- [ ] All infrastructure components deployed successfully
- [ ] Test suite passes with 100% success rate
- [ ] Slack integration working end-to-end
- [ ] Dashboards accessible and displaying data
- [ ] Team notified of new monitoring capabilities
- [ ] Documentation updated and accessible
- [ ] Runbook procedures tested and validated

### Sign-off
- [ ] **Technical Lead Approval:** Monitoring system meets requirements
- [ ] **DevOps Team Approval:** Infrastructure properly configured
- [ ] **Team Training:** All team members familiar with alert procedures

---

**Deployment Date:** ___________  
**Deployed By:** ___________  
**Approved By:** ___________  

*This checklist should be completed for each environment deployment and kept as a record of the monitoring system setup.*