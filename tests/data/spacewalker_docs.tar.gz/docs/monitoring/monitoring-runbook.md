# SpaceWalker Monitoring System - Operational Runbook

## 🎯 Quick Start Guide

This runbook provides step-by-step procedures for managing the SpaceWalker monitoring system.

**For Emergencies:** See [Emergency Procedures](#-emergency-procedures)
**For Alert Response:** See [Alert Response Guide](#-alert-response-procedures)

---

## 🚀 Deployment Procedures

### Initial Setup (New Environment)

1. **Deploy Infrastructure Components**
   ```bash
   # Deploy in dependency order
   just aws_deploy_foundation dev
   just aws_deploy_monitoring dev
   just aws_deploy_backend dev  # Required for alarm dependencies

   # Note: Alarms and dashboards are deployed as part of monitoring stack
   # No separate deployment commands needed
   ```

2. **Configure Slack Integration**
   ```bash
   # Create Slack webhook secret
   just secrets_create_slack dev "https://hooks.slack.com/services/..."

   # Alternative manual method:
   # aws secretsmanager create-secret \
   #   --name "dev/spacewalker/slack-webhook" \
   #   --description "Slack webhook for monitoring alerts" \
   #   --secret-string '{"webhook_url": "https://hooks.slack.com/..."}'
   ```

3. **Verify Complete Setup**
   ```bash
   # Comprehensive monitoring validation
   just monitor validate dev

   # Test Slack integration specifically
   just monitor slack-test dev

   # Check all secrets are configured
   just health dev
   ```

### Updating Thresholds

1. **Edit Alarm Thresholds**
   ```bash
   # Update sam/monitoring/monitoring.yaml
   # Modify Parameters section for new thresholds
   ```

2. **Deploy Changes**
   ```bash
   just aws deploy monitoring dev
   ```

3. **Validate Changes**
   ```bash
   python sam/monitoring/test-alarms.py dev
   ```

### Adding New Alarms

1. **Define New Alarm in Template**
   ```yaml
   # Add to sam/monitoring/monitoring.yaml
   NewServiceAlarm:
     Type: AWS::CloudWatch::Alarm
     Properties:
       AlarmName: !Sub '${Environment}-spacewalker-new-service-alert'
       # ... alarm configuration
   ```

2. **Update Testing Script**
   ```python
   # Add to expected_alarms list in test-alarms.py
   self.expected_alarms = [
       # ... existing alarms
       f'{environment}-spacewalker-new-service-alert'
   ]
   ```

3. **Deploy and Test**
   ```bash
   just aws deploy monitoring dev
   python sam/monitoring/test-alarms.py dev
   ```

---

## 🔍 Alert Response Procedures

### Step 1: Initial Assessment (0-2 minutes)

1. **Read the Alert**
   - Check severity level (Critical/High/Medium/Low)
   - Note the affected service and metric
   - Review the current value vs threshold

2. **Access Dashboards**
   - Click dashboard links in Slack alert
   - Start with "System Overview" for context
   - Switch to specific dashboard based on alert type

3. **Check System Status**
   ```bash
   # Quick system health check
   curl -f https://backend.spacewalker.littleponies.com/health/

   # Check ECS service status
   aws ecs describe-services \
     --cluster dev-spacewalker-ecs-cluster \
     --services dev-spacewalker-backend
   ```

### Step 2: Investigation (2-10 minutes)

1. **Review Recent Changes**
   ```bash
   # Check recent deployments
   git log --oneline -10

   # Check CloudFormation change sets
   aws cloudformation describe-stack-events \
     --stack-name dev-spacewalker-backend \
     --max-items 10
   ```

2. **Analyze Logs**
   ```bash
   # Check application logs
   aws logs tail /ecs/dev-spacewalker-backend --follow

   # Check for error patterns
   aws logs filter-log-events \
     --log-group-name /ecs/dev-spacewalker-backend \
     --start-time $(date -d '1 hour ago' +%s)000 \
     --filter-pattern "ERROR"
   ```

3. **Check Dependencies**
   - Database connectivity and performance
   - External API availability
   - AWS service health dashboard

### Step 3: Response Actions

#### For High Error Rates (4XX/5XX)
1. **Immediate Actions**
   ```bash
   # Check target health
   aws elbv2 describe-target-health \
     --target-group-arn $(aws elbv2 describe-target-groups \
       --names dev-spacewalker-backend-tg \
       --query 'TargetGroups[0].TargetGroupArn' --output text)

   # Check recent deployments
   aws ecs describe-services \
     --cluster dev-spacewalker-ecs-cluster \
     --services dev-spacewalker-backend \
     --query 'services[0].deployments'
   ```

2. **If Recent Deployment**
   ```bash
   # Rollback if necessary
   aws ecs update-service \
     --cluster dev-spacewalker-ecs-cluster \
     --service dev-spacewalker-backend \
     --task-definition <previous-task-definition-arn>
   ```

#### For High Response Times
1. **Check Resource Usage**
   ```bash
   # Get CPU/Memory utilization
   aws cloudwatch get-metric-statistics \
     --namespace AWS/ECS \
     --metric-name CPUUtilization \
     --dimensions Name=ServiceName,Value=dev-spacewalker-backend \
                  Name=ClusterName,Value=dev-spacewalker-ecs-cluster \
     --start-time $(date -d '1 hour ago' -u +%Y-%m-%dT%H:%M:%S) \
     --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
     --period 300 \
     --statistics Average
   ```

2. **Scale Service if Needed**
   ```bash
   # Increase desired count
   aws ecs update-service \
     --cluster dev-spacewalker-ecs-cluster \
     --service dev-spacewalker-backend \
     --desired-count 3
   ```

#### For Resource Exhaustion (CPU/Memory)
1. **Immediate Scaling**
   ```bash
   # Scale up tasks
   aws ecs update-service \
     --cluster dev-spacewalker-ecs-cluster \
     --service dev-spacewalker-backend \
     --desired-count 4
   ```

2. **Check for Memory Leaks**
   ```bash
   # Review memory usage trends
   aws logs filter-log-events \
     --log-group-name /ecs/dev-spacewalker-backend \
     --filter-pattern "OutOfMemory"
   ```

### Step 4: Documentation and Follow-up

1. **Document Actions Taken**
   ```markdown
   ## Incident Response: [Alert Name] - [Date/Time]

   **Alert:** [Description]
   **Severity:** [Level]
   **Duration:** [Start - End time]

   **Root Cause:** [Analysis]
   **Actions Taken:**
   - [Action 1]
   - [Action 2]

   **Resolution:** [How it was fixed]
   **Prevention:** [Steps to prevent recurrence]
   ```

2. **Update Slack Thread**
   - Summarize findings and actions
   - Confirm resolution
   - Mark as resolved

---

## 🛠️ Maintenance Procedures

### Daily Checks

1. **Alert Review**
   ```bash
   # Check alert volume from last 24 hours
   aws logs filter-log-events \
     --log-group-name /aws/lambda/spacewalker-slack-notifications-dev \
     --start-time $(date -d '1 day ago' +%s)000 \
     --filter-pattern "sent successfully"
   ```

2. **Dashboard Health**
   - Verify all dashboards load correctly
   - Check for missing data or visualization issues
   - Validate metric completeness

### Weekly Maintenance

1. **Threshold Review**
   ```bash
   # Run comprehensive testing
   python sam/monitoring/test-alarms.py dev
   python sam/monitoring/test-dashboards.py dev

   # Generate metrics report
   python scripts/monitoring/weekly-report.py dev
   ```

2. **False Positive Analysis**
   - Review alerts that didn't require action
   - Consider threshold adjustments
   - Update alert configurations if needed

### Monthly Tasks

1. **Capacity Planning**
   ```bash
   # Generate utilization report
   python scripts/monitoring/capacity-report.py dev
   ```

2. **Cost Optimization**
   ```bash
   # Review CloudWatch costs
   aws ce get-cost-and-usage \
     --time-period Start=2024-01-01,End=2024-01-31 \
     --granularity MONTHLY \
     --metrics BlendedCost \
     --group-by Type=DIMENSION,Key=SERVICE
   ```

---

## 🚨 Emergency Procedures

### Complete System Outage

1. **Immediate Response (0-2 minutes)**
   ```bash
   # Check AWS service health
   curl -s https://status.aws.amazon.com/

   # Quick connectivity test
   curl -I https://backend.spacewalker.littleponies.com/health/
   ```

2. **Emergency Scaling (2-5 minutes)**
   ```bash
   # Force service restart
   aws ecs update-service \
     --cluster dev-spacewalker-ecs-cluster \
     --service dev-spacewalker-backend \
     --force-new-deployment

   # Scale to maximum capacity
   aws ecs update-service \
     --cluster dev-spacewalker-ecs-cluster \
     --service dev-spacewalker-backend \
     --desired-count 6
   ```

3. **Database Issues**
   ```bash
   # Check RDS status
   aws rds describe-db-instances \
     --db-instance-identifier dev-spacewalker-db

   # Check connections
   aws rds describe-db-log-files \
     --db-instance-identifier dev-spacewalker-db
   ```

### Monitoring System Failure

1. **Detection**
   ```bash
   # Test alert delivery
   python sam/monitoring/test-alert-delivery.py dev

   # Check Lambda function health
   aws lambda get-function \
     --function-name spacewalker-slack-notifications-dev
   ```

2. **Recovery**
   ```bash
   # Redeploy monitoring stack
   just aws_deploy_monitoring dev

   # Restart Lambda function
   aws lambda update-function-code \
     --function-name spacewalker-slack-notifications-dev \
     --zip-file fileb://sam/monitoring/.aws-sam/build/SlackNotificationFunction/function.zip
   ```

---

## 🔧 Troubleshooting Guide

### Common Issues and Solutions

#### "No data available" in Dashboard
```bash
# Check metric availability
aws cloudwatch list-metrics \
  --namespace AWS/ApplicationELB \
  --dimensions Name=LoadBalancer,Value=dev-spacewalker-backend-alb

# Verify service is running
aws ecs describe-services \
  --cluster dev-spacewalker-ecs-cluster \
  --services dev-spacewalker-backend
```

#### Slack Notifications Not Working
```bash
# Check Lambda function logs
aws logs tail /aws/lambda/spacewalker-slack-notifications-dev

# Test webhook URL
curl -X POST -H 'Content-type: application/json' \
  --data '{"text":"Test message"}' \
  $SLACK_WEBHOOK_URL

# Check secrets manager
aws secretsmanager get-secret-value \
  --secret-id dev/spacewalker/slack-webhook
```

#### False Positive Alarms
```bash
# Check actual metric values
aws cloudwatch get-metric-statistics \
  --namespace AWS/ApplicationELB \
  --metric-name HTTPCode_Target_4XX_Count \
  --dimensions Name=LoadBalancer,Value=dev-spacewalker-backend-alb \
  --start-time $(date -d '1 hour ago' -u +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Sum

# Review alarm history
aws cloudwatch describe-alarm-history \
  --alarm-name dev-spacewalker-alb-high-4xx-errors
```

### Performance Issues

#### Dashboard Loading Slowly
1. **Check CloudWatch API limits**
2. **Reduce metric query time ranges**
3. **Optimize widget configurations**

#### High Alert Volume
1. **Review threshold settings**
2. **Implement alert grouping**
3. **Use composite alarms**

---

## 📊 Metrics and KPIs

### Key Monitoring Metrics

```bash
# Generate weekly monitoring report
python scripts/monitoring/metrics-report.py --period week --environment dev

# Key metrics to track:
# - Alert volume per day
# - False positive rate
# - Mean time to detection (MTTD)
# - Mean time to resolution (MTTR)
# - Dashboard usage statistics
```

### Monitoring System Health

```bash
# Check monitoring infrastructure health
aws cloudformation describe-stacks \
  --stack-name dev-spacewalker-monitoring \
  --query 'Stacks[0].StackStatus'
```

---

## 📞 Contact Information and Escalation

### Primary Contacts
- **On-Call Engineer:** Accessible via PagerDuty
- **DevOps Team:** #devops-team (Slack)
- **System Admin:** #infrastructure (Slack)

### Escalation Matrix
1. **Level 1:** Alert in #alerts channel
2. **Level 2:** Page on-call engineer (Critical alerts)
3. **Level 3:** Escalate to team lead (15+ minute resolution)
4. **Level 4:** Incident commander (30+ minute major impact)

### Emergency Contacts
- **AWS Support:** Enterprise Support, 24/7 phone support
- **Critical Issues:** Direct escalation to senior engineering

---

## 📚 Additional Resources

### Documentation Links
- [Alert Thresholds and Escalation](./alert-thresholds-and-escalation.md)
- [Monitoring Configuration](../../sam/monitoring/monitoring.yaml)
- [Slack Lambda Function](../../sam/monitoring/lambda/slack-notifications/)

### AWS Documentation
- [CloudWatch User Guide](https://docs.aws.amazon.com/cloudwatch/)
- [ECS Monitoring](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/cloudwatch-metrics.html)
- [Application Load Balancer Monitoring](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/load-balancer-monitoring.html)

### Tools and Scripts
- Testing Scripts: `sam/monitoring/test-*.py`
- Deployment Scripts: `scripts/deployment/`
- Monitoring Utilities: `scripts/monitoring/`

---

*This runbook should be kept current with system changes and operational learnings.*
