# Slack Integration Setup for SpaceWalker Monitoring

## Purpose
Complete guide for setting up Slack notifications for SpaceWalker monitoring alerts, including webhook configuration, secret management, and testing procedures.

## When to Use This
- Setting up monitoring alerts for new environments
- Configuring Slack notifications for production alerts
- Troubleshooting Slack integration issues
- Migrating Slack webhooks or channels

**Keywords:** slack, monitoring, alerts, notifications, webhook, integration

---

## 🚀 Quick Setup (5 Minutes)

### Prerequisites
- Slack workspace with appropriate permissions
- AWS CLI configured for target environment
- SpaceWalker monitoring infrastructure deployed

### Step 1: Create Slack Webhook
1. Go to your Slack workspace settings
2. Navigate to **Apps** → **Incoming Webhooks**
3. Click **Add to Slack**
4. Select the target channel:
   - Development: `#spacewalker-dev-alerts`
   - Production: `#spacewalker-prod-alerts`
5. Copy the webhook URL (format: `https://hooks.slack.com/services/...`)

### Step 2: Configure AWS Secret
```bash
# Create the Slack webhook secret
just secrets_create_slack [env] [webhook_url]

# Example for development
just secrets_create_slack dev "https://hooks.slack.com/services/T2NT6RK6X/B094U5KPV2N/..."

# Example for production
just secrets_create_slack prod "https://hooks.slack.com/services/T2NT6RK6X/B094U5KPV2N/..."
```

### Step 3: Test Integration
```bash
# Test the Slack integration
just monitor slack-test [env]

# Validate complete monitoring setup
just monitor validate [env]
```

---

## 📋 Detailed Setup Process

### Environment-Specific Configuration

#### Development Environment
- **Channel**: `#spacewalker-dev-alerts`
- **AWS Region**: `us-east-2`
- **AWS Profile**: `default`
- **Secret Name**: `dev/spacewalker/slack-webhook`

#### Production Environment
- **Channel**: `#spacewalker-prod-alerts`
- **AWS Region**: `us-east-1`
- **AWS Profile**: `production`
- **Secret Name**: `prod/spacewalker/slack-webhook`

### Manual Secret Creation (Alternative Method)
If you prefer to create the secret manually:

```bash
# For development
aws secretsmanager create-secret \
  --name "dev/spacewalker/slack-webhook" \
  --description "Slack webhook for SpaceWalker monitoring alerts" \
  --secret-string '{"webhook_url":"https://hooks.slack.com/services/..."}' \
  --region us-east-2

# For production (requires production AWS profile)
export AWS_PROFILE=production
aws secretsmanager create-secret \
  --name "prod/spacewalker/slack-webhook" \
  --description "Slack webhook for SpaceWalker monitoring alerts" \
  --secret-string '{"webhook_url":"https://hooks.slack.com/services/..."}' \
  --region us-east-1
```

### Secret Format Requirements
The secret must be stored as JSON with the exact key name:
```json
{
  "webhook_url": "https://hooks.slack.com/services/T2NT6RK6X/B094U5KPV2N/..."
}
```

**Important**: Use `webhook_url` (lowercase with underscore), not `WEBHOOK_URL`.

---

## 🧪 Testing and Validation

### Comprehensive Testing
```bash
# Full monitoring validation (includes Slack test)
just monitor validate [env]

# Slack-specific testing
just monitor slack-test [env]

# Production monitoring health check
just monitor status prod
```

### Expected Test Results
When running `just monitor slack-test [env]`, you should see:
```
✅ Lambda invocation successful
📋 Response: Slack notification sent successfully
🎉 Slack notification sent successfully!
💬 Check your #spacewalker-[env]-alerts channel for the test message
```

### Test Message Format
The test sends a CloudWatch alarm with this format:
- **Title**: `🚨 🔴 CRITICAL: Unknown Alert` or `🚨 🟡 MEDIUM: Unknown Alert`
- **Service**: Extracted from alarm name
- **Environment**: Current environment (DEV/PROD)
- **Metric**: TestMetric
- **Threshold**: 10.0
- **Action Buttons**: Links to CloudWatch dashboards and logs

---

## 🔧 Troubleshooting

### Common Issues

#### 1. Lambda Function Not Found
**Error**: `❌ Lambda function not found`
**Solution**: Deploy monitoring infrastructure first
```bash
just aws_deploy_monitoring [env]
```

#### 2. Secret Not Found
**Error**: `❌ Secret not found or access denied`
**Solutions**:
- Create the secret: `just secrets_create_slack [env] [webhook_url]`
- Verify secret name: `just aws_secrets [env]`
- Check AWS profile/region configuration

#### 3. Webhook Authentication Failed
**Error**: Slack returns 401 or 403
**Solutions**:
- Verify webhook URL is correct and active
- Check that webhook hasn't been revoked in Slack
- Ensure webhook is for the correct Slack workspace

#### 4. Lambda Execution Errors
**Error**: Lambda returns 500 status
**Solutions**:
- Check Lambda logs: `aws logs tail /aws/lambda/spacewalker-slack-notifications-[env]`
- Verify secret format (must use `webhook_url` key)
- Ensure Lambda has proper IAM permissions

### Diagnostic Commands
```bash
# Check secret exists and format
just aws_secret_show [env] "[env]/spacewalker/slack-webhook"

# View Lambda function configuration
aws lambda get-function --function-name spacewalker-slack-notifications-[env]

# Check CloudWatch logs for errors
aws logs tail /aws/lambda/spacewalker-slack-notifications-[env] --follow

# Verify SNS topic exists
aws sns list-topics --query 'Topics[?contains(TopicArn, `spacewalker-alerts`)]'
```

---

## 🔄 Maintenance and Updates

### Updating Webhook URL
```bash
# Update existing secret with new webhook URL
just secrets_create_slack [env] "new-webhook-url"
```

### Rotating Slack Integration
1. Create new webhook in Slack
2. Update AWS secret with new URL
3. Test integration: `just monitor slack-test [env]`
4. Remove old webhook from Slack

### Monitoring Secret Health
```bash
# Check all secrets including Slack webhook
just aws_secrets_health [env]

# Production-specific health check
just monitor status
```

---

## 📊 Message Format and Customization

### Standard Alert Message Components
- **State Emoji**: 🚨 (ALARM), ✅ (OK), ⚠️ (INSUFFICIENT_DATA)
- **Severity Emoji**: 🔴 (CRITICAL), 🟠 (HIGH), 🟡 (MEDIUM), 🟢 (LOW)
- **Service Information**: Extracted from alarm name pattern
- **Environment Badge**: DEV/PROD designation
- **Action Buttons**: Direct links to relevant dashboards and logs

### Dashboard Links Included
- **System Overview**: High-level system metrics
- **Real-time Monitor**: Live monitoring dashboard
- **Error Analysis**: Error-specific metrics (for error alarms)
- **Performance**: Performance metrics (for latency/CPU alarms)
- **View Logs**: Direct link to CloudWatch logs
- **All Alarms**: CloudWatch alarms overview

---

## 🚨 Production Considerations

### Security Best Practices
- Use separate webhooks for dev and prod environments
- Regularly rotate webhook URLs
- Monitor webhook usage in Slack audit logs
- Restrict webhook creation permissions in Slack

### Channel Configuration
- **Development**: `#spacewalker-dev-alerts` - Can be noisy, used for testing
- **Production**: `#spacewalker-prod-alerts` - Critical alerts only

### Alert Escalation
Production alerts should integrate with:
- PagerDuty or similar for critical alerts
- Team notification workflows
- Incident response procedures

---

## 🔗 Related Documentation
- [Monitoring Runbook](./monitoring-runbook.md) - Complete monitoring operations
- [Alert Thresholds](./alert-thresholds-and-escalation.md) - Alert configuration
- [Production Monitoring Deployment](../workflows/production-monitoring-deployment.md) - Deployment procedures
- [Environment Configuration](../setup/environment-configuration.md) - AWS secrets setup

---

## 📝 Quick Reference

### Common Commands
```bash
# Setup
just secrets_create_slack [env] [webhook_url]

# Testing
just monitor slack-test [env]
just monitor validate [env]

# Status
just aws_secrets_health [env]
just monitor status

# Troubleshooting
just aws_secret_show [env] "[env]/spacewalker/slack-webhook"
aws logs tail /aws/lambda/spacewalker-slack-notifications-[env]
```

### Required Secrets Format
```json
{
  "webhook_url": "https://hooks.slack.com/services/T2NT6RK6X/B094U5KPV2N/..."
}
```

### Environment Mapping
- **dev**: us-east-2, default profile, #spacewalker-dev-alerts
- **prod**: us-east-1, production profile, #spacewalker-prod-alerts