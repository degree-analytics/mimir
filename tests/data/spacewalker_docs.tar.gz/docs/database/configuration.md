# Database Configuration

## Overview

SpaceWalker uses PostgreSQL with PostGIS extensions for spatial data support. The database configuration is consistent across all environments with appropriate security measures.

## Standard Configuration

### Local Development (Docker)

| Setting | Value | Description |
|---------|-------|-------------|
| **Username** | `spacewalker_user` | Application database user |
| **Password** | `spacewalker_dev` | Development password |
| **Database** | `spacewalker` | Main application database |
| **Host** | `db` | Docker service name |
| **Port** | `5432` | PostgreSQL default port |

**Connection String:**
```
postgresql://spacewalker_user:spacewalker_dev@db:5432/spacewalker
```

### Environment Variables

```env
# PostgreSQL Docker container configuration
POSTGRES_USER=spacewalker_user
POSTGRES_PASSWORD=spacewalker_dev
POSTGRES_DB=spacewalker

# Application database connection
DATABASE_URL=postgresql://spacewalker_user:spacewalker_dev@db:5432/spacewalker
```

## Database Initialization

When the PostgreSQL container starts, it automatically:

1. Creates the `spacewalker` database (via `POSTGRES_DB` environment variable)
2. Creates the `spacewalker_user` with the specified password
3. Grants all necessary permissions to `spacewalker_user`
4. Sets up PostGIS extensions if needed

The initialization script is located at: `scripts/init-db/01-init-database.sql`

## Security Notes

### Local Development
- Uses `spacewalker_user` instead of default `postgres` superuser for better security
- Password `spacewalker_dev` is only for local development
- Never use these credentials in production

### Production
- Database credentials are managed through AWS Secrets Manager
- Connection strings are injected as environment variables
- SSL/TLS connections are enforced
- Database access is restricted to VPC

## Common Issues

### "role 'spacewalker_user' does not exist"
This happens when:
1. Starting with an existing postgres data volume from an old configuration
2. The init script failed to run

**Solution:**
```bash
# Clean everything and start fresh
just clean
rm -rf .build/postgres-data
just up
```

### Password Authentication Failed
Ensure your `.env` file has the correct configuration:
```env
POSTGRES_PASSWORD=spacewalker_dev
DATABASE_URL=postgresql://spacewalker_user:spacewalker_dev@db:5432/spacewalker
```

## Testing Configuration

For automated tests:
```env
TEST_DATABASE_URL=postgresql://spacewalker_user:spacewalker_dev@localhost:5432/spacewalker_test
```

Tests create and destroy their own test database to ensure isolation.