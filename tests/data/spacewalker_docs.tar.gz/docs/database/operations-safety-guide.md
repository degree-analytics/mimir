# 🚨 Database Operations Safety Guide

**CRITICAL**: This guide covers destructive database operations that can cause IRREVERSIBLE DATA LOSS. Read carefully before using any dangerous commands.

## ⚠️ Danger Level Classification

### 🔹 **SAFE OPERATIONS** (No Data Loss Risk)
- `init` - Initialize foundation data (only adds data)
- `seed` - Add demo data (only adds data)
- `verify` - Check database state (read-only)
- `shell` - Interactive database access (you control what you run)
- `sql` - Execute specific queries (depends on what you write)
- `tunnel`, `connect`, `kill-tunnels` - Connection management
- `backup`, `restore` - Data protection operations
- `update-ip` - Security group management

### 🚨 **EXTREME DANGER** - `clean-all-non-system-tenants`
**What it does**: Removes ALL non-system tenants and their data (ALL CUSTOMER DATA!)
**Preserves**: System Tenant (ID=1) + foundation data + migration history
**Sequence behavior**: Does NOT reset sequences - new tenants get incremental IDs

**Protection levels**:
- **Local/Dev**: Standard confirmation prompt (`DELETE NON-SYSTEM TENANTS`)
- **Production**: Must type `"DELETE ALL PRODUCTION CUSTOMERS"` + `--confirm-production` flag

**Use cases**:
- Remove test tenants while keeping foundation intact
- Clean up development environment
- Reset to foundation-only state

### 🚨 **EXTREME DANGER** - `wipe-all`
**What it does**: DELETES ALL DATA from ALL TABLES + resets sequences to 1
**Destroys**: Everything except database schema and migration history
**Sequence behavior**: Resets ALL sequences to 1 - System Tenant gets ID=1

**Protection levels**:
- **Local/Dev**: Must type `"WIPE ALL DATA"`
- **Production**: Must type `"NUCLEAR WIPE ALL PRODUCTION DATA"` + `--confirm-production` flag

**Use cases**:
- Complete database reset when sequences are wrong
- Fix System Tenant ID issues (forces System Tenant back to ID=1)
- Emergency production cleanup (LAST RESORT)

### 🚨 **MAXIMUM DANGER** - `reset-physical`
**What it does**: DESTROYS database schema + recreates from scratch
**Mechanism**: Docker volume deletion OR database object dropping
**Result**: Complete reconstruction of all database structures

**Protection levels**:
- **Local only**: Must type `"RESET PHYSICAL DATABASE"`
- **Production/Dev**: **COMPLETELY BLOCKED** - not available for safety

**Use cases**:
- Local development schema corruption
- Complete local environment reset
- Migration testing (local only)

## 🛡️ Protection Mechanisms

### Multi-Layer Confirmation System

#### Level 1: Basic Confirmation
```bash
Are you sure you want to [action]? (type 'yes' to continue): yes
```

#### Level 2: Moderate Protection
```bash
This will DELETE DEMO DATA from [environment].
Type "DELETE DEMO DATA FROM [ENVIRONMENT]" to continue: DELETE DEMO DATA FROM PRODUCTION
```

#### Level 3: Nuclear Protection
```bash
🚨 NUCLEAR OPERATION DETECTED 🚨
This will DELETE ALL DATA and reset sequences in [environment]
Type "NUCLEAR WIPE ALL [ENVIRONMENT] DATA" to continue: NUCLEAR WIPE ALL PRODUCTION DATA

Additionally requires: --confirm-production flag
```

#### Level 4: Physical Destruction (Local Only)
```bash
🚨 PHYSICAL DATABASE DESTRUCTION 🚨
This will destroy Docker volumes/database schema (CANNOT BE UNDONE)
Type "RESET PHYSICAL DATABASE" to continue: RESET PHYSICAL DATABASE
```

### Environment-Specific Protections

#### Production Environment
- Extra confirmation prompts with specific text
- Additional flags required for destructive operations
- Detailed logging of all operations
- Pre-operation state capture
- Automatic backup recommendations

#### Development Environment
- Standard confirmation prompts
- Detailed operation descriptions
- Rollback suggestions where applicable

#### Local Environment
- Minimal protections (fastest workflow)
- Physical reset operations allowed
- Docker-based recovery methods

## 📋 Pre-Operation Checklist

### Before ANY Destructive Operation:

**🔍 Verification Steps:**
- [ ] Confirm you're in the correct environment: `just db verify [env]`
- [ ] Check current tenant count: `just sql "SELECT COUNT(*) FROM tenants" [env]`
- [ ] Verify System Tenant ID: `just sql "SELECT id, name FROM tenants WHERE name = 'System Tenant'" [env]`
- [ ] Review active users: `just sql "SELECT COUNT(*) as users FROM users" [env]`

**🛡️ Protection Steps:**
- [ ] Create backup if not local: `just db backup [env] --name="pre-[operation]-$(date +%Y%m%d_%H%M%S)"`
- [ ] Document reason for operation
- [ ] Notify team if production operation
- [ ] Have rollback plan ready

**⚠️ Production-Specific:**
- [ ] Get explicit approval from team lead
- [ ] Schedule during maintenance window
- [ ] Verify backup is recent and valid
- [ ] Test operation in development first

## 🔄 Recovery Procedures

### If `clean-all-non-system-tenants` Goes Wrong:
```bash
# Restore from backup
just db restore [env] [backup-id]

# Or reseed demo data
just db seed [env]
```

### If `wipe-all` Goes Wrong:
```bash
# Restore from backup (REQUIRED)
just db restore [env] [backup-id]

# If no backup available (LAST RESORT):
just db init [env]
just db seed [env]
# Manual data recreation required
```

### If `reset-physical` Goes Wrong (Local Only):
```bash
# Complete environment rebuild
just service down all
docker volume prune -f
just service up all
just db init
just db seed
```

## 📊 Operation Comparison Matrix

| Command | Data Loss | Sequence Reset | System Tenant | Schema | Backup Needed | Prod Allowed |
|---------|-----------|----------------|---------------|---------|---------------|--------------|
| `init` | ❌ None | ❌ No | ✅ Creates | ❌ No | ❌ No | ✅ Yes |
| `seed` | ❌ None | ❌ No | ❌ No | ❌ No | ❌ No | ✅ Yes |
| `clean-all-non-system-tenants` | 🚨 All Customer Data | ❌ No | ✅ Preserved | ❌ No | ✅ Required | ⚠️ Nuclear Protection |
| `wipe-all` | 🚨 Everything | ✅ Yes | 🚨 Deleted | ❌ No | ✅ Required | ⚠️ Emergency Only |
| `reset-physical` | 🚨 Everything | ✅ Yes | 🚨 Deleted | 🚨 Recreated | ❌ N/A | ❌ Blocked |

## 🚨 Emergency Procedures

### Production Data Loss Emergency:
1. **STOP ALL OPERATIONS** immediately
2. Do not run any more database commands
3. Check available backups: `just db backup list prod`
4. Restore from most recent backup: `just db restore prod [backup-id]`
5. Verify restoration: `just db verify prod`
6. Document incident and review procedures

### Sequence ID Issues in Production:
**Scenario**: System Tenant has wrong ID, new tenants failing

**Solution**:
```bash
# 1. Backup first (CRITICAL)
just db backup prod --name="pre-sequence-fix-$(date +%Y%m%d_%H%M%S)"

# 2. Nuclear option (LAST RESORT)
just db wipe-all prod --confirm-production

# 3. Restore foundation data
just db init prod
just db seed prod

# 4. Verify System Tenant is ID=1
just sql "SELECT id, name FROM tenants WHERE name = 'System Tenant'" prod
```

## 📚 References

- **Implementation**: `scripts/helpers/db_manager.py`
- **Wipe Script**: `scripts/database/wipe_all_simple.sql`
- **Justfile Commands**: `justfile` (lines 104-127)
- **Database Configuration**: `docs/database/configuration.md`

## ⚡ Quick Reference

```bash
# Safe operations
just db verify [env]                    # Check database state
just db init [env]                      # Add foundation data
just db seed [env]                      # Add demo data

# Moderate danger (with protection)
just db clean-all-non-system-tenants [env]  # Remove ALL non-system tenants

# Extreme danger (nuclear protection)
just db wipe-all [env]                  # DELETE ALL + reset sequences
just db reset-physical                  # LOCAL ONLY - complete destruction

# Always backup first for destructive operations
just db backup [env] --name="pre-operation-backup"
```

---

**⚠️ REMEMBER**: When in doubt, backup first. When still in doubt, ask for help. Data loss in production is a career-limiting event - these protections exist for a reason.
