# Backend Database Design

## Purpose
Comprehensive database design documentation for the Spacewalker backend system, including SQLAlchemy ORM models, schema architecture, migration strategies, and multi-tenant data isolation patterns. Essential reference for backend developers working on data models, database schema changes, and data persistence layers.

## When to Use This
- Designing new database models and relationships
- Understanding existing database schema and constraints
- Planning database migrations and schema changes
- Implementing multi-tenant data isolation patterns
- Troubleshooting database-related backend issues
- Keywords: SQLAlchemy models, database schema, Alembic migrations, PostgreSQL, multi-tenancy

**Version:** 2.3 (Reorganized from architecture documentation)
**Date:** 2025-06-29
**Status:** Current - Production Database Architecture

---

## 🏗️ Database Architecture Overview

The database design for Spacewalker prioritizes a **model-first approach** where SQLAlchemy ORM models serve as the single source of truth for the database schema. This ensures consistency between application code and database structure while enabling automated schema management through migrations.

### Core Architecture Principles
- **Model-First Design** - SQLAlchemy ORM models define the canonical database schema
- **Migration-Driven Changes** - All schema modifications managed through Alembic migrations
- **Multi-Tenant Isolation** - Row-Level Security ensures complete data separation between tenants
- **Referential Integrity** - Foreign key constraints maintain data consistency across all relationships

---

## 📊 Entity-Relationship Diagram (ERD)

This diagram illustrates the high-level relationships between the core entities in the database, showing the complete data model architecture.

```mermaid
erDiagram
    TENANT ||--o{ USER : "has"
    TENANT ||--o{ BUILDING : "owns"
    TENANT ||--o{ ATTRIBUTE_DEFINITION : "defines"
    USER ||--o{ SURVEY : "conducts"
    BUILDING ||--|{ FLOOR : "contains"
    FLOOR ||--|{ ROOM : "contains"
    ROOM ||--o{ SURVEY : "is subject of"
    ROOM ||--o{ ROOM_ATTRIBUTE : "has"
    SURVEY ||--o{ SURVEY_IMAGE : "has"
    ATTRIBUTE_DEFINITION ||--o{ ROOM_ATTRIBUTE : "is instance of"
```

### Database Relationship Patterns
- **Multi-Tenant Hierarchy** - All entities linked to tenant for data isolation
- **Facility Structure** - Buildings → Floors → Rooms hierarchical organization
- **Survey Data** - Surveys linked to specific rooms with associated images and attributes
- **Dynamic Attributes** - Flexible attribute system supporting custom room properties

---

## 🗄️ Core Models & Schema

Below are the primary SQLAlchemy models that define our database schema. For the complete, up-to-date implementation, please refer to the source code linked in each section.

### Multi-Tenancy & User Models

| Model        | Source Code                                                                    | Description                                                                 |
| ------------ | ------------------------------------------------------------------------------ | --------------------------------------------------------------------------- |
| **Tenant**   | [`database.py`](../../apps/backend/src/spacecargo/models/database.py)          | Represents a distinct organization (e.g., a university) using the system.   |
| **User**     | [`database.py`](../../apps/backend/src/spacecargo/models/database.py)          | Represents an individual user, linked to a tenant and assigned a role.      |

#### Multi-Tenancy Implementation
```python
# Example Tenant Model Structure
class Tenant(Base):
    __tablename__ = "tenants"

    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    users = relationship("User", back_populates="tenant")
    buildings = relationship("Building", back_populates="tenant")
```

### Facility Hierarchy Models

| Model      | Source Code                                                                    | Description                                                                 |
| ---------- | ------------------------------------------------------------------------------ | --------------------------------------------------------------------------- |
| **Building** | [`database.py`](../../apps/backend/src/spacecargo/models/database.py)        | Represents a physical building within a tenant's organization.              |
| **Floor**    | [`database.py`](../../apps/backend/src/spacecargo/models/database.py)        | Represents a floor within a building.                                       |
| **Room**     | [`database.py`](../../apps/backend/src/spacecargo/models/database.py)        | Represents an individual room or space within a floor.                      |

#### Hierarchical Relationships
```python
# Example Building → Floor → Room Hierarchy
class Building(Base):
    __tablename__ = "buildings"

    id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.id"), nullable=False)
    name = Column(String, nullable=False)

    # Relationships
    tenant = relationship("Tenant", back_populates="buildings")
    floors = relationship("Floor", back_populates="building", cascade="all, delete-orphan")

class Floor(Base):
    __tablename__ = "floors"

    id = Column(String, primary_key=True)
    building_id = Column(String, ForeignKey("buildings.id"), nullable=False)
    floor_number = Column(Integer, nullable=False)

    # Relationships
    building = relationship("Building", back_populates="floors")
    rooms = relationship("Room", back_populates="floor", cascade="all, delete-orphan")
```

### Survey & Data Collection Models

| Model          | Source Code                                                                  | Description                                                                 |
| -------------- | ---------------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| **Survey**     | [`database.py`](../../apps/backend/src/spacecargo/models/database.py)    | Represents a single survey event for a room, including status and metadata. |
| **SurveyImage**| [`database.py`](../../apps/backend/src/spacecargo/models/database.py)| Represents an image associated with a survey.                               |

#### Survey Data Architecture
```python
# Example Survey Model with Image Relationships
class Survey(Base):
    __tablename__ = "surveys"

    id = Column(String, primary_key=True)
    room_id = Column(String, ForeignKey("rooms.id"), nullable=False)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    status = Column(Enum(SurveyStatus), default=SurveyStatus.DRAFT)
    ai_analysis = Column(JSON)  # Gemini API results
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    room = relationship("Room", back_populates="surveys")
    user = relationship("User", back_populates="surveys")
    images = relationship("SurveyImage", back_populates="survey", cascade="all, delete-orphan")
```

### Attribute & FICM Models

| Model                | Source Code                                                                            | Description                                                               |
| -------------------- | -------------------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| **AttributeDefinition**| [`database.py`](../../apps/backend/src/spacecargo/models/database.py) | Defines the schema for a custom attribute that can be applied to a room.  |
| **RoomAttribute**    | [`database.py`](../../apps/backend/src/spacecargo/models/database.py)     | An instance of an attribute with a specific value for a specific room.    |
| **FICM**             | [`database.py`](../../apps/backend/src/spacecargo/models/database.py)                 | Models for the FICM standard, loaded from seed data.                      |

#### Dynamic Attribute System
```python
# Flexible Attribute Architecture
class AttributeDefinition(Base):
    __tablename__ = "attribute_definitions"

    id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.id"), nullable=False)
    name = Column(String, nullable=False)
    data_type = Column(Enum(AttributeDataType), nullable=False)
    validation_rules = Column(JSON)

    # Relationships
    tenant = relationship("Tenant", back_populates="attribute_definitions")
    room_attributes = relationship("RoomAttribute", back_populates="definition")

class RoomAttribute(Base):
    __tablename__ = "room_attributes"

    id = Column(String, primary_key=True)
    room_id = Column(String, ForeignKey("rooms.id"), nullable=False)
    definition_id = Column(String, ForeignKey("attribute_definitions.id"), nullable=False)
    value = Column(JSON)  # Flexible value storage

    # Relationships
    room = relationship("Room", back_populates="attributes")
    definition = relationship("AttributeDefinition", back_populates="room_attributes")
```

---

## 🔄 Migration Strategy

All changes to the database schema are managed through **Alembic migrations**, ensuring consistent and versioned database evolution across all environments.

### Migration Workflow
1. **Model Modification** - Edit SQLAlchemy models in `apps/backend/src/spacecargo/models/`
2. **Migration Generation** - Run `just backend-alembic-revision` to auto-generate migration script
3. **Migration Review** - Examine generated script in `apps/backend/migrations/versions/`
4. **Local Application** - Apply migration locally using `just backend-alembic-upgrade`
5. **Production Deployment** - Migrations applied automatically during container startup

### Migration Best Practices
- **Review Generated Scripts** - Always examine auto-generated migrations before applying
- **Data Migration Planning** - Include data transformation logic for schema changes affecting existing data
- **Rollback Strategy** - Ensure migrations can be safely rolled back if needed
- **Testing** - Test migrations on copies of production data before deployment

### Migration Commands
```bash
# Generate new migration from model changes
just backend-alembic-revision --message "Description of changes"

# Apply pending migrations
just backend-alembic-upgrade

# Check current migration status
just backend-alembic-current

# Rollback to previous migration (if needed)
just backend-alembic-downgrade -1
```

---

## 🔐 Multi-Tenant Data Isolation

Multi-tenancy is enforced at the database level using PostgreSQL's **Row-Level Security (RLS)**, providing robust data isolation that operates independently of application code.

### Row-Level Security Implementation

#### Database Session Setup
```python
# Middleware sets tenant context for each request
async def set_tenant_context(db: AsyncSession, tenant_id: str):
    await db.execute(text("SET app.current_tenant_id = :tenant_id"), {"tenant_id": tenant_id})
```

#### RLS Policy Examples
```sql
-- Example RLS policy for surveys table
CREATE POLICY survey_tenant_isolation ON surveys
    FOR ALL TO application_role
    USING (tenant_id = current_setting('app.current_tenant_id'));

-- Example RLS policy for buildings table
CREATE POLICY building_tenant_isolation ON buildings
    FOR ALL TO application_role
    USING (tenant_id = current_setting('app.current_tenant_id'));
```

### Multi-Tenant Security Benefits
- **Database-Level Enforcement** - Security guaranteed by PostgreSQL, not just application logic
- **Automatic Query Filtering** - All queries automatically filtered by tenant without code changes
- **Zero-Trust Architecture** - Even application bugs cannot breach tenant boundaries
- **Performance Optimized** - Database indexes optimized for tenant-based access patterns

### Tenant Isolation Architecture
```
JWT Token (tenant_id) → Backend Middleware → Database Session Context → RLS Policies → Filtered Data
        ↓                       ↓                       ↓                     ↓             ↓
User Authentication → Tenant Extraction → Session Variable → Policy Application → Tenant Data Only
```

---

## 💾 Backup & Restore Strategy

### Automated Backup Strategy
- **Frequency** - Automated daily backups of production database
- **Storage** - Secure, geographically separate backup storage location
- **Retention** - Configurable retention policies for backup lifecycle management
- **Encryption** - All backups encrypted at rest and in transit

### Backup Implementation
```bash
# Database backup commands (production environment)
just aws_db_backup --environment production
just aws_db_backup_status --environment production

# Restore procedures (documented in operations guide)
just aws_db_restore --backup-id backup_20250629 --environment staging
```

### Disaster Recovery
- **Recovery Time Objective (RTO)** - Target restoration time for critical operations
- **Recovery Point Objective (RPO)** - Maximum acceptable data loss window
- **Testing Schedule** - Regular backup restoration testing to verify integrity
- **Documentation** - Detailed recovery procedures in operations documentation

---

## 🔧 Database Development Patterns

### Model Development Guidelines
- **Single Responsibility** - Each model represents one clear business entity
- **Consistent Naming** - Follow established naming conventions for tables and columns
- **Explicit Relationships** - Define all foreign key relationships explicitly
- **Validation** - Include appropriate constraints and validation at the database level

### Performance Considerations
- **Indexing Strategy** - Strategic indexes for common query patterns
- **Query Optimization** - N+1 query prevention through proper relationship loading
- **Connection Pooling** - Optimized connection pool configuration for concurrent access
- **Bulk Operations** - Efficient bulk insert/update patterns for large datasets

### Development Commands
```bash
# Model development workflow
just backend-shell  # Access backend development shell
just backend-test-db  # Run database-specific tests
just backend-db-reset  # Reset local database (development only)
just backend-db-seed  # Load seed data for development
```

---

## 📋 Related Database Documentation

### Implementation Details
> 🚀 **API Integration**: See [Backend API Components](./api-components.md) for SQLAlchemy integration patterns and database service implementations
> 🚀 **Migration Guide**: See [Database Migration Guide](../backend/database-migrations.md) for detailed migration procedures and best practices

### Development Resources
- **[Backend Development Setup](../backend/development/README.md)** - Development environment configuration for database work
- **[Database Testing Guide](../workflows/testing-guide.md)** - Testing strategies for database models and migrations
- **[Performance Optimization](./development/README.md)** - Database optimization patterns and monitoring strategies

### System Architecture Context
- **[Backend Container Architecture](./architecture/backend-container-architecture.md)** - Complete backend architecture including database integration
- **[Data Flow Patterns](../architecture/data-flow-patterns.md)** - Cross-system data flow including database interactions

---

**Status**: ✅ **PRODUCTION DATABASE ARCHITECTURE**
**Last Updated**: 2025-06-29
**Scope**: SQLAlchemy Models, Database Schema, Migrations, Multi-Tenant Isolation
**Technology Stack**: PostgreSQL, SQLAlchemy, Alembic, Row-Level Security

---

*This database design documentation provides comprehensive guidance for backend developers working with the Spacewalker data layer, ensuring consistent patterns and robust multi-tenant architecture across all database operations.*
