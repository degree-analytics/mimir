# Backend Authentication API

## Purpose
Comprehensive API documentation for authentication endpoints, JWT management, and multi-tenant authentication patterns in the Spacewalker backend API.

## When to Use This
- Implementing authentication in client applications
- Understanding JWT token management and validation
- Integrating with multi-tenant authentication flows
- Debugging authentication issues
- Keywords: authentication API, JWT tokens, multi-tenant auth, user registration, login endpoints

**Version:** 1.0
**Date:** 2025-07-09
**Status:** Current

## Key Concepts
- **JWT Authentication**: Stateless authentication using JSON Web Tokens with 24-hour expiration
- **Multi-Tenant Authentication**: User authentication with automatic tenant assignment and context
- **Role-Based Access Control**: Hierarchical permissions with admin and super user capabilities
- **Row Level Security**: Database-level tenant isolation for secure multi-tenancy

## Authentication Architecture Overview

```mermaid
graph TB
    Client[Client Application] --> Middleware[Tenant Middleware]
    Middleware --> JWT[JWT Validation]
    JWT --> Context[Tenant Context]
    Context --> RLS[Row Level Security]
    RLS --> Database[(Database)]

    Client --> Register[POST /register]
    Client --> Login[POST /login]
    Client --> Me[GET /me]
    Client --> Select[POST /select-tenant/{id}]

    Register --> UserCreation[User Creation]
    Login --> TokenGeneration[JWT Token Generation]
    Me --> UserInfo[Current User Info]
    Select --> TenantSwitch[Tenant Context Switch]

    classDef endpoint fill:#E3F2FD,stroke:#1976D2,color:#000000
    classDef security fill:#F3E5F5,stroke:#7B1FA2,color:#000000
    classDef database fill:#E8F5E8,stroke:#388E3C,color:#000000

    class Register,Login,Me,Select endpoint
    class JWT,Context,RLS security
    class Database database
```

## API Endpoints

### POST /register
Register a new user with automatic tenant assignment.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "secure_password123",
  "name": "John Doe",
  "tenant_id": 1  // Optional - will auto-assign if not provided
}
```

**Response (201 Created):**
```json
{
  "id": "user@example.com",
  "email": "user@example.com",
  "name": "John Doe",
  "tenant_id": 1,
  "is_admin": false,
  "is_super_user": false,
  "created_at": "2025-07-09T17:00:00Z"
}
```

**Error Responses:**
- `400 Bad Request`: Email already registered, invalid tenant, or validation errors
- `422 Unprocessable Entity`: Invalid request format

**Example Usage:**
```typescript
// TypeScript/JavaScript example
const response = await fetch('/register', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    email: 'john@university.edu',
    password: 'SecurePass123!',
    name: 'John Doe'
  })
});

const user = await response.json();
console.log('User created:', user);
```

```python
# Python example
import requests

response = requests.post('/register', json={
    'email': 'john@university.edu',
    'password': 'SecurePass123!',
    'name': 'John Doe'
})

user = response.json()
print(f"User created: {user}")
```

**Tenant Assignment Logic:**
1. If `tenant_id` provided, validate tenant exists and is active
2. If no `tenant_id`, check for domain-based assignment via `TenantDomain` table
3. Fallback to default tenant (ID: 1) if available
4. Error if no valid tenant assignment possible

### POST /login
Authenticate user and return JWT access token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "secure_password123"
}
```

**Response (200 OK):**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "bearer"
}
```

**Error Responses:**
- `401 Unauthorized`: Invalid credentials or inactive user
- `422 Unprocessable Entity`: Invalid request format

**JWT Token Claims:**
```json
{
  "sub": "user@example.com",
  "user_id": "user@example.com",
  "tenant_id": 1,
  "is_admin": false,
  "is_super_user": false,
  "is_owner": true,
  "exp": 1625875200
}
```

**Example Usage:**
```typescript
// Login and store token
const response = await fetch('/login', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    email: 'john@university.edu',
    password: 'SecurePass123!'
  })
});

const { access_token } = await response.json();
localStorage.setItem('auth_token', access_token);

// Use token in subsequent requests
const protectedResponse = await fetch('/protected-endpoint', {
  headers: {
    'Authorization': `Bearer ${access_token}`
  }
});
```

```python
# Python example with session management
import requests

# Login
login_response = requests.post('/login', json={
    'email': 'john@university.edu',
    'password': 'SecurePass123!'
})

token = login_response.json()['access_token']

# Use token for authenticated requests
headers = {'Authorization': f'Bearer {token}'}
protected_response = requests.get('/protected-endpoint', headers=headers)
```

### GET /me
Get current authenticated user information.

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Response (200 OK):**
```json
{
  "id": "user@example.com",
  "email": "user@example.com",
  "name": "John Doe",
  "tenant_id": 1,
  "is_admin": false,
  "is_super_user": false,
  "created_at": "2025-07-09T17:00:00Z"
}
```

**Error Responses:**
- `401 Unauthorized`: Invalid or expired token
- `404 Not Found`: User not found

**Example Usage:**
```typescript
// Get current user info
const response = await fetch('/me', {
  headers: {
    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
  }
});

const user = await response.json();
console.log('Current user:', user);
```

### POST /select-tenant/{tenant_id}
Select a tenant for the current session (super users only).

**Headers:**
```
Authorization: Bearer <jwt_token>
```

**Path Parameters:**
- `tenant_id` (integer): The tenant ID to select

**Response (200 OK):**
```json
{
  "message": "Tenant selected successfully",
  "selected_tenant_id": 2,
  "tenant_name": "University of Example"
}
```

**Error Responses:**
- `403 Forbidden`: Only super users can select tenants
- `404 Not Found`: Tenant not found
- `401 Unauthorized`: Invalid or expired token

**Example Usage:**
```typescript
// Super user tenant selection
const response = await fetch('/select-tenant/2', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
  }
});

const result = await response.json();
console.log('Tenant selected:', result.tenant_name);

// Use X-Selected-Tenant-Id header for subsequent requests
const tenantSpecificResponse = await fetch('/surveys', {
  headers: {
    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
    'X-Selected-Tenant-Id': '2'
  }
});
```

## JWT Configuration

### JWT Settings
- **Algorithm**: HS256 (configurable via `JWT_ALGORITHM`)
- **Expiration**: 24 hours (86400 seconds, configurable via `JWT_EXPIRATION_DELTA`)
- **Secret**: Loaded from AWS Secrets Manager or environment variables
- **Issuer**: Spacewalker Backend API

### Secret Management
```python
# Configuration priority:
# 1. AWS Secrets Manager (secret: dev/spacewalker/jwt-config)
# 2. Environment variables (JWT_SECRET_KEY, JWT_ALGORITHM, JWT_EXPIRATION_DELTA)

# Security requirements:
# - JWT_SECRET_KEY must be at least 32 characters
# - No weak/common secrets allowed
# - Expiration between 1 hour and 7 days
```

### Token Validation
```python
# Automatic token validation in middleware
def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    """Verify JWT token and return payload"""
    token = credentials.credentials
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.DecodeError:
        raise HTTPException(status_code=401, detail="Token decode error")
```

## Multi-Tenant Authentication

### Tenant Context Management
All authenticated requests automatically establish tenant context:

```python
# Tenant context is set via middleware
from spacecargo.api.middleware.tenant import TenantMiddleware

# Context is available in request handlers
@router.get("/protected")
def protected_endpoint(
    current_user: User = Depends(get_current_user),
    tenant_id: int = Depends(get_current_tenant_id)
):
    # tenant_id is automatically resolved from JWT token
    return {"user": current_user.email, "tenant": tenant_id}
```

### Super User Tenant Selection
Super users can override tenant context:

```python
# Super users can select tenant via header
@router.get("/admin-endpoint")
def admin_endpoint(
    current_user: User = Depends(require_super_user),
    tenant_id: int = Depends(get_current_tenant_id),
    x_selected_tenant_id: Optional[str] = Header(None)
):
    # tenant_id will be from X-Selected-Tenant-Id if provided
    return {"acting_as_tenant": tenant_id}
```

### Row Level Security Integration
Database queries are automatically scoped to tenant context:

```sql
-- RLS policies automatically applied
SELECT * FROM surveys; -- Only returns surveys for current tenant context

-- Set tenant context for database operations
SET app.current_tenant_id = 123;
```

## Authentication Middleware

### Tenant Middleware
Automatically extracts tenant context from JWT tokens:

```python
class TenantMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Extract tenant ID from JWT token
        tenant_id = None

        # Try Authorization header first
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ")[1]
            # Decode and extract tenant_id

        # Fallback to query parameter (for image proxy)
        if not token:
            token = request.query_params.get("token")

        # Set tenant context for request
        set_current_tenant_id(tenant_id)

        return await call_next(request)
```

### Authentication Dependencies
Common authentication patterns:

```python
# Basic authentication
def get_current_user(
    token_data: dict = Depends(verify_token),
    db: Session = Depends(get_db)
) -> User:
    """Get current authenticated user"""
    user_email = token_data.get("sub")
    user = db.query(User).filter(User.email == user_email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

# Admin required
def require_admin(current_user: User = Depends(get_current_user)) -> User:
    """Require admin privileges"""
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

# Super user required
def require_super_user(current_user: User = Depends(get_current_user)) -> User:
    """Require super user privileges"""
    if not current_user.is_super_user:
        raise HTTPException(status_code=403, detail="Super user access required")
    return current_user
```

## Role-Based Access Control (RBAC)

### User Roles
- **Regular User**: Basic access to own resources
- **Admin**: Manage users and tenant resources
- **Super User**: Cross-tenant access and system administration

### Tenant Roles
```python
class TenantRole(enum.Enum):
    OWNER = "owner"      # Can delete tenant, transfer ownership
    ADMIN = "admin"      # Can manage users, settings, billing
    MANAGER = "manager"  # Can manage surveys, view all data
    MEMBER = "member"    # Can create/edit own surveys
    VIEWER = "viewer"    # Read-only access
```

### Permission Checking
```python
# Check user permissions with owner-based model
def check_tenant_access_permission(
    tenant_id: int,
    token_data: dict = Depends(verify_token),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> User:
    """Verify user can access/modify the specified tenant (owner of that tenant, admin, or superuser)"""
    # Superuser can access any tenant
    if current_user.is_super_user:
        return current_user

    # Admin can access any tenant
    if current_user.is_admin:
        return current_user

    # Check if user is the owner of the specific tenant
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tenant not found"
        )

    if tenant.owner_id == current_user.id:
        return current_user

    # No sufficient permissions for this tenant
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="You can only access tenants you own"
    )

# Simplified owner-based permission checking
def require_owner_or_admin(
    token_data: dict = Depends(verify_token),
    current_user: User = Depends(get_current_user)
) -> User:
    """Verify current user is either the tenant owner, admin, or superuser"""
    # Check permissions in order of precedence
    if current_user.is_super_user:
        return current_user

    if current_user.is_admin:
        return current_user

    # Check owner status from JWT token
    is_owner = token_data.get("is_owner", False)
    if is_owner:
        return current_user

    # No sufficient permissions
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Tenant owner, admin, or superuser access required"
    )
```

## Security Considerations

### Password Security
- **Hashing**: bcrypt with automatic salt generation
- **Validation**: Minimum password requirements enforced
- **Storage**: Only hashed passwords stored, never plain text

```python
def hash_password(password: str) -> str:
    """Hash password using bcrypt with salt"""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode("utf-8"), salt).decode("utf-8")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password against hash"""
    return bcrypt.checkpw(
        plain_password.encode("utf-8"),
        hashed_password.encode("utf-8")
    )
```

### Token Security
- **Expiration**: 24-hour token lifetime
- **Secret Management**: AWS Secrets Manager integration
- **Validation**: Comprehensive error handling for all JWT scenarios

### Tenant Isolation
- **Database Level**: Row Level Security policies
- **Application Level**: Tenant context validation
- **API Level**: Automatic tenant scoping

## Testing Authentication

### Unit Tests
```python
def test_user_registration():
    """Test user registration with tenant assignment"""
    response = client.post("/register", json={
        "email": "test@example.com",
        "password": "SecurePass123!",
        "name": "Test User"
    })

    assert response.status_code == 201
    user = response.json()
    assert user["email"] == "test@example.com"
    assert user["tenant_id"] is not None

def test_user_login():
    """Test user login and token generation"""
    response = client.post("/login", json={
        "email": "test@example.com",
        "password": "SecurePass123!"
    })

    assert response.status_code == 200
    token_data = response.json()
    assert "access_token" in token_data
    assert token_data["token_type"] == "bearer"
```

### Integration Tests
```python
def test_authentication_flow():
    """Test complete authentication flow"""
    # Register user
    register_response = client.post("/register", json={
        "email": "integration@example.com",
        "password": "SecurePass123!",
        "name": "Integration User"
    })
    assert register_response.status_code == 201

    # Login
    login_response = client.post("/login", json={
        "email": "integration@example.com",
        "password": "SecurePass123!"
    })
    assert login_response.status_code == 200
    token = login_response.json()["access_token"]

    # Access protected endpoint
    protected_response = client.get("/me", headers={
        "Authorization": f"Bearer {token}"
    })
    assert protected_response.status_code == 200
    user = protected_response.json()
    assert user["email"] == "integration@example.com"
```

## Troubleshooting

### Common Issues

**401 Unauthorized Errors:**
```bash
# Check token expiration
import jwt
payload = jwt.decode(token, options={"verify_signature": False})
print(f"Token expires at: {payload['exp']}")

# Verify token format
curl -H "Authorization: Bearer your_token_here" /me
```

**403 Forbidden Errors:**
```bash
# Check user permissions
GET /me
# Verify is_admin or is_super_user flags

# Check tenant membership
GET /tenants/current
```

**Token Validation Errors:**
```python
# JWT configuration issues
os.environ["JWT_SECRET_KEY"]  # Must be at least 32 characters
os.environ["JWT_ALGORITHM"]   # Usually HS256
os.environ["JWT_EXPIRATION_DELTA"]  # Usually 86400 (24 hours)
```

### Debug Commands
```bash
# Test authentication endpoints
curl -X POST /register -H "Content-Type: application/json" -d '{
  "email": "debug@example.com",
  "password": "DebugPass123!",
  "name": "Debug User"
}'

curl -X POST /login -H "Content-Type: application/json" -d '{
  "email": "debug@example.com",
  "password": "DebugPass123!"
}'

# Test token validation
curl -H "Authorization: Bearer YOUR_TOKEN" /me
```

## Related Documentation
- [Admin Authentication Workflows](../admin/authentication-workflows.md) - Frontend authentication integration
- [Super User Security](./super-user-security.md) - Elevated permission management
- [Security Architecture](../architecture/security-architecture.md) - Overall security design
- [API Development Guide](./api-development.md) - General API patterns and best practices

---
**Status**: ✅ Current
**Last Updated**: 2025-07-09
**Technology Stack**: FastAPI, JWT, SQLAlchemy, PostgreSQL, bcrypt
