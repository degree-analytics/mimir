# BACnet Testing Guide

## Purpose
Comprehensive testing procedures for the BACnet connector using justfile commands. Essential workflow for development teams requiring unit tests, integration tests, system verification, and zone filtering testing across different testing scenarios and development workflows.

## When to Use This
- Testing BACnet connector changes during development
- Running comprehensive test suites before committing code
- Validating BACnet integration functionality with unit, integration, and system tests
- Verifying zone filtering features in both enabled and disabled modes
- Setting up CI/CD testing workflows for BACnet components
- Keywords: BACnet testing, integration tests, zone filtering tests, development workflow, CI/CD testing

**Version:** 2.0 (Migrated from Cursor rules)
**Date:** 2025-06-29
**Status:** Current - Production Development Workflow

---

## 🎯 Test Strategy Overview

### Two-Tier Testing Architecture

**CI/CD (GitHub Actions)** - Fast & Reliable:
- ✅ **Unit Tests** - Fast, no Docker required (~20 seconds)
- ✅ **Linting** - Code quality checks (~15 seconds)
- ⚡ **Total: ~35 seconds** - Much faster pipeline

**Local Development** - Comprehensive:
- ✅ **Unit Tests** - Fast component testing
- 🏠 **Integration Tests** - Docker required, local-only
- 🏠 **System Tests** - Full end-to-end verification

> **⚡ CRITICAL UPDATE**: Integration tests are **LOCAL-ONLY** and have been **removed from CI/CD**. This eliminates Docker infrastructure complexity and makes CI/CD faster and more reliable. **Developers must run integration tests locally before pushing PRs.**

### Zone Filtering Testing Coverage

This guide includes comprehensive testing for both filtering modes:
- **Baseline Mode**: Zone filtering disabled (backward compatibility verification)
- **Enhanced Mode**: Zone filtering enabled (new functionality verification)
- Tests cover configuration validation, hot reload, performance impact, and error handling

---

## 🚀 Quick Development Testing

Use during active development for fast feedback:

```bash
# Run unit tests only (no Docker required)
just test unit all

# Run unit tests with coverage reporting
just test unit all-coverage

# Development cycle: unit tests + linting + quick verification
just dev-cycle
```

**Expected Outcome:** Fast feedback loop for code changes without Docker overhead.

**Use Cases:**
- Active feature development
- Fixing unit test failures
- Quick validation of changes before integration testing

---

## 🔧 Standard Integration Testing

Use before committing changes or for comprehensive verification:

### Step 1: Start Test Infrastructure
```bash
# Start Docker services for testing
just test_infra-up
```

### Step 2: Run Integration Tests - FAIL FAST APPROACH
```bash
# Run integration tests with infrastructure
just test integration all

# ❌ CRITICAL: If ANY integration tests fail, STOP IMMEDIATELY
# DO NOT continue with other tests until ALL integration failures are fixed
# DO NOT hide or gloss over failures in progress reports

# Alternative: Run all tests with infrastructure
just test_with-infra
```

### Integration Test Failure Protocol (MANDATORY)
```bash
# If integration tests fail:

# Step 1: Run specific failing test with verbose output for debugging
just test integration backend -- tests/integration/path/to/failing_test.py::FailingTest::test_method --verbose

# Step 2: Catalog the exact error message and root cause
# Step 3: Fix the issue systematically (don't skip or defer)
# Step 4: Re-run the specific test to verify fix
# Step 5: Only after ALL integration tests achieve 100% pass rate, continue

# NEVER PROCEED PAST INTEGRATION TEST FAILURES WITHOUT FIXING THEM
```

### Step 3: Verify Results (ONLY after 100% pass rate)
```bash
# Check test infrastructure status
just test_infra-status

# View logs if needed for verification
just docker-logs-snapshot occupancy-bacnet-connector
```

### Step 4: Cleanup
```bash
# Stop test infrastructure when done
just test_infra-down
```

---

## 🏗️ Comprehensive System Testing

Use for final verification, CI/CD preparation, or troubleshooting:

### Step 1: Full Environment Setup
```bash
# Stop any existing services
just docker-stop

# Clean and rebuild everything from scratch
just docker-clean all
just docker-build --no-cache
just docker-start
```

### Step 2: Pre-flight Environment Verification
```bash
# Verify container status
just docker-status

# Verify API connectivity
just health-check

# Verify BACnet setup and networking
just diagnostics_bacnet
```

### Step 3: Unit Test Execution
```bash
# Run comprehensive unit tests with coverage
just test unit all-coverage
```

### Step 4: Integration Testing - FAIL FAST MANDATORY
```bash
# Run integration tests against live environment
just test integration all

# ❌ CRITICAL: STOP HERE if any integration tests fail
# Fix ALL failures before proceeding to verification steps below

# ONLY proceed after 100% integration test pass rate:
# Verify BACnet device discovery
just diagnostics_bacnet

# Test BACnet object reading
./scripts/diagnostics/read-objects.sh 337733

# Test device information retrieval
./scripts/diagnostics/device-info.sh 337733
```

### Step 5: API Functionality Testing
```bash
# Test API endpoints
just health-check

# Test API data retrieval (if available)
./scripts/diagnostics/api-debug-enhanced.sh

# Verify polling is working correctly
just docker-logs-snapshot occupancy-bacnet-connector | grep -i "Successfully fetched" | tail -5
```

### Step 6: Error and Log Validation
```bash
# Check for any errors in logs since system start
./scripts/diagnostics/verify-logs.sh --since 30m --all-services

# Verify no critical errors in connector logs
just docker-logs occupancy-bacnet-connector | grep -i error
```

### Step 7: Performance Testing (Optional)
```bash
# Long-running test to verify stability
echo "Starting 5-minute stability test..."
for i in {1..10}; do
    echo "Test iteration $i/10"
    just diagnostics_bacnet > /dev/null
    ./scripts/diagnostics/read-objects.sh 337733 > /dev/null
    sleep 30
done
echo "Stability test completed!"
```

---

## 🎯 Targeted Testing Scenarios

### BACnet Communication Testing
```bash
# Test BACnet stack initialization
just docker-logs-snapshot occupancy-bacnet-connector | grep -i "BACnet application.*is running"

# Test device discovery
just diagnostics_bacnet

# Test object enumeration
./scripts/diagnostics/read-objects.sh 337733

# Test specific object reading
./scripts/diagnostics/device-info.sh 337733

# Test network connectivity
just diagnostics_bacnet
```

### API Testing
```bash
# Basic API health verification
just health-check

# Enhanced API debugging with detailed output
./scripts/diagnostics/api-debug-enhanced.sh

# Test API endpoints manually
just docker-exec occupancy-bacnet-connector "curl -s localhost:8000/health"
```

### Configuration Testing
```bash
# Test with different configurations
just docker-stop
# Modify configuration files as needed
just docker-start

# Verify configuration loading
just docker-logs-snapshot occupancy-bacnet-connector | grep -i "configuration"
```

### Error Simulation Testing
```bash
# Test error handling by simulating network issues
just docker-exec testing-bacnet-client "ip link set eth0 down"
sleep 10
just diagnostics_bacnet
just docker-exec testing-bacnet-client "ip link set eth0 up"
sleep 5
just diagnostics_bacnet
```

---

## 🏢 Comprehensive Zone Filtering Test Suite

### Scenario 1: Zone Filtering Disabled (Baseline)
**Purpose:** Verify backward compatibility and full zone exposure

```bash
# Step 1: Ensure filtering is disabled
just docker-exec occupancy-bacnet-connector "echo 'ZONE_FILTER_ENABLED=false' >> .env"
just docker-restart occupancy-bacnet-connector

# Step 2: Verify all zones are exposed
TOTAL_ZONES=$(just docker-exec occupancy-bacnet-connector bacnet-filter list-zones --count-only)
BACNET_OBJECTS=$(./scripts/diagnostics/count-object-types.sh | grep "Analog Value" | awk '{print $1}')
echo "API Zones: $TOTAL_ZONES, BACnet Objects: $BACNET_OBJECTS"

# Step 3: Verify no filtering status
./scripts/diagnostics/show-filter-status.sh | grep "Status: Disabled"

# Step 4: Basic functionality tests
just diagnostics_bacnet
./scripts/diagnostics/read-objects.sh 337733
./scripts/diagnostics/device-info.sh 337733
```

### Scenario 2: Zone Filtering Enabled (Enhanced)
**Purpose:** Test filtering, custom naming, and aggregation features

```bash
# Step 1: Enable filtering with test configuration
just docker-exec occupancy-bacnet-connector "echo 'ZONE_FILTER_ENABLED=true' > .env"
just docker-exec occupancy-bacnet-connector "echo 'ZONE_FILTER_CONFIG_PATH=/app/config/zone_filter.json' >> .env"

# Step 2: Generate and customize test filter configuration
just docker-exec occupancy-bacnet-connector bacnet-filter generate-config --sample 50 > /tmp/test_filter.json
# Manually create a test filter configuration with 10-20 zones

# Step 3: Validate configuration before applying
just docker-exec occupancy-bacnet-connector bacnet-filter validate --config /app/config/zone_filter.json

# Step 4: Apply configuration and restart
just docker-restart occupancy-bacnet-connector

# Step 5: Verify filtering is active
./scripts/diagnostics/show-filter-status.sh | grep "Status: Active"
FILTERED_OBJECTS=$(./scripts/diagnostics/count-object-types.sh | grep "Analog Value" | awk '{print $1}')
echo "Filtered BACnet Objects: $FILTERED_OBJECTS (should be significantly less than baseline)"

# Step 6: Test hot reload functionality
./scripts/diagnostics/test-zone-filter-reload.sh

# Step 7: Test individual zone behavior
just docker-exec occupancy-bacnet-connector bacnet-filter test-zone --zone-id z_12345 --debug
just docker-exec occupancy-bacnet-connector bacnet-filter test-zone --zone-id z_nonexistent --debug
```

### Scenario 3: Zone Filtering Performance Testing
**Purpose:** Verify filtering performance and overhead

```bash
# Step 1: Measure baseline performance (no filtering)
echo "Testing baseline performance..."
time ./scripts/diagnostics/count-object-types.sh > /dev/null
time ./scripts/diagnostics/list-all-zones.sh > /dev/null

# Step 2: Enable filtering and measure performance
just docker-exec occupancy-bacnet-connector "echo 'ZONE_FILTER_ENABLED=true' > .env"
just docker-restart occupancy-bacnet-connector

echo "Testing filtered performance..."
time ./scripts/diagnostics/count-object-types.sh > /dev/null
time ./scripts/diagnostics/list-all-zones.sh > /dev/null

# Step 3: Measure filtering overhead in logs
just docker-logs-snapshot occupancy-bacnet-connector | grep -i "filtering.*ms" | tail -5
```

### Scenario 4: Zone Filtering Error Handling
**Purpose:** Test error scenarios and graceful degradation

```bash
# Test 1: Invalid JSON configuration
echo '{"invalid": json}' | just docker-exec occupancy-bacnet-connector "tee /app/config/zone_filter.json"
just docker-restart occupancy-bacnet-connector
# Should log error and continue with no filtering

# Test 2: Non-existent zone IDs in filter
echo '{"version": "1.0", "filter_mode": "include", "zones": [{"id": "z_nonexistent"}]}' | \
  just docker-exec occupancy-bacnet-connector "tee /app/config/zone_filter.json"
just docker-restart occupancy-bacnet-connector
# Should log warning but continue

# Test 3: Missing configuration file
just docker-exec occupancy-bacnet-connector "rm -f /app/config/zone_filter.json"
just docker-restart occupancy-bacnet-connector
# Should continue with no filtering

# Test 4: Hot reload with invalid configuration
./scripts/diagnostics/test-zone-filter-reload.sh --test-invalid-config
```

---

## 🔧 Zone Filtering Helper Commands Testing

### Basic Zone Filtering Commands
```bash
# Test zone filtering status and configuration
./scripts/diagnostics/show-filter-status.sh

# Test zone filtering with basic configuration
just docker-exec occupancy-bacnet-connector bacnet-filter generate-config
just docker-exec occupancy-bacnet-connector bacnet-filter validate

# Test individual zone filtering
just docker-exec occupancy-bacnet-connector bacnet-filter test-zone --zone-id z_12345 --debug

# Test zone filtering hot reload functionality
./scripts/diagnostics/test-zone-filter-reload.sh

# Compare object counts with and without filtering
./scripts/diagnostics/count-object-types.sh
```

---

## 🚀 Automated Testing Workflows

### Pre-commit Validation
```bash
# Complete pre-commit validation workflow
just test_with-infra
```

### CI/CD Testing
```bash
# Full CI/CD test suite
just docker-clean all
just docker-build --no-cache
just test_with-infra
./scripts/diagnostics/verify-logs.sh --since 30m --all-services
```

### Development Iteration
```bash
# Fast development cycle
just dev-cycle
```

---

## 📊 Test Data and Expected Results

### Expected BACnet Device Configuration
**Device ID:** `337733`
- This is the simulated BACnet device in the testing environment
- Use this ID for all object reading and device information tests

### Expected Object Types
The simulated device should support:
- Analog Input objects
- Binary Input objects
- Device object
- Trend Log objects (if configured)

### Zone Filtering Test Scenarios
**Two Primary Test Modes:**

1. **Zone Filtering Disabled** (default baseline testing)
   - `ZONE_FILTER_ENABLED=false` or no configuration file
   - All zones exposed (typically 2,894+ in test environment)
   - Tests existing functionality and backward compatibility

2. **Zone Filtering Enabled** (enhanced functionality testing)
   - `ZONE_FILTER_ENABLED=true` with valid configuration file
   - Reduced zone count based on filter configuration
   - Tests filtering, custom naming, and aggregation features

### Expected API Responses
- **Health Check:** Should return HTTP 200 with status information
- **Data Endpoints:** Should return JSON with occupancy data (when available)

### Expected Log Messages
Look for these key log messages indicating proper operation:
- `"BACnet application is running"`
- `"Successfully fetched occupancy data"`
- `"Device 337733 discovered"`
- `"API server started on port 8000"`

**Zone Filtering Specific Messages:**
- `"Zone filtering enabled"` / `"Zone filtering disabled"`
- `"Loaded zone filter configuration"`
- `"Applied filter: included X zones, excluded Y zones"`
- `"Zone filter hot reload completed"`
- `"Filtering processing completed in X ms"`
- `"Configuration file change detected, reloading filter"`

---

## 🚨 Troubleshooting Test Failures

### Unit Test Failures
```bash
# Run tests with verbose output
just test unit all -v

# Run specific test files
just test unit backend -- tests/unit/specific_test.py --verbose

# Run with debugging
just test unit backend -- tests/unit/ --pdb
```

### Integration Test Failures
```bash
# Check Docker service status
just docker-status

# Restart test infrastructure
just test_infra-down
just test_infra-up

# Check for container logs
just docker-logs occupancy-bacnet-connector
just docker-logs testing-bacnet-client
```

### BACnet Communication Failures
```bash
# Verify network setup
just diagnostics_bacnet

# Check for port conflicts
just docker-exec occupancy-bacnet-connector "netstat -ulnp | grep 47808"

# Verify container networking
just docker-exec occupancy-bacnet-connector "ping testing-bacnet-client"
just docker-exec testing-bacnet-client "ping occupancy-bacnet-connector"
```

### API Test Failures
```bash
# Debug API connectivity
./scripts/diagnostics/api-debug-enhanced.sh

# Check API server status
just docker-exec occupancy-bacnet-connector "curl -v localhost:8000/health"

# Verify API server logs
just docker-logs occupancy-bacnet-connector | grep -i api
```

### Zone Filtering Test Failures
```bash
# Check zone filtering configuration and status
./scripts/diagnostics/show-filter-status.sh

# Validate filter configuration syntax
just docker-exec occupancy-bacnet-connector bacnet-filter validate --config /app/config/zone_filter.json

# Check zone filtering logs
just docker-logs occupancy-bacnet-connector | grep -i "filter\|filtering"

# Test specific zone filtering behavior
just docker-exec occupancy-bacnet-connector bacnet-filter test-zone --zone-id z_12345 --debug

# Verify environment variables
just docker-exec occupancy-bacnet-connector env | grep ZONE_FILTER

# Check configuration file permissions and existence
just docker-exec occupancy-bacnet-connector ls -la /app/config/zone_filter.json

# Reset to no filtering for baseline testing
just docker-exec occupancy-bacnet-connector "echo 'ZONE_FILTER_ENABLED=false' > .env"
just docker-restart occupancy-bacnet-connector
```

---

## 🛠️ Test Environment Management

### Starting Fresh Test Environment
```bash
# Complete fresh start
just docker-stop
just docker-clean all
just docker-build --no-cache
just test_infra-up
```

### Preserving Test State
```bash
# Keep containers running between test runs
just test_infra-up
# Run tests...
# Don't run test-infra-down to preserve state
```

### Test Environment Validation
```bash
# Verify test environment is properly configured
just test_infra-status
just diagnostics_bacnet
just health-check
```

---

## 🔄 Integration with Development Workflow

### Daily Development Workflow
1. **Start:** `just dev-cycle` - Fast unit tests and linting
2. **Develop:** Make changes, repeat `just test unit all` as needed
3. **Integrate:** `just test_with-infra` before committing
4. **Commit:** Push changes with confidence

### Task Completion Verification
When completing development tasks:
1. Run appropriate test level based on task complexity
2. Use `just test_with-infra` for tasks affecting integration
3. Use `just dev-cycle` for unit-level changes
4. Document test results in task completion notes

### Legacy Compatibility
All previous `./scripts/docker_bacnet.sh` commands still work as thin wrappers:
- `./scripts/docker_bacnet.sh start` → `just docker-start`
- `./scripts/docker_bacnet.sh stop` → `just docker-stop`
- `./scripts/docker_bacnet.sh logs` → `just docker-logs`

---

## ✅ Test Success Criteria

A successful test run should meet these criteria:

### Core Testing Requirements
1. **Unit Tests:** All tests pass with no failures
2. **Integration Tests:** All tests pass with proper BACnet communication
3. **System Verification:**
   - BACnet device discovery works
   - API endpoints respond correctly
   - No errors in application logs
   - Container networking is functional

### Zone Filtering Verification
4. **Zone Filtering Verification:**
   - Both enabled and disabled filtering modes work correctly
   - Filter configuration validation passes
   - Hot reload functionality works without restart
   - Performance overhead is <100ms for filtering operations
   - Helper commands (generate-config, validate, test-zone) work correctly

### Performance and Stability
5. **Performance:** System remains stable during extended testing with and without filtering

---

## 📋 Related Development Documentation

### Core Development Workflows
- **[BACnet Environment Rebuild](../backend/bacnet-environment-rebuild.md)** - Development environment setup and rebuild procedures
- **[Development Tools](../development/development-tools.md)** - Comprehensive justfile automation and helper scripts
- **[Development Setup](../setup/development-setup.md)** - Initial development environment configuration

### BACnet-Specific Documentation
> 🚀 **Backend Teams**: See [Backend Development](../backend/development/) for BACnet implementation details and server configuration
> 🚀 **Backend Reference**: See [BACnet Terminology](../backend/bacnet-terminology.md) for consistent terminology and implementation standards

### Troubleshooting and Operations
- **[BACnet Timeout Debugging](../gotchas/bacnet-timeout-debugging.md)** - Troubleshooting APDU timeouts and communication failures
- **[Development Environment Issues](../setup/environment-setup.md)** - Common setup and configuration problems

### Testing and Quality Assurance
- **[Testing Guide](../workflows/testing-guide.md)** - Project-wide testing workflows including BACnet integration tests
- **[Git Commit Standards](../workflows/git-commit-standards.md)** - Commit message formatting for test-related changes

---

**Status**: ✅ **PRODUCTION DEVELOPMENT WORKFLOW**
**Last Updated**: 2025-06-29
**Applies To**: All development teams working with BACnet integration
**Integration**: Testing frameworks, justfile automation, CI/CD pipelines, zone filtering functionality

---

*This comprehensive testing guide ensures thorough validation of BACnet connector functionality across all development scenarios. Following these procedures provides confidence in both baseline functionality and enhanced zone filtering features before deployment or production use.*
