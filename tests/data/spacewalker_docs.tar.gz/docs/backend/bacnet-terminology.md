# BACnet Terminology

## Purpose
Defines standard BACnet terminology and project-specific terms for consistent usage across backend development teams. Essential reference for backend developers working on BACnet integration to ensure consistent variable names, function names, comments, and documentation.

## When to Use This
- Writing backend code that interacts with BACnet devices or protocols
- Creating variable names, function names, and code comments for BACnet integration
- Documenting BACnet implementation details in backend systems
- Ensuring consistent terminology across backend development teams
- Understanding BACnet protocol concepts for backend implementation
- Keywords: BACnet protocol, object types, property identifiers, backend integration, IoT terminology

**Version:** 2.0 (Migrated from Cursor rules)
**Date:** 2025-06-29
**Status:** Current - Backend Development Reference

---

## 🔧 Core BACnet Concepts

### Fundamental Protocol Elements
- **Device** - A physical or virtual BACnet device with a unique Device ID on the network
- **Object** - Represents a logical point or entity within a device (e.g., analog input, binary value)
- **Property** - A characteristic or attribute of an object (e.g., present value, status flags)
- **Service** - A BACnet operation or protocol function (e.g., ReadProperty, WriteProperty)
- **APDU** - Application Protocol Data Unit, the standardized format for BACnet messages and communication

### Network and Communication
- **Device ID** - Unique numerical identifier for each BACnet device on the network
- **Object Instance** - Unique numerical identifier for each object within a device
- **Network Layer** - BACnet networking protocol layer handling device-to-device communication
- **Application Layer** - BACnet application protocol layer handling service requests and responses

---

## 📊 Common Object Types

### Analog Objects
- **Analog Input** - Represents analog sensor values (e.g., temperature, humidity, pressure)
- **Analog Output** - Represents analog control outputs (e.g., valve position, damper control)
- **Analog Value** - Represents calculated or stored analog values (e.g., setpoints, computed values)

### Binary Objects
- **Binary Input** - Represents binary sensor states (e.g., switch position, alarm status)
- **Binary Output** - Represents binary control outputs (e.g., fan on/off, lighting control)
- **Binary Value** - Represents calculated or stored binary states (e.g., enable/disable flags)

### Multi-state Objects
- **Multi-state Input** - Represents sensors with multiple discrete states (e.g., mode selection)
- **Multi-state Output** - Represents control outputs with multiple discrete states
- **Multi-state Value** - Represents calculated or stored multi-state values

### Scheduling and Time Objects
- **Calendar** - A list of dates used for scheduling operations
- **Schedule** - A list of times and values for performing specific operations
- **Event Enrollment** - Configuration for event notifications and alarms

---

## 🏷️ Common Property Identifiers

### Value and Status Properties
- **Present_Value** - The current value of an object (primary data property)
- **Status_Flags** - Flags indicating object status (in-alarm, fault, overridden, out-of-service)
- **Out_Of_Service** - Boolean indicating whether the object is currently in service or can be written to by a BACnet client
- **Reliability** - Enumerated value indicating the reliability of the present value

### Descriptive Properties
- **Object_Name** - Textual name identifier for the object
- **Description** - Human-readable textual description of the object
- **Units** - Engineering units of the value (e.g., degrees Celsius, percent, volts)
- **Object_Type** - Enumerated value indicating the type of BACnet object

### Configuration Properties
- **Priority_Array** - Array of prioritized values for write operations
- **Relinquish_Default** - Default value when all priority levels are relinquished
- **COV_Increment** - Minimum change required to trigger Change of Value notifications
- **Event_State** - Current alarm/event state of the object

---

## ⚙️ Common Services

### Read Services
- **ReadProperty** - Read a single property from a single object
- **ReadPropertyMultiple** - Read multiple properties from one or more objects in a single request
- **ReadRange** - Read a range of values from a sequence or list property

### Write Services
- **WriteProperty** - Write a single property to a single object
- **WritePropertyMultiple** - Write multiple properties to one or more objects in a single request

### Discovery Services
- **Who-Is / I-Am** - Device discovery services used to find other BACnet devices on the network
- **DeviceCommunicationControl** - Control communication capabilities of a device
- **ReadBDT** - Read Broadcast Distribution Table for network routing

### Subscription Services
- **SubscribeCOV** - Subscribe to Change of Value notifications for a property
- **ConfirmedCOVNotification** - Confirmed notification of property value changes
- **UnconfirmedCOVNotification** - Unconfirmed notification of property value changes

---

## 🏢 Project-Specific Terms

### Spacewalker System Concepts
- **Zone** - A logical grouping of devices or space within a building relevant to occupancy sensing
- **Occupancy** - The state of a space being occupied or vacant, typically determined by BACnet objects
- **Monitoring** - The systematic process of tracking changes in BACnet object properties, especially `Present_Value` and `Status_Flags`, for occupancy and operational status
- **Connector** - Backend service that interfaces between BACnet devices and the Spacewalker platform

### Backend Implementation Terms
- **BACnet Connector** - Docker containerized service handling BACnet protocol communication
- **Device Registry** - Backend component managing known BACnet devices and their object lists
- **Property Cache** - Backend caching mechanism for frequently accessed BACnet property values
- **Zone Filter** - Backend component for filtering and organizing BACnet data by building zones

### Integration Concepts
- **APDU Timeout** - Network timeout condition when BACnet requests fail to receive responses
- **COV Subscription** - Backend mechanism for receiving automatic property change notifications
- **Discovery Process** - Backend procedure for identifying and cataloging BACnet devices on the network
- **Property Polling** - Backend process for periodically reading BACnet property values

---

## 💻 Backend Development Guidelines

### Consistent Terminology Usage
Use these terms consistently in all backend code (variable names, function names, comments), documentation, and commit messages.

### BACnet Object Naming Conventions
When referring to specific BACnet objects in backend code, use their standard BACnet names:
- `AnalogInputObject`, `AnalogOutputObject`, `AnalogValueObject`
- `BinaryInputObject`, `BinaryOutputObject`, `BinaryValueObject`
- `MultiStateInputObject`, `MultiStateOutputObject`, `MultiStateValueObject`

### BACnet Property Naming Conventions
When referring to specific BACnet properties in backend code, use their standard BACnet names:
- Use camelCase for properties in Python code interacting with BACpypes3: `presentValue`, `statusFlags`, `objectName`
- Use underscore notation for property constants: `Present_Value`, `Status_Flags`, `Object_Name`

### Code Comment Standards
```python
# ✅ GOOD: Reads the Present_Value of an Analog Input object
analog_input_value = read_property(device_id, object_type, object_instance, 'presentValue')

# ❌ BAD: Gets the current temp
temp = get_value(device_id, 1, 2)
```

### Function and Variable Naming
```python
# ✅ GOOD: Clear BACnet terminology
def read_binary_input_present_value(device_id: int, object_instance: int) -> bool:
    """Read Present_Value property from a Binary Input object."""
    pass

# ❌ BAD: Unclear terminology
def get_sensor_data(dev: int, obj: int) -> bool:
    pass
```

### Documentation Standards
Use precise BACnet terminology in all backend documentation:
- "The system monitors the `Present_Value` of `OccupancySensor` objects to determine zone status."
- "BACnet `SubscribeCOV` service enables real-time property change notifications."
- "The connector performs periodic `ReadPropertyMultiple` operations for efficient data collection."

---

## 🛠️ BACpypes3 Implementation Notes

### Library-Specific Considerations
When working with the BACpypes3 library in backend code:

```python
# Property access using BACpypes3 conventions
from bacpypes3.primitivedata import Real
from bacpypes3.object import AnalogInputObject

# Reading properties
present_value = analog_input.presentValue
status_flags = analog_input.statusFlags
object_name = analog_input.objectName

# Writing properties (for writable objects)
analog_output.presentValue = Real(75.5)
```

### Device Object Configuration
```python
# Device object setup with proper BACnet terminology
device_object = LocalDeviceObject(
    objectName="SpacewalkerConnector",
    objectIdentifier=('device', device_id),
    vendorIdentifier=1234,  # Use assigned vendor ID
    vendorName="Spacewalker",
    modelName="BACnet-Connector"
)
```

### Service Implementation
```python
# Implementing BACnet services with consistent terminology
async def read_occupancy_sensors(self, zone_devices: List[int]) -> Dict[int, bool]:
    """Read Present_Value from Binary Input objects representing occupancy sensors."""
    results = {}
    for device_id in zone_devices:
        try:
            # Use ReadPropertyMultiple for efficiency
            response = await self.read_property_multiple(
                device_id,
                [('binaryInput', 1, 'presentValue')]
            )
            results[device_id] = response[0]
        except APDUTimeoutError:
            logger.warning(f"APDU timeout reading device {device_id}")
            results[device_id] = None
    return results
```

---

## 📚 Official Reference

For complete and authoritative definitions of all BACnet terminology, refer to:
- **ASHRAE Standard 135-2020** - BACnet® - A Data Communication Protocol for Building Automation and Control Networks
- **BACnet International Organization** - [bacnet.org](https://bacnet.org)
- **BACpypes3 Documentation** - Library-specific implementation details

---

## 📋 Related Backend Documentation

### BACnet Implementation
> 🚀 **Backend Development**: See [Backend Development](./development/) for BACnet connector implementation details

### Troubleshooting and Operations
- **[BACnet Timeout Debugging](../gotchas/bacnet-timeout-debugging.md)** - Troubleshooting APDU timeouts and communication failures
- **[BACnet Environment Rebuild](../backend/bacnet-environment-rebuild.md)** - Development environment setup and rebuild procedures

### Development Workflows
- **[Development Tools](../development/development-tools.md)** - Backend development automation and helper scripts
- **[Git Commit Standards](../workflows/git-commit-standards.md)** - Commit message formatting for BACnet-related changes

---

**Status**: ✅ **PRODUCTION BACKEND REFERENCE**
**Last Updated**: 2025-06-29
**Applies To**: Backend development teams working with BACnet integration
**Integration**: BACpypes3 library, BACnet connector services, IoT device management

---

*This terminology reference ensures consistent BACnet implementation across all backend development teams. Following these conventions improves code readability, documentation quality, and team communication for BACnet integration projects.*
