# Super User Security Protocols

## Purpose
Comprehensive documentation for super user security protocols, elevated permissions management, monitoring, and compliance requirements in the Spacewalker authentication system.

## When to Use This
- Understanding super user privileges and responsibilities
- Implementing elevated permission workflows
- Managing cross-tenant operations and security
- Monitoring and auditing super user activities
- Keywords: super user, elevated permissions, cross-tenant access, security protocols, compliance

**Version:** 1.0
**Date:** 2025-07-09
**Status:** Current

## Key Concepts
- **Super User**: Elevated user with cross-tenant access and system administration privileges
- **Tenant Context Switching**: Ability to operate within different tenant contexts
- **Elevated Permissions**: Enhanced access rights for system administration
- **Security Monitoring**: Comprehensive logging and auditing of super user activities
- **Compliance Controls**: Regulatory and security compliance requirements

## Super User Architecture Overview

```mermaid
graph TB
    SuperUser[Super User] --> Authentication[Authentication Layer]
    Authentication --> TenantSelection[Tenant Selection]
    TenantSelection --> ContextSwitch[Context Switch]
    ContextSwitch --> Operations[Tenant Operations]

    SuperUser --> Monitoring[Security Monitoring]
    Monitoring --> AuditLog[Audit Logging]
    Monitoring --> AlertSystem[Alert System]

    Operations --> DatabaseAccess[Database Access]
    DatabaseAccess --> RLS[Row Level Security]
    RLS --> TenantData[(Tenant Data)]

    SuperUser --> AdminPanel[Admin Panel]
    AdminPanel --> UserManagement[User Management]
    AdminPanel --> TenantManagement[Tenant Management]
    AdminPanel --> SystemSettings[System Settings]

    classDef superuser fill:#F3E5F5,stroke:#7B1FA2,color:#000000
    classDef security fill:#FFEBEE,stroke:#F44336,color:#000000
    classDef data fill:#E8F5E8,stroke:#388E3C,color:#000000
    classDef admin fill:#E3F2FD,stroke:#1976D2,color:#000000

    class SuperUser,TenantSelection,ContextSwitch superuser
    class Monitoring,AuditLog,AlertSystem security
    class DatabaseAccess,RLS,TenantData data
    class AdminPanel,UserManagement,TenantManagement,SystemSettings admin
```

## Super User Privileges

### 1. Cross-Tenant Access
Super users can access and manage data across all tenants in the system.

**Database Model:**
```python
# User model with super user flag
class User(Base):
    __tablename__ = "users"

    id = Column(String(255), primary_key=True)
    email = Column(String(255), nullable=False, unique=True)
    name = Column(String(255))
    hashed_password = Column(String(255), nullable=True)
    tenant_id = Column(Integer, ForeignKey("tenants.id"), nullable=True)
    is_admin = Column(Boolean, default=False)
    is_super_user = Column(Boolean, default=False)  # Super user flag
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
```

**Super User Identification:**
```python
def require_super_user(current_user: User = Depends(get_current_user)) -> User:
    """Verify current user is a super user"""
    if not current_user.is_super_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Super user access required"
        )
    return current_user

# Usage in API endpoints
@router.get("/admin/system-stats")
def get_system_stats(
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db)
):
    """Get system-wide statistics (super user only)"""
    return {
        "total_tenants": db.query(Tenant).count(),
        "total_users": db.query(User).count(),
        "total_surveys": db.query(Survey).count(),
    }
```

### 2. Tenant Context Switching
Super users can operate within different tenant contexts using header-based selection.

**Tenant Selection API:**
```python
@router.post("/select-tenant/{tenant_id}")
def select_tenant_for_session(
    tenant_id: int,
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db),
):
    """Select a tenant for the current session (super users only)"""
    # Verify tenant exists
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tenant not found"
        )

    return {
        "message": "Tenant selected successfully",
        "selected_tenant_id": tenant_id,
        "tenant_name": tenant.name,
    }
```

**Context Management:**
```python
def get_current_tenant_id(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    x_selected_tenant_id: Optional[str] = Header(None),
) -> int:
    """Get the tenant ID from the current user or selected tenant header"""

    # Super users can select a tenant via header
    if current_user.is_super_user:
        if x_selected_tenant_id:
            try:
                selected_tenant_id = int(x_selected_tenant_id)
                # Verify tenant exists
                tenant = db.query(Tenant).filter(Tenant.id == selected_tenant_id).first()
                if not tenant:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Tenant {selected_tenant_id} not found"
                    )
                return selected_tenant_id
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid tenant ID format"
                )
        else:
            # Default to first available tenant if no selection
            first_tenant = db.query(Tenant).first()
            if not first_tenant:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="No tenants available"
                )
            return first_tenant.id

    # Regular users return their assigned tenant
    if not current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is not associated with any tenant"
        )
    return current_user.tenant_id
```

### 3. System Administration Capabilities

**User Management:**
```python
@router.post("/admin/users", response_model=UserResponse)
def create_user_admin(
    user: UserCreate,
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db),
):
    """Create a new user (super user only)"""

    # Check if user already exists
    existing_user = db.query(User).filter(User.email == user.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )

    # Create user with admin privileges
    db_user = User(
        id=user.email,
        email=user.email,
        name=user.name,
        hashed_password=hash_password(user.password),
        tenant_id=user.tenant_id,
        is_admin=user.is_admin,
        is_super_user=user.is_super_user,
    )

    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    return db_user

@router.put("/admin/users/{user_id}", response_model=UserResponse)
def update_user_admin(
    user_id: str,
    user_update: UserUpdate,
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db),
):
    """Update user information (super user only)"""

    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Update user fields
    for field, value in user_update.dict(exclude_unset=True).items():
        if field == "password":
            setattr(target_user, "hashed_password", hash_password(value))
        else:
            setattr(target_user, field, value)

    db.commit()
    db.refresh(target_user)

    return target_user
```

**Tenant Management:**
```python
@router.post("/admin/tenants", response_model=TenantResponse)
def create_tenant_admin(
    tenant: TenantCreate,
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db),
):
    """Create a new tenant (super user only)"""

    # Check subdomain uniqueness
    if tenant.subdomain:
        existing_tenant = db.query(Tenant).filter(
            Tenant.subdomain == tenant.subdomain
        ).first()
        if existing_tenant:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Subdomain already exists"
            )

    db_tenant = Tenant(
        name=tenant.name,
        location=tenant.location,
        subdomain=tenant.subdomain,
        config=tenant.config or {},
    )

    db.add(db_tenant)
    db.commit()
    db.refresh(db_tenant)

    return db_tenant

@router.delete("/admin/tenants/{tenant_id}")
def delete_tenant_admin(
    tenant_id: int,
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db),
):
    """Delete a tenant (super user only)"""

    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tenant not found"
        )

    # Check for dependent data
    user_count = db.query(User).filter(User.tenant_id == tenant_id).count()
    if user_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot delete tenant with {user_count} users"
        )

    db.delete(tenant)
    db.commit()

    return {"message": "Tenant deleted successfully"}
```

## Security Protocols

### 1. Authentication and Authorization

**Super User Authentication:**
```python
def get_current_user(
    token_data: dict = Depends(verify_token),
    db: Session = Depends(get_db)
):
    """Get current user with tenant context"""
    user_email = token_data.get("sub")
    user = db.query(User).filter(User.email == user_email).first()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Super users don't need tenant verification
    if user.is_super_user:
        return user

    # Regular users need active tenant
    if user.tenant_id and user.tenant and not user.tenant.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Tenant is not active"
        )

    return user
```

**JWT Token Claims for Super Users:**
```python
def create_access_token(data: dict) -> str:
    """Create a JWT access token with super user claims"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(seconds=JWT_EXPIRATION_DELTA)
    to_encode.update({"exp": expire})

    # Include super user flag in token
    # Example token payload:
    # {
    #   "sub": "admin@example.com",
    #   "user_id": "admin@example.com",
    #   "tenant_id": null,  # Super users may not have default tenant
    #   "is_admin": true,
    #   "is_super_user": true,
    #   "exp": 1625875200
    # }

    encoded_jwt = jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return encoded_jwt
```

### 2. Row Level Security (RLS) Integration

**RLS Context for Super Users:**
```python
# Super user RLS context management
def set_super_user_context(db: Session, tenant_id: Optional[int] = None):
    """Set database context for super user operations"""
    if tenant_id:
        # Set specific tenant context using parameterized query
        db.execute(text("SET app.current_tenant_id = :tenant_id"), {"tenant_id": tenant_id})
    else:
        # Set super user context (bypass RLS)
        db.execute(text("SET app.current_tenant_id = -1"))
    db.flush()

# Usage in super user endpoints
@router.get("/admin/all-surveys")
def get_all_surveys(
    current_user: User = Depends(require_super_user),
    tenant_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
):
    """Get surveys across all tenants or specific tenant"""

    if tenant_id:
        # Set specific tenant context
        set_super_user_context(db, tenant_id)
        surveys = db.query(Survey).all()
    else:
        # Bypass RLS to get all surveys
        set_super_user_context(db)
        surveys = db.query(Survey).all()

    return surveys
```

**Database RLS Policies:**
```sql
-- Super user RLS policy examples
CREATE POLICY "Super users can access all data" ON surveys
    FOR ALL TO application_user
    USING (get_current_tenant_id() = -1);

CREATE POLICY "Regular tenant access" ON surveys
    FOR ALL TO application_user
    USING (tenant_id = get_current_tenant_id());

-- Function to check super user context
CREATE OR REPLACE FUNCTION is_super_user_context()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN COALESCE(current_setting('app.current_tenant_id', TRUE), '0')::INT = -1;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

### 3. Access Control Patterns

**Hierarchical Permission Checking:**
```python
from enum import Enum

class PermissionLevel(Enum):
    READ = "read"
    WRITE = "write"
    ADMIN = "admin"
    SUPER_USER = "super_user"

def check_permission(
    user: User,
    resource: str,
    level: PermissionLevel
) -> bool:
    """Check if user has required permission level"""

    # Super users have all permissions
    if user.is_super_user:
        return True

    # Admin users have admin permissions
    if user.is_admin and level in [PermissionLevel.READ, PermissionLevel.WRITE, PermissionLevel.ADMIN]:
        return True

    # Regular users have read/write permissions
    if level in [PermissionLevel.READ, PermissionLevel.WRITE]:
        return True

    return False

# Usage in API endpoints
@router.delete("/admin/dangerous-operation")
def dangerous_operation(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Dangerous operation requiring super user permissions"""

    if not check_permission(current_user, "system", PermissionLevel.SUPER_USER):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Super user access required for this operation"
        )

    # Perform dangerous operation
    return {"message": "Operation completed successfully"}
```

## Security Monitoring and Auditing

### 1. Audit Logging

**Audit Log Model:**
```python
class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True)
    user_id = Column(String(255), ForeignKey("users.id"), nullable=False)
    action = Column(String(255), nullable=False)
    resource_type = Column(String(100), nullable=False)
    resource_id = Column(String(255), nullable=True)
    tenant_id = Column(Integer, ForeignKey("tenants.id"), nullable=True)
    details = Column(JSON, nullable=True)
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(String(500), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)

    # Relationships
    user = relationship("User")
    tenant = relationship("Tenant")
```

**Audit Logging Service:**
```python
class AuditService:
    @staticmethod
    def log_super_user_action(
        db: Session,
        user: User,
        action: str,
        resource_type: str,
        resource_id: Optional[str] = None,
        tenant_id: Optional[int] = None,
        details: Optional[dict] = None,
        request: Optional[Request] = None,
    ):
        """Log super user actions for security monitoring"""

        audit_log = AuditLog(
            user_id=user.id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            tenant_id=tenant_id,
            details=details,
            ip_address=request.client.host if request else None,
            user_agent=request.headers.get("User-Agent") if request else None,
        )

        db.add(audit_log)
        db.commit()

        # Send to monitoring system
        if action in ["user_created", "user_deleted", "tenant_created", "tenant_deleted"]:
            AlertService.send_security_alert(
                f"Super user {user.email} performed {action}",
                details=details
            )

# Usage in super user endpoints
@router.post("/admin/users", response_model=UserResponse)
def create_user_admin(
    user: UserCreate,
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db),
    request: Request = None,
):
    """Create a new user with audit logging"""

    # Create user logic...
    db_user = User(...)
    db.add(db_user)
    db.commit()

    # Log the action
    AuditService.log_super_user_action(
        db=db,
        user=current_user,
        action="user_created",
        resource_type="user",
        resource_id=db_user.id,
        tenant_id=db_user.tenant_id,
        details={
            "created_user_email": db_user.email,
            "is_admin": db_user.is_admin,
            "is_super_user": db_user.is_super_user,
        },
        request=request,
    )

    return db_user
```

### 2. Security Monitoring

**Security Metrics Collection:**
```python
class SecurityMetrics:
    @staticmethod
    def collect_super_user_metrics(db: Session) -> dict:
        """Collect security metrics for super user activities"""

        # Count super user actions in last 24 hours
        yesterday = datetime.utcnow() - timedelta(days=1)

        recent_actions = db.query(AuditLog).filter(
            AuditLog.timestamp >= yesterday,
            AuditLog.user_id.in_(
                db.query(User.id).filter(User.is_super_user == True)
            )
        ).count()

        # Count failed login attempts
        failed_logins = db.query(AuditLog).filter(
            AuditLog.action == "login_failed",
            AuditLog.timestamp >= yesterday
        ).count()

        # Count tenant context switches
        tenant_switches = db.query(AuditLog).filter(
            AuditLog.action == "tenant_selected",
            AuditLog.timestamp >= yesterday
        ).count()

        return {
            "super_user_actions_24h": recent_actions,
            "failed_logins_24h": failed_logins,
            "tenant_switches_24h": tenant_switches,
            "total_super_users": db.query(User).filter(User.is_super_user == True).count(),
        }

# Monitoring endpoint
@router.get("/admin/security-metrics")
def get_security_metrics(
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db),
):
    """Get security metrics (super user only)"""

    metrics = SecurityMetrics.collect_super_user_metrics(db)

    # Log metrics access
    AuditService.log_super_user_action(
        db=db,
        user=current_user,
        action="security_metrics_accessed",
        resource_type="system",
        details=metrics,
    )

    return metrics
```

### 3. Alert System

**Security Alert Service:**
```python
class AlertService:
    @staticmethod
    def send_security_alert(message: str, details: Optional[dict] = None):
        """Send security alert to monitoring system"""

        alert_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": "WARNING",
            "message": message,
            "details": details or {},
            "source": "spacewalker-auth",
        }

        # Send to logging system
        logger.warning(f"Security Alert: {message}", extra=alert_data)

        # Send to monitoring system (e.g., Slack, email, etc.)
        # This would integrate with your monitoring infrastructure

    @staticmethod
    def check_suspicious_activity(db: Session, user: User):
        """Check for suspicious super user activity"""

        # Check for rapid tenant switching
        recent_switches = db.query(AuditLog).filter(
            AuditLog.user_id == user.id,
            AuditLog.action == "tenant_selected",
            AuditLog.timestamp >= datetime.utcnow() - timedelta(minutes=5)
        ).count()

        if recent_switches > 5:
            AlertService.send_security_alert(
                f"Rapid tenant switching detected for user {user.email}",
                details={"switch_count": recent_switches}
            )

        # Check for unusual access patterns
        unusual_actions = db.query(AuditLog).filter(
            AuditLog.user_id == user.id,
            AuditLog.action.in_(["user_deleted", "tenant_deleted"]),
            AuditLog.timestamp >= datetime.utcnow() - timedelta(hours=1)
        ).count()

        if unusual_actions > 0:
            AlertService.send_security_alert(
                f"Deletion activity detected for user {user.email}",
                details={"deletion_count": unusual_actions}
            )
```

## Compliance and Governance

### 1. Compliance Requirements

**Data Protection Compliance:**
```python
class ComplianceService:
    @staticmethod
    def ensure_data_protection_compliance(
        user: User,
        action: str,
        resource_type: str,
        tenant_id: Optional[int] = None
    ) -> bool:
        """Ensure super user actions comply with data protection regulations"""

        # Check if action requires additional authorization
        high_risk_actions = [
            "user_deleted",
            "tenant_deleted",
            "data_export",
            "bulk_data_access"
        ]

        if action in high_risk_actions:
            # Require additional verification
            return ComplianceService.verify_high_risk_action(user, action, resource_type)

        return True

    @staticmethod
    def verify_high_risk_action(user: User, action: str, resource_type: str) -> bool:
        """Verify high-risk actions meet compliance requirements"""

        # Implementation would check:
        # - Recent authentication (require re-auth for sensitive actions)
        # - Business justification
        # - Approval workflows
        # - Retention policies

        return True  # Simplified for example

    @staticmethod
    def log_compliance_event(
        db: Session,
        user: User,
        action: str,
        compliance_check: str,
        result: bool,
        details: Optional[dict] = None
    ):
        """Log compliance-related events"""

        compliance_log = AuditLog(
            user_id=user.id,
            action=f"compliance_{action}",
            resource_type="compliance",
            details={
                "compliance_check": compliance_check,
                "result": result,
                "additional_details": details or {}
            }
        )

        db.add(compliance_log)
        db.commit()
```

### 2. Access Review and Governance

**Access Review Service:**
```python
class AccessReviewService:
    @staticmethod
    def generate_super_user_access_report(db: Session) -> dict:
        """Generate access report for super user privileges"""

        super_users = db.query(User).filter(User.is_super_user == True).all()

        report = {
            "report_date": datetime.utcnow().isoformat(),
            "total_super_users": len(super_users),
            "super_users": []
        }

        for user in super_users:
            # Get recent activity
            recent_activity = db.query(AuditLog).filter(
                AuditLog.user_id == user.id,
                AuditLog.timestamp >= datetime.utcnow() - timedelta(days=30)
            ).count()

            user_report = {
                "user_id": user.id,
                "email": user.email,
                "name": user.name,
                "created_at": user.created_at.isoformat(),
                "last_login": user.last_login.isoformat() if user.last_login else None,
                "recent_activity_count": recent_activity,
                "is_active": user.is_active,
            }

            report["super_users"].append(user_report)

        return report

    @staticmethod
    def review_super_user_access(db: Session, user_id: str) -> dict:
        """Review specific super user access and recommend actions"""

        user = db.query(User).filter(User.id == user_id).first()
        if not user or not user.is_super_user:
            return {"error": "User not found or not a super user"}

        # Analyze activity patterns
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)

        recent_actions = db.query(AuditLog).filter(
            AuditLog.user_id == user_id,
            AuditLog.timestamp >= thirty_days_ago
        ).count()

        # Check for inactive super users
        if user.last_login and user.last_login < thirty_days_ago:
            recommendation = "Consider deactivating - inactive for 30+ days"
        elif recent_actions == 0:
            recommendation = "Consider deactivating - no recent activity"
        else:
            recommendation = "Access appropriate - regular activity detected"

        return {
            "user_id": user_id,
            "last_login": user.last_login.isoformat() if user.last_login else None,
            "recent_activity_count": recent_actions,
            "recommendation": recommendation,
        }
```

## Best Practices and Security Guidelines

### 1. Super User Creation Guidelines

**Creating Super Users:**
```python
def create_super_user_securely(
    email: str,
    name: str,
    password: str,
    created_by: User,
    db: Session
) -> User:
    """Create a super user with proper security checks"""

    # Validate creator permissions
    if not created_by.is_super_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only super users can create super users"
        )

    # Validate email domain (optional security requirement)
    allowed_domains = ["company.com", "trusted-partner.com"]
    email_domain = email.split("@")[1].lower()
    if email_domain not in allowed_domains:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email domain not authorized for super user access"
        )

    # Validate password strength
    if len(password) < 12:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Super user password must be at least 12 characters"
        )

    # Create user
    super_user = User(
        id=email,
        email=email,
        name=name,
        hashed_password=hash_password(password),
        is_super_user=True,
        is_admin=True,  # Super users are also admins
        tenant_id=None,  # Super users may not have default tenant
    )

    db.add(super_user)
    db.commit()

    # Log creation
    AuditService.log_super_user_action(
        db=db,
        user=created_by,
        action="super_user_created",
        resource_type="user",
        resource_id=super_user.id,
        details={
            "created_user_email": email,
            "created_user_name": name,
        }
    )

    return super_user
```

### 2. Security Hardening

**Multi-Factor Authentication (Future Enhancement):**
```python
# Placeholder for MFA implementation
class MFAService:
    @staticmethod
    def require_mfa_for_super_user(user: User) -> bool:
        """Check if MFA is required for super user operations"""

        # All super users should use MFA
        return user.is_super_user

    @staticmethod
    def validate_mfa_token(user: User, token: str) -> bool:
        """Validate MFA token for super user"""

        # Implementation would validate TOTP, SMS, or other MFA methods
        return True  # Simplified for example
```

**IP Address Restrictions:**
```python
class IPRestrictionService:
    ALLOWED_SUPER_USER_IPS = [
        "192.168.1.0/24",  # Corporate network
        "10.0.0.0/8",      # VPN network
    ]

    @staticmethod
    def validate_ip_access(user: User, ip_address: str) -> bool:
        """Validate IP address for super user access"""

        if not user.is_super_user:
            return True  # Regular users not restricted

        # Check if IP is in allowed ranges
        from ipaddress import ip_address, ip_network

        user_ip = ip_address(ip_address)

        for allowed_range in IPRestrictionService.ALLOWED_SUPER_USER_IPS:
            if user_ip in ip_network(allowed_range):
                return True

        return False
```

### 3. Operational Security

**Session Management:**
```python
class SuperUserSessionService:
    @staticmethod
    def create_super_user_session(user: User, request: Request) -> dict:
        """Create enhanced session for super user"""

        session_data = {
            "user_id": user.id,
            "session_id": str(uuid.uuid4()),
            "ip_address": request.client.host,
            "user_agent": request.headers.get("User-Agent"),
            "created_at": datetime.utcnow(),
            "expires_at": datetime.utcnow() + timedelta(hours=4),  # Shorter session
        }

        # Store session in secure storage (Redis, database, etc.)
        # Implementation depends on your infrastructure

        return session_data

    @staticmethod
    def validate_super_user_session(session_id: str, user: User) -> bool:
        """Validate super user session"""

        # Check session validity
        # Implementation depends on your session storage

        return True  # Simplified for example
```

## Emergency Procedures

### 1. Emergency Access Revocation

**Immediate Access Revocation:**
```python
@router.post("/admin/emergency/revoke-access/{user_id}")
def emergency_revoke_access(
    user_id: str,
    current_user: User = Depends(require_super_user),
    db: Session = Depends(get_db),
):
    """Emergency revocation of super user access"""

    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Revoke super user privileges
    target_user.is_super_user = False
    target_user.is_admin = False
    target_user.is_active = False

    db.commit()

    # Log emergency action
    AuditService.log_super_user_action(
        db=db,
        user=current_user,
        action="emergency_access_revoked",
        resource_type="user",
        resource_id=user_id,
        details={
            "revoked_user_email": target_user.email,
            "reason": "Emergency access revocation",
        }
    )

    # Send immediate alert
    AlertService.send_security_alert(
        f"Emergency access revocation for user {target_user.email}",
        details={"revoked_by": current_user.email}
    )

    return {"message": "Access revoked successfully"}
```

### 2. Incident Response

**Security Incident Response:**
```python
class IncidentResponseService:
    @staticmethod
    def handle_security_incident(
        incident_type: str,
        user: User,
        details: dict,
        db: Session
    ):
        """Handle security incident involving super user"""

        # Log incident
        incident_log = AuditLog(
            user_id=user.id,
            action=f"security_incident_{incident_type}",
            resource_type="security",
            details={
                "incident_type": incident_type,
                "incident_details": details,
                "response_actions": []
            }
        )

        db.add(incident_log)
        db.commit()

        # Automated response actions
        if incident_type == "suspicious_activity":
            # Temporarily disable account
            user.is_active = False
            db.commit()

            AlertService.send_security_alert(
                f"User {user.email} temporarily disabled due to suspicious activity",
                details=details
            )

        elif incident_type == "unauthorized_access":
            # Revoke all active sessions
            # Implementation depends on session management
            pass
```

## Testing Super User Security

### Unit Tests

**Super User Authentication Tests:**
```python
def test_super_user_authentication():
    """Test super user authentication and permissions"""

    # Create super user
    super_user = User(
        id="super@example.com",
        email="super@example.com",
        name="Super User",
        is_super_user=True,
        is_admin=True,
        hashed_password=hash_password("secure_password")
    )

    # Test authentication
    response = client.post("/auth/login", json={
        "email": "super@example.com",
        "password": "secure_password"
    })

    assert response.status_code == 200
    token = response.json()["access_token"]

    # Test super user endpoint access
    response = client.get("/admin/system-stats", headers={
        "Authorization": f"Bearer {token}"
    })

    assert response.status_code == 200
    assert "total_tenants" in response.json()

def test_regular_user_cannot_access_super_user_endpoints():
    """Test that regular users cannot access super user endpoints"""

    # Create regular user
    regular_user = User(
        id="regular@example.com",
        email="regular@example.com",
        name="Regular User",
        is_super_user=False,
        is_admin=False,
        hashed_password=hash_password("password")
    )

    # Login as regular user
    response = client.post("/auth/login", json={
        "email": "regular@example.com",
        "password": "password"
    })

    token = response.json()["access_token"]

    # Try to access super user endpoint
    response = client.get("/admin/system-stats", headers={
        "Authorization": f"Bearer {token}"
    })

    assert response.status_code == 403
    assert "Super user access required" in response.json()["detail"]
```

### Integration Tests

**Tenant Context Switching Tests:**
```python
def test_super_user_tenant_context_switching():
    """Test super user can switch tenant contexts"""

    # Create tenants
    tenant1 = Tenant(name="Tenant 1", location={})
    tenant2 = Tenant(name="Tenant 2", location={})

    # Create super user
    super_user = User(
        id="super@example.com",
        email="super@example.com",
        is_super_user=True,
        hashed_password=hash_password("password")
    )

    # Login
    response = client.post("/auth/login", json={
        "email": "super@example.com",
        "password": "password"
    })
    token = response.json()["access_token"]

    # Select tenant
    response = client.post(f"/auth/select-tenant/{tenant1.id}", headers={
        "Authorization": f"Bearer {token}"
    })

    assert response.status_code == 200
    assert response.json()["selected_tenant_id"] == tenant1.id

    # Access tenant-specific data
    response = client.get("/surveys", headers={
        "Authorization": f"Bearer {token}",
        "X-Selected-Tenant-Id": str(tenant1.id)
    })

    assert response.status_code == 200
```

## Related Documentation
- [Backend Authentication API](./authentication-api.md) - Core authentication endpoints and JWT management
- [Admin Authentication Workflows](../admin/authentication-workflows.md) - Frontend authentication integration
- [Security Architecture](../architecture/security-architecture.md) - Overall security design principles
- [API Development Guide](./api-development.md) - General API patterns and security practices

---
**Status**: ✅ Current
**Last Updated**: 2025-07-09
**Technology Stack**: FastAPI, SQLAlchemy, PostgreSQL, JWT, Python
