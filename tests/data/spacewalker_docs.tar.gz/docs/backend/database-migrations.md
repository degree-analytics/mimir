# Database Migrations Guide

## Purpose
Comprehensive guide for managing PostgreSQL database schema changes in the Spacewalker backend using Alembic migrations. Essential reference for backend developers working with SQLAlchemy models, database schema evolution, and production deployment procedures. Covers development workflow, migration best practices, troubleshooting, and production deployment strategies.

## When to Use This
- Creating and applying database schema changes during development
- Managing SQLAlchemy model modifications and database migrations
- Deploying database changes to staging and production environments
- Troubleshooting migration conflicts and schema drift issues
- Implementing zero-downtime database changes and rollback procedures
- Keywords: Alembic migrations, SQLAlchemy, PostgreSQL, database schema, migration troubleshooting

**Version:** 2.3 (Reorganized from implementation documentation)
**Date:** 2025-06-29
**Status:** Current - Production Database Migration Guide

---

## 🗄️ Migration System Overview

### Technology Stack
- **Migration Tool**: [Alembic](https://alembic.sqlalchemy.org/) - SQLAlchemy's official migration framework
- **ORM**: SQLAlchemy with async support for PostgreSQL operations
- **Database**: PostgreSQL with row-level security for multi-tenant isolation
- **Configuration**: Alembic configuration via `apps/backend/alembic.ini`
- **Container Integration**: Automatic migration application during backend service startup

### Source of Truth
- **SQLAlchemy Models**: `apps/backend/src/spacewalker/models/` - Definitive database schema definition
- **Migration Scripts**: `apps/backend/migrations/versions/` - Version-controlled schema change history
- **Configuration**: `apps/backend/alembic.ini` - Alembic environment and connection settings

---

## 🔄 **CURRENT** Development Migration Workflow (2025)

### 🚨 **CRITICAL**: Always Use These Commands

**All migration operations now use the unified `migrations` command interface:**

### 🎯 **Command Interface Guide**

SpaceWalker uses different command interfaces for different purposes:

- **`just migrations <action>`** - **Primary interface** for all database migration operations (create, apply, validate, rollback, etc.)
- **`just db <operation>`** - Database utility operations (connect, shell, inspect, etc.) - NOT for migrations
- **`just app-deploy migrate <env>`** - **Deployment context only** - Used internally by deployment scripts for remote ECS-based migrations

**Rule of Thumb**: Use `just migrations` for all migration work. The other commands serve different purposes.

### 📊 **When to Use Which Command**

#### Decision Tree for Command Selection:

```
Are you working with database migrations?
│
├─ YES → Are you in a deployment/CI context?
│   │
│   ├─ NO (Local Development) → Use `just migrations <action>`
│   │   • Creating new migrations: `just migrations create "description"`
│   │   • Applying migrations: `just migrations apply local`
│   │   • Validating migrations: `just migrations validate local`
│   │   • Rolling back: `just migrations rollback local`
│   │
│   └─ YES (Deployment/CI) → Commands are called automatically
│       • SAM templates use: `just app-deploy migrate <env>`
│       • GitHub Actions uses: `just migrations apply/validate`
│       • Manual remote ops: `just migrations <action> <env>`
│
└─ NO → Are you doing database utility operations?
    │
    ├─ YES → Use `just db <operation>`
    │   • Connect to database: `just db shell`
    │   • Verify DB state: `just db verify`
    │   • Seed test data: `just db seed`
    │   • Clean demo data: `just db clean`
    │
    └─ NO → Check `just help` for other commands
```

#### Common Scenarios:

| Scenario | Command |
|----------|---------|
| **"I need to create a new migration"** | `just migrations create "add user preferences"` |
| **"I need to apply pending migrations locally"** | `just migrations apply local` |
| **"I want to check if migrations are in sync"** | `just migrations validate local` |
| **"I need to rollback the last migration"** | `just migrations rollback local` |
| **"I want to connect to the database"** | `just db shell` |
| **"I need to verify database is healthy"** | `just db verify` |
| **"Deploy is failing due to migrations"** | Check logs, then `just migrations apply <env>` |

#### ⚠️ Common Mistakes to Avoid:

- ❌ Don't use `just db` commands for migration operations
- ❌ Don't manually call `just app-deploy migrate` - it's for automated deployments
- ❌ Don't run remote migrations without checking deployment status first
- ✅ Always validate migrations before deploying: `just migrations validate <env>`

#### Step 1: Modify SQLAlchemy Models

Make changes to model files in `apps/backend/src/spacewalker/models/`:

```python
# Example: Adding a new column to Room model
# apps/backend/src/spacewalker/models/room.py

from sqlalchemy import Column, String, Text, DateTime
from sqlalchemy.sql import func

class Room(Base):
    __tablename__ = "rooms"

    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)

    # New column addition
    notes = Column(Text, nullable=True)
    last_inspection_date = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
```

#### Step 2: Generate Migration Script

**NEW COMMAND** - Use the unified database interface:

```bash
# Generate migration with descriptive message (CURRENT COMMAND)
just migrations create "add_notes_and_inspection_date_to_rooms"

# Verify migration was created
just migrations history
```

#### Step 3: Apply Migration Locally

```bash
# Apply the migration to your local database
just migrations apply local

# Verify migration was applied
just migrations validate local
```

#### Step 4: Test Your Changes

```bash
# Run tests to ensure migration doesn't break existing functionality
just test unit backend

# Test your new feature that uses the migrated schema
# Commit and push when everything works
```

#### Step 5: Create PR with Migration Notice

**CRITICAL**: When creating PR, you MUST:

1. **Check the migration checkbox** in PR template
2. **Fill in target environment** (dev/staging/prod)
3. **List the migration files** created
4. **Include warning**: "⚠️ BLOCKER: Someone must run `just migrations apply <env>` BEFORE merging this PR"

#### Step 6: Pre-Merge Migration Coordination

**BEFORE the PR is merged**:

```bash
# For PRs targeting dev branch:
just migrations apply dev

# For PRs targeting main/prod branch:
(just prod enable --minutes=30)
just migrations apply prod
```

**Only after migrations are applied can the PR be safely merged.**

### 🤝 **Team Coordination Protocol**

**For Dev Environment:**
1. **PR Author**: Mark PR with migration requirements
2. **Reviewer/Lead**: Run `just migrations apply dev` before approving
3. **Anyone**: Merge PR after migration is applied
4. **Result**: CI deployment succeeds automatically

**For Production Environment:**
1. **PR Author**: Mark PR with migration requirements  
2. **Production Access Holder**: Run `(just prod enable --minutes=30) && just migrations apply prod`
3. **Team Lead**: Merge PR after production migration confirmed
4. **Result**: Production deployment succeeds

### ⚠️ **What Happens If You Forget**

If someone merges a migration PR without running migrations first:

```bash
# Deployment will be BLOCKED with this error:
❌ Migration validation failed - aborting deployment
   Database has: abc123def456
   Code expects: xyz789abc123

# To fix:
just migrations apply <env>  # Apply the missing migration
# Then deployment will automatically succeed on next CI run
```

---

## 🛡️ **MIGRATION SAFETY SYSTEM (NEW 2025)**

### Automatic Protection

**CRITICAL**: The system now automatically prevents broken deployments:

1. **CI/CD Validation**: PR checks validate migrations before merge
2. **Deployment Blocking**: ECS deployments are blocked if migrations don't match database
3. **Remote Execution**: Migrations can be run remotely via ECS tasks

### Remote Migration Commands

```bash
# Apply migrations to remote environments
just migrations apply dev        # Apply to dev environment
just migrations apply staging    # Apply to staging environment  
just migrations apply prod       # Apply to production (requires prod_enable)

# Validate remote database state
just migrations validate dev     # Check dev database matches code
just migrations validate staging # Check staging database matches code
```

### Emergency Situations

If deployments are blocked due to migration mismatches:

```bash
# 1. Check what's wrong
just migrations validate dev

# 2. Apply missing migrations  
just migrations apply dev

# 3. Retry deployment (it will now succeed)
```

### Production Safety

Production migrations require special handling:

```bash
# Enable production mode first (required for all prod operations)
(just prod enable --minutes=30)

# Then apply migrations
just migrations apply prod

# Deployments will now succeed
```

#### Step 4: Review Generated Migration

**CRITICAL**: Always review the generated migration script before applying:

```python
# Example generated migration in apps/backend/migrations/versions/
"""Add notes and last_inspection_date to room table

Revision ID: 2f8a1b3c4d5e
Revises: 1a2b3c4d5e6f
Create Date: 2025-06-29 15:30:45.123456

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = '2f8a1b3c4d5e'
down_revision = '1a2b3c4d5e6f'
branch_labels = None
depends_on = None

def upgrade():
    # ### commands auto generated by Alembic - review carefully ###
    op.add_column('rooms', sa.Column('notes', sa.Text(), nullable=True))
    op.add_column('rooms', sa.Column('last_inspection_date',
                                   sa.DateTime(timezone=True), nullable=True))
    # ### end Alembic commands ###

def downgrade():
    # ### commands auto generated by Alembic - review carefully ###
    op.drop_column('rooms', 'last_inspection_date')
    op.drop_column('rooms', 'notes')
    # ### end Alembic commands ###
```

#### Step 4: Apply Migration

Apply pending migrations to development database:

```bash
# Apply all pending migrations
just backend-alembic-upgrade

# Apply specific number of migrations
just backend-alembic-upgrade +2

# Apply to specific revision
just backend-alembic-upgrade 2f8a1b3c4d5e
```

---

## 🛠️ Migration Command Reference

### Essential Migration Commands

| Command | Purpose | Usage Example |
|---------|---------|---------------|
| `just backend-alembic-revision "message"` | Create new migration script | `just backend-alembic-revision "Add user roles table"` |
| `just backend-alembic-upgrade` | Apply all pending migrations | `just backend-alembic-upgrade` |
| `just backend-alembic-downgrade` | Revert most recent migration | `just backend-alembic-downgrade` |
| `just backend-alembic-current` | Show current database version | `just backend-alembic-current` |
| `just backend-alembic-history` | View migration history | `just backend-alembic-history --verbose` |

### Advanced Migration Operations

#### Manual Migration Creation
```bash
# Create empty migration for manual SQL
just backend-alembic-revision --empty "Custom data migration"

# Create migration with specific dependencies
just backend-alembic-revision "Add indexes" --depends-on 2f8a1b3c4d5e
```

#### Migration Information and Debugging
```bash
# Check migration status
just backend-alembic-current

# Show detailed migration history
just backend-alembic-history --verbose

# Show SQL that would be executed (dry run)
just backend-alembic-upgrade --sql

# Show differences between database and models
just backend-alembic-revision --autogenerate --sql-dry-run
```

#### Targeted Migration Operations
```bash
# Downgrade to specific revision
just backend-alembic-downgrade 1a2b3c4d5e6f

# Upgrade/downgrade by relative number
just backend-alembic-upgrade +2
just backend-alembic-downgrade -1

# Stamp database with specific revision (without running migration)
just backend-alembic-stamp 2f8a1b3c4d5e
```

---

## 🚀 Production Deployment

### Automatic Migration Application

In production environments, migrations are applied **automatically** during backend container startup through the container entrypoint script:

```bash
#!/bin/bash
# Container entrypoint script

# Apply all pending migrations
# Note: In containerized environments, this runs directly
# For local development, use: just migrations up
alembic upgrade head

# Start FastAPI application
exec uvicorn spacewalker.main:app --host 0.0.0.0 --port 8000
```

### Production Migration Strategy

#### Zero-Downtime Migration Approach
1. **Backward Compatible Changes**: Deploy migrations that don't break existing code
2. **Code Deployment**: Deploy new application version that works with both old and new schema
3. **Migration Application**: Apply migrations during rolling deployment
4. **Cleanup**: Remove old code paths and deprecated columns in subsequent releases

#### Production Checklist
- [ ] Migration tested in staging environment identical to production
- [ ] Rollback procedure verified and documented
- [ ] Database backup completed before migration
- [ ] Migration runtime estimated and communicated
- [ ] Monitoring alerts configured for migration errors
- [ ] Team notified of deployment window

### Container Integration

```dockerfile
# Dockerfile excerpt showing migration integration
FROM python:3.11-slim

COPY apps/backend/migrations ./migrations
COPY apps/backend/alembic.ini ./alembic.ini
COPY apps/backend/src ./src

# Install dependencies and configure environment
RUN pip install -r requirements.txt

# Set migration entrypoint
COPY docker/entrypoint.sh ./entrypoint.sh
RUN chmod +x ./entrypoint.sh

ENTRYPOINT ["./entrypoint.sh"]
CMD ["uvicorn", "spacewalker.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

---

## 🔧 Advanced Migration Patterns

### Data Migrations

For complex data transformations that require more than schema changes:

```python
# Example: Data migration with SQL operations
def upgrade():
    # Schema change
    op.add_column('rooms', sa.Column('room_type_id', sa.String(), nullable=True))

    # Data migration
    connection = op.get_bind()
    connection.execute(
        """
        UPDATE rooms
        SET room_type_id = CASE
            WHEN name LIKE '%Classroom%' THEN 'classroom'
            WHEN name LIKE '%Lab%' THEN 'laboratory'
            ELSE 'general'
        END
        """
    )

    # Make column non-nullable after data migration
    op.alter_column('rooms', 'room_type_id', nullable=False)

def downgrade():
    op.drop_column('rooms', 'room_type_id')
```

### Large Table Migrations

For tables with millions of rows, use batch operations:

```python
# Example: Batch operations for large tables
def upgrade():
    # Use batch mode for large table modifications
    with op.batch_alter_table('survey_images') as batch_op:
        batch_op.add_column(sa.Column('file_size', sa.BigInteger(), nullable=True))
        batch_op.create_index('idx_survey_images_file_size', ['file_size'])

def downgrade():
    with op.batch_alter_table('survey_images') as batch_op:
        batch_op.drop_index('idx_survey_images_file_size')
        batch_op.drop_column('file_size')
```

### Multi-Tenant Migration Considerations

```python
# Example: Tenant-aware data migration
def upgrade():
    connection = op.get_bind()

    # Get all tenants
    tenants = connection.execute("SELECT id FROM tenants").fetchall()

    for tenant in tenants:
        # Apply tenant-specific data migration
        connection.execute(
            """
            UPDATE rooms
            SET standardized_name = UPPER(TRIM(name))
            WHERE tenant_id = %s
            """,
            (tenant.id,)
        )

def downgrade():
    # Rollback tenant-specific changes
    op.execute("UPDATE rooms SET standardized_name = NULL")
```

### Tenant Attribute Initialization Process

**Managing Tenant Attributes in Multi-Tenant Architecture**

For multi-tenant applications, tenant attributes must be initialized after tenant creation to ensure proper functionality. This process involves creating standardized attribute definitions that provide consistent data structure across all tenants.

#### System Default Tenant Attributes

The System Default tenant (ID: 1) requires special attribute initialization for development and testing purposes:

```python
# Example: System Default tenant attribute initialization
from spacewalker.services.attribute_service import AttributeService
from spacewalker.models.tenant import Tenant

def initialize_system_tenant_attributes():
    """Initialize attributes for System Default tenant."""
    async with get_db_session() as db:
        system_tenant = await db.get(Tenant, 1)
        if system_tenant:
            # Initialize all standard attributes for System Default tenant
            await AttributeService.initialize_tenant_attributes(db, system_tenant.id)
            print(f"✅ System Default tenant attributes initialized")
```

#### Standard Attribute Categories

The AttributeService provides 41 standard attribute definitions across 7 categories:

1. **Building Information** - Basic building metadata and identification
2. **Location Details** - Geographic and address information
3. **Facility Management** - Operational and maintenance tracking
4. **Compliance & Safety** - Regulatory and safety requirements
5. **Energy & Environment** - Sustainability and environmental metrics
6. **Technology Infrastructure** - IT and communication systems
7. **Custom Fields** - Tenant-specific customization options

#### Tenant Attribute Migration Pattern

```python
# Example: Migration with tenant attribute initialization
def upgrade():
    # Standard schema changes
    op.create_table('new_tenant_feature',
        sa.Column('id', sa.String(), nullable=False),
        sa.Column('tenant_id', sa.String(), nullable=False),
        sa.Column('feature_data', sa.JSON(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'])
    )
    
    # Initialize attributes for existing tenants
    connection = op.get_bind()
    tenants = connection.execute("SELECT id FROM tenants").fetchall()
    
    for tenant in tenants:
        # Use AttributeService to ensure consistent attribute setup
        # This would typically be done via a script or service call
        connection.execute(
            """
            INSERT INTO tenant_attributes (tenant_id, attribute_key, attribute_value)
            SELECT %s, 'new_feature_enabled', 'true'
            WHERE NOT EXISTS (
                SELECT 1 FROM tenant_attributes 
                WHERE tenant_id = %s AND attribute_key = 'new_feature_enabled'
            )
            """,
            (tenant.id, tenant.id)
        )

def downgrade():
    # Remove tenant-specific attributes
    op.execute("DELETE FROM tenant_attributes WHERE attribute_key = 'new_feature_enabled'")
    op.drop_table('new_tenant_feature')
```

#### Cloud Deployment Attribute Initialization

For cloud deployments, use ECS tasks to initialize tenant attributes:

```bash
# Initialize System Default tenant attributes in cloud environment
just aws_init_system_attributes dev   # Development environment
just aws_init_system_attributes prod  # Production environment (requires prod_enable)
```

This executes the tenant attribute initialization script within the deployed backend container environment, ensuring:
- Access to application database configuration
- Proper dependency and service layer access
- Consistent attribute definitions across environments
- Secure execution within the application context

#### Best Practices for Tenant Attribute Migrations

1. **Consistency Across Tenants**: Use AttributeService to ensure uniform attribute definitions
2. **Idempotent Operations**: Check for existing attributes before creation
3. **Environment-Specific Initialization**: Use appropriate commands for local vs cloud environments
4. **Validation**: Verify attribute initialization success after migration
5. **Documentation**: Include attribute purpose and usage in migration comments

```python
# Example: Comprehensive tenant attribute migration
def upgrade():
    """Add new survey-related attributes for all tenants."""
    
    # Schema changes first
    op.add_column('surveys', sa.Column('custom_attributes', sa.JSON(), nullable=True))
    
    # Initialize tenant attributes via service layer
    # Note: This would typically be done via a separate script
    connection = op.get_bind()
    
    # Define new attributes for all tenants
    new_attributes = [
        ('survey_retention_days', '365'),
        ('survey_approval_required', 'true'),
        ('survey_photo_limit', '10')
    ]
    
    tenants = connection.execute("SELECT id FROM tenants").fetchall()
    
    for tenant in tenants:
        for attr_key, attr_value in new_attributes:
            connection.execute(
                """
                INSERT INTO tenant_attributes (id, tenant_id, attribute_key, attribute_value, created_at)
                SELECT gen_random_uuid(), %s, %s, %s, NOW()
                WHERE NOT EXISTS (
                    SELECT 1 FROM tenant_attributes 
                    WHERE tenant_id = %s AND attribute_key = %s
                )
                """,
                (tenant.id, attr_key, attr_value, tenant.id, attr_key)
            )
```

**Related Commands:**
- `just db_init_system_attributes` - Initialize System Default tenant attributes locally
- `just aws_init_system_attributes <env>` - Initialize attributes in cloud environment
- `just db_inspect_attributes` - Verify tenant attribute setup
- `just db_inspect_attributes tenant_id=1` - Check specific tenant attributes

---

## ⚠️ Migration Troubleshooting

### Command Interface Confusion

#### "Unknown recipe" Errors

**Problem**: Running a command returns "Unknown recipe" error
**Solution**: Check the exact command syntax with `just help | grep migrations`

```bash
# Common mistakes:
just run-migrations dev        # ❌ Wrong - this command doesn't exist
just migrations apply dev      # ✅ Correct

just migrate up                # ❌ Wrong - missing 's' in migrations
just migrations apply local    # ✅ Correct

just db migrate                # ❌ Wrong - db commands don't handle migrations
just migrations apply local    # ✅ Correct
```

#### "Which Command Should I Use?"

**Problem**: Unsure which command interface to use
**Quick Reference**:
- For ALL migration operations → `just migrations <action> <env>`
- For database utilities → `just db <operation>`
- For deployment context → Handled automatically by deployment scripts

#### Command Not Working as Expected

**Problem**: Command runs but doesn't do what you expect
**Common Causes**:
- Wrong environment specified (local vs dev vs prod)
- Running from wrong directory (some commands need to be in backend/)
- Missing AWS credentials for remote operations
- Database connection issues

**Debug Process**:
```bash
# Check your environment
echo $AWS_PROFILE
just db verify local

# Verify command syntax
just help migrations

# Check if you're in the right directory
pwd  # Should be project root for just commands
```

### Common Migration Issues

#### 1. Migration Conflicts and Resolution

**Problem**: Multiple developers create migrations with the same down_revision:
```bash
alembic.util.exc.CommandError: Multiple heads exist in the database; please resolve
```

**Solution**: Merge conflicting migration heads:
```bash
# Check current heads
just backend-alembic-heads

# Create merge migration
just backend-alembic-merge -m "Merge migration heads" head1 head2

# Apply merge migration
just backend-alembic-upgrade
```

#### 2. Schema Drift Detection

**Problem**: Database schema doesn't match SQLAlchemy models:
```bash
# Generate comparison migration to detect drift
just backend-alembic-revision --autogenerate "Detect schema drift"

# Review the generated migration for unexpected changes
```

**Prevention**: Regular schema validation in CI/CD:
```bash
# Add to CI pipeline
just backend-alembic-revision --autogenerate --check "CI schema validation"
```

#### 3. Failed Migration Recovery

**Problem**: Migration fails partway through execution:

**Solution Steps**:
1. **Identify current state**:
   ```bash
   just backend-alembic-current
   just backend-alembic-history
   ```

2. **Manual database inspection**:
   ```bash
   just db_connect
   # SQL: SELECT * FROM alembic_version;
   # SQL: \d+ table_name  -- Check table structure
   ```

3. **Recovery options**:
   ```bash
   # Option 1: Fix and retry
   just backend-alembic-upgrade

   # Option 2: Force stamp to working revision
   just backend-alembic-stamp previous_working_revision

   # Option 3: Manual cleanup and re-run
   # Fix database manually, then:
   just backend-alembic-stamp target_revision
   ```

### Migration Debugging Strategies

#### SQL Preview and Validation
```bash
# Preview SQL without executing
just backend-alembic-upgrade --sql > migration_preview.sql

# Test migration in transaction (PostgreSQL)
just backend-alembic-upgrade --sql | psql "postgresql://user:pass@localhost/db" --single-transaction
```

#### Migration Testing Framework
```python
# Example: Migration test in pytest
def test_migration_up_down():
    """Test that migration can be applied and rolled back cleanly."""

    # Apply migration
    alembic_config = create_alembic_config()
    command.upgrade(alembic_config, "head")

    # Verify schema changes
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    assert "new_table" in tables

    # Test rollback
    command.downgrade(alembic_config, "-1")

    # Verify rollback
    tables = inspector.get_table_names()
    assert "new_table" not in tables
```

---

## 📋 Migration Best Practices

### Development Best Practices

#### 1. Migration Design Principles
- **Atomic Changes**: Each migration should represent a single, logical schema change
- **Backward Compatibility**: Ensure migrations don't break existing application code
- **Idempotent Operations**: Migrations should be safe to run multiple times
- **Descriptive Messages**: Use clear, descriptive migration messages

#### 2. Code Review Checklist
- [ ] **Migration Logic**: Verify upgrade/downgrade operations are correct
- [ ] **Data Safety**: Ensure no data loss during schema changes
- [ ] **Performance Impact**: Consider impact on large tables and indexes
- [ ] **Rollback Tested**: Verify downgrade operation works correctly
- [ ] **Dependencies**: Check migration dependencies and order

#### 3. Testing Strategy
```python
# Example: Comprehensive migration testing
class TestMigrations:
    def test_upgrade_path(self):
        """Test complete upgrade path from base to head."""
        command.upgrade(alembic_config, "head")
        assert_schema_matches_models()

    def test_downgrade_path(self):
        """Test rollback capabilities."""
        command.upgrade(alembic_config, "head")
        command.downgrade(alembic_config, "base")
        assert_clean_database_state()

    def test_data_preservation(self):
        """Test that data migrations preserve data integrity."""
        # Insert test data
        # Run migration
        # Verify data transformation correctness
```

### Production Best Practices

#### 1. Pre-Migration Validation
- **Schema Backup**: Complete database backup before migration
- **Staging Testing**: Test migration on production-like staging environment
- **Performance Testing**: Measure migration runtime on staging data
- **Rollback Testing**: Verify rollback procedures work correctly

#### 2. Migration Execution Strategy
- **Maintenance Window**: Schedule migrations during low-traffic periods
- **Monitoring**: Monitor database performance and application health
- **Communication**: Notify stakeholders of migration schedule and impact
- **Incremental Approach**: Break large migrations into smaller, safer steps

#### 3. Post-Migration Verification
```sql
-- Example: Post-migration validation queries
-- Check row counts before and after
SELECT 'rooms' as table_name, COUNT(*) as row_count FROM rooms
UNION ALL
SELECT 'surveys' as table_name, COUNT(*) as row_count FROM surveys;

-- Verify foreign key constraints
SELECT constraint_name, table_name
FROM information_schema.table_constraints
WHERE constraint_type = 'FOREIGN KEY';

-- Check for orphaned records
SELECT s.id FROM surveys s
LEFT JOIN rooms r ON s.room_id = r.id
WHERE r.id IS NULL;
```

---

## 🔗 Related Database Documentation

### Database Architecture and Design
> 🗄️ **Database Design**: See [Database Design](./database-design.md) for comprehensive database schema, model relationships, and architecture patterns
> 🗄️ **Database Development**: See [Database Development Guide](./development/README.md) for SQLAlchemy patterns, query optimization, and development workflows

### Operations and Management
- **[Database Access Workflows](../workflows/database-access.md)** - Secure database access, SSH tunneling, and production database operations
- **[Demo Data Management](../workflows/demo-data-management.md)** - Safe demo data creation, seeding, and cleanup procedures
- **[Database Performance Optimization](./development/README.md)** - Query optimization, indexing strategies, and performance monitoring

### Development Integration
- **[API Development Guide](./api-development.md)** - FastAPI development patterns and database integration
- **[Backend Testing Guide](../workflows/testing-guide.md)** - Testing strategies including database testing and migration validation
- **[Development Environment Setup](../setup/development-setup.md)** - Complete backend development environment including database setup

---

**Status**: ✅ **PRODUCTION DATABASE MIGRATION GUIDE**
**Last Updated**: 2025-06-29
**Scope**: Alembic Migrations, SQLAlchemy, PostgreSQL, Production Deployment, Migration Troubleshooting
**Technology Stack**: Alembic, SQLAlchemy, PostgreSQL, Docker, FastAPI

---

*This database migrations guide provides comprehensive procedures for safe and reliable database schema evolution, ensuring consistent development practices and robust production deployment strategies across all Spacewalker backend services.*
