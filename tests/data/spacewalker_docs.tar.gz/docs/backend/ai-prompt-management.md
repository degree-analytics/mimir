# AI Prompt Management System

## Purpose
Comprehensive documentation for managing AI prompt templates including versioning, multi-tenant customization, A/B testing frameworks, and optimization workflows. Essential reference for maintaining effective AI prompts across different tenants and use cases.

## When to Use This
- Managing and versioning AI prompt templates
- Customizing prompts for different tenant requirements
- Implementing A/B testing for prompt optimization
- Troubleshooting AI response quality issues
- Optimizing prompts for cost and performance
- Keywords: prompt management, template versioning, A/B testing, multi-tenant, AI optimization

**Version:** 1.0
**Date:** 2025-07-10
**Status:** Current - AI Prompt Management Technical Reference

---

## 🚀 Quick Start

### Basic Prompt Template Structure
```python
# Standard prompt template components
{
    "introduction": "You are an AI assistant specialized in room analysis...",
    "instructions": "Analyze the provided room image and extract the following information...",
    "json_format": "Return your response in the following JSON format: {...}",
    "reminder": "Ensure all confidence scores are between 0 and 1."
}
```

### Creating a New Prompt Template
```python
from spacecargo.models.prompt_models import PromptTemplate

def create_prompt_template(tenant_id: int, name: str, user_email: str):
    template = PromptTemplate(
        tenant_id=tenant_id,
        name=name,
        version=1,
        introduction="You are an AI assistant specialized in facility analysis...",
        instructions="Analyze this room image and identify FICM codes, furniture, and attributes...",
        json_format='{"room_type": "string", "ficm_code": "string", "confidence": 0.95, ...}',
        reminder="Be precise with confidence scores and FICM code selection.",
        created_by=user_email,
        is_active=True
    )

    db.add(template)
    db.commit()
    return template
```

### Activating a Template
```python
def activate_prompt_template(template_id: int, tenant_id: int):
    # Deactivate current active template
    current_active = db.query(PromptTemplate).filter(
        PromptTemplate.tenant_id == tenant_id,
        PromptTemplate.is_active == True
    ).first()

    if current_active:
        current_active.is_active = False

    # Activate new template
    new_template = db.query(PromptTemplate).get(template_id)
    new_template.is_active = True

    db.commit()

    # Clear cache to force reload
    clear_prompt_cache(tenant_id)
```

---

## 🏗️ Prompt Template Architecture

### Database Schema

#### Core Tables
```mermaid
erDiagram
    PROMPT_TEMPLATE ||--o{ PROMPT_TEMPLATE_HISTORY : "has history"
    PROMPT_TEMPLATE ||--o{ PROMPT_CACHE : "generates cache"
    TENANT ||--o{ PROMPT_TEMPLATE : "owns"

    PROMPT_TEMPLATE {
        int id PK
        int tenant_id FK
        string name
        int version
        text introduction
        text instructions
        text json_format
        text reminder
        string created_by
        timestamp created_at
        boolean is_active
        int parent_version_id FK
    }

    PROMPT_TEMPLATE_HISTORY {
        int id PK
        int template_id FK
        int version
        text introduction
        text instructions
        text json_format
        text reminder
        string changed_by
        timestamp changed_at
        text change_summary
    }

    PROMPT_CACHE {
        int id PK
        int template_id FK
        int tenant_id FK
        text full_prompt
        text ficm_section
        text attributes_section
        text attributes_json
        timestamp generated_at
        boolean is_valid
        int ficm_codes_count
        int attributes_count
    }
```

### Template Components

#### 1. Introduction Section
```python
def generate_introduction(tenant_config: dict) -> str:
    """Generate tenant-specific introduction"""

    base_intro = """You are an AI assistant specialized in facility management and room analysis for educational institutions."""

    if tenant_config.get('institution_type') == 'university':
        return base_intro + " You are analyzing university facilities including classrooms, labs, and administrative spaces."
    elif tenant_config.get('institution_type') == 'k12':
        return base_intro + " You are analyzing K-12 school facilities including classrooms, gymnasiums, and cafeterias."

    return base_intro
```

#### 2. Instructions Section
```python
def generate_instructions(analysis_type: str, tenant_requirements: dict) -> str:
    """Generate detailed analysis instructions"""

    base_instructions = """
    Analyze the provided room image and extract the following information:
    1. Room type and primary function
    2. FICM (Facilities Inventory and Classification Manual) code
    3. Room capacity (number of occupants the space can accommodate)
    4. Square footage estimation
    5. Furniture inventory with counts
    6. Equipment and technology present
    7. Room attributes and characteristics
    """

    if analysis_type == "detailed":
        detailed_additions = """
    8. Detailed condition assessment
    9. Accessibility features present
    10. Safety equipment and features
    11. Lighting and HVAC observations
    """
        base_instructions += detailed_additions

    # Add tenant-specific requirements
    if tenant_requirements.get('include_ada_compliance'):
        base_instructions += "\n12. ADA compliance features and accessibility"

    if tenant_requirements.get('include_sustainability'):
        base_instructions += "\n13. Sustainability features and energy efficiency indicators"

    return base_instructions
```

#### 3. JSON Format Specification
```python
def generate_json_format(tenant_attributes: List[dict]) -> str:
    """Generate JSON format based on tenant-specific attributes"""

    base_format = {
        "room_type": "string - Human readable room type",
        "ficm_code": "string - FICM classification code",
        "confidence": "number - Overall confidence (0-1)",
        "room_description": "string - Detailed room description",
        "capacity": "integer - Number of occupants",
        "square_footage": "integer - Estimated square footage",
        "furniture": {
            "chairs": {"count": "integer", "confidence": "number"},
            "desks": {"count": "integer", "confidence": "number"},
            "tables": {"count": "integer", "confidence": "number"}
        },
        "equipment": [
            {"name": "string", "confidence": "number"}
        ]
    }

    # Add tenant-specific attributes
    attributes_section = {}
    for attr in tenant_attributes:
        attr_name = attr['name'].lower().replace(' ', '_')
        attributes_section[attr_name] = {
            "value": f"{attr['data_type']} - {attr['description']}",
            "confidence": "number"
        }

    base_format["attributes"] = attributes_section

    return json.dumps(base_format, indent=2)
```

---

## 🎯 Template Versioning System

### Version Control Workflow

#### Creating New Versions
```python
class PromptVersionManager:
    def __init__(self, db: Session):
        self.db = db

    def create_new_version(self, base_template_id: int, changes: dict, user_email: str) -> PromptTemplate:
        """Create a new version based on existing template"""

        # Get base template
        base_template = self.db.query(PromptTemplate).get(base_template_id)
        if not base_template:
            raise ValueError(f"Base template {base_template_id} not found")

        # Create new version
        new_version = PromptTemplate(
            tenant_id=base_template.tenant_id,
            name=base_template.name,
            version=base_template.version + 1,
            introduction=changes.get('introduction', base_template.introduction),
            instructions=changes.get('instructions', base_template.instructions),
            json_format=changes.get('json_format', base_template.json_format),
            reminder=changes.get('reminder', base_template.reminder),
            created_by=user_email,
            is_active=False,  # New versions start inactive
            parent_version_id=base_template_id
        )

        self.db.add(new_version)
        self.db.flush()

        # Record change history
        self.record_version_history(new_version, changes, user_email)

        self.db.commit()
        return new_version

    def record_version_history(self, template: PromptTemplate, changes: dict, user_email: str):
        """Record detailed change history"""

        change_summary = self.generate_change_summary(changes)

        history = PromptTemplateHistory(
            template_id=template.id,
            version=template.version,
            introduction=template.introduction,
            instructions=template.instructions,
            json_format=template.json_format,
            reminder=template.reminder,
            changed_by=user_email,
            change_summary=change_summary
        )

        self.db.add(history)

    def generate_change_summary(self, changes: dict) -> str:
        """Generate human-readable change summary"""

        summary_parts = []

        if 'introduction' in changes:
            summary_parts.append("Updated introduction section")

        if 'instructions' in changes:
            summary_parts.append("Modified analysis instructions")

        if 'json_format' in changes:
            summary_parts.append("Updated JSON response format")

        if 'reminder' in changes:
            summary_parts.append("Changed reminder section")

        return "; ".join(summary_parts)
```

#### Version Comparison
```python
def compare_template_versions(version_a_id: int, version_b_id: int) -> dict:
    """Compare two template versions and highlight differences"""

    version_a = db.query(PromptTemplate).get(version_a_id)
    version_b = db.query(PromptTemplate).get(version_b_id)

    differences = {}

    for field in ['introduction', 'instructions', 'json_format', 'reminder']:
        value_a = getattr(version_a, field)
        value_b = getattr(version_b, field)

        if value_a != value_b:
            differences[field] = {
                'version_a': value_a,
                'version_b': value_b,
                'diff': generate_text_diff(value_a, value_b)
            }

    return {
        'version_a': {
            'id': version_a.id,
            'version': version_a.version,
            'created_at': version_a.created_at,
            'created_by': version_a.created_by
        },
        'version_b': {
            'id': version_b.id,
            'version': version_b.version,
            'created_at': version_b.created_at,
            'created_by': version_b.created_by
        },
        'differences': differences
    }

def generate_text_diff(text_a: str, text_b: str) -> List[dict]:
    """Generate line-by-line diff between two text blocks"""
    import difflib

    lines_a = text_a.splitlines()
    lines_b = text_b.splitlines()

    diff = list(difflib.unified_diff(lines_a, lines_b, lineterm=''))

    return [{
        'line': line,
        'type': 'added' if line.startswith('+') else 'removed' if line.startswith('-') else 'context'
    } for line in diff]
```

### Rollback Capabilities

```python
def rollback_to_version(tenant_id: int, target_version: int, user_email: str) -> PromptTemplate:
    """Rollback to a previous template version"""

    # Find target version
    target_template = db.query(PromptTemplate).filter(
        PromptTemplate.tenant_id == tenant_id,
        PromptTemplate.version == target_version
    ).first()

    if not target_template:
        raise ValueError(f"Version {target_version} not found for tenant {tenant_id}")

    # Get current active template
    current_template = db.query(PromptTemplate).filter(
        PromptTemplate.tenant_id == tenant_id,
        PromptTemplate.is_active == True
    ).first()

    # Create new version based on target (rollback)
    rollback_template = PromptTemplate(
        tenant_id=tenant_id,
        name=target_template.name,
        version=(current_template.version + 1) if current_template else 1,
        introduction=target_template.introduction,
        instructions=target_template.instructions,
        json_format=target_template.json_format,
        reminder=target_template.reminder,
        created_by=user_email,
        is_active=False,
        parent_version_id=target_template.id
    )

    db.add(rollback_template)
    db.flush()

    # Record rollback in history
    history = PromptTemplateHistory(
        template_id=rollback_template.id,
        version=rollback_template.version,
        introduction=rollback_template.introduction,
        instructions=rollback_template.instructions,
        json_format=rollback_template.json_format,
        reminder=rollback_template.reminder,
        changed_by=user_email,
        change_summary=f"Rollback to version {target_version}"
    )

    db.add(history)
    db.commit()

    return rollback_template
```

---

## 🧪 A/B Testing Framework

### Test Configuration

#### Setting Up A/B Tests
```python
from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional

class ABTestStatus(Enum):
    DRAFT = "draft"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"

@dataclass
class ABTestConfig:
    test_id: str
    name: str
    description: str
    tenant_id: int
    control_template_id: int
    variant_template_ids: List[int]
    traffic_split: Dict[str, float]  # {"control": 0.5, "variant_a": 0.3, "variant_b": 0.2}
    success_metrics: List[str]
    duration_days: int
    minimum_sample_size: int
    status: ABTestStatus

class ABTestManager:
    def __init__(self, db: Session):
        self.db = db

    def create_ab_test(self, config: ABTestConfig) -> str:
        """Create new A/B test configuration"""

        # Validate traffic split sums to 1.0
        if abs(sum(config.traffic_split.values()) - 1.0) > 0.001:
            raise ValueError("Traffic split must sum to 100%")

        # Validate templates exist
        all_template_ids = [config.control_template_id] + config.variant_template_ids
        for template_id in all_template_ids:
            template = self.db.query(PromptTemplate).get(template_id)
            if not template or template.tenant_id != config.tenant_id:
                raise ValueError(f"Template {template_id} not found or not owned by tenant")

        # Store test configuration
        test_record = {
            'test_id': config.test_id,
            'config': config.__dict__,
            'created_at': datetime.utcnow(),
            'status': ABTestStatus.DRAFT.value
        }

        # Store in database or cache
        self.store_ab_test_config(config.test_id, test_record)

        return config.test_id

    def start_ab_test(self, test_id: str) -> bool:
        """Start running an A/B test"""

        config = self.get_ab_test_config(test_id)
        if not config:
            return False

        # Update status to running
        config['status'] = ABTestStatus.RUNNING.value
        config['started_at'] = datetime.utcnow()

        self.store_ab_test_config(test_id, config)

        logger.info(f"Started A/B test {test_id}")
        return True
```

#### Template Selection Logic
```python
import hashlib
import random

def select_template_for_request(tenant_id: int, user_id: str = None, session_id: str = None) -> int:
    """Select appropriate template based on A/B test configuration"""

    # Check if tenant has active A/B tests
    active_tests = get_active_ab_tests(tenant_id)

    if not active_tests:
        # Return default active template
        return get_active_template_id(tenant_id)

    # Use consistent assignment based on user_id or session_id
    assignment_key = user_id or session_id or str(random.random())
    test_assignment = assign_to_test_group(active_tests[0], assignment_key)

    return get_template_for_assignment(test_assignment)

def assign_to_test_group(test_config: dict, assignment_key: str) -> str:
    """Consistently assign users to test groups"""

    # Generate consistent hash
    hash_value = int(hashlib.md5(assignment_key.encode()).hexdigest(), 16)
    assignment_ratio = (hash_value % 10000) / 10000.0

    # Assign to group based on traffic split
    cumulative = 0.0
    traffic_split = test_config['config']['traffic_split']

    for group, split in traffic_split.items():
        cumulative += split
        if assignment_ratio <= cumulative:
            return group

    # Fallback to control
    return 'control'

def get_template_for_assignment(assignment: str) -> int:
    """Get template ID for test group assignment"""

    if assignment == 'control':
        return test_config['config']['control_template_id']

    # Handle variants
    variant_index = int(assignment.split('_')[-1]) if '_' in assignment else 0
    variant_templates = test_config['config']['variant_template_ids']

    if variant_index < len(variant_templates):
        return variant_templates[variant_index]

    # Fallback to control
    return test_config['config']['control_template_id']
```

### Metrics Collection

#### Test Performance Tracking
```python
from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class ABTestMetrics:
    test_id: str
    group: str
    request_count: int
    success_rate: float
    avg_confidence: float
    avg_processing_time: float
    cost_per_request: float
    user_satisfaction: float

class ABTestMetricsCollector:
    def __init__(self, db: Session):
        self.db = db

    def record_test_result(self, test_id: str, group: str, request_data: dict, response_data: dict):
        """Record individual test result"""

        metrics = {
            'test_id': test_id,
            'group': group,
            'request_timestamp': datetime.utcnow(),
            'processing_time_ms': response_data.get('processing_time_ms', 0),
            'confidence_score': response_data.get('confidence', 0),
            'cost': response_data.get('cost_analysis', {}).get('total_cost', 0),
            'success': response_data.get('error') is None,
            'user_id': request_data.get('user_id'),
            'session_id': request_data.get('session_id')
        }

        # Store metrics for analysis
        self.store_test_metrics(metrics)

    def calculate_group_metrics(self, test_id: str, group: str) -> ABTestMetrics:
        """Calculate aggregated metrics for test group"""

        raw_metrics = self.get_raw_metrics(test_id, group)

        if not raw_metrics:
            return ABTestMetrics(
                test_id=test_id,
                group=group,
                request_count=0,
                success_rate=0.0,
                avg_confidence=0.0,
                avg_processing_time=0.0,
                cost_per_request=0.0,
                user_satisfaction=0.0
            )

        return ABTestMetrics(
            test_id=test_id,
            group=group,
            request_count=len(raw_metrics),
            success_rate=sum(1 for m in raw_metrics if m['success']) / len(raw_metrics),
            avg_confidence=sum(m['confidence_score'] for m in raw_metrics) / len(raw_metrics),
            avg_processing_time=sum(m['processing_time_ms'] for m in raw_metrics) / len(raw_metrics),
            cost_per_request=sum(m['cost'] for m in raw_metrics) / len(raw_metrics),
            user_satisfaction=self.calculate_user_satisfaction(test_id, group)
        )

    def calculate_statistical_significance(self, control_metrics: ABTestMetrics,
                                         variant_metrics: ABTestMetrics) -> dict:
        """Calculate statistical significance of test results"""
        from scipy import stats

        # Get raw data for statistical tests
        control_data = self.get_raw_metrics(control_metrics.test_id, control_metrics.group)
        variant_data = self.get_raw_metrics(variant_metrics.test_id, variant_metrics.group)

        results = {}

        # Confidence score comparison
        control_confidence = [m['confidence_score'] for m in control_data]
        variant_confidence = [m['confidence_score'] for m in variant_data]

        t_stat, p_value = stats.ttest_ind(control_confidence, variant_confidence)
        results['confidence_comparison'] = {
            't_statistic': t_stat,
            'p_value': p_value,
            'significant': p_value < 0.05,
            'control_mean': control_metrics.avg_confidence,
            'variant_mean': variant_metrics.avg_confidence
        }

        # Processing time comparison
        control_times = [m['processing_time_ms'] for m in control_data]
        variant_times = [m['processing_time_ms'] for m in variant_data]

        t_stat, p_value = stats.ttest_ind(control_times, variant_times)
        results['processing_time_comparison'] = {
            't_statistic': t_stat,
            'p_value': p_value,
            'significant': p_value < 0.05,
            'control_mean': control_metrics.avg_processing_time,
            'variant_mean': variant_metrics.avg_processing_time
        }

        return results
```

### Test Analysis & Reporting

#### Automated Test Evaluation
```python
def evaluate_ab_test(test_id: str) -> dict:
    """Evaluate A/B test results and provide recommendations"""

    test_config = get_ab_test_config(test_id)
    if not test_config:
        raise ValueError(f"Test {test_id} not found")

    # Collect metrics for all groups
    control_metrics = metrics_collector.calculate_group_metrics(test_id, 'control')

    variant_results = {}
    for i, variant_id in enumerate(test_config['config']['variant_template_ids']):
        variant_group = f'variant_{chr(97 + i)}'  # variant_a, variant_b, etc.
        variant_metrics = metrics_collector.calculate_group_metrics(test_id, variant_group)

        # Calculate statistical significance
        significance = metrics_collector.calculate_statistical_significance(
            control_metrics, variant_metrics
        )

        variant_results[variant_group] = {
            'metrics': variant_metrics,
            'significance': significance,
            'recommendation': generate_recommendation(control_metrics, variant_metrics, significance)
        }

    # Overall test evaluation
    evaluation = {
        'test_id': test_id,
        'test_config': test_config,
        'control_metrics': control_metrics,
        'variant_results': variant_results,
        'overall_recommendation': generate_overall_recommendation(control_metrics, variant_results),
        'evaluation_timestamp': datetime.utcnow()
    }

    return evaluation

def generate_recommendation(control: ABTestMetrics, variant: ABTestMetrics, significance: dict) -> str:
    """Generate actionable recommendation based on test results"""

    recommendations = []

    # Confidence improvement
    if (significance['confidence_comparison']['significant'] and
        variant.avg_confidence > control.avg_confidence):
        improvement = ((variant.avg_confidence - control.avg_confidence) / control.avg_confidence) * 100
        recommendations.append(f"✅ Significant confidence improvement: +{improvement:.1f}%")

    # Processing time analysis
    if (significance['processing_time_comparison']['significant'] and
        variant.avg_processing_time < control.avg_processing_time):
        improvement = ((control.avg_processing_time - variant.avg_processing_time) / control.avg_processing_time) * 100
        recommendations.append(f"⚡ Significant speed improvement: +{improvement:.1f}%")

    # Cost analysis
    if variant.cost_per_request < control.cost_per_request:
        savings = ((control.cost_per_request - variant.cost_per_request) / control.cost_per_request) * 100
        recommendations.append(f"💰 Cost reduction: -{savings:.1f}%")

    # Overall recommendation
    if recommendations:
        return "RECOMMEND VARIANT: " + "; ".join(recommendations)
    else:
        return "KEEP CONTROL: No significant improvements detected"
```

---

## 🔧 Prompt Optimization Techniques

### Performance-Based Optimization

#### Response Quality Analysis
```python
def analyze_prompt_performance(template_id: int, days: int = 7) -> dict:
    """Analyze prompt performance over specified period"""

    # Collect recent responses
    responses = get_recent_responses(template_id, days)

    if not responses:
        return {'error': 'No recent data available'}

    analysis = {
        'total_requests': len(responses),
        'avg_confidence': sum(r['confidence'] for r in responses) / len(responses),
        'confidence_distribution': calculate_confidence_distribution(responses),
        'common_low_confidence_patterns': identify_low_confidence_patterns(responses),
        'format_compliance_rate': calculate_format_compliance(responses),
        'cost_efficiency': calculate_cost_efficiency(responses),
        'processing_time_stats': calculate_processing_time_stats(responses)
    }

    # Generate optimization suggestions
    analysis['optimization_suggestions'] = generate_optimization_suggestions(analysis)

    return analysis

def identify_low_confidence_patterns(responses: List[dict]) -> List[dict]:
    """Identify patterns in low-confidence responses"""

    low_confidence_responses = [r for r in responses if r['confidence'] < 0.7]

    patterns = []

    # Analyze by room type
    room_type_issues = {}
    for response in low_confidence_responses:
        room_type = response.get('room_type', 'unknown')
        if room_type not in room_type_issues:
            room_type_issues[room_type] = 0
        room_type_issues[room_type] += 1

    # Identify problematic room types
    for room_type, count in room_type_issues.items():
        if count > len(low_confidence_responses) * 0.2:  # >20% of low confidence
            patterns.append({
                'type': 'room_type',
                'value': room_type,
                'frequency': count,
                'suggestion': f'Consider adding more specific instructions for {room_type} analysis'
            })

    return patterns

def generate_optimization_suggestions(analysis: dict) -> List[str]:
    """Generate specific optimization suggestions"""

    suggestions = []

    # Confidence-based suggestions
    if analysis['avg_confidence'] < 0.8:
        suggestions.append("Consider adding more specific visual cues in instructions")
        suggestions.append("Review and update FICM code descriptions for clarity")

    # Format compliance suggestions
    if analysis['format_compliance_rate'] < 0.95:
        suggestions.append("Strengthen JSON format requirements in prompt")
        suggestions.append("Add examples of correct response format")

    # Cost efficiency suggestions
    if analysis['cost_efficiency']['cost_per_token'] > 0.001:
        suggestions.append("Consider prompt length optimization to reduce input tokens")
        suggestions.append("Review if all instructions are necessary")

    # Processing time suggestions
    if analysis['processing_time_stats']['avg_time'] > 3000:  # >3 seconds
        suggestions.append("Simplify complex instructions that may confuse the AI")
        suggestions.append("Consider using a faster model for standard cases")

    return suggestions
```

### Token Optimization

#### Prompt Length Analysis
```python
def optimize_prompt_length(template_id: int) -> dict:
    """Analyze and optimize prompt length for cost efficiency"""

    template = db.query(PromptTemplate).get(template_id)
    if not template:
        raise ValueError(f"Template {template_id} not found")

    # Current prompt analysis
    current_prompt = compile_full_prompt(template)
    current_tokens = estimate_token_count(current_prompt)

    # Analyze each section
    sections = {
        'introduction': template.introduction,
        'instructions': template.instructions,
        'json_format': template.json_format,
        'reminder': template.reminder
    }

    section_analysis = {}
    for section_name, content in sections.items():
        tokens = estimate_token_count(content)
        section_analysis[section_name] = {
            'content': content,
            'tokens': tokens,
            'percentage': (tokens / current_tokens) * 100,
            'optimization_potential': analyze_section_for_optimization(content)
        }

    # Generate optimized version
    optimized_sections = {}
    total_saved_tokens = 0

    for section_name, analysis in section_analysis.items():
        if analysis['optimization_potential']['can_optimize']:
            optimized_content = optimize_section_content(analysis['content'])
            saved_tokens = analysis['tokens'] - estimate_token_count(optimized_content)

            optimized_sections[section_name] = {
                'original': analysis['content'],
                'optimized': optimized_content,
                'tokens_saved': saved_tokens,
                'changes': analysis['optimization_potential']['suggestions']
            }

            total_saved_tokens += saved_tokens

    return {
        'current_analysis': {
            'total_tokens': current_tokens,
            'sections': section_analysis
        },
        'optimization_results': {
            'optimized_sections': optimized_sections,
            'total_tokens_saved': total_saved_tokens,
            'cost_savings_per_request': total_saved_tokens * 0.000015,
            'percentage_reduction': (total_saved_tokens / current_tokens) * 100
        }
    }

def analyze_section_for_optimization(content: str) -> dict:
    """Analyze content section for optimization opportunities"""

    optimization_opportunities = []
    can_optimize = False

    # Check for verbose phrases
    verbose_patterns = [
        ("Please carefully", "Please"),
        ("Make sure to", ""),
        ("It is important that you", "You must"),
        ("as much detail as possible", "detailed"),
        ("be very specific", "be specific"),
        ("in order to", "to")
    ]

    for verbose, concise in verbose_patterns:
        if verbose.lower() in content.lower():
            optimization_opportunities.append(f"Replace '{verbose}' with '{concise}'")
            can_optimize = True

    # Check for repetitive instructions
    sentences = content.split('.')
    unique_sentences = set(s.strip().lower() for s in sentences if s.strip())

    if len(sentences) - len(unique_sentences) > 2:
        optimization_opportunities.append("Remove duplicate or redundant instructions")
        can_optimize = True

    # Check for overly long sentences
    long_sentences = [s for s in sentences if len(s.split()) > 25]
    if long_sentences:
        optimization_opportunities.append("Break down complex sentences")
        can_optimize = True

    return {
        'can_optimize': can_optimize,
        'suggestions': optimization_opportunities,
        'original_length': len(content),
        'estimated_tokens': estimate_token_count(content)
    }
```

### Multi-Tenant Customization

#### Tenant-Specific Optimization
```python
def customize_prompt_for_tenant(base_template_id: int, tenant_id: int, customizations: dict) -> PromptTemplate:
    """Create tenant-specific prompt customization"""

    base_template = db.query(PromptTemplate).get(base_template_id)
    tenant_config = get_tenant_configuration(tenant_id)

    # Apply tenant-specific customizations
    customized_introduction = customize_introduction(
        base_template.introduction,
        tenant_config,
        customizations.get('institution_focus')
    )

    customized_instructions = customize_instructions(
        base_template.instructions,
        tenant_config['specific_requirements'],
        customizations.get('analysis_focus', [])
    )

    customized_json_format = customize_json_format(
        base_template.json_format,
        tenant_config['custom_attributes']
    )

    # Create new customized template
    customized_template = PromptTemplate(
        tenant_id=tenant_id,
        name=f"{base_template.name} - {tenant_config['name']} Custom",
        version=1,
        introduction=customized_introduction,
        instructions=customized_instructions,
        json_format=customized_json_format,
        reminder=base_template.reminder,
        created_by=customizations.get('created_by', 'system'),
        is_active=False
    )

    db.add(customized_template)
    db.commit()

    return customized_template

def customize_introduction(base_intro: str, tenant_config: dict, focus: str = None) -> str:
    """Customize introduction for specific tenant needs"""

    customized = base_intro

    # Add institution-specific context
    if tenant_config.get('institution_type') == 'medical':
        customized += " You are specifically analyzing medical facility spaces including patient rooms, treatment areas, and clinical laboratories."
    elif tenant_config.get('institution_type') == 'research':
        customized += " You are analyzing research facility spaces including laboratories, clean rooms, and specialized research equipment areas."

    # Add focus area if specified
    if focus:
        focus_contexts = {
            'sustainability': " Pay special attention to sustainability features and energy-efficient elements.",
            'accessibility': " Focus particularly on accessibility features and ADA compliance elements.",
            'technology': " Emphasize technology infrastructure and digital learning capabilities."
        }

        if focus in focus_contexts:
            customized += focus_contexts[focus]

    return customized
```

---

## 💾 Caching & Performance

### Prompt Compilation Caching

#### Efficient Prompt Assembly
```python
class PromptCompilationEngine:
    def __init__(self, cache_manager):
        self.cache = cache_manager
        self.compilation_metrics = {
            'cache_hits': 0,
            'cache_misses': 0,
            'compilation_time_ms': []
        }

    def compile_prompt_for_tenant(self, tenant_id: int, template_id: int = None) -> str:
        """Compile full prompt with caching"""

        start_time = time.time()

        # Check cache first
        cache_key = f"compiled_prompt:{tenant_id}:{template_id or 'active'}"
        cached_prompt = self.cache.get(cache_key)

        if cached_prompt:
            self.compilation_metrics['cache_hits'] += 1
            return cached_prompt

        self.compilation_metrics['cache_misses'] += 1

        # Compile prompt from components
        template = self.get_template(tenant_id, template_id)
        ficm_data = self.get_tenant_ficm_data(tenant_id)
        attributes_data = self.get_tenant_attributes_data(tenant_id)

        compiled_prompt = self.assemble_prompt_components(
            template, ficm_data, attributes_data
        )

        # Cache the compiled prompt
        cache_ttl = 3600  # 1 hour
        self.cache.set(cache_key, compiled_prompt, ttl=cache_ttl)

        # Record compilation time
        compilation_time = (time.time() - start_time) * 1000
        self.compilation_metrics['compilation_time_ms'].append(compilation_time)

        return compiled_prompt

    def assemble_prompt_components(self, template: PromptTemplate,
                                 ficm_data: List[dict],
                                 attributes_data: List[dict]) -> str:
        """Assemble final prompt from all components"""

        # Base template sections
        prompt_parts = [
            template.introduction,
            "",  # Empty line
            template.instructions,
            "",
            "Available FICM Codes:",
            self.format_ficm_codes(ficm_data),
            "",
            "Available Attributes:",
            self.format_attributes(attributes_data),
            "",
            "Response Format:",
            template.json_format,
            "",
            template.reminder
        ]

        return "\n".join(prompt_parts)

    def format_ficm_codes(self, ficm_data: List[dict]) -> str:
        """Format FICM codes for prompt inclusion"""

        formatted_codes = []
        for ficm in ficm_data:
            formatted_codes.append(
                f"- {ficm['code']}: {ficm['description']} "
                f"(Category: {ficm['category']})"
            )

        return "\n".join(formatted_codes)

    def format_attributes(self, attributes_data: List[dict]) -> str:
        """Format attributes for prompt inclusion"""

        formatted_attrs = []
        for attr in attributes_data:
            formatted_attrs.append(
                f"- {attr['name']} ({attr['data_type']}): {attr['description']}"
            )

        return "\n".join(formatted_attrs)
```

### Cache Invalidation Strategy

```python
class PromptCacheInvalidator:
    def __init__(self, cache_manager, db: Session):
        self.cache = cache_manager
        self.db = db

    def invalidate_tenant_cache(self, tenant_id: int, reason: str = None):
        """Invalidate all cached prompts for a tenant"""

        # Find all cached prompts for tenant
        cache_patterns = [
            f"compiled_prompt:{tenant_id}:*",
            f"ficm_data:{tenant_id}",
            f"attributes_data:{tenant_id}"
        ]

        invalidated_keys = []
        for pattern in cache_patterns:
            keys = self.cache.keys(pattern)
            for key in keys:
                self.cache.delete(key)
                invalidated_keys.append(key)

        logger.info(
            f"Invalidated prompt cache for tenant {tenant_id}",
            extra={
                'tenant_id': tenant_id,
                'reason': reason,
                'invalidated_keys': len(invalidated_keys)
            }
        )

    def invalidate_template_cache(self, template_id: int):
        """Invalidate cache for specific template"""

        template = self.db.query(PromptTemplate).get(template_id)
        if template:
            self.invalidate_tenant_cache(template.tenant_id, f"template {template_id} updated")

    def setup_auto_invalidation(self):
        """Set up automatic cache invalidation triggers"""

        # This would typically be set up as database triggers or event listeners
        # For example, when PromptTemplate is updated, automatically invalidate cache

        @event.listens_for(PromptTemplate, 'after_update')
        def invalidate_on_template_update(mapper, connection, target):
            self.invalidate_template_cache(target.id)

        @event.listens_for(FICMDesignType, 'after_update')
        def invalidate_on_ficm_update(mapper, connection, target):
            self.invalidate_tenant_cache(target.tenant_id, "FICM data updated")

        @event.listens_for(AttributeDefinition, 'after_update')
        def invalidate_on_attribute_update(mapper, connection, target):
            self.invalidate_tenant_cache(target.tenant_id, "Attribute definitions updated")
```

---

## 🚨 Troubleshooting

### Common Issues

#### Low Confidence Scores
**Symptoms**: AI responses consistently below 0.8 confidence
**Diagnosis**:
```python
def diagnose_low_confidence(tenant_id: int, days: int = 7) -> dict:
    """Diagnose causes of low confidence scores"""

    recent_responses = get_tenant_responses(tenant_id, days)
    low_confidence = [r for r in recent_responses if r['confidence'] < 0.8]

    diagnosis = {
        'total_responses': len(recent_responses),
        'low_confidence_count': len(low_confidence),
        'low_confidence_rate': len(low_confidence) / len(recent_responses) if recent_responses else 0,
        'avg_confidence': sum(r['confidence'] for r in recent_responses) / len(recent_responses) if recent_responses else 0
    }

    # Analyze patterns
    diagnosis['patterns'] = analyze_confidence_patterns(low_confidence)
    diagnosis['recommendations'] = generate_confidence_recommendations(diagnosis['patterns'])

    return diagnosis
```

**Solutions**:
- Add more specific visual cues in instructions
- Include examples of expected responses
- Review FICM code descriptions for clarity
- Consider prompt optimization for the specific room types

#### Inconsistent Response Formats
**Symptoms**: Frontend errors parsing AI responses
**Diagnosis**: Check response standardization compliance
**Solutions**:
- Update JSON format specifications
- Add format validation examples
- Implement response normalization

#### High Processing Costs
**Symptoms**: Cost per request >$0.10
**Diagnosis**: Analyze token usage patterns
**Solutions**:
- Optimize prompt length
- Use appropriate model selection
- Implement better caching

### Debug Tools

```python
def debug_prompt_performance(template_id: int, sample_image: bytes = None) -> dict:
    """Comprehensive prompt performance debugging"""

    template = db.query(PromptTemplate).get(template_id)

    debug_info = {
        'template_info': {
            'id': template.id,
            'version': template.version,
            'tenant_id': template.tenant_id,
            'created_at': template.created_at,
            'is_active': template.is_active
        },
        'prompt_analysis': analyze_prompt_structure(template),
        'performance_metrics': get_template_performance_metrics(template_id),
        'recent_issues': get_recent_template_issues(template_id)
    }

    if sample_image:
        debug_info['test_analysis'] = test_prompt_with_sample(template, sample_image)

    return debug_info
```

---

## 📚 Related Documentation

### Architecture References
- **[AI Analysis API](./ai-analysis-api.md)** - API endpoints and integration patterns
- **[AI Performance Monitoring](./ai-performance.md)** - Performance optimization and monitoring
- **[Backend Architecture](../architecture/README.md)** - Overall system architecture

### Testing & Validation
- **[AI Testing Tools](../admin/ai-testing-tools.md)** - Admin dashboard testing interfaces
- **[Testing Guide](../workflows/testing-guide.md)** - General testing strategies

### Operational Procedures
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment procedures
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General troubleshooting guidance

---

**Status**: ✅ Production Ready - Comprehensive prompt management system with versioning, A/B testing, optimization tools, and performance monitoring
