# AI Image Analysis API

## Purpose
Comprehensive documentation for AI-powered image analysis endpoints including Google Gemini integration, multi-model support, cost tracking, and response standardization. Primary reference for implementing room survey analysis workflows.

## When to Use This
- Implementing AI image analysis endpoints in surveys
- Understanding multi-model selection and cost implications
- Integrating Google Gemini API for room classification
- Handling AI response standardization and validation
- Troubleshooting AI analysis workflows and performance issues
- Keywords: AI analysis, Gemini API, image classification, FICM codes, room analysis

**Version:** 1.0
**Date:** 2025-07-10
**Status:** Current - AI API Technical Reference

---

## 🚀 Quick Start

### Basic Image Analysis
```python
# POST /api/ai/analyze-image
{
    "image_base64": "data:image/jpeg;base64,/9j/4AAQSkZJRgABA...",
    "model": "flash_lite",
    "analysis_type": "detailed"
}
```

### Response Format
```json
{
    "room_type": "Conference Room",
    "ficm_code": "350-MTG",
    "confidence": 0.95,
    "capacity": 12,
    "square_footage": 400,
    "furniture": {
        "chairs": {"count": 12, "confidence": 0.95},
        "tables": {"count": 1, "confidence": 1.0}
    },
    "equipment": [
        {"name": "Projector", "confidence": 0.90},
        {"name": "TV", "confidence": 0.95}
    ],
    "cost_analysis": {
        "total_cost": 0.0675,
        "input_tokens": 1500,
        "output_tokens": 300
    }
}
```

---

## 🔌 API Endpoints

### Image Analysis Endpoint

**POST** `/api/ai/analyze-image`

Analyzes room images using Google Gemini models to extract FICM codes, room attributes, and facility data.

#### Request Schema
```json
{
    "image_base64": "string (required)",
    "model": "string (optional, default: flash_lite)",
    "analysis_type": "string (optional, default: standard)",
    "include_raw_response": "boolean (optional, default: false)",
    "custom_prompt": "string (optional)"
}
```

#### Request Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `image_base64` | string | Yes | Base64-encoded image data with MIME type prefix |
| `model` | string | No | Gemini model selection: `flash_lite`, `flash`, `flash_8b` |
| `analysis_type` | string | No | Analysis depth: `standard`, `detailed`, `quick` |
| `include_raw_response` | boolean | No | Include raw Gemini API response for debugging |
| `custom_prompt` | string | No | Override default prompt template |

#### Supported Models

| Model | Code | Use Case | Cost | Performance |
|-------|------|----------|------|-------------|
| Gemini Flash Lite | `flash_lite` | Quick analysis, cost-efficient | $0.000015/token | Fast |
| Gemini Flash | `flash` | Standard analysis, balanced | $0.00015/token | Medium |
| Gemini Flash 8B | `flash_8b` | Detailed analysis, high accuracy | $0.0003/token | Slower |

#### Response Schema
```json
{
    "room_type": "string",
    "ficm_code": "string",
    "confidence": "number (0-1)",
    "room_description": "string",
    "capacity": "integer",
    "square_footage": "integer",
    "furniture": {
        "[item_type]": {
            "count": "integer",
            "confidence": "number (0-1)"
        }
    },
    "equipment": [
        {
            "name": "string",
            "confidence": "number (0-1)"
        }
    ],
    "attributes": {
        "[attribute_name]": {
            "value": "any",
            "confidence": "number (0-1)"
        }
    },
    "model_used": "string",
    "processing_time_ms": "integer",
    "token_usage": {
        "input_tokens": "integer",
        "output_tokens": "integer",
        "total_tokens": "integer"
    },
    "cost_analysis": {
        "input_cost": "number",
        "output_cost": "number",
        "total_cost": "number"
    }
}
```

---

## 🎯 Response Standardization

### Data Structure Standards

The AI API enforces consistent response formats to ensure reliable frontend processing:

#### Core Fields (Required)
- **`capacity`**: Simple integer, NOT nested object
- **`square_footage`**: Simple integer when present, NOT nested object
- **`furniture`**: Consistent nested structure with count and confidence
- **`equipment`**: Array of objects with name and confidence
- **`attributes`**: Flattened structure with value and confidence

#### Deprecated Formats (Avoided)
```json
// ❌ INCORRECT - Nested capacity
{"capacity": {"value": 4, "confidence": 0.9}}

// ✅ CORRECT - Simple integer
{"capacity": 4}

// ❌ INCORRECT - Inconsistent square footage
{"square_footage": null, "attributes": {"square_footage": {"value": 300}}}

// ✅ CORRECT - Single authoritative field
{"square_footage": 300}
```

### Response Normalization

The API automatically normalizes problematic response formats:

```python
def normalize_ai_response(raw_response: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize AI response to standard format"""
    normalized = raw_response.copy()

    # Fix capacity format
    if "capacity" in normalized:
        capacity_val = normalized["capacity"]
        if isinstance(capacity_val, dict) and "value" in capacity_val:
            normalized["capacity"] = capacity_val["value"]

    # Fix square footage consistency
    if "square_footage" in normalized and normalized["square_footage"] is None:
        attr_sqft = normalized.get("attributes", {}).get("square_footage", {})
        if isinstance(attr_sqft, dict) and "value" in attr_sqft:
            normalized["square_footage"] = attr_sqft["value"]

    # Remove redundant fields
    if "technology" in normalized:
        del normalized["technology"]  # Use equipment instead

    return normalized
```

---

## 💰 Cost Analysis & Optimization

### Token Usage Calculation

Each API call tracks token consumption for cost analysis:

```python
# Input tokens: Image + prompt text
input_tokens = base_image_tokens + prompt_text_tokens

# Output tokens: Generated response
output_tokens = response_text_tokens

# Cost calculation (Gemini Flash Lite rates)
input_cost = input_tokens * 0.000015  # $0.000015 per input token
output_cost = output_tokens * 0.00015  # $0.00015 per output token
total_cost = input_cost + output_cost
```

### Cost Optimization Strategies

1. **Model Selection**
   - Use `flash_lite` for quick classifications
   - Use `flash` for standard analysis
   - Reserve `flash_8b` for complex scenarios requiring high accuracy

2. **Image Optimization**
   - Resize images to optimal dimensions (1024x1024 max)
   - Use JPEG compression to reduce token count
   - Avoid sending multiple images when one suffices

3. **Prompt Optimization**
   - Use cached prompt templates to reduce input tokens
   - Remove unnecessary instructions from prompts
   - Leverage tenant-specific prompt customization

### Cost Monitoring

Track cost metrics across different dimensions:

```python
# Daily cost tracking
daily_costs = {
    "total_requests": 450,
    "total_cost": 12.35,
    "avg_cost_per_request": 0.027,
    "model_breakdown": {
        "flash_lite": {"requests": 300, "cost": 6.20},
        "flash": {"requests": 120, "cost": 4.80},
        "flash_8b": {"requests": 30, "cost": 1.35}
    }
}

# Tenant cost allocation
tenant_costs = {
    "tenant_1": {"requests": 200, "cost": 5.40},
    "tenant_2": {"requests": 150, "cost": 4.05},
    "tenant_3": {"requests": 100, "cost": 2.90}
}
```

---

## 🔒 Security & Authentication

### API Key Management

AI endpoints use AWS Secrets Manager for secure API key storage:

```python
# Secrets retrieval with fallback
secrets_service = SecretsService()
try:
    gemini_api_key = secrets_service.get_gemini_api_key()
except SecretsRetrievalError:
    # Fallback to environment variable
    gemini_api_key = os.getenv('GEMINI_API_KEY')
```

### Multi-Tenant Isolation

All AI analysis requests are automatically scoped to the authenticated user's tenant:

```python
# Tenant context automatically applied
current_tenant_id = get_current_tenant_id()
prompt_template = get_tenant_prompt_template(db, current_tenant_id)
ficm_codes = get_tenant_ficm_codes(db, current_tenant_id)
```

### Request Validation

Input validation ensures security and data integrity:

```python
# Image validation
if not image_base64.startswith('data:image/'):
    raise ValidationError("Invalid image format")

# Size limits
max_image_size = 10 * 1024 * 1024  # 10MB
if len(image_base64) > max_image_size:
    raise ValidationError("Image too large")

# Model validation
allowed_models = ["flash_lite", "flash", "flash_8b"]
if model not in allowed_models:
    raise ValidationError(f"Invalid model: {model}")
```

---

## 🧪 Testing & Validation

### Unit Testing

Test AI endpoints with mock responses:

```python
@pytest.fixture
def mock_gemini_response():
    return {
        "room_type": "Conference Room",
        "ficm_code": "350-MTG",
        "confidence": 0.95,
        "capacity": 12,
        "square_footage": 400
    }

def test_analyze_image_success(client, auth_headers, mock_gemini_response):
    response = client.post(
        "/api/ai/analyze-image",
        json={"image_base64": "data:image/jpeg;base64,test"},
        headers=auth_headers
    )
    assert response.status_code == 200
    assert response.json()["room_type"] == "Conference Room"
```

### Integration Testing

Test with actual Gemini API calls:

```python
def test_gemini_integration(client, auth_headers):
    """Test actual Gemini API integration"""
    test_image = create_test_image()
    image_base64 = image_to_base64(test_image)

    response = client.post(
        "/api/ai/analyze-image",
        json={"image_base64": image_base64, "model": "flash_lite"},
        headers=auth_headers
    )

    assert response.status_code == 200
    data = response.json()
    assert "cost_analysis" in data
    assert data["cost_analysis"]["total_cost"] > 0
```

### Response Validation

Ensure response format compliance:

```python
def validate_ai_response(response_data):
    """Validate AI response follows standard format"""
    required_fields = ["room_type", "ficm_code", "confidence"]
    for field in required_fields:
        assert field in response_data

    # Validate capacity is simple integer
    assert isinstance(response_data["capacity"], int)

    # Validate furniture structure
    if "furniture" in response_data:
        for item, data in response_data["furniture"].items():
            assert "count" in data
            assert "confidence" in data
            assert isinstance(data["count"], int)
```

---

## 🔧 Error Handling

### Common Error Scenarios

| Error Type | HTTP Status | Description | Resolution |
|------------|-------------|-------------|------------|
| Invalid Image | 400 | Malformed base64 or unsupported format | Validate image format and encoding |
| Image Too Large | 413 | Image exceeds size limits | Resize image before upload |
| Invalid Model | 400 | Unsupported model specified | Use supported model codes |
| Gemini API Error | 502 | External API failure | Retry with exponential backoff |
| Rate Limit | 429 | Too many requests | Implement request throttling |
| Insufficient Credits | 402 | Gemini API quota exceeded | Check billing and usage limits |

### Error Response Format

```json
{
    "error": {
        "code": "INVALID_IMAGE",
        "message": "Image format not supported",
        "details": {
            "supported_formats": ["JPEG", "PNG", "GIF"],
            "received_format": "BMP"
        }
    },
    "request_id": "req_123456789"
}
```

### Retry Logic

Implement exponential backoff for transient failures:

```python
import backoff

@backoff.on_exception(
    backoff.expo,
    requests.exceptions.RequestException,
    max_tries=3
)
def call_gemini_api(image_data, prompt):
    response = requests.post(
        gemini_endpoint,
        json={"image": image_data, "prompt": prompt},
        headers={"Authorization": f"Bearer {api_key}"}
    )
    response.raise_for_status()
    return response.json()
```

---

## 📊 Monitoring & Observability

### Key Metrics

Track these metrics for AI API performance:

- **Request Volume**: Requests per minute/hour/day
- **Response Time**: 95th percentile processing time
- **Error Rate**: Failed requests percentage
- **Cost Metrics**: Total cost, cost per request, cost by model
- **Model Usage**: Distribution across different models
- **Tenant Usage**: Request volume and cost by tenant

### Logging Structure

Use structured logging for AI operations:

```python
logger.info(
    "AI analysis completed",
    extra={
        "request_id": request_id,
        "tenant_id": tenant_id,
        "model_used": model_name,
        "processing_time_ms": processing_time,
        "input_tokens": token_usage.input_tokens,
        "output_tokens": token_usage.output_tokens,
        "total_cost": cost_analysis.total_cost,
        "confidence_score": response.confidence
    }
)
```

### Performance Thresholds

Set up alerts for performance degradation:

- **Response Time**: Alert if 95th percentile > 5 seconds
- **Error Rate**: Alert if error rate > 5%
- **Cost Anomaly**: Alert if daily cost > 150% of 7-day average
- **Rate Limiting**: Alert if rate limit hit more than 3 times/hour

---

## 🔗 Integration Examples

### Frontend Integration (TypeScript)

```typescript
interface AIAnalysisRequest {
    image_base64: string;
    model?: 'flash_lite' | 'flash' | 'flash_8b';
    analysis_type?: 'standard' | 'detailed' | 'quick';
}

async function analyzeImage(request: AIAnalysisRequest): Promise<AIResponse> {
    const response = await fetch('/api/ai/analyze-image', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify(request)
    });

    if (!response.ok) {
        throw new Error(`AI analysis failed: ${response.statusText}`);
    }

    return response.json();
}
```

### Mobile Integration (React Native)

```typescript
import { ImagePicker } from 'expo-image-picker';

async function captureAndAnalyze() {
    // Capture image
    const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
    });

    if (!result.canceled) {
        // Convert to base64
        const base64 = await FileSystem.readAsStringAsync(
            result.assets[0].uri,
            { encoding: 'base64' }
        );

        // Analyze with AI
        const analysis = await analyzeImage({
            image_base64: `data:image/jpeg;base64,${base64}`,
            model: 'flash_lite'
        });

        return analysis;
    }
}
```

---

## 🚨 Troubleshooting

### Common Issues

#### High Processing Times
**Symptoms**: Requests taking >10 seconds
**Causes**: Large images, complex prompts, model overload
**Solutions**:
- Resize images to 1024x1024 max
- Use `flash_lite` for faster processing
- Implement request queuing

#### Inconsistent Response Formats
**Symptoms**: Frontend errors processing AI responses
**Causes**: AI model returning non-standard format
**Solutions**:
- Enable response normalization
- Update prompt templates for consistency
- Add response validation middleware

#### Cost Overruns
**Symptoms**: Unexpected high AI costs
**Causes**: Using expensive models, large images, high volume
**Solutions**:
- Set up cost monitoring alerts
- Implement usage quotas per tenant
- Optimize image sizes and prompt length

### Debug Mode

Enable detailed logging for troubleshooting:

```python
# Set environment variable
DEBUG_AI_RESPONSES=true

# Enhanced logging output
{
    "level": "DEBUG",
    "message": "AI response received",
    "raw_response": {...},
    "normalized_response": {...},
    "token_usage": {...},
    "processing_steps": [...]
}
```

---

## 📚 Related Documentation

### Architecture References
- **[Backend Architecture](../architecture/README.md)** - Overall backend system design
- **[API Components](./api-components.md)** - Service layer architecture patterns
- **[Security Implementation](./architecture/security-implementation.md)** - Authentication and authorization

### Integration Guides
- **[AI Performance Monitoring](./ai-performance.md)** - Performance optimization and monitoring
- **[AI Prompt Management](./ai-prompt-management.md)** - Prompt template management and versioning
- **[AI Testing Tools](../admin/ai-testing-tools.md)** - Admin dashboard testing interfaces

### Operational Procedures
- **[Deployment Guide](../workflows/deployment-guide.md)** - AI service deployment procedures
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General system troubleshooting

---

**Status**: ✅ Production Ready - Comprehensive AI API documentation with integration examples, cost analysis, and troubleshooting guidance
