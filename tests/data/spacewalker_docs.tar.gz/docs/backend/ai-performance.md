# AI Performance Monitoring & Optimization

## Purpose
Comprehensive guide for monitoring, optimizing, and scaling AI analysis performance including cost management, resource optimization, caching strategies, and performance metrics. Essential reference for maintaining efficient AI operations at scale.

## When to Use This
- Optimizing AI analysis costs and performance
- Setting up monitoring and alerting for AI services
- Implementing caching strategies for improved response times
- Scaling AI operations across multiple tenants
- Troubleshooting performance bottlenecks and cost overruns
- Keywords: AI performance, cost optimization, monitoring, caching, scaling, resource management

**Version:** 1.0
**Date:** 2025-07-10
**Status:** Current - AI Performance Technical Reference

---

## 🚀 Quick Start

### Performance Overview Dashboard
```json
{
    "current_metrics": {
        "avg_response_time": "2.3s",
        "requests_per_minute": 45,
        "cost_per_request": "$0.027",
        "cache_hit_rate": "78%",
        "error_rate": "1.2%"
    },
    "cost_summary": {
        "daily_cost": "$127.50",
        "monthly_projection": "$3,825.00",
        "cost_by_model": {
            "flash_lite": "$85.20 (67%)",
            "flash": "$32.10 (25%)",
            "flash_8b": "$10.20 (8%)"
        }
    }
}
```

### Key Performance Targets
- **Response Time**: <3 seconds (95th percentile)
- **Cache Hit Rate**: >70%
- **Error Rate**: <2%
- **Cost per Request**: <$0.05
- **Availability**: >99.5%

---

## 📊 Performance Metrics & Monitoring

### Core Performance Indicators

#### Request Processing Metrics
```python
# Response time tracking
response_time_histogram = Histogram(
    'ai_request_duration_seconds',
    'Time spent processing AI requests',
    ['model', 'tenant_id', 'analysis_type']
)

# Request volume tracking
request_counter = Counter(
    'ai_requests_total',
    'Total AI requests',
    ['model', 'status', 'tenant_id']
)

# Error rate tracking
error_counter = Counter(
    'ai_errors_total',
    'Total AI request errors',
    ['error_type', 'model', 'tenant_id']
)
```

#### Cost & Resource Metrics
```python
# Token usage tracking
token_usage_histogram = Histogram(
    'ai_tokens_used',
    'Tokens consumed per request',
    ['model', 'token_type']  # input/output
)

# Cost tracking
cost_histogram = Histogram(
    'ai_cost_per_request',
    'Cost per AI request in USD',
    ['model', 'tenant_id']
)

# Model usage distribution
model_usage_counter = Counter(
    'ai_model_usage_total',
    'AI model usage distribution',
    ['model', 'tenant_id']
)
```

### Monitoring Dashboard Setup

#### Grafana Dashboard Configuration
```json
{
    "dashboard": {
        "title": "AI Performance Monitoring",
        "panels": [
            {
                "title": "Response Time (95th percentile)",
                "type": "stat",
                "targets": [
                    {
                        "expr": "histogram_quantile(0.95, ai_request_duration_seconds)",
                        "legendFormat": "95th percentile"
                    }
                ],
                "thresholds": [
                    {"color": "green", "value": 0},
                    {"color": "yellow", "value": 3},
                    {"color": "red", "value": 5}
                ]
            },
            {
                "title": "Cost per Request",
                "type": "timeseries",
                "targets": [
                    {
                        "expr": "rate(ai_cost_per_request_sum[5m]) / rate(ai_cost_per_request_count[5m])",
                        "legendFormat": "{{model}}"
                    }
                ]
            },
            {
                "title": "Cache Hit Rate",
                "type": "stat",
                "targets": [
                    {
                        "expr": "rate(cache_hits_total[5m]) / (rate(cache_hits_total[5m]) + rate(cache_misses_total[5m])) * 100"
                    }
                ]
            }
        ]
    }
}
```

#### Alert Rules
```yaml
groups:
  - name: ai_performance_alerts
    rules:
      - alert: HighAIResponseTime
        expr: histogram_quantile(0.95, ai_request_duration_seconds) > 5
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "AI response time is high"
          description: "95th percentile response time is {{ $value }}s"

      - alert: HighAICost
        expr: increase(ai_cost_per_request_sum[1h]) / increase(ai_cost_per_request_count[1h]) > 0.05
        for: 10m
        labels:
          severity: critical
        annotations:
          summary: "AI cost per request is high"
          description: "Average cost per request is ${{ $value }}"

      - alert: LowCacheHitRate
        expr: rate(cache_hits_total[10m]) / (rate(cache_hits_total[10m]) + rate(cache_misses_total[10m])) * 100 < 60
        for: 15m
        labels:
          severity: warning
        annotations:
          summary: "AI cache hit rate is low"
          description: "Cache hit rate is {{ $value }}%"
```

---

## 💰 Cost Optimization Strategies

### Model Selection Optimization

#### Cost-Performance Matrix
| Model | Cost/Token | Speed | Accuracy | Best Use Case |
|-------|------------|-------|----------|---------------|
| Flash Lite | $0.000015 | Fastest | Good | Quick classification, high volume |
| Flash | $0.00015 | Medium | Better | Standard analysis, balanced needs |
| Flash 8B | $0.0003 | Slowest | Best | Complex analysis, high accuracy required |

#### Intelligent Model Routing
```python
def select_optimal_model(image_complexity, accuracy_requirement, cost_priority):
    """Select the most cost-effective model based on requirements"""

    if cost_priority == "high" and accuracy_requirement == "standard":
        return "flash_lite"

    if image_complexity == "complex" or accuracy_requirement == "high":
        return "flash_8b"

    return "flash"  # Default balanced choice

# Usage in analysis pipeline
def analyze_image_optimized(image_data, user_preferences):
    complexity = assess_image_complexity(image_data)
    model = select_optimal_model(
        complexity,
        user_preferences.accuracy,
        user_preferences.cost_priority
    )

    return analyze_with_model(image_data, model)
```

### Token Usage Optimization

#### Image Optimization Strategies
```python
from PIL import Image
import io

def optimize_image_for_ai(image_data, max_size=(1024, 1024), quality=85):
    """Optimize image to reduce token consumption while maintaining quality"""

    # Open image
    image = Image.open(io.BytesIO(image_data))

    # Resize if too large
    if image.size[0] > max_size[0] or image.size[1] > max_size[1]:
        image.thumbnail(max_size, Image.Resampling.LANCZOS)

    # Optimize compression
    output = io.BytesIO()
    image.save(output, format='JPEG', quality=quality, optimize=True)

    # Calculate token savings
    original_size = len(image_data)
    optimized_size = len(output.getvalue())
    token_savings = (original_size - optimized_size) / 1000  # Approximate

    return {
        'data': output.getvalue(),
        'size_reduction': f"{((original_size - optimized_size) / original_size * 100):.1f}%",
        'estimated_token_savings': token_savings
    }
```

#### Prompt Optimization
```python
def optimize_prompt_for_cost(base_prompt, tenant_requirements):
    """Optimize prompt length while maintaining effectiveness"""

    # Remove unnecessary verbosity
    optimized = base_prompt.replace(
        "Please carefully analyze this image and provide detailed information about",
        "Analyze this image for"
    )

    # Use concise instructions
    optimized = optimized.replace(
        "Make sure to include all relevant details and be as specific as possible",
        "Include relevant details"
    )

    # Calculate token reduction
    original_tokens = estimate_token_count(base_prompt)
    optimized_tokens = estimate_token_count(optimized)

    return {
        'prompt': optimized,
        'token_reduction': original_tokens - optimized_tokens,
        'cost_savings_per_request': (original_tokens - optimized_tokens) * 0.000015
    }
```

### Cost Budgeting & Quotas

#### Tenant-Based Cost Management
```python
class TenantCostManager:
    def __init__(self, db: Session):
        self.db = db

    def check_cost_quota(self, tenant_id: int, estimated_cost: float) -> bool:
        """Check if request would exceed tenant's cost quota"""

        # Get current month usage
        current_month_cost = self.get_monthly_cost(tenant_id)
        tenant_quota = self.get_tenant_quota(tenant_id)

        if current_month_cost + estimated_cost > tenant_quota:
            logger.warning(
                f"Cost quota exceeded for tenant {tenant_id}",
                extra={
                    "current_cost": current_month_cost,
                    "quota": tenant_quota,
                    "requested_cost": estimated_cost
                }
            )
            return False

        return True

    def estimate_request_cost(self, model: str, image_size: int, prompt_length: int) -> float:
        """Estimate cost before making AI request"""

        # Estimate tokens
        image_tokens = image_size / 1000  # Rough approximation
        prompt_tokens = prompt_length / 4  # ~4 chars per token
        estimated_output_tokens = 150  # Average response length

        # Calculate cost
        model_rates = {
            "flash_lite": {"input": 0.000015, "output": 0.00015},
            "flash": {"input": 0.00015, "output": 0.0015},
            "flash_8b": {"input": 0.0003, "output": 0.003}
        }

        rates = model_rates.get(model, model_rates["flash"])
        input_cost = (image_tokens + prompt_tokens) * rates["input"]
        output_cost = estimated_output_tokens * rates["output"]

        return input_cost + output_cost
```

---

## 🚀 Caching Strategies

### Multi-Level Caching Architecture

#### 1. Prompt Template Caching
```python
class PromptCacheManager:
    def __init__(self, redis_client):
        self.redis = redis_client
        self.cache_ttl = 3600  # 1 hour

    def get_cached_prompt(self, tenant_id: int, template_id: int) -> Optional[str]:
        """Get cached compiled prompt for tenant"""
        cache_key = f"prompt:{tenant_id}:{template_id}"
        cached = self.redis.get(cache_key)

        if cached:
            logger.debug(f"Prompt cache hit for {cache_key}")
            return cached.decode('utf-8')

        return None

    def cache_prompt(self, tenant_id: int, template_id: int, compiled_prompt: str):
        """Cache compiled prompt with TTL"""
        cache_key = f"prompt:{tenant_id}:{template_id}"
        self.redis.setex(cache_key, self.cache_ttl, compiled_prompt)
        logger.debug(f"Cached prompt for {cache_key}")
```

#### 2. FICM Code Caching
```python
class FICMCacheManager:
    def __init__(self, redis_client):
        self.redis = redis_client
        self.cache_ttl = 86400  # 24 hours

    def get_tenant_ficm_codes(self, tenant_id: int) -> Optional[List[dict]]:
        """Get cached FICM codes for tenant"""
        cache_key = f"ficm_codes:{tenant_id}"
        cached = self.redis.get(cache_key)

        if cached:
            return json.loads(cached)
        return None

    def cache_ficm_codes(self, tenant_id: int, ficm_codes: List[dict]):
        """Cache FICM codes with longer TTL"""
        cache_key = f"ficm_codes:{tenant_id}"
        self.redis.setex(cache_key, self.cache_ttl, json.dumps(ficm_codes))
```

#### 3. Response Caching for Similar Images
```python
import hashlib

class ResponseCacheManager:
    def __init__(self, redis_client):
        self.redis = redis_client
        self.cache_ttl = 7200  # 2 hours

    def generate_image_hash(self, image_data: bytes) -> str:
        """Generate hash for image deduplication"""
        return hashlib.sha256(image_data).hexdigest()

    def get_cached_response(self, image_hash: str, model: str, tenant_id: int) -> Optional[dict]:
        """Get cached analysis response for similar image"""
        cache_key = f"response:{tenant_id}:{model}:{image_hash}"
        cached = self.redis.get(cache_key)

        if cached:
            response = json.loads(cached)
            # Add cache hit indicator
            response['from_cache'] = True
            response['cache_timestamp'] = time.time()
            return response

        return None

    def cache_response(self, image_hash: str, model: str, tenant_id: int, response: dict):
        """Cache successful analysis response"""
        cache_key = f"response:{tenant_id}:{model}:{image_hash}"

        # Don't cache responses with low confidence
        if response.get('confidence', 0) < 0.7:
            return

        # Remove sensitive fields before caching
        cache_response = {k: v for k, v in response.items()
                        if k not in ['raw_response', 'debug_info']}

        self.redis.setex(cache_key, self.cache_ttl, json.dumps(cache_response))
```

### Cache Performance Optimization

#### Cache Hit Rate Monitoring
```python
class CacheMetrics:
    def __init__(self):
        self.hit_counter = Counter('cache_hits_total', 'Cache hits', ['cache_type'])
        self.miss_counter = Counter('cache_misses_total', 'Cache misses', ['cache_type'])

    def record_hit(self, cache_type: str):
        self.hit_counter.labels(cache_type=cache_type).inc()

    def record_miss(self, cache_type: str):
        self.miss_counter.labels(cache_type=cache_type).inc()

    def get_hit_rate(self, cache_type: str) -> float:
        hits = self.hit_counter.labels(cache_type=cache_type)._value._value
        misses = self.miss_counter.labels(cache_type=cache_type)._value._value
        total = hits + misses
        return (hits / total * 100) if total > 0 else 0
```

#### Cache Warming Strategy
```python
async def warm_cache_for_tenant(tenant_id: int):
    """Pre-populate cache with frequently used data"""

    # Warm prompt cache
    active_templates = get_active_prompt_templates(tenant_id)
    for template in active_templates:
        compiled_prompt = compile_prompt_template(template, tenant_id)
        prompt_cache.cache_prompt(tenant_id, template.id, compiled_prompt)

    # Warm FICM codes cache
    ficm_codes = get_tenant_ficm_codes_from_db(tenant_id)
    ficm_cache.cache_ficm_codes(tenant_id, ficm_codes)

    logger.info(f"Cache warmed for tenant {tenant_id}")
```

---

## ⚡ Performance Optimization Techniques

### Asynchronous Processing

#### Async AI Request Processing
```python
import asyncio
import aiohttp
from typing import List

class AsyncAIProcessor:
    def __init__(self, max_concurrent_requests: int = 10):
        self.semaphore = asyncio.Semaphore(max_concurrent_requests)
        self.session = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.session.close()

    async def process_image_async(self, image_data: bytes, model: str) -> dict:
        """Process single image asynchronously"""
        async with self.semaphore:
            # Simulate async AI processing
            await asyncio.sleep(0.1)  # Rate limiting

            return await self._call_ai_api(image_data, model)

    async def process_batch_images(self, image_batch: List[tuple]) -> List[dict]:
        """Process multiple images concurrently"""
        tasks = []
        for image_data, model in image_batch:
            task = self.process_image_async(image_data, model)
            tasks.append(task)

        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results

# Usage
async def batch_analyze_images(images: List[bytes]):
    async with AsyncAIProcessor(max_concurrent_requests=5) as processor:
        image_pairs = [(img, "flash_lite") for img in images]
        results = await processor.process_batch_images(image_pairs)
        return results
```

### Request Batching & Queuing

#### Queue-Based Processing
```python
from celery import Celery
from typing import Dict, Any

celery_app = Celery('ai_processor')

@celery_app.task(bind=True, max_retries=3)
def process_ai_request_async(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
    """Process AI request asynchronously via Celery"""
    try:
        # Extract request parameters
        image_data = base64.b64decode(request_data['image_base64'])
        model = request_data.get('model', 'flash_lite')
        tenant_id = request_data['tenant_id']

        # Check cache first
        image_hash = generate_image_hash(image_data)
        cached_response = response_cache.get_cached_response(image_hash, model, tenant_id)

        if cached_response:
            return cached_response

        # Process with AI
        result = call_gemini_api(image_data, model, tenant_id)

        # Cache successful result
        response_cache.cache_response(image_hash, model, tenant_id, result)

        return result

    except Exception as exc:
        # Retry with exponential backoff
        raise self.retry(exc=exc, countdown=60 * (2 ** self.request.retries))

# High-priority processing for real-time requests
@celery_app.task(queue='high_priority')
def process_realtime_ai_request(request_data: Dict[str, Any]) -> Dict[str, Any]:
    """Process urgent AI requests in high-priority queue"""
    return process_ai_request_async(request_data)
```

### Database Query Optimization

#### Optimized Prompt Retrieval
```python
from sqlalchemy.orm import selectinload, joinedload

def get_optimized_prompt_data(db: Session, tenant_id: int) -> dict:
    """Efficiently retrieve all prompt-related data in minimal queries"""

    # Single query to get prompt template with relationships
    prompt_template = (
        db.query(PromptTemplate)
        .options(
            selectinload(PromptTemplate.tenant),
            joinedload(PromptTemplate.cache)
        )
        .filter(
            PromptTemplate.tenant_id == tenant_id,
            PromptTemplate.is_active == True
        )
        .first()
    )

    # Batch query for FICM codes
    ficm_codes = (
        db.query(FICMDesignType)
        .filter(
            FICMDesignType.tenant_id == tenant_id,
            FICMDesignType.is_active == True
        )
        .options(selectinload(FICMDesignType.attributes))
        .all()
    )

    # Batch query for attributes
    attributes = (
        db.query(AttributeDefinition)
        .filter(
            AttributeDefinition.tenant_id == tenant_id,
            AttributeDefinition.is_active == True
        )
        .all()
    )

    return {
        'prompt_template': prompt_template,
        'ficm_codes': ficm_codes,
        'attributes': attributes
    }
```

---

## 📈 Scaling Strategies

### Horizontal Scaling

#### Load Balancing Configuration
```yaml
# nginx.conf for AI service load balancing
upstream ai_backend {
    least_conn;
    server ai-service-1:8000 weight=3;
    server ai-service-2:8000 weight=3;
    server ai-service-3:8000 weight=2;  # Lower spec instance
}

server {
    listen 80;
    location /api/ai/ {
        proxy_pass http://ai_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_connect_timeout 30s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
```

#### Auto-Scaling Policy
```yaml
# Kubernetes HPA for AI service
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: ai-service-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ai-service
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  - type: Pods
    pods:
      metric:
        name: ai_requests_per_second
      target:
        type: AverageValue
        averageValue: "50"
```

### Resource Optimization

#### Memory Management
```python
import gc
import psutil
from typing import Optional

class ResourceMonitor:
    def __init__(self, memory_threshold: float = 0.8):
        self.memory_threshold = memory_threshold

    def check_memory_usage(self) -> dict:
        """Monitor memory usage and trigger cleanup if needed"""
        memory = psutil.virtual_memory()

        if memory.percent / 100 > self.memory_threshold:
            # Force garbage collection
            gc.collect()

            # Clear application caches if memory still high
            if psutil.virtual_memory().percent / 100 > self.memory_threshold:
                self.clear_application_caches()

        return {
            'memory_percent': memory.percent,
            'memory_available': memory.available,
            'memory_threshold_exceeded': memory.percent / 100 > self.memory_threshold
        }

    def clear_application_caches(self):
        """Clear application-level caches to free memory"""
        # Clear response cache older than 30 minutes
        response_cache.clear_old_entries(max_age=1800)

        # Clear compiled prompt cache
        prompt_cache.clear_expired()

        logger.info("Application caches cleared due to high memory usage")

# Usage in request processing
resource_monitor = ResourceMonitor()

def process_ai_request_with_monitoring(request_data):
    # Check resources before processing
    memory_status = resource_monitor.check_memory_usage()

    if memory_status['memory_threshold_exceeded']:
        logger.warning("High memory usage detected", extra=memory_status)

    # Process request
    result = process_ai_request(request_data)

    return result
```

### Geographic Distribution

#### Multi-Region Deployment Strategy
```python
class RegionAwareAIService:
    def __init__(self):
        self.regions = {
            'us-east-1': {
                'endpoint': 'https://ai-us-east.spacewalker.com',
                'latency_ms': 50,
                'cost_multiplier': 1.0
            },
            'eu-west-1': {
                'endpoint': 'https://ai-eu-west.spacewalker.com',
                'latency_ms': 120,
                'cost_multiplier': 1.1
            },
            'ap-southeast-1': {
                'endpoint': 'https://ai-ap-southeast.spacewalker.com',
                'latency_ms': 200,
                'cost_multiplier': 1.2
            }
        }

    def select_optimal_region(self, user_location: str, priority: str = 'latency') -> str:
        """Select the best region based on user location and preferences"""

        if priority == 'cost':
            return min(self.regions.keys(),
                      key=lambda r: self.regions[r]['cost_multiplier'])

        # Default to latency optimization
        user_region_map = {
            'US': 'us-east-1',
            'EU': 'eu-west-1',
            'APAC': 'ap-southeast-1'
        }

        return user_region_map.get(user_location, 'us-east-1')
```

---

## 🚨 Performance Troubleshooting

### Common Performance Issues

#### Slow Response Times
**Symptoms**: API responses >5 seconds, timeouts
**Diagnosis**:
```python
def diagnose_slow_responses():
    """Systematic diagnosis of slow AI responses"""

    metrics = {
        'avg_response_time': get_avg_response_time_last_hour(),
        'cache_hit_rate': get_cache_hit_rate(),
        'queue_depth': get_current_queue_depth(),
        'active_connections': get_active_db_connections(),
        'memory_usage': psutil.virtual_memory().percent
    }

    issues = []

    if metrics['cache_hit_rate'] < 50:
        issues.append("Low cache hit rate - check cache configuration")

    if metrics['queue_depth'] > 100:
        issues.append("High queue depth - consider scaling workers")

    if metrics['memory_usage'] > 85:
        issues.append("High memory usage - check for memory leaks")

    return {
        'metrics': metrics,
        'potential_issues': issues,
        'recommendations': generate_performance_recommendations(metrics)
    }
```

**Solutions**:
- Enable response caching for similar images
- Optimize image sizes before processing
- Scale horizontally with more workers
- Use faster AI models for non-critical requests

#### High Costs
**Symptoms**: Cost per request >$0.10, budget overruns
**Diagnosis**:
```python
def analyze_cost_drivers():
    """Identify primary cost drivers"""

    cost_analysis = {
        'cost_by_model': get_cost_breakdown_by_model(),
        'cost_by_tenant': get_cost_breakdown_by_tenant(),
        'avg_tokens_per_request': get_avg_token_usage(),
        'high_cost_requests': get_expensive_requests(threshold=0.20)
    }

    recommendations = []

    if cost_analysis['avg_tokens_per_request'] > 2000:
        recommendations.append("Optimize image sizes and prompt length")

    expensive_model_usage = cost_analysis['cost_by_model'].get('flash_8b', 0)
    if expensive_model_usage > 30:  # >30% of total cost
        recommendations.append("Review flash_8b usage - consider flash_lite for simpler cases")

    return {
        'analysis': cost_analysis,
        'recommendations': recommendations
    }
```

### Performance Optimization Playbook

#### Step 1: Identify Bottlenecks
```bash
# Check current performance metrics
curl -s "http://monitoring:9090/api/v1/query?query=ai_request_duration_seconds" | jq

# Check cache performance
redis-cli info stats | grep -E "(hits|misses)"

# Check queue status
celery -A ai_processor inspect active_queues
```

#### Step 2: Apply Targeted Optimizations
```python
def apply_performance_optimizations(performance_profile: dict):
    """Apply optimizations based on performance profile"""

    if performance_profile['response_time'] > 3.0:
        # Enable more aggressive caching
        enable_extended_caching()

        # Increase worker pool size
        scale_worker_pool(target_size=10)

    if performance_profile['cost_per_request'] > 0.05:
        # Switch to more cost-effective models
        update_default_model_selection("flash_lite")

        # Enable image optimization
        enable_automatic_image_optimization()

    if performance_profile['cache_hit_rate'] < 0.7:
        # Warm cache proactively
        schedule_cache_warming()

        # Increase cache TTL
        extend_cache_ttl(multiplier=2.0)
```

#### Step 3: Monitor and Validate
```python
def validate_optimizations(baseline_metrics: dict, current_metrics: dict) -> dict:
    """Validate that optimizations improved performance"""

    improvements = {}

    for metric in ['response_time', 'cost_per_request', 'cache_hit_rate']:
        baseline = baseline_metrics[metric]
        current = current_metrics[metric]

        if metric == 'cache_hit_rate':
            improvement = ((current - baseline) / baseline) * 100
        else:
            improvement = ((baseline - current) / baseline) * 100

        improvements[metric] = {
            'baseline': baseline,
            'current': current,
            'improvement_percent': improvement
        }

    return improvements
```

---

## 📚 Related Documentation

### Architecture References
- **[AI Analysis API](./ai-analysis-api.md)** - API endpoints and integration patterns
- **[Backend Architecture](../architecture/README.md)** - Overall system architecture
- **[Security Guide](../backend/authentication-api.md)** - Security and authentication

### Operational Guides
- **[AI Prompt Management](./ai-prompt-management.md)** - Prompt optimization and management
- **[AI Testing Tools](../admin/ai-testing-tools.md)** - Testing and validation interfaces
- **[Deployment Guide](../workflows/deployment-guide.md)** - Production deployment procedures

### Monitoring & Operations
- **[Troubleshooting Guide](../workflows/troubleshooting-guide.md)** - General troubleshooting guidance

---

**Status**: ✅ Production Ready - Comprehensive performance monitoring and optimization guide with metrics, caching strategies, and troubleshooting procedures
