# BACnet Environment Rebuild

## Purpose
Comprehensive guide for rebuilding and verifying the BACnet connector Docker environment using justfile commands. Essential workflow for development teams managing containerized BACnet systems with multiple rebuild approaches based on specific needs.

## When to Use This
- Setting up BACnet development environment for the first time
- Rebuilding after making routine code changes to BACnet connector
- Troubleshooting Docker container networking issues
- Starting fresh after pulling new code changes
- Resolving Docker layer caching issues or build problems
- Keywords: BACnet rebuild, Docker environment, container rebuild, justfile workflow, development setup

**Version:** 2.0 (Migrated from Cursor rules)
**Date:** 2025-06-29
**Status:** Current - Production Development Workflow

---

## 🎯 Prerequisites

### Required Tools
Ensure these tools are installed and configured before proceeding:

```bash
# Verify Docker and Docker Compose installation
docker --version
docker-compose --version

# Verify you're in the project root directory
pwd  # Should show spacewalker project root

# Verify justfile commands are available
just help
```

### Environment Verification
```bash
# Check current working directory
ls -la | rg "(justfile|docker|scripts)"
# Should show justfile, docker/, and scripts/ directories
```

---

## 🚀 Rebuild Strategy Selection

Choose the appropriate rebuild approach based on your specific situation:

### Quick Rebuild (Most Common)
**Use this when:**
- Making routine code changes to BACnet connector
- Docker containers are already running and healthy
- No issues with container networking detected
- No Docker cache problems suspected
- Need fast iteration during development

**Estimated Time:** 2-3 minutes

### Standard Rebuild
**Use this when:**
- Starting fresh after pulling new code changes
- Containers aren't currently running
- Minor issues with the development environment
- Switching between development branches
- After configuration file modifications

**Estimated Time:** 5-8 minutes

### Full/Deep Rebuild
**Use this when:**
- First time setting up the development environment
- Major changes to Dockerfiles or dependencies
- Persistent issues with the environment that standard rebuild doesn't resolve
- Suspected Docker layer caching issues
- Explicitly instructed to do a "clean rebuild"
- Docker network or volume corruption suspected

**Estimated Time:** 10-15 minutes

---

## ⚡ Quick Rebuild Process

### Step 1: Restart the Application
```bash
# Restart the BACnet connector with latest code changes
just docker-restart occupancy-bacnet-connector
```

**Expected Outcome:** The application restarts with your code changes incorporated.

### Step 2: Verify Application Startup
```bash
# Check for successful BACnet application startup
just docker-logs-snapshot occupancy-bacnet-connector | rg -i "BACnet application.*is running"
```

**Expected Outcome:** Should see confirmation message that the BACnet application started successfully.

### Step 3: Verify Zone Filtering Configuration
```bash
# Display current zone filtering status and configuration
./scripts/diagnostics/show-filter-status.sh
```

**Expected Outcome:** Zone filtering status should be clearly displayed (enabled/disabled with appropriate configuration details).

### Step 4: Verify Clean Startup (No Errors)
```bash
# Check for any errors in logs since the restart
./scripts/diagnostics/verify-logs.sh --since 5m occupancy-bacnet-connector
```

**Expected Outcome:** No errors should be found in logs since the restart. Any errors indicate the rebuild was unsuccessful and requires investigation.

---

## 🔧 Standard Rebuild Process

### Step 1: Stop Running Services
```bash
# Gracefully stop all running Docker services
just docker-stop
```

**Expected Outcome:** All services are stopped and containers are removed cleanly.

### Step 2: Build and Start Services
```bash
# Rebuild images and start all services in one command
just docker-rebuild
```

**Expected Outcome:** Docker images are built (using cache where appropriate) and containers start successfully.

### Step 3: Verify Container Health
```bash
# Check status of all Docker containers
just docker-status
```

**Expected Outcome:** Both `occupancy-bacnet-connector` and `testing-bacnet-client` services should show status as "Up".

### Step 4: Comprehensive Service Verification
```bash
# API connectivity verification (run first as prerequisite)
just health-check

# BACnet device discovery verification
just diagnostics_bacnet

# Application running status verification
just docker-logs-snapshot occupancy-bacnet-connector | rg -i "BACnet application.*is running"

# Zone filtering status verification
./scripts/diagnostics/show-filter-status.sh
```

**Expected Outcome:**
- API connectivity should be confirmed and responsive
- BACnet device should be discoverable on the network
- Application should be running with proper initialization
- Zone filtering status should be clearly displayed

### Step 5: Final Error Check
```bash
# Verify no errors occurred during the rebuild process
./scripts/diagnostics/verify-logs.sh --since 10m --all-services
```

**Expected Outcome:** No errors should be found in logs since the rebuild started. Any errors indicate the rebuild was unsuccessful.

---

## 🔥 Full/Deep Rebuild Process

### Step 1: Stop All Services
```bash
# Ensure all Docker services are completely stopped
just docker-stop
```

**Expected Outcome:** All services are stopped and all containers are removed.

### Step 2: Complete Docker Cleanup
```bash
# Remove all project containers, images, and volumes
just docker-clean all
```

**Expected Outcome:** All project-related Docker resources (containers, images, volumes) are completely cleaned up.

**⚠️ Warning:** This removes all Docker data for the project, including any cached layers or persistent volumes.

### Step 3: Rebuild Images from Scratch
```bash
# Build all images completely from scratch (no cache)
just docker-build --no-cache
```

**Expected Outcome:** New Docker images are built completely from scratch without using any cached layers.

**Note:** This step takes longest as it rebuilds every layer without cache assistance.

### Step 4: Start Clean Services
```bash
# Start all services with fresh images
just docker-start
```

**Expected Outcome:** Containers start successfully and remain running with clean state.

### Step 5: Comprehensive Environment Verification
```bash
# Container status verification
just docker-status

# API connectivity verification (critical first check)
just health-check

# Network connectivity verification
just diagnostics_bacnet

# BACnet device discovery verification
just diagnostics_bacnet

# BACnet object reading verification
./scripts/diagnostics/read-objects.sh 337733

# Device information verification
./scripts/diagnostics/device-info.sh 337733

# API polling verification
just docker-logs-snapshot occupancy-bacnet-connector | rg -i "Successfully fetched" | tail -3

# Zone filtering functionality verification
./scripts/diagnostics/show-filter-status.sh
just docker-exec occupancy-bacnet-connector bacnet-filter validate || echo "No filter config (OK)"
```

**Expected Outcome:** All verification steps should pass completely, including:
- All containers running and healthy
- API connectivity confirmed and responsive
- BACnet network discovery working
- Device communication functional
- API polling operating correctly
- Zone filtering properly configured or appropriately disabled

### Step 6: Final Comprehensive Log Verification
```bash
# Check for any errors since the full rebuild process began
./scripts/diagnostics/verify-logs.sh --since 15m --all-services
```

**Expected Outcome:** No errors should be found in logs since the rebuild process began. This confirms the rebuild was completely successful.

---

## 🎮 Alternative: Justfile Testing Workflows

For integrated rebuild and testing, use comprehensive justfile testing commands:

### Development Iteration Workflow
```bash
# Quick rebuild with unit tests (recommended for development)
just dev-cycle
```

### Complete Testing Workflow
```bash
# Complete rebuild with all tests (recommended for validation)
just test_with-infra
```

### Infrastructure Management
```bash
# Start infrastructure only (equivalent to docker-start)
just test_infra-up

# Check infrastructure status and health
just test_infra-status

# Stop infrastructure cleanly
just test_infra-down
```

### Complete Command Reference
See related documentation for comprehensive justfile command reference and integration details:
- **[Development Tools](../development/development-tools.md)** - Complete justfile command reference and automation
- **[Development Setup](../setup/development-setup.md)** - Initial environment configuration and setup

---

## 🚨 Troubleshooting Failed Rebuilds

### API Connectivity Issues
```bash
# Run comprehensive API health check with detailed output
just health-check

# Run enhanced API debugging with retry logic and detailed diagnostics
./scripts/diagnostics/api-debug-enhanced.sh
```

### Container and Application Issues
```bash
# View detailed application logs for error analysis
just docker-logs occupancy-bacnet-connector

# View logs for the testing client container
just docker-logs testing-bacnet-client
```

### Interactive Debugging Access
```bash
# Access shell in BACnet connector container
just docker-shell occupancy-bacnet-connector

# Access shell in testing client container
just docker-shell testing-bacnet-client

# Execute specific commands directly in containers
just docker-exec occupancy-bacnet-connector "ps aux"
just docker-exec testing-bacnet-client "ip addr show"
```

### Docker Configuration Debugging
```bash
# Check Docker network and container configuration
just docker-config

# Inspect Docker network details
docker network inspect app_bacnet_network
```

### Advanced Cleanup Options
```bash
# Graduated cleanup levels (use progressively if issues persist)
just docker-clean containers   # Remove containers only
just docker-clean images      # Remove containers + images
just docker-clean all         # Remove everything project-related
just docker-clean prune       # Remove ALL Docker resources (⚠️ use with extreme caution)
```

### Zone Filtering Specific Issues
```bash
# Check zone filtering status and configuration details
./scripts/diagnostics/show-filter-status.sh

# Validate filter configuration syntax and settings
just docker-exec occupancy-bacnet-connector bacnet-filter validate

# Test zone filtering without applying changes (safe testing)
just docker-exec occupancy-bacnet-connector bacnet-filter test-zone --zone-id z_12345

# Check zone filtering logs for errors or warnings
just docker-logs occupancy-bacnet-connector | grep -i "filter"

# Reset to baseline (disable filtering) for troubleshooting
just docker-exec occupancy-bacnet-connector "echo 'ZONE_FILTER_ENABLED=false' > .env"
just docker-restart occupancy-bacnet-connector
```

### Persistent Issues Resolution
If rebuilds continue to fail after troubleshooting:

1. **Try Full/Deep Rebuild Process** - Most comprehensive cleanup and rebuild
2. **Check Application Logs** - Look for specific error messages and root causes
3. **Verify Configuration Files** - Ensure all required configuration files are present and correctly formatted
4. **Port Conflict Detection** - Ensure no other BACnet applications are running on UDP port 47808
5. **Docker System Issues** - Consider `docker system prune` if Docker itself has issues (⚠️ affects all Docker projects)

---

## 🔗 Integration with Development Workflow

### Taskmaster Integration
```bash
# After completing development tasks, verify with appropriate rebuild level
# Quick rebuild for minor changes
just docker-restart occupancy-bacnet-connector

# Standard rebuild for significant changes
just docker-rebuild

# Full rebuild for major changes or persistent issues
just docker-clean all && just docker-build --no-cache && just docker-start
```

### Pre-commit Validation
```bash
# Complete validation before committing code changes
just test_with-infra
```

### Development Iteration
```bash
# Fast unit testing during active development
just dev-cycle
```

### Legacy Script Compatibility
All legacy `./scripts/docker_bacnet.sh` commands continue to work as thin wrappers around justfile commands, ensuring backward compatibility.

### Related Workflow Documentation
- **[Development Tools](../development/development-tools.md)** - Complete justfile command reference and automation scripts
- **[Development Setup](../setup/development-setup.md)** - Initial development environment configuration and setup
- **[Git Merge Strategy](../workflows/git-merge-strategy.md)** - Git workflow integration and branch management

---

## 📊 Environment Validation Checklist

### Container Health
- [ ] All required containers running (`docker ps` shows both services as "Up")
- [ ] No container restart loops or crash patterns
- [ ] Container logs show clean startup without errors
- [ ] Container networking properly configured

### BACnet System Health
- [ ] API connectivity confirmed (`just health-check` passes)
- [ ] BACnet device discovery working (`just diagnostics_bacnet` succeeds)
- [ ] Application running indefinitely with proper initialization
- [ ] Zone filtering properly configured or appropriately disabled

### Development Environment
- [ ] Justfile commands available and working
- [ ] Diagnostic scripts executable and functional
- [ ] No errors in recent logs (`verify-logs.sh` clean)
- [ ] Environment ready for development or testing workflows

---

## 📋 Related Development Documentation

### Core Development Workflows
- **[Development Setup](../setup/development-setup.md)** - Initial environment configuration and prerequisites
- **[Development Tools](../development/development-tools.md)** - Comprehensive justfile automation and helper scripts

### BACnet-Specific Documentation
> 🚀 **Backend Teams**: See [Backend Development](../backend/development/) for BACnet implementation details and server configuration
> 🚀 **IoT Integration**: See [Backend IoT Integration](../backend/iot-integration/) for BACnet protocol implementation specifics

### Troubleshooting and Operations
- **[BACnet Timeout Debugging](../gotchas/bacnet-timeout-debugging.md)** - Troubleshooting APDU timeouts and communication failures
- **[Development Environment Issues](../setup/development-setup.md)** - Common setup and configuration problems

### Testing and Deployment
- **[AWS Deployment Guide](../workflows/aws-deployment-guide.md)** - Production deployment procedures and container orchestration
- **[Testing Guide](../workflows/testing-guide.md)** - Comprehensive testing workflows including BACnet integration tests

---

**Status**: ✅ **PRODUCTION DEVELOPMENT WORKFLOW**
**Last Updated**: 2025-06-29
**Applies To**: All Spacewalker development teams working with BACnet integration
**Integration**: Docker workflows, justfile automation, development environment management

---

*This rebuild workflow ensures consistent, reliable BACnet development environments across all team members. Following these procedures provides clean, verified environments for development, testing, and troubleshooting BACnet connector functionality with proper zone filtering configuration.*
