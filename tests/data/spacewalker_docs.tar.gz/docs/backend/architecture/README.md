# Backend Architecture

## Purpose
Comprehensive FastAPI backend architecture documentation including service design, database schema, API contracts, and technical implementation details. Primary reference for backend development and system integration.

## When to Use This
- Understanding backend service architecture and design patterns
- Implementing API endpoints and database models
- Designing integrations with external services
- Troubleshooting backend issues and performance optimization
- Planning database migrations and schema changes
- Keywords: FastAPI, backend architecture, database design, API contracts, SQLAlchemy

**Version:** 2.0 (Extracted from comprehensive PRD)
**Date:** 2025-06-29
**Status:** Current - Backend Technical Reference

---

## 🏗️ Backend Component Architecture (C4 Level 3)

The Backend API is a monolithic service whose components are organized by function.

```mermaid
graph TD
    subgraph "Backend API Container (FastAPI)"
        direction LR

        subgraph "API Layer"
            APIRouters["API Routers<br/><i>Handles HTTP requests, auth, and validation.</i>"]
        end

        subgraph "Business Logic"
            AIService["AI Service<br/><i>Orchestrates calls to Google Gemini.</i>"]
            SurveyService["<a href='apps/backend/src/spacecargo/api/routers/surveys.py'>Survey Service</a><br/><i>Core logic for survey processing.</i>"]
        end

        subgraph "Data Access Layer"
            Models["SQLAlchemy Models<br/><i>Defines database schema and relationships.</i>"]
            DBSession["Database Session<br/><i>Manages DB connections.</i>"]
        end

    end

    APIRouters --> AIService
    APIRouters --> SurveyService
    SurveyService --> Models
    Models --> DBSession
```

## 🗄️ Database Design

The database schema is defined using SQLAlchemy ORM models, with migrations managed by Alembic.

### Entity Relationship Diagram

```mermaid
erDiagram
    TENANT ||--o{ USER : "has"
    TENANT ||--o{ BUILDING : "owns"
    TENANT ||--o{ ATTRIBUTE_DEFINITION : "defines"
    USER ||--o{ SURVEY : "conducts"
    BUILDING ||--|{ FLOOR : "contains"
    FLOOR ||--|{ ROOM : "contains"
    ROOM ||--o{ SURVEY : "is subject of"
    ROOM ||--o{ ROOM_ATTRIBUTE : "has"
    SURVEY ||--o{ SURVEY_IMAGE : "has"
    ATTRIBUTE_DEFINITION ||--o{ ROOM_ATTRIBUTE : "is instance of"
```

### Core Database Tables

#### Tenant Management
- **TENANT**: Multi-tenant isolation with university/organization data
- **USER**: User accounts with role-based access control
- **ATTRIBUTE_DEFINITION**: Tenant-specific room attribute definitions

#### Facility Structure
- **BUILDING**: Physical buildings within a tenant
- **FLOOR**: Floors within buildings with spatial organization
- **ROOM**: Individual rooms with location and metadata

#### Survey Data
- **SURVEY**: Room survey submissions with status tracking
- **SURVEY_IMAGE**: Images associated with survey submissions
- **ROOM_ATTRIBUTE**: Dynamic room attributes based on tenant definitions

### Multi-Tenant Security
Data is securely isolated between university tenants using **PostgreSQL's Row-Level Security (RLS)**:
- All queries automatically filtered by tenant context
- Users can only access data within their tenant scope
- Database-level enforcement prevents cross-tenant data leakage

---

## 🔌 API Contracts

The system exposes a REST API for all client interactions with comprehensive OpenAPI documentation.

### API Configuration
- **Base URL (Dev):** `http://localhost:8000/api`
- **Authentication:** JWT Bearer Tokens (24-hour expiration)
- **Interactive Documentation:** [http://localhost:8000/docs](http://localhost:8000/docs) (when running locally)
- **Content Type:** `application/json`
- **Error Format:** Standardized JSON error responses

### Core Endpoints

#### Authentication
```
POST /login
```
**Purpose:** Authenticate user and receive JWT token
- **Request:** `{ "email": "user@example.com", "password": "password" }`
- **Response:** `{ "access_token": "jwt_token", "token_type": "bearer" }`
- **Status:** `[Implemented]`

#### Building Management
```
GET /api/buildings
```
**Purpose:** List all buildings for authenticated tenant
- **Authentication:** Required (JWT Bearer)
- **Response:** Array of building objects with floors and rooms
- **Status:** `[Implemented]`

#### Survey Operations
```
POST /api/surveys/submit
```
**Purpose:** Submit a new room survey with images and AI analysis
- **Authentication:** Required (JWT Bearer)
- **Request:** Multipart form with room data and image files
- **Response:** Survey ID and processing status
- **Status:** `[Implemented]`

```
GET /api/surveys/pending
```
**Purpose:** List pending surveys for admin review
- **Authentication:** Required (Admin role)
- **Response:** Array of survey objects with review status
- **Status:** `[Implemented]`

### API Standards
- **RESTful Design:** Standard HTTP methods and status codes
- **JSON Responses:** Consistent response format across all endpoints
- **Error Handling:** Standardized error responses with detailed messages
- **Validation:** Request/response validation using Pydantic models
- **Documentation:** Auto-generated OpenAPI/Swagger documentation

---

## 🤖 External Service Integration

### Google Gemini AI Integration
- **Service:** AI image analysis for room classification
- **Implementation:** REST API calls to Google Gemini Vision API
- **Data Flow:** Survey images → Gemini analysis → FICM room type suggestions
- **Error Handling:** Fallback to manual classification on API failures
- **Rate Limiting:** Configured to respect API limits and retry policies

### File Storage Integration
- **Service:** S3-compatible object storage for survey images
- **Implementation:** S3 API for image upload, retrieval, and management
- **Security:** Pre-signed URLs for secure image access
- **Organization:** Tenant-isolated storage with structured paths

---

## 🛠️ Development Workflow

### Database Migrations
After changing a SQLAlchemy model in `apps/backend/src/spacewalker/models/`:

```bash
# 1. Generate a new migration script
just backend_alembic_revision "Your descriptive message"

# 2. Apply the migration to the local database
just backend_alembic_upgrade
```

### API Development
- **FastAPI Framework:** Modern Python web framework with automatic OpenAPI generation
- **SQLAlchemy ORM:** Database modeling with automatic relationship management
- **Alembic Migrations:** Version-controlled database schema evolution
- **Pydantic Validation:** Request/response validation and serialization

### Testing Strategy
- **Unit Tests:** Service layer and business logic validation
- **Integration Tests:** Database and external service interaction testing
- **API Tests:** Endpoint validation with realistic request/response cycles
- **Database Tests:** Migration and schema validation

---

## 📚 Related Documentation

### Implementation Details
- **[Backend Development Guide](../development/README.md)** - Development setup, coding standards, and implementation patterns
- **[API Testing Guide](../../workflows/testing-guide.md)** - Testing strategies and test data management

### System Integration
- **[Mobile Architecture](../../mobile/architecture/README.md)** - Mobile client integration with backend APIs
- **[Admin Architecture](../../admin/architecture/README.md)** - Admin dashboard integration with backend services

### Workflow Resources
- **[Development Setup](../../setup/development-setup.md)** - Backend development environment configuration
- **[Deployment Guide](../../workflows/deployment-guide.md)** - Backend deployment and infrastructure setup
- **[FICM Specifications](../../setup/environment-configuration.md)** - Room classification standards implemented in backend

### Troubleshooting
- **[Troubleshooting Guide](../../workflows/troubleshooting-guide.md)** - Backend service diagnostics and problem resolution
- **[Database Issues](../../gotchas/)** - Common database and backend configuration problems

---

**Status**: ✅ Updated and current as of 2025-06-29. Extracted from comprehensive PRD and enhanced with backend-specific architecture details and cross-references.
