# API Contract Specification

## Purpose
Comprehensive REST API contract definition for Spacewalker's FastAPI backend service including authentication, endpoints, and response formats.

## When to Use This
- Implementing new API endpoints in FastAPI
- Understanding authentication and authorization patterns
- Debugging API integration issues
- Keywords: REST API, FastAPI, JWT authentication, endpoint specification, OpenAPI

**Version:** 2.2
**Last Updated:** 2024-12-26
**Status:** Implemented & In Review

## Key Concepts
- **FastAPI Framework**: Auto-generated OpenAPI documentation and validation
- **JWT Authentication**: Bearer token authentication with 24-hour expiration
- **Versioned API**: URL path versioning for backward compatibility
- **Standardized Errors**: Consistent error response format across all endpoints

## API Configuration

### Base Configuration
- **Base URL (Dev):** `http://localhost:8000/api/v1`
- **Authentication:** JWT Bearer Tokens (24-hour expiration)
- **Content Type:** `application/json`
- **Interactive Docs (Swagger):** `http://localhost:8000/docs` (when running locally)
- **OpenAPI Schema:** `http://localhost:8000/openapi.json`

### Authentication Implementation

Authentication is handled via JWT tokens with the following pattern:

```http
POST /api/v1/auth/token
Content-Type: application/x-www-form-urlencoded

username=admin@demo.university.edu&password=demo123

# Success Response (200 OK)
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

**Implementation Details:**
- **JWT Expiration**: 24 hours
- **Source Code**: [`apps/backend/src/spacecargo/api/routers/auth.py`](../../../apps/backend/src/spacecargo/api/routers/auth.py)
- **Token Usage**: Include in `Authorization: Bearer <token>` header for protected endpoints

## Core API Endpoints

For complete and interactive endpoint documentation, refer to the **[Swagger Documentation](http://localhost:8000/docs)**.

### Survey Management
- **`POST /api/v1/surveys`** `[Implemented]`
  - **Description:** Submits a new room survey
  - **Request Body Model:** [`SurveyCreate`](../../../apps/backend/src/spacecargo/api/routers/surveys.py)
  - **Source:** [`apps/backend/src/spacecargo/api/routers/surveys.py`](../../../apps/backend/src/spacecargo/api/routers/surveys.py)

- **`GET /api/v1/surveys/pending`** `[Implemented]`
  - **Description:** Retrieves paginated list of surveys awaiting review
  - **Response Model:** `Page[SurveyRead]`
  - **Source:** [`apps/backend/src/spacecargo/api/routers/surveys.py`](../../../apps/backend/src/spacecargo/api/routers/surveys.py)

### Building & Room Management
- **`GET /api/v1/buildings`** `[Implemented]`
  - **Description:** Retrieves buildings list for current tenant
  - **Response Model:** `list[BuildingRead]`
  - **Source:** [`apps/backend/src/spacecargo/api/routers/buildings.py`](../../../apps/backend/src/spacecargo/api/routers/buildings.py)

- **`GET /api/v1/rooms/{room_id}`** `[Implemented]`
  - **Description:** Retrieves detailed room information
  - **Response Model:** `RoomRead`
  - **Source:** [`apps/backend/src/spacecargo/api/routers/rooms.py`](../../../apps/backend/src/spacecargo/api/routers/rooms.py)

## Error Response Standards

All `4xx` and `5xx` status codes follow standardized error response format:

```json
// Example: 404 Not Found
{
  "detail": "Survey with ID 999 not found."
}

// Example: 422 Unprocessable Entity (Validation Error)
{
  "detail": [
    {
      "loc": [
        "body",
        "room_id"
      ],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

## API Versioning Strategy

- **Current Version**: v1 (URL path: `/api/v1/...`)
- **Breaking Changes**: New version path (e.g., `/api/v2/...`)
- **Backward Compatibility**: Previous versions maintained until deprecation
- **Version Headers**: Not currently implemented, using URL path versioning

## Future Enhancements

### Rate Limiting `[Planned]`
Rate limiting implementation planned for future releases:
- **Response Code**: `429 Too Many Requests`
- **Headers**: `Retry-After` with wait time
- **Strategy**: Per-user token bucket or sliding window

## Related Documentation
- Backend Architecture → ../backend/architecture/README.md
- API Development Guide → ../development/create-endpoint.md
- Authentication Implementation → ./auth-flow.md
- Error Handling Patterns → ../operations/debugging.md

---
Last Updated: 2025-06-28
Status: Current
