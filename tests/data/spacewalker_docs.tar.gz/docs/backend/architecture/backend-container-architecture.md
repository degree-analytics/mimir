# Backend Container Architecture

## Purpose
Detailed architecture documentation for the backend containers in the Spacewalker system, including FastAPI service design, PostgreSQL database patterns, S3 file storage integration, and external service connections. Essential reference for backend developers working on server-side architecture and infrastructure.

## When to Use This
- Designing backend services and API architecture
- Understanding database schema and data persistence patterns
- Implementing file storage and external service integrations
- Planning backend scaling and performance optimizations
- Troubleshooting backend container interactions and data flow
- Keywords: FastAPI architecture, PostgreSQL design, S3 integration, backend containers, server architecture

**Version:** 2.0 (Extracted from system container documentation)
**Date:** 2025-06-29
**Status:** Current - Production Backend Architecture

---

## 🏗️ Backend Container Overview

> 📊 **System Context**: See [System Container Overview](../../architecture/system-container-overview.md) for complete system architecture and container relationships

The backend containers form the core service layer of the Spacewalker system, providing secure API access, business logic processing, data persistence, and external service orchestration.

### Backend Container Architecture
```
External APIs → Backend API → Database Layer → File Storage
     ↓              ↓              ↓              ↓
Google Gemini → FastAPI Service → PostgreSQL → S3 Storage
     ↓              ↓              ↓              ↓
AI Analysis ← Business Logic ← Data Models ← File Management
```

---

## ⚙️ Backend API Container

### Technology Stack
- **Framework**: FastAPI 0.115.6 with Python 3.12
- **ORM**: SQLAlchemy 2.0 with async support
- **Authentication**: JWT-based stateless authentication
- **Validation**: Pydantic models for request/response validation
- **Documentation**: Automatic OpenAPI/Swagger generation

### Container Responsibilities
- **API Gateway** - Secure entry point for all client requests
- **Authentication & Authorization** - JWT validation and role-based access control
- **Business Logic** - Survey processing, validation, and workflow orchestration
- **External Integrations** - Google Gemini API and email service coordination
- **Data Orchestration** - Database operations and file storage management

### Internal Architecture Pattern
```python
# FastAPI Service Architecture
FastAPI Application
├── API Routes Layer          # HTTP request handling
│   ├── Authentication routes
│   ├── Survey CRUD routes
│   └── Admin management routes
├── Business Services Layer   # Core business logic
│   ├── Survey processing service
│   ├── AI analysis service
│   └── User management service
└── Data Access Layer        # Database and storage
    ├── SQLAlchemy models
    ├── Database sessions
    └── File storage operations
```

### API Design Patterns
- **RESTful Endpoints** - Standard HTTP methods with resource-based URLs
- **Request Validation** - Pydantic models enforce data contracts
- **Response Serialization** - Consistent JSON response formatting
- **Error Handling** - Standardized error codes and user-friendly messages
- **API Versioning** - Path-based versioning for backward compatibility

### Security Architecture
```python
# Authentication & Authorization Flow
@router.post("/api/surveys")
async def create_survey(
    survey_data: SurveyCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # JWT validation → User context → Business logic → Database operation
    return await survey_service.create_survey(survey_data, current_user, db)
```

---

## 🗄️ PostgreSQL Database Container

### Technology Configuration
- **Database**: PostgreSQL 17
- **Connection**: SQLAlchemy async with connection pooling
- **Security**: Row-Level Security (RLS) for multi-tenancy
- **Performance**: Optimized indexes and query patterns
- **Migration**: Alembic for schema versioning

### Database Architecture
```sql
-- Core Data Model Structure
Users → Organizations → Buildings → Surveys → Analysis Results
  ↓          ↓             ↓          ↓           ↓
Roles → Permissions → Locations → Photos → AI Insights
```

### Key Schema Patterns
- **Multi-Tenancy** - Row-Level Security for data isolation
- **Audit Trails** - Created/updated timestamps on all entities
- **Soft Deletion** - Logical deletion with deleted_at columns
- **JSON Flexibility** - JSONB columns for dynamic survey data
- **Relationship Integrity** - Foreign key constraints and cascading rules

### Data Security Implementation
```sql
-- Row-Level Security for Multi-Tenancy
ALTER TABLE surveys ENABLE ROW LEVEL SECURITY;

CREATE POLICY survey_tenant_isolation ON surveys
    FOR ALL TO application_role
    USING (organization_id = current_setting('app.current_organization_id'));
```

### Performance Optimization
- **Connection Pooling** - Optimized pool size for concurrent requests
- **Query Optimization** - Strategic indexing and query planning
- **Bulk Operations** - Efficient batch processing for large datasets
- **Caching Strategy** - Application-level caching for frequently accessed data

### Database Deployment Configuration
```yaml
# Docker Compose Database Configuration
postgres:
  image: postgres:17
  environment:
    POSTGRES_DB: spacewalker
    POSTGRES_USER: ${DB_USER}
    POSTGRES_PASSWORD: ${DB_PASSWORD}
  volumes:
    - postgres_data:/var/lib/postgresql/data
    - ./docker/postgres/init.sql:/docker-entrypoint-initdb.d/init.sql
  ports:
    - "5432:5432"
```

---

## 📁 File Storage Container

### Technology Stack
- **Storage**: S3-compatible object store (AWS S3, MinIO)
- **Access**: Signed URLs for secure file access
- **Integration**: AWS SDK or S3-compatible client library
- **Processing**: Image optimization and thumbnail generation
- **Lifecycle**: Automated cleanup and archival policies

### Storage Architecture Patterns
```
Survey Images → Backend Upload → S3 Storage → CDN Distribution
     ↓              ↓              ↓              ↓
Client Upload → Signed URL → Object Storage → Public Access
     ↓              ↓              ↓              ↓
Metadata DB ← File Reference ← Storage Key ← URL Generation
```

### File Management Features
- **Secure Upload** - Pre-signed URLs for direct client uploads
- **Access Control** - Temporary access URLs with expiration
- **Image Processing** - Automatic thumbnail and optimization
- **Storage Lifecycle** - Automated archival and cleanup policies
- **CDN Integration** - Content delivery network for global distribution

### File Storage Implementation
```python
# S3 Service Integration
class FileStorageService:
    async def generate_upload_url(self, file_name: str, file_type: str) -> str:
        """Generate pre-signed URL for secure file upload"""
        return s3_client.generate_presigned_url(
            'put_object',
            Params={'Bucket': BUCKET_NAME, 'Key': file_name, 'ContentType': file_type},
            ExpiresIn=3600  # 1 hour expiration
        )

    async def get_file_url(self, file_key: str) -> str:
        """Generate temporary access URL for file download"""
        return s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': BUCKET_NAME, 'Key': file_key},
            ExpiresIn=900  # 15 minutes expiration
        )
```

---

## 🤖 External Service Integrations

### Google Gemini API Integration
- **Purpose** - AI-powered image analysis for survey processing
- **Authentication** - API key-based authentication
- **Rate Limiting** - Request throttling and retry logic
- **Error Handling** - Graceful degradation when service unavailable
- **Response Processing** - Structured data extraction from AI responses

### Email Service Integration
- **Purpose** - Notification delivery and user communication
- **Protocol** - SMTP with TLS encryption
- **Templates** - HTML email templates for different notification types
- **Queue Management** - Asynchronous email processing with retry logic
- **Delivery Tracking** - Status monitoring and bounce handling

### External Integration Patterns
```python
# External Service Orchestration
class SurveyProcessingService:
    async def process_survey_submission(self, survey: Survey) -> ProcessingResult:
        # 1. Validate survey data
        validation_result = await self.validate_survey(survey)

        # 2. Process images with AI
        if survey.images:
            ai_analysis = await gemini_service.analyze_images(survey.images)
            survey.ai_analysis = ai_analysis

        # 3. Save to database
        await db_service.save_survey(survey)

        # 4. Send notifications
        await email_service.send_survey_confirmation(survey.user, survey)

        return ProcessingResult(status="completed", survey_id=survey.id)
```

---

## 🔧 Container Configuration & Deployment

### Environment Configuration
```bash
# Backend API Environment Variables
DATABASE_URL=postgresql+asyncpg://user:pass@postgres:5432/spacewalker
S3_BUCKET_NAME=spacewalker-files
S3_ENDPOINT_URL=http://minio:9000
GEMINI_API_KEY=your-api-key
JWT_SECRET_KEY=your-secret-key
CORS_ORIGINS=http://localhost:3000,https://admin.spacewalker.com
```

### Docker Configuration
```dockerfile
# Backend API Dockerfile
FROM python:3.12-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY src/ ./src/
COPY alembic/ ./alembic/

# Run application
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Container Orchestration
```yaml
# Docker Compose Backend Services
version: '3.8'
services:
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql+asyncpg://user:pass@postgres:5432/spacewalker
      - S3_ENDPOINT_URL=http://minio:9000
    depends_on:
      - postgres
      - minio
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  postgres:
    image: postgres:17
    environment:
      POSTGRES_DB: spacewalker
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data

  minio:
    image: minio/minio:latest
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: ${MINIO_USER}
      MINIO_ROOT_PASSWORD: ${MINIO_PASSWORD}
    volumes:
      - minio_data:/data
```

---

## 📊 Backend Performance & Monitoring

### Performance Metrics
- **API Response Times** - Monitor endpoint latency and throughput
- **Database Performance** - Query execution time and connection pool usage
- **File Upload Speed** - S3 upload/download performance monitoring
- **External API Latency** - Google Gemini API response time tracking

### Health Monitoring
```python
# Health Check Endpoints
@router.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow(),
        "database": await check_database_health(),
        "storage": await check_storage_health(),
        "external_apis": await check_external_apis_health()
    }
```

### Logging & Observability
- **Structured Logging** - JSON-formatted logs with correlation IDs
- **Error Tracking** - Comprehensive error logging with stack traces
- **Performance Monitoring** - Request timing and resource utilization
- **Security Auditing** - Authentication and authorization event logging

---

## 🧪 Backend Testing Strategies

### Unit Testing
```python
# FastAPI Endpoint Testing
@pytest.mark.asyncio
async def test_create_survey_endpoint():
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post(
            "/api/surveys",
            json={"title": "Test Survey", "description": "Test"},
            headers={"Authorization": f"Bearer {test_token}"}
        )
    assert response.status_code == 201
    assert "id" in response.json()
```

### Integration Testing
```python
# Database Integration Testing
@pytest.mark.asyncio
async def test_survey_database_operations():
    async with AsyncSession(test_engine) as session:
        # Test survey creation
        survey = Survey(title="Integration Test", user_id=test_user.id)
        session.add(survey)
        await session.commit()

        # Test survey retrieval
        result = await session.get(Survey, survey.id)
        assert result.title == "Integration Test"
```

### External Service Testing
```python
# Mock External Services
@pytest.fixture
def mock_gemini_service():
    with patch('src.services.gemini_service.GeminiService') as mock:
        mock.return_value.analyze_images.return_value = {
            "confidence": 0.95,
            "analysis": "Test analysis result"
        }
        yield mock
```

---

## 📋 Related Backend Documentation

### Implementation Details
> 🚀 **Backend API**: See [Backend API Components](../api-components.md) for detailed component architecture and implementation patterns
> 🚀 **Database Design**: See [Database Schema](../database-design.md) for complete data model and relationship documentation

### Development Resources
- **[Backend Development Setup](../../setup/development-setup.md)** - Development environment configuration
- **[API Testing Guide](../../workflows/testing-guide.md)** - Comprehensive testing strategies for backend services
- **[Database Migration Guide](../../backend/database-migrations.md)** - Schema versioning and deployment procedures

### System Architecture Context
- **[System Container Overview](../../architecture/system-container-overview.md)** - Complete system architecture with all container relationships
- **[Component Architecture](../../architecture/component-diagrams.md)** - Detailed component relationships within backend containers

---

**Status**: ✅ **PRODUCTION BACKEND ARCHITECTURE**
**Last Updated**: 2025-06-29
**Container Scope**: Backend API, PostgreSQL Database, S3 File Storage
**Technology Stack**: FastAPI, PostgreSQL, S3, Google Gemini API

---

*This backend container architecture documentation provides comprehensive guidance for developers working on server-side services, ensuring consistent patterns and scalable design across all backend components.*
