# RLS Policy Decision Trees and Visual Guide

## Overview
This document provides visual representations and detailed decision trees for the Row-Level Security (RLS) policies implemented in the Spacewalker platform. It complements the [complete RLS architecture documentation](rls-architecture-complete.md) with focused visual aids.

## Table of Contents
1. [RLS Policy Decision Tree](#1-rls-policy-decision-tree)
2. [Request Lifecycle Flow](#2-request-lifecycle-flow)
3. [CRUD Operation Policies](#3-crud-operation-policies)
4. [Hierarchical Access Patterns](#4-hierarchical-access-patterns)
5. [Performance Decision Matrix](#5-performance-decision-matrix)

---

## 1. RLS Policy Decision Tree

The following diagram shows how RLS policies evaluate access permissions:

```mermaid
graph TD
    A["🔐 RLS Policy<br/>Decision Tree"] --> B{"🔑 Super User Check<br/>get_current_tenant_id() = -1?"}

    B -->|YES| C["✅ ALLOW<br/>(All Data Access)<br/>Super User Bypass"]
    B -->|NO| D{"👤 User Context<br/>Check"}

    D --> E{"🏢 Tenant Match<br/>record.tenant_id =<br/>get_current_tenant_id()?"}

    E -->|YES| F["✅ ALLOW<br/>(Tenant Data)<br/>Normal Access"]
    E -->|NO| G["❌ DENY<br/>(Access Forbidden)<br/>Cross-Tenant Block"]

    H["📊 CRUD Operations"] --> I["SELECT Policy"]
    H --> J["INSERT Policy"]
    H --> K["UPDATE Policy"]
    H --> L["DELETE Policy"]

    I --> B
    J --> M{"🔍 INSERT Check<br/>WITH CHECK<br/>tenant_id = current?"}
    K --> B
    L --> B

    M -->|YES| N["✅ ALLOW INSERT<br/>Correct Tenant"]
    M -->|NO| O["❌ DENY INSERT<br/>Wrong Tenant"]

    style C fill:#d4edda,stroke:#28a745,stroke-width:2px
    style F fill:#d4edda,stroke:#28a745,stroke-width:2px
    style N fill:#d4edda,stroke:#28a745,stroke-width:2px
    style G fill:#f8d7da,stroke:#dc3545,stroke-width:2px
    style O fill:#f8d7da,stroke:#dc3545,stroke-width:2px
    style A fill:#e3f2fd,stroke:#1976d2,stroke-width:3px
```

### Decision Logic Explanation

1. **Super User Check**: First evaluation checks if `get_current_tenant_id() = -1`
   - If YES: Grant full access (super user bypass)
   - If NO: Continue to tenant-specific evaluation

2. **Tenant Context Evaluation**: Compare record's tenant_id with current session context
   - If MATCH: Grant access to tenant-scoped data
   - If NO MATCH: Deny access (cross-tenant protection)

3. **CRUD-Specific Logic**: Each operation type has specific validation
   - **SELECT/UPDATE/DELETE**: Use `USING` clause for row visibility
   - **INSERT**: Use `WITH CHECK` clause for data insertion validation

---

## 2. Request Lifecycle Flow

The complete request lifecycle showing RLS integration:

```mermaid
graph TD
    A["🌐 HTTP Request<br/>with JWT Token"] --> B["🔐 TenantMiddleware"]

    B --> C["🎫 JWT Decode"]
    C --> D{"🔑 Extract Context<br/>tenant_id, user_id<br/>is_super_user"}

    D --> E{"👑 Superuser Check<br/>X-Selected-Tenant-Id<br/>Header Present?"}

    E -->|YES| F["🔄 Tenant Switch<br/>Override Context"]
    E -->|NO| G["📝 Set Standard Context"]

    F --> H["📊 Audit Log<br/>Tenant Switch Event"]
    G --> I["📝 ContextVar Storage"]
    H --> I

    I --> J["🗄️ Database Connection<br/>Checkout Event"]

    J --> K["🔧 Set Session Variables<br/>app.current_tenant_id<br/>app.current_user_id"]

    K --> L["🛡️ PostgreSQL RLS<br/>Policy Evaluation"]

    L --> M{"🏢 Query Execution<br/>with RLS Filtering"}

    M --> N["📄 Tenant-Filtered<br/>Response Data"]

    N --> O["🧹 Connection Checkin<br/>Clear Session Context"]

    O --> P["🎯 HTTP Response<br/>to Client"]

    Q["⚠️ Error Handling"] --> R["🔄 Context Reset<br/>Safe Fallback State"]
    R --> S["📝 Error Logging"]

    style A fill:#e3f2fd,stroke:#1976d2,stroke-width:2px
    style B fill:#fff3e0,stroke:#f57c00,stroke-width:2px
    style L fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px
    style P fill:#e8f5e8,stroke:#4caf50,stroke-width:2px
    style Q fill:#ffebee,stroke:#f44336,stroke-width:2px
```

### Key Lifecycle Stages

1. **Authentication Layer**: JWT processing and context extraction
2. **Middleware Layer**: Tenant context management and superuser handling
3. **Database Layer**: Session variable setting and RLS policy enforcement
4. **Response Layer**: Tenant-filtered data delivery with context cleanup

---

## 3. CRUD Operation Policies

### 3.1 Policy Types and Conditions

| Operation | Policy Type | Condition Logic | Purpose |
|-----------|-------------|-----------------|---------|
| SELECT | `USING` | `tenant_id = get_current_tenant_id() OR get_current_tenant_id() = -1` | Row visibility filtering |
| INSERT | `WITH CHECK` | `tenant_id = get_current_tenant_id() OR get_current_tenant_id() = -1` | Insertion validation |
| UPDATE | `USING` | `tenant_id = get_current_tenant_id() OR get_current_tenant_id() = -1` | Update permission check |
| DELETE | `USING` | `tenant_id = get_current_tenant_id() OR get_current_tenant_id() = -1` | Delete permission check |

### 3.2 Policy Examples by Table Type

#### Direct Tenant Tables
Tables with direct `tenant_id` columns use straightforward policies:

```sql
-- tenant_audit_logs (direct tenant_id)
CREATE POLICY tenant_audit_logs_select ON tenant_audit_logs
FOR SELECT TO CURRENT_USER
USING (
    get_current_tenant_id() = -1 OR
    tenant_id = get_current_tenant_id()
);
```

#### Hierarchical Tables
Tables inheriting tenant context through relationships:

```sql
-- floors (inherits through buildings.tenant_id)
CREATE POLICY floors_select ON floors
FOR SELECT TO CURRENT_USER
USING (
    get_current_tenant_id() = -1 OR
    EXISTS (
        SELECT 1 FROM buildings b
        WHERE b.id = floors.building_id
        AND b.tenant_id = get_current_tenant_id()
    )
);
```

---

## 4. Hierarchical Access Patterns

### 4.1 Tenant Inheritance Hierarchy

```
┌─────────────────────────────────────┐
│           Tenant Context            │
│        (Primary Isolation)          │
└─────────────────┬───────────────────┘
                  │
    ┌─────────────▼─────────────┐
    │      Buildings Table      │
    │   (tenant_id column)      │
    └─────────────┬─────────────┘
                  │ 1:N
    ┌─────────────▼─────────────┐
    │       Floors Table        │
    │  (building_id FK only)    │
    └─────────────┬─────────────┘
                  │ 1:N
    ┌─────────────▼─────────────┐
    │       Rooms Table         │
    │   (floor_id FK only)      │
    └───────────────────────────┘
```

### 4.2 Inheritance Policy Pattern

```sql
-- Rooms inherit tenant context through floors → buildings
CREATE POLICY rooms_select ON rooms
FOR SELECT TO CURRENT_USER
USING (
    get_current_tenant_id() = -1 OR
    EXISTS (
        SELECT 1 FROM floors f
        JOIN buildings b ON b.id = f.building_id
        WHERE f.id = rooms.floor_id
        AND b.tenant_id = get_current_tenant_id()
    )
);
```

### 4.3 Performance Impact by Depth

| Hierarchy Level | Query Complexity | Avg Performance | Index Requirements |
|-----------------|------------------|-----------------|-------------------|
| Direct (tenant_id) | Simple equality | 2.2ms | tenant_id index |
| 1-Level (floors) | EXISTS + 1 JOIN | 8.5ms | building_id index |
| 2-Level (rooms) | EXISTS + 2 JOINs | 12.3ms | floor_id + building_id indexes |

---

## 5. Performance Decision Matrix

### 5.1 Query Performance by Pattern

| Access Pattern | RLS Overhead | Optimization Strategy | Performance Rating |
|----------------|--------------|----------------------|-------------------|
| Direct tenant_id | <5% | Single column index | ⭐⭐⭐⭐⭐ Excellent |
| 1-Level inheritance | ~10% | FK index + EXISTS optimization | ⭐⭐⭐⭐ Good |
| 2-Level inheritance | ~15% | Multi-column indexes | ⭐⭐⭐ Acceptable |
| Complex JOINs | ~20% | Query rewriting needed | ⭐⭐ Requires attention |

### 5.2 Optimization Decision Tree

```
Query Performance Analysis
        │
        ▼
┌─────────────────┐
│ Identify Table  │
│ Hierarchy Depth │
└─────────┬───────┘
          │
    ┌─────▼─────┐
    │   Direct  │
    │ tenant_id?│
    └─────┬─────┘
          │
   ┌──────┴──────┐
   │YES          │NO
   ▼             ▼
┌─────────┐  ┌─────────────┐
│ Standard│  │ Hierarchical│
│ Index   │  │ Strategy    │
│ Only    │  │ Needed      │
└─────────┘  └─────┬───────┘
                   │
            ┌──────▼──────┐
            │ 1-Level or  │
            │ 2-Level?    │
            └──────┬──────┘
                   │
         ┌─────────┴─────────┐
         │1-Level           │2-Level
         ▼                   ▼
   ┌──────────┐       ┌─────────────┐
   │ EXISTS + │       │ Double JOIN │
   │ FK Index │       │ + Multi-Key │
   │          │       │ Indexes     │
   └──────────┘       └─────────────┘
```

### 5.3 Index Strategy Recommendations

#### High Performance (Direct tenant_id)
```sql
CREATE INDEX IF NOT EXISTS idx_{table}_tenant_id ON {table} (tenant_id);
-- Expected overhead: <5%
-- Recommended for: All tables with direct tenant relationships
```

#### Good Performance (1-Level inheritance)
```sql
CREATE INDEX IF NOT EXISTS idx_{child_table}_{fk_column} ON {child_table} ({fk_column});
-- Expected overhead: ~10%
-- Recommended for: floors, direct foreign key relationships
```

#### Acceptable Performance (2-Level inheritance)
```sql
CREATE INDEX IF NOT EXISTS idx_{table}_composite ON {table} ({fk_column_1}, {fk_column_2});
-- Expected overhead: ~15%
-- Recommended for: rooms, complex hierarchical relationships
```

---

## Usage Guidelines

### When to Use This Document
- Understanding RLS policy evaluation logic
- Troubleshooting access control issues
- Optimizing query performance with RLS
- Designing new tenant-scoped features
- Training developers on RLS architecture

### Integration with Main Documentation
This document provides visual aids for the comprehensive [RLS Architecture Guide](rls-architecture-complete.md). Use both documents together for complete understanding.

### Related Resources
- [ADR-006: RLS-Only Architecture](../../architecture/adr-006-rls-only-tenant-isolation.md)
- [SECURITY DEFINER Functions](../../development/security-definer-functions.md)
- [Security Implementation Guide](security-implementation.md)

---

**Last Updated**: 2025-08-24
**Related Task**: 2.5 - Document RLS Architecture and Policy Decision Trees
**Status**: Complete
