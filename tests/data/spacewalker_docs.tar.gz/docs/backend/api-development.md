# Backend API Development Guide

## Purpose
Comprehensive development guide for the FastAPI backend in the Spacewalker system, covering patterns, best practices, and implementation details for building robust, secure, and maintainable API endpoints. Essential reference for backend developers working on server-side architecture and API design.

## When to Use This
- Developing new FastAPI endpoints and routers
- Implementing authentication and authorization patterns
- Setting up request validation and response serialization
- Following backend development best practices and patterns
- Testing backend API functionality and error handling
- Keywords: FastAPI development, API patterns, backend architecture, authentication, validation

**Version:** 2.3 (Reorganized from implementation documentation)
**Date:** 2025-06-29
**Status:** Current - Production API Development Guide

---

## 🏗️ Backend API Architecture Overview

The Spacewalker backend API is built using FastAPI with a modular, resource-based architecture that emphasizes type safety, automatic validation, and comprehensive documentation generation.

### Core Architecture Principles
- **Resource-Based Organization** - API endpoints organized into logical routers by resource type
- **Dependency Injection** - Extensive use of FastAPI's dependency system for database sessions and authentication
- **Type Safety** - Comprehensive Pydantic models for request validation and response serialization
- **Automatic Documentation** - OpenAPI/Swagger documentation generated automatically from code
- **Security First** - JWT-based authentication with role-based access control

---

## 🔧 Router Patterns and Organization

### Router Structure and Naming

All API endpoints are organized into routers based on their resource domain, providing clear separation of concerns and maintainable code organization.

**Location**: `apps/backend/src/spacecargo/api/routers/`

#### Router Naming Conventions
- **Resource-Based**: Routers named after the resource they manage (e.g., `surveys.py`, `buildings.py`)
- **Plural Resources**: Use plural forms for consistency (`users.py`, not `user.py`)
- **Clear Inclusion**: Each router must be included in the main `api.py` router aggregator
- **Logical Grouping**: Related endpoints grouped together within each router

### Example Router Implementation

```python
# apps/backend/src/spacecargo/api/routers/surveys.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from spacecargo.db import get_db
from spacecargo.models import survey_models
from spacecargo.api.auth import get_current_user

router = APIRouter(prefix="/surveys", tags=["surveys"])

@router.get("/", response_model=List[survey_models.SurveyRead])
async def read_surveys(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Retrieve all surveys for the authenticated user's tenant.

    Returns:
        List of surveys with associated metadata and status
    """
    surveys = await survey_service.get_surveys_for_tenant(
        db, current_user.tenant_id
    )
    return surveys

@router.post("/", response_model=survey_models.SurveyRead, status_code=201)
async def create_survey(
    survey_data: survey_models.SurveyCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Create a new survey for the specified room.

    Args:
        survey_data: Survey creation data including room_id and metadata

    Returns:
        Created survey with generated ID and timestamps
    """
    new_survey = await survey_service.create_survey(
        db, survey_data, current_user
    )
    return new_survey
```

### Router Registration

```python
# apps/backend/src/spacecargo/api/api.py
from fastapi import APIRouter
from .routers import surveys, buildings, users, auth

api_router = APIRouter(prefix="/api/v1")

api_router.include_router(auth.router, prefix="/auth", tags=["authentication"])
api_router.include_router(surveys.router, prefix="/surveys", tags=["surveys"])
api_router.include_router(buildings.router, prefix="/buildings", tags=["buildings"])
api_router.include_router(users.router, prefix="/users", tags=["users"])
```

---

## 💉 Dependency Injection Patterns

FastAPI's dependency injection system is extensively used for managing cross-cutting concerns like database sessions, authentication, and authorization.

### Database Session Management

The primary use case for dependency injection is providing SQLAlchemy database sessions with proper lifecycle management.

```python
# apps/backend/src/spacecargo/db.py
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

async def get_db() -> AsyncSession:
    """
    Dependency that provides a database session for the request.

    Automatically handles:
    - Session creation and configuration
    - Transaction management
    - Session cleanup after request completion
    - Connection pooling optimization
    """
    async with async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

# Usage in endpoints
@router.get("/items")
async def get_items(db: AsyncSession = Depends(get_db)):
    """The db session is automatically managed by the dependency."""
    items = await db.execute(select(Item))
    return items.scalars().all()
```

### Advanced Dependency Patterns

#### Cached Dependencies
```python
from functools import lru_cache

@lru_cache()
def get_settings():
    """Cached dependency for application settings."""
    return Settings()

@router.get("/config")
def get_config(settings: Settings = Depends(get_settings)):
    return {"environment": settings.environment}
```

#### Conditional Dependencies
```python
def get_admin_user(current_user: User = Depends(get_current_user)):
    """Dependency that ensures user has admin privileges."""
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

@router.delete("/users/{user_id}")
async def delete_user(
    user_id: str,
    admin_user: User = Depends(get_admin_user)
):
    """Only admin users can delete other users."""
    await user_service.delete_user(user_id)
```

---

## 🔐 Authentication and Authorization

### JWT Bearer Token Authentication

The API uses stateless JWT authentication with comprehensive user context and role-based access control.

```python
# apps/backend/src/spacecargo/api/auth.py
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from sqlalchemy.ext.asyncio import AsyncSession

security = HTTPBearer()

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
) -> User:
    """
    Dependency that validates JWT token and returns authenticated user.

    Validates:
    - Token signature and expiration
    - User existence in database
    - Tenant context and permissions
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = jwt.decode(
            credentials.credentials,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        user_id: str = payload.get("sub")
        tenant_id: str = payload.get("tenant_id")

        if user_id is None or tenant_id is None:
            raise credentials_exception

    except JWTError:
        raise credentials_exception

    user = await user_service.get_user(db, user_id=user_id)
    if user is None or user.tenant_id != tenant_id:
        raise credentials_exception

    return user
```

### Role-Based Access Control

```python
from enum import Enum

class UserRole(str, Enum):
    ADMIN = "admin"
    MANAGER = "manager"
    SURVEYOR = "surveyor"
    VIEWER = "viewer"

def require_role(required_role: UserRole):
    """Dependency factory for role-based access control."""
    def role_checker(current_user: User = Depends(get_current_user)):
        if current_user.role != required_role:
            raise HTTPException(
                status_code=403,
                detail=f"Access denied. {required_role} role required."
            )
        return current_user
    return role_checker

# Usage in protected endpoints
@router.post("/surveys/{survey_id}/approve")
async def approve_survey(
    survey_id: str,
    manager: User = Depends(require_role(UserRole.MANAGER))
):
    """Only managers can approve surveys."""
    await survey_service.approve_survey(survey_id, manager.id)
```

---

## ✅ Request Validation with Pydantic

FastAPI uses Pydantic models for automatic request validation, providing type safety and comprehensive error messages.

### Pydantic Model Patterns

#### Create Models
```python
# apps/backend/src/spacecargo/models/survey_models.py
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime

class SurveyCreate(BaseModel):
    """Model for survey creation requests."""
    room_id: str = Field(..., description="ID of the room being surveyed")
    notes: Optional[str] = Field(None, max_length=1000, description="Optional survey notes")
    survey_type: str = Field(..., description="Type of survey being conducted")
    images: Optional[List[str]] = Field(default_factory=list, description="List of image URLs")

    @validator('survey_type')
    def validate_survey_type(cls, v):
        allowed_types = ['initial', 'follow_up', 'inspection']
        if v not in allowed_types:
            raise ValueError(f'Survey type must be one of: {allowed_types}')
        return v

    @validator('images')
    def validate_images(cls, v):
        if v and len(v) > 10:
            raise ValueError('Maximum 10 images allowed per survey')
        return v

class SurveyUpdate(BaseModel):
    """Model for survey update requests."""
    notes: Optional[str] = Field(None, max_length=1000)
    status: Optional[str] = Field(None)
    completion_date: Optional[datetime] = Field(None)

    class Config:
        # Allow partial updates with only provided fields
        extra = "forbid"
```

#### Response Models
```python
class SurveyRead(BaseModel):
    """Model for survey response serialization."""
    id: str
    room_id: str
    user_id: str
    tenant_id: str
    survey_type: str
    status: str
    notes: Optional[str]
    created_at: datetime
    updated_at: datetime
    completion_date: Optional[datetime]

    # Related data
    room: Optional['RoomRead'] = None
    user: Optional['UserRead'] = None
    images: List['SurveyImageRead'] = []

    class Config:
        orm_mode = True  # Enable SQLAlchemy model compatibility
        allow_population_by_field_name = True
```

### Advanced Validation Patterns

#### Custom Validators
```python
from pydantic import root_validator

class BuildingCreate(BaseModel):
    name: str
    address: str
    floors: int = Field(ge=1, le=200, description="Number of floors (1-200)")

    @root_validator
    def validate_building_data(cls, values):
        """Cross-field validation for building creation."""
        name = values.get('name')
        address = values.get('address')

        if name and len(name.strip()) < 2:
            raise ValueError('Building name must be at least 2 characters')

        if address and 'P.O. Box' in address:
            raise ValueError('Physical address required, P.O. Box not allowed')

        return values
```

---

## 📤 Response Serialization Patterns

### ORM Integration with Pydantic

```python
# SQLAlchemy model
class Survey(Base):
    __tablename__ = "surveys"

    id = Column(String, primary_key=True)
    room_id = Column(String, ForeignKey("rooms.id"))
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    room = relationship("Room", back_populates="surveys")
    images = relationship("SurveyImage", back_populates="survey")

# Endpoint with automatic serialization
@router.get("/surveys/{survey_id}", response_model=SurveyRead)
async def get_survey(
    survey_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    The returned SQLAlchemy Survey object is automatically
    serialized to the SurveyRead model, with relationship data included.
    """
    survey = await survey_service.get_survey_with_relations(
        db, survey_id, current_user.tenant_id
    )
    if not survey:
        raise HTTPException(status_code=404, detail="Survey not found")
    return survey
```

### Custom Response Models

```python
from pydantic import computed_field

class SurveyStatistics(BaseModel):
    """Advanced response model with computed fields."""
    total_surveys: int
    completed_surveys: int
    pending_surveys: int
    completion_rate: float

    @computed_field
    @property
    def completion_percentage(self) -> str:
        """Format completion rate as percentage string."""
        return f"{self.completion_rate:.1%}"

@router.get("/surveys/stats", response_model=SurveyStatistics)
async def get_survey_statistics(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Return comprehensive survey statistics."""
    stats = await survey_service.get_tenant_statistics(
        db, current_user.tenant_id
    )
    return SurveyStatistics(**stats)
```

---

## ⚠️ Error Handling and Exception Management

### Standard HTTP Exceptions

```python
from fastapi import HTTPException, status

@router.get("/surveys/{survey_id}")
async def get_survey(survey_id: str):
    """Standard error handling with HTTP exceptions."""
    survey = await survey_service.get_survey(survey_id)

    if not survey:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Survey with ID {survey_id} not found",
            headers={"X-Error": "RESOURCE_NOT_FOUND"}
        )

    if not survey.is_accessible_by_user(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this survey"
        )

    return survey
```

### Custom Exception Handlers

```python
# apps/backend/src/spacecargo/exceptions.py
class SpacecargoException(Exception):
    """Base exception for application-specific errors."""
    def __init__(self, message: str, error_code: str = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)

class TenantAccessDenied(SpacecargoException):
    """Raised when user attempts to access another tenant's data."""
    pass

class SurveyValidationError(SpacecargoException):
    """Raised when survey data validation fails."""
    pass

# apps/backend/src/spacecargo/main.py
from fastapi import Request
from fastapi.responses import JSONResponse

@app.exception_handler(TenantAccessDenied)
async def tenant_access_denied_handler(request: Request, exc: TenantAccessDenied):
    return JSONResponse(
        status_code=403,
        content={
            "detail": exc.message,
            "error_code": "TENANT_ACCESS_DENIED",
            "timestamp": datetime.utcnow().isoformat()
        }
    )

@app.exception_handler(SurveyValidationError)
async def survey_validation_error_handler(request: Request, exc: SurveyValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "detail": exc.message,
            "error_code": "SURVEY_VALIDATION_ERROR",
            "timestamp": datetime.utcnow().isoformat()
        }
    )
```

---

## 🧪 API Testing Patterns

### Testing Infrastructure

```python
# apps/backend/tests/conftest.py
import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from spacecargo.main import app
from spacecargo.db import get_db
from spacecargo.models.base import Base

@pytest.fixture
async def test_db():
    """Create test database with Testcontainers."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async_session = sessionmaker(engine, class_=AsyncSession)

    async with async_session() as session:
        yield session

@pytest.fixture
def client(test_db):
    """FastAPI test client with dependency overrides."""
    def override_get_db():
        yield test_db

    app.dependency_overrides[get_db] = override_get_db

    with TestClient(app) as c:
        yield c

    app.dependency_overrides.clear()
```

### Endpoint Testing Examples

```python
# apps/backend/tests/test_surveys.py
import pytest
from fastapi import status

class TestSurveyEndpoints:
    """Comprehensive survey endpoint testing."""

    async def test_create_survey_success(self, client, authenticated_user):
        """Test successful survey creation."""
        survey_data = {
            "room_id": "room-123",
            "survey_type": "initial",
            "notes": "Test survey notes"
        }

        response = client.post(
            "/api/v1/surveys/",
            json=survey_data,
            headers={"Authorization": f"Bearer {authenticated_user.token}"}
        )

        assert response.status_code == status.HTTP_201_CREATED

        survey = response.json()
        assert survey["room_id"] == survey_data["room_id"]
        assert survey["survey_type"] == survey_data["survey_type"]
        assert survey["status"] == "draft"
        assert "id" in survey
        assert "created_at" in survey

    async def test_create_survey_validation_error(self, client, authenticated_user):
        """Test survey creation with validation errors."""
        invalid_data = {
            "room_id": "",  # Invalid: empty room_id
            "survey_type": "invalid_type",  # Invalid: not in allowed types
            "notes": "x" * 1001  # Invalid: exceeds max length
        }

        response = client.post(
            "/api/v1/surveys/",
            json=invalid_data,
            headers={"Authorization": f"Bearer {authenticated_user.token}"}
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

        error_detail = response.json()["detail"]
        assert any("room_id" in error["loc"] for error in error_detail)
        assert any("survey_type" in error["loc"] for error in error_detail)

    async def test_get_survey_unauthorized(self, client):
        """Test survey access without authentication."""
        response = client.get("/api/v1/surveys/survey-123")
        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    async def test_get_survey_cross_tenant_access_denied(self, client, other_tenant_survey):
        """Test that users cannot access surveys from other tenants."""
        response = client.get(
            f"/api/v1/surveys/{other_tenant_survey.id}",
            headers={"Authorization": f"Bearer {authenticated_user.token}"}
        )
        assert response.status_code == status.HTTP_403_FORBIDDEN
```

### Integration Testing

```python
# apps/backend/tests/test_integration.py
class TestSurveyWorkflow:
    """End-to-end survey workflow testing."""

    async def test_complete_survey_workflow(self, client, authenticated_user):
        """Test complete survey creation, update, and completion workflow."""

        # 1. Create survey
        create_response = client.post(
            "/api/v1/surveys/",
            json={"room_id": "room-123", "survey_type": "initial"},
            headers={"Authorization": f"Bearer {authenticated_user.token}"}
        )
        assert create_response.status_code == 201
        survey_id = create_response.json()["id"]

        # 2. Add images to survey
        image_response = client.post(
            f"/api/v1/surveys/{survey_id}/images",
            json={"image_urls": ["https://example.com/image1.jpg"]},
            headers={"Authorization": f"Bearer {authenticated_user.token}"}
        )
        assert image_response.status_code == 200

        # 3. Update survey status
        update_response = client.patch(
            f"/api/v1/surveys/{survey_id}",
            json={"status": "completed", "notes": "Survey completed successfully"},
            headers={"Authorization": f"Bearer {authenticated_user.token}"}
        )
        assert update_response.status_code == 200

        # 4. Verify final state
        final_survey = update_response.json()
        assert final_survey["status"] == "completed"
        assert final_survey["notes"] == "Survey completed successfully"
        assert len(final_survey["images"]) == 1
```

---

## 📋 Related Backend Development Documentation

### Architecture and Design
> 🚀 **Database Design**: See [Database Design](./database-design.md) for comprehensive database schema and SQLAlchemy model documentation
> 🚀 **API Components**: See [API Components](./api-components.md) for detailed component architecture and service layer patterns
> 🚀 **Tenant Management**: See [Tenant Management](./tenant-management.md) for multi-tenant patterns and AttributeService implementation

### AttributeService
The AttributeService provides centralized management of attribute definitions across tenants. It handles the initialization of standard attribute categories (Building, Room, Survey, etc.) and ensures consistent attribute schemas throughout the system. Key features include:

- **Tenant-specific attribute initialization**: Each tenant gets standardized attribute definitions
- **41 standard attributes across 7 categories**: Comprehensive attribute coverage for all entity types
- **Automatic schema validation**: Ensures attribute definitions meet system requirements
- **Bulk initialization support**: Efficient setup of complete attribute sets for new tenants

For implementation details, see the [Tenant Management](./tenant-management.md) documentation.

### Development Workflows
- **[Development Setup](../setup/development-setup.md)** - Complete development environment configuration for backend work
- **[Testing Guide](../workflows/testing-guide.md)** - Comprehensive testing strategies for backend services and endpoints
- **[Database Migrations](./database-migrations.md)** - Database-specific development patterns and migration procedures

---

**Status**: ✅ **PRODUCTION API DEVELOPMENT GUIDE**
**Last Updated**: 2025-06-29
**Scope**: FastAPI Development, Authentication, Validation, Testing, Error Handling
**Technology Stack**: FastAPI, SQLAlchemy, Pydantic, JWT Authentication

---

*This API development guide provides comprehensive patterns and best practices for building robust, secure, and maintainable FastAPI backends, ensuring consistent development practices across all Spacewalker backend services.*
