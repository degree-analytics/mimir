# Tenant Management System Guide

## Purpose
Comprehensive guide for implementing multi-tenant architecture in the Spacewalker backend, covering Row Level Security (RLS), tenant isolation patterns, role-based access control, and tenant provisioning workflows. Essential reference for backend developers working on multi-tenancy, data isolation, and tenant lifecycle management.

## When to Use This
- Implementing tenant-aware database models and RLS policies
- Understanding tenant isolation patterns and security boundaries
- Setting up role-based access control and tenant permissions
- Configuring tenant provisioning and member management workflows
- Working with session context and tenant middleware
- Keywords: multi-tenancy, tenant isolation, RLS, tenant roles, tenant provisioning

**Version:** 1.0 (Initial comprehensive implementation guide)
**Date:** 2025-07-10
**Status:** Current - Production Multi-Tenancy Architecture

---

## 🏗️ Multi-Tenancy Architecture Overview

The Spacewalker multi-tenancy system implements a **shared database, isolated data** architecture using PostgreSQL Row Level Security (RLS) to ensure complete data separation between tenants. This design provides strong security guarantees while maintaining operational efficiency and cost-effectiveness.

### Core Architecture Principles
- **Database-Level Isolation** - PostgreSQL RLS policies enforce tenant boundaries at the database level
- **Session Context Management** - Tenant ID stored in session variables for automatic policy enforcement
- **Role-Based Access Control** - Granular permissions within tenant boundaries
- **Tenant Lifecycle Management** - Complete tenant provisioning, configuration, and deprovisioning workflows
- **Security-First Design** - Multiple validation layers to prevent cross-tenant data access

---

## 🔒 Row Level Security Implementation

### Database Session Functions

The foundation of tenant isolation relies on PostgreSQL session functions that manage tenant context:

**Location**: `apps/backend/src/spacewalker/migrations/versions/11a60a9d6337_implement_row_level_security_for_tenant_.py`

#### Session Context Functions

```sql
-- Function to set current tenant in session
CREATE OR REPLACE FUNCTION set_current_tenant_id(tenant_id INTEGER)
RETURNS VOID AS $$
BEGIN
    PERFORM set_config('app.current_tenant_id', tenant_id::TEXT, FALSE);
END;
$$ LANGUAGE plpgsql;

-- Function to get current tenant from session
CREATE OR REPLACE FUNCTION get_current_tenant_id()
RETURNS INTEGER AS $$
BEGIN
    RETURN COALESCE(current_setting('app.current_tenant_id', TRUE)::INTEGER, -1);
END;
$$ LANGUAGE plpgsql;
```

**Key Features:**
- **Session Isolation**: Each database connection maintains its own tenant context
- **Automatic Fallback**: Returns -1 for system operations when no tenant is set
- **Transaction Safety**: Session variables persist for the entire database transaction
- **Security Default**: Invalid or missing tenant context defaults to restricted access

### RLS Policy Implementation

#### Tenant-Aware Tables

All tenant-scoped tables have RLS enabled with consistent isolation policies:

```sql
-- Enable RLS on tenant-aware tables
tenant_tables = [
    "users",
    "buildings",
    "surveys",
    "ficm_categories",
    "ficm_base_codes",
    "ficm_design_types",
    "attribute_categories",
    "attribute_definitions",
    "tenant_invitations",
    "tenant_domains"
]

FOR table IN tenant_tables:
    ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;
```

**Note**: `tenant_members` table has been removed in favor of a simplified owner-based tenant model using `owner_id` field on the `tenants` table.

#### Standard RLS Policy Pattern

```sql
-- Standard tenant isolation policy applied to all tenant-aware tables
CREATE POLICY tenant_isolation_policy ON {table_name}
USING (tenant_id = get_current_tenant_id() OR get_current_tenant_id() = -1);
```

**Policy Logic:**
- `tenant_id = get_current_tenant_id()`: Normal tenant-scoped access
- `get_current_tenant_id() = -1`: System operations with elevated access
- **Automatic Enforcement**: Database automatically filters all queries
- **INSERT/UPDATE Protection**: Prevents cross-tenant data creation/modification

#### Special Case: Users Table

```sql
-- Users table allows NULL tenant_id for system users
CREATE POLICY tenant_isolation_policy ON users
USING (tenant_id = get_current_tenant_id() OR get_current_tenant_id() = -1 OR tenant_id IS NULL);
```

**Rationale**: System users (administrators, service accounts) may have `NULL` tenant_id for cross-tenant operations.

---

## 👥 Tenant Data Models

### Core Tenant Models

**Location**: `apps/backend/src/spacewalker/models/tenant_models.py`

#### Tenant Model

```python
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, JSON, Boolean, DateTime
from sqlalchemy.orm import relationship

class Tenant(Base):
    """
    Core tenant model representing an organization or customer
    """
    __tablename__ = "tenants"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    location = Column(JSON, nullable=False)  # Geographic/business location data
    subdomain = Column(String(100), unique=True, nullable=True)  # For multi-tenant URL routing
    config = Column(JSON, default={})  # Tenant-specific configuration
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    # Relationships
    buildings = relationship("Building", back_populates="tenant")
    users = relationship("User", back_populates="tenant")
    domains = relationship("TenantDomain", back_populates="tenant")
    # Owner-based model - check if user owns the tenant
    invitations = relationship("TenantInvitation", back_populates="tenant")
```

#### Tenant Role Enum

```python
import enum

class TenantRole(enum.Enum):
    """Roles within a tenant organization"""

    OWNER = "owner"      # Can delete tenant, transfer ownership
    ADMIN = "admin"      # Can manage users, settings, billing
    MANAGER = "manager"  # Can manage surveys, view all data
    MEMBER = "member"    # Can create/edit own surveys
    VIEWER = "viewer"    # Read-only access
```

#### Tenant Member Model

```python
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum, UniqueConstraint
from sqlalchemy.orm import relationship

# Owner-based tenant model implementation
# The TenantMember model has been replaced with a simple owner_id field on Tenant model
# This provides simplified tenant ownership without complex membership hierarchies

#     __tablename__ = "tenant_members"
#
#     id = Column(Integer, primary_key=True)
#     tenant_id = Column(Integer, ForeignKey("tenants.id"), nullable=False)
#     user_id = Column(String(255), ForeignKey("users.id"), nullable=False)
#     role = Column(Enum(TenantRole), nullable=False, default=TenantRole.MEMBER)
#     joined_at = Column(DateTime, default=datetime.utcnow)
#     invited_by = Column(String(255), ForeignKey("users.id"), nullable=True)
#
#     # Ensure unique user per tenant
#     __table_args__ = (UniqueConstraint("tenant_id", "user_id", name="uq_tenant_user"),)
#
#     # Relationships
#     tenant = relationship("Tenant", back_populates="members")
#     user = relationship("User", foreign_keys=[user_id])
#     inviter = relationship("User", foreign_keys=[invited_by])
```

---

## 🏷️ AttributeService - Tenant Attribute Initialization

### Service Overview

**Location**: `apps/backend/src/spacewalker/services/attribute_service.py`

The AttributeService provides centralized management of tenant-specific attribute definitions and categories. This service ensures that each tenant has a complete set of attribute categories and definitions available for room characterization and data collection.

#### Core Functionality

```python
from spacewalker.services.attribute_service import AttributeService

# Initialize complete attribute system for a tenant
AttributeService.initialize_tenant_attributes(db, tenant_id)
```

**Key Features:**
- **Automatic Initialization**: Creates complete attribute category and definition sets for new tenants
- **Idempotent Operations**: Safe to run multiple times without creating duplicates
- **Standardized Categories**: Ensures consistent attribute categories across all tenants
- **Multi-Tenant Isolation**: Operates within tenant boundaries using RLS policies

### Tenant Attribute Initialization Process

#### 1. Attribute Categories Creation

```python
def initialize_tenant_attributes(db: Session, tenant_id: int) -> None:
    """
    Initialize a complete set of attribute categories and definitions for a tenant.
    This creates the foundation for room attribute collection and management.
    """
    # Create standard attribute categories
    categories = [
        {
            "name": "Physical Characteristics",
            "description": "Physical attributes of the room (dimensions, materials, etc.)",
            "display_order": 1
        },
        {
            "name": "Environmental Conditions",
            "description": "Environmental factors (temperature, humidity, lighting, etc.)",
            "display_order": 2
        },
        {
            "name": "Safety & Security",
            "description": "Safety equipment and security measures",
            "display_order": 3
        },
        {
            "name": "Equipment & Infrastructure",
            "description": "Fixed equipment and infrastructure elements",
            "display_order": 4
        },
        {
            "name": "Usage & Occupancy",
            "description": "Room usage patterns and occupancy information",
            "display_order": 5
        }
    ]

    for category_data in categories:
        # Check if category already exists for this tenant
        existing = db.query(AttributeCategory).filter(
            AttributeCategory.tenant_id == tenant_id,
            AttributeCategory.name == category_data["name"]
        ).first()

        if not existing:
            category = AttributeCategory(
                tenant_id=tenant_id,
                **category_data
            )
            db.add(category)

    db.flush()  # Ensure categories are available for definitions
```

#### 2. Attribute Definitions Creation

```python
    # Create comprehensive attribute definitions for each category
    definitions = [
        # Physical Characteristics
        {
            "category_name": "Physical Characteristics",
            "name": "Room Area (sq ft)",
            "data_type": AttributeDataType.NUMBER,
            "validation_rules": {"min": 1, "max": 10000},
            "is_required": True
        },
        {
            "category_name": "Physical Characteristics",
            "name": "Ceiling Height (ft)",
            "data_type": AttributeDataType.NUMBER,
            "validation_rules": {"min": 6, "max": 30},
            "is_required": False
        },

        # Environmental Conditions
        {
            "category_name": "Environmental Conditions",
            "name": "Natural Light Level",
            "data_type": AttributeDataType.SELECT,
            "validation_rules": {
                "options": ["Excellent", "Good", "Fair", "Poor", "None"]
            },
            "is_required": False
        },

        # Safety & Security
        {
            "category_name": "Safety & Security",
            "name": "Fire Suppression System",
            "data_type": AttributeDataType.SELECT,
            "validation_rules": {
                "options": ["Sprinkler", "Suppression Gas", "Fire Extinguisher", "None"]
            },
            "is_required": False
        },

        # Equipment & Infrastructure
        {
            "category_name": "Equipment & Infrastructure",
            "name": "HVAC System Type",
            "data_type": AttributeDataType.SELECT,
            "validation_rules": {
                "options": ["Central Air", "Mini-Split", "Window Units", "Radiant", "None"]
            },
            "is_required": False
        },

        # Usage & Occupancy
        {
            "category_name": "Usage & Occupancy",
            "name": "Primary Function",
            "data_type": AttributeDataType.SELECT,
            "validation_rules": {
                "options": [
                    "Office", "Classroom", "Laboratory", "Storage",
                    "Conference Room", "Common Area", "Utility", "Other"
                ]
            },
            "is_required": True
        }
    ]

    for def_data in definitions:
        category = db.query(AttributeCategory).filter(
            AttributeCategory.tenant_id == tenant_id,
            AttributeCategory.name == def_data["category_name"]
        ).first()

        if category:
            # Check if definition already exists
            existing = db.query(AttributeDefinition).filter(
                AttributeDefinition.tenant_id == tenant_id,
                AttributeDefinition.category_id == category.id,
                AttributeDefinition.name == def_data["name"]
            ).first()

            if not existing:
                definition = AttributeDefinition(
                    tenant_id=tenant_id,
                    category_id=category.id,
                    name=def_data["name"],
                    data_type=def_data["data_type"],
                    validation_rules=def_data["validation_rules"],
                    is_required=def_data["is_required"]
                )
                db.add(definition)

    db.commit()
```

### Integration with Tenant Creation

The AttributeService is automatically called during tenant provisioning workflows:

#### 1. Admin Tenant Creation
```python
# In apps/backend/src/spacewalker/api/routers/tenants.py
@router.post("/", response_model=TenantResponse, status_code=201)
def create_tenant(tenant: TenantCreate, db: Session = Depends(get_db)):
    # Create tenant
    db_tenant = Tenant(name=tenant.name, ...)
    db.add(db_tenant)
    db.commit()

    # Initialize tenant-specific data
    AttributeService.initialize_tenant_attributes(db, db_tenant.id)
    FICMService.ensure_ficm_codes_exist(db, db_tenant.id)
```

#### 2. Self-Service Tenant Creation
```python
@router.post("/self-service", response_model=TenantResponse)
def create_tenant_self_service(tenant: TenantCreateSelfService, db: Session = Depends(get_db)):
    # Create tenant and membership atomically
    db_tenant = Tenant(name=tenant.name, ...)
    db.add(db_tenant)
    db.flush()

    # Initialize tenant-specific data
    AttributeService.initialize_tenant_attributes(db, db_tenant.id)
    FICMService.ensure_ficm_codes_exist(db, db_tenant.id)
```

#### 3. Demo Tenant Creation
```python
# In apps/backend/src/spacewalker/scripts/database/seed_demo_comprehensive.py
def create_demo_tenant(db: Session) -> int:
    # Create demo tenant
    tenant = Tenant(name="Demo University", subdomain="demo", ...)
    db.add(tenant)
    db.flush()

    # Initialize attribute system for demo tenant
    AttributeService.initialize_tenant_attributes(db, tenant.id)
    logger.info("  ✅ Attribute definitions initialized")

    return tenant.id
```

### Validation and Inspection

#### Database Commands for Attribute Inspection

```bash
# Inspect attribute setup for demo tenant
just db_inspect_attributes

# Inspect attributes for specific tenant ID
just db_inspect_attributes tenant_id=123

# Demo tenant debugging workflow (includes attribute inspection)
just db_demo_debug
```

#### Validation Queries

```sql
-- Check attribute categories for tenant
SELECT
    ac.name as category,
    ac.description,
    COUNT(ad.id) as definition_count
FROM attribute_categories ac
LEFT JOIN attribute_definitions ad ON ac.id = ad.category_id
WHERE ac.tenant_id = :tenant_id
GROUP BY ac.id, ac.name, ac.description
ORDER BY ac.display_order;

-- Check attribute definitions by category
SELECT
    ac.name as category,
    ad.name as attribute,
    ad.data_type,
    ad.is_required,
    ad.validation_rules
FROM attribute_definitions ad
JOIN attribute_categories ac ON ad.category_id = ac.id
WHERE ad.tenant_id = :tenant_id
ORDER BY ac.display_order, ad.name;
```

### Error Handling and Recovery

#### Common Issues and Solutions

1. **Missing Attribute Categories**
   - **Symptom**: Room attribute collection fails or shows empty category lists
   - **Solution**: Run `AttributeService.initialize_tenant_attributes(db, tenant_id)` to create missing categories

2. **Incomplete Attribute Definitions**
   - **Symptom**: Some attribute types are missing from room forms
   - **Solution**: Re-run initialization process (idempotent - won't create duplicates)

3. **Cross-Tenant Attribute Access**
   - **Symptom**: RLS policy violations when accessing attributes
   - **Solution**: Ensure proper tenant context is set before attribute operations

#### Recovery Procedures

```python
# Manual attribute initialization for existing tenant
def recover_tenant_attributes(tenant_id: int):
    db = SessionLocal()
    try:
        # Set tenant context for RLS
        db.execute(text("SELECT set_current_tenant_id(:tenant_id)"), {"tenant_id": tenant_id})

        # Initialize attributes (idempotent)
        AttributeService.initialize_tenant_attributes(db, tenant_id)

        logger.info(f"Attribute recovery completed for tenant {tenant_id}")
    except Exception as e:
        logger.error(f"Attribute recovery failed for tenant {tenant_id}: {e}")
        db.rollback()
        raise
    finally:
        db.close()
```

---

## 🏛️ System Default Tenant

### Overview

The **System Default tenant** (ID: 1) is a special tenant that serves as the platform-level tenant for system operations, development testing, and administrative functions. Unlike regular tenants, it provides a controlled environment for developers and administrators to test platform features without affecting production tenant data.

### Characteristics

- **Tenant ID**: Always `1` (first tenant in the system)
- **Name**: "System Default" (by convention)
- **Purpose**: Platform-level operations and development testing
- **Isolation**: Follows same RLS policies as regular tenants
- **Attributes**: Requires full attribute initialization for testing attribute functionality

### Use Cases

1. **Development Testing**
   - Test attribute collection and management features
   - Validate room survey functionality
   - Test admin interface components

2. **Platform Operations**
   - System-level administrative tasks
   - Cross-tenant reporting and analytics
   - Platform maintenance operations

3. **Quality Assurance**
   - Feature validation before tenant deployment
   - Integration testing across system components
   - Performance testing with realistic attribute data

### Initialization Requirements

The System Default tenant requires the same initialization as regular tenants to function properly:

#### 1. Attribute System Initialization

```python
# Initialize System Default tenant attributes
from spacewalker.api.services.attribute_service import AttributeService

# Find System Default tenant (ID: 1)
system_tenant = db.query(Tenant).filter(Tenant.id == 1).first()

if system_tenant:
    # Initialize complete attribute system
    AttributeService.initialize_tenant_attributes(db, system_tenant.id)
    print("✅ System Default tenant attributes initialized")
```

#### 2. FICM Code Initialization

```python
# Ensure FICM codes are available for System Default tenant
from spacewalker.services.ficm_service import FICMService

FICMService.ensure_ficm_codes_exist(db, system_tenant.id)
print("✅ System Default tenant FICM codes initialized")
```

### Management Commands

#### Local Development

```bash
# Initialize System Default tenant attributes (LOCAL)
just db_init_system_attributes

# Results:
# ✅ Found System Default: System Default (ID: 1)
# ✅ System Default attributes initialized successfully
# ✅ All 41 standard attributes across 7 categories now available
```

#### Cloud Environments

```bash
# Initialize System Default tenant attributes (CLOUD)
just aws_init_system_attributes dev   # For development environment
just aws_init_system_attributes prod  # For production environment

# Results:
# ✅ System Default attribute initialization completed successfully!
# ✅ System Default tenant now has all 41 standard attributes
# ✅ Developers can now test attribute functionality in admin interface
```

### Validation and Inspection

#### Check System Default Tenant Status

```bash
# Inspect System Default tenant attributes
just db_inspect_attributes tenant_id=1

# View all tenants including System Default
just db verify
```

#### Manual Validation Queries

```sql
-- Check if System Default tenant exists
SELECT id, name, subdomain, created_at, is_active
FROM tenants
WHERE id = 1;

-- Check attribute initialization status
SELECT
    ac.name as category,
    COUNT(ad.id) as definition_count
FROM attribute_categories ac
LEFT JOIN attribute_definitions ad ON ac.id = ad.category_id
WHERE ac.tenant_id = 1
GROUP BY ac.id, ac.name
ORDER BY ac.display_order;

-- Verify FICM codes are available
SELECT category, COUNT(*) as code_count
FROM ficm_base_codes
WHERE tenant_id = 1
GROUP BY category;
```

## 🧪 Testing and Verification

### Post-Installation Verification

After running attribute initialization commands, verify the setup using these comprehensive tests:

#### 1. Database Verification (Local Development)

```bash
# Start local services
just up

# Run the attribute initialization
just db_init_system_attributes

# Verify initialization success
just db shell
```

```sql
-- In database shell, verify all 41 attributes are present
SELECT
    ac.name as category,
    COUNT(ad.id) as definition_count,
    STRING_AGG(ad.name, ', ' ORDER BY ad.display_order) as attributes
FROM attribute_categories ac
LEFT JOIN attribute_definitions ad ON ac.id = ad.category_id
WHERE ac.tenant_id = 1
GROUP BY ac.id, ac.name
ORDER BY ac.display_order;

-- Expected results:
-- Building: 5 attributes
-- Room: 8 attributes
-- Survey: 6 attributes
-- User: 4 attributes
-- Tenant: 3 attributes
-- System: 7 attributes
-- Custom: 8 attributes
-- Total: 41 attributes

-- Verify System Default tenant exists and is active
SELECT id, name, subdomain, is_active, created_at
FROM tenants
WHERE id = 1;

-- Should return: 1 | System Default | system | t | <timestamp>
```

#### 2. Admin Interface Verification

```bash
# Access admin interface
just admin_dev  # Opens http://localhost:3000

# Verification steps in admin interface:
# 1. Login with system admin credentials
# 2. Navigate to Settings → Attributes
# 3. Verify all 7 categories are visible
# 4. Check that each category contains the expected number of attributes
# 5. Test creating a new building - attribute dropdowns should be populated
```

#### 3. Cloud Environment Verification

```bash
# For development environment
just aws_init_system_attributes dev

# Verify cloud deployment
just health dev
just aws_logs dev

# Check ECS task succeeded
aws ecs describe-tasks --cluster dev-spacewalker-ecs-cluster --tasks <task_arn>
```

#### 4. API Endpoint Verification

```bash
# Test attribute endpoints directly
curl -X GET "https://backend.spacewalker.littleponies.com/api/v1/attributes/categories" \
  -H "Authorization: Bearer <token>"

# Expected response: Array of 7 categories with attribute definitions
```

### Verification Checklist

Before considering attribute initialization complete, verify:

- [ ] **Database**: All 41 attributes across 7 categories are present in `attribute_definitions` table
- [ ] **System Default Tenant**: Tenant ID 1 exists and is active
- [ ] **Category Counts**: Each category has the expected number of attributes
- [ ] **Admin Interface**: Attribute dropdowns are populated in building/room creation forms
- [ ] **API Endpoints**: Attribute endpoints return complete data
- [ ] **Cloud Environment**: ECS task completed successfully (for cloud deployments)
- [ ] **Error Handling**: No error messages in application logs

### Automated Verification Script

```bash
#!/bin/bash
# File: scripts/verify-attributes.sh

echo "🔍 Verifying attribute initialization..."

# Check database
ATTR_COUNT=$(psql $DATABASE_URL -t -c "SELECT COUNT(*) FROM attribute_definitions WHERE tenant_id = 1;")
if [ "$ATTR_COUNT" -eq 41 ]; then
    echo "✅ Database: All 41 attributes present"
else
    echo "❌ Database: Expected 41 attributes, found $ATTR_COUNT"
    exit 1
fi

# Check categories
CATEGORY_COUNT=$(psql $DATABASE_URL -t -c "SELECT COUNT(*) FROM attribute_categories WHERE tenant_id = 1;")
if [ "$CATEGORY_COUNT" -eq 7 ]; then
    echo "✅ Database: All 7 categories present"
else
    echo "❌ Database: Expected 7 categories, found $CATEGORY_COUNT"
    exit 1
fi

# Check System Default tenant
TENANT_EXISTS=$(psql $DATABASE_URL -t -c "SELECT COUNT(*) FROM tenants WHERE id = 1 AND is_active = true;")
if [ "$TENANT_EXISTS" -eq 1 ]; then
    echo "✅ System Default tenant exists and is active"
else
    echo "❌ System Default tenant not found or inactive"
    exit 1
fi

echo "✅ All verification checks passed!"
```

### Security Considerations

#### Access Control

1. **RLS Enforcement**: System Default tenant follows standard RLS policies
2. **User Assignment**: Only authorized users should have access
3. **Audit Logging**: All operations are logged for security monitoring

#### Development Best Practices

```python
# Always use proper tenant context when working with System Default tenant
from spacewalker.api.context import set_current_tenant_id

# Set System Default tenant context
set_current_tenant_id(1)

# Perform operations - RLS will enforce tenant isolation
buildings = db.query(Building).all()
```

### Troubleshooting

#### Common Issues

1. **Missing Attributes**
   - **Symptom**: Empty attribute lists in admin interface
   - **Solution**: Run `just db_init_system_attributes` or `just aws_init_system_attributes dev`

2. **Incomplete Initialization**
   - **Symptom**: Some attribute categories missing
   - **Solution**: Re-run initialization commands (idempotent operations)

3. **RLS Policy Conflicts**
   - **Symptom**: Cross-tenant access errors
   - **Solution**: Ensure proper tenant context is set before operations

#### Recovery Procedures

```bash
# Complete System Default tenant recovery
just db_init_system_attributes          # Initialize attributes
just db_demo_debug                      # Validate overall system health
just db_inspect_attributes tenant_id=1  # Verify attribute initialization
```

### Integration with Development Workflows

The System Default tenant plays a crucial role in development and testing workflows:

1. **Admin Interface Testing**: Developers can test attribute functionality
2. **Feature Validation**: New features are validated against System Default tenant
3. **CI/CD Pipeline**: Automated tests run against System Default tenant
4. **Performance Testing**: Load testing uses System Default tenant data

---

## 🚀 Tenant Provisioning Workflows

### Tenant Creation Process

**Location**: `apps/backend/src/spacewalker/api/routers/tenants.py`

#### 1. New Tenant Registration (Router-Based)

```python
@router.post("/", response_model=TenantResponse, status_code=201)
def create_tenant(
    tenant: TenantCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Create a new tenant (admin only)"""
    # Check if subdomain is already taken
    if tenant.subdomain:
        existing = db.query(Tenant).filter(Tenant.subdomain == tenant.subdomain).first()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Subdomain already in use",
            )

    # Create tenant
    db_tenant = Tenant(
        name=tenant.name,
        location=tenant.location,
        subdomain=tenant.subdomain,
        config=tenant.config or {},
    )
    db.add(db_tenant)
    db.commit()
    db.refresh(db_tenant)

    # Initialize tenant-specific data
    AttributeService.initialize_tenant_attributes(db, db_tenant.id)
    FICMService.ensure_ficm_codes_exist(db, db_tenant.id)

    # Return with counts (all zero for new tenant)
    return TenantResponse(
        id=db_tenant.id,
        name=db_tenant.name,
        location=db_tenant.location,
        subdomain=db_tenant.subdomain,
        config=db_tenant.config,
        is_active=db_tenant.is_active,
        created_at=db_tenant.created_at,
        user_count=0,
        building_count=0,
        room_count=0,
    )
```

#### 2. Self-Service Tenant Creation

```python
@router.post("/self-service", response_model=TenantResponse)
def create_tenant_self_service(
    tenant: TenantCreateSelfService,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Create a new tenant (self-service) - user becomes owner"""
    # Start transaction for atomic operations
    try:
        # Check if subdomain is already taken
        existing = db.query(Tenant).filter(Tenant.subdomain == tenant.subdomain).first()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Subdomain already in use"
            )

        # Owner-based model - check if user owns the tenant
        # Check if user already owns a tenant
        # from spacewalker.models.tenant_models import TenantMember, TenantRole
        #
        # existing_owner = (
        #     db.query(TenantMember)
        #     .filter(
        #         TenantMember.user_id == current_user.id,
        #         TenantMember.role == TenantRole.OWNER,
        #     )
        #     .first()
        # )

        if existing_owner:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="You already own a tenant organization",
            )

        # Create tenant with owner membership in transaction
        db_tenant = Tenant(
            name=tenant.name,
            location=tenant.location,
            subdomain=tenant.subdomain,
            config={},
        )
        db.add(db_tenant)
        db.flush()  # Get the tenant ID

        # Owner-based model - check if user owns the tenant
        # Make user the owner
        # member = TenantMember(
        #     tenant_id=db_tenant.id, user_id=current_user.id, role=TenantRole.OWNER
        # )
        db.add(member)
        current_user.tenant_id = db_tenant.id

        # Initialize tenant-specific data
        AttributeService.initialize_tenant_attributes(db, db_tenant.id)
        FICMService.ensure_ficm_codes_exist(db, db_tenant.id)

        # Log tenant creation for audit trail
        log_tenant_action(
            tenant_id=db_tenant.id,
            user_id=current_user.id,
            action="create",
            resource_type="tenant",
            resource_id=db_tenant.id,
            details={"subdomain": tenant.subdomain, "self_service": True},
            db=db
        )

        # Commit all changes atomically
        db.commit()

    except Exception as e:
        db.rollback()
        raise e

    return TenantResponse(
        id=db_tenant.id,
        name=db_tenant.name,
        location=db_tenant.location,
        subdomain=db_tenant.subdomain,
        config=db_tenant.config,
        is_active=db_tenant.is_active,
        created_at=db_tenant.created_at,
        user_count=1,
        building_count=0,
        room_count=0,
    )
```

### Member Management

#### Owner-Based Tenant Management

Tenant ownership is managed through a simplified owner-based model in `apps/backend/src/spacecargo/api/routers/tenants.py`. Each tenant has a single owner referenced by the `owner_id` field in the Tenant model:

```python
# Tenant model with owner-based structure
class Tenant(Base):
    __tablename__ = "tenants"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    owner_id = Column(String(255), ForeignKey("users.id"), nullable=True, index=True)
    # ... other fields

    # Relationships
    owner = relationship("User", foreign_keys=[owner_id])
    users = relationship("User", back_populates="tenant", foreign_keys=[User.tenant_id])
```

#### Permission Hierarchy and Validation

The system implements a three-tier permission hierarchy for tenant access:

```python
def _check_tenant_ownership(user: User, tenant_id: int, db: Session) -> None:
    """Check if user has permission to modify tenant (owner, admin, or superuser)"""
    # 1. Superuser can access any tenant
    if user.is_super_user:
        return

    # 2. Admin can access any tenant
    if user.is_admin:
        return

    # 3. Check if user is the owner of the specific tenant
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(404, "Tenant not found")

    if tenant.owner_id == user.id:
        return

    # No sufficient permissions
    raise HTTPException(403, "You can only access tenants you own")
```

#### JWT Token Integration

The authentication system includes `is_owner` claims in JWT tokens for efficient permission checking:

```python
# JWT token creation includes owner status
token_data = {
    "sub": user.email,
    "user_id": user.id,
    "tenant_id": user.tenant_id,
    "is_admin": user.is_admin,
    "is_super_user": user.is_super_user,
    "is_owner": user_result.get("is_owner", False) or False,
    # ... other claims
}
```

This allows for efficient permission checks without database queries:

```python
# Permission validation using JWT claims
is_owner = token_data.get("is_owner", False)
if not is_owner:
    raise HTTPException(403, "Owner permissions required")
```

#### Ownership Transfer

While the current system supports single-owner tenants, ownership can be transferred by updating the `owner_id` field. This operation requires superuser or admin privileges to prevent unauthorized ownership changes.

**Note**: The owner-based model eliminates the complexity of the previous TenantMember role system while maintaining clear permission boundaries through the Superuser → Admin → Owner hierarchy.

---

## 🔐 Session Context Management

### ContextVar-Based Tenant Context

**Implementation**: `apps/backend/src/spacewalker/api/context/tenant_context.py`

The system uses Python's ContextVar for thread-safe, async-compatible tenant isolation:

```python
from contextvars import ContextVar
from typing import Optional

# Global ContextVar for storing the current tenant ID
current_tenant_id: ContextVar[Optional[int]] = ContextVar(
    "current_tenant_id", default=None
)

def get_current_tenant_id() -> Optional[int]:
    """Get the current tenant ID from the context"""
    return current_tenant_id.get()

def set_current_tenant_id(tenant_id: Optional[int]) -> None:
    """Set the current tenant ID in the context"""
    current_tenant_id.set(tenant_id)

class TenantContextManager:
    """Context manager for temporarily setting tenant context"""

    def __init__(self, tenant_id: Optional[int]):
        self.tenant_id = tenant_id
        self.token = None

    def __enter__(self):
        self.token = current_tenant_id.set(self.tenant_id)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token is not None:
            current_tenant_id.reset(self.token)

def with_tenant_context(tenant_id: Optional[int]):
    """Context manager for setting tenant context"""
    return TenantContextManager(tenant_id)
```

### Usage in API Endpoints

```python
# Usage with context manager
with with_tenant_context(123):
    # All database operations here will use tenant_id=123
    buildings = db.query(Building).all()

# Usage in router dependencies
from spacewalker.api.context import set_current_tenant_id

@router.get("/buildings")
def get_buildings(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    set_current_tenant_id(current_user.tenant_id)
    buildings = db.query(Building).all()
    return buildings
```

### JWT Token Integration

**Implementation**: `apps/backend/src/spacewalker/api/routers/auth.py`

```python
def get_current_tenant_id(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    x_selected_tenant_id: Optional[str] = Header(None),
    request: Request = None
) -> int:
    """Get the tenant ID from the current user or selected tenant header"""
    # Super users can select any tenant via header
    if current_user.is_super_user and x_selected_tenant_id:
        try:
            selected_tenant_id = int(x_selected_tenant_id)
            # Verify tenant exists
            tenant = db.query(Tenant).filter(Tenant.id == selected_tenant_id).first()
            if tenant:
                # Log super user tenant context switch for security monitoring
                log_tenant_action(
                    tenant_id=selected_tenant_id,
                    user_id=current_user.id,
                    action="context_switch",
                    resource_type="tenant",
                    resource_id=selected_tenant_id,
                    details={
                        "super_user": True,
                        "original_tenant": current_user.tenant_id,
                        "selected_tenant": selected_tenant_id
                    },
                    request=request,
                    db=db
                )
                return selected_tenant_id
        except (ValueError, TypeError):
            pass

    # Regular users use their assigned tenant
    if not current_user.tenant_id:
        raise HTTPException(
            status_code=403,
            detail="User is not associated with any tenant"
        )

    return current_user.tenant_id
```

### Tenant Context Setup in Endpoints

```python
from spacewalker.api.routers.auth import get_current_tenant_id
from spacewalker.api.context import set_current_tenant_id

@router.get("/buildings")
def get_buildings(
    tenant_id: int = Depends(get_current_tenant_id),
    db: Session = Depends(get_db)
):
    """Get buildings for current tenant with automatic RLS enforcement"""
    set_current_tenant_id(tenant_id)
    buildings = db.query(Building).all()  # RLS automatically filters by tenant
    return buildings
```

---

## 🛡️ Security Patterns and Best Practices

### Cross-Tenant Data Protection

#### 1. Query Validation
```python
from fastapi import HTTPException
from sqlalchemy.orm import Session
from spacewalker.models.database import Building

def validate_tenant_access(
    resource_tenant_id: int,
    current_tenant_id: int
) -> None:
    """
    Ensure resource belongs to current tenant
    """
    if resource_tenant_id != current_tenant_id:
        raise HTTPException(403, "Cross-tenant access denied")

# Usage in services
def get_building(building_id: int, tenant_id: int, db: Session) -> Building:
    building = db.query(Building).filter(Building.id == building_id).first()
    if not building:
        raise HTTPException(404, "Building not found")

    validate_tenant_access(building.tenant_id, tenant_id)
    return building
```

#### 2. API Endpoint Security
```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from spacewalker.api.routers.auth import get_current_tenant_id
from spacewalker.api.context import set_current_tenant_id
from spacewalker.models.database import Building

router = APIRouter()

@router.get("/buildings/{building_id}")
def get_building_endpoint(
    building_id: int,
    tenant_id: int = Depends(get_current_tenant_id),
    db: Session = Depends(get_db)
):
    """Tenant-isolated building retrieval"""
    # Set tenant context for RLS enforcement
    set_current_tenant_id(tenant_id)

    # RLS automatically enforces tenant isolation
    building = db.query(Building).filter(Building.id == building_id).first()
    if not building:
        raise HTTPException(404, "Building not found")
    return building
```

### Audit Logging

```python
import json
from datetime import datetime, timezone
from typing import Optional, Dict
from sqlalchemy.orm import Session
from fastapi import Request
from spacewalker.models.tenant_models import TenantAuditLog

def log_tenant_action(
    tenant_id: int,
    user_id: str,
    action: str,
    resource_type: str,
    db: Session,
    resource_id: Optional[int] = None,
    details: Optional[Dict] = None,
    request: Optional[Request] = None
):
    """
    Log tenant-scoped actions for security auditing and compliance monitoring
    """
    log_entry = TenantAuditLog(
        tenant_id=tenant_id,
        user_id=user_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details=json.dumps(details) if details else None,
        ip_address=request.client.host if request else None,
        user_agent=request.headers.get("user-agent") if request else None,
        timestamp=datetime.utcnow()
    )
    db.add(log_entry)
    db.flush()  # Don't commit here - let caller manage transaction
```

---

## 📋 Testing Multi-Tenancy

### Unit Test Patterns

```python
@pytest.fixture
def tenant_context_db(db_session):
    """Database session with tenant context set"""
    with with_tenant_context(TEST_TENANT_ID):
        yield db_session

def test_tenant_isolation(tenant_context_db):
    """Verify RLS policies prevent cross-tenant access"""
    # Create data for different tenants
    tenant1_building = Building(name="Tenant 1 Building", tenant_id=1)
    tenant2_building = Building(name="Tenant 2 Building", tenant_id=2)

    tenant_context_db.add(tenant1_building)
    tenant_context_db.add(tenant2_building)
    tenant_context_db.commit()

    # Set tenant 1 context
    set_current_tenant_id(1)
    tenant_context_db.execute(text("SELECT set_current_tenant_id(1)"))

    # Should only see tenant 1 buildings
    buildings = tenant_context_db.query(Building).all()

    assert len(buildings) == 1
    assert buildings[0].tenant_id == 1
```

### Integration Test Examples

```python
def test_api_tenant_isolation():
    """Test API endpoints respect tenant boundaries"""
    # Create test client with tenant 1 user
    client = TestClient(app)

    # Create user with tenant 1
    user1 = User(id="user1", email="user1@test.com", tenant_id=1)
    db.add(user1)
    db.commit()

    # Create JWT token for user1
    tenant1_token = create_jwt_token(user_id="user1", tenant_id=1)

    # Attempt to access tenant 2 resource
    response = client.get(
        "/api/buildings/999",  # Building belongs to tenant 2
        headers={"Authorization": f"Bearer {tenant1_token}"}
    )

    assert response.status_code == 404  # Should not find cross-tenant resource
```

---

## 🔧 Operational Procedures

### Tenant Management Commands

```bash
# Database operations
just db verify                            # Check database and view all tenants
just db_demo_clean                        # Remove ONLY demo tenant data (preserves others)
just db_demo_minimal                      # Create demo tenant and users only

# AWS operations
just aws_s3_list dev tenant_123           # List S3 files for specific tenant
just aws_db_demo_clean dev                # Remove demo tenant data from cloud
just aws_init_demo_db dev                 # Initialize demo tenant in cloud database

# Direct database queries (for inspection)
just db shell                          # Access database shell for manual queries
# Then use: SELECT set_current_tenant_id(123); to set tenant context
```

### Production Monitoring

#### Tenant Metrics
- Active tenant count
- Per-tenant resource usage
- Cross-tenant access attempts (security alerts)
- Session context failures

#### Key Performance Indicators
- Tenant isolation policy effectiveness
- Query performance with RLS overhead
- Memory usage per tenant context
- Failed authentication attempts by tenant

---

## 🦸 Superuser Tenant Context Switching

### Overview

Superusers have special capabilities to access data across all tenants by switching their tenant context. This is implemented through the `X-Selected-Tenant-Id` header mechanism.

### Backend Implementation

The tenant context switching is handled in the `get_current_tenant_id` dependency:

```python
def get_current_tenant_id(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    x_selected_tenant_id: Optional[str] = Header(None),
) -> int:
    """Get the tenant ID from the current user or selected tenant header"""
    # Super users can select a tenant via header
    if current_user.is_super_user:
        if x_selected_tenant_id:
            try:
                selected_tenant_id = int(x_selected_tenant_id)
                # Verify tenant exists
                tenant = db.query(Tenant).filter(Tenant.id == selected_tenant_id).first()
                if not tenant:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Tenant {selected_tenant_id} not found",
                    )
                return selected_tenant_id
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid tenant ID format",
                )
        else:
            # Default to first available tenant if no selection
            first_tenant = db.query(Tenant).first()
            if not first_tenant:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="No tenants available"
                )
            return first_tenant.id

    # Regular users return their assigned tenant
    if not current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is not associated with any tenant",
        )
    return current_user.tenant_id
```

### Frontend Integration

The admin interface automatically includes the `X-Selected-Tenant-Id` header for superusers:

```typescript
// From apps/admin/src/lib/api.ts
if (typeof window !== 'undefined') {
  const selectedTenantId = localStorage.getItem('selectedTenantId');
  if (selectedTenantId) {
    config.headers['X-Selected-Tenant-Id'] = selectedTenantId;
  }
}
```

### Security Considerations

1. **Authentication Required**: Only users with `is_super_user = true` can use this feature
2. **Tenant Validation**: Selected tenant ID is validated on every request
3. **RLS Bypass**: Superusers with tenant context still go through RLS for data consistency
4. **Audit Trail**: All superuser actions are logged with the selected tenant context

### Testing Superuser Features

```python
def test_superuser_tenant_switching():
    """Test superuser can switch between tenant contexts"""
    # Create superuser
    superuser = User(id="super", email="super@test.com", is_super_user=True)
    db.add(superuser)

    # Create test tenants
    tenant1 = Tenant(name="Tenant 1", subdomain="tenant1")
    tenant2 = Tenant(name="Tenant 2", subdomain="tenant2")
    db.add_all([tenant1, tenant2])
    db.commit()

    # Create JWT token for superuser
    token = create_jwt_token(user_id="super", is_super_user=True)

    # Test accessing tenant 1 data
    response = client.get(
        "/api/buildings",
        headers={
            "Authorization": f"Bearer {token}",
            "X-Selected-Tenant-Id": str(tenant1.id)
        }
    )
    assert response.status_code == 200
    # Verify only tenant 1 buildings returned

    # Switch to tenant 2
    response = client.get(
        "/api/buildings",
        headers={
            "Authorization": f"Bearer {token}",
            "X-Selected-Tenant-Id": str(tenant2.id)
        }
    )
    assert response.status_code == 200
    # Verify only tenant 2 buildings returned
```

### Common Use Cases

1. **Cross-Tenant Support**: Debug issues for specific tenants
2. **Data Migration**: Move data between tenants
3. **Testing**: Verify tenant isolation and data integrity
4. **Reporting**: Generate cross-tenant analytics

---

## 📚 Related Documentation

- **Authentication API**: `docs/backend/authentication-api.md` - JWT implementation and user authentication
- **Database Architecture**: `docs/backend/database-architecture.md` - RLS policies and migration patterns
- **API Security**: `docs/backend/api-security.md` - Endpoint protection and validation
- **Multi-Tenant Testing**: `docs/backend/testing-guide.md` - Testing patterns for tenant isolation
- **Multi-Tenant Superuser**: `docs/admin/multi-tenant-superuser.md` - Frontend superuser features
- **FICM API**: `docs/backend/ficm-api.md` - FICM data and tenant context

---

**Status**: ✅ Complete comprehensive tenant management documentation covering RLS implementation, role-based access control, tenant provisioning workflows, security patterns, and operational procedures for the Spacewalker backend system.
