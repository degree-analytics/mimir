# Backend API Components

## Purpose
Detailed implementation documentation for the FastAPI backend components, including source code organization, API router structure, business logic services, and data access layer. Essential reference for backend developers working on server-side functionality and API development.

## When to Use This
- Implementing new backend API endpoints and business logic
- Understanding FastAPI router organization and service architecture
- Working with SQLAlchemy models and database components
- Debugging backend component interactions and dependencies
- Planning backend component modifications and extensions
- Keywords: FastAPI components, API routers, business logic, SQLAlchemy models, backend architecture

**Version:** 2.0 (Extracted from component diagrams)
**Date:** 2025-06-29
**Status:** Current - Production Implementation Reference

---

## 🏗️ Backend Component Architecture

The Backend API follows a layered architecture pattern with clear separation between API handling, business logic, and data access layers. This design ensures maintainability, testability, and scalability of the server-side components.

### Component Layer Organization
```
API Layer (HTTP Interface)
    ↓
Business Logic Layer (Services)
    ↓
Data Access Layer (Models & Database)
```

---

## 🌐 API Layer Components

### API Routers
**Location**: `apps/backend/src/spacecargo/api/routers/`
**Technology**: FastAPI APIRouter
**Status**: `[Implemented]`

**Responsibility**: Handles all incoming HTTP requests, validates payloads, manages authentication, and calls appropriate business logic services.

#### Router Organization
```
api/routers/
├── auth.py          # Authentication and authorization endpoints
├── surveys.py       # Survey CRUD operations and submission
├── buildings.py     # Building management endpoints
├── users.py         # User management and profile endpoints
├── health.py        # Health check and system status
└── __init__.py      # Router registration and configuration
```

#### Key Router Features
- **Request Validation** - Automatic Pydantic model validation for all payloads
- **Authentication Middleware** - JWT token validation and user context injection
- **Error Handling** - Consistent error response formatting across all endpoints
- **API Documentation** - Automatic OpenAPI/Swagger documentation generation
- **Rate Limiting** - Built-in request rate limiting for API protection

#### Example Router Pattern
```python
from fastapi import APIRouter, Depends, HTTPException
from spacecargo.services.survey_service import SurveyService
from spacecargo.models.survey import SurveyCreate, SurveyResponse

router = APIRouter(prefix="/api/surveys", tags=["surveys"])

@router.post("/", response_model=SurveyResponse)
async def create_survey(
    survey_data: SurveyCreate,
    survey_service: SurveyService = Depends(),
    current_user: User = Depends(get_current_user)
):
    return await survey_service.create_survey(survey_data, current_user)
```

---

## ⚙️ Business Logic Layer Components

### AI Service
**Location**: `apps/backend/src/spacecargo/ai/`
**Technology**: Google Gemini API Client
**Status**: `[Implemented]`

**Responsibility**: Orchestrates calls to Google Gemini for image analysis and survey processing.

#### AI Service Features
- **Image Analysis** - Processes survey images using Google Gemini vision models
- **Prompt Engineering** - Configurable prompts for different survey types
- **Response Processing** - Structured extraction of analysis results
- **Error Handling** - Graceful degradation when AI services are unavailable
- **Caching** - Response caching to reduce API costs and improve performance

#### Key Methods
```python
class AIService:
    async def analyze_survey_images(self, images: List[str]) -> AnalysisResult
    async def process_building_assessment(self, survey_data: SurveyData) -> Assessment
    async def validate_survey_quality(self, survey: Survey) -> QualityScore
```

### Survey Service
**Location**: `apps/backend/src/spacecargo/services/survey.py`
**Technology**: FastAPI Service Pattern
**Status**: `[Implemented]`

**Responsibility**: Core business logic for survey processing, validation, and workflow orchestration.

#### Survey Service Features
- **Survey Lifecycle Management** - Creation, validation, submission, and completion workflows
- **Data Validation** - Business rule validation beyond basic schema validation
- **Workflow Orchestration** - Coordinates AI analysis, data persistence, and notifications
- **Status Management** - Tracks survey progress through various states
- **Integration Coordination** - Manages interactions between AI service and database components

#### Service Methods
```python
class SurveyService:
    async def create_survey(self, survey_data: SurveyCreate, user: User) -> Survey
    async def submit_survey(self, survey_id: str, submission: SurveySubmission) -> Survey
    async def process_ai_analysis(self, survey_id: str) -> AnalysisResult
    async def validate_survey_completion(self, survey: Survey) -> ValidationResult
```

---

## 🗄️ Data Access Layer Components

### SQLAlchemy Models
**Location**: `apps/backend/src/spacecargo/models/`
**Technology**: SQLAlchemy 2.0 with Async Support
**Status**: `[Implemented]`

**Responsibility**: Defines the application's data structures, relationships, and database schema using SQLAlchemy's ORM.

#### Model Organization
```
models/
├── base.py          # Base model class with common fields
├── user.py          # User authentication and profile models
├── survey.py        # Survey data models and relationships
├── building.py      # Building and location models
├── analysis.py      # AI analysis result models
└── __init__.py      # Model registration and imports
```

#### Key Model Features
- **Relationship Mapping** - Comprehensive foreign key relationships between entities
- **Validation Rules** - SQLAlchemy validators for data integrity
- **Audit Fields** - Automatic created_at/updated_at timestamps
- **Soft Deletion** - Logical deletion with deleted_at timestamps
- **JSON Fields** - Flexible JSON columns for dynamic data storage

#### Example Model Structure
```python
class Survey(Base):
    __tablename__ = "surveys"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[SurveyStatus] = mapped_column(Enum(SurveyStatus))

    # Relationships
    user_id: Mapped[str] = mapped_column(String, ForeignKey("users.id"))
    user: Mapped["User"] = relationship("User", back_populates="surveys")

    # AI Analysis Results
    analyses: Mapped[List["Analysis"]] = relationship("Analysis", back_populates="survey")
```

### Database Session Management
**Location**: `apps/backend/src/spacecargo/db/`
**Technology**: SQLAlchemy Async Sessions with PostgreSQL
**Status**: `[Implemented]`

**Responsibility**: Manages database connection pool, session lifecycle, and transaction management.

#### Database Features
- **Connection Pooling** - Optimized connection pool configuration for concurrent requests
- **Async Operations** - Full async/await support for database operations
- **Transaction Management** - Automatic transaction handling with rollback on errors
- **Migration Support** - Alembic integration for schema versioning
- **Health Monitoring** - Database health checks and connection monitoring

#### Session Management Pattern
```python
from spacecargo.db.session import get_db

async def get_survey_by_id(survey_id: str, db: AsyncSession = Depends(get_db)) -> Survey:
    result = await db.execute(select(Survey).where(Survey.id == survey_id))
    return result.scalar_one_or_none()
```

---

## 🔄 Component Interaction Patterns

### Request Flow Through Components
```
HTTP Request → API Router → Business Service → Data Model → Database
     ↓              ↓              ↓              ↓           ↓
Validation → Authentication → Business Logic → ORM Query → SQL Execution
     ↓              ↓              ↓              ↓           ↓
Response ← JSON Serialization ← Service Response ← Model Instance ← Query Result
```

### Dependency Injection Pattern
- **Router Dependencies** - Services injected via FastAPI's dependency system
- **Service Dependencies** - Database sessions and external clients injected
- **Configuration Injection** - Environment-specific settings injected at startup
- **Testing Overrides** - Easy dependency mocking for unit and integration tests

### Error Handling Flow
```python
# Router Level - HTTP Error Responses
@router.post("/surveys")
async def create_survey(...):
    try:
        result = await survey_service.create_survey(...)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except ServiceError as e:
        raise HTTPException(status_code=500, detail="Internal server error")

# Service Level - Business Logic Errors
class SurveyService:
    async def create_survey(self, ...):
        if not self.validate_survey_data(data):
            raise ValidationError("Invalid survey data")

        try:
            return await self.repository.create(data)
        except DatabaseError as e:
            raise ServiceError("Failed to create survey") from e
```

---

## 🧪 Component Testing Strategies

### API Router Testing
```python
# Test API endpoints with FastAPI TestClient
@pytest.mark.asyncio
async def test_create_survey_endpoint(client: TestClient, auth_headers: dict):
    survey_data = {"title": "Test Survey", "description": "Test"}
    response = client.post("/api/surveys", json=survey_data, headers=auth_headers)
    assert response.status_code == 201
    assert "id" in response.json()
```

### Service Layer Testing
```python
# Test business logic with mocked dependencies
@pytest.mark.asyncio
async def test_survey_service_create(mock_db_session, mock_ai_service):
    service = SurveyService(db=mock_db_session, ai_service=mock_ai_service)
    result = await service.create_survey(test_survey_data, test_user)
    assert result.status == SurveyStatus.DRAFT
```

### Model Testing
```python
# Test SQLAlchemy models with test database
@pytest.mark.asyncio
async def test_survey_model_relationships(db_session):
    survey = Survey(title="Test", user_id=user.id)
    db_session.add(survey)
    await db_session.commit()

    loaded_survey = await db_session.get(Survey, survey.id)
    assert loaded_survey.user.email == user.email
```

---

## 📊 Component Performance Considerations

### API Router Optimization
- **Request Validation** - Use Pydantic models with efficient validation rules
- **Response Serialization** - Optimize JSON serialization for large datasets
- **Middleware Performance** - Minimize middleware overhead in request processing
- **Endpoint Caching** - Implement response caching for read-heavy endpoints

### Service Layer Performance
- **Business Logic Efficiency** - Optimize complex business rules and calculations
- **External API Management** - Simple circuit breakers and rate limiters for external service protection
- **Caching Strategies** - Cache expensive computations and AI analysis results with bounded cleanup
- **Async Operations** - Use async/await for all I/O bound operations

### Database Component Performance
- **Query Optimization** - Use SQLAlchemy query optimization techniques
- **Connection Pooling** - Configure optimal connection pool settings
- **Index Strategy** - Implement database indexes for common query patterns
- **Batch Operations** - Use bulk operations for large data sets

---

## 🔧 Component Configuration

### Environment Configuration
```python
# Database Configuration
DATABASE_URL = "postgresql+asyncpg://user:pass@host:port/db"
DATABASE_POOL_SIZE = 20
DATABASE_MAX_OVERFLOW = 30

# AI Service Configuration
GEMINI_API_KEY = "your-api-key"
GEMINI_MODEL = "gemini-1.5-pro"
GEMINI_MAX_TOKENS = 4000

# API Configuration
API_PREFIX = "/api"
CORS_ORIGINS = ["http://localhost:3000"]
JWT_SECRET_KEY = "your-secret-key"
```

### Component Initialization
```python
# Application startup configuration
async def create_app() -> FastAPI:
    app = FastAPI(title="Spacewalker API")

    # Initialize database
    await init_database(app)

    # Register routers
    app.include_router(auth_router)
    app.include_router(survey_router)

    # Configure middleware
    app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS)

    return app
```

---

## 🛡️ Simplified Protection Services

### Simple Circuit Breaker
**Location**: `apps/backend/src/spacecargo/api/services/simple_circuit_breaker.py`
**Technology**: Python with Async Support
**Status**: `[Implemented]`

**Responsibility**: Provides basic fault tolerance for external service calls without over-engineering complexity.

#### Circuit Breaker Features
- **Two-State Design** - Simple CLOSED/OPEN states (no half-open complexity)
- **Failure Threshold** - Configurable failure count before circuit opens (default: 3)
- **Recovery Timeout** - Automatic circuit closure after timeout period (default: 60s)
- **Request Timeout** - Configurable timeout for external calls (default: 30s)
- **Scale-Appropriate** - Designed for current application scale, not enterprise complexity

#### Usage Pattern
```python
from spacecargo.api.services.simple_circuit_breaker import SimpleCircuitBreaker

circuit_breaker = SimpleCircuitBreaker(
    name="gemini_api",
    failure_threshold=3,
    recovery_timeout=60
)

async def call_external_service():
    return await circuit_breaker.call(external_api_function)
```

### Simple Rate Limiter
**Location**: `apps/backend/src/spacecargo/api/services/simple_rate_limiter.py`
**Technology**: Token Bucket Algorithm
**Status**: `[Implemented]`

**Responsibility**: Provides basic rate limiting protection for external APIs without adaptive complexity.

#### Rate Limiter Features
- **Token Bucket Algorithm** - Simple, well-understood rate limiting approach
- **Configurable Limits** - Max requests per time window (default: 10 req/60s)
- **Non-Blocking Design** - Bounded operations to prevent request blocking
- **Memory Efficient** - Minimal memory footprint for tracking state
- **Scale-Appropriate** - Optimized for current usage patterns

#### Usage Pattern
```python
from spacecargo.api.services.simple_rate_limiter import SimpleRateLimiter

rate_limiter = SimpleRateLimiter(
    max_requests=10,
    time_window=60
)

async def rate_limited_api_call():
    if await rate_limiter.is_allowed("api_client_id"):
        return await make_api_call()
    else:
        raise RateLimitExceeded("Too many requests")
```

---

## 📋 Related Backend Documentation

### API Documentation
> 🚀 **API Reference**: See [API Contracts](./architecture/api-contracts.md) for detailed endpoint specifications and request/response schemas

### Development Resources
- **[Development Setup](../setup/development-setup.md)** - Development environment configuration
- **[Database Migrations](./database-migrations.md)** - Schema versioning and deployment procedures
- **[Testing Guide](../workflows/testing-guide.md)** - Comprehensive testing approaches for backend components

### Architecture Context
- **[Component Architecture](../architecture/component-diagrams.md)** - Cross-system component relationships and interactions

---

**Status**: ✅ **PRODUCTION IMPLEMENTATION REFERENCE**
**Last Updated**: 2025-06-29
**Component Scope**: FastAPI Backend API Layer, Business Logic, and Data Access
**Technology Stack**: FastAPI, SQLAlchemy, PostgreSQL, Google Gemini API

---

*This backend component documentation provides comprehensive implementation guidance for developers working on the FastAPI server-side architecture, ensuring consistent patterns and maintainable code across all backend services.*
