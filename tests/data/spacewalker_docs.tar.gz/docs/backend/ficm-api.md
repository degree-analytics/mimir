# FICM API Documentation

## Purpose
Documents the FICM (Facilities Inventory and Classification Manual) API endpoints, data structures, and integration patterns for room classification in Spacewalker.

## When to Use This
- Integrating with FICM classification system
- Understanding FICM hierarchy data structure
- Implementing room classification features
- Debugging FICM data loading issues

**Keywords:** FICM, room classification, hierarchy API, facilities inventory, room codes

## Overview

The FICM API provides endpoints for managing and retrieving facility classification codes used to categorize university spaces. These codes follow a hierarchical structure: Categories → Base Codes → Design Types.

## API Endpoints

### Get FICM Hierarchy
```
GET /api/ficm/hierarchy
```

Returns a **flat array** of all FICM codes with their complete hierarchy information.

#### Response Structure
```typescript
interface FICMHierarchyResponse {
  category_code: string;        // e.g., "100"
  category_name: string;        // e.g., "Classroom Facilities"
  category_description?: string;
  base_code: string;           // e.g., "110"
  base_name: string;           // e.g., "Classroom"
  base_description?: string;
  design_type_code?: string;   // e.g., "110-LCT"
  design_type_name?: string;   // e.g., "Lecture Hall"
  design_type_description?: string;
  full_code: string;           // Complete code (design type or base)
  full_name: string;           // Complete name
  full_description?: string;
  // Enhanced metadata
  ai_keywords?: string[];
  typical_equipment?: string[];
  distinguishing_features?: string[];
  capacity_range?: string;
  seating_style?: string;
}
```

#### Example Response
```json
[
  {
    "category_code": "100",
    "category_name": "Classroom Facilities",
    "category_description": "Spaces primarily designed for instruction",
    "base_code": "110",
    "base_name": "Classroom",
    "base_description": "General teaching spaces",
    "design_type_code": "110-LCT",
    "design_type_name": "Lecture Hall",
    "design_type_description": "Large classroom with tiered seating",
    "full_code": "110-LCT",
    "full_name": "Lecture Hall",
    "full_description": "Large classroom with tiered seating...",
    "ai_keywords": ["tiered", "lecture", "auditorium"],
    "typical_equipment": ["projector", "microphone", "podium"],
    "capacity_range": "50-500",
    "seating_style": "fixed_tiered"
  },
  {
    "category_code": "100",
    "category_name": "Classroom Facilities",
    "base_code": "110",
    "base_name": "Classroom",
    "design_type_code": null,
    "design_type_name": null,
    "full_code": "110",
    "full_name": "Classroom",
    "full_description": "General teaching spaces..."
  }
]
```

### Important Notes

1. **Flat Structure**: The API returns a flat array, not a hierarchical tree
2. **Duplicate Base Codes**: Base codes appear multiple times (once for each design type)
3. **Optional Design Types**: Not all entries have design types
4. **Full Code Logic**: 
   - If `design_type_code` exists, `full_code` = `design_type_code`
   - Otherwise, `full_code` = `base_code`

## Frontend Integration

### Processing the Flat Array

When consuming the hierarchy API in the frontend:

```typescript
const loadFicmCodes = async () => {
  const data = await ficm.getHierarchy();
  const allCodes: FICMCode[] = [];
  
  // Process flat array - each item is a complete code
  data.forEach((item: FICMHierarchyResponse) => {
    if (item.full_code && item.full_name) {
      allCodes.push({
        code: item.full_code,
        name: item.full_name,
        description: item.full_description || '',
      });
    }
  });
  
  return allCodes;
};
```

### Common Pitfall

The API response is **not** hierarchical. Don't expect:
```typescript
// ❌ WRONG - API doesn't return this structure
{
  category: "100",
  base_codes: [
    {
      code: "110",
      design_types: [...]
    }
  ]
}
```

## Tenant Isolation

- FICM data is tenant-specific
- Filtered by `tenant_id` in all queries
- Superusers must select appropriate tenant context

## Database Schema

### Tables
- `ficm_categories`: Top-level facility categories
- `ficm_base_codes`: Base classification codes
- `ficm_design_types`: Specific design variations

### Relationships
```
ficm_categories (1) → (many) ficm_base_codes
ficm_base_codes (1) → (many) ficm_design_types
```

## Other FICM Endpoints

### Get Categories
```
GET /api/ficm/categories
```

### Get Base Codes
```
GET /api/ficm/base-codes
```

### Get Design Types
```
GET /api/ficm/design-types
```

### Search FICM Codes
```
GET /api/ficm/search?query=classroom
```

## Integration with AI Prompts

FICM codes are automatically included in AI analysis prompts:
1. Backend queries all active FICM data for the tenant
2. Formats into structured prompt sections
3. AI uses these codes to classify room images

## Troubleshooting

### No FICM Codes Loading
1. Check tenant context (superusers)
2. Verify FICM data exists: `just ficm_status`
3. Ensure frontend processes flat array correctly
4. Check browser console for API errors

### Incorrect Data Structure
- Remember: API returns flat array, not nested hierarchy
- Each row represents one complete code path
- Process `full_code` and `full_name` fields

## Related Documentation
- [AI Prompt Management](./ai-prompt-management.md)
- [Tenant Management](./tenant-management.md)
- [Multi-Tenant Superuser](../admin/multi-tenant-superuser.md)

## Version History
- **v1.0** (2025-01-16): Documented flat array structure and common pitfalls