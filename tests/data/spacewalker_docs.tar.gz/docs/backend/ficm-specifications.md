# FICM Room Classification Specifications

## Purpose
Complete FICM (Facilities Inventory and Classification Manual) room classification standards and specifications used throughout the Spacewalker system. Essential reference for understanding room types, attributes, and classification requirements.

## When to Use This
- Understanding room classification standards and FICM codes
- Implementing room type detection and validation logic
- Designing AI prompts for room classification
- Validating survey data against FICM requirements
- Training staff on proper room classification procedures
- Keywords: FICM, room classification, facility inventory, room types, space categories

**Version:** 2.0 (Extracted from comprehensive PRD)
**Date:** 2025-06-29
**Status:** Current - FICM Standards Reference

---

## 📚 FICM Overview

The Spacewalker app aligns with the [FICM 2006 Edition](https://nces.ed.gov/pubs2006/ficm/), covering assignable and nonassignable space categories used by educational institutions for facility management and reporting.

### FICM Purpose
- **Standardization:** Consistent room classification across institutions
- **Reporting:** Federal and state facility reporting requirements
- **Planning:** Space utilization and facility planning
- **Compliance:** Educational facility standards compliance

### Classification Structure
- **Assignable Space:** Rooms with specific functional purposes (100-900 series)
- **Nonassignable Space:** Support and circulation spaces (A-C series)
- **Attributes:** Room-specific characteristics captured for each space type

---

## 🏫 Assignable Space Categories (100-900 Series)

### 100 Series: Classroom Facilities
**Purpose:** General teaching spaces for instruction and learning

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 110       | Classroom                    | General purpose classroom                        |
| 115       | Classroom Service            | Storage and prep areas for classrooms           |

#### Key Attributes Captured
- **Seating Capacity:** Number of student stations
- **Seating Type:** Fixed, movable, tiered, or flexible
- **Technology:** Projector, interactive board, audio/visual equipment
- **Writing Surfaces:** Whiteboards, chalkboards, smart boards
- **Room Style:** Traditional, flexible, seminar, or lecture hall

#### Examples
- Traditional lecture halls with fixed seating
- Flexible classrooms with movable furniture
- Technology-enhanced active learning spaces
- Seminar rooms for small group instruction

---

### 200 Series: Laboratory Facilities
**Purpose:** Instructional or research laboratories with specialized equipment

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 210       | Class Laboratory             | Instructional laboratory                         |
| 215       | Class Lab Service            | Lab prep and storage areas                      |
| 220       | Open Laboratory              | Unscheduled lab access                          |
| 230       | Research/Nonclass Laboratory | Research-focused laboratories                    |
| 235       | Research Lab Service         | Research lab support spaces                     |

#### Key Attributes Captured
- **Lab Type:** Chemistry, biology, physics, computer, engineering
- **Bench Count:** Number of work stations or lab benches
- **Safety Equipment:** Fume hoods, eyewash stations, safety showers
- **Utilities:** Gas, compressed air, vacuum, electrical capacity
- **Containment Level:** Biosafety level or chemical safety rating

#### Examples
- General chemistry teaching laboratories
- Specialized research laboratories
- Computer programming laboratories
- Engineering design studios

---

### 300 Series: Office Facilities
**Purpose:** Administrative or faculty office spaces

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 310       | Office                       | Individual or shared office space               |
| 315       | Office Service               | Office support and storage areas               |

#### Key Attributes Captured
- **Occupant Information:** Name, department, title
- **Office Type:** Private, shared, open plan, or cubicle
- **Furniture:** Desk, chairs, filing cabinets, bookshelves
- **Technology:** Computer, phone, network access

#### Examples
- Faculty private offices
- Administrative staff offices
- Department head offices
- Shared graduate student offices

---

### 400 Series: Study Facilities
**Purpose:** Individual or group study areas

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 410       | Study Room                   | Individual or group study spaces                |
| 415       | Study Service                | Study area support spaces                      |

#### Key Attributes Captured
- **Seating Count:** Number of study stations
- **Furniture:** Tables, chairs, carrels, lounge seating
- **Technology:** Power outlets, network access, displays
- **Noise Level:** Quiet, collaborative, or silent study

#### Examples
- Library individual study carrels
- Group study rooms with whiteboards
- Graduate student study spaces
- Collaborative learning areas

---

### 500 Series: Special Use Facilities
**Purpose:** Specialized spaces for unique functions

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 520       | Athletics/Physical Education | Gymnasium, courts, fitness areas                |
| 530       | Media Production             | Audio/video production facilities               |
| 540       | Clinic                       | Health and medical facilities                   |
| 550       | Demonstration                | Live animal, greenhouse, observatory            |
| 570       | Fieldwork                    | Outdoor education and research                  |

#### Key Attributes Captured
- **Equipment:** Specialized equipment and fixtures
- **Capacity:** Maximum occupancy or usage capacity
- **Safety Features:** Safety equipment and protocols
- **Surface Type:** Flooring, wall, and ceiling materials

#### Examples
- Athletic courts and gymnasiums
- Television/radio production studios
- Campus health centers
- Greenhouse and observatory facilities

---

### 600 Series: General Use Facilities
**Purpose:** Multi-purpose communal spaces

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 610       | Assembly                     | Auditoriums, theaters, meeting rooms            |
| 620       | Exhibition                   | Museums, galleries, display areas               |
| 630       | Food Facility                | Dining halls, cafeterias, food service          |
| 640       | Day Care                     | Child care and early education                  |
| 650       | Lounge                       | Social and informal gathering spaces            |
| 660       | Merchandising                | Bookstores, retail spaces                       |
| 670       | Recreation                   | Gaming, entertainment, leisure activities       |

#### Key Attributes Captured
- **Seating Capacity:** Maximum occupancy
- **Amenities:** Kitchen facilities, AV equipment, special features
- **AV Equipment:** Sound systems, lighting, projection
- **Dining Style:** Cafeteria, food court, formal dining

#### Examples
- Large auditoriums and lecture halls
- Student dining facilities
- Campus bookstores
- Student recreation centers

---

### 700 Series: Support Facilities
**Purpose:** Operational support spaces

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 710       | Central Service              | Mail, printing, telecommunications              |
| 720       | Shop                         | Maintenance, fabrication, repair                |
| 730       | Central Storage              | General institutional storage                   |
| 740       | Vehicle Storage              | Parking, vehicle maintenance                    |
| 750       | Hazardous Materials          | Chemical storage, waste management              |

#### Key Attributes Captured
- **Equipment List:** Major equipment and tools
- **Hazard Storage:** Types of hazardous materials
- **Access Restrictions:** Security and safety requirements
- **Shelving Capacity:** Storage volume and organization

#### Examples
- Central receiving and mail facilities
- Maintenance workshops
- Chemical storage rooms
- Vehicle maintenance facilities

---

### 800 Series: Health Care Facilities
**Purpose:** Medical or wellness spaces

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 810       | Patient Care                 | Treatment rooms, examination areas              |
| 820       | Diagnostic Service           | Medical testing and diagnostic equipment        |
| 830       | Therapy                      | Physical, occupational, mental health therapy   |
| 840       | Pharmacy                     | Medication storage and dispensing               |
| 850       | Medical Research             | Clinical and medical research spaces            |

#### Key Attributes Captured
- **Treatment Rooms:** Number and type of treatment areas
- **Medical Equipment:** Specialized medical devices
- **Waiting Area Size:** Patient and visitor capacity
- **Compliance Notes:** Healthcare regulations and standards

#### Examples
- Student health centers
- Physical therapy clinics
- Counseling and mental health facilities
- Campus medical research labs

---

### 900 Series: Residential Facilities
**Purpose:** Housing spaces for students, faculty, or staff

| FICM Code | Category                     | Description                                      |
|-----------|------------------------------|--------------------------------------------------|
| 910       | Sleep/Study without Toilet   | Dormitory rooms without private bathrooms       |
| 919       | Sleep/Study with Toilet      | Dormitory rooms with private bathrooms          |
| 920       | Apartment                    | Multi-room residential units                    |
| 930       | House                        | Single-family residential units                 |
| 935       | Residential Service          | Housing support facilities                      |

#### Key Attributes Captured
- **Bed Count:** Number of sleeping accommodations
- **Room Type:** Single, double, suite, apartment
- **Furniture:** Beds, desks, storage, seating
- **Accessibility:** ADA compliance and accessibility features

#### Examples
- Traditional dormitory rooms
- Suite-style student housing
- Graduate student apartments
- Faculty housing

---

## 🏗️ Nonassignable Space Categories (A-C Series)

### A Series: Circulation Areas
**Purpose:** Corridors, lobbies, stairways, and movement spaces

| FICM Code | Category       | Description                     |
|-----------|----------------|---------------------------------|
| A10       | Corridor       | Interior corridors and hallways |
| A20       | Lobby          | Building entrances and lobbies  |
| A30       | Stairway       | Staircases and stairwells       |
| A40       | Elevator       | Elevator shafts and machine rooms |
| A50       | Bridge         | Connecting bridges between buildings |

#### Key Attributes Captured
- **Width:** Corridor width for accessibility compliance
- **Accessibility:** Ramps, elevators, accessibility features
- **Lighting:** Natural and artificial lighting adequacy
- **Condition:** Maintenance status and repair needs

---

### B Series: Mechanical Areas
**Purpose:** Mechanical rooms, utility plants, and building systems

| FICM Code | Category       | Description                     |
|-----------|----------------|---------------------------------|
| B10       | Mechanical     | HVAC, electrical, plumbing equipment |
| B20       | Fuel           | Fuel storage and distribution   |
| B30       | Utility        | Utility distribution and access |

#### Key Attributes Captured
- **Equipment List:** Major mechanical and utility equipment
- **Access Restrictions:** Security and maintenance access
- **Condition:** Equipment condition and maintenance status

---

### C Series: Structural Areas
**Purpose:** Unfinished basements, attics, and structural spaces

| FICM Code | Category       | Description                     |
|-----------|----------------|---------------------------------|
| C10       | Unfinished     | Unfinished basements and attics |
| C20       | Unusable       | Spaces too small or inaccessible for use |

#### Key Attributes Captured
- **Condition:** Structural condition and finish status
- **Potential Use:** Possible future conversion or renovation

---

## 🔍 Implementation in Spacewalker

### AI Classification
The Spacewalker system uses Google Gemini AI to analyze room images and suggest FICM classifications based on:
- **Visual Recognition:** Room furniture, equipment, and layout
- **Contextual Clues:** Signage, technology, and spatial organization
- **Attribute Detection:** Specific features that indicate room function

### Data Validation
All survey submissions are validated against FICM standards:
- **Code Validation:** Ensures valid FICM codes are used
- **Attribute Consistency:** Verifies attributes match room type
- **Completeness Checking:** Ensures required attributes are captured

### Reporting Compliance
FICM classifications enable:
- **Federal Reporting:** IPEDS (Integrated Postsecondary Education Data System) compliance
- **State Reporting:** State-specific facility reporting requirements
- **Institutional Planning:** Space utilization and planning analysis

---

## 📚 Related Documentation

### System Integration
- **[Backend Architecture](../backend/architecture/README.md)** - FICM data modeling and validation logic
- **[Mobile Architecture](../mobile/architecture/README.md)** - Mobile FICM classification interface
- **[Admin Architecture](../admin/architecture/README.md)** - Admin FICM review and approval workflows

### Development Resources
- **[Development Setup](../setup/development-setup.md)** - Development environment for FICM implementation
- **[Product Overview](../product/product-overview.md)** - System overview including FICM integration

### External References
- **[FICM 2006 Edition](https://nces.ed.gov/pubs2006/ficm/)** - Official FICM documentation
- **[IPEDS Reporting](https://nces.ed.gov/ipeds/)** - Federal reporting requirements using FICM

---

**Status**: ✅ Updated and current as of 2025-06-29. Extracted from comprehensive PRD and enhanced with detailed FICM specifications and implementation guidance.
