# Backend Development Guide

## Purpose
Comprehensive development guide for the FastAPI-based backend service including environment setup, development workflows, and troubleshooting.

## When to Use This
- Setting up backend development environment
- Daily backend development workflows and commands
- Debugging backend issues and common problems
- Keywords: FastAPI development, Docker backend, database migrations, backend testing

## Prerequisites
- [ ] Docker and Docker Compose installed
- [ ] Project cloned and `just` command available
- [ ] Basic familiarity with Python and FastAPI

## Quick Start

### Essential Commands
```bash
# Start backend service
just backend

# Run all backend tests
just test-backend

# Open shell in backend container
just backend-sh

# Create database migration
just backend-alembic-revision

# Apply database migrations
just backend-alembic-upgrade
```

## Development Environment

The backend service runs inside a Docker container, orchestrated by `just` and `docker-compose`. All commands should be run from the **project root**.

### Key Features
- **Hot Reloading**: Live code reloading for any changes in `apps/backend/src/`
- **Dependencies**: Python dependencies managed with `uv` in [`pyproject.toml`](../../../apps/backend/pyproject.toml)
- **Virtual Environment**: Dependencies installed in `.venv/` inside the backend directory
- **Containerized**: Consistent development environment across all team members

### Development Workflow
1. **Start Backend**: `just backend` (runs in foreground with live reload)
2. **Make Code Changes**: Edit files in `apps/backend/src/spacecargo/`
3. **Auto-Reload**: Service automatically restarts when files change
4. **Run Tests**: `just test-backend` to verify changes
5. **Debug Issues**: `just backend-sh` for container shell access

## Project Structure

The backend follows a `src` layout with all application code in `apps/backend/src/spacecargo/`:

```
apps/backend/
├── src/spacecargo/
│   ├── api/          # FastAPI application, routers, dependencies
│   ├── models/       # SQLAlchemy ORM models
│   ├── db/           # Database session and connection logic
│   ├── ai/           # Google Gemini API integration
│   └── services/     # Business logic services
├── migrations/       # Alembic database migration scripts
├── tests/           # pytest tests (unit & integration)
└── pyproject.toml   # Python dependencies and project config
```

### Code Organization Patterns
- **API Layer**: Route handlers in `api/` with minimal business logic
- **Service Layer**: Business logic in `services/` for testability
- **Model Layer**: SQLAlchemy models in `models/` with relationships
- **Database Layer**: Session management and queries in `db/`

## API Documentation

FastAPI provides auto-generated interactive documentation:

- **Swagger UI**: [http://localhost:8000/docs](http://localhost:8000/docs) (recommended for testing)
- **ReDoc**: [http://localhost:8000/redoc](http://localhost:8000/redoc) (better for reading)
- **OpenAPI Schema**: [http://localhost:8000/openapi.json](http://localhost:8000/openapi.json)

### Using API Documentation
1. Start backend: `just backend`
2. Open [http://localhost:8000/docs](http://localhost:8000/docs)
3. Click "Authorize" to add JWT token for protected endpoints
4. Test endpoints directly in the browser

## Database Development

### Migration Workflow
```bash
# Create new migration
just backend-alembic-revision -m "description of change"

# Review generated migration file
# Edit apps/backend/migrations/versions/[hash]_description.py if needed

# Apply migrations
just backend-alembic-upgrade

# Check current migration status
just backend-alembic-current
```

### Database Commands
```bash
# Check database status
just db-status

# Reset database (destructive - wipes all data)
just db-reset

# Access database directly
just db-shell
```

## Testing Strategy

### Current Test Status
- **Test Coverage**: 142/164 tests passing
- **Test Framework**: pytest with fixtures and factories
- **Test Database**: Ephemeral PostgreSQL via Testcontainers
- **Test Types**: Unit tests, integration tests, API endpoint tests

### Running Tests
```bash
# Run all backend tests
just test-backend

# Run specific test file
just test unit backend -- tests/test_specific_file.py

# Run tests with coverage
just test unit backend --coverage

# Run tests with verbose output
just test unit backend --verbose
```

### Test Organization
- **Unit Tests**: `tests/unit/` - Test individual functions and classes
- **Integration Tests**: `tests/integration/` - Test component interactions
- **API Tests**: `tests/api/` - Test HTTP endpoints end-to-end

## Common Issues and Solutions

### Development Environment Issues

| Symptom | Cause | Solution |
|---------|-------|----------|
| **`ModuleNotFoundError`** | Python interpreter can't find `spacecargo` package | Run `just backend-restart` to refresh container |
| **DB Connection Errors** | Database not ready when backend starts | Check `just db-status`, then `just backend-restart` |
| **Import Errors** | Package dependencies out of sync | Run `just backend-sh` then `uv sync` |
| **Port Already in Use** | Backend port 8000 occupied | Stop other services or use `just backend-stop` first |

### Database Issues

| Symptom | Cause | Solution |
|---------|-------|----------|
| **Alembic "Target DB not up to date"** | Manual DB changes or sync issues | Run `just db-reset` (destroys data) or debug migration state |
| **Migration Conflicts** | Multiple developers creating migrations | Resolve in migration files, then `just backend-alembic-upgrade` |
| **Connection Timeouts** | Database container not healthy | Check `just db-logs` and restart if needed |

### Performance Issues

| Symptom | Cause | Solution |
|---------|-------|----------|
| **Slow API Responses** | Missing database indexes or N+1 queries | Check query logs and add indexes or optimize queries |
| **High Memory Usage** | SQLAlchemy session leaks | Ensure proper session cleanup in service layer |
| **Container Startup Slow** | Large dependency installation | Check Docker layer caching and optimize Dockerfile |

## Development Best Practices

### Code Quality
- **Type Hints**: Use Python type hints for all function signatures
- **Pydantic Models**: Use for request/response validation
- **Error Handling**: Use proper HTTP status codes and error responses
- **Async/Await**: Use async patterns for database and external API calls

### Testing Practices
- **Test First**: Write tests before implementing features
- **Factory Pattern**: Use factories for creating test data
- **Isolated Tests**: Each test should be independent and clean up after itself
- **Mock External APIs**: Mock calls to Gemini API and other external services

### Database Practices
- **Migration Safety**: Always review generated migrations before applying
- **Transaction Management**: Use proper transaction boundaries in services
- **Connection Pooling**: Let SQLAlchemy handle connection pooling
- **Query Optimization**: Use `select()` with proper joins to avoid N+1 queries

## Related Documentation
- Backend Architecture → ../backend/architecture/README.md
- API Contract Specification → ../backend/architecture/api-contracts.md
- Database Schema Design → ../backend/architecture/database.md
- Security Implementation → ../backend/architecture/security-implementation.md
- Database Migration Guide → ./database-migrations.md

---
Last Updated: 2025-06-28
Status: Current
